import { useEmployeeStore } from '@/store/employeeStore';

/**
 * Custom hook for role-based access control
 * @returns {Object} Object containing role checking functions and current role
 */
export const useRoleAccess = () => {
    const { userRole } = useEmployeeStore();

    /**
     * Check if current user is admin
     * @returns {boolean}
     */
    const isAdmin = () => userRole === 'admin';

    /**
     * Check if current user is regular user
     * @returns {boolean}
     */
    const isUser = () => userRole === 'user';

    /**
     * Check if user has any of the specified roles
     * @param {string|string[]} roles - Role or array of roles to check
     * @returns {boolean}
     */
    const hasRole = (roles) => {
        if (!userRole) return false;
        
        if (Array.isArray(roles)) {
            return roles.includes(userRole);
        }
        
        return userRole === roles;
    };

    /**
     * Check if user has admin role
     * @returns {boolean}
     */
    const hasAdminAccess = () => hasRole('admin');

    /**
     * Check if user has user role
     * @returns {boolean}
     */
    const hasUserAccess = () => hasRole('user');

    /**
     * Get current user role
     * @returns {string|null}
     */
    const getCurrentRole = () => userRole;

    return {
        userRole,
        isAdmin,
        isUser,
        hasRole,
        hasAdminAccess,
        hasUserAccess,
        getCurrentRole,
    };
};

/**
 * Higher-order component for role-based component rendering
 * @param {React.Component} Component - Component to render
 * @param {string|string[]} allowedRoles - Roles allowed to see this component
 * @param {React.Component} FallbackComponent - Component to render if role doesn't match
 * @returns {React.Component}
 */
export const withRoleAccess = (Component, allowedRoles, FallbackComponent = null) => {
    return (props) => {
        const { hasRole } = useRoleAccess();
        
        if (hasRole(allowedRoles)) {
            return <Component {...props} />;
        }
        
        return FallbackComponent ? <FallbackComponent {...props} /> : null;
    };
};

/**
 * Component for conditional rendering based on role
 * @param {Object} props
 * @param {string|string[]} props.allowedRoles - Roles allowed to see this component
 * @param {React.ReactNode} props.children - Content to render if role matches
 * @param {React.ReactNode} props.fallback - Content to render if role doesn't match
 * @returns {React.ReactNode}
 */
export const RoleGuard = ({ allowedRoles, children, fallback = null }) => {
    const { hasRole } = useRoleAccess();
    
    if (hasRole(allowedRoles)) {
        return children;
    }
    
    return fallback;
};
