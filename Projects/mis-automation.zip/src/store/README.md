# Employee Store Documentation

## Overview

The `useEmployeeStore` is a Zustand store that manages employee details fetched from the SSO API. It provides a centralized way to store and access employee information across the application.

## Features

- **Centralized State Management**: Store employee details in a global state
- **Automatic API Integration**: Fetch employee details using access token
- **Error Handling**: Built-in error handling and loading states
- **Session Integration**: Automatically initialize from localStorage session
- **Type Safety**: Proper state management with clear interfaces

## Usage

### Basic Usage

```javascript
import { useEmployeeStore } from "@/store/employeeStore";

const MyComponent = () => {
  const { employeeDetails, loading, error, getLoggedInUserDetails } =
    useEmployeeStore();

  // Fetch employee details with access token
  const fetchEmployeeDetails = async (accessToken) => {
    const result = await getLoggedInUserDetails(accessToken);
    if (result.success) {
      console.log("Employee details:", result.data);
    } else {
      console.error("Error:", result.error);
    }
  };

  return (
    <div>
      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      {employeeDetails && (
        <div>
          <h3>{employeeDetails.name}</h3>
          <p>Employee Code: {employeeDetails.employee_code}</p>
        </div>
      )}
    </div>
  );
};
```

### Initialize from Session

```javascript
import { useEmployeeStore } from "@/store/employeeStore";

const MyComponent = () => {
  const { initializeEmployeeDetails } = useEmployeeStore();

  useEffect(() => {
    // This will automatically fetch employee details from localStorage session
    initializeEmployeeDetails();
  }, []);

  // ... rest of component
};
```

### Using the EmployeeDetailsDisplay Component

```javascript
import EmployeeDetailsDisplay from "@/components/EmployeeDetailsDisplay";

const MyComponent = () => {
  const session = JSON.parse(localStorage.getItem("session") || "null");

  return (
    <div>
      <EmployeeDetailsDisplay
        accessToken={session?.accessToken}
        showApiInfo={true}
      />
    </div>
  );
};
```

## Store Methods

### `getLoggedInUserDetails(accessToken)`

Fetches employee details from the API using the provided access token.

**Parameters:**

- `accessToken` (string): The bearer token for API authentication

**Returns:**

- `{ success: boolean, data?: object, error?: string }`

### `initializeEmployeeDetails()`

Attempts to fetch employee details using the access token from localStorage session.

**Returns:**

- `{ success: boolean, data?: object, error?: string }`

### `setEmployeeDetails(details)`

Manually sets employee details in the store.

**Parameters:**

- `details` (object): Employee details object

### `clearEmployeeDetails()`

Clears employee details from the store.

### `setLoading(loading)`

Sets the loading state.

**Parameters:**

- `loading` (boolean): Loading state

### `setError(error)`

Sets the error state.

**Parameters:**

- `error` (string): Error message

### `setUserRole(role)`

Manually sets the user role.

**Parameters:**

- `role` (string): 'admin' or 'user'

### `checkAndSetUserRole(employeeCode)`

Automatically determines and sets the user role based on employee code.

**Parameters:**

- `employeeCode` (string): Employee code to check against admin code

**Returns:**

- `string`: The determined role ('admin' or 'user')

## Store State

```javascript
{
    employeeDetails: null,    // Employee details object
    userRole: null,          // 'admin' or 'user'
    loading: false,          // Loading state
    error: null             // Error message
}
```

## Integration with SSO Login

The employee store is automatically integrated with the SSO login process. When a user successfully logs in:

1. The access token is obtained from the SSO authentication
2. Employee details are automatically fetched using `getLoggedInUserDetails()`
3. The details are stored in the global state
4. Other components can access the employee details through the store

## Environment Variables

Make sure these environment variables are configured:

```env
NEXT_PUBLIC_SSO_EMPLOYEE_DETAIL=your_employee_details_api_url
NEXT_PUBLIC_EMPLOYEE_DETAILS_API_TAG=Employee Details API
NEXT_PUBLIC_ADMIN_EMPLOYEE_CODE=your_admin_employee_code
```

## Error Handling

The store provides comprehensive error handling:

- Network errors are caught and stored in the error state
- API response errors are properly handled
- Missing configuration errors are caught
- Invalid access token errors are handled

## Best Practices

1. **Always check loading state** before rendering employee details
2. **Handle errors gracefully** by displaying user-friendly error messages
3. **Use the EmployeeDetailsDisplay component** for consistent UI
4. **Initialize the store early** in your app lifecycle
5. **Clear the store** when user logs out

## Role-Based Access Control

The employee store includes built-in role management. Users are automatically assigned roles based on their employee code:

- **Admin**: Employee code matches `NEXT_PUBLIC_ADMIN_EMPLOYEE_CODE`
- **User**: All other employee codes (default)

### Using Role-Based Access

```javascript
import { useRoleAccess } from "@/hooks/useRoleAccess";

const MyComponent = () => {
  const { isAdmin, isUser, hasRole, userRole } = useRoleAccess();

  return (
    <div>
      <h2>Current Role: {userRole}</h2>

      {isAdmin() && <div>Admin-only content</div>}

      {isUser() && <div>User content</div>}

      {hasRole(["admin", "user"]) && <div>Content for both admin and user</div>}
    </div>
  );
};
```

### Using RoleGuard Component

```javascript
import { RoleGuard } from "@/hooks/useRoleAccess";

const MyComponent = () => {
  return (
    <div>
      <RoleGuard allowedRoles="admin">
        <div>Admin-only content</div>
      </RoleGuard>

      <RoleGuard allowedRoles={["admin", "user"]}>
        <div>Content for both roles</div>
      </RoleGuard>

      <RoleGuard allowedRoles="admin" fallback={<div>Access denied</div>}>
        <div>Admin content with fallback</div>
      </RoleGuard>
    </div>
  );
};
```

## Example: Complete Integration

```javascript
// In your main app component
import { useEmployeeStore } from "@/store/employeeStore";

const App = () => {
  const { initializeEmployeeDetails } = useEmployeeStore();

  useEffect(() => {
    // Initialize employee details when app loads
    initializeEmployeeDetails();
  }, []);

  return <div>{/* Your app content */}</div>;
};

// In any component that needs employee details
import { useEmployeeStore } from "@/store/employeeStore";

const UserProfile = () => {
  const { employeeDetails, userRole, loading, error } = useEmployeeStore();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  if (!employeeDetails) return <div>No employee details</div>;

  return (
    <div>
      <h2>Welcome, {employeeDetails.name}!</h2>
      <p>Employee Code: {employeeDetails.employee_code}</p>
      <p>Role: {userRole}</p>
    </div>
  );
};
```
