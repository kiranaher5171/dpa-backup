import { create } from 'zustand';
import { isTokenExpired, getCurrentSession, clearSession as clearSessionUtil } from '@/utils/tokenUtils';

export const useEmployeeStore = create((set, get) => ({
  employeeDetails: null,
  userRole: null, // 'admin' or 'user'
  error: null,
  loading: false,
  isAuthenticated: false,
  isInitialized: false,

  // Set employee details
  setEmployeeDetails: (details) => {
    console.log('🔐 EmployeeStore: Setting employee details:', details);
    set({
      employeeDetails: details,
      error: null,
      isAuthenticated: true
    });
    console.log('🔐 EmployeeStore: Employee details set successfully');
  },

  // Set user role
  setUserRole: (role) => {
    console.log('🔐 EmployeeStore: Setting user role:', role);
    set({ userRole: role });
  },

  // Check and set user role based on employee code from database
  checkAndSetUserRole: async (employeeCode) => {
    console.log('🔐 EmployeeStore: === Database Role Check Debug ===');
    console.log('🔐 EmployeeStore: Employee Code:', employeeCode);

    try {
      // Get the current session to access the token
      const session = getCurrentSession();
      if (!session || !session.accessToken) {
        throw new Error('No access token available');
      }

      // Call the API to check role from database
      const response = await fetch('/api/check-user-role', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.accessToken}`
        },
        body: JSON.stringify({ emp_code: employeeCode })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      
      if (result.success) {
        const role = result.role;
        set({ userRole: role });
        console.log(`🔐 EmployeeStore: User role set to: ${role} (from database)`);
        console.log(`🔐 EmployeeStore: Is Admin: ${result.is_admin}`);
        console.log(`🔐 EmployeeStore: Employee Name: ${result.emp_name}`);
        console.log('🔐 EmployeeStore: === End Database Role Check ===');
        return role;
      } else {
        throw new Error(result.error || 'Failed to check role');
      }
    } catch (error) {
      console.error('🔐 EmployeeStore: Error checking role from database:', error);
      
      // No fallback - database is required
      const role = 'user';
      set({ userRole: role });
      console.log(`🔐 EmployeeStore: Database error - User role set to: ${role}`);
      console.log('🔐 EmployeeStore: === End Database Role Check ===');
      return role;
    }
  },

  // Clear employee details
  clearEmployeeDetails: () => {
    console.log('🔐 EmployeeStore: Clearing employee details');
    set({
      employeeDetails: null,
      userRole: null,
      error: null,
      isAuthenticated: false
    });
    console.log('🔐 EmployeeStore: Employee details cleared');
  },

  // Set error state
  setError: (error) => {
    console.log('🔐 EmployeeStore: Setting error:', error);
    set({ error });
  },

  // Set loading state
  setLoading: (loading) => {
    console.log('🔐 EmployeeStore: Setting loading:', loading);
    set({ loading });
  },

  // Get current session data
  getCurrentSession: () => {
    return getCurrentSession();
  },

  // Clear session from localStorage
  clearSession: () => {
    clearSessionUtil();
    get().clearEmployeeDetails();
  },

  // Initialize employee details from localStorage session (for page refresh)
  initializeFromSession: async () => {
    const { getCurrentSession, getLoggedInUserDetails, setEmployeeDetails, checkAndSetUserRole, setLoading, setError } = get();

    if (typeof window === 'undefined') {
      set({ isInitialized: true });
      return { success: false, error: 'Not in browser' };
    }

    try {
      console.log('🔐 EmployeeStore: Initializing from session...');
      setLoading(true);
      setError(null);

      const session = getCurrentSession();
      if (!session || !session.accessToken) {
        console.log('🔐 EmployeeStore: No valid session found');
        set({ isAuthenticated: false, isInitialized: true, loading: false });
        return { success: false, error: 'No valid session' };
      }

      console.log('🔐 EmployeeStore: Found session, fetching employee details...');
      const result = await getLoggedInUserDetails(session.accessToken);

      if (result.success) {
        console.log('🔐 EmployeeStore: Successfully initialized from session');
        set({ isAuthenticated: true, isInitialized: true, loading: false });
        return { success: true, data: result.data, role: result.role };
      } else {
        console.log('🔐 EmployeeStore: Failed to initialize from session:', result.error);
        set({ isAuthenticated: false, isInitialized: true, loading: false });
        return result;
      }
    } catch (error) {
      console.error('🔐 EmployeeStore: Error initializing from session:', error);
      set({ isAuthenticated: false, isInitialized: true, loading: false, error: error.message });
      return { success: false, error: error.message };
    }
  },

  // Get logged in user details using access token
  getLoggedInUserDetails: async (accessToken) => {
    const { setEmployeeDetails, setError, setLoading } = get();

    setError(null);
    setLoading(true);

    try {
      const url = process.env.NEXT_PUBLIC_SSO_EMPLOYEE_DETAIL;
      const apiTag = process.env.NEXT_PUBLIC_EMPLOYEE_DETAILS_API_TAG || 'Employee Details API';

      console.log('🔐 EmployeeStore: Environment variables:', {
        hasUrl: !!url,
        url: url,
        apiTag: apiTag
      });

      if (!url) {
        throw new Error('Employee details API URL not configured');
      }

      if (!accessToken) {
        throw new Error('Access token is required');
      }

      // Check if token is expired
      if (isTokenExpired(accessToken)) {
        console.log('🔐 EmployeeStore: Token is expired, skipping API call');
        setLoading(false);
        return { success: false, error: 'Token expired', isTokenExpired: true };
      }

      console.log(`🔐 EmployeeStore: ${apiTag} URL:`, url);

      const headers = {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      };

      const response = await fetch(url, {
        method: 'GET',
        headers: headers
      });

      console.log(`🔐 EmployeeStore: ${apiTag} response status:`, response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`🔐 EmployeeStore: ${apiTag} failed:`, response.status, errorText);
        throw new Error(`${apiTag} failed: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      console.log(`🔐 EmployeeStore: ${apiTag} Response:`, data);

      // Set employee details
      setEmployeeDetails({ ...data, apiTag, url });

      // Check and set user role based on employee code (now async)
      const role = await get().checkAndSetUserRole(data.employee_code);

      setLoading(false);
      return { success: true, data, role };
    } catch (error) {
      console.error('🔐 EmployeeStore: Error fetching employee details:', error);
      setError(`Failed to fetch employee details: ${error.message}`);
      setLoading(false);

      // Check if it's a 401 error (token expired)
      if (error.message && error.message.includes('401')) {
        return { success: false, error: error.message, isTokenExpired: true };
      }

      return { success: false, error: error.message };
    }
  },

  // Logout function
  logout: async () => {
    console.log('🔐 EmployeeStore: Logging out...');
    
    try {
      // Clear session data
      get().clearSession();
      
      // Call server-side logout cleanup API
      console.log('🧹 Cleaning up database connections...');
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' }
        });
        console.log('✅ Server-side logout cleanup completed');
      } catch (cleanupError) {
        console.warn('⚠️ Database cleanup failed:', cleanupError);
      }
      
      set({ isAuthenticated: false, isInitialized: true, loading: false });
      console.log('🔐 EmployeeStore: Logout completed with connection cleanup');
    } catch (error) {
      console.error('❌ Error during logout cleanup:', error);
      // Still complete logout even if cleanup fails
      set({ isAuthenticated: false, isInitialized: true, loading: false });
    }
  },
}));
