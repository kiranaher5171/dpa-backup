"use client";
import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'
 import CodeIcon from '@mui/icons-material/Code';
import DesignServicesOutlinedIcon from '@mui/icons-material/DesignServicesOutlined';
import CampaignOutlinedIcon from '@mui/icons-material/CampaignOutlined';
import { TitleWithShape } from './TitleWithShape';


const cardData = [
  {
    icon: <CodeIcon className='icon-mui' />,
    number: "01",
    heading: 'Increased Efficiency',
    desc: 'Effortlessly generate professional HTML reports, MIS, newsletters, and email templates—all with one intuitive dashboard that reduces manual formatting and speeds up your workflow.'
  },
  {
    icon: <DesignServicesOutlinedIcon className='icon-mui' />,
    number: "02",
    heading: 'Enhanced Collaboration',
    desc: 'Work seamlessly with your team through real-time content sharing and editing, ensuring everyone stays aligned and projects move forward together.'
  },
  {
    icon: <CampaignOutlinedIcon className='icon-mui' />,
    number: "03",
    heading: 'Improved Accountability',
    desc: 'Keep track of every change with our built-in audit trails, so you can monitor progress, meet deadlines, and ensure accountability across your organization.'
  },
  {
    icon: <CodeIcon className='icon-mui' />,
    number: "04",
    heading: 'Data-Driven Decision Making',
    desc: 'Utilize detailed performance analytics and comprehensive reports to uncover insights, optimize processes, and make informed strategic decisions.'
  },
  {
    icon: <CodeIcon className='icon-mui' />,
    number: "05",
    heading: 'Centralized Management',
    desc: 'Store and organize all your reports, templates, and key documents in one secure, easily accessible platform—eliminating clutter and keeping your data safe.'
  },

];

const CardComponent = ({ icon, number, heading, desc }) => (
                  <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
    <Box className="service-card appear-on-scroll">
      <Box className="fx_sb">
        <Box className="shape-icon">
          {icon}
          <span className='dots'></span>
        </Box>
        <Typography variant='h1' className='service-card_number'>{number}</Typography>
      </Box>

      <Box pt={3}>
        <Typography variant='h4' className='fw6 text'>
          {heading}
        </Typography>
      </Box>
      <Box pt={2}>
        <Typography variant='h6' className='fw4 text-color'>
          {desc}
        </Typography>
      </Box> 
      <Box className="go-corner" href="#">
        <Box className="go-arrow" />
      </Box>
    </Box>
  </Grid>
);



const Benefits = () => {



  return (
    <>

      <Box id="our-services" className="section">
        <Container maxWidth="lg">
          <Grid container alignItems="center" justifyContent='center' spacing={4}>
            <Grid size={{ lg: 6, md: 7, sm: 10, xs: 12 }}>
              <Box>
                <Box className="fx_c">
                  <TitleWithShape title={"Benefits"} />
                </Box>
                <Box pt={2} className="center">
                  <Typography variant='h2' className='fw6 secondary'>
                    We Provide Exclusive <span className='primary fw7'>Service</span> for Your Business
                  </Typography>
                </Box>
              </Box>
            </Grid>
          </Grid>

          <Box pt={4} pb={4}>
            <Grid container alignItems="center" justifyContent='center' spacing={4}>
              {cardData.map((data, index) => (
                <CardComponent key={index} {...data} />
              ))}
            </Grid>
          </Box>

        </Container>
      </Box>

    </>
  );
};

export default Benefits;