"use client";
import React from 'react'; 
import { Box, Button, Container, Grid, IconButton, Stack, Tooltip, Typography } from '@mui/material'
import Link from 'next/link';
import { EastOutlined, PlayCircleFilledWhiteOutlined } from '@mui/icons-material';

const HeroSection = () => { 

    return (
        <>
            <Box id="hero" className="hero">
                <Container maxWidth="lg">

                    <Box mt={"64px"}>
                        <Grid container alignItems="center" justifyContent='center' spacing={2}>
                            <Grid size={{ xs: 12, sm: 12, md: 10, lg: 10 }}>
                                <Box mb={4}>
                                    <Box className="center">
                                        <Typography variant='h1' className='black fw6'>
                                            Empower Your Content Creation with DPA-MISBuilder
                                        </Typography>
                                    </Box>

                                    <Box pt={3} className="center">
                                        <Grid container alignItems="center" justifyContent='center' spacing={2}>
                                            <Grid size={{ xs: 12, sm: 10, md: 9, lg: 9 }}>
                                                <Typography variant='h5' className="text">
                                                    Effortlessly design and manage HTML reports, newsletters, and email templates with precision and ease.
                                                </Typography>
                                            </Grid>
                                        </Grid>
                                    </Box>

                                    <Box pt={4}>
                                        <Stack direction={"row"} justifyContent={"center"} spacing={4}>
                                            <Link href="/auth/signin">
                                                <Button variant='contained' className='sq-btn' endIcon={<EastOutlined />}>
                                                    Get Started
                                                </Button>
                                            </Link>
                                            <Tooltip arrow title="View Demo">
                                                <IconButton id="play-btn" className="css-button">
                                                    <PlayCircleFilledWhiteOutlined />
                                                </IconButton>
                                            </Tooltip>
                                        </Stack>
                                    </Box>
                                </Box>
                            </Grid>

                        </Grid>
                    </Box>
                </Container>
            </Box>


        </>
    );
};

export default HeroSection;