import { Avatar, Box, Container, Grid, List, ListItem, ListItemAvatar, ListItemText, Typography } from '@mui/material'
import React from 'react'
import Abt from "../../public/images/landingpage/about-us.png";
import Efficiency from '../../public/images/icons/efficiency.png';
import Quality from '../../public/images/icons/quality.png';
import Design from '../../public/images/icons/design-thinking.png';
import { TitleWithShape } from './TitleWithShape';
import Image from 'next/image';


const AboutusSection = () => {
  return (
    <>

      <Box id="about-us" className="section">
        <Container maxWidth="lg">
          <Grid container alignItems="center" justifyContent='space-between' spacing={4}>
            <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
              <Box className="relative no-select">
                <Box className="abt-over">
                  <Box>
                    <Typography variant='h4' gutterBottom>
                      100+
                    </Typography>
                    <Typography variant='h6'>
                      Reports Generated
                    </Typography>
                  </Box>
                </Box>
                <Image src={Abt} className='w100' style={{ height: 'auto' }} draggable={false} alt='about us' loading="lazy" />
              </Box>
            </Grid>
            <Grid size={{ lg: 8, md: 6, sm: 12, xs: 12 }}>
              <Box>
                <Box>
                  <TitleWithShape title={"Who We Are"} />
                </Box>

                <Box pt={2}>
                  <Typography variant='h5' className='fw4 text' gutterBottom>
                    At DPA-MISBuilder, we revolutionize digital content creation by transforming complex tasks into streamlined processes. Our platform empowers you to effortlessly produce high-quality HTML reports, newsletters, and email templates.
                  </Typography>
                </Box>

                <Box pt={2}>
                  <Typography variant='h2' className='fw6 secondary'>
                    Empowering Your <span className='primary fw7'>Creativity</span> and <span className='primary fw7'>Productivity</span>
                  </Typography>
                </Box>

                <Box pt={2}>
                  <Typography variant='h5' className='fw4 text' gutterBottom>
                    We equip you with intuitive tools to:
                  </Typography>
                </Box>
              </Box>



              <Box pt={0} pb={4}>
                <Grid container alignItems="center" justifyContent='space-between' spacing={1}>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <List>
                      <ListItem>
                        <ListItemAvatar>
                          <Avatar>
                            <Image src={Efficiency} className='w100' alt='Efficiency' loading="lazy" />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={<>
                            <span className='h5 fw6 text'>Enhance Efficiency:</span>
                          </>}
                          secondary={<>
                            <span className='h6 fw4 text-color'>
                              Quickly add and customize content elements.
                            </span>
                          </>} />
                      </ListItem>

                      <ListItem>
                        <ListItemAvatar>
                          <Avatar>
                            <Image src={Quality} className='w100' alt='Quality' loading="lazy" />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={<>
                            <span className='h5 fw6 text'>Ensure Quality:</span>
                          </>}
                          secondary={<>
                            <span className='h6 fw4 text-color'>
                              Maintain control over aesthetics and accuracy.
                            </span>
                          </>} />
                      </ListItem>

                      <ListItem>
                        <ListItemAvatar>
                          <Avatar>
                            <Image src={Design} className='w100' alt='Design Thinking' loading="lazy" />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={<>
                            <span className='h5 fw6 text'>Drive Engagement:</span>
                          </>}
                          secondary={<>
                            <span className='h6 fw4 text-color'>
                              Create visually compelling content that resonates.
                            </span>
                          </>} />
                      </ListItem>
                    </List>
                  </Grid> 
                </Grid>
              </Box>
 
            </Grid>
          </Grid>
        </Container>
      </Box>

    </>
  );
};
export default AboutusSection;