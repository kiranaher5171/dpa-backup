import { Avatar, Box, Container, Grid, List, ListItem, ListItemAvatar, ListItemText, Typography } from '@mui/material'
import React from 'react'
import IMG from "../../public/images/landingpage/why-us.png";
import { TitleWithShape } from './TitleWithShape';
import Image from 'next/image';
import Check from '../../public/images/icons/check-mark.png';


const WhyUsSection = () => {
  return (
    <>

      <Box id="why-choose-us" className="section">
        <Container maxWidth="lg">
          <Grid container alignItems="center" justifyContent='space-between' spacing={4}>
            <Grid size={{ lg: 7, md: 6, sm: 12, xs: 12 }}>

              <Box>
                <TitleWithShape title={"Key Features"} />
              </Box>
              <Box pt={2}>
                <Typography variant='h2' className='fw6 secondary'>
                  Designed with <span className='primary fw7'>comprehensive features</span> to meet all your requirements
                </Typography>
              </Box>

              <Box pt={2} pb={4}>
                <Grid container alignItems="center" justifyContent='space-between' spacing={1}>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <List>
                      <ListItem>
                        <ListItemAvatar>
                          <Avatar>
                            <Image src={Check} className='w100' alt='Pre-Built HTML Components' loading="lazy" />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={<span className='h5 fw6 text'>Pre-Built HTML Components</span>}
                          secondary={<span className='h6 fw4 text-color'>Access a rich library of ready-made elements to effortlessly build professional templates.</span>}
                        />
                      </ListItem>

                      <ListItem>
                        <ListItemAvatar>
                          <Avatar>
                            <Image src={Check} className='w100' alt='Real-Time Preview & Editing' loading="lazy" />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={<span className='h5 fw6 text'>Real-Time Preview & Editing:</span>}
                          secondary={<span className='h6 fw4 text-color'> See your changes instantly and fine-tune your content with ease.</span>}
                        />
                      </ListItem>


                      <ListItem>
                        <ListItemAvatar>
                          <Avatar>
                            <Image src={Check} className='w100' alt='Automated Content Insertion' loading="lazy" />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={<span className='h5 fw6 text'>Automated Content Insertion:</span>}
                          secondary={<span className='h6 fw4 text-color'>Simplify repetitive tasks by auto-filling dynamic data for accurate and consistent reports.</span>}
                        />
                      </ListItem>

                      <ListItem>
                        <ListItemAvatar>
                          <Avatar>
                            <Image src={Check} className='w100' alt='Secure & Centralized Management' loading="lazy" />
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={<span className='h5 fw6 text'>Secure & Centralized Management:</span>}
                          secondary={<span className='h6 fw4 text-color'>Keep all your templates and reports in one safe, accessible place.</span>}
                        />
                      </ListItem>


                    </List>
                  </Grid>
                </Grid>
              </Box>
            </Grid>


            <Grid size={{ lg: 5, md: 6, sm: 12, xs: 12 }}>
              <Box className="relative no-select">
                <Box className="abt-over">
                  <Box>
                    <Typography variant='h4' gutterBottom>
                      25+
                    </Typography>
                    <Typography variant='h6'>
                      Active Clients
                    </Typography>
                  </Box>
                </Box>
                <Image src={IMG} className='w100' style={{ height: 'auto' }} draggable={false} alt='about us' loading="lazy" />
              </Box>
            </Grid>


          </Grid>
        </Container>
      </Box>

    </>
  );
};
export default WhyUsSection;
