import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react';
import { TitleWithShape } from './TitleWithShape';
import Image from 'next/image';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import HTML from "../../public/images/icons/html-template.png";
import Content from "../../public/images/icons/content.png";
import Generate from "../../public/images/icons/generate-share.png";

 
const HowItWorks = () => {
  return (
    <>

      <Box id="working-process" className="section">
        <Container maxWidth="lg"> 
          <Box pb={4}>
            <Grid container alignItems="center" justifyContent='center' spacing={4}>
              <Grid size={{ lg: 5, md: 6, sm: 12, xs: 12 }}>
                <Box data-aos="fade-up" data-aos-duration="800">
                  <Box className="fx_c relative">
                    <Typography variant='h1' className='shadow-title'> PROCESS</Typography>
                    <TitleWithShape title={"WORK PROCESS"} />
                  </Box>
                  <Box pt={2} className="fx_c al_center">
                    <Typography variant='h2' className='fw6 secondary'>
                      Let's See How It <span className='primary fw7'>Works!</span>
                    </Typography>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box> 

          <Box mt={6} mb={6} className="relative"> 
            <Grid container alignItems="center" justifyContent='space-between' spacing={8}>
              <Grid size={{ lg: 4, md: 4, sm: 4, xs: 12 }}>
                <Box className="work-box" data-aos="fade-up" data-aos-duration="1200">
                  <Box className='process-number pulse'>
                    <span>01</span>
                  </Box>
                  <Box className="al_center no-select" pb={2}>
                    <Image src={HTML} className='process-img' alt='HTML' draggable="false" loading="lazy" />
                  </Box>
                  <Box className="al_center">
                    <Typography variant='h5' className='fw6 primary'>Build Your Template</Typography>
                  </Box>
                  <Box className="al_center" pt={2}>
                    <Typography variant='h6' className='fw4 text'>
                      Start by assembling your document using our pre-designed HTML blocks—choose from headings, text sections, images, and more to craft the perfect layout.
                    </Typography>
                  </Box>
                </Box>
              </Grid>


              <Grid size={{ lg: 4, md: 4, sm: 4, xs: 12 }}>
                <Box className="work-box" data-aos="fade-up" data-aos-duration="1800">
                  <Box className='process-number pulse'>
                    <span>02</span>
                  </Box>
                  <Box className="al_center no-select" pb={2}>
                    <Image src={Content} className='process-img' alt='Content' draggable="false" loading="lazy" />
                  </Box>
                  <Box className="al_center">
                    <Typography variant='h5' className='fw6 primary'>Customize Your Content</Typography>
                  </Box>
                  <Box className="al_center" pt={2}>
                    <Typography variant='h6' className='fw4 text'>
                      Personalize every element with your unique data. Effortlessly add details like report metrics, newsletter content, or MIS data with our intuitive editing tools.
                    </Typography>
                  </Box>
                </Box>
              </Grid>

              <Grid size={{ lg: 4, md: 4, sm: 4, xs: 12 }}>
                <Box className="work-box" data-aos="fade-up" data-aos-duration="400">
                  <Box className='process-number pulse'>
                    <span>03</span>
                  </Box>
                  <Box className="al_center no-select" pb={2}>
                    <Image src={Generate} className='process-img' alt='Generate' draggable="false" loading="lazy" />
                  </Box>
                  <Box className="al_center">
                    <Typography variant='h5' className='fw6 primary'>Generate & Share</Typography>
                  </Box>
                  <Box className="al_center" pt={2}>
                    <Typography variant='h6' className='fw4 text'>
                      Output your finished template as an HTML report, email template, or MIS document. Instantly share your polished content with your team or clients.
                    </Typography>
                  </Box>
                </Box>
              </Grid>

            </Grid>
          </Box>


        </Container>
      </Box>

    </>
  );
};

export default HowItWorks;