import { Box, Container, Grid, IconButton, Stack, Typography } from '@mui/material'
import React from 'react'
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import InstagramIcon from "@mui/icons-material/Instagram";
import YouTubeIcon from "@mui/icons-material/YouTube";
import FacebookIcon from '@mui/icons-material/Facebook';

import Link from 'next/link';
import LOGO from "../../public/logos/dpa-white.svg";
import Image from 'next/image';

const Footer = () => {

  const currentYear = new Date().getFullYear();

  return (
    <>
      <Box id="footer" className="section">
        <Container maxWidth="lg">
          <Box>
            <Grid container alignItems="center" justifyContent='center' spacing={4}>
              <Grid size={{ lg: 8, md: 12, sm: 8, xs: 10 }} data-aos="fade-up" data-aos-duration="1500">
                <Box className="center">
                  <Image src={LOGO} className='footer-logo' priority alt='Footer Logo' />
                </Box>
                <Box pt={3}>
                  <Typography variant='h6' className='white fw4 center' gutterBottom>
                    Empower Your Content Workflow with DPA-MISBuilder
                  </Typography>

                  <Typography variant='h6' className='white fw4 center'>
                    Professionally redefine your document creation and content management process. Experience efficient, automated, and collaborative creation of HTML reports, newsletters, and email templates—all in one powerful platform.
                  </Typography>

                  <Typography variant='h6' className='white fw4 center'>
                    Your one-stop solution to streamline, track, and transform complex tasks into simple, impactful digital content.
                  </Typography>
                </Box>
              </Grid>
            </Grid>

            {/* <Grid container alignItems="flex-start" justifyContent='space-between' spacing={4}>

              <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }} data-aos="fade-up" data-aos-duration="1500">

                <Box className="social-icons" mt={3} mb={0}>
                  <Stack direction={"row"} justifyContent={"center"} spacing={2}>

                    <a href="#" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn Profile">
                      <IconButton size="medium" className="linkedin-icon" aria-label="LinkedIn">
                        <LinkedInIcon fontSize="medium" />
                      </IconButton>
                    </a>

                    <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Instagram Profile">
                      <IconButton size="medium" className="instagram-icon" aria-label="Instagram">
                        <InstagramIcon fontSize="medium" />
                      </IconButton>
                    </a>

                    <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Youtube Profile">
                      <IconButton size="medium" className="youtube-icon" aria-label="Youtube">
                        <YouTubeIcon fontSize="medium" />
                      </IconButton>
                    </a>

                    <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Facebook Profile">
                      <IconButton size="medium" className="facebook-icon" aria-label="Facebook">
                        <FacebookIcon fontSize="medium" />
                      </IconButton>
                    </a>

                  </Stack>
                </Box>


              </Grid>


            </Grid> */}
          </Box>
        </Container>
      </Box>


      <Box className="footer-copyright-strip">
        <Container maxWidth="lg">
          <Grid container alignItems="center" justifyContent='center' spacing={1}>
            <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} className='relative'>
              <Box className="left mob_c">
                <Typography variant='h6' className='white fw4'>Copyright &copy;{currentYear} <Link href="/"> <strong>Decimal Point Analytics</strong> Pvt Ltd. </Link></Typography>
              </Box>
            </Grid>

            {/* <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} className='relative'>
              <Box className="right mob_c">
                <Typography variant='h6' className='white fw4'>Designed & Developed by <a href="https://api.whatsapp.com/send?phone=+918381007317&text=Hi,%20Nikhil,%0A%0AI%20just%20visited%DPA%MISBuilder%2026%20I%20want%20to%20learn%20more%20about%20your%20Services" target="_blank">
                  <strong>@Nikhil</strong>
                </a>.</Typography>
              </Box>
            </Grid> */}
          </Grid>
        </Container>
      </Box>
    </>
  );
};

export default Footer;