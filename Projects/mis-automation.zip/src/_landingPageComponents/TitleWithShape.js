import React from 'react'
import { Typography, Box } from '@mui/material'
import Shape from "../../public/images/icons/shape.png";
import Image from 'next/image';


export const TitleWithShape = ({ title }) => {
    return (
        <>
            <Box className="fx_fs gap1">
                <Image src={Shape} draggable={false} alt={title} height={20} width={20} loading="lazy" />
                <Typography variant='h5' className='secondary fw7'> {title} </Typography>
            </Box>
        </>
    )
}
