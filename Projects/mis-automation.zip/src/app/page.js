import React from 'react'
import { CircularProgress } from '@mui/material'
import dynamic from 'next/dynamic';
import KeyFeatures from '../_landingPageComponents/KeyFeatures';
import Benefits from '../_landingPageComponents/Benefits';
import HowItWorks from '../_landingPageComponents/HowItWorks';
import BasicLayout from './layouts/BasicLayout';

const HeroSection = dynamic(() => import('../_landingPageComponents/HeroSection'), {
  loading: () => <CircularProgress />
});

const AboutusSection = dynamic(() => import('../_landingPageComponents/AboutusSection'), {
  loading: () => <CircularProgress />
});

const Footer = dynamic(() => import('../_landingPageComponents/Footer'), {
  loading: () => <CircularProgress />
});

const page = () => {
  return (
    <>
      <BasicLayout>
        <HeroSection />
        <AboutusSection />
        <Benefits />
        <HowItWorks />
        <KeyFeatures />
        <Footer />
      </BasicLayout>
    </>
  )
}

export default page