import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';
import { verifyAnyToken } from '@/lib/jwt';
import oracledb from 'oracledb';

/**
 * Infographics API - Handles upload and retrieval of three types of infographics:
 * 
 * 1. CHARTS (from ChartBuilder.js):
 *    - chartType: 'bar', 'column', 'stack', 'line', 'combo', 'pie', 'doughnut', 'polar', 'radar'
 *    - originalData: { dataPoints, dataPoints2, type, colors, selectedColors, chartName, legendPosition, showLegends }
 * 
 * 2. TABLES (from TableBuilder.js):
 *    - tableName: string (e.g., 'Table')
 *    - originalData: { headers, rows, colors, headerBgColor, showBorders, showStripes, tableSize, headerTextColor, cellTextColor, columnWidths }
 * 
 * 3. IMAGES (from ImageUploader.js):
 *    - imageType: 'uploaded'
 *    - originalData: null (no regeneration data needed)
 * 
 * All infographics are stored in CLIENT_MIS_DOCUMENTS.GENERATED_INFOGRAPHICS as a JSON array
 */

// OCI PAR URL for infographics uploads (used only for uploading)
const OCI_INFOGRAPHICS_UPLOAD_PATH = process.env.OCI_INFOGRAPHICS_UPLOAD_PATH || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/p/PLACEHOLDER/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/';

// OCI permanent URL for infographics access (without PAR, for storing and displaying)
const OCI_INFOGRAPHICS_PUBLIC_PATH = process.env.OCI_INFOGRAPHICS_PUBLIC_PATH || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/';

// Helper function to normalize filename (lowercase, spaces to dashes)
function normalizeFilename(filename) {
  if (!filename) return null;
  return filename
    .toLowerCase()
    .replace(/\s+/g, '-') // Replace spaces with dashes
    .replace(/[^a-z0-9.-]/g, '') // Remove special characters except dots and dashes
    .replace(/--+/g, '-') // Replace multiple dashes with single dash
    .replace(/^-+|-+$/g, ''); // Remove leading/trailing dashes
}

// Helper function to generate OCI file URL (permanent URL without PAR)
function generateOciFileUrl(filename, documentName) {
  if (!filename) return null;
  const normalizedDocName = documentName
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');
  // Always use the permanent URL without PAR for storage and display
  return `${OCI_INFOGRAPHICS_PUBLIC_PATH}uploads/${normalizedDocName}/${filename}`;
}

// Helper function to generate OCI upload URL (with PAR for uploading only)
function generateOciUploadUrl(filename, documentName) {
  if (!filename) return null;
  const normalizedDocName = documentName
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');
  // Use PAR URL only for the upload operation
  return `${OCI_INFOGRAPHICS_UPLOAD_PATH}uploads/${normalizedDocName}/${filename}`;
}

// Helper function to normalize existing infographics data for backward compatibility
function normalizeInfographicData(infographic) {
  if (!infographic) return null;
  
  // Add missing fields for backward compatibility
  const normalized = { ...infographic };
  
  // Determine infographic type if not present
  if (!normalized.infographicType) {
    if (normalized.chartType) {
      normalized.infographicType = 'chart';
      normalized.contentType = normalized.chartType;
    } else if (normalized.tableName) {
      normalized.infographicType = 'table';
      normalized.contentType = normalized.tableName;
    } else if (normalized.imageType) {
      normalized.infographicType = 'image';
      normalized.contentType = normalized.imageType;
    } else {
      normalized.infographicType = 'image';
      normalized.contentType = 'uploaded';
    }
  }
  
  // Convert old PAR URLs to permanent URLs
  if (normalized.url && normalized.url.includes('/p/')) {
    // Extract the path after the bucket name
    const pathMatch = normalized.url.match(/\/o\/(.*)/);
    if (pathMatch) {
      // Reconstruct URL without PAR
      normalized.url = `${OCI_INFOGRAPHICS_PUBLIC_PATH}${pathMatch[1]}`;
      console.log('🔄 Converted PAR URL to permanent URL:', normalized.url);
    }
  }
  
  return normalized;
}

// Helper function to validate file upload
function validateFileUpload(file, documentName) {
  if (!file) {
    return { isValid: false, error: 'No file provided' };
  }

  if (!documentName) {
    return { isValid: false, error: 'Document name is required' };
  }

  // Validate file type (only images)
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
  if (!allowedTypes.includes(file.type)) {
    return { isValid: false, error: 'Only image files (JPEG, PNG, GIF, WebP) are allowed' };
  }

  // Validate file size (1MB limit)
  const maxFileSize = 1 * 1024 * 1024; // 1MB in bytes
  if (file.size > maxFileSize) {
    return { 
      isValid: false, 
      error: `File size exceeds the 1MB limit. Current size: ${(file.size / 1024 / 1024).toFixed(2)}MB` 
    };
  }

  return { isValid: true };
}

// Helper function to determine infographic type
function determineInfographicType(chartType, tableName, imageType) {
  if (chartType) {
    return { infographicType: 'chart', contentType: chartType };
  } else if (tableName) {
    return { infographicType: 'table', contentType: tableName };
  } else if (imageType) {
    return { infographicType: 'image', contentType: imageType };
  } else {
    return { infographicType: 'image', contentType: 'uploaded' };
  }
}

// Helper function to create infographic metadata
function createInfographicMetadata(file, filename, documentName, infographicType, contentType, chartType, tableName, imageType, originalData) {
  const normalizedDocumentName = documentName
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');

  return {
    filename: filename,
    url: generateOciFileUrl(filename, documentName),
    documentName: normalizedDocumentName,
    objectPath: `uploads/${normalizedDocumentName}/${filename}`,
    fileSize: file.size,
    fileType: file.type,
    uploadedAt: new Date().toISOString(),
    infographicType: infographicType,
    chartType: chartType || null,
    tableName: tableName || null,
    imageType: imageType || null,
    contentType: contentType,
    originalData: originalData ? JSON.parse(originalData) : null
  };
}

// Helper function to upload file to OCI
async function uploadFileToOCI(file, uploadUrl) {
  const uploadResponse = await fetch(uploadUrl, {
    method: 'PUT',
    body: file,
    headers: {
      'Content-Type': file.type,
    }
  });

  if (!uploadResponse.ok) {
    throw new Error(`OCI upload failed: ${uploadResponse.status} - ${uploadResponse.statusText}`);
  }

  return uploadResponse;
}

// Helper function to read CLOB content
async function readCLOBContent(clobObject) {
  const chunks = [];
  return new Promise((resolve, reject) => {
    clobObject.on('data', (chunk) => chunks.push(chunk));
    clobObject.on('end', () => {
      const content = Buffer.concat(chunks).toString('utf8');
      resolve(content);
    });
    clobObject.on('error', reject);
  });
}

// Helper function to get existing infographics
async function getExistingInfographics(documentName) {
  const getQuery = `
    SELECT GENERATED_INFOGRAPHICS 
    FROM CLIENT_MIS_DOCUMENTS 
    WHERE MIS_DOCUMENT_NAME = :1
  `;
  
  const { getConnection } = await import('@/lib/db');
  let connection;
  
  try {
    connection = await getConnection();
    
    const existingResult = await connection.execute(getQuery, [documentName], {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      autoCommit: true
    });
    
    if (!existingResult || !existingResult.rows || existingResult.rows.length === 0) {
      return [];
    }

    const existingData = existingResult.rows[0].GENERATED_INFOGRAPHICS;
    if (!existingData) {
      return [];
    }

    let dataToParse = existingData;
    if (typeof existingData === 'object' && existingData._type) {
      dataToParse = await readCLOBContent(existingData);
    }
    
    const parsedInfographics = JSON.parse(dataToParse);
    return parsedInfographics.map(normalizeInfographicData).filter(Boolean);
    
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (closeError) {
        console.error('Error closing connection:', closeError);
      }
    }
  }
}

// Helper function to save infographics to database
async function saveInfographicsToDatabase(documentName, infographics) {
  const updateQuery = `
    UPDATE CLIENT_MIS_DOCUMENTS 
    SET GENERATED_INFOGRAPHICS = :1 
    WHERE MIS_DOCUMENT_NAME = :2
  `;
  
  const jsonData = JSON.stringify(infographics);
  
  const { getConnection } = await import('@/lib/db');
  let connection;
  
  try {
    connection = await getConnection();
    
    await connection.execute(updateQuery, [jsonData, documentName], {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      autoCommit: true
    });
    
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (closeError) {
        console.error('Error closing connection:', closeError);
      }
    }
  }
}

// Helper function to execute query and handle CLOB data properly
async function executeQueryWithCLOB(query, params = []) {
  const { getConnection } = await import('@/lib/db');
  let connection;
  
  try {
    connection = await getConnection();
    
    const result = await connection.execute(query, params, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      autoCommit: true
    });
    
    // If we have CLOB data, read it before closing the connection
    if (result && result.rows && result.rows.length > 0) {
      for (let row of result.rows) {
        for (let key in row) {
          const value = row[key];
          if (value && typeof value === 'object' && value._type) {
            // This is a CLOB object, read its content
            console.log('📊 Reading CLOB content for field:', key);
            try {
              row[key] = await readCLOBContent(value);
            } catch (error) {
              console.error('❌ Error processing CLOB:', error);
              row[key] = null; // Set to null if reading fails
            }
          }
        }
      }
    }
    
    return result;
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('Connection closed after CLOB processing');
      } catch (closeError) {
        console.error('Error closing connection:', closeError);
      }
    }
  }
}

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  return { isValid: true, authResult };
}

// Helper function to validate document name
function validateDocumentName(documentName) {
  if (!documentName) {
    return { isValid: false, error: 'Document name is required' };
  }

  if (typeof documentName !== 'string' || documentName.length > 255) {
    return { isValid: false, error: 'Invalid document name format or length' };
  }

  const sanitizedDocumentName = documentName.trim().replace(/[^a-zA-Z0-9\s\-_\.]/g, '');
  if (sanitizedDocumentName !== documentName) {
    return { isValid: false, error: 'Document name contains invalid characters' };
  }

  return { isValid: true, sanitizedDocumentName };
}

// Helper function to categorize infographics
function categorizeInfographics(infographics) {
  const charts = infographics.filter(inf => inf.infographicType === 'chart' || inf.chartType);
  const tables = infographics.filter(inf => inf.infographicType === 'table' || inf.tableName);
  const images = infographics.filter(inf => inf.infographicType === 'image' || inf.imageType);
  
  return { charts, tables, images };
}

export async function POST(request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file');
    const documentName = formData.get('documentName');
    const chartType = formData.get('chartType');
    const tableName = formData.get('tableName');
    const imageType = formData.get('imageType');
    const originalData = formData.get('originalData');
    
    // Validate file upload
    const fileValidation = validateFileUpload(file, documentName);
    if (!fileValidation.isValid) {
      return NextResponse.json({ error: fileValidation.error }, { status: 400 });
    }

    console.log('📁 Uploading infographic for document:', documentName);
    console.log('📁 File details:', { name: file.name, size: file.size, type: file.type });
    
    // Determine infographic type
    const { infographicType, contentType } = determineInfographicType(chartType, tableName, imageType);
    console.log('📊 Infographic type detected:', { infographicType, contentType });

    // Generate filename and prepare upload
    const timestamp = Date.now();
    const fileExtension = file.name.split('.').pop().toLowerCase();
    const filename = `infographic-${timestamp}.${fileExtension}`;
    const normalizedDocumentName = documentName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    
    // Use PAR URL for upload
    const uploadUrl = generateOciUploadUrl(filename, documentName);
    
    // Generate permanent URL for storage (without PAR)
    const permanentUrl = generateOciFileUrl(filename, documentName);

    console.log('📁 Uploading to OCI (PAR URL):', uploadUrl);
    console.log('📁 Will store permanent URL:', permanentUrl);

    // Upload file to OCI
    await uploadFileToOCI(file, uploadUrl);
    console.log(`✅ File uploaded to OCI: ${filename}`);

    // Create infographic metadata
    const infographicData = createInfographicMetadata(
      file, filename, documentName, infographicType, contentType,
      chartType, tableName, imageType, originalData
    );

    // Get existing infographics and add new one
    let existingInfographics = [];
    try {
      existingInfographics = await getExistingInfographics(documentName);
      existingInfographics.push(infographicData);
      await saveInfographicsToDatabase(documentName, existingInfographics);
      console.log('✅ Infographic metadata saved to database');
    } catch (dbError) {
      console.error('❌ Database error:', dbError);
      console.log('⚠️ Upload succeeded but database save failed');
      existingInfographics = [infographicData];
    }
    
    console.log('📊 Final response - total infographics:', existingInfographics.length);
    
    return NextResponse.json({
      success: true,
      infographic: infographicData,
      totalInfographics: existingInfographics.length,
      allInfographics: existingInfographics
    });

  } catch (error) {
    console.error('❌ Error uploading infographic:', error);
    return NextResponse.json({ 
      error: `Upload failed: ${error.message}` 
    }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const documentName = searchParams.get('documentName');

    // Validate document name
    const documentNameValidation = validateDocumentName(documentName);
    if (!documentNameValidation.isValid) {
      return NextResponse.json({ error: documentNameValidation.error }, { status: 400 });
    }

    console.log('📁 Fetching infographics for document:', documentNameValidation.sanitizedDocumentName);

    // Get infographics from database
    const query = `
      SELECT GENERATED_INFOGRAPHICS 
      FROM CLIENT_MIS_DOCUMENTS 
      WHERE MIS_DOCUMENT_NAME = :1
    `;
    
    const result = await executeQueryWithCLOB(query, [documentNameValidation.sanitizedDocumentName]);
    let infographics = [];
    
    if (result && result.rows && result.rows.length > 0) {
      const infographicsData = result.rows[0].GENERATED_INFOGRAPHICS;
      
      if (infographicsData) {
        try {
          const parsedInfographics = JSON.parse(infographicsData);
          infographics = parsedInfographics.map(normalizeInfographicData).filter(Boolean);
        } catch (e) {
          console.error('❌ Error parsing infographics JSON:', e);
          infographics = [];
        }
      }
    }

    // Categorize infographics
    const { charts, tables, images } = categorizeInfographics(infographics);
    
    console.log(`📁 Found ${infographics.length} infographics for document: ${documentNameValidation.sanitizedDocumentName}`);
    console.log(`📊 Breakdown: ${charts.length} charts, ${tables.length} tables, ${images.length} images`);

    return NextResponse.json({
      success: true,
      documentName: documentNameValidation.sanitizedDocumentName,
      infographics: infographics,
      count: infographics.length,
      breakdown: {
        charts: charts.length,
        tables: tables.length,
        images: images.length
      }
    });

  } catch (error) {
    console.error('❌ Error fetching infographics:', error);
    return NextResponse.json({ 
      error: `Failed to fetch infographics: ${error.message}` 
    }, { status: 500 });
  }
}

export async function DELETE(request) {
  try {
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const documentName = searchParams.get('documentName');
    const filename = searchParams.get('filename');

    // Validate parameters
    const documentNameValidation = validateDocumentName(documentName);
    if (!documentNameValidation.isValid) {
      return NextResponse.json({ error: documentNameValidation.error }, { status: 400 });
    }

    if (!filename) {
      return NextResponse.json({ error: 'Filename is required' }, { status: 400 });
    }

    console.log('🗑️ Deleting infographic:', filename, 'from document:', documentNameValidation.sanitizedDocumentName);

    // Get existing infographics
    const existingInfographics = await getExistingInfographics(documentNameValidation.sanitizedDocumentName);
    
    // Find and remove the infographic
    const updatedInfographics = existingInfographics.filter(inf => inf.filename !== filename);
    
    if (updatedInfographics.length === existingInfographics.length) {
      return NextResponse.json({ error: 'Infographic not found' }, { status: 404 });
    }

    // Save updated infographics to database
    await saveInfographicsToDatabase(documentNameValidation.sanitizedDocumentName, updatedInfographics);
    
    console.log(`✅ Infographic deleted: ${filename}`);
    console.log(`📊 Remaining infographics: ${updatedInfographics.length}`);

    return NextResponse.json({
      success: true,
      message: 'Infographic deleted successfully',
      deletedFilename: filename,
      remainingCount: updatedInfographics.length
    });

  } catch (error) {
    console.error('❌ Error deleting infographic:', error);
    return NextResponse.json({ 
      error: `Failed to delete infographic: ${error.message}` 
    }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const body = await request.json();
    const { documentName, filename, isUsed } = body;

    // Validate parameters
    const documentNameValidation = validateDocumentName(documentName);
    if (!documentNameValidation.isValid) {
      return NextResponse.json({ error: documentNameValidation.error }, { status: 400 });
    }

    if (!filename) {
      return NextResponse.json({ error: 'Filename is required' }, { status: 400 });
    }

    if (typeof isUsed !== 'boolean') {
      return NextResponse.json({ error: 'isUsed must be a boolean value' }, { status: 400 });
    }

    console.log('🏷️ Updating infographic usage status:', filename, 'isUsed:', isUsed);

    // Get existing infographics
    const existingInfographics = await getExistingInfographics(documentNameValidation.sanitizedDocumentName);
    
    // Find and update the infographic
    const infographicIndex = existingInfographics.findIndex(inf => inf.filename === filename);
    
    if (infographicIndex === -1) {
      return NextResponse.json({ error: 'Infographic not found' }, { status: 404 });
    }

    // Update the usage status
    existingInfographics[infographicIndex].isUsed = isUsed;
    existingInfographics[infographicIndex].usageUpdatedAt = new Date().toISOString();

    // Save updated infographics to database
    await saveInfographicsToDatabase(documentNameValidation.sanitizedDocumentName, existingInfographics);
    
    console.log(`✅ Infographic usage status updated: ${filename} - ${isUsed ? 'USED' : 'UNUSED'}`);

    return NextResponse.json({
      success: true,
      message: 'Infographic usage status updated successfully',
      filename: filename,
      isUsed: isUsed
    });

  } catch (error) {
    console.error('❌ Error updating infographic usage status:', error);
    return NextResponse.json({ 
      error: `Failed to update infographic usage status: ${error.message}` 
    }, { status: 500 });
  }
}