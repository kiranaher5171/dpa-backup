import { NextResponse } from 'next/server';

export async function POST(request) {
    try {
        const { htmlContent, documentId } = await request.json();

        if (!htmlContent) {
            return NextResponse.json(
                { error: 'HTML content is required' },
                { status: 400 }
            );
        }

        console.log('🔄 Starting alternative PDF generation for document:', documentId);

        // Create a simple HTML to PDF conversion using basic HTML structure
        const fullHTML = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>MIS Document - ${documentId || 'Generated'}</title>
    <style>
        body {
            font-family: 'Calibri', 'Arial', sans-serif !important;
            margin: 0;
            padding: 20px;
            background-color: #ffffff;
        }
        * {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        table {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        td {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        p {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    ${htmlContent}
</body>
</html>`;

        // For now, return the HTML content as a downloadable file
        // In a production environment, you would use a proper HTML-to-PDF library
        const htmlBuffer = Buffer.from(fullHTML, 'utf-8');

        console.log('✅ Alternative PDF generation completed (HTML format)');

        // Return HTML as response (can be saved and opened in browser for printing)
        return new NextResponse(htmlBuffer, {
            status: 200,
            headers: {
                'Content-Type': 'text/html',
                'Content-Disposition': `attachment; filename="MIS-Document-${documentId || 'generated'}.html"`,
                'Content-Length': htmlBuffer.length.toString(),
            },
        });

    } catch (error) {
        console.error('❌ Error in alternative PDF generation:', error);

        return NextResponse.json(
            {
                error: 'Failed to generate document',
                details: error.message,
                code: 'ALTERNATIVE_GENERATION_ERROR'
            },
            { status: 500 }
        );
    }
}
