import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';

// POST endpoint to set up employee 501 as admin for testing
export async function POST(request) {
    try {
        console.log('🔧 Setting up employee 501 as admin...');
        
        // Check if employee 501 exists
        const checkQuery = `SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN FROM MIS_ACCESS_CONTROL WHERE EMP_CODE = '501'`;
        const checkResult = await executeQuery(checkQuery);
        
        if (checkResult.rows && checkResult.rows.length > 0) {
            // Employee exists, update to admin
            const updateQuery = `UPDATE MIS_ACCESS_CONTROL SET IS_ADMIN = 1 WHERE EMP_CODE = '501'`;
            await executeQuery(updateQuery);
            
            console.log('✅ Employee 501 updated to admin');
            return NextResponse.json({
                success: true,
                message: 'Employee 501 updated to admin',
                action: 'updated_to_admin'
            });
        } else {
            // Employee doesn't exist, insert as admin
            const insertQuery = `
                INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN) 
                VALUES ('emp_501_admin', '501', 'Amol Patil', 1)
            `;
            await executeQuery(insertQuery);
            
            console.log('✅ Employee 501 added as admin');
            return NextResponse.json({
                success: true,
                message: 'Employee 501 added as admin',
                action: 'added_as_admin'
            });
        }
        
    } catch (error) {
        console.error('❌ Error setting up admin:', error);
        return NextResponse.json({
            success: false,
            error: error.message
        }, { status: 500 });
    }
}
