import { NextResponse } from 'next/server';
import puppeteer from 'puppeteer';

export async function POST(request) {
    let browser = null;
    let page = null;
    
    try {
        const { htmlContent, documentId } = await request.json();

        if (!htmlContent) {
            return NextResponse.json(
                { error: 'HTML content is required' },
                { status: 400 }
            );
        }

        console.log('🔄 Starting PDF generation for document:', documentId);

        // Launch Puppeteer browser with Linux-compatible configuration
        browser = await puppeteer.launch({
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu',
                '--disable-extensions',
                '--disable-plugins',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-features=TranslateUI',
                '--disable-ipc-flooding-protection',
                '--disable-web-security',
                '--disable-features=VizDisplayCompositor',
                '--memory-pressure-off',
                '--max_old_space_size=4096',
                '--disable-background-networking',
                '--disable-default-apps',
                '--disable-sync'
            ],
            timeout: 120000, // Increased to 2 minutes
            handleSIGINT: false,
            handleSIGTERM: false,
            handleSIGHUP: false,
            protocolTimeout: 120000 // Add protocol timeout
        });

        page = await browser.newPage();

        // Set viewport for consistent rendering
        await page.setViewport({
            width: 1200,
            height: 800,
            deviceScaleFactor: 1,
        });

        // Add connection monitoring
        page.on('disconnected', () => {
            console.log('⚠️ Page disconnected unexpectedly');
        });

        browser.on('disconnected', () => {
            console.log('⚠️ Browser disconnected unexpectedly');
        });

        // Since htmlContent already contains complete HTML, inject Calibri font styles into it
        const calibriStyles = `
    <style>
        body {
            font-family: 'Calibri', 'Arial', sans-serif !important;
            margin: 0;
            padding: 0;
            background-color: #ffffff;
        }
        * {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        table {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        td {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        p {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Calibri', 'Arial', sans-serif !important;
        }
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
    </style>`;

        let fullHTML;

        // Inject Calibri styles into the existing HTML content
        if (htmlContent.includes('</head>')) {
            // Insert styles before closing </head> tag
            fullHTML = htmlContent.replace('</head>', `${calibriStyles}\n</head>`);
        } else if (htmlContent.includes('<head>')) {
            // Insert styles after opening <head> tag
            fullHTML = htmlContent.replace('<head>', `<head>${calibriStyles}`);
        } else if (htmlContent.includes('<html>')) {
            // Insert head section with styles after <html> tag
            fullHTML = htmlContent.replace('<html>', `<html>\n<head>${calibriStyles}\n</head>`);
        } else {
            // Fallback: add styles at the beginning
            fullHTML = `${calibriStyles}\n${htmlContent}`;
        }

        console.log('📄 Setting HTML content...');
        
        // Set page timeout to prevent hanging
        page.setDefaultTimeout(45000); // 45 seconds
        
        try {
            await page.setContent(fullHTML, { 
                waitUntil: 'domcontentloaded', // Changed from 'networkidle0' to 'domcontentloaded'
                timeout: 45000 // Increased timeout to 45 seconds
            });
        } catch (timeoutError) {
            console.log('⚠️ Content loading timed out, trying fallback approach...');
            
            // Fallback: try with just 'load' event
            await page.setContent(fullHTML, { 
                waitUntil: 'load',
                timeout: 30000
            });
        }

        console.log('📄 HTML content loaded, waiting for fonts and images...');
        
        // Wait for fonts to load (important for Calibri font)
        await page.evaluateHandle('document.fonts.ready');
        
        // Wait for any remaining images to load
        await page.waitForFunction(() => {
            const images = Array.from(document.images);
            return images.every(img => img.complete);
        }, { timeout: 10000 }).catch(() => {
            console.log('⚠️ Some images may not have loaded completely');
        });
        
        // Add a small delay to ensure content is fully rendered
        await new Promise(resolve => setTimeout(resolve, 2000));

        // Check if page is still connected before generating PDF
        if (page.isClosed()) {
            throw new Error('Page was closed before PDF generation');
        }

        console.log('📄 Generating PDF...');
        
        // Generate PDF with retry mechanism
        let pdfBuffer;
        let retryCount = 0;
        const maxRetries = 2;
        
        while (retryCount <= maxRetries) {
            try {
                // Check if page is still connected before each attempt
                if (page.isClosed()) {
                    throw new Error('Page was closed before PDF generation');
                }
                
                pdfBuffer = await page.pdf({
                    format: 'A4',
                    printBackground: true,
                    margin: {
                        top: '5mm',
                        right: '10mm',
                        bottom: '5mm',
                        left: '10mm'
                    },
                    displayHeaderFooter: false,
                    timeout: 60000, // 60 seconds timeout for PDF generation
                    preferCSSPageSize: true // Better page size handling
                });
                
                console.log('✅ PDF generated successfully on attempt', retryCount + 1);
                break; // Success, exit retry loop
                
            } catch (pdfError) {
                retryCount++;
                console.log(`⚠️ PDF generation attempt ${retryCount} failed:`, pdfError.message);
                
                if (retryCount > maxRetries) {
                    throw pdfError; // Re-throw if max retries exceeded
                }
                
                // Wait before retry
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }

        console.log('✅ PDF generated successfully, size:', pdfBuffer.length, 'bytes');

        // Return PDF as response
        return new NextResponse(pdfBuffer, {
            status: 200,
            headers: {
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="MIS-Document-${documentId || 'generated'}.pdf"`,
                'Content-Length': pdfBuffer.length.toString(),
            },
        });

    } catch (error) {
        console.error('❌ Error generating PDF:', error);

        // Clean up browser resources
        try {
            if (page && !page.isClosed()) {
                await page.close().catch(() => {
                    console.log('⚠️ Page was already closed');
                });
            }
            if (browser && browser.isConnected()) {
                await browser.close().catch(() => {
                    console.log('⚠️ Browser was already closed');
                });
            }
        } catch (cleanupError) {
            console.error('❌ Error during cleanup:', cleanupError.message);
        }

        // Check for specific error types
        if (error.message.includes('Target closed') || 
            error.message.includes('Protocol error') ||
            error.message.includes('Page.printToPDF')) {
            return NextResponse.json(
                {
                    error: 'PDF generation failed - browser connection lost',
                    details: 'The PDF generation process was interrupted. Please try again.',
                    code: 'TARGET_CLOSED_ERROR'
                },
                { status: 500 }
            );
        }

        // Check if it's a Chrome launch error
        if (error.message.includes('Failed to launch the browser process') ||
            error.message.includes('libgbm.so.1') ||
            error.message.includes('Code: 127')) {
            return NextResponse.json(
                {
                    error: 'PDF generation temporarily unavailable',
                    details: 'Server configuration issue. Please contact support or try again later.',
                    code: 'CHROME_LAUNCH_ERROR'
                },
                { status: 503 }
            );
        }

        // Check for timeout errors
        if (error.message.includes('timeout') || 
            error.message.includes('Timeout') ||
            error.message.includes('Navigation timeout') ||
            error.name === 'TimeoutError') {
            return NextResponse.json(
                {
                    error: 'PDF generation timeout',
                    details: 'The PDF generation took too long to complete. The document may be too complex or have slow-loading content. Please try again.',
                    code: 'TIMEOUT_ERROR'
                },
                { status: 504 }
            );
        }

        return NextResponse.json(
            {
                error: 'Failed to generate PDF',
                details: error.message,
                code: 'PDF_GENERATION_ERROR'
            },
            { status: 500 }
        );
    } finally {
        // Ensure browser cleanup happens even if there's an unexpected error
        try {
            if (page && !page.isClosed()) {
                await page.close().catch(() => {
                    console.log('⚠️ Page was already closed in finally block');
                });
            }
            if (browser && browser.isConnected()) {
                await browser.close().catch(() => {
                    console.log('⚠️ Browser was already closed in finally block');
                });
            }
        } catch (cleanupError) {
            console.error('❌ Error during final cleanup:', cleanupError.message);
        }
    }
}
