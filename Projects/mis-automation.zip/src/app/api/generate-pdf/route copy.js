import { NextResponse } from 'next/server';
import puppeteer from 'puppeteer';

export async function POST(request) {
    try {
        const { htmlContent, documentId } = await request.json();

        if (!htmlContent) {
            return NextResponse.json(
                { error: 'HTML content is required' },
                { status: 400 }
            );
        }

        console.log('🔄 Starting PDF generation for document:', documentId);

        // Launch Puppeteer browser
        const browser = await puppeteer.launch({
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ]
        });

        const page = await browser.newPage();

        // Set viewport for consistent rendering
        await page.setViewport({
            width: 1200,
            height: 800,
            deviceScaleFactor: 1,
        });

        // Set content with proper HTML structure
        const fullHTML = ` 
                ${htmlContent} 
        `;

        await page.setContent(fullHTML, { waitUntil: 'networkidle0' });

        // Generate PDF with proper settings
        const pdfBuffer = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: {
                top: '20mm',
                right: '15mm',
                bottom: '20mm',
                left: '15mm'
            },
            displayHeaderFooter: true,
            headerTemplate: `
                <div style="font-size: 10px; text-align: center; width: 100%; color: #666;">
                    MIS Document - Generated on ${new Date().toLocaleDateString()}
                </div>
            `,
            footerTemplate: `
                <div style="font-size: 10px; text-align: center; width: 100%; color: #666;">
                    Page <span class="pageNumber"></span> of <span class="totalPages"></span>
                </div>
            `
        });

        await browser.close();

        console.log('✅ PDF generated successfully');

        // Return PDF as response
        return new NextResponse(pdfBuffer, {
            status: 200,
            headers: {
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="MIS-Document-${documentId || 'generated'}.pdf"`,
                'Content-Length': pdfBuffer.length.toString(),
            },
        });

    } catch (error) {
        console.error('❌ Error generating PDF:', error);

        return NextResponse.json(
            {
                error: 'Failed to generate PDF',
                details: error.message
            },
            { status: 500 }
        );
    }
}
