import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';

export async function POST(request) {
    try {
        console.log('🔄 Starting employee sync process...');
        
        // Extract authorization header from the request
        const authHeader = request.headers.get('authorization');
        console.log('🔍 Auth header present:', !!authHeader);
        
        // Get all employees from external API
        const externalApiUrl = process.env.NEXT_PUBLIC_ALL_EMPLOYEES;
        
        console.log('🔍 Environment check:', {
            hasApiUrl: !!externalApiUrl,
            apiUrl: externalApiUrl ? 'Configured' : 'Not configured'
        });
        
        if (!externalApiUrl) {
            console.warn('⚠️ NEXT_PUBLIC_ALL_EMPLOYEES not configured, using test data');
            
            // Use test data when external API is not configured
            const testData = {
                "0": { "id": "501", "display_name": "Amol Patil" },
                "1": { "id": "1949", "display_name": "Admin User" },
                "2": { "id": "1001", "display_name": "John Doe" },
                "3": { "id": "1002", "display_name": "Jane Smith" },
                "4": { "id": "1003", "display_name": "Bob Johnson" },
                "5": { "id": "1004", "display_name": "Alice Brown" }
            };
            
            console.log('🔍 Using test data for sync:', testData);
            
            // Process test data
            const employees = Object.values(testData).map((employee, index) => ({
                id: employee.id || `emp_${index}`,
                emp_code: employee.id || `emp_${index}`,
                emp_name: employee.display_name || 'Unknown Employee'
            }));

            console.log('🔍 Processed test employees:', employees);

            // Get current admin statuses from database
            console.log('🔍 Fetching current admin statuses from database...');
            const adminQuery = `SELECT EMP_CODE, IS_ADMIN FROM MIS_ACCESS_CONTROL`;
            let adminResult;
            try {
                adminResult = await executeQuery(adminQuery);
            } catch (dbError) {
                console.error('❌ Database error fetching admin statuses:', dbError);
                throw new Error(`Database error: ${dbError.message}`);
            }
            
            // Create a map of current admin statuses
            const currentAdminStatus = {};
            if (adminResult.rows) {
                adminResult.rows.forEach(row => {
                    currentAdminStatus[row.EMP_CODE] = row.IS_ADMIN;
                });
            }

            console.log('🔍 Current admin statuses:', currentAdminStatus);

            // Sync employees to database
            let insertedCount = 0;
            let updatedCount = 0;
            let skippedCount = 0;

            for (const employee of employees) {
                try {
                    console.log(`🔍 Processing employee: ${employee.emp_code} - ${employee.emp_name}`);
                    
                    // Check if employee exists
                    const checkQuery = `SELECT ID, IS_ADMIN FROM MIS_ACCESS_CONTROL WHERE EMP_CODE = :emp_code`;
                    let checkResult;
                    try {
                        checkResult = await executeQuery(checkQuery, [employee.emp_code]);
                    } catch (checkError) {
                        console.error(`❌ Database error checking employee ${employee.emp_code}:`, checkError);
                        skippedCount++;
                        continue;
                    }

                    if (!checkResult.rows || checkResult.rows.length === 0) {
                        // Insert new employee with is_admin = 0 (default)
                        const insertQuery = `
                            INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN) 
                            VALUES (:id, :emp_code, :emp_name, 0)
                        `;
                        try {
                            await executeQuery(insertQuery, [
                                employee.id,
                                employee.emp_code,
                                employee.emp_name
                            ]);
                            insertedCount++;
                            console.log(`✅ Inserted new employee: ${employee.emp_code} - ${employee.emp_name}`);
                        } catch (insertError) {
                            console.error(`❌ Database error inserting employee ${employee.emp_code}:`, insertError);
                            skippedCount++;
                        }
                    } else {
                        // Update existing employee (preserve admin status)
                        const existingAdminStatus = checkResult.rows[0].IS_ADMIN;
                        const updateQuery = `
                            UPDATE MIS_ACCESS_CONTROL 
                            SET EMP_NAME = :emp_name 
                            WHERE EMP_CODE = :emp_code
                        `;
                        try {
                            await executeQuery(updateQuery, [
                                employee.emp_name,
                                employee.emp_code
                            ]);
                            updatedCount++;
                            console.log(`🔄 Updated employee: ${employee.emp_code} - ${employee.emp_name} (admin: ${existingAdminStatus})`);
                        } catch (updateError) {
                            console.error(`❌ Database error updating employee ${employee.emp_code}:`, updateError);
                            skippedCount++;
                        }
                    }
                } catch (error) {
                    console.error(`❌ Unexpected error processing employee ${employee.emp_code}:`, error);
                    skippedCount++;
                }
            }

            // Get final count
            console.log('🔍 Getting final counts...');
            let totalEmployees = 0;
            let totalAdmins = 0;
            
            try {
                const countQuery = `SELECT COUNT(*) as total_count FROM MIS_ACCESS_CONTROL`;
                const countResult = await executeQuery(countQuery);
                totalEmployees = countResult.rows[0].TOTAL_COUNT;
            } catch (countError) {
                console.error('❌ Error getting total count:', countError);
            }

            try {
                const adminCountQuery = `SELECT COUNT(*) as admin_count FROM MIS_ACCESS_CONTROL WHERE IS_ADMIN = 1`;
                const adminCountResult = await executeQuery(adminCountQuery);
                totalAdmins = adminCountResult.rows[0].ADMIN_COUNT;
            } catch (adminCountError) {
                console.error('❌ Error getting admin count:', adminCountError);
            }

            console.log('✅ Employee sync completed successfully!');
            console.log(`📊 Sync Summary:
                - Inserted: ${insertedCount}
                - Updated: ${updatedCount}
                - Skipped: ${skippedCount}
                - Total Employees: ${totalEmployees}
                - Total Admins: ${totalAdmins}
            `);

            return NextResponse.json({
                success: true,
                message: 'Employee sync completed successfully (using test data)',
                data: {
                    inserted: insertedCount,
                    updated: updatedCount,
                    skipped: skippedCount,
                    total_employees: totalEmployees,
                    total_admins: totalAdmins,
                    test_mode: true
                }
            });
        }

        console.log('🔍 Fetching employees from external API:', externalApiUrl);
        
        // Fetch from external API
        let response;
        try {
            const headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };
            
            // Add authorization header if available
            if (authHeader) {
                headers['Authorization'] = authHeader;
                console.log('🔍 Using authorization header for external API call');
            } else {
                console.warn('⚠️ No authorization header available for external API call');
            }
            
            response = await fetch(externalApiUrl, {
                method: 'GET',
                headers: headers
            });
        } catch (fetchError) {
            console.error('❌ Network error fetching from external API:', fetchError);
            throw new Error(`Network error: ${fetchError.message}`);
        }

        console.log('🔍 External API response status:', response.status, response.statusText);

        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ External API error:', response.status, errorText);
            
            // If 401 Unauthorized, fall back to test mode
            if (response.status === 401) {
                console.warn('⚠️ External API returned 401 Unauthorized, falling back to test mode');
                
                // Use test data when external API is not accessible
                const testData = {
                    "0": { "id": "501", "display_name": "Amol Patil" },
                    "1": { "id": "1949", "display_name": "Admin User" },
                    "2": { "id": "1001", "display_name": "John Doe" },
                    "3": { "id": "1002", "display_name": "Jane Smith" },
                    "4": { "id": "1003", "display_name": "Bob Johnson" },
                    "5": { "id": "1004", "display_name": "Alice Brown" }
                };
                
                console.log('🔍 Using test data due to 401 error:', testData);
                
                // Process test data (same logic as before)
                const employees = Object.values(testData).map((employee, index) => ({
                    id: employee.id || `emp_${index}`,
                    emp_code: employee.id || `emp_${index}`,
                    emp_name: employee.display_name || 'Unknown Employee'
                }));

                console.log('🔍 Processed test employees:', employees);

                // Get current admin statuses from database
                console.log('🔍 Fetching current admin statuses from database...');
                const adminQuery = `SELECT EMP_CODE, IS_ADMIN FROM MIS_ACCESS_CONTROL`;
                let adminResult;
                try {
                    adminResult = await executeQuery(adminQuery);
                } catch (dbError) {
                    console.error('❌ Database error fetching admin statuses:', dbError);
                    throw new Error(`Database error: ${dbError.message}`);
                }
                
                // Create a map of current admin statuses
                const currentAdminStatus = {};
                if (adminResult.rows) {
                    adminResult.rows.forEach(row => {
                        currentAdminStatus[row.EMP_CODE] = row.IS_ADMIN;
                    });
                }

                console.log('🔍 Current admin statuses:', currentAdminStatus);

                // Sync employees to database
                let insertedCount = 0;
                let updatedCount = 0;
                let skippedCount = 0;

                for (const employee of employees) {
                    try {
                        console.log(`🔍 Processing employee: ${employee.emp_code} - ${employee.emp_name}`);
                        
                        // Check if employee exists
                        const checkQuery = `SELECT ID, IS_ADMIN FROM MIS_ACCESS_CONTROL WHERE EMP_CODE = :emp_code`;
                        let checkResult;
                        try {
                            checkResult = await executeQuery(checkQuery, [employee.emp_code]);
                        } catch (checkError) {
                            console.error(`❌ Database error checking employee ${employee.emp_code}:`, checkError);
                            skippedCount++;
                            continue;
                        }

                        if (!checkResult.rows || checkResult.rows.length === 0) {
                            // Insert new employee with is_admin = 0 (default)
                            const insertQuery = `
                                INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN) 
                                VALUES (:id, :emp_code, :emp_name, 0)
                            `;
                            try {
                                await executeQuery(insertQuery, [
                                    employee.id,
                                    employee.emp_code,
                                    employee.emp_name
                                ]);
                                insertedCount++;
                                console.log(`✅ Inserted new employee: ${employee.emp_code} - ${employee.emp_name}`);
                            } catch (insertError) {
                                console.error(`❌ Database error inserting employee ${employee.emp_code}:`, insertError);
                                skippedCount++;
                            }
                        } else {
                            // Update existing employee (preserve admin status)
                            const existingAdminStatus = checkResult.rows[0].IS_ADMIN;
                            const updateQuery = `
                                UPDATE MIS_ACCESS_CONTROL 
                                SET EMP_NAME = :emp_name 
                                WHERE EMP_CODE = :emp_code
                            `;
                            try {
                                await executeQuery(updateQuery, [
                                    employee.emp_name,
                                    employee.emp_code
                                ]);
                                updatedCount++;
                                console.log(`🔄 Updated employee: ${employee.emp_code} - ${employee.emp_name} (admin: ${existingAdminStatus})`);
                            } catch (updateError) {
                                console.error(`❌ Database error updating employee ${employee.emp_code}:`, updateError);
                                skippedCount++;
                            }
                        }
                    } catch (error) {
                        console.error(`❌ Unexpected error processing employee ${employee.emp_code}:`, error);
                        skippedCount++;
                    }
                }

                // Get final count
                console.log('🔍 Getting final counts...');
                let totalEmployees = 0;
                let totalAdmins = 0;
                
                try {
                    const countQuery = `SELECT COUNT(*) as total_count FROM MIS_ACCESS_CONTROL`;
                    const countResult = await executeQuery(countQuery);
                    totalEmployees = countResult.rows[0].TOTAL_COUNT;
                } catch (countError) {
                    console.error('❌ Error getting total count:', countError);
                }

                try {
                    const adminCountQuery = `SELECT COUNT(*) as admin_count FROM MIS_ACCESS_CONTROL WHERE IS_ADMIN = 1`;
                    const adminCountResult = await executeQuery(adminCountQuery);
                    totalAdmins = adminCountResult.rows[0].ADMIN_COUNT;
                } catch (adminCountError) {
                    console.error('❌ Error getting admin count:', adminCountError);
                }

                console.log('✅ Employee sync completed successfully!');
                console.log(`📊 Sync Summary:
                    - Inserted: ${insertedCount}
                    - Updated: ${updatedCount}
                    - Skipped: ${skippedCount}
                    - Total Employees: ${totalEmployees}
                    - Total Admins: ${totalAdmins}
                `);

                return NextResponse.json({
                    success: true,
                    message: 'Employee sync completed successfully (using test data due to 401 error)',
                    data: {
                        inserted: insertedCount,
                        updated: updatedCount,
                        skipped: skippedCount,
                        total_employees: totalEmployees,
                        total_admins: totalAdmins,
                        test_mode: true,
                        reason: 'External API returned 401 Unauthorized'
                    }
                });
            }
            
            throw new Error(`External API error: ${response.status} - ${response.statusText}. Response: ${errorText}`);
        }

        const externalData = await response.json();
        console.log('🔍 External API response data:', externalData);

        // Process external data
        const employees = Object.values(externalData).map((employee, index) => ({
            id: employee.id || `emp_${index}`,
            emp_code: employee.id || `emp_${index}`,
            emp_name: employee.display_name || 'Unknown Employee'
        }));

        console.log('🔍 Processed employees:', employees);

        // Get current admin statuses from database
        console.log('🔍 Fetching current admin statuses from database...');
        const adminQuery = `SELECT EMP_CODE, IS_ADMIN FROM MIS_ACCESS_CONTROL`;
        let adminResult;
        try {
            adminResult = await executeQuery(adminQuery);
        } catch (dbError) {
            console.error('❌ Database error fetching admin statuses:', dbError);
            throw new Error(`Database error: ${dbError.message}`);
        }
        
        // Create a map of current admin statuses
        const currentAdminStatus = {};
        if (adminResult.rows) {
            adminResult.rows.forEach(row => {
                currentAdminStatus[row.EMP_CODE] = row.IS_ADMIN;
            });
        }

        console.log('🔍 Current admin statuses:', currentAdminStatus);

        // Sync employees to database
        let insertedCount = 0;
        let updatedCount = 0;
        let skippedCount = 0;

        for (const employee of employees) {
            try {
                console.log(`🔍 Processing employee: ${employee.emp_code} - ${employee.emp_name}`);
                
                // Check if employee exists
                const checkQuery = `SELECT ID, IS_ADMIN FROM MIS_ACCESS_CONTROL WHERE EMP_CODE = :emp_code`;
                let checkResult;
                try {
                    checkResult = await executeQuery(checkQuery, [employee.emp_code]);
                } catch (checkError) {
                    console.error(`❌ Database error checking employee ${employee.emp_code}:`, checkError);
                    skippedCount++;
                    continue;
                }

                if (!checkResult.rows || checkResult.rows.length === 0) {
                    // Insert new employee with is_admin = 0 (default)
                    const insertQuery = `
                        INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN) 
                        VALUES (:id, :emp_code, :emp_name, 0)
                    `;
                    try {
                        await executeQuery(insertQuery, [
                            employee.id,
                            employee.emp_code,
                            employee.emp_name
                        ]);
                        insertedCount++;
                        console.log(`✅ Inserted new employee: ${employee.emp_code} - ${employee.emp_name}`);
                    } catch (insertError) {
                        console.error(`❌ Database error inserting employee ${employee.emp_code}:`, insertError);
                        skippedCount++;
                    }
                } else {
                    // Update existing employee (preserve admin status)
                    const existingAdminStatus = checkResult.rows[0].IS_ADMIN;
                    const updateQuery = `
                        UPDATE MIS_ACCESS_CONTROL 
                        SET EMP_NAME = :emp_name 
                        WHERE EMP_CODE = :emp_code
                    `;
                    try {
                        await executeQuery(updateQuery, [
                            employee.emp_name,
                            employee.emp_code
                        ]);
                        updatedCount++;
                        console.log(`🔄 Updated employee: ${employee.emp_code} - ${employee.emp_name} (admin: ${existingAdminStatus})`);
                    } catch (updateError) {
                        console.error(`❌ Database error updating employee ${employee.emp_code}:`, updateError);
                        skippedCount++;
                    }
                }
            } catch (error) {
                console.error(`❌ Unexpected error processing employee ${employee.emp_code}:`, error);
                skippedCount++;
            }
        }

        // Get final count
        console.log('🔍 Getting final counts...');
        let totalEmployees = 0;
        let totalAdmins = 0;
        
        try {
            const countQuery = `SELECT COUNT(*) as total_count FROM MIS_ACCESS_CONTROL`;
            const countResult = await executeQuery(countQuery);
            totalEmployees = countResult.rows[0].TOTAL_COUNT;
        } catch (countError) {
            console.error('❌ Error getting total count:', countError);
        }

        try {
            const adminCountQuery = `SELECT COUNT(*) as admin_count FROM MIS_ACCESS_CONTROL WHERE IS_ADMIN = 1`;
            const adminCountResult = await executeQuery(adminCountQuery);
            totalAdmins = adminCountResult.rows[0].ADMIN_COUNT;
        } catch (adminCountError) {
            console.error('❌ Error getting admin count:', adminCountError);
        }

        console.log('✅ Employee sync completed successfully!');
        console.log(`📊 Sync Summary:
            - Inserted: ${insertedCount}
            - Updated: ${updatedCount}
            - Skipped: ${skippedCount}
            - Total Employees: ${totalEmployees}
            - Total Admins: ${totalAdmins}
        `);

        return NextResponse.json({
            success: true,
            message: 'Employee sync completed successfully',
            data: {
                inserted: insertedCount,
                updated: updatedCount,
                skipped: skippedCount,
                total_employees: totalEmployees,
                total_admins: totalAdmins
            }
        });

    } catch (error) {
        console.error('❌ Error in employee sync:', error);
        return NextResponse.json({
            success: false,
            error: error.message
        }, { status: 500 });
    }
}

// GET method to check sync status
export async function GET() {
    try {
        const countQuery = `SELECT COUNT(*) as total_count FROM MIS_ACCESS_CONTROL`;
        const countResult = await executeQuery(countQuery);
        const totalEmployees = countResult.rows[0].TOTAL_COUNT;

        const adminCountQuery = `SELECT COUNT(*) as admin_count FROM MIS_ACCESS_CONTROL WHERE IS_ADMIN = 1`;
        const adminCountResult = await executeQuery(adminCountQuery);
        const totalAdmins = adminCountResult.rows[0].ADMIN_COUNT;

        return NextResponse.json({
            success: true,
            data: {
                total_employees: totalEmployees,
                total_admins: totalAdmins,
                last_sync: new Date().toISOString()
            }
        });
    } catch (error) {
        console.error('❌ Error checking sync status:', error);
        return NextResponse.json({
            success: false,
            error: error.message
        }, { status: 500 });
    }
}
