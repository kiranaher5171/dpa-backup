import { NextRequest } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// OCI PAR URLs for different file types
const OCI_PAR_URLS = {
  logo: process.env.OCI_CLIENT_LOGO_PAR_URL || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/bmexgnkisxsv/bucket_dev_dpa_mis_automation/client-logo/',
  banner: process.env.OCI_MIS_BANNERS_PAR_URL || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/bmexgnkisxsv/bucket_dev_dpa_mis_automation/mis-banners/'
};

// Helper function to generate OCI file URL
function generateOciFileUrl(filename, type) {
  if (!filename) return null;
  const baseUrl = OCI_PAR_URLS[type];
  if (!baseUrl) return null;
  return `${baseUrl}${filename}`; // Use filename as-is, no encoding
}

// Helper function to extract filename from path
function extractFilename(filePath) {
  if (!filePath) return null;
  return filePath.split('/').pop(); // Get the filename with extension
}

// PUT - Update client logo or banner
export async function PUT(request) {
  try {
    console.log('📤 PUT /api/upload - Starting upload request...');
    
    // Verify authentication using SSO token
    const authResult = await verifyAnyToken(request);
    if (!authResult.isValid) {
      console.error('❌ Authentication failed');
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    console.log('✅ Authentication successful');

    let formData;
    try {
      formData = await request.formData();
      console.log('✅ FormData parsed successfully');
    } catch (formError) {
      console.error('❌ Error parsing FormData:', formError);
      return new Response(JSON.stringify({ 
        error: 'Failed to parse form data',
        details: formError.message
      }), { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const file = formData.get('file');
    const type = formData.get('type'); // 'logo' or 'banner'
    const clientId = formData.get('clientId');

    console.log('📋 Form data received:', {
      hasFile: !!file,
      fileType: file?.type,
      fileName: file?.name,
      fileSize: file?.size,
      type: type,
      clientId: clientId
    });

    if (!file || !type) {
      console.error('❌ Missing required fields:', { hasFile: !!file, hasType: !!type });
      return new Response(JSON.stringify({ 
        error: 'File and type are required' 
      }), { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Validate type parameter
    if (!['logo', 'banner'].includes(type)) {
      console.error('❌ Invalid type:', type);
      return new Response(JSON.stringify({ 
        error: 'Type must be either "logo" or "banner"' 
      }), { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Validate file type (only images)
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      return new Response(JSON.stringify({ 
        error: 'Only image files (JPEG, PNG, GIF, WebP) are allowed' 
      }), { status: 400 });
    }

    // Validate file size (1MB limit)
    const maxFileSize = 1 * 1024 * 1024; // 1MB in bytes
    if (file.size > maxFileSize) {
      return new Response(JSON.stringify({ 
        error: `File size exceeds the 1MB limit. Current size: ${(file.size / 1024 / 1024).toFixed(2)}MB` 
      }), { status: 400 });
    }

    // Validate clientId for logos
    if (type === 'logo' && !clientId) {
      return new Response(JSON.stringify({ 
        error: 'clientId is required for logo uploads' 
      }), { status: 400 });
    }

    // Use original filename as-is
    const filename = file.name;

    // Upload to OCI using PAR
    const ociUrl = OCI_PAR_URLS[type];
    console.log(`🔍 Checking OCI PAR URL for type: ${type}`);
    console.log(`   Environment variable: OCI_MIS_BANNERS_PAR_URL=${process.env.OCI_MIS_BANNERS_PAR_URL || 'NOT SET'}`);
    console.log(`   Environment variable: OCI_CLIENT_LOGO_PAR_URL=${process.env.OCI_CLIENT_LOGO_PAR_URL || 'NOT SET'}`);
    console.log(`   Resolved OCI URL: ${ociUrl || 'NOT SET'}`);
    
    if (!ociUrl) {
      console.error(`❌ OCI PAR URL not configured for type: ${type}`);
      console.error(`   Available OCI_PAR_URLS:`, Object.keys(OCI_PAR_URLS));
      return new Response(JSON.stringify({ 
        error: `OCI PAR URL not configured for type: ${type}. Please check environment variables.`,
        type: type,
        availableTypes: Object.keys(OCI_PAR_URLS)
      }), { 
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if OCI URL is accessible before attempting upload
    try {
      console.log('🔍 Testing OCI URL accessibility...');
      const testResponse = await fetch(ociUrl, {
        method: 'HEAD',
        headers: {
          'User-Agent': 'DPA-MIS-Automation/1.0'
        }
      });
      
      if (!testResponse.ok) {
        console.warn(`⚠️ OCI URL not accessible: ${testResponse.status} ${testResponse.statusText}`);
        // Continue with upload attempt anyway, as some OCI endpoints might not support HEAD
      } else {
        console.log('✅ OCI URL is accessible');
      }
    } catch (testError) {
      console.warn('⚠️ OCI URL test failed:', testError.message);
      // Continue with upload attempt anyway
    }

    // Construct the full upload URL with object name
    // For banners, we need to include the mis-banners/ folder path
    // For logos, we need to include the client-logo/ folder path
    let objectName = filename;
    if (type === 'banner') {
      // Ensure mis-banners/ folder is included in the path
      objectName = `mis-banners/${filename}`;
    } else if (type === 'logo') {
      // Ensure client-logo/ folder is included in the path
      objectName = `client-logo/${filename}`;
    }
    
    // Construct upload URL - PAR URL should end with /o/ and we append the object name
    const uploadUrl = ociUrl.endsWith('/') ? `${ociUrl}${objectName}` : `${ociUrl}/${objectName}`;

    console.log('🔍 Upload Debug Info:');
    console.log('  - Type:', type);
    console.log('  - OCI Base URL:', ociUrl);
    console.log('  - Object Name:', objectName);
    console.log('  - Full Upload URL:', uploadUrl);
    console.log('  - Original filename:', file.name);
    console.log('  - File size:', file.size, 'bytes');
    console.log('  - File type:', file.type);

    try {
      // Upload file to OCI
      console.log('🚀 Starting OCI upload...');
      console.log('   Upload URL:', uploadUrl);
      console.log('   File details:', {
        name: file.name,
        type: file.type,
        size: file.size,
        lastModified: file.lastModified
      });

      // Convert file to buffer/stream for upload
      let fileBuffer;
      try {
        const arrayBuffer = await file.arrayBuffer();
        fileBuffer = Buffer.from(arrayBuffer);
        console.log('✅ File converted to buffer, size:', fileBuffer.length);
      } catch (bufferError) {
        console.error('❌ Error converting file to buffer:', bufferError);
        throw new Error(`Failed to read file: ${bufferError.message}`);
      }

      const uploadResponse = await fetch(uploadUrl, {
        method: 'PUT',
        body: fileBuffer,
        headers: {
          'Content-Type': file.type,
          'Content-Length': fileBuffer.length.toString()
        }
      });

      console.log('📡 OCI Upload Response:');
      console.log('  - Status:', uploadResponse.status);
      console.log('  - Status Text:', uploadResponse.statusText);
      console.log('  - Headers:', Object.fromEntries(uploadResponse.headers.entries()));

      if (!uploadResponse.ok) {
        let errorText = '';
        try {
          errorText = await uploadResponse.text();
          console.error('❌ OCI Upload Error Response:', errorText);
        } catch (textError) {
          console.error('❌ Could not read error response:', textError);
          errorText = `Status: ${uploadResponse.status} ${uploadResponse.statusText}`;
        }
        throw new Error(`OCI upload failed: ${uploadResponse.status} - ${uploadResponse.statusText}. Response: ${errorText}`);
      }

      console.log(`✅ File uploaded to OCI successfully: ${filename}`);
      console.log('   Upload URL:', uploadUrl);

      // Update database with filename only (for logos)
      if (type === 'logo' && clientId) {
        const updateQuery = 'UPDATE clients SET logo_url = :1, updated_at = CURRENT_TIMESTAMP WHERE id = :2';
        await executeQuery(updateQuery, [filename, clientId]);
      }

      return new Response(JSON.stringify({
        success: true,
        message: `${type} uploaded successfully`,
        filename: filename,
        url: generateOciFileUrl(filename, type)
      }), { 
        status: 200,
        headers: {
          'Content-Type': 'application/json'
        }
      });

    } catch (uploadError) {
      console.error('❌ OCI upload error:', uploadError);
      console.error('❌ Error details:', {
        name: uploadError.name,
        message: uploadError.message,
        stack: uploadError.stack,
        cause: uploadError.cause
      });
      
      // Handle specific error types
      let errorMessage = 'Failed to upload file to OCI';
      if (uploadError.message.includes('fetch failed')) {
        errorMessage = 'Network error: Unable to connect to OCI storage. Please check your internet connection and try again.';
      } else if (uploadError.message.includes('Failed to fetch')) {
        errorMessage = 'Connection error: Unable to reach OCI storage server. The PAR URL may be expired or invalid.';
      } else if (uploadError.message.includes('CORS')) {
        errorMessage = 'CORS error: Cross-origin request blocked. Please contact administrator.';
      } else {
        errorMessage = `Failed to upload file to OCI: ${uploadError.message}`;
      }
      
      return new Response(JSON.stringify({ 
        error: errorMessage,
        details: uploadError.message,
        type: 'upload_error'
      }), { status: 500 });
    }

  } catch (error) {
    console.error('❌ Error uploading file:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      name: error.name,
      message: error.message,
      cause: error.cause
    });
    
    // Provide more specific error messages
    let errorMessage = 'Failed to upload file';
    let statusCode = 500;
    
    if (error.message.includes('OCI PAR URL not configured')) {
      errorMessage = error.message;
      statusCode = 500;
    } else if (error.message.includes('Failed to parse form data')) {
      errorMessage = error.message;
      statusCode = 400;
    } else if (error.message.includes('OCI upload failed')) {
      errorMessage = `Upload to storage failed: ${error.message}`;
      statusCode = 502; // Bad Gateway
    } else if (error.message.includes('Failed to read file')) {
      errorMessage = error.message;
      statusCode = 400;
    } else {
      errorMessage = `Failed to upload file: ${error.message}`;
    }
    
    return new Response(JSON.stringify({ 
      error: errorMessage,
      details: process.env.NODE_ENV === 'development' ? error.message : undefined,
      type: 'upload_error'
    }), { 
      status: statusCode,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
}

// POST method for backward compatibility (deprecated)
export async function POST(request) {
  console.warn('POST method is deprecated. Please use PUT method for file uploads.');
  return await PUT(request);
}


