import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';

// GET endpoint to fetch all employees from MIS_ACCESS_CONTROL table
export async function GET(request) {
    try {
        console.log('🔍 Get All Employees: Fetching all employees from database...');
        
        // Validate authentication
        const authResult = await verifyAnyToken(request);
        if (!authResult.isValid) {
            return NextResponse.json(
                { success: false, error: 'Unauthorized - please login' },
                { status: 401 }
            );
        }

        // Get all employees from MIS_ACCESS_CONTROL table
        const query = `
            SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
            FROM MIS_ACCESS_CONTROL 
            ORDER BY EMP_NAME
        `;
        
        const result = await executeQuery(query);
        
        console.log(`✅ Get All Employees: Found ${result.rows.length} employees in database`);

        return NextResponse.json({
            success: true,
            employees: result.rows,
            total_count: result.rows.length
        });

    } catch (error) {
        console.error('❌ Get All Employees: Error fetching employees:', error);
        return NextResponse.json(
            { 
                success: false, 
                error: 'Failed to fetch employees from database',
                details: error.message 
            },
            { status: 500 }
        );
    }
}
