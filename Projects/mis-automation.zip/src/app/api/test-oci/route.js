import { NextResponse } from 'next/server';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// OCI PAR URLs for different file types
const OCI_PAR_URLS = {
  logo: process.env.OCI_CLIENT_LOGO_PAR_URL || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/bmexgnkisxsv/bucket_dev_dpa_mis_automation/client-logo/',
  banner: process.env.OCI_MIS_BANNERS_PAR_URL || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/bmexgnkisxsv/bucket_dev_dpa_mis_automation/mis-banners/'
};

// GET - Test OCI connectivity
export async function GET(request) {
  try {
    console.log('🧪 Testing OCI connectivity...');
    
    const results = {};
    
    for (const [type, url] of Object.entries(OCI_PAR_URLS)) {
      console.log(`🔍 Testing ${type} URL: ${url}`);
      
      try {
        // Test with a simple HEAD request to check if the URL is accessible
        const testResponse = await fetch(url, {
          method: 'HEAD',
          headers: {
            'User-Agent': 'DPA-MIS-Automation/1.0'
          }
        });
        
        results[type] = {
          url: url,
          status: testResponse.status,
          statusText: testResponse.statusText,
          accessible: testResponse.ok,
          headers: Object.fromEntries(testResponse.headers.entries())
        };
        
        console.log(`✅ ${type} test result:`, results[type]);
        
      } catch (error) {
        console.error(`❌ ${type} test error:`, error);
        results[type] = {
          url: url,
          error: error.message,
          accessible: false
        };
      }
    }
    
    return NextResponse.json({
      success: true,
      message: 'OCI connectivity test completed',
      results: results,
      environment: {
        NODE_ENV: process.env.NODE_ENV,
        hasLogoUrl: !!process.env.OCI_CLIENT_LOGO_PAR_URL,
        hasBannerUrl: !!process.env.OCI_MIS_BANNERS_PAR_URL
      }
    });
    
  } catch (error) {
    console.error('❌ OCI test error:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      results: {}
    }, { status: 500 });
  }
}
