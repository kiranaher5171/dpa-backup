import { NextResponse } from 'next/server'
import { verifyAnyToken } from '@/lib/jwt'
import { executeQuery } from '@/lib/db'
import { sendTemplateRequestStatusEmail } from '@/lib/emailService'

export async function PUT(request, { params }) {
    try {
        console.log('🔄 PUT /api/raise-template-request/[id]/update-status')

        // Fix for Next.js 15: await params
        const { id } = await params
        console.log('📝 Request ID:', id)

        // Verify authentication
        const authResult = await verifyAnyToken(request)
        if (!authResult.isValid) {
            console.error('❌ Authentication failed:', authResult.error)
            return NextResponse.json(
                { error: 'Authentication failed', details: authResult.error },
                { status: 401 }
            )
        }

        console.log('✅ Authentication successful:', {
            employeeCode: authResult.employee_code,
            userId: authResult.userId,
            isAdmin: authResult.isAdmin
        })

        // Get request body
        const body = await request.json()
        const { status, adminComment } = body

        console.log('📝 Request body:', { status, adminComment })

        // Validate required fields
        if (!status) {
            console.error('❌ Status is required')
            return NextResponse.json(
                { error: 'Status is required' },
                { status: 400 }
            )
        }

        // Validate status value
        const validStatuses = ['open', 'approved', 'rejected', 'in_progress', 'completed']
        if (!validStatuses.includes(status)) {
            console.error('❌ Invalid status:', status)
            return NextResponse.json(
                { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
                { status: 400 }
            )
        }

        // Validate request ID
        const requestId = id
        if (!requestId) {
            console.error('❌ Request ID is required')
            return NextResponse.json(
                { error: 'Request ID is required' },
                { status: 400 }
            )
        }

        // Check if request exists and get requestor details
        const checkQuery = `
            SELECT ID, STATUS, ADMIN_COMMENT, REQUESTOR_NAME, EMPLOYEE_CODE, MIS_REQ_CLIENT_NAME, MIS_REQ_INVOICE_ID, REQUEST_COMMENT, CREATED_AT, REQUESTOR_EMAIL
            FROM MIS_Template_Requests 
            WHERE ID = :1
        `

        const checkResult = await executeQuery(checkQuery, [requestId])

        if (!checkResult.rows || checkResult.rows.length === 0) {
            console.error('❌ Request not found:', requestId)
            return NextResponse.json(
                { error: 'Request not found' },
                { status: 404 }
            )
        }

        const existingRequest = checkResult.rows[0]
        console.log('📝 Existing request:', existingRequest)

        // Get requestor email from the request itself
        const requestorEmail = existingRequest.REQUESTOR_EMAIL

        console.log('📧 Requestor email from request:', {
            employeeCode: existingRequest.EMPLOYEE_CODE,
            email: requestorEmail
        })

        // Update the request
        const updateQuery = `
            UPDATE MIS_Template_Requests 
            SET STATUS = :1,
                ADMIN_COMMENT = :2,
                ADMIN_UPDATED_AT = CURRENT_TIMESTAMP,
                UPDATED_BY = :3
            WHERE ID = :4
        `

        const updateParams = [
            status,
            adminComment || null,
            authResult.employee_code,
            requestId
        ]

        console.log('📝 Update query params:', updateParams)

        await executeQuery(updateQuery, updateParams)

        console.log('✅ Request updated successfully')

        // Fetch the updated request
        const fetchQuery = `
            SELECT 
                ID,
                REQUESTOR_NAME,
                EMPLOYEE_CODE,
                MIS_REQ_CLIENT_NAME,
                MIS_REQ_INVOICE_ID,
                REQUEST_COMMENT,
                STATUS,
                ADMIN_COMMENT,
                CREATED_AT,
                ADMIN_UPDATED_AT,
                REQUESTOR_EMAIL
            FROM MIS_Template_Requests 
            WHERE ID = :1
        `

        const fetchResult = await executeQuery(fetchQuery, [requestId])

        const updatedRequest = fetchResult.rows && fetchResult.rows[0] ? fetchResult.rows[0] : null
        console.log('✅ Updated request data:', updatedRequest)

        // Send email notification if status changed and email is available
        // COMMENTED OUT FOR TESTING - Email sending disabled
        let emailSent = false
        // if (updatedRequest && requestorEmail && status !== existingRequest.STATUS) {
        //     try {
        //         console.log('📧 Sending status update email...', {
        //             requestId: updatedRequest.ID,
        //             oldStatus: existingRequest.STATUS,
        //             newStatus: status,
        //             requestorEmail: requestorEmail
        //         })

        //         await sendTemplateRequestStatusEmail(
        //             requestorEmail,
        //             updatedRequest.REQUESTOR_NAME,
        //             status,
        //             updatedRequest,
        //             adminComment
        //         )

        //         console.log('✅ Status update email sent successfully')
        //         emailSent = true
        //     } catch (emailError) {
        //         console.error('❌ Failed to send status update email:', emailError)
        //         // Don't fail the request if email fails, just log the error
        //     }
        // } else {
        //     console.log('📧 Email notification skipped:', {
        //         hasUpdatedRequest: !!updatedRequest,
        //         hasEmail: !!requestorEmail,
        //         statusChanged: status !== existingRequest.STATUS
        //     })
        // }

        return NextResponse.json({
            success: true,
            message: 'Request status updated successfully',
            request: updatedRequest,
            emailSent: emailSent
        })

    } catch (error) {
        console.error('❌ Unexpected error in update-status:', error)
        return NextResponse.json(
            { error: 'Internal server error', details: error.message },
            { status: 500 }
        )
    }
}
