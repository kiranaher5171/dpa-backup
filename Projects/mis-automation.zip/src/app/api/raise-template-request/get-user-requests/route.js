import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful for GET, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to validate employee code
function validateEmployeeCode(employeeCode) {
  if (!employeeCode) {
    return { isValid: false, error: 'Employee code not found in token' };
  }
  return { isValid: true, employeeCode };
}

// Helper function to validate status parameter
function validateStatus(status) {
  if (!status) return { isValid: true };

  const validStatuses = ['req_raised', 'approved', 'rejected', 'in_progress', 'completed'];
  if (typeof status !== 'string' || !validStatuses.includes(status)) {
    return { isValid: false, error: 'Invalid status value' };
  }

  return { isValid: true, sanitizedStatus: status.trim() };
}

// Helper function to validate pagination parameters
function validatePagination(limit, offset) {
  const limitNum = parseInt(limit);
  const offsetNum = parseInt(offset);
  
  if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
    return { isValid: false, error: 'Invalid limit value. Must be between 1 and 100' };
  }
  
  if (isNaN(offsetNum) || offsetNum < 0) {
    return { isValid: false, error: 'Invalid offset value. Must be 0 or greater' };
  }

  return { isValid: true, limitNum, offsetNum };
}

// Helper function to build query
function buildQuery(employeeCode, sanitizedStatus, limitNum, offsetNum) {
  let query = `
    SELECT 
      ID,
      REQUESTOR_NAME,
      EMPLOYEE_CODE,
      MIS_REQ_CLIENT_NAME,
      MIS_REQ_INVOICE_ID,
      TO_CHAR(REQUEST_COMMENT) as REQUEST_COMMENT,
      STATUS,
      CREATED_AT,
      UPDATED_AT,
      CREATED_BY,
      UPDATED_BY,
      TO_CHAR(ADMIN_COMMENT) as ADMIN_COMMENT,
      ADMIN_UPDATED_AT,
      ADMIN_UPDATED_BY
    FROM MIS_Template_Requests
    WHERE EMPLOYEE_CODE = :1
  `;
  
  const queryParams = [employeeCode];
  
  if (sanitizedStatus) {
    query += ` AND STATUS = :${queryParams.length + 1}`;
    queryParams.push(sanitizedStatus);
  }
  
  query += ' ORDER BY CREATED_AT DESC';
  query += ` OFFSET ${offsetNum} ROWS FETCH NEXT ${limitNum} ROWS ONLY`;

  return { query, queryParams };
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to clean row data
function cleanRowData(row) {
  const cleanRow = {};
  for (const [key, value] of Object.entries(row)) {
    if (value && typeof value === 'object' && value.constructor && value.constructor.name === 'Date') {
      // Handle Date objects
      cleanRow[key] = value.toISOString();
    } else if (value && typeof value === 'object' && value.constructor && value.constructor.name === 'Buffer') {
      // Handle Buffer objects
      cleanRow[key] = value.toString('utf8');
    } else if (value && typeof value === 'object' && value.constructor && value.constructor.name === 'ConnectDescription') {
      // Skip circular reference objects
      console.log(`⚠️ Skipping circular reference object for ${key}`);
      continue; // Skip this field entirely
    } else {
      // Handle regular values
      cleanRow[key] = value;
    }
  }
  return cleanRow;
}

// Helper function to clean all rows
function cleanRows(rows) {
  return rows.map(cleanRowData);
}

// GET - Fetch user-specific template requests
export async function GET(request) {
  try {
    console.log('🔍 Fetching user-specific template requests...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Validate employee code
    const employeeCodeValidation = validateEmployeeCode(authValidation.authResult.employee_code);
    if (!employeeCodeValidation.isValid) {
      return NextResponse.json({ error: employeeCodeValidation.error }, { status: 400 });
    }

    console.log('👤 Processing template requests for employee code:', employeeCodeValidation.employeeCode);

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const limit = searchParams.get('limit') || '50';
    const offset = searchParams.get('offset') || '0';

    // Validate parameters
    const statusValidation = validateStatus(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    const paginationValidation = validatePagination(limit, offset);
    if (!paginationValidation.isValid) {
      return NextResponse.json({ error: paginationValidation.error }, { status: 400 });
    }

    // Build and execute query
    const { query, queryParams } = buildQuery(
      employeeCodeValidation.employeeCode,
      statusValidation.sanitizedStatus,
      paginationValidation.limitNum,
      paginationValidation.offsetNum
    );

    console.log('🔍 Executing user-specific template requests query:', query);
    console.log('🔍 Query parameters:', queryParams);

    const results = await executeQuery(query, queryParams);
    console.log('📊 Database query results:', results);

    // Extract and clean rows
    const rows = extractRows(results);
    const cleanedRows = cleanRows(rows);

    console.log(`✅ Found ${cleanedRows.length} user-specific template requests for employee ${employeeCodeValidation.employeeCode}`);
    return NextResponse.json({ 
      success: true, 
      requests: cleanedRows || [],
      total: cleanedRows.length,
      limit: paginationValidation.limitNum,
      offset: paginationValidation.offsetNum,
      userId: authValidation.authResult.userId,
      employeeCode: employeeCodeValidation.employeeCode,
      dataType: 'user_template_requests',
      filteredByUser: true
    });

  } catch (error) {
    console.error('❌ Error fetching user-specific template requests:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState
    });
    
    return NextResponse.json({ 
      error: 'Failed to fetch user-specific template requests',
      details: error.message,
      code: error.code || 'UNKNOWN'
    }, { status: 500 });
  }
}
