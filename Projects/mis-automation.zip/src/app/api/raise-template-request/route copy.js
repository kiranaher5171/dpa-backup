import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';
import { verifyAnyToken } from '@/lib/jwt';
import { sendTemplateRequestStatusEmail, sendNewTemplateRequestAdminEmail } from '@/lib/emailService';

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to validate requestor name
function validateRequestorName(requestorName) {
  if (!requestorName || typeof requestorName !== 'string' || requestorName.length > 255) {
    return { isValid: false, error: 'Invalid requestorName: must be a string with max length 255' };
  }
  return { isValid: true, sanitized: requestorName.trim() };
}

// Helper function to validate employee code
function validateEmployeeCode(employeeCode) {
  if (!employeeCode || typeof employeeCode !== 'string' || employeeCode.length > 100) {
    return { isValid: false, error: 'Invalid employeeCode: must be a string with max length 100' };
  }
  return { isValid: true, sanitized: employeeCode.trim() };
}

// Helper function to validate client name
function validateClientName(misReqClientName) {
  if (!misReqClientName || typeof misReqClientName !== 'string' || misReqClientName.length > 255) {
    return { isValid: false, error: 'Invalid misReqClientName: must be a string with max length 255' };
  }
  return { isValid: true, sanitized: misReqClientName.trim() };
}

// Helper function to validate invoice ID
function validateInvoiceId(misReqInvoiceId) {
  if (!misReqInvoiceId || (typeof misReqInvoiceId !== 'string' && typeof misReqInvoiceId !== 'number') || misReqInvoiceId.toString().length > 100) {
    return { isValid: false, error: 'Invalid misReqInvoiceId: must be a string or number with max length 100' };
  }
  return { isValid: true, sanitized: misReqInvoiceId.toString().trim() };
}

// Helper function to validate request comment
function validateRequestComment(requestComment) {
  if (requestComment && (typeof requestComment !== 'string' || requestComment.length > 4000)) {
    return { isValid: false, error: 'Invalid requestComment: must be a string with max length 4000' };
  }
  return { isValid: true, sanitized: requestComment ? requestComment.trim() : null };
}

// Helper function to validate requestor email
function validateRequestorEmail(requestorEmail) {
  if (requestorEmail && (typeof requestorEmail !== 'string' || requestorEmail.length > 255)) {
    return { isValid: false, error: 'Invalid requestorEmail: must be a string with max length 255' };
  }
  // Basic email validation
  if (requestorEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(requestorEmail)) {
    return { isValid: false, error: 'Invalid requestorEmail: must be a valid email address' };
  }
  return { isValid: true, sanitized: requestorEmail ? requestorEmail.trim() : null };
}

// Helper function to validate template name
function validateTemplateName(templateName) {
  if (!templateName || typeof templateName !== 'string' || templateName.length > 255) {
    return { isValid: false, error: 'Invalid templateName: must be a string with max length 255' };
  }
  if (templateName.trim().length === 0) {
    return { isValid: false, error: 'Template name cannot be empty' };
  }
  return { isValid: true, sanitized: templateName.trim() };
}

// Helper function to build insert query
function buildInsertQuery() {
  return `
    INSERT INTO MIS_Template_Requests (
      REQUESTOR_NAME,
      EMPLOYEE_CODE,
      MIS_REQ_CLIENT_NAME,
      MIS_REQ_INVOICE_ID,
      TEMPLATE_NAME,
      REQUEST_COMMENT,
      REQUESTOR_EMAIL,
      STATUS,
      CREATED_AT,
      UPDATED_AT,
      CREATED_BY,
      UPDATED_BY
    ) VALUES (
      :1, :2, :3, :4, :5, :6, :7, 'open', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, :8, :9
    )
  `;
}

// Helper function to build fetch query
function buildFetchQuery() {
  return `
    SELECT 
      ID,
      REQUESTOR_NAME,
      EMPLOYEE_CODE,
      MIS_REQ_CLIENT_NAME,
      MIS_REQ_INVOICE_ID,
      TEMPLATE_NAME,
      TO_CHAR(REQUEST_COMMENT) as REQUEST_COMMENT,
      REQUESTOR_EMAIL,
      STATUS,
      CREATED_AT,
      UPDATED_AT,
      CREATED_BY,
      UPDATED_BY,
      TO_CHAR(ADMIN_COMMENT) as ADMIN_COMMENT,
      ADMIN_UPDATED_AT,
      ADMIN_UPDATED_BY
    FROM MIS_Template_Requests
    WHERE REQUESTOR_NAME = :1 
    AND EMPLOYEE_CODE = :2 
    AND MIS_REQ_CLIENT_NAME = :3 
    AND MIS_REQ_INVOICE_ID = :4
    ORDER BY CREATED_AT DESC
  `;
}

// Helper function to create fallback data
function createFallbackData(sanitizedData, currentTimestamp) {
  return {
    requestorName: sanitizedData.requestorName,
    employeeCode: sanitizedData.employeeCode,
    misReqClientName: sanitizedData.misReqClientName,
    misReqInvoiceId: sanitizedData.misReqInvoiceId,
    templateName: sanitizedData.templateName,
    requestComment: sanitizedData.requestComment,
    status: 'open',
    createdAt: currentTimestamp
  };
}

// Helper function to validate employee code parameter
function validateEmployeeCodeParam(employeeCode) {
  if (employeeCode && (typeof employeeCode !== 'string' || employeeCode.length > 100)) {
    return { isValid: false, error: 'Invalid employeeCode format or length' };
  }
  return { isValid: true, sanitized: employeeCode ? employeeCode.trim().replace(/[^a-zA-Z0-9\-_]/g, '') : null };
}

// Helper function to validate status parameter
function validateStatusParam(status) {
  if (status && (typeof status !== 'string' || !['open', 'approved', 'rejected', 'in_progress', 'completed'].includes(status))) {
    return { isValid: false, error: 'Invalid status value' };
  }
  return { isValid: true, sanitized: status ? status.trim() : null };
}

// Helper function to build select query
function buildSelectQuery(sanitizedEmployeeCode, sanitizedStatus) {
  let query = `
    SELECT 
      ID,
      REQUESTOR_NAME,
      EMPLOYEE_CODE,
      MIS_REQ_CLIENT_NAME,
      MIS_REQ_INVOICE_ID,
      TEMPLATE_NAME,
      TO_CHAR(REQUEST_COMMENT) as REQUEST_COMMENT,
      REQUESTOR_EMAIL,
      STATUS,
      CREATED_AT,
      UPDATED_AT,
      CREATED_BY,
      UPDATED_BY,
      TO_CHAR(ADMIN_COMMENT) as ADMIN_COMMENT,
      ADMIN_UPDATED_AT,
      ADMIN_UPDATED_BY
    FROM MIS_Template_Requests
  `;

  const queryParams = [];
  const conditions = [];

  if (sanitizedEmployeeCode) {
    conditions.push('EMPLOYEE_CODE = :' + (queryParams.length + 1));
    queryParams.push(sanitizedEmployeeCode);
  }

  if (sanitizedStatus) {
    conditions.push('STATUS = :' + (queryParams.length + 1));
    queryParams.push(sanitizedStatus);
  }

  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }

  query += ' ORDER BY CREATED_AT DESC';

  return { query, queryParams };
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to validate all request fields
function validateAllFields(body) {
  const { requestorName, employeeCode, misReqClientName, misReqInvoiceId, templateName, requestComment, requestorEmail } = body;

  const requestorNameValidation = validateRequestorName(requestorName);
  if (!requestorNameValidation.isValid) {
    return { isValid: false, error: requestorNameValidation.error };
  }

  const employeeCodeValidation = validateEmployeeCode(employeeCode);
  if (!employeeCodeValidation.isValid) {
    return { isValid: false, error: employeeCodeValidation.error };
  }

  const clientNameValidation = validateClientName(misReqClientName);
  if (!clientNameValidation.isValid) {
    return { isValid: false, error: clientNameValidation.error };
  }

  const invoiceIdValidation = validateInvoiceId(misReqInvoiceId);
  if (!invoiceIdValidation.isValid) {
    return { isValid: false, error: invoiceIdValidation.error };
  }

  const templateNameValidation = validateTemplateName(templateName);
  if (!templateNameValidation.isValid) {
    return { isValid: false, error: templateNameValidation.error };
  }

  const requestCommentValidation = validateRequestComment(requestComment);
  if (!requestCommentValidation.isValid) {
    return { isValid: false, error: requestCommentValidation.error };
  }

  const requestorEmailValidation = validateRequestorEmail(requestorEmail);
  if (!requestorEmailValidation.isValid) {
    return { isValid: false, error: requestorEmailValidation.error };
  }

  return {
    isValid: true,
    sanitizedData: {
      requestorName: requestorNameValidation.sanitized,
      employeeCode: employeeCodeValidation.sanitized,
      misReqClientName: clientNameValidation.sanitized,
      misReqInvoiceId: invoiceIdValidation.sanitized,
      templateName: templateNameValidation.sanitized,
      requestComment: requestCommentValidation.sanitized,
      requestorEmail: requestorEmailValidation.sanitized
    }
  };
}

// Helper function to handle error responses
function handleErrorResponse(error) {
  console.error('❌ Error raising template request:', error);

  // Check if it's a database table not found error
  if (error.message && error.message.includes('table or view does not exist')) {
    return NextResponse.json({
      success: false,
      error: 'Database table MIS_Template_Requests does not exist. Please create the table first.',
      details: 'Run the database table creation script in your Oracle ATP database.'
    }, { status: 500 });
  }

  // Check if it's a validation error
  if (error.message && error.message.includes('Invalid')) {
    return NextResponse.json({
      success: false,
      error: error.message
    }, { status: 400 });
  }

  return NextResponse.json({
    success: false,
    error: 'Failed to raise template request',
    details: error.message
  }, { status: 500 });
}

export async function POST(request) {
  try {
    console.log('📝 Raising template request...');

    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const body = await request.json();

    console.log('📝 Received request body:', body);
    console.log('📝 Request body types:', {
      requestorName: typeof body.requestorName,
      employeeCode: typeof body.employeeCode,
      misReqClientName: typeof body.misReqClientName,
      misReqInvoiceId: typeof body.misReqInvoiceId,
      requestComment: typeof body.requestComment,
      requestorEmail: typeof body.requestorEmail
    });

    // Validate all fields
    const validationResult = validateAllFields(body);
    if (!validationResult.isValid) {
      return NextResponse.json({ success: false, error: validationResult.error }, { status: 400 });
    }

    const sanitizedData = validationResult.sanitizedData;

    const currentTimestamp = new Date().toISOString();

    console.log('📝 Inserting template request with data:', {
      requestorName: sanitizedData.requestorName,
      employeeCode: sanitizedData.employeeCode,
      misReqClientName: sanitizedData.misReqClientName,
      misReqInvoiceId: sanitizedData.misReqInvoiceId,
      templateName: sanitizedData.templateName,
      requestComment: sanitizedData.requestComment ? 'provided' : 'null',
      requestorEmail: sanitizedData.requestorEmail ? 'provided' : 'null',
      timestamp: currentTimestamp
    });

    // Insert the template request
    const insertQuery = buildInsertQuery();
    const insertParams = [
      sanitizedData.requestorName,
      sanitizedData.employeeCode,
      sanitizedData.misReqClientName,
      sanitizedData.misReqInvoiceId,
      sanitizedData.templateName,
      sanitizedData.requestComment,
      sanitizedData.requestorEmail,
      sanitizedData.requestorName,  // CREATED_BY
      sanitizedData.requestorName   // UPDATED_BY
    ];

    console.log('📝 Executing INSERT query:', insertQuery);
    console.log('📝 INSERT parameters:', insertParams);

    await executeQuery(insertQuery, insertParams);
    console.log('✅ Template request created successfully');

    // Fetch the created request
    const fetchQuery = buildFetchQuery();
    const fetchParams = [
      sanitizedData.requestorName,
      sanitizedData.employeeCode,
      sanitizedData.misReqClientName,
      sanitizedData.misReqInvoiceId
    ];

    const fetchResult = await executeQuery(fetchQuery, fetchParams);

    let createdRequest = null;
    if (fetchResult.rows && fetchResult.rows[0]) {
      createdRequest = fetchResult.rows[0];
    }

            // Send confirmation email to requestor if email is provided
        // COMMENTED OUT FOR TESTING - Email sending disabled
        let emailSent = false;
        // if (createdRequest && sanitizedData.requestorEmail) {
        //     try {
        //         console.log('📧 Sending request confirmation email...', {
        //             requestId: createdRequest.ID,
        //             requestorEmail: sanitizedData.requestorEmail,
        //             requestorName: sanitizedData.requestorName
        //         });

        //         await sendTemplateRequestStatusEmail(
        //             sanitizedData.requestorEmail,
        //             sanitizedData.requestorName,
        //             'open', // Status is 'open' for new requests
        //             createdRequest,
        //             'Your request has been raised successfully. The creative team will review and work on this. Thank you for your patience.'
        //         );

        //         console.log('✅ Request confirmation email sent successfully');
        //         emailSent = true;
        //     } catch (emailError) {
        //         console.error('❌ Failed to send request confirmation email:', emailError);
        //         // Don't fail the request if email fails, just log the error
        //     }
        // } else {
        //     console.log('📧 Request confirmation email skipped:', {
        //         hasCreatedRequest: !!createdRequest,
        //         hasEmail: !!sanitizedData.requestorEmail
        //     });
        // }

        // Send notification email to admin (only if admin email is different from requestor email)
        // COMMENTED OUT FOR TESTING - Admin notification email disabled
        let adminEmailSent = false;
        // if (createdRequest) {
        //     const adminEmail = process.env.NEXT_PUBLIC_ADMIN_EMAIL;
            
        //     // Skip admin notification if admin email is the same as requestor email
        //     if (adminEmail && sanitizedData.requestorEmail && adminEmail.toLowerCase() === sanitizedData.requestorEmail.toLowerCase()) {
        //         console.log('📧 Admin notification email skipped: Admin email is same as requestor email');
        //     } else {
        //         try {
        //             console.log('📧 Sending admin notification email...', {
        //                 requestId: createdRequest.ID,
        //                 requestorName: sanitizedData.requestorName,
        //                 adminEmail: adminEmail,
        //                 requestorEmail: sanitizedData.requestorEmail
        //             });

        //             const adminEmailResult = await sendNewTemplateRequestAdminEmail(createdRequest);
                    
        //             if (adminEmailResult.success) {
        //                 console.log('✅ Admin notification email sent successfully');
        //                 adminEmailSent = true;
        //             } else {
        //                 console.log('⚠️ Admin notification email skipped:', adminEmailResult.reason);
        //             }
        //         } catch (adminEmailError) {
        //             console.error('❌ Failed to send admin notification email:', adminEmailError);
        //             // Don't fail the request if admin email fails, just log the error
        //         }
        //     }
        // }

            return NextResponse.json({
            success: true,
            message: 'Template request raised successfully',
            data: createdRequest || createFallbackData(sanitizedData, currentTimestamp),
            emailSent: emailSent,
            adminEmailSent: adminEmailSent
        });

  } catch (error) {
    return handleErrorResponse(error);
  }
}

// GET method to retrieve template requests (for admin use)
export async function GET(request) {
  try {
    console.log('📋 Fetching template requests...');

    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const employeeCode = searchParams.get('employeeCode');
    const status = searchParams.get('status');

    const employeeCodeValidation = validateEmployeeCodeParam(employeeCode);
    if (!employeeCodeValidation.isValid) {
      return NextResponse.json({ error: employeeCodeValidation.error }, { status: 400 });
    }

    const statusValidation = validateStatusParam(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    // Build and execute query
    const { query, queryParams } = buildSelectQuery(
      employeeCodeValidation.sanitized,
      statusValidation.sanitized
    );

    console.log('🔍 Executing query:', query);
    console.log('🔍 Query parameters:', queryParams);

    const result = await executeQuery(query, queryParams);
    const rows = extractRows(result);

    return NextResponse.json({
      success: true,
      data: rows
    });

  } catch (error) {
    console.error('❌ Error fetching template requests:', error);

    return NextResponse.json({
      success: false,
      error: 'Failed to fetch template requests',
      details: error.message
    }, { status: 500 });
  }
}
