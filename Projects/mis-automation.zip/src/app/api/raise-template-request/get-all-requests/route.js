import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import { determineRoleFromEmployeeCode } from '@/lib/roleUtils';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful for GET, user:', authResult.userId);
  return { isValid: true, authResult };
}


// Helper function to get employee details and determine role (fallback)
async function getEmployeeDetailsAndRole(accessToken) {
  try {
    const url = process.env.NEXT_PUBLIC_SSO_EMPLOYEE_DETAIL;
    const apiTag = process.env.NEXT_PUBLIC_EMPLOYEE_DETAILS_API_TAG || 'Employee Details API';

    console.log('🔐 API: Fetching employee details from:', url);

    if (!url) {
      throw new Error('Employee details API URL not configured');
    }

    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    };

    const response = await fetch(url, {
      method: 'GET',
      headers: headers
    });

    console.log(`🔐 API: Employee details response status:`, response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`🔐 API: Employee details failed:`, response.status, errorText);
      throw new Error(`${apiTag} failed: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log(`🔐 API: Employee details response:`, data);

    // Database-based role checking - no environment variable fallback
    const role = 'user'; // Will be determined by database
    return { success: true, data, role };
  } catch (error) {
    console.error('🔐 API: Error fetching employee details:', error);
    return { success: false, error: error.message };
  }
}

// Helper function to extract access token from request
function extractAccessToken(request) {
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const accessToken = authHeader.substring(7);
    console.log('🔐 Using access token from Authorization header for employee details API');
    return accessToken;
  }
  return null;
}

// Helper function to determine user role and details
async function determineUserRoleAndDetails(authResult, request) {
  let userRole = 'user';
  let employeeCode = null;
  let employeeDetails = null;

  // Check if employee_code is available in JWT token (fast path)
  if (authResult.employee_code) {
    console.log('🚀 Fast path: Using employee_code from JWT token');
    employeeCode = authResult.employee_code;
    userRole = await determineRoleFromEmployeeCode(employeeCode);
    employeeDetails = { employee_code: employeeCode };
  } else {
    // Fallback: Get employee details from API (slower path)
    console.log('🔄 Fallback path: Fetching employee details from API');
    
    const accessToken = extractAccessToken(request);
    if (!accessToken) {
      console.error('❌ No access token available for employee details API');
      throw new Error('No access token available');
    }
    
    const employeeResult = await getEmployeeDetailsAndRole(accessToken);
    if (!employeeResult.success) {
      console.error('❌ Failed to get employee details:', employeeResult.error);
      throw new Error('Failed to get employee details');
    }
    
    userRole = employeeResult.role;
    employeeDetails = employeeResult.data;
    employeeCode = employeeDetails.employee_code;
  }

  return { userRole, employeeCode, employeeDetails };
}

// Helper function to validate status parameter
function validateStatus(status) {
  if (!status) return { isValid: true };

  const validStatuses = ['req_raised', 'approved', 'rejected', 'in_progress', 'completed'];
  if (typeof status !== 'string' || !validStatuses.includes(status)) {
    return { isValid: false, error: 'Invalid status value' };
  }

  return { isValid: true, sanitizedStatus: status.trim() };
}

// Helper function to validate employee code filter
function validateEmployeeCodeFilter(employeeCodeFilter) {
  if (!employeeCodeFilter) return { isValid: true };

  if (typeof employeeCodeFilter !== 'string' || employeeCodeFilter.length > 100) {
    return { isValid: false, error: 'Invalid employeeCode format or length' };
  }

  const sanitized = employeeCodeFilter.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedEmployeeCodeFilter: sanitized };
}

// Helper function to validate pagination parameters
function validatePagination(limit, offset) {
  const limitNum = parseInt(limit);
  const offsetNum = parseInt(offset);
  
  if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
    return { isValid: false, error: 'Invalid limit value. Must be between 1 and 100' };
  }
  
  if (isNaN(offsetNum) || offsetNum < 0) {
    return { isValid: false, error: 'Invalid offset value. Must be 0 or greater' };
  }

  return { isValid: true, limitNum, offsetNum };
}

// Helper function to build query
function buildQuery(sanitizedStatus, sanitizedEmployeeCodeFilter, limitNum, offsetNum) {
  let query = `
    SELECT 
      ID,
      REQUESTOR_NAME,
      EMPLOYEE_CODE,
      MIS_REQ_CLIENT_NAME,
      MIS_REQ_INVOICE_ID,
      TEMPLATE_NAME,
      TO_CHAR(REQUEST_COMMENT) as REQUEST_COMMENT,
      REQUESTOR_EMAIL,
      STATUS,
      CREATED_AT,
      UPDATED_AT,
      CREATED_BY,
      UPDATED_BY,
      TO_CHAR(ADMIN_COMMENT) as ADMIN_COMMENT,
      ADMIN_UPDATED_AT,
      ADMIN_UPDATED_BY
    FROM MIS_Template_Requests
    WHERE 1=1
  `;
  
  const queryParams = [];
  
  if (sanitizedStatus) {
    query += ` AND STATUS = :${queryParams.length + 1}`;
    queryParams.push(sanitizedStatus);
  }
  
  if (sanitizedEmployeeCodeFilter) {
    query += ` AND EMPLOYEE_CODE = :${queryParams.length + 1}`;
    queryParams.push(sanitizedEmployeeCodeFilter);
  }
  
  query += ' ORDER BY CREATED_AT DESC';
  query += ` OFFSET ${offsetNum} ROWS FETCH NEXT ${limitNum} ROWS ONLY`;

  return { query, queryParams };
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to clean row data
function cleanRowData(row) {
  const cleanRow = {};
  for (const [key, value] of Object.entries(row)) {
    if (value && typeof value === 'object' && value.constructor && value.constructor.name === 'Date') {
      // Handle Date objects
      cleanRow[key] = value.toISOString();
    } else if (value && typeof value === 'object' && value.constructor && value.constructor.name === 'Buffer') {
      // Handle Buffer objects
      cleanRow[key] = value.toString('utf8');
    } else if (value && typeof value === 'object' && value.constructor && value.constructor.name === 'ConnectDescription') {
      // Skip circular reference objects
      console.log(`⚠️ Skipping circular reference object for ${key}`);
      continue; // Skip this field entirely
    } else {
      // Handle regular values
      cleanRow[key] = value;
    }
  }
  return cleanRow;
}

// Helper function to clean all rows
function cleanRows(rows) {
  return rows.map(cleanRowData);
}

// GET - Fetch all template requests
export async function GET(request) {
  try {
    console.log('🔍 Fetching all template requests...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Determine user role and details
    const { userRole, employeeCode, employeeDetails } = await determineUserRoleAndDetails(authValidation.authResult, request);
    const loggedInUserId = authValidation.authResult.userId;
    
    console.log('👤 Processing all template requests for admin user:', loggedInUserId, 'with role:', userRole);
    console.log('👤 Employee code:', employeeCode);

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const employeeCodeFilter = searchParams.get('employeeCode');
    const limit = searchParams.get('limit') || '50';
    const offset = searchParams.get('offset') || '0';

    // Validate parameters
    const statusValidation = validateStatus(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    const employeeCodeValidation = validateEmployeeCodeFilter(employeeCodeFilter);
    if (!employeeCodeValidation.isValid) {
      return NextResponse.json({ error: employeeCodeValidation.error }, { status: 400 });
    }

    const paginationValidation = validatePagination(limit, offset);
    if (!paginationValidation.isValid) {
      return NextResponse.json({ error: paginationValidation.error }, { status: 400 });
    }

    // Build and execute query
    const { query, queryParams } = buildQuery(
      statusValidation.sanitizedStatus,
      employeeCodeValidation.sanitizedEmployeeCodeFilter,
      paginationValidation.limitNum,
      paginationValidation.offsetNum
    );

    console.log('🔍 Executing all template requests query:', query);
    console.log('🔍 Query parameters:', queryParams);

    const results = await executeQuery(query, queryParams);
    console.log('📊 Database query results:', results);

    // Extract and clean rows
    const rows = extractRows(results);
    const cleanedRows = cleanRows(rows);

    console.log(`✅ Found ${cleanedRows.length} all template requests for admin user ${loggedInUserId}`);
    return NextResponse.json({ 
      success: true, 
      requests: cleanedRows || [],
      total: cleanedRows.length,
      limit: paginationValidation.limitNum,
      offset: paginationValidation.offsetNum,
      userId: loggedInUserId,
      userRole: userRole,
      employeeCode: employeeCode,
      dataType: 'all_template_requests',
      filteredByAdmin: true,
      performanceMode: authValidation.authResult.employee_code ? 'fast_path' : 'fallback_path'
    });

  } catch (error) {
    console.error('❌ Error fetching all template requests:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState
    });
    
    return NextResponse.json({ 
      error: 'Failed to fetch all template requests',
      details: error.message,
      code: error.code || 'UNKNOWN'
    }, { status: 500 });
  }
}
