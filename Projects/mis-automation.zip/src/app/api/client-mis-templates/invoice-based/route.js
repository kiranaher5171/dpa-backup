import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful for GET, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to validate status parameter
function validateStatus(status) {
  if (!status) return { isValid: true };

  const validStatuses = ['ACTIVE', 'INACTIVE', 'DRAFT'];
  if (typeof status !== 'string' || !validStatuses.includes(status.toUpperCase())) {
    return { isValid: false, error: 'Invalid status value' };
  }
  return { isValid: true, sanitizedStatus: status.trim().toUpperCase() };
}

// Helper function to validate ssoClientId parameter
function validateSsoClientId(ssoClientId) {
  if (!ssoClientId) return { isValid: true };

  if (typeof ssoClientId !== 'string' || ssoClientId.length > 100) {
    return { isValid: false, error: 'Invalid ssoClientId format or length' };
  }

  const sanitized = ssoClientId.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedSsoClientId: sanitized };
}

// Helper function to validate pagination parameters
function validatePagination(limit, offset) {
  const limitNum = parseInt(limit || '50');
  const offsetNum = parseInt(offset || '0');

  if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
    return { isValid: false, error: 'Invalid limit value. Must be between 1 and 100' };
  }

  if (isNaN(offsetNum) || offsetNum < 0) {
    return { isValid: false, error: 'Invalid offset value. Must be 0 or greater' };
  }

  return { isValid: true, limitNum, offsetNum };
}

// Helper function to extract access token from request
function extractAccessToken(request) {
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const accessToken = authHeader.substring(7);
    console.log('🔐 Using access token from Authorization header for invoice API call');
    return accessToken;
  }
  return null;
}

// Helper function to call invoice API
async function callInvoiceAPI(accessToken) {
  const url = process.env.NEXT_PUBLIC_SSO_TIMESHEET_INVOICE_DETAIL;
  if (!url) {
    throw new Error('Invoice API URL not configured');
  }

  const today = new Date().toISOString().split('T')[0];
  const headers = {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  };

  console.log('🔍 Calling invoice API with URL:', url);
  console.log('🔍 Invoice API headers:', headers);
  console.log('🔍 Invoice API body:', { date: today });

  const response = await fetch(url, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify({ date: today })
  });

  console.log('📡 Invoice API response status:', response.status);
  console.log('📡 Invoice API response ok:', response.ok);

  if (!response.ok) {
    const errorText = await response.text();
    console.log('❌ Invoice API error response:', errorText);
    throw new Error(`Invoice API failed: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log('🔍 Raw invoice API response:', data);
  return data;
}

// Helper function to extract invoice client IDs
function extractInvoiceClientIds(invoiceData) {
  const invoiceArray = Array.isArray(invoiceData) ? invoiceData : Object.values(invoiceData).filter(item =>
    typeof item === 'object' && item.invoice_id && item.invoice_name && item.client_name
  );

  console.log('🔍 Filtered invoice array:', invoiceArray);

  const userInvoiceClientIds = [...new Set(invoiceArray.map(invoice => invoice.invoice_id))];
  console.log('🔍 User Invoice IDs (matching SSO_CLIENT_ID):', userInvoiceClientIds);
  console.log('🔍 Invoice details:', invoiceArray.map(inv => ({
    invoice_id: inv.invoice_id,
    client_name: inv.client_name,
    invoice_name: inv.invoice_name
  })));

  return userInvoiceClientIds;
}

// Helper function to fetch user invoice data
async function fetchUserInvoiceData(request) {
  const accessToken = extractAccessToken(request);
  if (!accessToken) {
    return { success: false, error: 'No access token available' };
  }

  try {
    const invoiceData = await callInvoiceAPI(accessToken);
    const userInvoiceClientIds = extractInvoiceClientIds(invoiceData);
    return { success: true, userInvoiceClientIds };
  } catch (error) {
    console.error('❌ Error fetching invoice data:', error);
    return { success: false, error: error.message };
  }
}

// Helper function to build template query
function buildTemplateQuery(userInvoiceClientIds, sanitizedStatus, sanitizedSsoClientId, limitNum, offsetNum) {
  let query = `
    SELECT 
      ID,
      SSO_CLIENT_ID,
      SSO_CLIENT_NAME,
      TEMPLATE_NAME,
      BANNER_URL,
      THEME_COLORS,
      CREATED_AT,
      UPDATED_AT,
      IS_ACTIVE,
      TEMPLATE_ACCESS_EMP_NAMES
    FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
    WHERE IS_ACTIVE = 1
  `;

  const queryParams = [];

  // Filter by user's invoice IDs if available
  if (userInvoiceClientIds.length > 0) {
    const placeholders = userInvoiceClientIds.map((_, index) => `:${index + 1}`).join(',');
    query += ` AND SSO_CLIENT_ID IN (${placeholders})`;
    queryParams.push(...userInvoiceClientIds);
    console.log('🔍 Filtering templates by invoice IDs:', userInvoiceClientIds);
  } else {
    // If no invoice data available, show a limited set of templates for debugging
    console.log('⚠️ No invoice data available, showing limited templates for debugging purposes');
    query += ` AND ROWNUM <= 5`;
    console.log('🔍 Using fallback query with ROWNUM limit');
  }

  if (sanitizedStatus) {
    query += ` AND STATUS = :${queryParams.length + 1}`;
    queryParams.push(sanitizedStatus);
  }

  if (sanitizedSsoClientId) {
    query += ` AND SSO_CLIENT_ID = :${queryParams.length + 1}`;
    queryParams.push(sanitizedSsoClientId);
  }

  query += ' ORDER BY CREATED_AT DESC';
  query += ` OFFSET ${offsetNum} ROWS FETCH NEXT ${limitNum} ROWS ONLY`;

  return { query, queryParams };
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to convert CLOB to string safely
async function clobToString(clobValue) {
  if (!clobValue) return null;

  try {
    // If it's already a string, return it
    if (typeof clobValue === 'string') {
      return clobValue;
    }

    // If it's a CLOB object, convert it to string
    if (clobValue && typeof clobValue.getData === 'function') {
      return await clobValue.getData();
    }

    // If it's null or undefined, return null
    return null;
  } catch (error) {
    console.warn('Error converting CLOB to string:', error);
    return null;
  }
}

// Helper function to handle object type conversion
async function handleObjectValue(value, key) {
  const constructorName = value.constructor?.name;

  if (constructorName === 'Date') {
    return value.toISOString();
  } else if (constructorName === 'Buffer') {
    return value.toString('utf8');
  } else if (constructorName === 'ConnectDescription') {
    console.log(`⚠️ Skipping circular reference object for ${key}`);
    return null; // Return null to indicate this should be skipped
  } else {
    return value;
  }
}

// Helper function to clean row data
async function cleanRowData(row) {
  const cleanRow = {};

  for (const [key, value] of Object.entries(row)) {
    if (key === 'THEME_COLORS' && value) {
      // Convert CLOB to string first, then parse JSON
      const themeColorsString = await clobToString(value);
      try {
        cleanRow[key] = JSON.parse(themeColorsString);
      } catch (e) {
        console.log(`⚠️ Could not parse THEME_COLORS JSON for ${key}:`, e.message);
        cleanRow[key] = [];
      }
    } else if (value && typeof value === 'object') {
      const processedValue = await handleObjectValue(value, key);
      if (processedValue !== null) {
        cleanRow[key] = processedValue;
      }
      // If processedValue is null, skip this field (circular reference)
    } else {
      cleanRow[key] = value;
    }
  }

  return cleanRow;
}

// Helper function to clean all rows
async function cleanRows(rows) {
  return await Promise.all(rows.map(cleanRowData));
}

// Helper function to create error response
function createErrorResponse(loggedInUserId, limit, offset, message, error = null) {
  const response = {
    success: true,
    templates: [],
    total: 0,
    limit: parseInt(limit),
    offset: parseInt(offset),
    userId: loggedInUserId,
    dataType: 'invoice_based_templates',
    userInvoiceClientIds: [],
    filteredByInvoice: false,
    message: message
  };

  if (error) {
    response.error = error;
  }

  return response;
}

// Helper function to debug all templates
async function debugAllTemplates() {
  const allTemplatesQuery = `
    SELECT SSO_CLIENT_ID, SSO_CLIENT_NAME, TEMPLATE_NAME 
    FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
    WHERE IS_ACTIVE = 1
  `;

  try {
    const allTemplatesResult = await executeQuery(allTemplatesQuery, []);
    console.log('🔍 All available templates in database:', allTemplatesResult);
  } catch (debugError) {
    console.error('❌ Error fetching all templates for debug:', debugError);
  }
}

// GET - Fetch invoice-based client MIS templates
export async function GET(request) {
  try {
    console.log('🔍 Fetching invoice-based client MIS templates...');

    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const loggedInUserId = authValidation.authResult.userId;
    console.log('👤 Filtering templates for user:', loggedInUserId);

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const ssoClientId = searchParams.get('ssoClientId');
    const limit = searchParams.get('limit');
    const offset = searchParams.get('offset');

    // Validate parameters
    const statusValidation = validateStatus(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    const ssoClientIdValidation = validateSsoClientId(ssoClientId);
    if (!ssoClientIdValidation.isValid) {
      return NextResponse.json({ error: ssoClientIdValidation.error }, { status: 400 });
    }

    const paginationValidation = validatePagination(limit, offset);
    if (!paginationValidation.isValid) {
      return NextResponse.json({ error: paginationValidation.error }, { status: 400 });
    }

    // Fetch user invoice data
    const invoiceResult = await fetchUserInvoiceData(request);
    if (!invoiceResult.success) {
      console.log('⚠️ Could not fetch invoice data, restricting access for security');
      return NextResponse.json(createErrorResponse(
        loggedInUserId,
        limit,
        offset,
        'Unable to verify your access permissions',
        invoiceResult.error
      ));
    }

    // Build and execute query
    const { query, queryParams } = buildTemplateQuery(
      invoiceResult.userInvoiceClientIds,
      statusValidation.sanitizedStatus,
      ssoClientIdValidation.sanitizedSsoClientId,
      paginationValidation.limitNum,
      paginationValidation.offsetNum
    );

    console.log('🔍 Executing invoice-based template query:', query);
    console.log('🔍 Query parameters:', queryParams);

    const results = await executeQuery(query, queryParams);
    console.log('📊 Database query results:', results);

    // Debug all templates
    await debugAllTemplates();

    // Extract and clean rows
    const rows = extractRows(results);
    const cleanedRows = await cleanRows(rows);

    console.log(`✅ Found ${cleanedRows.length} invoice-based filtered templates for user ${loggedInUserId}`);
    return NextResponse.json({
      success: true,
      templates: cleanedRows || [],
      total: cleanedRows.length,
      limit: paginationValidation.limitNum,
      offset: paginationValidation.offsetNum,
      userId: loggedInUserId,
      dataType: 'invoice_based_templates',
      userInvoiceClientIds: invoiceResult.userInvoiceClientIds,
      filteredByInvoice: invoiceResult.userInvoiceClientIds.length > 0
    });

  } catch (error) {
    console.error('❌ Error fetching invoice-based filtered templates:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState
    });

    return NextResponse.json({
      error: 'Failed to fetch invoice-based filtered templates',
      details: error.message,
      code: error.code || 'UNKNOWN'
    }, { status: 500 });
  }
}