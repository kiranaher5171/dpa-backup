import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';
import { verifyAnyToken } from '@/lib/jwt';

export async function POST(request) {
    try {
        console.log('📋 Fetching all MIS templates with user access info...');

        // Validate authentication
        const authResult = await verifyAnyToken(request);
        if (!authResult.isValid) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }
        console.log('✅ Authentication successful, user:', authResult.userId);

        // Get user name from request body
        let userName = '';
        try {
            const body = await request.json();
            userName = body.userName || body.fullName || body.employeeName || body.name || '';
            console.log('🔍 User name from request body:', userName);
        } catch (e) {
            console.log('🔍 Could not parse request body');
        }

        // If no userName from body, try to get from auth result
        if (!userName) {
            userName = authResult.fullName || authResult.userId || authResult.employeeName || authResult.name || '';
            console.log('🔍 User name from auth result:', userName);
        }

        if (!userName) {
            return NextResponse.json({
                error: 'User name not found. Please provide userName in request body.'
            }, { status: 400 });
        }

        // Fetch all active templates
        const query = `
      SELECT 
        ID,
        SSO_CLIENT_ID,
        SSO_CLIENT_NAME,
        TEMPLATE_NAME,
        TEMPLATE_DATA,
        CREATED_AT,
        UPDATED_AT,
        BANNER_URL,
        THEME_COLORS,
        CREATED_BY,
        STATUS,
        IS_ACTIVE,
        TEMPLATE_ACCESS_EMP_NAMES
      FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
      WHERE IS_ACTIVE = 1
      ORDER BY CREATED_AT DESC
    `;

        console.log('🔍 Executing query for all templates...');
        const result = await executeQuery(query, []);

        console.log(`📊 Fetched ${result.rows.length} total templates`);

        // Clean the rows to handle Oracle-specific objects
        const cleanedRows = await cleanRows(result.rows);
        console.log(`📊 Cleaned ${cleanedRows.length} templates`);

        // Process templates and add access information
        const templatesWithAccess = cleanedRows.map(template => {
            const hasAccess = checkUserAccess(template.TEMPLATE_ACCESS_EMP_NAMES, userName);

            return {
                ...template,
                USER_HAS_ACCESS: hasAccess,
                ACCESS_EMPLOYEE_COUNT: template.TEMPLATE_ACCESS_EMP_NAMES
                    ? template.TEMPLATE_ACCESS_EMP_NAMES.split(',').filter(name => name.trim()).length
                    : 0
            };
        });

        // Sort: templates with access first, then by creation date
        templatesWithAccess.sort((a, b) => {
            if (a.USER_HAS_ACCESS && !b.USER_HAS_ACCESS) return -1;
            if (!a.USER_HAS_ACCESS && b.USER_HAS_ACCESS) return 1;
            return new Date(b.CREATED_AT) - new Date(a.CREATED_AT);
        });

        const accessCount = templatesWithAccess.filter(t => t.USER_HAS_ACCESS).length;
        console.log(`✅ Found ${accessCount} templates with access for user: ${userName}`);

        return NextResponse.json({
            success: true,
            templates: templatesWithAccess,
            totalTemplates: templatesWithAccess.length,
            accessibleTemplates: accessCount,
            userName: userName
        });

    } catch (error) {
        console.error('❌ Error fetching all templates with access:', error);
        return NextResponse.json({
            error: 'Failed to fetch templates with access information',
            details: error.message
        }, { status: 500 });
    }
}

// Helper function to check if user has access to a template
function checkUserAccess(accessNames, userName) {
    if (!accessNames || !userName) return false;

    const names = accessNames.split(',').map(name => name.trim()).filter(name => name);
    return names.includes(userName);
}

// Helper function to convert CLOB to string
async function clobToString(clob) {
    if (!clob) return null;

    if (typeof clob === 'string') {
        return clob;
    }

    // Try to get data using getData() method first
    if (clob && typeof clob.getData === 'function') {
        try {
            return await clob.getData();
        } catch (error) {
            console.warn('Failed to get CLOB data using getData():', error.message);
        }
    }

    // If it's an object with toString method, try to get the string value
    if (clob && typeof clob === 'object' && clob.toString) {
        const stringValue = clob.toString();
        // Only return if it's not the default object string representation
        if (stringValue !== '[object Object]') {
            return stringValue;
        }
    }

    return null;
}

// Helper function to parse JSON fields safely
function parseJsonField(value, fieldName) {
    if (!value || typeof value !== 'string') {
        return value;
    }

    try {
        const parsed = JSON.parse(value);
        console.log(`✅ Successfully parsed ${fieldName}:`, parsed);
        return parsed;
    } catch (error) {
        console.warn(`⚠️ Failed to parse ${fieldName} as JSON:`, error.message);
        console.warn(`⚠️ Raw ${fieldName} value:`, value);
        return value; // Return original value if parsing fails
    }
}

// Helper function to handle object values and avoid circular references
async function handleObjectValue(value, key) {
    if (!value || typeof value !== 'object') {
        return value;
    }

    // Check for circular references
    try {
        JSON.stringify(value);
        return value;
    } catch (error) {
        console.warn(`⚠️ Circular reference detected in ${key}, skipping field`);
        return null;
    }
}

// Helper function to clean row data
async function cleanRowData(row) {
    const cleanRow = {};

    for (const [key, value] of Object.entries(row)) {
        if (key === 'THEME_COLORS' && value) {
            // Convert CLOB to string first, then parse JSON
            console.log('🎨 Processing THEME_COLORS for template:', cleanRow.TEMPLATE_NAME || 'Unknown');
            console.log('🎨 Raw THEME_COLORS value:', value);
            console.log('🎨 THEME_COLORS type:', typeof value);
            console.log('🎨 THEME_COLORS constructor:', value?.constructor?.name);
            
            const themeColorsString = await clobToString(value);
            console.log('🎨 CLOB converted to string:', themeColorsString);
            
            const parsed = parseJsonField(themeColorsString, 'THEME_COLORS');
            console.log('🎨 Parsed THEME_COLORS:', parsed);
            cleanRow[key] = parsed;
        } else if (key === 'TEMPLATE_DATA' && value) {
            // Convert CLOB to string first, then parse JSON
            const templateDataString = await clobToString(value);
            cleanRow[key] = parseJsonField(templateDataString, 'TEMPLATE_DATA') || templateDataString;
        } else if (value && typeof value === 'object') {
            const processedValue = await handleObjectValue(value, key);
            if (processedValue !== null) {
                cleanRow[key] = processedValue;
            }
            // If processedValue is null, skip this field (circular reference)
        } else {
            cleanRow[key] = value;
        }
    }

    return cleanRow;
}

// Helper function to clean all rows
async function cleanRows(rows) {
    return await Promise.all(rows.map(cleanRowData));
}

export async function GET(request) {
    return POST(request);
}
