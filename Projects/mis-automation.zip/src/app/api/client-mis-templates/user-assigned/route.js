import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';
import { verifyAnyToken } from '@/lib/jwt';

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to build select query for user-assigned templates
function buildUserTemplatesQuery(userName) {
  return `
    SELECT 
      ID,
      SSO_CLIENT_ID,
      SSO_CLIENT_NAME,
      TEMPLATE_NAME,
      TEMPLATE_DATA,
      CREATED_AT,
      UPDATED_AT,
      BANNER_URL,
      THEME_COLORS,
      CREATED_BY,
      STATUS,
      IS_ACTIVE,
      TEMPLATE_ACCESS_EMP_NAMES
    FROM CLIENT_MIS_TEMPLATES
    WHERE IS_ACTIVE = 1
    AND STATUS = 'ACTIVE'
    AND (
      TEMPLATE_ACCESS_EMP_NAMES = :userName
      OR TEMPLATE_ACCESS_EMP_NAMES LIKE :userNameCommaStart
      OR TEMPLATE_ACCESS_EMP_NAMES LIKE :userNameCommaEnd
      OR TEMPLATE_ACCESS_EMP_NAMES LIKE :userNameCommaMiddle
    )
    ORDER BY CREATED_AT DESC
  `;
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to clean and process template data
function cleanTemplateData(templates) {
  return templates.map(template => {
    // Process theme colors if they exist
    let themeColors = [];
    if (template.THEME_COLORS) {
      try {
        if (typeof template.THEME_COLORS === 'string') {
          themeColors = JSON.parse(template.THEME_COLORS);
        } else if (Array.isArray(template.THEME_COLORS)) {
          themeColors = template.THEME_COLORS;
        }
      } catch (error) {
        console.warn('Failed to parse theme colors for template:', template.ID, error);
        themeColors = [];
      }
    }

    return {
      ...template,
      THEME_COLORS: themeColors,
      CLIENT_ID: template.SSO_CLIENT_ID,
      CLIENT_NAME: template.SSO_CLIENT_NAME
    };
  });
}

// POST - Fetch user-assigned MIS templates
export async function POST(request) {
  try {
    console.log('📋 Fetching user-assigned MIS templates...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const { authResult } = authValidation;
    
    // Try to get user name from different sources
    let userName = '';
    
    // First try to get it from the request body (most reliable)
    try {
      const body = await request.json();
      userName = body.userName || body.fullName || body.employeeName || body.name || '';
      console.log('🔍 User name from request body:', userName);
    } catch (e) {
      console.log('🔍 Could not parse request body, trying auth result...');
    }
    
    // If still no name, try from authResult
    if (!userName) {
      if (authResult.fullName) {
        userName = authResult.fullName;
      } else if (authResult.userId) {
        userName = authResult.userId;
      } else if (authResult.employeeName) {
        userName = authResult.employeeName;
      } else if (authResult.name) {
        userName = authResult.name;
      }
      console.log('🔍 User name from auth result:', userName);
    }
    
    console.log('🔍 Auth result:', authResult);
    console.log('🔍 Extracted user name:', userName);
    
    if (!userName) {
      return NextResponse.json({ 
        error: 'User name not found in authentication data. Please provide userName in request body.',
        authResult: authResult
      }, { status: 400 });
    }

    console.log('🔍 Fetching templates for user:', userName);
    console.log('🔍 User name type:', typeof userName);
    console.log('🔍 User name length:', userName.length);

    // Build and execute query with proper comma-separated name matching
    const query = buildUserTemplatesQuery(userName);
    const queryParams = [
      userName,                    // Exact match: "John Doe"
      `${userName},%`,           // Start of list: "John Doe,"
      `%,${userName}`,           // End of list: ",John Doe"
      `%,${userName},%`          // Middle of list: ",John Doe,"
    ];

    console.log('🔍 Executing user templates query:', query);
    console.log('🔍 Query parameters:', queryParams);

    const results = await executeQuery(query, queryParams);
    console.log('📊 Database query results:', results);

    // Extract and clean rows
    let rows = extractRows(results);
    let cleanedTemplates = cleanTemplateData(rows);

    // If no results from SQL query, try fetching all templates and filtering manually
    if (cleanedTemplates.length === 0) {
      console.log('🔍 No results from SQL query, trying manual filtering...');
      
      const allTemplatesQuery = `
        SELECT 
          ID,
          SSO_CLIENT_ID,
          SSO_CLIENT_NAME,
          TEMPLATE_NAME,
          TEMPLATE_DATA,
          CREATED_AT,
          UPDATED_AT,
          BANNER_URL,
          THEME_COLORS,
          CREATED_BY,
          STATUS,
          IS_ACTIVE,
          TEMPLATE_ACCESS_EMP_NAMES
        FROM CLIENT_MIS_TEMPLATES
        WHERE IS_ACTIVE = 1
        AND STATUS = 'ACTIVE'
        ORDER BY CREATED_AT DESC
      `;
      
      const allResults = await executeQuery(allTemplatesQuery, []);
      const allRows = extractRows(allResults);
      const allTemplates = cleanTemplateData(allRows);
      
      console.log(`📊 Fetched ${allTemplates.length} total templates for manual filtering`);
      
      // Filter templates where user name appears in TEMPLATE_ACCESS_EMP_NAMES
      cleanedTemplates = allTemplates.filter(template => {
        const accessNames = template.TEMPLATE_ACCESS_EMP_NAMES;
        if (!accessNames) return false;
        
        // Split by comma and trim whitespace
        const names = accessNames.split(',').map(name => name.trim());
        const hasAccess = names.includes(userName);
        
        console.log(`Template ${template.TEMPLATE_NAME} access check:`, {
          ACCESS_NAMES: accessNames,
          SPLIT_NAMES: names,
          USER_NAME: userName,
          HAS_ACCESS: hasAccess
        });
        
        return hasAccess;
      });
      
      console.log(`📊 After manual filtering: ${cleanedTemplates.length} templates for user: ${userName}`);
    }

    // Debug: Log each template's access information
    cleanedTemplates.forEach((template, index) => {
      console.log(`Template ${index + 1} access info:`, {
        ID: template.ID,
        NAME: template.TEMPLATE_NAME,
        ACCESS_NAMES: template.TEMPLATE_ACCESS_EMP_NAMES,
        USER_NAME: userName,
        HAS_ACCESS: template.TEMPLATE_ACCESS_EMP_NAMES?.includes(userName) || false
      });
    });

    console.log(`✅ Found ${cleanedTemplates.length} user-assigned templates for user: ${userName}`);
    
    return NextResponse.json({ 
      success: true, 
      templates: cleanedTemplates || [],
      total: cleanedTemplates.length,
      userName: userName,
      dataType: 'user_assigned_templates',
      message: `Found ${cleanedTemplates.length} templates assigned to ${userName}`
    });

  } catch (error) {
    console.error('❌ Error fetching user-assigned templates:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState
    });
    
    return NextResponse.json({ 
      error: 'Failed to fetch user-assigned templates',
      details: error.message,
      code: error.code || 'UNKNOWN'
    }, { status: 500 });
  }
}

// GET - Fallback method (for backward compatibility)
export async function GET(request) {
  return POST(request);
}
