import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to validate ssoClientId parameter
function validateSsoClientId(ssoClientId) {
  if (!ssoClientId) return { isValid: true };
  
  if (typeof ssoClientId !== 'string' || ssoClientId.length > 100) {
    return { isValid: false, error: 'Invalid ssoClientId format or length' };
  }
  
  const sanitized = ssoClientId.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedSsoClientId: sanitized };
}

// Helper function to validate status parameter
function validateStatus(status) {
  if (!status) return { isValid: true };
  
  const validStatuses = ['ACTIVE', 'INACTIVE', 'DRAFT'];
  if (typeof status !== 'string' || !validStatuses.includes(status.toUpperCase())) {
    return { isValid: false, error: 'Invalid status value' };
  }
  
  return { isValid: true, sanitizedStatus: status.trim().toUpperCase() };
}

// Helper function to build select query
function buildSelectQuery(sanitizedSsoClientId, sanitizedStatus) {
  let query = `
    SELECT 
      ID,
      SSO_CLIENT_ID,
      SSO_CLIENT_NAME,
      TEMPLATE_NAME,
      TEMPLATE_DATA,
      CREATED_AT,
      UPDATED_AT,
      BANNER_URL,
      THEME_COLORS,
      CREATED_BY,
      STATUS,
      IS_ACTIVE,
      TEMPLATE_ACCESS_EMP_NAMES
    FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
    WHERE IS_ACTIVE = 1
  `;
  
  const queryParams = [];
  
  if (sanitizedSsoClientId) {
    query += ' AND SSO_CLIENT_ID = :1';
    queryParams.push(sanitizedSsoClientId);
  }
  
  if (sanitizedStatus) {
    query += ' AND STATUS = :' + (queryParams.length + 1);
    queryParams.push(sanitizedStatus);
  }
  
  query += ' ORDER BY CREATED_AT DESC';
  
  return { query, queryParams };
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to convert CLOB to string safely
async function clobToString(clobValue) {
  if (!clobValue) return null;
  
  try {
    // If it's already a string, return it
    if (typeof clobValue === 'string') {
      return clobValue;
    }
    
    // If it's a CLOB object, convert it to string
    if (clobValue && typeof clobValue.getData === 'function') {
      return await clobValue.getData();
    }
    
    // If it's null or undefined, return null
    return null;
  } catch (error) {
    console.warn('Error converting CLOB to string:', error);
    return null;
  }
}

// Helper function to parse JSON field safely
function parseJsonField(fieldValue, fieldName) {
  if (!fieldValue) return null;
  
  try {
    return JSON.parse(fieldValue);
  } catch (e) {
    console.log(`⚠️ Could not parse ${fieldName} JSON:`, e.message);
    return null;
  }
}

// Helper function to handle object type conversion
async function handleObjectValue(value, key) {
  const constructorName = value.constructor?.name;
  
  if (constructorName === 'Date') {
    return value.toISOString();
  } else if (constructorName === 'Buffer') {
    return value.toString('utf8');
  } else if (constructorName === 'ConnectDescription') {
    console.log(`⚠️ Skipping circular reference object for ${key}`);
    return null; // Return null to indicate this should be skipped
  } else {
    return value;
  }
}

// Helper function to clean row data
async function cleanRowData(row) {
  const cleanRow = {};
  
  for (const [key, value] of Object.entries(row)) {
    if (key === 'THEME_COLORS' && value) {
      console.log(`🔍 Raw THEME_COLORS value for ${key}:`, value);
      console.log(`🔍 Raw THEME_COLORS type:`, typeof value);
      console.log(`🔍 Raw THEME_COLORS length:`, value?.length);
      
      // Convert CLOB to string first, then parse JSON
      const themeColorsString = await clobToString(value);
      const parsed = parseJsonField(themeColorsString, 'THEME_COLORS');
      cleanRow[key] = parsed;
      console.log(`✅ Parsed THEME_COLORS:`, cleanRow[key]);
    } else if (key === 'TEMPLATE_DATA' && value) {
      // Convert CLOB to string first, then parse JSON
      const templateDataString = await clobToString(value);
      cleanRow[key] = parseJsonField(templateDataString, 'TEMPLATE_DATA') || templateDataString;
    } else if (value && typeof value === 'object') {
      const processedValue = await handleObjectValue(value, key);
      if (processedValue !== null) {
        cleanRow[key] = processedValue;
      }
      // If processedValue is null, skip this field (circular reference)
    } else {
      cleanRow[key] = value;
    }
  }
  
  return cleanRow;
}

// Helper function to clean all rows
async function cleanRows(rows) {
  return await Promise.all(rows.map(cleanRowData));
}

// Helper function to validate required fields for POST
function validateRequiredFields(body) {
  const { ssoClientId, templateName } = body;
  
  if (!ssoClientId || !templateName) {
    return { isValid: false, error: 'Missing required fields: ssoClientId, templateName' };
  }
  return { isValid: true };
}

// Helper function to generate template ID
function generateTemplateId() {
  return `cmt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Helper function to prepare template data for storage
function prepareTemplateData(templateData, themeColors) {
  const templateDataString = templateData ? JSON.stringify(templateData) : null;
  const themeColorsString = themeColors ? JSON.stringify(themeColors) : null;

  console.log('📝 Template data to store:', templateDataString);
  console.log('📝 Theme colors to store:', themeColorsString);
  console.log('📝 Theme colors type:', typeof themeColorsString);
  console.log('📝 Theme colors length:', themeColorsString?.length);

  return { templateDataString, themeColorsString };
}

// Helper function to build insert query
function buildInsertQuery() {
  return `
    INSERT INTO DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES (
      ID, SSO_CLIENT_ID, SSO_CLIENT_NAME, TEMPLATE_NAME, TEMPLATE_DATA,
      CREATED_AT, UPDATED_AT, BANNER_URL, THEME_COLORS, CREATED_BY,
      STATUS, IS_ACTIVE
    ) VALUES (
      :1, :2, :3, :4, :5,
      SYSTIMESTAMP, SYSTIMESTAMP, :6, :7, :8,
      :9, 1
    )
  `;
}

// Helper function to build update query
function buildUpdateQuery() {
  return `
    UPDATE DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES SET
      SSO_CLIENT_ID = :1,
      SSO_CLIENT_NAME = :2,
      TEMPLATE_NAME = :3,
      TEMPLATE_DATA = :4,
      UPDATED_AT = SYSTIMESTAMP,
      BANNER_URL = :5,
      THEME_COLORS = :6,
      STATUS = :7
    WHERE ID = :8
  `;
}

// Helper function to validate ID parameter
function validateId(id) {
  if (!id) {
    return { isValid: false, error: 'Missing required parameter: id in request body' };
  }
  
  if (typeof id !== 'string' || id.length > 100) {
    return { isValid: false, error: 'Invalid id format or length' };
  }
  
  const sanitized = id.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  if (sanitized !== id) {
    return { isValid: false, error: 'Id contains invalid characters' };
  }
  
  return { isValid: true, sanitizedId: sanitized };
}

// Helper function to build delete query
function buildDeleteQuery() {
  return `
    UPDATE DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
    SET IS_ACTIVE = 0, UPDATED_AT = SYSTIMESTAMP 
    WHERE ID = :1
  `;
}

// GET - Fetch all client MIS templates
export async function GET(request) {
  try {
    console.log('🔍 Fetching client MIS templates...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const ssoClientId = searchParams.get('ssoClientId');
    const status = searchParams.get('status');

    // Validate parameters
    const ssoClientIdValidation = validateSsoClientId(ssoClientId);
    if (!ssoClientIdValidation.isValid) {
      return NextResponse.json({ error: ssoClientIdValidation.error }, { status: 400 });
    }

    const statusValidation = validateStatus(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    // Build and execute query
    const { query, queryParams } = buildSelectQuery(
      ssoClientIdValidation.sanitizedSsoClientId,
      statusValidation.sanitizedStatus
    );

    console.log('🔍 Executing query:', query);
    console.log('🔍 Query parameters:', queryParams);

    const results = await executeQuery(query, queryParams);
    console.log('📊 Database query results:', results);

    // Extract and clean rows
    const rows = extractRows(results);
    const cleanedRows = await cleanRows(rows);

    console.log(`✅ Found ${cleanedRows.length} client MIS templates`);
    return NextResponse.json({ 
      success: true, 
      templates: cleanedRows || [] 
    });

  } catch (error) {
    console.error('❌ Error fetching client MIS templates:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState
    });
    
    return NextResponse.json({ 
      error: 'Failed to fetch client MIS templates',
      details: error.message,
      code: error.code || 'UNKNOWN'
    }, { status: 500 });
  }
}

// POST - Create new client MIS template
export async function POST(request) {
  try {
    console.log('📝 Creating new client MIS template...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const body = await request.json();
    
    // Validate required fields
    const requiredFieldsValidation = validateRequiredFields(body);
    if (!requiredFieldsValidation.isValid) {
      return NextResponse.json({ error: requiredFieldsValidation.error }, { status: 400 });
    }

    const {
      ssoClientId,
      ssoClientName,
      templateName,
      templateData = '',
      bannerUrl = '',
      themeColors = '{}',
      status = 'ACTIVE'
    } = body;

    // Generate template ID and prepare data
    const templateId = generateTemplateId();
    const { templateDataString, themeColorsString } = prepareTemplateData(templateData, themeColors);

    // Insert new template
    const insertQuery = buildInsertQuery();
    await executeQuery(insertQuery, [
      templateId,
      ssoClientId,
      ssoClientName,
      templateName,
      templateDataString,
      bannerUrl,
      themeColorsString,
      authValidation.authResult.fullName || authValidation.authResult.userId,
      status
    ]);

    console.log(`✅ Created client MIS template with ID: ${templateId}`);
    return NextResponse.json({ 
      success: true, 
      templateId,
      message: 'Client MIS template created successfully' 
    });

  } catch (error) {
    console.error('❌ Error creating client MIS template:', error);
    return NextResponse.json({ 
      error: 'Failed to create client MIS template',
      details: error.message 
    }, { status: 500 });
  }
}

// PUT - Update client MIS template
export async function PUT(request) {
  try {
    console.log('📝 Updating client MIS template...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const body = await request.json();
    
    const {
      id,
      ssoClientId,
      ssoClientName,
      templateName,
      templateData,
      bannerUrl,
      themeColors,
      status
    } = body;

    if (!id) {
      return NextResponse.json({ error: 'Missing required field: id' }, { status: 400 });
    }

    // Prepare data and update template
    const { templateDataString, themeColorsString } = prepareTemplateData(templateData, themeColors);
    const updateQuery = buildUpdateQuery();
    
    await executeQuery(updateQuery, [
      ssoClientId,
      ssoClientName,
      templateName,
      templateDataString,
      bannerUrl,
      themeColorsString,
      status,
      id
    ]);

    console.log(`✅ Updated client MIS template with ID: ${id}`);
    return NextResponse.json({ 
      success: true, 
      message: 'Client MIS template updated successfully' 
    });

  } catch (error) {
    console.error('❌ Error updating client MIS template:', error);
    return NextResponse.json({ 
      error: 'Failed to update client MIS template',
      details: error.message 
    }, { status: 500 });
  }
}

// DELETE - Delete client MIS template (soft delete)
export async function DELETE(request) {
  try {
    console.log('🗑️ Deleting client MIS template...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const body = await request.json();
    const { id } = body;

    // Validate ID parameter
    const idValidation = validateId(id);
    if (!idValidation.isValid) {
      return NextResponse.json({ error: idValidation.error }, { status: 400 });
    }

    // Soft delete template
    const deleteQuery = buildDeleteQuery();
    await executeQuery(deleteQuery, [idValidation.sanitizedId]);

    console.log(`✅ Deleted client MIS template with ID: ${idValidation.sanitizedId}`);
    return NextResponse.json({ 
      success: true, 
      message: 'Client MIS template deleted successfully' 
    });

  } catch (error) {
    console.error('❌ Error deleting client MIS template:', error);
    return NextResponse.json({ 
      error: 'Failed to delete client MIS template',
      details: error.message 
    }, { status: 500 });
  }
}
