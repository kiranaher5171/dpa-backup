import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';

// This endpoint will be called by a cron job every 24 hours
export async function GET(request) {
    try {
        console.log('🕐 Cron Job: Starting scheduled employee sync...');
        
        // Verify this is a legitimate cron request (you can add additional security here)
        const cronSecret = request.headers.get('x-cron-secret');
        const expectedSecret = process.env.CRON_SECRET;
        
        if (expectedSecret && cronSecret !== expectedSecret) {
            console.log('❌ Cron Job: Invalid cron secret');
            return NextResponse.json({ 
                success: false, 
                error: 'Unauthorized cron request' 
            }, { status: 401 });
        }
        
        // Get all employees from external API
        const externalApiUrl = process.env.NEXT_PUBLIC_ALL_EMPLOYEES;
        
        if (!externalApiUrl) {
            console.log('❌ Cron Job: NEXT_PUBLIC_ALL_EMPLOYEES not configured');
            return NextResponse.json({ 
                success: false, 
                error: 'NEXT_PUBLIC_ALL_EMPLOYEES not configured' 
            }, { status: 400 });
        }

        console.log('🔍 Cron Job: Fetching employees from external API:', externalApiUrl);
        
        // Fetch from external API
        const response = await fetch(externalApiUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`External API error: ${response.status} - ${response.statusText}`);
        }

        const externalData = await response.json();
        console.log('🔍 Cron Job: External API response received');

        // Process external data
        const employees = Object.values(externalData).map((employee, index) => ({
            id: employee.id || `emp_${index}`,
            emp_code: employee.id || `emp_${index}`,
            emp_name: employee.display_name || 'Unknown Employee'
        }));

        console.log(`🔍 Cron Job: Processing ${employees.length} employees`);

        // Get current admin statuses from database
        const adminQuery = `SELECT EMP_CODE, IS_ADMIN FROM MIS_ACCESS_CONTROL`;
        const adminResult = await executeQuery(adminQuery);
        
        // Create a map of current admin statuses
        const currentAdminStatus = {};
        adminResult.rows.forEach(row => {
            currentAdminStatus[row.EMP_CODE] = row.IS_ADMIN;
        });

        console.log(`🔍 Cron Job: Found ${Object.keys(currentAdminStatus).length} existing employees in database`);

        // Sync employees to database
        let insertedCount = 0;
        let updatedCount = 0;
        let skippedCount = 0;

        for (const employee of employees) {
            try {
                // Check if employee exists
                const checkQuery = `SELECT ID, IS_ADMIN FROM MIS_ACCESS_CONTROL WHERE EMP_CODE = :emp_code`;
                const checkResult = await executeQuery(checkQuery, [employee.emp_code]);

                if (checkResult.rows.length === 0) {
                    // Insert new employee with is_admin = 0 (default)
                    const insertQuery = `
                        INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN) 
                        VALUES (:id, :emp_code, :emp_name, 0)
                    `;
                    await executeQuery(insertQuery, [
                        employee.id,
                        employee.emp_code,
                        employee.emp_name
                    ]);
                    insertedCount++;
                } else {
                    // Update existing employee (preserve admin status)
                    const updateQuery = `
                        UPDATE MIS_ACCESS_CONTROL 
                        SET EMP_NAME = :emp_name 
                        WHERE EMP_CODE = :emp_code
                    `;
                    await executeQuery(updateQuery, [
                        employee.emp_name,
                        employee.emp_code
                    ]);
                    updatedCount++;
                }
            } catch (error) {
                console.error(`❌ Cron Job: Error processing employee ${employee.emp_code}:`, error);
                skippedCount++;
            }
        }

        // Get final count
        const countQuery = `SELECT COUNT(*) as total_count FROM MIS_ACCESS_CONTROL`;
        const countResult = await executeQuery(countQuery);
        const totalEmployees = countResult.rows[0].TOTAL_COUNT;

        const adminCountQuery = `SELECT COUNT(*) as admin_count FROM MIS_ACCESS_CONTROL WHERE IS_ADMIN = 1`;
        const adminCountResult = await executeQuery(adminCountQuery);
        const totalAdmins = adminCountResult.rows[0].ADMIN_COUNT;

        console.log('✅ Cron Job: Employee sync completed successfully!');
        console.log(`📊 Cron Job Summary:
            - Inserted: ${insertedCount}
            - Updated: ${updatedCount}
            - Skipped: ${skippedCount}
            - Total Employees: ${totalEmployees}
            - Total Admins: ${totalAdmins}
        `);

        return NextResponse.json({
            success: true,
            message: 'Scheduled employee sync completed successfully',
            data: {
                inserted: insertedCount,
                updated: updatedCount,
                skipped: skippedCount,
                total_employees: totalEmployees,
                total_admins: totalAdmins,
                sync_time: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error('❌ Cron Job: Error in scheduled employee sync:', error);
        return NextResponse.json({
            success: false,
            error: error.message,
            sync_time: new Date().toISOString()
        }, { status: 500 });
    }
}
