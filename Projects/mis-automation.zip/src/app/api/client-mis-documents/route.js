import { NextResponse } from 'next/server'
import { executeQuery } from '@/lib/db'
import { verifyAnyToken } from '@/lib/jwt'
import { v4 as uuidv4 } from 'uuid'

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  return { isValid: true, authResult };
}

// Helper function to validate userId parameter
function validateUserId(userId) {
  if (!userId) return { isValid: true };
  
  if (typeof userId !== 'string' || userId.length > 100) {
    return { isValid: false, error: 'Invalid userId format or length' };
  }
  
  const sanitized = userId.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedUserId: sanitized };
}

// Helper function to validate clientId parameter
function validateClientId(clientId) {
  if (!clientId) return { isValid: true };
  
  if (typeof clientId !== 'string' || clientId.length > 100) {
    return { isValid: false, error: 'Invalid clientId format or length' };
  }
  
  const sanitized = clientId.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedClientId: sanitized };
}

// Helper function to validate templateId parameter
function validateTemplateId(templateId) {
  if (!templateId) return { isValid: true };
  
  if (typeof templateId !== 'string' || templateId.length > 100) {
    return { isValid: false, error: 'Invalid templateId format or length' };
  }
  
  const sanitized = templateId.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedTemplateId: sanitized };
}

// Helper function to validate status parameter
function validateStatus(status) {
  if (!status) return { isValid: true };
  
  const validStatuses = ['Draft', 'In Progress', 'Review', 'Approved', 'Rejected'];
  if (typeof status !== 'string' || !validStatuses.includes(status)) {
    return { isValid: false, error: 'Invalid status value' };
  }
  
  return { isValid: true, sanitizedStatus: status.trim() };
}

// Helper function to build select query
function buildSelectQuery(sanitizedUserId, sanitizedClientId, sanitizedTemplateId, sanitizedStatus) {
  let query = `
    SELECT 
      ID, SSO_CLIENT_ID, SSO_CLIENT_NAME, TEMPLATE_ID, TEMPLATE_NAME,
      USER_ID, MIS_DOCUMENT_NAME, HTML_TEMPLATE, STATUS, CREATED_AT, 
      UPDATED_AT, CREATED_BY, CREATED_BY_EMAIL, CREATED_BY_ROLE, 
      BANNER_URL, THEME_COLORS, DYNAMIC_ELEMENTS, 
      GENERATED_INFOGRAPHICS, 
      REVIEWED_AT, REVIEW_COMMENT
    FROM CLIENT_MIS_DOCUMENTS 
    WHERE IS_ACTIVE = 1
  `;
  
  const queryParams = [];

  if (sanitizedUserId) {
    query += ' AND USER_ID = :' + (queryParams.length + 1);
    queryParams.push(sanitizedUserId);
  }

  if (sanitizedClientId) {
    query += ' AND SSO_CLIENT_ID = :' + (queryParams.length + 1);
    queryParams.push(sanitizedClientId);
  }

  if (sanitizedTemplateId) {
    query += ' AND TEMPLATE_ID = :' + (queryParams.length + 1);
    queryParams.push(sanitizedTemplateId);
  }

  if (sanitizedStatus) {
    query += ' AND STATUS = :' + (queryParams.length + 1);
    queryParams.push(sanitizedStatus);
  }

  query += ' ORDER BY CREATED_AT DESC';
  
  return { query, queryParams };
}

// Helper function to convert CLOB to string safely
async function clobToString(clobValue) {
  if (!clobValue) return null;
  
  try {
    // If it's already a string, return it
    if (typeof clobValue === 'string') {
      return clobValue;
    }
    
    // If it's a CLOB object, convert it to string
    if (clobValue && typeof clobValue.getData === 'function') {
      return await clobValue.getData();
    }
    
    // If it's an object with toString method, try to get the string value
    if (clobValue && typeof clobValue === 'object' && clobValue.toString) {
      const stringValue = clobValue.toString();
      // Only return if it's not the default object string representation
      if (stringValue !== '[object Object]') {
        return stringValue;
      }
    }
    
    // If it's null or undefined, return null
    return null;
  } catch (error) {
    console.warn('Error converting CLOB to string:', error);
    return null;
  }
}

// Helper function to parse JSON field safely
function parseJsonField(fieldValue, fieldName, documentId) {
  if (!fieldValue) return null;
  
  try {
    return JSON.parse(fieldValue);
  } catch (e) {
    console.warn(`Failed to parse ${fieldName} for document:`, documentId);
    return null;
  }
}

// Helper function to process document data
async function processDocumentData(doc) {
  // Convert CLOB fields to strings
  const htmlTemplate = await clobToString(doc.HTML_TEMPLATE);
  const themeColorsClob = await clobToString(doc.THEME_COLORS);
  const dynamicElementsClob = await clobToString(doc.DYNAMIC_ELEMENTS);
  const generatedInfographicsClob = await clobToString(doc.GENERATED_INFOGRAPHICS);
  const reviewCommentClob = await clobToString(doc.REVIEW_COMMENT);
  
  // Parse JSON fields
  const themeColors = parseJsonField(themeColorsClob, 'THEME_COLORS', doc.ID);
  const dynamicElements = parseJsonField(dynamicElementsClob, 'DYNAMIC_ELEMENTS', doc.ID);
  const generatedInfographics = parseJsonField(generatedInfographicsClob, 'GENERATED_INFOGRAPHICS', doc.ID);

  return {
    ID: doc.ID,
    SSO_CLIENT_ID: doc.SSO_CLIENT_ID,
    SSO_CLIENT_NAME: doc.SSO_CLIENT_NAME,
    TEMPLATE_ID: doc.TEMPLATE_ID,
    TEMPLATE_NAME: doc.TEMPLATE_NAME,
    USER_ID: doc.USER_ID,
    MIS_DOCUMENT_NAME: doc.MIS_DOCUMENT_NAME,
    HTML_TEMPLATE: htmlTemplate,
    STATUS: doc.STATUS,
    CREATED_AT: doc.CREATED_AT,
    UPDATED_AT: doc.UPDATED_AT,
    CREATED_BY: doc.CREATED_BY,
    CREATED_BY_EMAIL: doc.CREATED_BY_EMAIL,
    CREATED_BY_ROLE: doc.CREATED_BY_ROLE,
    BANNER_URL: doc.BANNER_URL,
    THEME_COLORS: themeColors,
    DYNAMIC_ELEMENTS: dynamicElements,
    GENERATED_INFOGRAPHICS: generatedInfographics,
    REVIEWED_AT: doc.REVIEWED_AT,
    REVIEW_COMMENT: reviewCommentClob
  };
}

// Helper function to validate required fields for POST
function validateRequiredFields(body) {
  const { sso_client_id, template_id, user_id, mis_document_name } = body;
  
  if (!sso_client_id || !template_id || !user_id || !mis_document_name) {
    return { isValid: false, error: 'Missing required fields' };
  }
  
  return { isValid: true };
}

// Helper function to check for duplicate documents
async function checkDuplicateDocument(templateId, misDocumentName) {
  const checkQuery = `
    SELECT COUNT(*) as count 
    FROM CLIENT_MIS_DOCUMENTS 
    WHERE TEMPLATE_ID = :1 AND MIS_DOCUMENT_NAME = :2 AND IS_ACTIVE = 1
  `;
  
  const checkResult = await executeQuery(checkQuery, [templateId, misDocumentName]);
  
  if (checkResult.rows && checkResult.rows[0] && checkResult.rows[0].COUNT > 0) {
    return { isDuplicate: true };
  }
  
  return { isDuplicate: false };
}

// Helper function to prepare insert parameters
function prepareInsertParams(body, documentId) {
  const {
    sso_client_id,
    sso_client_name,
    template_id,
    template_name,
    user_id,
    mis_document_name,
    html_template,
    status = 'Draft',
    banner_url,
    theme_colors,
    dynamic_elements,
    created_by,
    created_by_email,
    created_by_role
  } = body;

  // Ensure CLOB fields are properly handled as strings
  const htmlTemplateValue = typeof html_template === 'string' ? html_template : (html_template || '');
  const themeColorsValue = typeof theme_colors === 'string' ? theme_colors : JSON.stringify(theme_colors || []);
  const dynamicElementsValue = typeof dynamic_elements === 'string' ? dynamic_elements : JSON.stringify(dynamic_elements || []);

  return {
    documentId,
    insertParams: [
      documentId,
      sso_client_id,
      sso_client_name || '',
      template_id,
      template_name || '',
      user_id,
      mis_document_name,
      htmlTemplateValue,
      status,
      created_by || '',
      created_by_email || '',
      created_by_role || '',
      banner_url || '',
      themeColorsValue,
      dynamicElementsValue
    ],
    debugInfo: {
      documentId,
      sso_client_id,
      template_id,
      mis_document_name,
      htmlTemplateLength: htmlTemplateValue.length,
      themeColorsLength: themeColorsValue.length,
      dynamicElementsLength: dynamicElementsValue.length,
      htmlTemplateType: typeof htmlTemplateValue,
      themeColorsType: typeof themeColorsValue,
      dynamicElementsType: typeof dynamicElementsValue
    }
  };
}

// Helper function to build insert query
function buildInsertQuery() {
  return `
    INSERT INTO CLIENT_MIS_DOCUMENTS (
      ID, SSO_CLIENT_ID, SSO_CLIENT_NAME, TEMPLATE_ID, TEMPLATE_NAME,
      USER_ID, MIS_DOCUMENT_NAME, HTML_TEMPLATE, STATUS, CREATED_AT, 
      UPDATED_AT, CREATED_BY, CREATED_BY_EMAIL, CREATED_BY_ROLE, 
      BANNER_URL, THEME_COLORS, DYNAMIC_ELEMENTS, IS_ACTIVE
    ) VALUES (
      :1, :2, :3, :4, :5, :6, :7, :8, :9, CURRENT_TIMESTAMP, 
      CURRENT_TIMESTAMP, :10, :11, :12, :13, :14, :15, 1
    )
  `;
}

// Helper function to build fetch query
function buildFetchQuery() {
  return `
    SELECT 
      ID, SSO_CLIENT_ID, SSO_CLIENT_NAME, TEMPLATE_ID, TEMPLATE_NAME,
      USER_ID, MIS_DOCUMENT_NAME, HTML_TEMPLATE, STATUS, CREATED_AT, 
      UPDATED_AT, CREATED_BY, CREATED_BY_EMAIL, CREATED_BY_ROLE, 
      BANNER_URL, THEME_COLORS, DYNAMIC_ELEMENTS, 
      GENERATED_INFOGRAPHICS, 
      REVIEWED_AT, REVIEW_COMMENT
    FROM CLIENT_MIS_DOCUMENTS 
    WHERE ID = :1
  `;
}

// GET - Fetch all documents or filter by user/client
export async function GET(request) {
  try {
    // Extract query parameters
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const clientId = searchParams.get('clientId');
    const templateId = searchParams.get('templateId');
    const status = searchParams.get('status');

    // Validate parameters
    const userIdValidation = validateUserId(userId);
    if (!userIdValidation.isValid) {
      return NextResponse.json({ error: userIdValidation.error }, { status: 400 });
    }

    const clientIdValidation = validateClientId(clientId);
    if (!clientIdValidation.isValid) {
      return NextResponse.json({ error: clientIdValidation.error }, { status: 400 });
    }

    const templateIdValidation = validateTemplateId(templateId);
    if (!templateIdValidation.isValid) {
      return NextResponse.json({ error: templateIdValidation.error }, { status: 400 });
    }

    const statusValidation = validateStatus(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Build and execute query
    const { query, queryParams } = buildSelectQuery(
      userIdValidation.sanitizedUserId,
      clientIdValidation.sanitizedClientId,
      templateIdValidation.sanitizedTemplateId,
      statusValidation.sanitizedStatus
    );

    const result = await executeQuery(query, queryParams);

    // Process documents
    const documents = await Promise.all((result.rows || []).map(processDocumentData));

    return NextResponse.json({
      success: true,
      documents: documents
    });

  } catch (error) {
    console.error('Database error while fetching documents:', error);
    return NextResponse.json({ error: 'Database error while fetching documents' }, { status: 500 });
  }
}

// POST - Create new document
export async function POST(request) {
  try {
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const body = await request.json();

    // Validate required fields
    const requiredFieldsValidation = validateRequiredFields(body);
    if (!requiredFieldsValidation.isValid) {
      return NextResponse.json({ error: requiredFieldsValidation.error }, { status: 400 });
    }

    // Check for duplicate document
    const duplicateCheck = await checkDuplicateDocument(body.template_id, body.mis_document_name);
    if (duplicateCheck.isDuplicate) {
      return NextResponse.json({
        error: 'A document for this template and period already exists',
        code: 'DUPLICATE_DOCUMENT'
      }, { status: 409 });
    }

    // Generate unique ID and prepare parameters
    const documentId = uuidv4();
    const { insertParams, debugInfo } = prepareInsertParams(body, documentId);

    console.log('📄 Insert params:', debugInfo);

    // Insert new document
    const insertQuery = buildInsertQuery();
    await executeQuery(insertQuery, insertParams);

    // Fetch the created document
    const fetchQuery = buildFetchQuery();
    const fetchResult = await executeQuery(fetchQuery, [documentId]);

    // Process the document data
    let document = null;
    if (fetchResult.rows && fetchResult.rows[0]) {
      document = await processDocumentData(fetchResult.rows[0]);
    }

    return NextResponse.json({
      success: true,
      message: 'Document created successfully',
      document: document
    });

  } catch (error) {
    console.error('Database error while creating document:', error);
    return NextResponse.json({ error: 'Database error while creating document' }, { status: 500 });
  }
}
