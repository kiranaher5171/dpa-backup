import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to check if user has access to a template
function checkUserAccess(accessNames, userName) {
  if (!accessNames || !userName) return false;
  
  const names = accessNames.split(',').map(name => name.trim()).filter(name => name);
  return names.includes(userName);
}

// Helper function to convert CLOB to string safely
async function clobToString(clobValue) {
  if (!clobValue) return null;
  
  try {
    // If it's already a string, return it
    if (typeof clobValue === 'string') {
      return clobValue;
    }
    
    // If it's a CLOB object, convert it to string
    if (clobValue && typeof clobValue.getData === 'function') {
      return await clobValue.getData();
    }
    
    // If it's an object with toString method, try to get the string value
    if (clobValue && typeof clobValue === 'object' && clobValue.toString) {
      const stringValue = clobValue.toString();
      // Only return if it's not the default object string representation
      if (stringValue !== '[object Object]') {
        return stringValue;
      }
    }
    
    // If it's null or undefined, return null
    return null;
  } catch (error) {
    console.warn('Error converting CLOB to string:', error);
    return null;
  }
}

// Helper function to parse JSON fields safely
function parseJsonField(value, fieldName) {
  if (!value || typeof value !== 'string') {
    return value;
  }
  
  try {
    const parsed = JSON.parse(value);
    return parsed;
  } catch (error) {
    console.warn(`⚠️ Failed to parse ${fieldName} as JSON:`, error.message);
    return value; // Return original value if parsing fails
  }
}

// Helper function to handle object values and avoid circular references
async function handleObjectValue(value, key) {
  if (!value || typeof value !== 'object') {
    return value;
  }
  
  // Check for circular references
  try {
    JSON.stringify(value);
    return value;
  } catch (error) {
    console.warn(`⚠️ Circular reference detected in ${key}, skipping field`);
    return null;
  }
}

// Helper function to clean row data
async function cleanRowData(row) {
  const cleanRow = {};
  
  for (const [key, value] of Object.entries(row)) {
    if (key === 'THEME_COLORS' && value) {
      console.log('🎨 Processing THEME_COLORS for document:', row.MIS_DOCUMENT_NAME);
      console.log('🎨 Raw THEME_COLORS value:', value);
      console.log('🎨 THEME_COLORS type:', typeof value);
      console.log('🎨 THEME_COLORS constructor:', value?.constructor?.name);
      
      const themeColorsString = await clobToString(value);
      console.log('🎨 CLOB converted to string:', themeColorsString);
      
      const parsed = parseJsonField(themeColorsString, 'THEME_COLORS');
      console.log('🎨 Parsed THEME_COLORS:', parsed);
      cleanRow[key] = parsed;
    } else if (key === 'TEMPLATE_DATA' && value) {
      const templateDataString = await clobToString(value);
      cleanRow[key] = parseJsonField(templateDataString, 'TEMPLATE_DATA') || templateDataString;
    } else if (value && typeof value === 'object') {
      const processedValue = await handleObjectValue(value, key);
      if (processedValue !== null) {
        cleanRow[key] = processedValue;
      }
    } else {
      cleanRow[key] = value;
    }
  }
  
  return cleanRow;
}

// Helper function to clean all rows
async function cleanRows(rows) {
  return await Promise.all(rows.map(cleanRowData));
}

export async function POST(request) {
  try {
    console.log('📋 Fetching documents created from user-accessible templates...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const { authResult } = authValidation;
    
    // Get user name from request body
    let userName = '';
    try {
      const body = await request.json();
      userName = body.userName || body.fullName || body.employeeName || body.name || '';
      console.log('🔍 User name from request body:', userName);
    } catch (e) {
      console.log('🔍 Could not parse request body');
    }
    
    // If no userName from body, try to get from auth result
    if (!userName) {
      userName = authResult.fullName || authResult.userId || authResult.employeeName || authResult.name || '';
      console.log('🔍 User name from auth result:', userName);
    }
    
    if (!userName) {
      return NextResponse.json({
        error: 'User name not found. Please provide userName in request body.'
      }, { status: 400 });
    }

    // First, get all templates that the user has access to
    const templatesQuery = `
      SELECT 
        TEMPLATE_NAME,
        TEMPLATE_ACCESS_EMP_NAMES
      FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
      WHERE IS_ACTIVE = 1
    `;

    console.log('🔍 Fetching user-accessible templates...');
    const templatesResult = await executeQuery(templatesQuery, []);
    
    // Filter templates that user has access to
    const accessibleTemplates = templatesResult.rows.filter(template => 
      checkUserAccess(template.TEMPLATE_ACCESS_EMP_NAMES, userName)
    );
    
    const accessibleTemplateNames = accessibleTemplates.map(t => t.TEMPLATE_NAME);
    console.log(`📊 Found ${accessibleTemplateNames.length} accessible templates:`, accessibleTemplateNames);

    if (accessibleTemplateNames.length === 0) {
      return NextResponse.json({
        success: true,
        documents: [],
        totalDocuments: 0,
        accessibleTemplates: 0,
        userName: userName
      });
    }

    // Now fetch documents created using these templates
    const documentsQuery = `
      SELECT 
        ID,
        SSO_CLIENT_NAME,
        TEMPLATE_NAME,
        MIS_DOCUMENT_NAME,
        STATUS,
        CREATED_AT,
        UPDATED_AT,
        CREATED_BY,
        CREATED_BY_EMAIL,
        IS_ACTIVE,
        BANNER_URL,
        THEME_COLORS
      FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_DOCUMENTS 
      WHERE IS_ACTIVE = 1 
      AND TEMPLATE_NAME IN (${accessibleTemplateNames.map((_, index) => `:${index + 1}`).join(', ')})
      ORDER BY CREATED_AT DESC
    `;

    console.log('🔍 Fetching documents from accessible templates...');
    const documentsResult = await executeQuery(documentsQuery, accessibleTemplateNames);
    
    console.log(`📊 Fetched ${documentsResult.rows.length} documents`);

    // Clean the rows to handle Oracle-specific objects
    const cleanedDocuments = await cleanRows(documentsResult.rows);
    console.log(`📊 Cleaned ${cleanedDocuments.length} documents`);

    // Add template access info to each document
    const documentsWithAccess = cleanedDocuments.map(document => {
      const template = accessibleTemplates.find(t => t.TEMPLATE_NAME === document.TEMPLATE_NAME);
      return {
        ...document,
        TEMPLATE_ACCESS_NAMES: template?.TEMPLATE_ACCESS_EMP_NAMES || '',
        USER_HAS_TEMPLATE_ACCESS: true
      };
    });

    console.log(`✅ Found ${documentsWithAccess.length} documents created from user-accessible templates`);

    return NextResponse.json({
      success: true,
      documents: documentsWithAccess,
      totalDocuments: documentsWithAccess.length,
      accessibleTemplates: accessibleTemplateNames.length,
      userName: userName
    });

  } catch (error) {
    console.error('❌ Error fetching user-accessible documents:', error);
    return NextResponse.json({
      error: 'Failed to fetch user-accessible documents',
      details: error.message
    }, { status: 500 });
  }
}

export async function GET(request) {
  return POST(request);
}
