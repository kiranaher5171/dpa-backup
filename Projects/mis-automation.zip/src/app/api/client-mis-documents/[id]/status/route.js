import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';
import { verifyAnyToken } from '@/lib/jwt';

export const dynamic = 'force-dynamic';

// PUT - Update document status
export async function PUT(request, { params }) {
  try {
    // Await params for Next.js 15 compatibility
    const { id } = await params;
    console.log('📝 Updating status for client MIS document:', id);
    
    // Verify authentication
    const authResult = await verifyAnyToken(request);
    console.log('🔐 Auth result:', authResult);
    if (!authResult.isValid) {
      console.log('❌ Authentication failed');
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    console.log('✅ Authentication successful');
    const body = await request.json();
    console.log('📄 Request body:', body);
    const { status } = body;

    if (!status) {
      return NextResponse.json({ error: 'Status is required' }, { status: 400 });
    }

    // Check if the ID looks like a UUID (36 characters) or a document name
    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
    console.log('🔍 Is UUID format:', isUUID);
    
    let updateQuery, updateParams;
    
    if (isUUID) {
      // Update by document ID (UUID)
      updateQuery = `
        UPDATE CLIENT_MIS_DOCUMENTS 
        SET STATUS = :1, 
            UPDATED_AT = SYSTIMESTAMP
        WHERE ID = :2
      `;
      updateParams = [status, id];
    } else {
      // Update by document name
      updateQuery = `
        UPDATE CLIENT_MIS_DOCUMENTS 
        SET STATUS = :1, 
            UPDATED_AT = SYSTIMESTAMP
        WHERE MIS_DOCUMENT_NAME = :2
      `;
      updateParams = [status, id];
    }

    console.log('📊 Executing query:', updateQuery);
    console.log('📊 Query params:', updateParams);
    
    const queryResult = await executeQuery(updateQuery, updateParams);
    console.log('📊 Query result:', queryResult);

    console.log(`✅ Updated status for client MIS document: ${id} to ${status}`);
    
    const responseData = { 
      success: true, 
      message: 'Status updated successfully',
      status: status
    };
    
    console.log('📤 Sending response:', responseData);
    const response = NextResponse.json(responseData);
    console.log('📤 Response object created:', {
      status: response.status,
      headers: Object.fromEntries(response.headers.entries())
    });
    
    return response;

  } catch (error) {
    console.error('❌ Error updating status:', error);
    return NextResponse.json({ 
      error: 'Failed to update status',
      details: error.message 
    }, { status: 500 });
  }
}
