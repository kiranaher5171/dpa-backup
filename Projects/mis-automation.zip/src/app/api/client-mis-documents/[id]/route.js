import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';
import { verifyAnyToken } from '@/lib/jwt';

export const dynamic = 'force-dynamic';

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Authentication required' };
  }
  return { isValid: true, userId: authResult.user.userId };
}

// Helper function to check if ID is UUID
function isUUID(id) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
}

// Helper function to build select query
function buildSelectQuery(id) {
  const isUUIDFormat = isUUID(id);
  const query = `
    SELECT 
      ID,
      SSO_CLIENT_ID,
      SSO_CLIENT_NAME,
      TEMPLATE_ID,
      TEMPLATE_NAME,
      USER_ID,
      MIS_DOCUMENT_NAME,
      HTML_TEMPLATE,
      STATUS,
      CREATED_AT,
      UPDATED_AT,
      CREATED_BY,
      CREATED_BY_EMAIL,
      CREATED_BY_ROLE,
      BANNER_URL,
      THEME_COLORS,
      DYNAMIC_ELEMENTS,
      GENERATED_INFOGRAPHICS,
      REVIEWED_AT,
      REVIEW_COMMENT,
      IS_ACTIVE
    FROM CLIENT_MIS_DOCUMENTS
    WHERE ${isUUIDFormat ? 'ID' : 'MIS_DOCUMENT_NAME'} = :1
      AND IS_ACTIVE = 1
  `;
  return { query, queryParams: [id], isUUIDFormat };
}

// Helper function to convert CLOB to string safely
async function clobToString(clobValue) {
  if (!clobValue) return null;
  
  try {
    // If it's already a string, return it
    if (typeof clobValue === 'string') {
      return clobValue;
    }
    
    // If it's a CLOB object, convert it to string
    if (clobValue && typeof clobValue.getData === 'function') {
      return await clobValue.getData();
    }
    
    // If it's an object with toString method, try to get the string value
    if (clobValue && typeof clobValue === 'object' && clobValue.toString) {
      const stringValue = clobValue.toString();
      // Only return if it's not the default object string representation
      if (stringValue !== '[object Object]') {
        return stringValue;
      }
    }
    
    // If it's null or undefined, return null
    return null;
  } catch (error) {
    console.warn('Error converting CLOB to string:', error);
    return null;
  }
}

// Helper function to parse JSON fields safely
function parseJsonField(fieldValue, fieldName) {
  if (!fieldValue) return [];
  
  try {
    return JSON.parse(fieldValue);
  } catch (e) {
    console.warn(`Failed to parse ${fieldName} as JSON:`, e.message);
    return [];
  }
}

// Helper function to build document object
async function buildDocumentObject(rawDoc) {
  // Convert CLOB fields to strings
  const htmlTemplate = await clobToString(rawDoc.HTML_TEMPLATE);
  const themeColorsClob = await clobToString(rawDoc.THEME_COLORS);
  const dynamicElementsClob = await clobToString(rawDoc.DYNAMIC_ELEMENTS);
  const generatedInfographicsClob = await clobToString(rawDoc.GENERATED_INFOGRAPHICS);
  const reviewCommentClob = await clobToString(rawDoc.REVIEW_COMMENT);
  
  // Parse JSON fields
  const themeColors = parseJsonField(themeColorsClob, 'THEME_COLORS');
  const dynamicElements = parseJsonField(dynamicElementsClob, 'DYNAMIC_ELEMENTS');
  const generatedInfographics = parseJsonField(generatedInfographicsClob, 'GENERATED_INFOGRAPHICS');

  return {
    ID: rawDoc.ID,
    SSO_CLIENT_ID: rawDoc.SSO_CLIENT_ID,
    SSO_CLIENT_NAME: rawDoc.SSO_CLIENT_NAME,
    TEMPLATE_ID: rawDoc.TEMPLATE_ID,
    TEMPLATE_NAME: rawDoc.TEMPLATE_NAME,
    USER_ID: rawDoc.USER_ID,
    MIS_DOCUMENT_NAME: rawDoc.MIS_DOCUMENT_NAME,
    HTML_TEMPLATE: htmlTemplate,
    STATUS: rawDoc.STATUS,
    CREATED_AT: rawDoc.CREATED_AT,
    UPDATED_AT: rawDoc.UPDATED_AT,
    CREATED_BY: rawDoc.CREATED_BY,
    CREATED_BY_EMAIL: rawDoc.CREATED_BY_EMAIL,
    CREATED_BY_ROLE: rawDoc.CREATED_BY_ROLE,
    BANNER_URL: rawDoc.BANNER_URL,
    THEME_COLORS: themeColors,
    DYNAMIC_ELEMENTS: dynamicElements,
    GENERATED_INFOGRAPHICS: generatedInfographics,
    REVIEWED_AT: rawDoc.REVIEWED_AT,
    REVIEW_COMMENT: reviewCommentClob,
    IS_ACTIVE: rawDoc.IS_ACTIVE
  };
}

// Helper function to check document existence
async function checkDocumentExists(id) {
  const isUUIDFormat = isUUID(id);
  const checkQuery = `
    SELECT ID FROM CLIENT_MIS_DOCUMENTS 
    WHERE ${isUUIDFormat ? 'ID' : 'MIS_DOCUMENT_NAME'} = :1 AND IS_ACTIVE = 1
  `;
  const checkResult = await executeQuery(checkQuery, [id]);
  return checkResult.rows.length > 0;
}

// Helper function to build update query
function buildUpdateQuery(id, updateFields) {
  const isUUIDFormat = isUUID(id);
  let updateQuery = 'UPDATE CLIENT_MIS_DOCUMENTS SET UPDATED_AT = SYSTIMESTAMP';
  const updateParams = [];
  let paramIndex = 1;

  const fieldMappings = {
    misDocumentName: 'MIS_DOCUMENT_NAME',
    htmlTemplate: 'HTML_TEMPLATE',
    status: 'STATUS',
    bannerUrl: 'BANNER_URL',
    themeColors: 'THEME_COLORS',
    dynamicElements: 'DYNAMIC_ELEMENTS',
    generatedInfographics: 'GENERATED_INFOGRAPHICS',
    reviewComment: 'REVIEW_COMMENT'
  };

  Object.entries(updateFields).forEach(([key, value]) => {
    if (value !== undefined) {
      const fieldName = fieldMappings[key];
      if (fieldName) {
        updateQuery += `, ${fieldName} = :${paramIndex}`;
        
        // Handle JSON fields
        if (['themeColors', 'dynamicElements', 'generatedInfographics'].includes(key)) {
          updateParams.push(JSON.stringify(value));
        } else if (key === 'reviewComment') {
          updateQuery += ', REVIEWED_AT = SYSTIMESTAMP';
          updateParams.push(value);
        } else {
          updateParams.push(value);
        }
        
        paramIndex++;
      }
    }
  });

  updateQuery += ` WHERE ${isUUIDFormat ? 'ID' : 'MIS_DOCUMENT_NAME'} = :${paramIndex}`;
  updateParams.push(id);

  return { updateQuery, updateParams };
}

// Helper function to build delete query
function buildDeleteQuery(id, userId) {
  const isUUIDFormat = isUUID(id);
  const deleteQuery = `
    UPDATE CLIENT_MIS_DOCUMENTS 
    SET IS_ACTIVE = 0, UPDATED_AT = SYSTIMESTAMP
    WHERE ${isUUIDFormat ? 'ID' : 'MIS_DOCUMENT_NAME'} = :1 AND USER_ID = :2
  `;
  return { deleteQuery, deleteParams: [id, userId] };
}

// GET - Fetch specific client MIS document
export async function GET(request, { params }) {
  try {
    const { id } = await params;
    console.log('🔍 Fetching client MIS document:', id);
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Build and execute query
    const { query, queryParams, isUUIDFormat } = buildSelectQuery(id);
    console.log('🔍 Is UUID format:', isUUIDFormat);
    console.log('🔍 Document ID:', id);
    
    const result = await executeQuery(query, queryParams);

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    const document = await buildDocumentObject(result.rows[0]);
    console.log(`✅ Found client MIS document: ${document.ID}`);
    
    return NextResponse.json({ 
      success: true, 
      document 
    });

  } catch (error) {
    console.error('❌ Error fetching client MIS document:', error);
    return NextResponse.json({ 
      error: 'Failed to fetch client MIS document',
      details: error.message 
    }, { status: 500 });
  }
}

// PUT - Update client MIS document
export async function PUT(request, { params }) {
  try {
    const { id } = await params;
    console.log('📝 Updating client MIS document:', id);
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const body = await request.json();
    console.log('📄 PUT request body received:', body);
    
    const {
      misDocumentName,
      htmlTemplate,
      status,
      bannerUrl,
      themeColors,
      dynamicElements,
      generatedInfographics,
      reviewComment
    } = body;
    
    console.log('📊 Extracted fields:', {
      hasHtmlTemplate: htmlTemplate !== undefined,
      htmlTemplateLength: htmlTemplate ? htmlTemplate.length : 0,
      hasDynamicElements: dynamicElements !== undefined,
      dynamicElementsCount: dynamicElements ? dynamicElements.length : 0,
      status: status
    });

    // Check document existence
    const documentExists = await checkDocumentExists(id);
    if (!documentExists) {
      console.log('❌ Document not found in database');
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }
    
    console.log('✅ Document found in database, proceeding with update');

    // Build and execute update query
    const updateFields = {
      misDocumentName,
      htmlTemplate,
      status,
      bannerUrl,
      themeColors,
      dynamicElements,
      generatedInfographics,
      reviewComment
    };

    const { updateQuery, updateParams } = buildUpdateQuery(id, updateFields);
    
    console.log('📊 Final update query:', updateQuery);
    console.log('📊 Update parameters:', updateParams);
    
    const updateResult = await executeQuery(updateQuery, updateParams);
    console.log('📊 Update result:', updateResult);

    if (updateResult.rowsAffected === 0) {
      console.log('❌ No rows were updated - this might indicate an issue with the WHERE clause');
      return NextResponse.json({ 
        error: 'No rows were updated. Document might not exist or WHERE clause issue.',
        details: 'Update query executed but affected 0 rows'
      }, { status: 500 });
    }

    console.log(`✅ Updated client MIS document: ${id} (${updateResult.rowsAffected} rows affected)`);
    return NextResponse.json({ 
      success: true, 
      message: 'Client MIS document updated successfully',
      rowsAffected: updateResult.rowsAffected
    });

  } catch (error) {
    console.error('❌ Error updating client MIS document:', error);
    return NextResponse.json({ 
      error: 'Failed to update client MIS document',
      details: error.message 
    }, { status: 500 });
  }
}

// DELETE - Soft delete client MIS document
export async function DELETE(request, { params }) {
  try {
    const { id } = await params;
    console.log('🗑️ Deleting client MIS document:', id);
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Build and execute delete query
    const { deleteQuery, deleteParams } = buildDeleteQuery(id, authValidation.userId);
    const result = await executeQuery(deleteQuery, deleteParams);

    if (result.rowsAffected === 0) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    console.log(`✅ Deleted client MIS document: ${id}`);
    return NextResponse.json({ 
      success: true, 
      message: 'Client MIS document deleted successfully' 
    });

  } catch (error) {
    console.error('❌ Error deleting client MIS document:', error);
    return NextResponse.json({ 
      error: 'Failed to delete client MIS document',
      details: error.message 
    }, { status: 500 });
  }
}
