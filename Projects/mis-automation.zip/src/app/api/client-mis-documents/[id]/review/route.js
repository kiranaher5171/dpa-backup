import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db';
import { sendReviewActionEmail, sendCleanContentEmail } from '@/lib/emailService';
import { verifyAnyToken } from '@/lib/jwt';

export const dynamic = 'force-dynamic';

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    console.log('🔐 Auth Debug - Authentication failed:', authResult.error);
    return { isValid: false, error: authResult.error };
  }
  console.log('🔐 Auth Debug - Authentication successful with SSO token');
  return { isValid: true };
}

// Helper function to validate review action
function validateReviewAction(action) {
  if (!action || !['approve', 'reject'].includes(action)) {
    return { isValid: false, error: 'Invalid action. Must be "approve" or "reject"' };
  }
  return { isValid: true, status: action === 'approve' ? 'Approved' : 'Rejected' };
}

// Helper function to check if ID is UUID
function isUUID(id) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
}

// Helper function to build update query
function buildUpdateQuery(id, reviewComment, status) {
  const isUUIDFormat = isUUID(id);
  const updateQuery = `
    UPDATE CLIENT_MIS_DOCUMENTS 
    SET REVIEW_COMMENT = :1, 
        REVIEWED_AT = SYSTIMESTAMP,
        STATUS = :2,
        UPDATED_AT = SYSTIMESTAMP
    WHERE ${isUUIDFormat ? 'ID' : 'MIS_DOCUMENT_NAME'} = :3
  `;
  const updateParams = [reviewComment || null, status, id];
  return { updateQuery, updateParams, isUUIDFormat };
}

// Helper function to convert CLOB to string safely
async function clobToString(clobValue) {
  if (!clobValue) return null;
  
  try {
    // If it's already a string, return it
    if (typeof clobValue === 'string') {
      return clobValue;
    }
    
    // If it's a CLOB object, convert it to string
    if (clobValue && typeof clobValue.getData === 'function') {
      return await clobValue.getData();
    }
    
    // If it's null or undefined, return null
    return null;
  } catch (error) {
    console.warn('Error converting CLOB to string:', error);
    return null;
  }
}

// Helper function to get document data
async function getDocumentData(id, isUUIDFormat) {
  const documentQuery = `
    SELECT 
      ID,
      MIS_DOCUMENT_NAME,
      CREATED_BY,
      CREATED_BY_EMAIL,
      CREATED_AT,
      HTML_TEMPLATE,
      STATUS,
      SSO_CLIENT_NAME as CLIENT_NAME
    FROM CLIENT_MIS_DOCUMENTS 
    WHERE ${isUUIDFormat ? 'ID' : 'MIS_DOCUMENT_NAME'} = :1
  `;
  const result = await executeQuery(documentQuery, [id]);
  
  // Convert CLOB to string if needed
  if (result.rows && result.rows.length > 0) {
    const row = result.rows[0];
    row.HTML_CONTENT = await clobToString(row.HTML_TEMPLATE);
  }
  
  return result;
}

// Helper function to validate email
function isValidEmail(email) {
  return email && email.includes('@');
}

// Helper function to send status notification email
async function sendStatusEmail(documentData, action, reviewComment, ccEmails) {
  try {
    console.log('📧 Sending review action email...');
    const result = await sendReviewActionEmail(
      documentData.CREATED_BY_EMAIL,
      documentData.MIS_DOCUMENT_NAME,
      action,
      documentData.HTML_CONTENT,
      reviewComment,
      ccEmails || []
    );
    console.log('✅ Status notification email sent successfully:', result);
    return { success: true, result };
  } catch (error) {
    console.error('❌ Status email failed:', error);
    return { success: false, error: error.message };
  }
}

// Helper function to send clean content email
async function sendCleanContentEmailIfApproved(documentData, ccEmails) {
  try {
    const result = await sendCleanContentEmail(
      documentData.CREATED_BY_EMAIL,
      documentData.MIS_DOCUMENT_NAME,
      documentData.HTML_CONTENT,
      ccEmails || []
    );
    console.log('✅ Clean content email sent successfully:', result);
    return { success: true, result };
  } catch (error) {
    console.error('❌ Clean content email failed:', error);
    return { success: false, error: error.message };
  }
}

// Helper function to handle email sending
async function handleEmailSending(documentData, action, reviewComment, ccEmails) {
  if (!isValidEmail(documentData.CREATED_BY_EMAIL)) {
    console.log('⚠️ No valid creator email found for notification');
    return { emailSent: false };
  }

  try {
    const statusEmailResult = await sendStatusEmail(documentData, action, reviewComment, ccEmails);

    let cleanEmailResult = null;
    if (action === 'approve') {
      cleanEmailResult = await sendCleanContentEmailIfApproved(documentData, ccEmails);
    }

    console.log('📧 Email summary:', {
      statusEmailSent: statusEmailResult.success,
      cleanEmailSent: action === 'approve' ? cleanEmailResult.success : false,
      totalEmails: action === 'approve' ? 2 : 1
    });

    return {
      emailSent: true,
      statusEmailResult: statusEmailResult.success ? statusEmailResult.result : null,
      cleanEmailResult: cleanEmailResult?.success ? cleanEmailResult.result : null,
      emailError: null
    };
  } catch (error) {
    console.error('❌ Email sending failed:', error);
    console.log('⚠️ Email failed but review action completed successfully');
    return {
      emailSent: false,
      emailError: error.message,
      statusEmailResult: null,
      cleanEmailResult: null
    };
  }
}

// POST - Handle review actions (approve/reject)
export async function POST(request, { params }) {
  try {
    const { id } = await params;
    console.log('📝 Processing review action for client MIS document:', id);

    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = await request.json();
    const { action, reviewComment, ccEmails } = body;
    console.log('📝 Review action details:', { action, reviewComment, ccEmails });

    // Validate action
    const actionValidation = validateReviewAction(action);
    if (!actionValidation.isValid) {
      return NextResponse.json({ error: actionValidation.error }, { status: 400 });
    }

    // Build and execute update query
    const { updateQuery, updateParams, isUUIDFormat } = buildUpdateQuery(id, reviewComment, actionValidation.status);
    const result = await executeQuery(updateQuery, updateParams);
    console.log('📊 Update result:', result);

    // Get document data and handle email sending
    const documentResult = await getDocumentData(id, isUUIDFormat);
    let emailResults = { emailSent: false, emailError: null, statusEmailResult: null, cleanEmailResult: null };

    if (documentResult.rows && documentResult.rows.length > 0) {
      const documentData = documentResult.rows[0];
      console.log('📄 Document data for email:', documentData);
      emailResults = await handleEmailSending(documentData, action, reviewComment, ccEmails);
    }

    console.log(`✅ Review action "${action}" completed for client MIS document: ${id}`);
    return NextResponse.json({
      success: true,
      message: `Document ${action === 'approve' ? 'approved' : 'rejected'} successfully`,
      status: actionValidation.status,
      action: action,
      emailSent: emailResults.emailSent,
      emailError: emailResults.emailError,
      statusEmailMessageId: emailResults.statusEmailResult?.messageId || null,
      cleanEmailMessageId: emailResults.cleanEmailResult?.messageId || null,
      cleanEmailSent: action === 'approve' ? !!emailResults.cleanEmailResult : false,
      documentStatus: actionValidation.status
    });

  } catch (error) {
    console.error('❌ Error processing review action:', error);
    return NextResponse.json({
      error: 'Failed to process review action',
      details: error.message
    }, { status: 500 });
  }
}

// PUT - Update review status and comment
export async function PUT(request, { params }) {
  try {
    const { id } = await params;
    console.log('📝 Updating review for client MIS document:', id);

    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = await request.json();
    const { reviewComment, status } = body;

    // Build and execute update query
    const { updateQuery, updateParams } = buildUpdateQuery(id, reviewComment, status || 'Reviewed');
    await executeQuery(updateQuery, updateParams);

    console.log(`✅ Updated review for client MIS document: ${id}`);
    return NextResponse.json({
      success: true,
      message: 'Review updated successfully'
    });

  } catch (error) {
    console.error('❌ Error updating review:', error);
    return NextResponse.json({
      error: 'Failed to update review',
      details: error.message
    }, { status: 500 });
  }
}
