import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful for GET, user:', authResult.userId);
  return { isValid: true, userId: authResult.userId };
}

// Helper function to validate status parameter
function validateStatus(status) {
  if (!status) return { isValid: true };
  
  const validStatuses = ['Draft', 'In Progress', 'Review', 'Approved', 'Rejected'];
  if (typeof status !== 'string' || !validStatuses.includes(status)) {
    return { isValid: false, error: 'Invalid status value' };
  }
  return { isValid: true, sanitizedStatus: status.trim() };
}

// Helper function to validate ssoClientId parameter
function validateSsoClientId(ssoClientId) {
  if (!ssoClientId) return { isValid: true };
  
  if (typeof ssoClientId !== 'string' || ssoClientId.length > 100) {
    return { isValid: false, error: 'Invalid ssoClientId format or length' };
  }
  
  const sanitized = ssoClientId.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedSsoClientId: sanitized };
}

// Helper function to validate pagination parameters
function validatePagination(limit, offset) {
  const limitNum = parseInt(limit || '50');
  const offsetNum = parseInt(offset || '0');
  
  if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
    return { isValid: false, error: 'Invalid limit value. Must be between 1 and 100' };
  }
  
  if (isNaN(offsetNum) || offsetNum < 0) {
    return { isValid: false, error: 'Invalid offset value. Must be 0 or greater' };
  }
  
  return { isValid: true, limitNum, offsetNum };
}

// Helper function to build employee-specific query
function buildEmployeeQuery(userId, sanitizedStatus, sanitizedSsoClientId, limitNum, offsetNum) {
  let query = `
    SELECT 
      ID,
      SSO_CLIENT_NAME,
      TEMPLATE_NAME,
      MIS_DOCUMENT_NAME,
      STATUS,
      CREATED_AT,
      CREATED_BY,
      CREATED_BY_EMAIL,
      IS_ACTIVE
    FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_DOCUMENTS 
    WHERE IS_ACTIVE = 1 AND USER_ID = :1
  `;
  
  const queryParams = [userId];
  
  if (sanitizedStatus) {
    query += ' AND STATUS = :' + (queryParams.length + 1);
    queryParams.push(sanitizedStatus);
  }
  
  if (sanitizedSsoClientId) {
    query += ' AND SSO_CLIENT_ID = :' + (queryParams.length + 1);
    queryParams.push(sanitizedSsoClientId);
  }
  
  query += ' ORDER BY CREATED_AT DESC';
  query += ` OFFSET ${offsetNum} ROWS FETCH NEXT ${limitNum} ROWS ONLY`;
  
  return { query, queryParams };
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to clean row data
function cleanRowData(row) {
  const cleanRow = {};
  
  for (const [key, value] of Object.entries(row)) {
    if (value && typeof value === 'object') {
      const constructorName = value.constructor?.name;
      
      if (constructorName === 'Date') {
        cleanRow[key] = value.toISOString();
      } else if (constructorName === 'Buffer') {
        cleanRow[key] = value.toString('utf8');
      } else if (constructorName === 'ConnectDescription') {
        console.log(`⚠️ Skipping circular reference object for ${key}`);
        continue;
      } else {
        cleanRow[key] = value;
      }
    } else {
      cleanRow[key] = value;
    }
  }
  
  return cleanRow;
}

// Helper function to clean all rows
function cleanRows(rows) {
  return rows.map(cleanRowData);
}

// GET - Fetch employee specific client MIS documents
export async function GET(request) {
  try {
    console.log('🔍 Fetching employee specific client MIS documents...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const ssoClientId = searchParams.get('ssoClientId');
    const limit = searchParams.get('limit');
    const offset = searchParams.get('offset');

    // Validate parameters
    const statusValidation = validateStatus(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    const ssoClientIdValidation = validateSsoClientId(ssoClientId);
    if (!ssoClientIdValidation.isValid) {
      return NextResponse.json({ error: ssoClientIdValidation.error }, { status: 400 });
    }

    const paginationValidation = validatePagination(limit, offset);
    if (!paginationValidation.isValid) {
      return NextResponse.json({ error: paginationValidation.error }, { status: 400 });
    }

    // Build and execute query
    const { query, queryParams } = buildEmployeeQuery(
      authValidation.userId,
      statusValidation.sanitizedStatus,
      ssoClientIdValidation.sanitizedSsoClientId,
      paginationValidation.limitNum,
      paginationValidation.offsetNum
    );

    console.log('🔍 Executing query:', query);
    console.log('🔍 Query parameters:', queryParams);
    console.log('👤 Filtering documents for user:', authValidation.userId);

    const results = await executeQuery(query, queryParams);
    console.log('📊 Database query results:', results);

    // Extract and clean rows
    const rows = extractRows(results);
    const cleanedRows = cleanRows(rows);

    console.log(`✅ Found ${cleanedRows.length} employee-specific documents for user ${authValidation.userId} (optimized columns)`);
    return NextResponse.json({ 
      success: true, 
      documents: cleanedRows || [],
      total: cleanedRows.length,
      limit: paginationValidation.limitNum,
      offset: paginationValidation.offsetNum,
      userId: authValidation.userId,
      dataType: 'employee_specific'
    });

  } catch (error) {
    console.error('❌ Error fetching employee specific client MIS documents:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState
    });
    
    return NextResponse.json({ 
      error: 'Failed to fetch employee specific client MIS documents',
      details: error.message,
      code: error.code || 'UNKNOWN'
    }, { status: 500 });
  }
}
