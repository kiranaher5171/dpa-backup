import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import { determineRoleFromEmployeeCode } from '@/lib/roleUtils';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful for GET, user:', authResult.userId);
  return { isValid: true, authResult };
}


// Helper function to get employee details from API
async function getEmployeeDetailsFromAPI(accessToken) {
  const url = process.env.NEXT_PUBLIC_SSO_EMPLOYEE_DETAIL;
  const apiTag = process.env.NEXT_PUBLIC_EMPLOYEE_DETAILS_API_TAG || 'Employee Details API';

  console.log('🔐 API: Fetching employee details from:', url);

  if (!url) {
    throw new Error('Employee details API URL not configured');
  }

  const headers = {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json'
  };

  const response = await fetch(url, {
    method: 'GET',
    headers: headers
  });

  console.log(`🔐 API: Employee details response status:`, response.status);

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`🔐 API: Employee details failed:`, response.status, errorText);
    throw new Error(`${apiTag} failed: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log(`🔐 API: Employee details response:`, data);
  return data;
}

// Helper function to get employee details and determine role
async function getEmployeeDetailsAndRole(accessToken) {
  try {
    const data = await getEmployeeDetailsFromAPI(accessToken);
    // Database-based role checking - no environment variable fallback
    const role = 'user'; // Will be determined by database
    return { success: true, data, role };
  } catch (error) {
    console.error('🔐 API: Error fetching employee details:', error);
    return { success: false, error: error.message };
  }
}

// Helper function to extract access token from request
function extractAccessToken(request) {
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const accessToken = authHeader.substring(7);
    console.log('🔐 Using access token from Authorization header for employee details API');
    return accessToken;
  }
  return null;
}

// Helper function to determine user role and details
async function determineUserRoleAndDetails(authResult, request) {
  // Try to get employee_code from JWT token first (fast path)
  if (authResult.employee_code) {
    console.log('🚀 Fast path: Using employee_code from JWT token');
    const employeeCode = authResult.employee_code;
    const userRole = await determineRoleFromEmployeeCode(employeeCode);
    const employeeDetails = { employee_code: employeeCode };
    return { userRole, employeeDetails, employeeCode, performanceMode: 'fast_path' };
  }

  // Fallback: Get employee details from API (slower path)
  console.log('🔄 Fallback path: Fetching employee details from API');
  
  const accessToken = extractAccessToken(request);
  if (!accessToken) {
    throw new Error('No access token available for employee details API');
  }
  
  const employeeResult = await getEmployeeDetailsAndRole(accessToken);
  if (!employeeResult.success) {
    throw new Error(`Failed to get employee details: ${employeeResult.error}`);
  }
  
  return {
    userRole: employeeResult.role,
    employeeDetails: employeeResult.data,
    employeeCode: employeeResult.data.employee_code,
    performanceMode: 'fallback_path'
  };
}

// Helper function to validate status parameter
function validateStatus(status) {
  if (!status) return { isValid: true };
  
  const validStatuses = ['Draft', 'In Progress', 'Review', 'Approved', 'Rejected'];
  if (typeof status !== 'string' || !validStatuses.includes(status)) {
    return { isValid: false, error: 'Invalid status value' };
  }
  return { isValid: true, sanitizedStatus: status.trim() };
}

// Helper function to validate ssoClientId parameter
function validateSsoClientId(ssoClientId) {
  if (!ssoClientId) return { isValid: true };
  
  if (typeof ssoClientId !== 'string' || ssoClientId.length > 100) {
    return { isValid: false, error: 'Invalid ssoClientId format or length' };
  }
  
  const sanitized = ssoClientId.trim().replace(/[^a-zA-Z0-9\-_]/g, '');
  return { isValid: true, sanitizedSsoClientId: sanitized };
}

// Helper function to validate pagination parameters
function validatePagination(limit, offset) {
  const limitNum = parseInt(limit || '50');
  const offsetNum = parseInt(offset || '0');
  
  if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
    return { isValid: false, error: 'Invalid limit value. Must be between 1 and 100' };
  }
  
  if (isNaN(offsetNum) || offsetNum < 0) {
    return { isValid: false, error: 'Invalid offset value. Must be 0 or greater' };
  }
  
  return { isValid: true, limitNum, offsetNum };
}

// Helper function to build role-based query
function buildRoleBasedQuery(userRole, employeeCode, sanitizedStatus, sanitizedSsoClientId, limitNum, offsetNum) {
  let query = `
    SELECT 
      ID,
      SSO_CLIENT_NAME,
      TEMPLATE_NAME,
      MIS_DOCUMENT_NAME,
      STATUS,
      CREATED_AT,
      UPDATED_AT,
      IS_ACTIVE
  `;

  // Add admin-specific columns only for admin users
  if (userRole.toLowerCase() === 'admin') {
    query += `,
      CREATED_BY,
      CREATED_BY_EMAIL
    `;
  }

  query += `
    FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_DOCUMENTS 
    WHERE IS_ACTIVE = 1
  `;
  
  const queryParams = [];
  
  // Role-based filtering using USER_ID (which stores employee_code)
  if (userRole.toLowerCase() === 'user') {
    query += ` AND USER_ID = :1`;
    queryParams.push(employeeCode);
    console.log('🔍 Filtering for user role - showing only user documents (employee_code:', employeeCode, ')');
  } else {
    console.log('🔍 Filtering for admin role - showing all documents');
  }
  
  if (sanitizedStatus) {
    query += ` AND STATUS = :${queryParams.length + 1}`;
    queryParams.push(sanitizedStatus);
  }
  
  if (sanitizedSsoClientId) {
    query += ` AND SSO_CLIENT_ID = :${queryParams.length + 1}`;
    queryParams.push(sanitizedSsoClientId);
  }
  
  query += ' ORDER BY CREATED_AT DESC';
  query += ` OFFSET ${offsetNum} ROWS FETCH NEXT ${limitNum} ROWS ONLY`;
  
  return { query, queryParams };
}

// Helper function to extract rows from results
function extractRows(results) {
  if (results && results.rows) {
    console.log('📊 Using results.rows, count:', results.rows.length);
    return results.rows;
  } else if (Array.isArray(results)) {
    console.log('📊 Using results directly, count:', results.length);
    return results;
  } else {
    console.error('❌ Unexpected results format:', results);
    return [];
  }
}

// Helper function to clean row data
function cleanRowData(row) {
  const cleanRow = {};
  
  for (const [key, value] of Object.entries(row)) {
    if (value && typeof value === 'object') {
      const constructorName = value.constructor?.name;
      
      if (constructorName === 'Date') {
        cleanRow[key] = value.toISOString();
      } else if (constructorName === 'Buffer') {
        cleanRow[key] = value.toString('utf8');
      } else if (constructorName === 'ConnectDescription') {
        console.log(`⚠️ Skipping circular reference object for ${key}`);
        continue;
      } else {
        cleanRow[key] = value;
      }
    } else {
      cleanRow[key] = value;
    }
  }
  
  return cleanRow;
}

// Helper function to clean all rows
function cleanRows(rows) {
  return rows.map(cleanRowData);
}

// GET - Fetch rolewise client MIS documents
export async function GET(request) {
  try {
    console.log('🔍 Fetching rolewise client MIS documents...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Determine user role and details
    const { userRole, employeeDetails, employeeCode, performanceMode } = await determineUserRoleAndDetails(authValidation.authResult, request);
    
    const loggedInUserId = authValidation.authResult.userId;
    console.log('👤 Processing documents for user:', loggedInUserId, 'with role:', userRole);
    console.log('👤 Employee code:', employeeCode);

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const ssoClientId = searchParams.get('ssoClientId');
    const limit = searchParams.get('limit');
    const offset = searchParams.get('offset');

    // Validate parameters
    const statusValidation = validateStatus(status);
    if (!statusValidation.isValid) {
      return NextResponse.json({ error: statusValidation.error }, { status: 400 });
    }

    const ssoClientIdValidation = validateSsoClientId(ssoClientId);
    if (!ssoClientIdValidation.isValid) {
      return NextResponse.json({ error: ssoClientIdValidation.error }, { status: 400 });
    }

    const paginationValidation = validatePagination(limit, offset);
    if (!paginationValidation.isValid) {
      return NextResponse.json({ error: paginationValidation.error }, { status: 400 });
    }

    // Build and execute query
    const { query, queryParams } = buildRoleBasedQuery(
      userRole,
      employeeCode,
      statusValidation.sanitizedStatus,
      ssoClientIdValidation.sanitizedSsoClientId,
      paginationValidation.limitNum,
      paginationValidation.offsetNum
    );

    console.log('🔍 Executing role-based document query:', query);
    console.log('🔍 Query parameters:', queryParams);

    const results = await executeQuery(query, queryParams);
    console.log('📊 Database query results:', results);

    // Extract and clean rows
    const rows = extractRows(results);
    const cleanedRows = cleanRows(rows);

    console.log(`✅ Found ${cleanedRows.length} role-based filtered documents for user ${loggedInUserId} (${userRole})`);
    return NextResponse.json({ 
      success: true, 
      documents: cleanedRows || [],
      total: cleanedRows.length,
      limit: paginationValidation.limitNum,
      offset: paginationValidation.offsetNum,
      userId: loggedInUserId,
      userRole: userRole,
      employeeCode: employeeCode,
      dataType: 'rolewise_documents',
      filteredByRole: true,
      performanceMode: performanceMode
    });

  } catch (error) {
    console.error('❌ Error fetching role-based filtered documents:', error);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ Error details:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState
    });
    
    return NextResponse.json({ 
      error: 'Failed to fetch role-based filtered documents',
      details: error.message,
      code: error.code || 'UNKNOWN'
    }, { status: 500 });
  }
}
