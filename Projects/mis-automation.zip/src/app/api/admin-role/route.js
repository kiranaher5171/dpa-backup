import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';

// Helper function to check if user is admin
async function checkAdminAccess(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }

  // Check if user is admin by checking their role in database
  try {
    const roleQuery = `
      SELECT IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    console.log('🔍 Admin validation: Checking employee code:', authResult.employee_code);
    const roleResult = await executeQuery(roleQuery, [authResult.employee_code]);
    
    console.log('🔍 Admin validation: Query result:', {
      rowsCount: roleResult.rows ? roleResult.rows.length : 0,
      rows: roleResult.rows
    });
    
    if (!roleResult.rows || roleResult.rows.length === 0) {
      console.log('🔍 Admin validation: Employee not found in MIS_ACCESS_CONTROL table');
      
      // TEMPORARY: Allow employee 501 to access for testing
      if (authResult.employee_code === '501') {
        console.log('🔍 Admin validation: TEMPORARY - Allowing employee 501 for testing');
        return { isValid: true, authResult };
      }
      
      return { isValid: false, error: 'Access denied - admin privileges required' };
    }

    const isAdmin = roleResult.rows[0].IS_ADMIN;
    console.log('🔍 Admin validation: IS_ADMIN value:', isAdmin, 'Type:', typeof isAdmin);
    
    // Handle different data types (number, string, boolean)
    const isAdminValue = Number(isAdmin);
    if (isAdminValue !== 1) {
      console.log('🔍 Admin validation: User is not admin (IS_ADMIN != 1)');
      return { isValid: false, error: 'Access denied - admin privileges required' };
    }

    console.log('🔍 Admin validation: User is admin, access granted');
    return { isValid: true, authResult };
  } catch (error) {
    console.error('Error checking admin access:', error);
    return { isValid: false, error: 'Error verifying admin access' };
  }
}

// GET - Check if employee is admin
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const empCode = searchParams.get('emp_code');
    
    if (!empCode) {
      return NextResponse.json({ 
        success: false, 
        error: 'Employee code is required' 
      }, { status: 400 });
    }

    console.log('🔍 Checking admin status for employee:', empCode);

    const query = `
      SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    const result = await executeQuery(query, [empCode]);
    
    if (result.rows && result.rows.length > 0) {
      const employee = result.rows[0];
      const isAdmin = employee.IS_ADMIN === 1;
      console.log('✅ Employee found in access control table:', employee);
      return NextResponse.json({
        success: true,
        is_admin: isAdmin,
        emp_code: employee.EMP_CODE,
        emp_name: employee.EMP_NAME,
        role: isAdmin ? 'admin' : 'user'
      });
    } else {
      console.log('❌ Employee not found in access control table');
      return NextResponse.json({
        success: true,
        is_admin: false,
        emp_code: empCode,
        role: 'user'
      });
    }
  } catch (error) {
    console.error('❌ Error checking admin status:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to check admin status' 
    }, { status: 500 });
  }
}

// POST - Add employee as admin
export async function POST(request) {
  try {
    const adminValidation = await checkAdminAccess(request);
    if (!adminValidation.isValid) {
      return NextResponse.json({ 
        success: false, 
        error: adminValidation.error 
      }, { status: 401 });
    }

    const { emp_code, emp_name } = await request.json();
    
    if (!emp_code) {
      return NextResponse.json({ 
        success: false, 
        error: 'Employee code is required' 
      }, { status: 400 });
    }

    console.log('🔍 Adding employee as admin:', { emp_code, emp_name });

    // Check if employee already exists
    const checkQuery = `
      SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    const checkResult = await executeQuery(checkQuery, [emp_code]);
    
    if (checkResult.rows && checkResult.rows.length > 0) {
      // Employee already exists, update to admin
      const updateQuery = `
        UPDATE MIS_ACCESS_CONTROL 
        SET IS_ADMIN = 1, EMP_NAME = :emp_name 
        WHERE EMP_CODE = :emp_code
      `;
      
      await executeQuery(updateQuery, [emp_name || `Employee ${emp_code}`, emp_code]);
      
      console.log('✅ Employee role updated to admin');
      return NextResponse.json({
        success: true,
        message: `Employee ${emp_code} role updated to admin`,
        action: 'updated_to_admin',
        emp_code,
        role: 'admin',
        is_admin: true
      });
    } else {
      // Employee doesn't exist, insert new record
      const insertQuery = `
        INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN) 
        VALUES (:id, :emp_code, :emp_name, 1)
      `;
      
      const employeeId = `emp_${emp_code}_${Date.now()}`;
      const employeeName = emp_name || `Employee ${emp_code}`;
      
      await executeQuery(insertQuery, [employeeId, emp_code, employeeName]);
      
      console.log('✅ Employee added as admin');
      return NextResponse.json({
        success: true,
        message: `Employee ${emp_code} added as admin`,
        action: 'added_as_admin',
        emp_code,
        role: 'admin',
        is_admin: true
      });
    }
  } catch (error) {
    console.error('❌ Error adding admin role:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to add admin role' 
    }, { status: 500 });
  }
}

// DELETE - Remove employee from admin
export async function DELETE(request) {
  try {
    const adminValidation = await checkAdminAccess(request);
    if (!adminValidation.isValid) {
      return NextResponse.json({ 
        success: false, 
        error: adminValidation.error 
      }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const empCode = searchParams.get('emp_code');
    
    if (!empCode) {
      return NextResponse.json({ 
        success: false, 
        error: 'Employee code is required' 
      }, { status: 400 });
    }

    console.log('🔍 Removing admin role for employee:', empCode);

    // Check if employee exists first
    const checkQuery = `
      SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    const checkResult = await executeQuery(checkQuery, [empCode]);
    
    if (checkResult.rows && checkResult.rows.length > 0) {
      // Employee exists, update IS_ADMIN to 0
      const updateQuery = `
        UPDATE MIS_ACCESS_CONTROL 
        SET IS_ADMIN = 0 
        WHERE EMP_CODE = :emp_code
      `;
      
      await executeQuery(updateQuery, [empCode]);
      
      console.log('✅ Employee admin role removed (set to user)');
      return NextResponse.json({
        success: true,
        message: `Employee ${empCode} role changed to user`,
        action: 'removed_from_admin',
        emp_code: empCode,
        role: 'user',
        is_admin: false
      });
    } else {
      // Employee doesn't exist in table, insert as user
      const insertQuery = `
        INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN) 
        VALUES (:id, :emp_code, :emp_name, 0)
      `;
      
      const employeeId = `emp_${empCode}_${Date.now()}`;
      const employeeName = `Employee ${empCode}`;
      
      await executeQuery(insertQuery, [employeeId, empCode, employeeName]);
      
      console.log('✅ Employee added as user');
      return NextResponse.json({
        success: true,
        message: `Employee ${empCode} added as user`,
        action: 'added_as_user',
        emp_code: empCode,
        role: 'user',
        is_admin: false
      });
    }
  } catch (error) {
    console.error('❌ Error removing admin role:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to remove admin role' 
    }, { status: 500 });
  }
}
