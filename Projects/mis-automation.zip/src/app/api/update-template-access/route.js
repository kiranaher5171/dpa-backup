import { NextResponse } from 'next/server';
import oracledb from 'oracledb';

// Configure Oracle connection
const dbConfig = {
    user: process.env.ORACLE_USER,
    password: process.env.ORACLE_PASSWORD,
    connectString: process.env.ORACLE_CONNECTION_STRING,
    externalAuth: false
};

export async function PUT(request) {
    let connection;
    
    try {
        // Parse request body
        const body = await request.json();
        const { templateId, templateAccessEmpCodes } = body;

        console.log('API received data:', { templateId, templateAccessEmpCodes });

        // Validate required fields
        if (!templateId) {
            return NextResponse.json({
                success: false,
                error: 'Template ID is required'
            }, { status: 400 });
        }

        // Get authorization header
        const authHeader = request.headers.get('authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json({
                success: false,
                error: 'Authorization token is required'
            }, { status: 401 });
        }

        const token = authHeader.split(' ')[1];

        // TODO: Add JWT token validation here
        // For now, we'll proceed with the database update

        // Create database connection
        connection = await oracledb.getConnection(dbConfig);

        // Update template access in the database
        const updateQuery = `
            UPDATE client_mis_templates 
            SET template_access_emp_names = :templateAccessEmpNames,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = :templateId
        `;

        console.log('Executing query with params:', {
            templateAccessEmpNames: templateAccessEmpCodes || null,
            templateId: templateId
        });

        const result = await connection.execute(updateQuery, {
            templateAccessEmpNames: templateAccessEmpCodes || null,
            templateId: templateId
        }, {
            autoCommit: true
        });

        console.log('Query result:', { rowsAffected: result.rowsAffected });

        // Check if any rows were affected
        if (result.rowsAffected === 0) {
            return NextResponse.json({
                success: false,
                error: 'Template not found or no changes made'
            }, { status: 404 });
        }

        // Log the access update
        console.log(`Template access updated for template ${templateId}:`, templateAccessEmpCodes);

        return NextResponse.json({
            success: true,
            message: 'Template access updated successfully',
            data: {
                templateId: templateId,
                templateAccessEmpCodes: templateAccessEmpCodes,
                updatedAt: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error('Error updating template access:', error);
        
        return NextResponse.json({
            success: false,
            error: 'Failed to update template access',
            details: error.message
        }, { status: 500 });
        
    } finally {
        // Close database connection
        if (connection) {
            try {
                await connection.close();
            } catch (closeError) {
                console.error('Error closing database connection:', closeError);
            }
        }
    }
}
