import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';

export async function POST(request) {
  try {
    // For internal role checking, we can either verify token or make it simpler
    // Let's try to verify token first, but fallback to direct role check if needed
    let authResult = null;
    try {
      authResult = await verifyAnyToken(request);
    } catch (authError) {
      console.log('🔐 Role API: Token verification failed, proceeding with direct role check');
    }

    const { emp_code } = await request.json();
    
    if (!emp_code) {
      return NextResponse.json(
        { success: false, error: 'Employee code is required' },
        { status: 400 }
      );
    }

    // Check role in database
    console.log('🔍 API: Checking role for emp_code:', emp_code);
    const roleData = await checkUserRoleFromDatabase(emp_code);
    console.log('🔍 API: Role data received:', roleData);
    
    return NextResponse.json({
      success: true,
      emp_code: roleData.emp_code,
      role: roleData.role,
      is_admin: roleData.is_admin,
      emp_name: roleData.emp_name,
      id: roleData.id
    });

  } catch (error) {
    console.error('Error checking user role:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Function to check user role from MIS_ACCESS_CONTROL table
async function checkUserRoleFromDatabase(emp_code) {
  try {
    const query = `
      SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    const result = await executeQuery(query, [emp_code]);
    
    console.log('🔍 Database query result:', {
      rowsCount: result.rows ? result.rows.length : 0,
      rows: result.rows,
      emp_code_searched: emp_code
    });
    
    if (!result.rows || result.rows.length === 0) {
      // User not found in access control table, default to 'user'
      console.log('🔍 User not found in database, defaulting to user role');
      return {
        emp_code,
        emp_name: null,
        is_admin: 0,
        role: 'user'
      };
    }
    
    const row = result.rows[0];
    console.log('🔍 Database row data:', row);
    
    // Since executeQuery uses OUT_FORMAT_OBJECT, we can access by column name
    const id = row.ID;
    const emp_code_db = row.EMP_CODE;
    const emp_name = row.EMP_NAME;
    const is_admin = row.IS_ADMIN;
    
    console.log('🔍 Parsed data:', {
      id,
      emp_code_db,
      emp_name,
      is_admin,
      is_admin_type: typeof is_admin
    });
    
    // Check the actual IS_ADMIN flag from database
    const isAdminValue = Number(is_admin);
    console.log('🔍 Employee found in MIS_ACCESS_CONTROL - IS_ADMIN value:', isAdminValue);
    
    return {
      id: id,
      emp_code: emp_code_db,
      emp_name: emp_name,
      is_admin: isAdminValue, // Use actual IS_ADMIN value from database
      role: isAdminValue === 1 ? 'admin' : 'user' // Set role based on IS_ADMIN flag
    };
    
  } catch (error) {
    console.error('Database error:', error);
    console.log('🔍 Database error details:', {
      message: error.message,
      stack: error.stack,
      emp_code_searched: emp_code
    });
    
    // No fallback - database is required
    console.log('🔍 Database connection failed - no fallback available');
    
    return {
      emp_code,
      emp_name: null,
      is_admin: 0,
      role: 'user'
    };
  }
}

// Test database connection
export async function PUT(request) {
  try {
    console.log('🔍 Testing database connection...');
    
    // Test a simple query
    const testQuery = 'SELECT COUNT(*) as count FROM MIS_ACCESS_CONTROL';
    const result = await executeQuery(testQuery);
    console.log('🔍 Test query result:', result.rows);
    
    return NextResponse.json({
      success: true,
      message: 'Database connection test successful',
      count: result.rows[0].COUNT
    });
  } catch (error) {
    console.error('❌ Database connection test failed:', error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

// GET method for direct role checking (alternative approach)
export async function GET(request) {
  try {
    const authResult = await verifyAnyToken(request);
    if (!authResult.isValid) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const emp_code = searchParams.get('emp_code');
    
    if (!emp_code) {
      return NextResponse.json(
        { success: false, error: 'Employee code is required' },
        { status: 400 }
      );
    }

    const roleData = await checkUserRoleFromDatabase(emp_code);
    
    return NextResponse.json({
      success: true,
      emp_code: roleData.emp_code,
      role: roleData.role,
      is_admin: roleData.is_admin,
      emp_name: roleData.emp_name,
      id: roleData.id
    });

  } catch (error) {
    console.error('Error checking user role:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
