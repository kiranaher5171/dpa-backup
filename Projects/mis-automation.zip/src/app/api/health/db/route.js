import { NextResponse } from 'next/server';
import { healthCheck, getPoolStatus, getConnectionStats, forceCleanup } from '@/lib/db';

export async function GET() {
  try {
    console.log('🏥 Database health check requested');
    
    const health = await healthCheck();
    const poolStatus = await getPoolStatus();
    const connectionStats = await getConnectionStats();
    
    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      health: health,
      poolStatus: poolStatus,
      connectionStats: connectionStats
    });
  } catch (error) {
    console.error('❌ Database health check failed:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { action } = await request.json();
    
    console.log(`🔧 Database action requested: ${action}`);
    
    switch (action) {
      case 'cleanup':
        const cleanupResult = await forceCleanup();
        return NextResponse.json({
          success: true,
          action: 'cleanup',
          result: cleanupResult,
          timestamp: new Date().toISOString()
        });
        
      case 'status':
        const poolStatus = await getPoolStatus();
        const connectionStats = await getConnectionStats();
        return NextResponse.json({
          success: true,
          action: 'status',
          poolStatus: poolStatus,
          connectionStats: connectionStats,
          timestamp: new Date().toISOString()
        });
        
      default:
        return NextResponse.json({
          success: false,
          error: 'Invalid action. Use "cleanup" or "status"',
          timestamp: new Date().toISOString()
        }, { status: 400 });
    }
  } catch (error) {
    console.error('❌ Database action failed:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}
