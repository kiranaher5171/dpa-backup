import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';

// GET endpoint to check admin roles for all employees
export async function GET(request) {
  try {
    console.log('🔍 Check Admin Roles: Fetching admin status for all employees...');
    
    // Validate authentication (but don't require admin access)
    const authResult = await verifyAnyToken(request);
    if (!authResult.isValid) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized - please login' },
        { status: 401 }
      );
    }

    // Get all admin employees from MIS_ACCESS_CONTROL table
    const query = `
      SELECT EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE IS_ADMIN = 1
      ORDER BY EMP_NAME
    `;
    
    const result = await executeQuery(query);
    
    // Create a set of admin employee codes for easy lookup
    const adminEmpCodes = new Set();
    if (result.rows && result.rows.length > 0) {
      result.rows.forEach(row => {
        adminEmpCodes.add(row.EMP_CODE);
      });
    }

    console.log(`✅ Check Admin Roles: Found ${adminEmpCodes.size} admin employees`);

    return NextResponse.json({
      success: true,
      admin_emp_codes: Array.from(adminEmpCodes),
      total_admins: adminEmpCodes.size,
      note: 'Returns list of employee codes who have admin access'
    });

  } catch (error) {
    console.error('❌ Check Admin Roles: Error fetching admin roles:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch admin roles',
        details: error.message 
      },
      { status: 500 }
    );
  }
}
