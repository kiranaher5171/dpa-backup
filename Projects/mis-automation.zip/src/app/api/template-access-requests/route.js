import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to clean row data
async function cleanRowData(row) {
  const cleanRow = {};
  
  for (const [key, value] of Object.entries(row)) {
    if (value && typeof value === 'object') {
      // Check for circular references
      try {
        JSON.stringify(value);
        cleanRow[key] = value;
      } catch (error) {
        console.warn(`⚠️ Circular reference detected in ${key}, skipping field`);
        cleanRow[key] = null;
      }
    } else {
      cleanRow[key] = value;
    }
  }
  
  return cleanRow;
}

// Helper function to clean all rows
async function cleanRows(rows) {
  return await Promise.all(rows.map(cleanRowData));
}

// POST - Create new access request
export async function POST(request) {
  try {
    console.log('📋 Creating new template access request...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const { authResult } = authValidation;
    
    // Get request data
    const body = await request.json();
    const { templateName, requestorName, requestorEmpCode, requestorEmail } = body;

    // Validate required fields
    if (!templateName || !requestorName || !requestorEmpCode) {
      return NextResponse.json({
        error: 'Missing required fields: templateName, requestorName, requestorEmpCode'
      }, { status: 400 });
    }

    // Insert new access request
    const insertQuery = `
      INSERT INTO MIS_TEMPLATE_ACCESS_REQUESTS (
        TEMPLATE_NAME,
        REQUESTOR_NAME,
        REQUESTOR_EMP_CODE,
        REQUESTOR_EMAIL,
        STATUS,
        CREATED_BY,
        UPDATED_BY,
        IS_ACTIVE
      ) VALUES (
        :1, :2, :3, :4, 'REQUESTED', :5, :6, 1
      )
    `;

    const insertParams = [
      templateName,
      requestorName,
      requestorEmpCode,
      requestorEmail || null,
      requestorName,
      requestorName
    ];

    console.log('🔍 Executing insert query...');
    const result = await executeQuery(insertQuery, insertParams);

    console.log('✅ Template access request created successfully');
    return NextResponse.json({
      success: true,
      message: 'Access request created successfully',
      requestId: result.lastRowid || 'unknown'
    });

  } catch (error) {
    console.error('❌ Error creating template access request:', error);
    return NextResponse.json({
      error: 'Failed to create access request',
      details: error.message
    }, { status: 500 });
  }
}

// GET - Fetch all access requests (for admin)
export async function GET(request) {
  try {
    console.log('📋 Fetching all template access requests...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    // Fetch all access requests
    const query = `
      SELECT 
        ID,
        TEMPLATE_NAME,
        REQUESTOR_NAME,
        REQUESTOR_EMP_CODE,
        REQUESTOR_EMAIL,
        STATUS,
        CREATED_AT,
        UPDATED_AT,
        CREATED_BY,
        UPDATED_BY,
        ADMIN_UPDATED_AT,
        ADMIN_UPDATED_BY,
        IS_ACTIVE
      FROM MIS_TEMPLATE_ACCESS_REQUESTS 
      WHERE IS_ACTIVE = 1
      ORDER BY CREATED_AT DESC
    `;

    console.log('🔍 Executing query for all access requests...');
    const result = await executeQuery(query, []);
    
    console.log(`📊 Fetched ${result.rows.length} access requests`);

    // Clean the rows
    const cleanedRequests = await cleanRows(result.rows);
    console.log(`📊 Cleaned ${cleanedRequests.length} requests`);

    return NextResponse.json({
      success: true,
      requests: cleanedRequests,
      totalRequests: cleanedRequests.length
    });

  } catch (error) {
    console.error('❌ Error fetching template access requests:', error);
    return NextResponse.json({
      error: 'Failed to fetch access requests',
      details: error.message
    }, { status: 500 });
  }
}
