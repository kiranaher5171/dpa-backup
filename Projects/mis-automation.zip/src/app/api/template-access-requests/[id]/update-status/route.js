import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  console.log('✅ Authentication successful, user:', authResult.userId);
  return { isValid: true, authResult };
}

// Helper function to append name to TEMPLATE_ACCESS_EMP_NAMES
async function appendToTemplateAccess(templateName, requestorName) {
  try {
    // First, get the current access names
    const selectQuery = `
      SELECT TEMPLATE_ACCESS_EMP_NAMES 
      FROM DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
      WHERE TEMPLATE_NAME = :1 AND IS_ACTIVE = 1
    `;
    
    const selectResult = await executeQuery(selectQuery, [templateName]);
    
    if (selectResult.rows.length === 0) {
      throw new Error(`Template '${templateName}' not found`);
    }
    
    const currentAccessNames = selectResult.rows[0].TEMPLATE_ACCESS_EMP_NAMES || '';
    
    // Check if name already exists
    const existingNames = currentAccessNames.split(',').map(name => name.trim()).filter(name => name);
    if (existingNames.includes(requestorName)) {
      console.log(`⚠️ User '${requestorName}' already has access to template '${templateName}'`);
      return { success: true, message: 'User already has access' };
    }
    
    // Append the new name
    const updatedAccessNames = currentAccessNames 
      ? `${currentAccessNames},${requestorName}`
      : requestorName;
    
    // Update the template access
    const updateQuery = `
      UPDATE DEV_DPA_MIS_AUTOMATION.CLIENT_MIS_TEMPLATES 
      SET TEMPLATE_ACCESS_EMP_NAMES = :1,
          UPDATED_AT = CURRENT_TIMESTAMP
      WHERE TEMPLATE_NAME = :2 AND IS_ACTIVE = 1
    `;
    
    await executeQuery(updateQuery, [updatedAccessNames, templateName]);
    
    console.log(`✅ Added '${requestorName}' to template '${templateName}' access list`);
    return { success: true, message: 'Access granted successfully' };
    
  } catch (error) {
    console.error('❌ Error updating template access:', error);
    throw error;
  }
}

// PUT - Update access request status (grant/reject)
export async function PUT(request, { params }) {
  try {
    console.log('📋 Updating template access request status...');
    
    // Validate authentication
    const authValidation = await validateAuth(request);
    if (!authValidation.isValid) {
      return NextResponse.json({ error: authValidation.error }, { status: 401 });
    }

    const { authResult } = authValidation;
    const requestId = params.id;
    
    // Get request data
    const body = await request.json();
    const { status, adminName } = body;

    // Validate status
    if (!status || !['GRANTED', 'REJECTED'].includes(status)) {
      return NextResponse.json({
        error: 'Invalid status. Must be GRANTED or REJECTED'
      }, { status: 400 });
    }

    // First, get the request details
    const selectQuery = `
      SELECT 
        TEMPLATE_NAME,
        REQUESTOR_NAME,
        REQUESTOR_EMP_CODE,
        STATUS
      FROM MIS_TEMPLATE_ACCESS_REQUESTS 
      WHERE ID = :1 AND IS_ACTIVE = 1
    `;

    const selectResult = await executeQuery(selectQuery, [requestId]);
    
    if (selectResult.rows.length === 0) {
      return NextResponse.json({
        error: 'Access request not found'
      }, { status: 404 });
    }

    const requestData = selectResult.rows[0];
    
    // Check if already processed
    if (requestData.STATUS !== 'REQUESTED') {
      return NextResponse.json({
        error: `Request already processed with status: ${requestData.STATUS}`
      }, { status: 400 });
    }

    // If granting access, update the template access
    if (status === 'GRANTED') {
      try {
        await appendToTemplateAccess(requestData.TEMPLATE_NAME, requestData.REQUESTOR_NAME);
      } catch (error) {
        console.error('❌ Error granting template access:', error);
        return NextResponse.json({
          error: 'Failed to grant template access',
          details: error.message
        }, { status: 500 });
      }
    }

    // Update the request status
    const updateQuery = `
      UPDATE MIS_TEMPLATE_ACCESS_REQUESTS 
      SET STATUS = :1,
          UPDATED_BY = :2,
          ADMIN_UPDATED_BY = :3,
          ADMIN_UPDATED_AT = CURRENT_TIMESTAMP,
          UPDATED_AT = CURRENT_TIMESTAMP
      WHERE ID = :4
    `;

    const updateParams = [
      status,
      adminName || authResult.fullName || authResult.userId || 'Admin',
      adminName || authResult.fullName || authResult.userId || 'Admin',
      requestId
    ];

    console.log('🔍 Executing status update query...');
    await executeQuery(updateQuery, updateParams);

    console.log(`✅ Access request ${requestId} updated to status: ${status}`);
    return NextResponse.json({
      success: true,
      message: `Access request ${status.toLowerCase()} successfully`,
      requestId: requestId,
      status: status
    });

  } catch (error) {
    console.error('❌ Error updating access request status:', error);
    return NextResponse.json({
      error: 'Failed to update access request status',
      details: error.message
    }, { status: 500 });
  }
}
