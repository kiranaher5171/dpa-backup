import { NextResponse } from 'next/server'
import { executeQuery } from '@/lib/db'
import { verifyAnyToken } from '@/lib/jwt'
import { v4 as uuidv4 } from 'uuid'

// Helper function to validate authentication
async function validateAuth(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }
  return { isValid: true, authResult };
}

// Helper function to validate required fields
function validateRequiredFields(body) {
  const { sso_client_id, template_id, user_id, mis_document_name } = body;
  
  if (!sso_client_id || !template_id || !user_id || !mis_document_name) {
    return { 
      isValid: false, 
      error: 'Missing required fields: sso_client_id, template_id, user_id, mis_document_name' 
    };
  }
  
  return { isValid: true };
}

// Helper function to check for duplicate documents
async function checkDuplicateDocument(templateId, misDocumentName) {
  const checkQuery = `
    SELECT COUNT(*) as count 
    FROM CLIENT_MIS_DOCUMENTS 
    WHERE TEMPLATE_ID = :1 AND MIS_DOCUMENT_NAME = :2 AND IS_ACTIVE = 1
  `;
  
  const checkResult = await executeQuery(checkQuery, [templateId, misDocumentName]);
  
  if (checkResult.rows && checkResult.rows[0] && checkResult.rows[0].COUNT > 0) {
    return { isDuplicate: true };
  }
  
  return { isDuplicate: false };
}

// Helper function to prepare data for storage
function prepareDataForStorage(html_template, theme_colors, dynamic_elements, generated_infographics) {
  const htmlTemplateString = html_template ? html_template.toString() : null;
  
  // Handle theme_colors properly - check if it exists and is an array with length > 0
  let themeColorsString = null;
  if (theme_colors && Array.isArray(theme_colors) && theme_colors.length > 0) {
    themeColorsString = JSON.stringify(theme_colors);
  } else if (theme_colors && typeof theme_colors === 'string') {
    // If it's already a string, use it directly
    themeColorsString = theme_colors;
  }
  
  const dynamicElementsString = dynamic_elements && dynamic_elements.length > 0 ? JSON.stringify(dynamic_elements) : null;
  const generatedInfographicsString = generated_infographics && generated_infographics.length > 0 ? JSON.stringify(generated_infographics) : null;

  console.log('🔧 prepareDataForStorage - theme_colors input:', theme_colors);
  console.log('🔧 prepareDataForStorage - theme_colors type:', typeof theme_colors);
  console.log('🔧 prepareDataForStorage - theme_colors is array:', Array.isArray(theme_colors));
  console.log('🔧 prepareDataForStorage - themeColorsString result:', themeColorsString);

  return {
    htmlTemplateString,
    themeColorsString,
    dynamicElementsString,
    generatedInfographicsString
  };
}

// Helper function to build insert query
function buildInsertQuery() {
  return `
    INSERT INTO CLIENT_MIS_DOCUMENTS (
      ID, SSO_CLIENT_ID, SSO_CLIENT_NAME, TEMPLATE_ID, TEMPLATE_NAME,
      USER_ID, MIS_DOCUMENT_NAME, HTML_TEMPLATE, STATUS, CREATED_AT, 
      UPDATED_AT, CREATED_BY, CREATED_BY_EMAIL, CREATED_BY_ROLE, 
      BANNER_URL, THEME_COLORS, DYNAMIC_ELEMENTS, GENERATED_INFOGRAPHICS, IS_ACTIVE
    ) VALUES (
      :1, :2, :3, :4, :5, :6, :7, :8, :9, CURRENT_TIMESTAMP, 
      CURRENT_TIMESTAMP, :10, :11, :12, :13, :14, :15, :16, 1
    )
  `;
}

// Helper function to build fetch query
function buildFetchQuery() {
  return `
    SELECT 
      ID, SSO_CLIENT_ID, SSO_CLIENT_NAME, TEMPLATE_ID, TEMPLATE_NAME,
      USER_ID, MIS_DOCUMENT_NAME, HTML_TEMPLATE, STATUS, CREATED_AT, 
      UPDATED_AT, CREATED_BY, CREATED_BY_EMAIL, CREATED_BY_ROLE, 
      BANNER_URL, THEME_COLORS, DYNAMIC_ELEMENTS,
      GENERATED_INFOGRAPHICS
    FROM CLIENT_MIS_DOCUMENTS 
    WHERE ID = :1
  `;
}

// Helper function to convert CLOB to string safely
async function clobToString(clobValue) {
  if (!clobValue) return null;
  
  try {
    // If it's already a string, return it
    if (typeof clobValue === 'string') {
      return clobValue;
    }
    
    // If it's a CLOB object, convert it to string
    if (clobValue && typeof clobValue.getData === 'function') {
      return await clobValue.getData();
    }
    
    // If it's null or undefined, return null
    return null;
  } catch (error) {
    console.warn('Error converting CLOB to string:', error);
    return null;
  }
}

// Helper function to parse JSON field safely
function parseJsonField(fieldValue, fieldName) {
  if (!fieldValue) return [];
  
  try {
    return JSON.parse(fieldValue);
  } catch (e) {
    console.warn(`Failed to parse ${fieldName}:`, e);
    return [];
  }
}

// Helper function to process document data
async function processDocumentData(rawDoc) {
  // Convert CLOB fields to strings
  const htmlTemplate = await clobToString(rawDoc.HTML_TEMPLATE);
  const themeColorsClob = await clobToString(rawDoc.THEME_COLORS);
  const dynamicElementsClob = await clobToString(rawDoc.DYNAMIC_ELEMENTS);
  const generatedInfographicsClob = await clobToString(rawDoc.GENERATED_INFOGRAPHICS);
  
  // Parse JSON fields
  const themeColors = parseJsonField(themeColorsClob, 'THEME_COLORS');
  const dynamicElements = parseJsonField(dynamicElementsClob, 'DYNAMIC_ELEMENTS');
  const generatedInfographics = parseJsonField(generatedInfographicsClob, 'GENERATED_INFOGRAPHICS');

  return {
    ID: rawDoc.ID,
    SSO_CLIENT_ID: rawDoc.SSO_CLIENT_ID,
    SSO_CLIENT_NAME: rawDoc.SSO_CLIENT_NAME,
    TEMPLATE_ID: rawDoc.TEMPLATE_ID,
    TEMPLATE_NAME: rawDoc.TEMPLATE_NAME,
    USER_ID: rawDoc.USER_ID,
    MIS_DOCUMENT_NAME: rawDoc.MIS_DOCUMENT_NAME,
    HTML_TEMPLATE: htmlTemplate,
    STATUS: rawDoc.STATUS,
    CREATED_AT: rawDoc.CREATED_AT,
    UPDATED_AT: rawDoc.UPDATED_AT,
    CREATED_BY: rawDoc.CREATED_BY,
    CREATED_BY_EMAIL: rawDoc.CREATED_BY_EMAIL,
    CREATED_BY_ROLE: rawDoc.CREATED_BY_ROLE,
    BANNER_URL: rawDoc.BANNER_URL,
    THEME_COLORS: themeColors,
    DYNAMIC_ELEMENTS: dynamicElements,
    GENERATED_INFOGRAPHICS: generatedInfographics
  };
}

// Helper function to log document creation details
function logDocumentCreation(documentId, sso_client_name, template_name, mis_document_name, data) {
  console.log('💾 Executing database insert into CLIENT_MIS_DOCUMENTS table...');
  console.log('📄 Document data:', {
    id: documentId,
    client: sso_client_name,
    template: template_name,
    documentName: mis_document_name,
    hasHtmlTemplate: !!data.htmlTemplateString,
    hasThemeColors: !!data.themeColorsString,
    hasDynamicElements: !!data.dynamicElementsString,
    hasGeneratedInfographics: !!data.generatedInfographicsString,
    infographicsCount: data.generatedInfographicsString ? JSON.parse(data.generatedInfographicsString).length : 0
  });
}

export async function POST(request) {
    try {
        console.log('📝 Creating new MIS document...');
        
        // Validate authentication
        const authValidation = await validateAuth(request);
        if (!authValidation.isValid) {
            return NextResponse.json({ error: authValidation.error }, { status: 401 });
        }

        const body = await request.json();
        
        // Validate required fields
        const requiredFieldsValidation = validateRequiredFields(body);
        if (!requiredFieldsValidation.isValid) {
            return NextResponse.json({ error: requiredFieldsValidation.error }, { status: 400 });
        }

        const {
            sso_client_id,
            sso_client_name,
            template_id,
            template_name,
            user_id,
            mis_document_name,
            html_template,
            status = 'Draft',
            banner_url = '',
            theme_colors = [],
            dynamic_elements = [],
            generated_infographics = [],
            created_by,
            created_by_email,
            created_by_role
        } = body;

        console.log('📝 Received theme_colors in request body:', theme_colors);
        console.log('📝 theme_colors type:', typeof theme_colors);
        console.log('📝 theme_colors is array:', Array.isArray(theme_colors));
        console.log('📝 theme_colors length:', theme_colors?.length);

        // Check for duplicate document
        const duplicateCheck = await checkDuplicateDocument(template_id, mis_document_name);
        if (duplicateCheck.isDuplicate) {
            return NextResponse.json({
                error: 'A document for this template and period already exists',
                code: 'DUPLICATE_DOCUMENT'
            }, { status: 409 });
        }

        // Generate unique ID and prepare data
        const documentId = uuidv4();
        const data = prepareDataForStorage(html_template, theme_colors, dynamic_elements, generated_infographics);

        // Log document creation details
        logDocumentCreation(documentId, sso_client_name, template_name, mis_document_name, data);

        // Insert new document
        const insertQuery = buildInsertQuery();
        const insertParams = [
            documentId,
            sso_client_id,
            sso_client_name,
            template_id,
            template_name,
            user_id,
            mis_document_name,
            data.htmlTemplateString,
            status,
            created_by || 'Unknown User',
            created_by_email || '',
            created_by_role || 'User',
            banner_url,
            data.themeColorsString,
            data.dynamicElementsString,
            data.generatedInfographicsString
        ];

        const insertResult = await executeQuery(insertQuery, insertParams);
        console.log('✅ Database insert result:', insertResult);

        // Fetch the created document
        const fetchQuery = buildFetchQuery();
        const fetchResult = await executeQuery(fetchQuery, [documentId]);
        
        if (!fetchResult.rows || fetchResult.rows.length === 0) {
            throw new Error('Failed to fetch created document');
        }

        // Process and return document data
        const document = await processDocumentData(fetchResult.rows[0]);

        console.log('✅ MIS document created successfully in CLIENT_MIS_DOCUMENTS table:', document);
        console.log('📊 Infographics copied:', document.GENERATED_INFOGRAPHICS.length, 'items');

        return NextResponse.json({
            success: true,
            message: 'MIS document created successfully',
            document: document
        });

    } catch (error) {
        console.error('❌ Error creating MIS document:', error);
        return NextResponse.json({ 
            error: 'Database error while creating document',
            details: error.message
        }, { status: 500 });
    }
}
