import { NextResponse } from 'next/server';
import { closePool, forceCleanup } from '@/lib/db';

export async function POST() {
  try {
    console.log('🔄 Server-side logout cleanup requested');
    
    // Force cleanup of database connections
    console.log('🧹 Cleaning up database connections...');
    const cleanupResult = await forceCleanup();
    
    // Close the connection pool
    console.log('🔌 Closing database connection pool...');
    const closeResult = await closePool();
    
    return NextResponse.json({
      success: true,
      message: 'Logout cleanup completed',
      cleanup: cleanupResult,
      closePool: closeResult,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Error during logout cleanup:', error);
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}
