import { NextResponse } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';

// Helper function to validate authentication and admin access
async function validateAdminAccess(request) {
  const authResult = await verifyAnyToken(request);
  if (!authResult.isValid) {
    return { isValid: false, error: 'Unauthorized' };
  }

  // Check if user is admin by checking their role in database
  try {
    const roleQuery = `
      SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    console.log('🔍 Admin validation: Checking employee code:', authResult.employee_code);
    console.log('🔍 Admin validation: Query:', roleQuery);
    const roleResult = await executeQuery(roleQuery, [authResult.employee_code]);
    
    console.log('🔍 Admin validation: Query result:', {
      rowsCount: roleResult.rows ? roleResult.rows.length : 0,
      rows: roleResult.rows,
      resultKeys: roleResult.rows ? Object.keys(roleResult.rows[0] || {}) : []
    });
    
    if (!roleResult.rows || roleResult.rows.length === 0) {
      console.log('🔍 Admin validation: Employee not found in MIS_ACCESS_CONTROL table');
      
      // TEMPORARY: Allow employee 501 to access for testing
      if (authResult.employee_code === '501') {
        console.log('🔍 Admin validation: TEMPORARY - Allowing employee 501 for testing');
        return { isValid: true, authResult };
      }
      
      return { isValid: false, error: 'Access denied - admin privileges required' };
    }

    const isAdmin = roleResult.rows[0].IS_ADMIN;
    console.log('🔍 Admin validation: IS_ADMIN value:', isAdmin, 'Type:', typeof isAdmin);
    console.log('🔍 Admin validation: Raw row data:', roleResult.rows[0]);
    
    // Handle different data types (number, string, boolean)
    const isAdminValue = Number(isAdmin);
    console.log('🔍 Admin validation: Converted IS_ADMIN value:', isAdminValue);
    
    if (isAdminValue !== 1) {
      console.log('🔍 Admin validation: User is not admin (IS_ADMIN != 1)');
      return { isValid: false, error: 'Access denied - admin privileges required' };
    }

    console.log('🔍 Admin validation: User is admin, access granted');
    return { isValid: true, authResult };
  } catch (error) {
    console.error('Error checking admin access:', error);
    return { isValid: false, error: 'Error verifying admin access' };
  }
}

// PUT - Update user role
export async function PUT(request) {
  try {
    console.log('🔐 Manage Role: Updating user role...');
    
    // Validate admin access
    const adminValidation = await validateAdminAccess(request);
    if (!adminValidation.isValid) {
      return NextResponse.json(
        { success: false, error: adminValidation.error },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { emp_code, role } = body;

    // Validate input
    if (!emp_code || !role) {
      return NextResponse.json(
        { success: false, error: 'Employee code and role are required' },
        { status: 400 }
      );
    }

    if (!['admin', 'user'].includes(role)) {
      return NextResponse.json(
        { success: false, error: 'Invalid role. Must be "admin" or "user"' },
        { status: 400 }
      );
    }

    const adminUser = adminValidation.authResult.employee_code;

    console.log('🔐 Manage Role: Managing role for employee:', emp_code, 'to:', role, 'by admin:', adminUser);

    if (role === 'admin') {
      // Add employee to MIS_ACCESS_CONTROL table (make them admin)
      const checkQuery = `
        SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
        FROM MIS_ACCESS_CONTROL 
        WHERE EMP_CODE = :emp_code
      `;
      
      const checkResult = await executeQuery(checkQuery, [emp_code]);
      
      if (checkResult.rows && checkResult.rows.length > 0) {
        // Employee already exists in table, update to admin
        const updateQuery = `
          UPDATE MIS_ACCESS_CONTROL 
          SET IS_ADMIN = 1 
          WHERE EMP_CODE = :emp_code
        `;
        
        await executeQuery(updateQuery, [emp_code]);
        
        console.log('✅ Manage Role: Updated existing employee to admin');
        
        return NextResponse.json({
          success: true,
          message: `Employee ${emp_code} role updated to admin`,
          action: 'updated_to_admin',
          emp_code,
          role: 'admin',
          is_admin: true
        });
      } else {
        // Employee doesn't exist, add them to table as admin
        const insertQuery = `
          INSERT INTO MIS_ACCESS_CONTROL (ID, EMP_CODE, EMP_NAME, IS_ADMIN)
          VALUES (:id, :emp_code, :emp_name, 1)
        `;
        
        const employeeId = `emp_${emp_code}_${Date.now()}`;
        const employeeName = `Employee ${emp_code}`; // Placeholder name
        
        await executeQuery(insertQuery, [employeeId, emp_code, employeeName]);
        
        console.log('✅ Manage Role: Added new employee as admin');
        
        return NextResponse.json({
          success: true,
          message: `Employee ${emp_code} added as admin`,
          action: 'added_as_admin',
          emp_code,
          role: 'admin',
          is_admin: true
        });
      }
    } else {
      // Remove employee from MIS_ACCESS_CONTROL table (make them regular user)
      const deleteQuery = `
        DELETE FROM MIS_ACCESS_CONTROL 
        WHERE EMP_CODE = :emp_code
      `;
      
      const result = await executeQuery(deleteQuery, [emp_code]);
      
      console.log('✅ Manage Role: Removed employee from admin access');
      
      return NextResponse.json({
        success: true,
        message: `Employee ${emp_code} role changed to user (removed from admin access)`,
        action: 'removed_from_admin',
        emp_code,
        role: 'user',
        is_admin: false
      });
    }

  } catch (error) {
    console.error('❌ Manage Role: Error updating user role:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to update user role',
        details: error.message 
      },
      { status: 500 }
    );
  }
}

// Test endpoint to check if specific employee exists in database
export async function POST(request) {
  try {
    const { searchParams } = new URL(request.url);
    const testEmpCode = searchParams.get('test_emp_code') || '501';
    
    console.log('🧪 Testing employee in database:', testEmpCode);
    
    const query = `
      SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    const result = await executeQuery(query, [testEmpCode]);
    
    console.log('🧪 Test result:', {
      rowsCount: result.rows ? result.rows.length : 0,
      rows: result.rows
    });
    
    if (result.rows && result.rows.length > 0) {
      const employee = result.rows[0];
      return NextResponse.json({
        success: true,
        found: true,
        employee: {
          id: employee.ID,
          emp_code: employee.EMP_CODE,
          emp_name: employee.EMP_NAME,
          is_admin: employee.IS_ADMIN,
          is_admin_type: typeof employee.IS_ADMIN,
          is_admin_number: Number(employee.IS_ADMIN)
        }
      });
    } else {
      return NextResponse.json({
        success: true,
        found: false,
        message: `Employee ${testEmpCode} not found in MIS_ACCESS_CONTROL table`
      });
    }
  } catch (error) {
    console.error('❌ Error testing employee:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to test employee' 
    }, { status: 500 });
  }
}

// GET - Get all employees with their roles
export async function GET(request) {
  try {
    console.log('🔐 Manage Role: Fetching all employees with roles...');
    
    // Validate admin access
    const adminValidation = await validateAdminAccess(request);
    if (!adminValidation.isValid) {
      return NextResponse.json(
        { success: false, error: adminValidation.error },
        { status: 401 }
      );
    }

    const query = `
      SELECT ID, EMP_CODE, EMP_NAME, IS_ADMIN 
      FROM MIS_ACCESS_CONTROL 
      ORDER BY EMP_NAME
    `;
    
    const result = await executeQuery(query);
    
    const employees = result.rows.map(row => ({
      id: row.ID,
      emp_code: row.EMP_CODE,
      emp_name: row.EMP_NAME,
      is_admin: true, // All employees in this table are admins
      role: 'admin'
    }));

    console.log(`✅ Manage Role: Found ${employees.length} admin employees`);

    return NextResponse.json({
      success: true,
      employees,
      total: employees.length,
      note: 'Only admin employees are returned (those in MIS_ACCESS_CONTROL table)'
    });

  } catch (error) {
    console.error('❌ Manage Role: Error fetching employees:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch employees',
        details: error.message 
      },
      { status: 500 }
    );
  }
}

// DELETE - Remove employee from access control
export async function DELETE(request) {
  try {
    console.log('🔐 Manage Role: Removing employee from access control...');
    
    // Validate admin access
    const adminValidation = await validateAdminAccess(request);
    if (!adminValidation.isValid) {
      return NextResponse.json(
        { success: false, error: adminValidation.error },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const emp_code = searchParams.get('emp_code');

    if (!emp_code) {
      return NextResponse.json(
        { success: false, error: 'Employee code is required' },
        { status: 400 }
      );
    }

    const adminUser = adminValidation.authResult.employee_code;
    console.log('🔐 Manage Role: Removing employee:', emp_code, 'by admin:', adminUser);

    const deleteQuery = `
      DELETE FROM MIS_ACCESS_CONTROL 
      WHERE EMP_CODE = :emp_code
    `;
    
    const result = await executeQuery(deleteQuery, [emp_code]);
    
    console.log('✅ Manage Role: Employee removed from access control');

    return NextResponse.json({
      success: true,
      message: `Employee ${emp_code} removed from access control`,
      emp_code
    });

  } catch (error) {
    console.error('❌ Manage Role: Error removing employee:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to remove employee',
        details: error.message 
      },
      { status: 500 }
    );
  }
}
