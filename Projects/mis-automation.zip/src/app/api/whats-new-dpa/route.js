import { NextRequest } from 'next/server';
import { verifyAnyToken } from '@/lib/jwt';
import { executeQuery } from '@/lib/db';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// OCI PAR URL for What's New At DPA images
// The PAR URL should include the folder path (e.g., .../new-at-dpa/)
const OCI_NEW_AT_DPA_PAR_URL = process.env.OCI_NEW_AT_DPA_PAR_URL || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/bmexgnkisxsv/bucket_dev_dpa_mis_automation/new-at-dpa/';

// Helper function to normalize filename (lowercase, spaces to dashes)
function normalizeFilename(filename) {
  if (!filename) return null;
  return filename
    .toLowerCase()
    .replace(/\s+/g, '-') // Replace spaces with dashes
    .replace(/[^a-z0-9.-]/g, '') // Remove special characters except dots and dashes
    .replace(/--+/g, '-') // Replace multiple dashes with single dash
    .replace(/^-+|-+$/g, ''); // Remove leading/trailing dashes
}

// Helper function to generate OCI file URL
function generateOciFileUrl(filename) {
  if (!filename) return null;
  
  // Generate URL in the exact format that works everywhere
  // Format: https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/new-at-dpa%2Ffilename.png
  const baseUrl = 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o';
  const encodedFolderPath = 'new-at-dpa%2F'; // Pre-encoded folder path
  
  return `${baseUrl}/${encodedFolderPath}${filename}`;
}

// Helper function to validate file
function validateFile(file) {
  if (!file) {
    throw new Error('File is required');
  }

  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
  if (!allowedTypes.includes(file.type)) {
    throw new Error('Only image files (JPEG, PNG, GIF, WebP) are allowed');
  }

  const maxFileSize = 1 * 1024 * 1024; // 1MB in bytes
  if (file.size > maxFileSize) {
    throw new Error(`File size exceeds the 1MB limit. Current size: ${(file.size / 1024 / 1024).toFixed(2)}MB`);
  }
}

// Helper function to generate filename
function generateFilename(file, customName) {
  if (customName) {
    const normalizedName = normalizeFilename(customName);
    const extension = file.name.split('.').pop().toLowerCase();
    return `${normalizedName}.${extension}`;
  }
  
  const originalName = file.name.split('.').slice(0, -1).join('.');
  const extension = file.name.split('.').pop().toLowerCase();
  const normalizedName = normalizeFilename(originalName);
  return `${normalizedName}.${extension}`;
}

// Helper function to upload file to OCI
async function uploadToOCI(file, filename) {
  // Use PAR URL for upload
  const ociUrl = OCI_NEW_AT_DPA_PAR_URL;
  if (!ociUrl) {
    throw new Error('OCI PAR URL not configured for new-at-dpa uploads');
  }

  // Check if PAR URL already includes the folder path
  const folderPath = 'new-at-dpa/';
  let uploadUrl;
  
  if (ociUrl.includes(folderPath)) {
    // PAR URL already includes the folder path, just append filename
    uploadUrl = ociUrl.endsWith('/') ? ociUrl + filename : ociUrl + '/' + filename;
  } else {
    // PAR URL doesn't include folder path, add it
    const baseUrl = ociUrl.endsWith('/') ? ociUrl : ociUrl + '/';
    uploadUrl = baseUrl + folderPath + filename;
  }

  console.log('🔍 Upload Debug Info:');
  console.log('  - OCI PAR URL:', ociUrl);
  console.log('  - Filename:', filename);
  console.log('  - Full Upload URL:', uploadUrl);
  console.log('  - Original filename:', file.name);
  console.log('  - File size:', file.size, 'bytes');
  console.log('  - File type:', file.type);

  try {
    console.log('🚀 Starting OCI upload...');
    const uploadResponse = await fetch(uploadUrl, {
      method: 'PUT',
      body: file,
      headers: {
        'Content-Type': file.type,
      }
    });

    console.log('📡 OCI Upload Response:');
    console.log('  - Status:', uploadResponse.status);
    console.log('  - Status Text:', uploadResponse.statusText);

    if (!uploadResponse.ok) {
      const errorText = await uploadResponse.text();
      console.error('❌ OCI Upload Error Response:', errorText);
      throw new Error(`OCI upload failed: ${uploadResponse.status} - ${uploadResponse.statusText}. Response: ${errorText}`);
    }

    console.log(`✅ File uploaded to OCI: ${filename}`);
  } catch (uploadError) {
    console.error('❌ OCI upload error:', uploadError);
    throw uploadError;
  }
}

// Helper function to save file to database
async function saveToDatabase(filename, file) {
  const insertQuery = `
    INSERT INTO whats_new_dpa_images 
    (filename, original_name, file_size, file_type) 
    VALUES (:1, :2, :3, :4)
  `;

  console.log('About to save to database with values:', {
    filename: filename,
    originalName: file.name,
    fileSize: file.size,
    fileType: file.type
  });

  try {
    await executeQuery(insertQuery, [filename, file.name, file.size, file.type]);
    console.log('✅ File saved to database successfully');
  } catch (dbError) {
    console.error('❌ Database insert error:', dbError);
    console.error('Error details:', {
      message: dbError.message,
      stack: dbError.stack
    });
    // If duplicate key error, that's okay - file already exists in DB
    if (dbError.message && dbError.message.includes('unique')) {
      console.log('Duplicate filename detected, continuing...');
    } else {
      throw dbError; // Re-throw if it's not a duplicate error
    }
  }
}

// GET - List all images in the What's New At DPA folder
export async function GET(request) {
  try {
    // Verify authentication using Bearer token only
    const authResult = await verifyAnyToken(request);
    if (!authResult.isValid) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    console.log('✅ Authentication successful for user:', authResult.userId);

    // Get all images from database
    const query = `
      SELECT 
        filename,
        original_name,
        file_size,
        file_type,
        uploaded_at
      FROM whats_new_dpa_images 
      ORDER BY uploaded_at DESC
    `;

    const results = await executeQuery(query);
    console.log('📊 Database query results:', results);
    console.log('📊 Results type:', typeof results);
    console.log('📊 Is array:', Array.isArray(results));

    // Handle different result formats
    let rows = [];
    if (results && results.rows) {
      rows = results.rows;
      console.log('📊 Using results.rows, count:', rows.length);
    } else if (Array.isArray(results)) {
      rows = results;
      console.log('📊 Using results directly, count:', rows.length);
    } else {
      console.error('❌ Unexpected results format:', results);
      rows = [];
    }

    // Transform database results to API format
    const images = rows.map(row => {
      // Handle both uppercase and lowercase column names
      const filename = row.FILENAME || row.filename;
      const originalName = row.ORIGINAL_NAME || row.original_name || filename;
      const fileSize = row.FILE_SIZE || row.file_size || 0;
      const fileType = row.FILE_TYPE || row.file_type || 'image/jpeg';
      const uploadedAt = row.UPLOADED_AT || row.uploaded_at;

      // Always generate the correct URL format
      const correctUrl = generateOciFileUrl(filename);
      
      console.log(`🖼️ Processing image: ${filename}`);
      console.log(`   Generated URL: ${correctUrl}`);

      return {
        filename: filename,
        url: correctUrl,
        originalName: originalName,
        fileSize: fileSize,
        fileType: fileType,
        uploadedAt: uploadedAt
      };
    });

    return new Response(JSON.stringify({
      success: true,
      images: images,
      baseUrl: 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o'
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Error listing images:', error);
    return new Response(JSON.stringify({
      error: `Failed to list images: ${error.message}`
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
}

// POST - Upload a new image to What's New At DPA folder
export async function POST(request) {
  try {
    // Verify authentication using Bearer token only
    const authResult = await verifyAnyToken(request);
    if (!authResult.isValid) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    console.log('✅ Authentication successful for POST, user:', authResult.userId);

    const formData = await request.formData();
    const file = formData.get('file');
    const customName = formData.get('customName'); // Optional custom name

    // Validate file
    try {
      validateFile(file);
    } catch (validationError) {
      return new Response(JSON.stringify({
        error: validationError.message
      }), { status: 400 });
    }

    // Generate filename
    const filename = generateFilename(file, customName);

    // Upload to OCI
    try {
      await uploadToOCI(file, filename);
    } catch (uploadError) {
      console.error('OCI upload error:', uploadError);
      return new Response(JSON.stringify({
        error: `Failed to upload file to OCI: ${uploadError.message}`
      }), { status: 500 });
    }

    // Save to database
    await saveToDatabase(filename, file);

    const imageUrl = generateOciFileUrl(filename);

    return new Response(JSON.stringify({
      success: true,
      message: 'Image uploaded successfully',
      filename: filename,
      url: imageUrl,
      originalName: file.name,
      fileSize: file.size,
      fileType: file.type
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Error uploading file:', error);
    return new Response(JSON.stringify({
      error: `Failed to upload file: ${error.message}`
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
}

// PATCH - Add existing images to the database
export async function PATCH(request) {
  try {
    // Verify authentication using Bearer token only
    const authResult = await verifyAnyToken(request);
    if (!authResult.isValid) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    console.log('✅ Authentication successful for PATCH, user:', authResult.userId);

    const body = await request.json();
    const { images } = body;

    if (!images || !Array.isArray(images)) {
      return new Response(JSON.stringify({
        error: 'Images array is required'
      }), { status: 400 });
    }

    let addedCount = 0;

    // Add each image to database - simple INSERT (Oracle syntax)
    for (const image of images) {
      try {
        const insertQuery = `
          INSERT INTO whats_new_dpa_images 
          (filename, original_name, file_size, file_type) 
          VALUES (:1, :2, :3, :4)
        `;

        await executeQuery(insertQuery, [
          image.filename,
          image.originalName || image.filename,
          image.fileSize || 0,
          image.fileType || 'image/jpeg'
        ]);

        addedCount++;
      } catch (error) {
        // If duplicate key error, that's okay
        console.log(`Image ${image.filename} already exists in database`);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Images added to database',
      addedCount: addedCount
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Error adding images:', error);
    return new Response(JSON.stringify({
      error: `Failed to add images: ${error.message}`
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
}

// DELETE - Delete an image from database
export async function DELETE(request) {
  try {
    // Verify authentication using Bearer token only
    const authResult = await verifyAnyToken(request);
    if (!authResult.isValid) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    console.log('✅ Authentication successful for DELETE, user:', authResult.userId);

    // Get filename from request body instead of query parameters
    const body = await request.json();
    const { filename } = body;

    // Input validation for filename
    if (!filename) {
      return new Response(JSON.stringify({
        error: 'Filename is required in request body'
      }), { status: 400 });
    }

    // Validate filename format and length
    if (typeof filename !== 'string' || filename.length > 255) {
      return new Response(JSON.stringify({
        error: 'Invalid filename format or length'
      }), { status: 400 });
    }

    // Sanitize filename to prevent injection attacks
    const sanitizedFilename = filename.trim().replace(/[^a-zA-Z0-9\-_\.]/g, '');
    if (sanitizedFilename !== filename) {
      return new Response(JSON.stringify({
        error: 'Filename contains invalid characters'
      }), { status: 400 });
    }

    // Remove from database (Oracle syntax)
    const deleteQuery = `DELETE FROM whats_new_dpa_images WHERE filename = :1`;
    await executeQuery(deleteQuery, [sanitizedFilename]);

    return new Response(JSON.stringify({
      success: true,
      message: 'Image deleted from database'
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Error deleting image:', error);
    return new Response(JSON.stringify({
      error: `Failed to delete image: ${error.message}`
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
}
