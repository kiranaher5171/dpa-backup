"use client";
import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import BasicLayout from '../layouts/BasicLayout'
import { useEmployeeStore } from '@/store/employeeStore';
import { useRoleAccess } from '@/hooks/useRoleAccess';
import { useRouter } from 'next/navigation';
import {
    Container,
    Skeleton,
    Typography,
    Grid,
    Card,
    CardContent,
    TextField,
    InputAdornment,
    Button,
    Chip,
    Alert,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Snackbar
} from '@mui/material';
import { Search, Add, ArrowBack, Delete } from '@mui/icons-material';
import { CircularProgress } from '@mui/material';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import NewReleasesOutlinedIcon from '@mui/icons-material/NewReleasesOutlined';
import { BsPatchQuestion } from "react-icons/bs";
import PeopleIcon from '@mui/icons-material/People';
import AddNewTemplate from './AddNewTemplate';
import MISRaisedRequests from "./MISRaisedRequests";
import TemplatesTable from './TemplatesTable';
import TemplateAccessRequests from './TemplateAccessRequests';

// Lazy load child components for better performance
const WhatsNewAtDPA = React.lazy(() => import('./WhatsNewAtDPA'));

// Loading fallback component
const ComponentLoader = () => (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
        <Skeleton variant="circular" width={40} height={40} />
    </Box>
);

// MIS Directory Skeleton Component
const MISDirectorySkeleton = () => (
    <BasicLayout>
        <Box className="fit-content-box">
            {/* Tabs Skeleton */}
            <Box className="sticky-tabs" mb={4}>
                <Container maxWidth>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                        <Box display="flex" gap={2}>
                            {[...Array(3)].map((_, index) => (
                                <Box key={index} sx={{ flex: 1, textAlign: 'center' }}>
                                    <Skeleton variant="circular" width={24} height={24} sx={{ mx: 'auto', mb: 1 }} />
                                    <Skeleton variant="text" width="80%" height={20} sx={{ mx: 'auto' }} />
                                </Box>
                            ))}
                        </Box>
                    </Box>
                </Container>
            </Box>

            {/* Content Skeleton */}
            <Container maxWidth>
                <Box>
                    {/* Header Skeleton */}
                    <Box mb={3}>
                        <Skeleton variant="text" width="60%" height={40} />
                        <Skeleton variant="text" width="40%" height={24} sx={{ mt: 1 }} />
                    </Box>

                    {/* Cards/Content Skeleton */}
                    <Box>
                        <Grid container spacing={3}>
                            {[...Array(6)].map((_, index) => (
                                <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} key={index}>
                                    <Box sx={{
                                        border: '1px solid #e0e0e0',
                                        borderRadius: 2,
                                        p: 2,
                                        height: 200
                                    }}>
                                        <Skeleton variant="rectangular" width="100%" height={120} sx={{ borderRadius: 1, mb: 2 }} />
                                        <Skeleton variant="text" width="80%" height={24} />
                                        <Skeleton variant="text" width="60%" height={20} sx={{ mt: 1 }} />
                                    </Box>
                                </Grid>
                            ))}
                        </Grid>
                    </Box>
                </Box>
            </Container>
        </Box>
    </BasicLayout>
);

function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && <Box sx={{ pt: 0, pb: 0 }}>{children}</Box>}
        </div>
    );
}

CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

// MIS Templates Management Component
const MISManagement = () => {
    const { employeeDetails } = useEmployeeStore();
    const [templates, setTemplates] = React.useState([]);
    const [clients, setClients] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    // Fetch all MIS templates and clients
    React.useEffect(() => {
        const fetchData = async () => {
            if (!employeeDetails) return;

            try {
                setLoading(true);

                // Get authentication token
                const session = localStorage.getItem('session');
                let accessToken = '';
                if (session) {
                    try {
                        const sessionData = JSON.parse(session);
                        accessToken = sessionData.accessToken || '';
                    } catch (parseError) {
                        console.error('Error parsing session data:', parseError);
                    }
                }

                const headers = {
                    'Content-Type': 'application/json'
                };

                // Add Authorization header if we have a token
                if (accessToken) {
                    headers['Authorization'] = `Bearer ${accessToken}`;
                }

                // Fetch all templates
                let templatesResponse;
                try {
                    console.log('🔍 Fetching templates from /api/client-mis-templates');
                    console.log('🔍 Headers being sent:', headers);
                    templatesResponse = await fetch('/api/client-mis-templates', {
                        headers: headers
                    });
                    console.log('🔍 Templates response status:', templatesResponse?.status);
                    console.log('🔍 Templates response ok:', templatesResponse?.ok);
                } catch (fetchError) {
                    console.error('❌ Network error fetching templates:', fetchError);
                    console.error('❌ Fetch error details:', {
                        message: fetchError.message,
                        name: fetchError.name,
                        stack: fetchError.stack
                    });
                    templatesResponse = null;
                }

                if (templatesResponse && templatesResponse.ok) {
                    const templatesData = await templatesResponse.json();
                    console.log('📋 Templates loaded:', templatesData.templates || []);
                    console.log('📋 Template access data check:', templatesData.templates?.map(t => ({
                        id: t.ID,
                        name: t.TEMPLATE_NAME,
                        access: t.TEMPLATE_ACCESS_EMP_NAMES,
                        accessCount: t.TEMPLATE_ACCESS_EMP_NAMES ? t.TEMPLATE_ACCESS_EMP_NAMES.split(',').filter(name => name.trim()).length : 0
                    })));
                    setTemplates(templatesData.templates || []);
                } else if (templatesResponse) {
                    console.error('Failed to fetch templates:', templatesResponse.status, templatesResponse.statusText);
                    try {
                        const errorData = await templatesResponse.json();
                        console.error('Error details:', errorData);
                        console.error('Error message:', errorData.error);
                        console.error('Error code:', errorData.code);
                        console.error('Error details field:', errorData.details);
                    } catch (jsonError) {
                        console.error('Failed to parse error response as JSON:', jsonError);
                        const errorText = await templatesResponse.text();
                        console.error('Raw error response:', errorText);
                    }
                    
                    // Set user-friendly error message for 500 errors
                    if (templatesResponse.status === 500) {
                        setApiError('Server error: Unable to load templates. Please try refreshing the page or contact support if the issue persists.');
                    } else {
                        setApiError(`Failed to load templates (${templatesResponse.status}): ${templatesResponse.statusText}`);
                    }
                } else {
                    console.warn('⚠️ Templates fetch failed due to network error');
                    setApiError('Network error: Unable to connect to the server. Please check your internet connection and try again.');
                }

                // Fetch SSO clients for filtering
                let ssoClientsResponse;
                try {
                    ssoClientsResponse = await fetch(process.env.NEXT_PUBLIC_SSO_GET_ALL_CLIENTS || 'https://api-timesheet.decimalpointanalytics.com/master/clients/', {
                        headers: headers
                    });
                } catch (fetchError) {
                    console.error('❌ Network error fetching SSO clients:', fetchError);
                    ssoClientsResponse = null;
                }

                if (ssoClientsResponse && ssoClientsResponse.ok) {
                    const ssoClientsData = await ssoClientsResponse.json();
                    // Convert to array format for autocomplete
                    const clientsArray = Object.values(ssoClientsData).filter(item =>
                        typeof item === 'object' && item && item.id && item.display_name
                    );
                    console.log('👥 SSO Clients loaded:', clientsArray);
                    setClients(clientsArray);
                } else if (ssoClientsResponse) {
                    console.error('Failed to fetch SSO clients:', ssoClientsResponse.status, ssoClientsResponse.statusText);
                } else {
                    console.warn('⚠️ SSO clients fetch failed due to network error');
                }

            } catch (error) {
                console.error('Error fetching data:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [employeeDetails]);

    // Function to handle template deletion
    const handleDeleteTemplate = async (template) => {
        try {
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json',
            };
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch('/api/client-mis-templates', {
                method: 'DELETE',
                headers: headers,
                body: JSON.stringify({ id: template.ID })
            });

            if (response.ok) {
                // Remove the template from the local state
                setTemplates(prev => prev.filter(t => t.ID !== template.ID));
                return true;
            } else {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to delete template');
            }
        } catch (error) {
            console.error('Error deleting template:', error);
            throw error;
        }
    };

    // Function to refresh data
    const handleRefresh = () => {
        const fetchData = async () => {
            if (!employeeDetails) return;

            try {
                setLoading(true);

                const session = localStorage.getItem('session');
                let accessToken = '';
                if (session) {
                    try {
                        const sessionData = JSON.parse(session);
                        accessToken = sessionData.accessToken || '';
                    } catch (parseError) {
                        console.error('Error parsing session data:', parseError);
                    }
                }

                const headers = {
                    'Content-Type': 'application/json'
                };

                if (accessToken) {
                    headers['Authorization'] = `Bearer ${accessToken}`;
                }

                const templatesResponse = await fetch('/api/client-mis-templates', {
                    headers: headers
                });

                if (templatesResponse && templatesResponse.ok) {
                    const templatesData = await templatesResponse.json();
                    console.log('📋 Templates refreshed:', templatesData.templates?.map(t => ({
                        id: t.ID,
                        name: t.TEMPLATE_NAME,
                        access: t.TEMPLATE_ACCESS_EMP_NAMES,
                        accessCount: t.TEMPLATE_ACCESS_EMP_NAMES ? t.TEMPLATE_ACCESS_EMP_NAMES.split(',').filter(name => name.trim()).length : 0
                    })));
                    setTemplates(templatesData.templates || []);
                }
            } catch (error) {
                console.error('Error refreshing data:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    };

    return (
        <Box>
            <TemplatesTable
                templates={templates}
                clients={clients}
                loading={loading}
                onRefresh={handleRefresh}
                onDelete={handleDeleteTemplate}
            />
        </Box>
    );
};

const page = () => {
    const router = useRouter();
    const { isAdmin, isUser } = useRoleAccess();
    const { employeeDetails } = useEmployeeStore();
    const [isInitializing, setIsInitializing] = React.useState(false);

    // Get the last selected tab from localStorage, default to 0 if not found
    const getInitialTab = () => {
        if (typeof window !== 'undefined') {
            const savedTab = localStorage.getItem('misDirectorySelectedTab');
            return savedTab ? parseInt(savedTab, 10) : 0;
        }
        return 0;
    };

    const [value, setValue] = React.useState(getInitialTab);

    const handleChange = (event, newValue) => {
        setValue(newValue);
        // Save the selected tab to localStorage
        if (typeof window !== 'undefined') {
            localStorage.setItem('misDirectorySelectedTab', newValue.toString());
        }
    };

    // Check for session and authentication on component mount
    React.useEffect(() => {
        console.log('🔐 Document Directory: Component mounted, checking session...');

        const sessionData = localStorage.getItem("session");
        if (!sessionData) {
            console.log('🔐 Document Directory: No session found, redirecting to login');
            router.push('/auth/sso-login');
        } else {
            // If we have a session but no employee details, we might be initializing
            if (!employeeDetails) {
                console.log('🔐 Document Directory: Session found but no employee details, might be initializing...');
                setIsInitializing(true);
            } else {
                // Employee details are loaded, stop initializing
                setIsInitializing(false);
            }
        }
    }, [employeeDetails]);

    // Show loading skeleton if no employee details or if initializing
    if (!employeeDetails || isInitializing) {
        console.log('🔐 Document Directory: No employee details or initializing, showing skeleton');
        return <MISDirectorySkeleton />;
    }

    // Check if user is not admin - prevent access
    if (!isAdmin()) {
        return (
            <BasicLayout>
                <Container maxWidth="xl" sx={{ pt: '64px' }}>
                    <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh" flexDirection="column" gap={3}>
                        <Alert severity="error" sx={{ maxWidth: 600 }}>
                            <Typography variant="h6" gutterBottom>
                                Access Denied
                            </Typography>
                            <Typography variant="body1">
                                This page is only accessible to admin users. Regular users cannot access the Document Directory.
                            </Typography>
                        </Alert>
                        <Button
                            variant="outlined"
                            startIcon={<ArrowBack />}
                            onClick={() => router.push('/main-dashboard')}
                        >
                            Back to Dashboard
                        </Button>
                    </Box>
                </Container>
            </BasicLayout>
        );
    }

    return (
        <>
            <BasicLayout>
                <Box className="fit-content-box">
                    <Box className="sticky-tabs" mb={4}>
                        <Container maxWidth>
                            <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
                                <Tab
                                    label="Manage MIS Templates"
                                    icon={<AssignmentOutlinedIcon />}
                                    iconPosition="top"
                                    {...a11yProps(0)} />
                                <Tab
                                    label="What's New at DPA"
                                    icon={<NewReleasesOutlinedIcon />}
                                    iconPosition="top"
                                    {...a11yProps(1)} />
                                <Tab
                                    label="New Template Requests"
                                    icon={<BsPatchQuestion />}
                                    iconPosition="top"
                                    {...a11yProps(2)} />
                                <Tab
                                    label="Template Access Requests"
                                    icon={<PeopleIcon />}
                                    iconPosition="top"
                                    {...a11yProps(3)} />
                            </Tabs>
                        </Container>
                    </Box>

                    <CustomTabPanel value={value} index={0}>
                        <MISManagement />
                    </CustomTabPanel>

                    <CustomTabPanel value={value} index={1}>
                        <React.Suspense fallback={<ComponentLoader />}>
                            <WhatsNewAtDPA />
                        </React.Suspense>
                    </CustomTabPanel>
                    <CustomTabPanel value={value} index={2}>
                        <MISRaisedRequests />
                    </CustomTabPanel>
                    <CustomTabPanel value={value} index={3}>
                        <TemplateAccessRequests />
                    </CustomTabPanel>
                </Box>
            </BasicLayout>
        </>
    )
}

export default page