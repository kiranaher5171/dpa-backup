'use client'
import React, { useState, useEffect } from 'react'
import {
    Card,
    CardContent,
    Typography,
    Grid,
    Box,
    Chip,
    Button,
    TextField,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    CircularProgress,
    Snackbar,
    Alert,
    Container,
    Avatar,
    IconButton,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Autocomplete,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    TablePagination,
    InputAdornment
} from '@mui/material'
import {
    Business,
    Person,
    CalendarToday,
    Update,
    Save,
    Cancel,
    Description,
    Search,
    FilterList
} from '@mui/icons-material'
import { useEmployeeStore } from '@/store/employeeStore'

const MISRaisedRequests = () => {
    const { employeeDetails, userRole } = useEmployeeStore()

    // States
    const [requests, setRequests] = useState([])
    const [originalRequests, setOriginalRequests] = useState([]) // Keep original data for sorting
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)
    const [updatingRequest, setUpdatingRequest] = useState(null)
    const [isUpdating, setIsUpdating] = useState(false)

    // Search and filter states
    const [searchQuery, setSearchQuery] = useState('')
    const [statusFilter, setStatusFilter] = useState('')
    const [page, setPage] = useState(0)
    const [rowsPerPage, setRowsPerPage] = useState(10)

    // Track changes for save button state
    const [requestChanges, setRequestChanges] = useState({})

    // Snackbar states
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'info'
    })

    // Status options with proper flow
    const statusOptions = [
        { value: 'open', label: 'Open', order: 1 },
        { value: 'in_progress', label: 'In Progress', order: 2 },
        { value: 'approved', label: 'Approved', order: 3 },
        { value: 'rejected', label: 'Rejected', order: 3 },
        { value: 'completed', label: 'Completed', order: 4 }
    ]

    // Snackbar handlers
    const showSnackbar = (message, severity = 'info') => {
        setSnackbar({
            open: true,
            message,
            severity
        })
    }

    const handleCloseSnackbar = () => {
        setSnackbar(prev => ({
            ...prev,
            open: false
        }))
    }

    // Fetch all requests
    const fetchAllRequests = async () => {
        try {
            setLoading(true)
            setError(null)

            console.log('🔄 Fetching all MIS template requests...')

            // Get authentication token from localStorage
            const session = localStorage.getItem('session')
            let accessToken = ''

            if (session) {
                try {
                    const sessionData = JSON.parse(session)
                    accessToken = sessionData.accessToken || ''
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError)
                }
            }

            if (!accessToken) {
                setError('No authentication token available')
                console.error('❌ No access token available')
                return
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }

            const response = await fetch('/api/raise-template-request/get-all-requests', {
                headers: headers
            })

            console.log('📡 Response status:', response.status)

            if (response.ok) {
                const data = await response.json()
                console.log('📊 All requests data:', data)
                setRequests(data.requests || [])
                setOriginalRequests(data.requests || []) // Keep original data for sorting
                console.log('✅ All requests loaded:', data.requests?.length || 0)
            } else {
                const errorData = await response.json()
                console.error('❌ Failed to fetch requests:', errorData)
                setError(errorData.error || 'Failed to fetch requests')
            }
        } catch (error) {
            console.error('❌ Error fetching requests:', error)
            setError('Error connecting to requests service')
        } finally {
            setLoading(false)
        }
    }

    // Update request status and admin comment
    const updateRequest = async (requestId, status, adminComment) => {
        try {
            setIsUpdating(true)
            setUpdatingRequest(requestId)

            console.log('🔄 Updating request:', { requestId, status, adminComment })

            // Get authentication token from localStorage
            const session = localStorage.getItem('session')
            let accessToken = ''

            if (session) {
                try {
                    const sessionData = JSON.parse(session)
                    accessToken = sessionData.accessToken || ''
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError)
                }
            }

            if (!accessToken) {
                showSnackbar('No authentication token available', 'error')
                return
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }

            const requestBody = {
                status: status,
                adminComment: adminComment || null
            }

            const response = await fetch(`/api/raise-template-request/${requestId}/update-status`, {
                method: 'PUT',
                headers: headers,
                body: JSON.stringify(requestBody)
            })

            console.log('📡 Update response status:', response?.status)
            console.log('📡 Update response:', response)

            if (response && response.ok) {
                const result = await response.json()
                console.log('✅ Request updated successfully:', result)

                // Show success message with email notification info
                // COMMENTED OUT FOR TESTING - Email notification messages disabled
                // const emailMessage = result.emailSent ?
                //     'Request status updated successfully! Email notification sent to requestor.' :
                //     'Request status updated successfully!'
                // showSnackbar(emailMessage, 'success')

                // For testing purposes - simple success message without email confirmation
                showSnackbar('Request status updated successfully!', 'success')

                // Update the local state
                setRequests(prevRequests =>
                    prevRequests.map(req =>
                        req.ID === requestId
                            ? {
                                ...req,
                                STATUS: status,
                                ADMIN_COMMENT: adminComment,
                                ADMIN_UPDATED_AT: new Date().toISOString()
                            }
                            : req
                    )
                )

                // Update original requests for sorting
                setOriginalRequests(prevRequests =>
                    prevRequests.map(req =>
                        req.ID === requestId
                            ? {
                                ...req,
                                STATUS: status,
                                ADMIN_COMMENT: adminComment,
                                ADMIN_UPDATED_AT: new Date().toISOString()
                            }
                            : req
                    )
                )

                setUpdatingRequest(null)
            } else if (response) {
                const errorData = await response.json()
                throw new Error(errorData.error || 'Failed to update request')
            } else {
                throw new Error('No response received from server')
            }
        } catch (error) {
            console.error('❌ Error updating request:', error)
            showSnackbar(`Failed to update request: ${error.message}`, 'error')
        } finally {
            setIsUpdating(false)
            setUpdatingRequest(null)
        }
    }

    // Handle status change
    const handleStatusChange = (requestId, newStatus) => {
        setRequests(prevRequests =>
            prevRequests.map(req =>
                req.ID === requestId
                    ? { ...req, STATUS: newStatus }
                    : req
            )
        )

        // Track changes for save button
        setRequestChanges(prev => ({
            ...prev,
            [requestId]: {
                ...prev[requestId],
                statusChanged: true
            }
        }))
    }

    // Handle admin comment change
    const handleCommentChange = (requestId, newComment) => {
        setRequests(prevRequests =>
            prevRequests.map(req =>
                req.ID === requestId
                    ? { ...req, ADMIN_COMMENT: newComment }
                    : req
            )
        )

        // Track changes for save button
        setRequestChanges(prev => ({
            ...prev,
            [requestId]: {
                ...prev[requestId],
                commentChanged: true
            }
        }))
    }

    // Handle save changes
    const handleSaveChanges = async (request) => {
        await updateRequest(request.ID, request.STATUS, request.ADMIN_COMMENT)

        // Clear changes tracking for this request
        setRequestChanges(prev => {
            const newChanges = { ...prev }
            delete newChanges[request.ID]
            return newChanges
        })
    }

    // Handle cancel changes
    const handleCancelChanges = () => {
        setUpdatingRequest(null)
        // Refresh the data to reset any changes
        fetchAllRequests()
    }

    // Check if request has changes
    const hasChanges = (requestId) => {
        const changes = requestChanges[requestId]
        return changes && (changes.statusChanged || changes.commentChanged)
    }

    // Get status color
    const getStatusColor = (status) => {
        switch (status) {
            case 'approved': return 'success'
            case 'rejected': return 'error'
            case 'in_progress': return 'warning'
            case 'completed': return 'primary'
            case 'open':
            default: return 'default'
        }
    }

    // Get status display text
    const getStatusDisplayText = (status) => {
        const statusOption = statusOptions.find(option => option.value === status)
        return statusOption ? statusOption.label : status.charAt(0).toUpperCase() + status.slice(1)
    }

    // Get status option by value
    const getStatusOption = (status) => {
        return statusOptions.find(option => option.value === status) || statusOptions[0]
    }

    // Get available next statuses based on current status
    const getAvailableStatuses = (currentStatus) => {
        const currentOrder = statusOptions.find(option => option.value === currentStatus)?.order || 1

        // Allow moving to next step or staying at current step
        return statusOptions.filter(option => option.order >= currentOrder)
    }

    // Filter and sort requests
    const filteredAndSortedRequests = React.useMemo(() => {
        // Use originalRequests for sorting to prevent UI changes from affecting sort order
        let filtered = originalRequests

        // Apply search filter
        if (searchQuery.trim()) {
            const query = searchQuery.toLowerCase()
            filtered = filtered.filter(request =>
                request.MIS_REQ_CLIENT_NAME?.toLowerCase().includes(query) ||
                request.REQUESTOR_NAME?.toLowerCase().includes(query) ||
                request.EMPLOYEE_CODE?.toLowerCase().includes(query) ||
                request.MIS_REQ_INVOICE_ID?.toLowerCase().includes(query) ||
                request.REQUEST_COMMENT?.toLowerCase().includes(query) ||
                request.ADMIN_COMMENT?.toLowerCase().includes(query)
            )
        }

        // Apply status filter
        if (statusFilter) {
            filtered = filtered.filter(request => request.STATUS === statusFilter)
        }

        // Sort by status: open at top, completed at bottom
        // Use original status for sorting, not the temporary UI changes
        return filtered.sort((a, b) => {
            const statusOrder = { 'open': 1, 'in_progress': 2, 'approved': 3, 'rejected': 3, 'completed': 4 }
            const aOrder = statusOrder[a.STATUS] || 5
            const bOrder = statusOrder[b.STATUS] || 5

            if (aOrder !== bOrder) {
                return aOrder - bOrder
            }

            // If same status, sort by creation date (newest first)
            return new Date(b.CREATED_AT) - new Date(a.CREATED_AT)
        })
    }, [originalRequests, searchQuery, statusFilter])

    // Get display data that merges original data with temporary UI changes
    const getDisplayData = React.useMemo(() => {
        return filteredAndSortedRequests.map(originalRequest => {
            // Check if this request has temporary changes
            const tempRequest = requests.find(req => req.ID === originalRequest.ID)
            if (tempRequest) {
                // Return the request with temporary changes for display
                return tempRequest
            }
            // Return original request if no temporary changes
            return originalRequest
        })
    }, [filteredAndSortedRequests, requests])

    // Get paginated requests
    const paginatedRequests = React.useMemo(() => {
        const startIndex = page * rowsPerPage
        return getDisplayData.slice(startIndex, startIndex + rowsPerPage)
    }, [getDisplayData, page, rowsPerPage])

    // Handle page change
    const handleChangePage = (event, newPage) => {
        setPage(newPage)
    }

    // Handle rows per page change
    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10))
        setPage(0)
    }

    // Fetch data on component mount
    useEffect(() => {
        if (employeeDetails) {
            fetchAllRequests()
        }
    }, [employeeDetails])

    // If not authenticated, show message
    if (!employeeDetails) {
        return (
            <Container maxWidth>
                <Box pt={8} px={3} display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                    <Typography>Please sign in to access the MIS Raised Requests.</Typography>
                </Box>
            </Container>
        )
    }

    return (
        <Container maxWidth>
            {/* Header Section */}
            <Box mb={3} display="flex" justifyContent="space-between" alignItems="flex-start">
                <Box>
                    <Typography variant="h4" className='page-heading'>
                        <Box className="decorator" /> MIS Raised Requests Management
                    </Typography>
                    <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                        Manage all template requests from users
                    </Typography>
                </Box>

                {/* Search and Filter Controls */}
                <Box display="flex" gap={2} alignItems="center" flexWrap="wrap">
                    <Box className="textfield auto-complete ph2">
                        <TextField
                            placeholder="Search requests..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            size="small"
                            sx={{ minWidth: 250 }}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <Search />
                                    </InputAdornment>
                                ),
                            }}
                        />
                    </Box>

                    <Box className="textfield auto-complete ph2">
                        <Autocomplete
                            options={statusOptions}
                            getOptionLabel={(option) => option.label}
                            value={statusOptions.find(option => option.value === statusFilter) || null}
                            onChange={(event, newValue) => {
                                setStatusFilter(newValue ? newValue.value : '')
                            }}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Filter by Status"
                                    size="small"
                                    sx={{ minWidth: 200 }}
                                />
                            )}
                            clearOnEscape
                            sx={{ minWidth: 200 }}
                        />
                    </Box>

                    <Button
                        variant="outlined"
                        onClick={fetchAllRequests}
                        disabled={loading}
                        startIcon={loading ? <CircularProgress size={20} /> : null}
                        sx={{ ml: 'auto' }}
                    >
                        {loading ? 'Refreshing...' : 'Refresh'}
                    </Button>
                </Box>
            </Box>



            {/* Error Display */}
            {error && (
                <Box mb={3}>
                    <Alert severity="error" onClose={() => setError(null)}>
                        {error}
                    </Alert>
                </Box>
            )}

            {/* Loading State */}
            {loading ? (
                <Box display="flex" justifyContent="center" alignItems="center" py={4}>
                    <CircularProgress size={40} />
                    <Typography variant="body1" sx={{ ml: 2 }}>
                        Loading MIS raised requests...
                    </Typography>
                </Box>
            ) : filteredAndSortedRequests.length === 0 ? (
                <Card sx={{ p: 4, textAlign: 'center' }}>
                    <Description sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                        {searchQuery || statusFilter ? 'No matching requests found' : 'No MIS raised requests found'}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        {searchQuery || statusFilter ? 'Try adjusting your search or filter criteria.' : 'There are currently no template requests to manage.'}
                    </Typography>
                </Card>
            ) : (
                /* Requests Table */
                <Box className="simple-table-card">
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                                    <TableCell><strong>Client Name</strong></TableCell>
                                    <TableCell><strong>Invoice ID</strong></TableCell>
                                    <TableCell><strong>Requestor</strong></TableCell>
                                    <TableCell><strong>Status</strong></TableCell>
                                    <TableCell><strong>Created Date</strong></TableCell>
                                    <TableCell><strong>User Comment</strong></TableCell>
                                    <TableCell><strong>Admin Comment</strong></TableCell>
                                    <TableCell><strong>Actions</strong></TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {paginatedRequests.map((request) => (
                                    <TableRow key={request.ID} hover>
                                        <TableCell>
                                            <Box display="flex" alignItems="center">
                                                <Avatar sx={{ mr: 2, bgcolor: 'primary.main', width: 32, height: 32 }}>
                                                    <Business fontSize="small" />
                                                </Avatar>
                                                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                                    {request.MIS_REQ_CLIENT_NAME}
                                                </Typography>
                                            </Box>
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2">
                                                {request.MIS_REQ_INVOICE_ID}
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Box>
                                                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                                    {request.REQUESTOR_NAME}
                                                </Typography>
                                                <Typography variant="caption" color="text.secondary">
                                                    {request.EMPLOYEE_CODE}
                                                </Typography>
                                            </Box>
                                        </TableCell>
                                        <TableCell>
                                            <Chip
                                                label={getStatusDisplayText(request.STATUS)}
                                                color={getStatusColor(request.STATUS)}
                                                variant="outlined"
                                                size="small"
                                            />
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2">
                                                {new Date(request.CREATED_AT).toLocaleDateString()}
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            {request.REQUEST_COMMENT ? (
                                                <Typography
                                                    variant="body2"
                                                    sx={{
                                                        maxWidth: 200,
                                                        overflow: 'hidden',
                                                        textOverflow: 'ellipsis',
                                                        whiteSpace: 'nowrap'
                                                    }}
                                                    title={request.REQUEST_COMMENT}
                                                >
                                                    {request.REQUEST_COMMENT}
                                                </Typography>
                                            ) : (
                                                <Typography variant="body2" color="text.secondary">
                                                    No comment
                                                </Typography>
                                            )}
                                        </TableCell>
                                        <TableCell>
                                            <Box className="textfield auto-complete ph2">
                                                <TextField
                                                    fullWidth
                                                    // multiline
                                                    // rows={0}
                                                    size="small"
                                                    label="Admin Comment"
                                                    placeholder={request.STATUS === 'completed' ? 'No comment' : 'Add comment...'}
                                                    value={request.ADMIN_COMMENT || ''}
                                                    onChange={(e) => handleCommentChange(request.ID, e.target.value)}
                                                    disabled={updatingRequest === request.ID || request.STATUS === 'completed'}
                                                    sx={{ minWidth: 200 }}
                                                />
                                            </Box>
                                        </TableCell>
                                        <TableCell>
                                            <Box display="flex" alignItems="center" gap={1} minWidth={200}>
                                                {/* Status Update */}
                                                <Box className="textfield auto-complete ph2 w100">
                                                    <Autocomplete
                                                        options={getAvailableStatuses(request.STATUS || 'open')}
                                                        getOptionLabel={(option) => option.label}
                                                        value={getStatusOption(request.STATUS || 'open')}
                                                        onChange={(event, newValue) => {
                                                            handleStatusChange(request.ID, newValue ? newValue.value : 'open')
                                                        }}
                                                        renderInput={(params) => (
                                                            <TextField
                                                                {...params}
                                                                label="Status"
                                                                size="small"
                                                                disabled={updatingRequest === request.ID}
                                                            />
                                                        )}
                                                        disableClearable
                                                        sx={{ flex: 1 }}
                                                    />
                                                </Box>

                                                {/* Save Button */}
                                                <IconButton
                                                    color="primary"
                                                    onClick={() => handleSaveChanges(request)}
                                                    disabled={updatingRequest === request.ID || !hasChanges(request.ID)}
                                                    sx={{
                                                        ml: 1,
                                                        opacity: hasChanges(request.ID) ? 1 : 0.5
                                                    }}
                                                >
                                                    {updatingRequest === request.ID ?
                                                        <CircularProgress size={20} /> :
                                                        <Save />
                                                    }
                                                </IconButton>
                                            </Box>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>

                        {/* Pagination */}
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25, 50]}
                            component="div"
                            count={filteredAndSortedRequests.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                            labelRowsPerPage="Rows per page:"
                            labelDisplayedRows={({ from, to, count }) =>
                                `${from}-${to} of ${count !== -1 ? count : `more than ${to}`}`
                            }
                        />
                    </TableContainer>
                </Box>
            )}

            {/* Snackbar for notifications */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Container>
    )
}

export default MISRaisedRequests

