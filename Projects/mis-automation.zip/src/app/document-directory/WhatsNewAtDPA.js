import React, { useState, useEffect } from 'react'
import {
    Autocomplete,
    TextField,
    Card,
    CardContent,
    Typography,
    Grid,
    Box,
    Chip,
    Button,
    Avatar,
    IconButton,
    Paper,
    Container,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    FormControl,
    Alert,
    CircularProgress,
    Stack,
    Divider,
    Snackbar,
    Skeleton
} from '@mui/material'
import SafeImage from '@/components/SafeImage'
import {
    Add as AddIcon,
    CloudUpload as CloudUploadIcon,
    Image as ImageIcon,
    Delete as DeleteIcon,
    Visibility as VisibilityIcon,
    Close as CloseIcon
} from '@mui/icons-material'
import { useEmployeeStore } from '@/store/employeeStore'

const WhatsNewAtDPA = () => {
    const { employeeDetails } = useEmployeeStore();
    const [images, setImages] = useState([]);
    const [loading, setLoading] = useState(true);

    const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [selectedFile, setSelectedFile] = useState(null);
    const [customName, setCustomName] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [addExistingDialogOpen, setAddExistingDialogOpen] = useState(false);
    const [existingImageList, setExistingImageList] = useState('');
    const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [imageToDelete, setImageToDelete] = useState(null);
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [snackbarSeverity, setSnackbarSeverity] = useState('success');

    // Admin-only page - no role checks needed

    // Fetch images data
    useEffect(() => {
        const fetchImages = async () => {
            if (!employeeDetails) return;

            try {
                setLoading(true);
                
                // Try to get token from localStorage first (for backward compatibility)
                const session = localStorage.getItem('session');
                let accessToken = '';

                if (session) {
                    try {
                        const sessionData = JSON.parse(session);
                        accessToken = sessionData.accessToken || '';
                    } catch (parseError) {
                        console.error('Error parsing session data:', parseError);
                    }
                }

                const headers = {
                    'Content-Type': 'application/json'
                };

                // Add Authorization header if we have a token
                if (accessToken) {
                    headers['Authorization'] = `Bearer ${accessToken}`;
                }

                const response = await fetch('/api/whats-new-dpa', {
                    headers: headers,
                    credentials: 'include' // Include cookies for fallback authentication
                });

                if (response.ok) {
                    const data = await response.json();
                    setImages(data.images || []);
                } else {
                    console.error('Failed to fetch images:', response.status, response.statusText);
                    const errorData = await response.json().catch(() => ({}));
                    console.error('Error details:', errorData);
                }
            } catch (error) {
                console.error('Error fetching images:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchImages();
    }, [employeeDetails]);

    const handleFileSelect = (event) => {
        const file = event.target.files[0];
        if (file) {
            // Validate file type
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            if (!allowedTypes.includes(file.type)) {
                setError('Please select a valid image file (JPEG, PNG, GIF, WebP)');
                return;
            }

            // Validate file size (max 1MB)
            const maxSize = 1 * 1024 * 1024; // 1MB
            if (file.size > maxSize) {
                setError('File size must be less than 1MB');
                return;
            }

            setSelectedFile(file);
            setError(''); // Clear any previous errors
            // Auto-generate custom name from filename
            const originalName = file.name.split('.').slice(0, -1).join('.');
            setCustomName(originalName);
        }
    };

    const handleUpload = async () => {
        if (!selectedFile) {
            setError('Please select a file');
            return;
        }

        setUploading(true);
        setError('');

        try {
            const formData = new FormData();
            formData.append('file', selectedFile);
            if (customName.trim()) {
                formData.append('customName', customName.trim());
            }

            // Get authentication token
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {};
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch('/api/whats-new-dpa', {
                method: 'POST',
                body: formData,
                headers: headers,
                credentials: 'include'
            });

            const data = await response.json();

            if (response.ok) {
                console.log('Upload response:', data);
                showSnackbar('Image uploaded successfully!', 'success');
                setUploadDialogOpen(false);
                setSelectedFile(null);
                setCustomName('');

                // Refresh data by refetching
                const refreshResponse = await fetch('/api/whats-new-dpa', {
                    headers: headers,
                    credentials: 'include'
                });
                if (refreshResponse.ok) {
                    const refreshData = await refreshResponse.json();
                    setImages(refreshData.images || []);
                }
            } else {
                showSnackbar(data.error || 'Failed to upload image', 'error');
            }
        } catch (error) {
            console.error('Error uploading image:', error);
            showSnackbar('Failed to upload image', 'error');
        } finally {
            setUploading(false);
        }
    };

    const handleCloseDialog = () => {
        setUploadDialogOpen(false);
        setSelectedFile(null);
        setCustomName('');
        setError('');
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const getFileExtension = (filename) => {
        return filename.split('.').pop().toUpperCase();
    };

    const handleDeleteImage = async (filename) => {
        setImageToDelete(filename);
        setDeleteConfirmOpen(true);
    };

    const confirmDelete = async () => {
        if (!imageToDelete) return;

        try {
            // Get authentication token
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json',
            };
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch('/api/whats-new-dpa', {
                method: 'DELETE',
                headers: headers,
                body: JSON.stringify({ filename: imageToDelete }),
                credentials: 'include'
            });

            if (response.ok) {
                showSnackbar('Image deleted successfully!', 'success');
                // Refresh data by refetching
                const refreshResponse = await fetch('/api/whats-new-dpa', {
                    headers: headers,
                    credentials: 'include'
                });
                if (refreshResponse.ok) {
                    const refreshData = await refreshResponse.json();
                    setImages(refreshData.images || []);
                }
            } else {
                const errorData = await response.json();
                showSnackbar(errorData.error || 'Failed to delete image', 'error');
            }
        } catch (error) {
            console.error('Error deleting image:', error);
            showSnackbar('Failed to delete image', 'error');
        } finally {
            setDeleteConfirmOpen(false);
            setImageToDelete(null);
        }
    };

    const showSnackbar = (message, severity = 'success') => {
        setSnackbarMessage(message);
        setSnackbarSeverity(severity);
        setSnackbarOpen(true);
    };

    // Card skeleton component
    const CardSkeleton = () => (
        <Grid container spacing={3}>
            {Array.from({ length: 3 }).map((_, index) => (
                <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} key={index}>
                    <Box className="whats-new-card" sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                        <Box sx={{ position: 'relative', height: 200 }}>
                            <Skeleton
                                variant="rectangular"
                                width="100%"
                                height="100%"
                                sx={{
                                    borderTopLeftRadius: '4px',
                                    borderTopRightRadius: '4px'
                                }}
                            />
                            <Skeleton
                                variant="rectangular"
                                width={60}
                                height={24}
                                sx={{
                                    position: 'absolute',
                                    top: 8,
                                    right: 8,
                                    borderRadius: 1
                                }}
                            />
                        </Box>
                        <Box sx={{ flexGrow: 1, p: 2 }}>
                            <Skeleton variant="text" width="80%" height={24} sx={{ mb: 1 }} />
                            <Skeleton variant="text" width="60%" height={16} sx={{ mb: 2 }} />
                            <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
                                <Skeleton variant="circular" width={32} height={32} />
                                <Skeleton variant="circular" width={32} height={32} />
                            </Box>
                        </Box>
                    </Box>
                </Grid>
            ))}
        </Grid>
    );

    const handleAddExistingImages = async () => {
        if (!existingImageList.trim()) {
            setError('Please enter image filenames');
            return;
        }

        try {
            // Parse the image list (one filename per line)
            const filenames = existingImageList
                .split('\n')
                .map(line => line.trim())
                .filter(line => line.length > 0);

            if (filenames.length === 0) {
                setError('Please enter at least one valid filename');
                return;
            }

            const images = filenames.map(filename => ({
                filename: filename,
                originalName: filename
            }));

            // Get authentication token
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json',
            };
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch('/api/whats-new-dpa', {
                method: 'PATCH',
                headers: headers,
                body: JSON.stringify({ images }),
                credentials: 'include'
            });

            const data = await response.json();

            if (response.ok) {
                showSnackbar(`Added ${data.addedCount} images to database!`, 'success');
                setAddExistingDialogOpen(false);
                setExistingImageList('');
                // Refresh data by refetching
                const refreshResponse = await fetch('/api/whats-new-dpa', {
                    headers: headers,
                    credentials: 'include'
                });
                if (refreshResponse.ok) {
                    const refreshData = await refreshResponse.json();
                    setImages(refreshData.images || []);
                }
            } else {
                showSnackbar(data.error || 'Failed to add existing images', 'error');
            }
        } catch (error) {
            console.error('Error adding existing images:', error);
            showSnackbar('Failed to add existing images', 'error');
        }
    };

    return (
        <>
            <Container maxWidth>
                <Box mt={0} mb={3}>
                    <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                        <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                            <Typography variant="h4" className='page-heading'>
                                <Box className="decorator" /> What's New At DPA
                            </Typography>
                            <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                                Manage images for What's New At DPA section
                            </Typography>
                        </Grid>
                        <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                            <Box className="fx_fe" sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
                                    <Button
                                        variant='contained'
                                        startIcon={<AddIcon />}
                                        onClick={() => setUploadDialogOpen(true)}
                                        className='main-btn btn-primary'
                                    >
                                        Add New Image
                                    </Button>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>

                {/* Images Grid */}
                {loading ? (
                    <CardSkeleton />
                ) : images.length === 0 ? (
                    <Paper sx={{ p: 4, textAlign: 'center' }}>
                        <ImageIcon sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                        <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                            No images uploaded yet
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                            Upload your first image to get started
                        </Typography>
                            <Button
                                variant="contained"
                                startIcon={<CloudUploadIcon />}
                                onClick={() => setUploadDialogOpen(true)}
                            >
                                Upload First Image
                            </Button>
                    </Paper>
                ) : (
                    <Grid container spacing={3}>
                        {images.map((image, index) => (
                            <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} key={index}>
                                <Box className="whats-new-card" sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                                    <Box sx={{ position: 'relative', height: 200 }}>
                                        <SafeImage
                                            src={image.url}
                                            alt={image.filename}
                                            style={{
                                                width: '100%',
                                                height: '100%',
                                                objectFit: 'cover',
                                                objectPosition: 'top',
                                                borderTopLeftRadius: '4px',
                                                borderTopRightRadius: '4px'
                                            }}
                                        />
                                        <Box
                                            sx={{
                                                display: 'none',
                                                width: '100%',
                                                height: '100%',
                                                bgcolor: '#f5f5f5',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                borderTopLeftRadius: '4px',
                                                borderTopRightRadius: '4px'
                                            }}
                                        >
                                            <Typography variant="caption" color="text.secondary">
                                                Image not found
                                            </Typography>
                                        </Box>
                                        <Chip
                                            label={getFileExtension(image.filename)}
                                            size="small"
                                            sx={{
                                                position: 'absolute',
                                                top: 8,
                                                right: 8,
                                                bgcolor: 'rgba(0,0,0,0.7)',
                                                color: 'white'
                                            }}
                                        />
                                    </Box>
                                    <Box sx={{ flexGrow: 1, p: 2 }}>
                                        <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 'bold' }}>
                                            {image.filename}
                                        </Typography>
                                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                            {formatFileSize(image.fileSize)}
                                        </Typography>
                                        <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
                                            <IconButton
                                                size="small"
                                                color="primary"
                                                onClick={() => window.open(image.url, '_blank')}
                                                title="View Image"
                                                className="tb-sq-btn primary-act-btn"
                                            >
                                                <VisibilityIcon />
                                            </IconButton>
                                                <IconButton
                                                    size="small"
                                                    color="error"
                                                    onClick={() => handleDeleteImage(image.filename)}
                                                    title="Delete Image"
                                                    className="tb-sq-btn error-act-btn"
                                                >
                                                    <DeleteIcon />
                                                </IconButton>
                                        </Stack>
                                    </Box>
                                </Box>
                            </Grid>
                        ))}
                    </Grid>
                )}
            </Container>

            {/* Upload Dialog */}
            <Dialog
                open={uploadDialogOpen}
                onClose={handleCloseDialog}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle className='custom-dialog-title'>
                    Upload New Image
                    {/* <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Typography variant="h6">
                            </Typography>
                        <IconButton onClick={handleCloseDialog}>
                            <CloseIcon />
                        </IconButton>
                    </Box> */}
                </DialogTitle>
                <DialogContent>
                    <Stack spacing={3} sx={{ mt: 1 }}>
                        {/* File Selection */}
                        <Box>
                            <Typography variant="subtitle2" sx={{ mb: 1 }}>
                                Select Image File
                            </Typography>
                            <Button
                                variant="outlined"
                                component="label"
                                startIcon={<CloudUploadIcon />}
                                fullWidth
                                sx={{ height: 56 }}
                            >
                                {selectedFile ? selectedFile.name : 'Choose Image File'}
                                <input
                                    type="file"
                                    hidden
                                    accept="image/*"
                                    onChange={handleFileSelect}
                                />
                            </Button>
                            {selectedFile && (
                                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                                    File size: {formatFileSize(selectedFile.size)}
                                </Typography>
                            )}
                        </Box>

                        {/* Custom Name */}
                        <Box>
                            <Typography variant="subtitle2" sx={{ mb: 1 }}>
                                Custom File Name (Optional)
                            </Typography>
                            <TextField
                                fullWidth
                                placeholder="Enter custom name (spaces will be converted to dashes)"
                                value={customName}
                                onChange={(e) => setCustomName(e.target.value)}
                                helperText="Leave empty to use original filename"
                            />
                        </Box>

                        {/* Preview */}
                        {selectedFile && (
                            <Box>
                                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                                    Preview
                                </Typography>
                                <Box sx={{
                                    border: '1px solid #e0e0e0',
                                    borderRadius: 1,
                                    p: 2,
                                    bgcolor: '#fafafa'
                                }}>
                                    <Typography variant="body2" sx={{ mb: 1 }}>
                                        <strong>Original:</strong> {selectedFile.name}
                                    </Typography>
                                    <Typography variant="body2" sx={{ mb: 1 }}>
                                        <strong>Normalized:</strong> {customName ?
                                            `${customName.toLowerCase().replace(/\s+/g, '-')}.${selectedFile.name.split('.').pop()}` :
                                            selectedFile.name.toLowerCase().replace(/\s+/g, '-')
                                        }
                                    </Typography>
                                    <Typography variant="body2">
                                        <strong>Type:</strong> {selectedFile.type}
                                    </Typography>
                                </Box>
                            </Box>
                        )}

                        {/* Error Message */}
                        {error && (
                            <Alert severity="error">
                                {error}
                            </Alert>
                        )}
                    </Stack>
                </DialogContent>
                <DialogActions className='custom-dialog-action'>
                    <Button onClick={handleCloseDialog} disabled={uploading} className='main-btn btn-tertiary'>
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        onClick={handleUpload}
                        className='main-btn btn-primary'
                        disabled={!selectedFile || uploading}
                        startIcon={uploading ? <CircularProgress size={16} /> : <CloudUploadIcon />}
                    >
                        {uploading ? 'Uploading...' : 'Upload Image'}
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Add Existing Images Dialog */}
            <Dialog
                open={addExistingDialogOpen}
                onClose={() => setAddExistingDialogOpen(false)}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle className='custom-dialog-title'>
                    {/* <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}> */}
                    {/* <Typography variant="h6"> */}
                    Add Existing Images
                    {/* </Typography> */}
                    {/* <IconButton onClick={() => setAddExistingDialogOpen(false)}>
                            <CloseIcon />
                        </IconButton> */}
                    {/* </Box> */}
                </DialogTitle>
                <DialogContent>
                    <Stack spacing={3} sx={{ mt: 1 }}>
                        <Box>
                            <Typography variant="subtitle2" sx={{ mb: 1 }}>
                                Enter Image Filenames
                            </Typography>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                Enter one filename per line. These images should already exist in the new-at-dpa folder.
                            </Typography>
                            <TextField
                                fullWidth
                                multiline
                                rows={8}
                                placeholder="image1.jpg&#10;image2.png&#10;document.pdf"
                                value={existingImageList}
                                onChange={(e) => setExistingImageList(e.target.value)}
                                helperText="Enter filenames that exist in your OCI new-at-dpa folder"
                            />
                        </Box>

                        {/* Error Message */}
                        {error && (
                            <Alert severity="error">
                                {error}
                            </Alert>
                        )}
                    </Stack>
                </DialogContent>
                <DialogActions className='custom-dialog-action'>
                    <Button onClick={() => setAddExistingDialogOpen(false)} className='main-btn btn-tertiary'>
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        className='main-btn btn-primary'
                        onClick={handleAddExistingImages}
                        disabled={!existingImageList.trim()}
                        startIcon={<AddIcon />}
                    >
                        Add Images
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Delete Confirmation Dialog */}
            <Dialog
                open={deleteConfirmOpen}
                onClose={() => setDeleteConfirmOpen(false)}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle className='custom-dialog-title'>
                    Confirm Delete
                </DialogTitle>
                <DialogContent>
                    <Typography variant="body1" sx={{ mt: 1 }}>
                        Are you sure you want to delete the image "{imageToDelete}"? This action cannot be undone.
                    </Typography>
                </DialogContent>
                <DialogActions className='custom-dialog-action'>
                    <Button onClick={() => setDeleteConfirmOpen(false)} className='main-btn btn-tertiary'>
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        color="error"
                        className='main-btn btn-primary'
                        onClick={confirmDelete}
                    >
                        Delete Image
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Snackbar for messages */}
            <Snackbar
                open={snackbarOpen}
                autoHideDuration={6000}
                onClose={() => setSnackbarOpen(false)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert
                    onClose={() => setSnackbarOpen(false)}
                    severity={snackbarSeverity}
                    sx={{ width: '100%' }}
                >
                    {snackbarMessage}
                </Alert>
            </Snackbar>
        </>
    )
}

// Component is now self-contained, no props needed

export default WhatsNewAtDPA