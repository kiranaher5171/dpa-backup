'use client';
import React, { useState, useEffect } from 'react';
import {
    Box,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Chip,
    IconButton,
    Tooltip,
    CircularProgress,
    Alert,
    Typography,
    Button,
    Container
} from '@mui/material';
import {
    CheckCircle as GrantIcon,
    Cancel as RejectIcon,
    Refresh as RefreshIcon
} from '@mui/icons-material';
import { useEmployeeStore } from '@/store/employeeStore';

const TemplateAccessRequests = () => {
    const { employeeDetails } = useEmployeeStore();
    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [processing, setProcessing] = useState({});
    const [processingGrant, setProcessingGrant] = useState(new Set());
    const [processingReject, setProcessingReject] = useState(new Set());

    // Fetch access requests
    const fetchRequests = async () => {
        try {
            setLoading(true);
            setError(null);

            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch('/api/template-access-requests', {
                headers: headers
            });

            if (response.ok) {
                const data = await response.json();
                setRequests(data.requests || []);
                console.log('✅ Fetched access requests:', data.requests?.length || 0);
            } else {
                const errorData = await response.json();
                setError(errorData.error || 'Failed to fetch requests');
                console.error('❌ Failed to fetch access requests:', errorData);
            }
        } catch (error) {
            setError(`Error fetching requests: ${error.message}`);
            console.error('❌ Error fetching access requests:', error);
        } finally {
            setLoading(false);
        }
    };

    // Update request status (grant/reject)
    const updateRequestStatus = async (requestId, status) => {
        try {
            // Set specific loading state based on action
            if (status === 'GRANTED') {
                setProcessingGrant(prev => new Set([...prev, requestId]));
            } else {
                setProcessingReject(prev => new Set([...prev, requestId]));
            }

            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            // Get admin name
            const getDisplayName = () => {
                if (employeeDetails?.full_name) {
                    return employeeDetails.full_name;
                }
                if (employeeDetails?.name) {
                    return employeeDetails.name;
                }
                if (employeeDetails?.first_name && employeeDetails?.last_name) {
                    return `${employeeDetails.first_name} ${employeeDetails.last_name}`;
                }
                return 'Admin';
            };

            const response = await fetch(`/api/template-access-requests/${requestId}/update-status`, {
                method: 'PUT',
                headers: headers,
                body: JSON.stringify({
                    status: status,
                    adminName: getDisplayName()
                })
            });

            if (response.ok) {
                const data = await response.json();
                console.log(`✅ Request ${requestId} ${status.toLowerCase()} successfully:`, data);

                // Refresh the requests list
                await fetchRequests();
            } else {
                const errorData = await response.json();
                console.error(`❌ Failed to ${status.toLowerCase()} request:`, errorData);
                setError(errorData.error || `Failed to ${status.toLowerCase()} request`);
            }
        } catch (error) {
            console.error(`❌ Error ${status.toLowerCase()}ing request:`, error);
            setError(`Error ${status.toLowerCase()}ing request: ${error.message}`);
        } finally {
            // Clear specific loading state
            if (status === 'GRANTED') {
                setProcessingGrant(prev => {
                    const newSet = new Set(prev);
                    newSet.delete(requestId);
                    return newSet;
                });
            } else {
                setProcessingReject(prev => {
                    const newSet = new Set(prev);
                    newSet.delete(requestId);
                    return newSet;
                });
            }
        }
    };

    // Get status color
    const getStatusColor = (status) => {
        switch (status) {
            case 'REQUESTED': return '#ff9800';
            case 'GRANTED': return '#4caf50';
            case 'REJECTED': return '#f44336';
            default: return '#757575';
        }
    };

    // Format date
    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    // Load requests on component mount
    useEffect(() => {
        if (employeeDetails) {
            fetchRequests();
        }
    }, [employeeDetails]);

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return (
            <Alert severity="error" sx={{ mb: 2 }}>
                {error}
            </Alert>
        );
    }

    return (
        <Box>
            <Container maxWidth>

                {/* Header */}
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                    <Typography variant="h4" className='page-heading'>
                        <Box className="decorator" /> Template Access Requests ({requests.length})
                    </Typography>
                    <Button
                        variant="outlined"
                        startIcon={<RefreshIcon />}
                        onClick={fetchRequests}
                        disabled={loading}
                    >
                        Refresh
                    </Button>
                </Box>

                {/* Table */}
                <Box className="simple-table-card">
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell><strong>Template Name</strong></TableCell>
                                    <TableCell><strong>Requestor</strong></TableCell>
                                    <TableCell><strong>Employee Code</strong></TableCell>
                                    <TableCell><strong>Email</strong></TableCell>
                                    <TableCell><strong>Status</strong></TableCell>
                                    <TableCell><strong>Requested On</strong></TableCell>
                                    <TableCell><strong>Actions</strong></TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {requests.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={7} align="center">
                                            <Typography variant="body2" color="text.secondary">
                                                No access requests found
                                            </Typography>
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    requests.map((request) => (
                                        <TableRow key={request.ID} hover>
                                            <TableCell>
                                                <Typography variant="body2" fontWeight="medium">
                                                    {request.TEMPLATE_NAME}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2">
                                                    {request.REQUESTOR_NAME}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2">
                                                    {request.REQUESTOR_EMP_CODE}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2">
                                                    {request.REQUESTOR_EMAIL || 'N/A'}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Chip
                                                    label={request.STATUS}
                                                    size="small"
                                                    sx={{
                                                        backgroundColor: getStatusColor(request.STATUS),
                                                        color: 'white',
                                                        fontWeight: 'bold'
                                                    }}
                                                />
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2">
                                                    {formatDate(request.CREATED_AT)}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Box display="flex" gap={1}>
                                                    {request.STATUS === 'REQUESTED' ? (
                                                        <>
                                                            <Tooltip title="Grant Access">
                                                                <IconButton
                                                                    color="success"
                                                                    onClick={() => updateRequestStatus(request.ID, 'GRANTED')}
                                                                    disabled={processingGrant.has(request.ID) || processingReject.has(request.ID)}
                                                                    size="small"
                                                                >
                                                                    {processingGrant.has(request.ID) ? (
                                                                        <CircularProgress size={16} />
                                                                    ) : (
                                                                        <GrantIcon />
                                                                    )}
                                                                </IconButton>
                                                            </Tooltip>
                                                            <Tooltip title="Reject Request">
                                                                <IconButton
                                                                    color="error"
                                                                    onClick={() => updateRequestStatus(request.ID, 'REJECTED')}
                                                                    disabled={processingGrant.has(request.ID) || processingReject.has(request.ID)}
                                                                    size="small"
                                                                >
                                                                    {processingReject.has(request.ID) ? (
                                                                        <CircularProgress size={16} />
                                                                    ) : (
                                                                        <RejectIcon />
                                                                    )}
                                                                </IconButton>
                                                            </Tooltip>
                                                        </>
                                                    ) : (
                                                        <Typography variant="body2" color="text.secondary">
                                                            {request.STATUS === 'GRANTED' ? 'Access Granted' : 'Request Rejected'}
                                                        </Typography>
                                                    )}
                                                </Box>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>


            </Container>
        </Box>
    );
};

export default TemplateAccessRequests;
