'use client'
import React, { useState, useEffect } from 'react'
import {
    Card,
    CardContent,
    Typography,
    Grid,
    Box,
    Chip,
    Button,
    TextField,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    CircularProgress,
    Snackbar,
    Alert,
    Container,
    Avatar,
    IconButton,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Autocomplete
} from '@mui/material'
import {
    Business,
    Person,
    CalendarToday,
    Update,
    Save,
    Cancel,
    Description
} from '@mui/icons-material'
import { useEmployeeStore } from '@/store/employeeStore'

const MISRaisedRequests = () => {
    const { employeeDetails, userRole } = useEmployeeStore()

    // States
    const [requests, setRequests] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)
    const [updatingRequest, setUpdatingRequest] = useState(null)
    const [isUpdating, setIsUpdating] = useState(false)

    // Snackbar states
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'info'
    })

    // Status options with proper flow
    const statusOptions = [
        { value: 'open', label: 'Open', order: 1 },
        { value: 'in_progress', label: 'In Progress', order: 2 },
        { value: 'approved', label: 'Approved', order: 3 },
        { value: 'rejected', label: 'Rejected', order: 3 },
        { value: 'completed', label: 'Completed', order: 4 }
    ]

    // Snackbar handlers
    const showSnackbar = (message, severity = 'info') => {
        setSnackbar({
            open: true,
            message,
            severity
        })
    }

    const handleCloseSnackbar = () => {
        setSnackbar(prev => ({
            ...prev,
            open: false
        }))
    }

    // Fetch all requests
    const fetchAllRequests = async () => {
        try {
            setLoading(true)
            setError(null)

            console.log('🔄 Fetching all MIS template requests...')

            // Get authentication token from localStorage
            const session = localStorage.getItem('session')
            let accessToken = ''

            if (session) {
                try {
                    const sessionData = JSON.parse(session)
                    accessToken = sessionData.accessToken || ''
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError)
                }
            }

            if (!accessToken) {
                setError('No authentication token available')
                console.error('❌ No access token available')
                return
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }

            const response = await fetch('/api/raise-template-request/get-all-requests', {
                headers: headers
            })

            console.log('📡 Response status:', response.status)

            if (response.ok) {
                const data = await response.json()
                console.log('📊 All requests data:', data)
                setRequests(data.requests || [])
                console.log('✅ All requests loaded:', data.requests?.length || 0)
            } else {
                const errorData = await response.json()
                console.error('❌ Failed to fetch requests:', errorData)
                setError(errorData.error || 'Failed to fetch requests')
            }
        } catch (error) {
            console.error('❌ Error fetching requests:', error)
            setError('Error connecting to requests service')
        } finally {
            setLoading(false)
        }
    }

    // Update request status and admin comment
    const updateRequest = async (requestId, status, adminComment) => {
        try {
            setIsUpdating(true)
            setUpdatingRequest(requestId)

            console.log('🔄 Updating request:', { requestId, status, adminComment })

            // Get authentication token from localStorage
            const session = localStorage.getItem('session')
            let accessToken = ''

            if (session) {
                try {
                    const sessionData = JSON.parse(session)
                    accessToken = sessionData.accessToken || ''
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError)
                }
            }

            if (!accessToken) {
                showSnackbar('No authentication token available', 'error')
                return
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }

            const requestBody = {
                status: status,
                adminComment: adminComment || null
            }

            const response = await fetch(`/api/raise-template-request/${requestId}/update-status`, {
                method: 'PUT',
                headers: headers,
                body: JSON.stringify(requestBody)
            })

            console.log('📡 Update response status:', response?.status)
            console.log('📡 Update response:', response)

            if (response && response.ok) {
                const result = await response.json()
                console.log('✅ Request updated successfully:', result)

                // Show success message with email notification info
                const emailMessage = result.emailSent ?
                    'Request status updated successfully! Email notification sent to requestor.' :
                    'Request status updated successfully!'
                showSnackbar(emailMessage, 'success')

                // Update the local state
                setRequests(prevRequests =>
                    prevRequests.map(req =>
                        req.ID === requestId
                            ? {
                                ...req,
                                STATUS: status,
                                ADMIN_COMMENT: adminComment,
                                ADMIN_UPDATED_AT: new Date().toISOString()
                            }
                            : req
                    )
                )

                setUpdatingRequest(null)
            } else if (response) {
                const errorData = await response.json()
                throw new Error(errorData.error || 'Failed to update request')
            } else {
                throw new Error('No response received from server')
            }
        } catch (error) {
            console.error('❌ Error updating request:', error)
            showSnackbar(`Failed to update request: ${error.message}`, 'error')
        } finally {
            setIsUpdating(false)
            setUpdatingRequest(null)
        }
    }

    // Handle status change
    const handleStatusChange = (requestId, newStatus) => {
        setRequests(prevRequests =>
            prevRequests.map(req =>
                req.ID === requestId
                    ? { ...req, STATUS: newStatus }
                    : req
            )
        )
    }

    // Handle admin comment change
    const handleCommentChange = (requestId, newComment) => {
        setRequests(prevRequests =>
            prevRequests.map(req =>
                req.ID === requestId
                    ? { ...req, ADMIN_COMMENT: newComment }
                    : req
            )
        )
    }

    // Handle save changes
    const handleSaveChanges = async (request) => {
        await updateRequest(request.ID, request.STATUS, request.ADMIN_COMMENT)
    }

    // Handle cancel changes
    const handleCancelChanges = () => {
        setUpdatingRequest(null)
        // Refresh the data to reset any changes
        fetchAllRequests()
    }

    // Get status color
    const getStatusColor = (status) => {
        switch (status) {
            case 'approved': return 'success'
            case 'rejected': return 'error'
            case 'in_progress': return 'warning'
            case 'completed': return 'primary'
            case 'open':
            default: return 'default'
        }
    }

    // Get status display text
    const getStatusDisplayText = (status) => {
        const statusOption = statusOptions.find(option => option.value === status)
        return statusOption ? statusOption.label : status.charAt(0).toUpperCase() + status.slice(1)
    }

    // Get status option by value
    const getStatusOption = (status) => {
        return statusOptions.find(option => option.value === status) || statusOptions[0]
    }

    // Get available next statuses based on current status
    const getAvailableStatuses = (currentStatus) => {
        const currentOrder = statusOptions.find(option => option.value === currentStatus)?.order || 1

        // Allow moving to next step or staying at current step
        return statusOptions.filter(option => option.order >= currentOrder)
    }

    // Fetch data on component mount
    useEffect(() => {
        if (employeeDetails) {
            fetchAllRequests()
        }
    }, [employeeDetails])

    // If not authenticated, show message
    if (!employeeDetails) {
        return (
            <Container maxWidth>
                <Box pt={8} px={3} display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                    <Typography>Please sign in to access the MIS Raised Requests.</Typography>
                </Box>
            </Container>
        )
    }

    return (
        <Container maxWidth>
            {/* Header Section */}
            <Box mb={4}>
                <Typography variant="h4" className='page-heading'>
                    <Box className="decorator" /> MIS Raised Requests Management
                </Typography>
                <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                    Manage all template requests from users
                </Typography>
            </Box>

            {/* Refresh Button */}
            <Box mb={3} display="flex" justifyContent="flex-end">
                <Button
                    variant="outlined"
                    onClick={fetchAllRequests}
                    disabled={loading}
                    startIcon={loading ? <CircularProgress size={20} /> : null}
                >
                    {loading ? 'Refreshing...' : 'Refresh'}
                </Button>
            </Box>

            {/* Error Display */}
            {error && (
                <Box mb={3}>
                    <Alert severity="error" onClose={() => setError(null)}>
                        {error}
                    </Alert>
                </Box>
            )}

            {/* Loading State */}
            {loading ? (
                <Box display="flex" justifyContent="center" alignItems="center" py={4}>
                    <CircularProgress size={40} />
                    <Typography variant="body1" sx={{ ml: 2 }}>
                        Loading MIS raised requests...
                    </Typography>
                </Box>
            ) : requests.length === 0 ? (
                <Card sx={{ p: 4, textAlign: 'center' }}>
                    <Description sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                        No MIS raised requests found
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        There are currently no template requests to manage.
                    </Typography>
                </Card>
            ) : (
                /* Requests Grid */
                <Grid container spacing={3}>
                    {requests.map((request) => (
                        <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }} key={request.ID}>
                            <Card sx={{
                                height: '100%',
                                border: '1px solid #e0e0e0',
                                '&:hover': {
                                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                }
                            }}>
                                <CardContent sx={{ p: 3 }}>
                                    {/* Header with Status */}
                                    <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
                                        <Box display="flex" alignItems="center">
                                            <Avatar sx={{ mr: 2, bgcolor: 'primary.main' }}>
                                                <Business />
                                            </Avatar>
                                            <Box>
                                                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                                    {request.MIS_REQ_CLIENT_NAME}
                                                </Typography>
                                                <Typography variant="body2" color="text.secondary">
                                                    Invoice ID: {request.MIS_REQ_INVOICE_ID}
                                                </Typography>
                                            </Box>
                                        </Box>
                                        <Chip
                                            label={getStatusDisplayText(request.STATUS)}
                                            color={getStatusColor(request.STATUS)}
                                            variant="outlined"
                                            size="small"
                                        />
                                    </Box>

                                    {/* Requestor Info */}
                                    <Box mb={2}>
                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                            <strong>Requestor:</strong> {request.REQUESTOR_NAME} ({request.EMPLOYEE_CODE})
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            <strong>Created:</strong> {new Date(request.CREATED_AT).toLocaleDateString()}
                                        </Typography>
                                    </Box>

                                    {/* User Comment */}
                                    {request.REQUEST_COMMENT && (
                                        <Box mb={2} p={2} bgcolor="#f5f5f5" borderRadius={1}>
                                            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>
                                                User Comment:
                                            </Typography>
                                            <Typography variant="body2" sx={{ mt: 0.5 }}>
                                                {request.REQUEST_COMMENT}
                                            </Typography>
                                        </Box>
                                    )}

                                    {/* Admin Comment */}
                                    {request.ADMIN_COMMENT && (
                                        <Box mb={2} p={2} bgcolor="#e3f2fd" borderRadius={1}>
                                            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>
                                                Admin Comment:
                                            </Typography>
                                            <Typography variant="body2" sx={{ mt: 0.5 }}>
                                                {request.ADMIN_COMMENT}
                                            </Typography>
                                        </Box>
                                    )}

                                    {/* Status Update Section */}
                                    <Box mt={3}>
                                        <Typography variant="subtitle2" gutterBottom>
                                            Update Status
                                        </Typography>

                                        {/* Status Autocomplete */}
                                        <Box className="textfield auto-complete ph2" mt={2}>
                                            <Autocomplete
                                                options={getAvailableStatuses(request.STATUS || 'open')}
                                                getOptionLabel={(option) => option.label}
                                                value={getStatusOption(request.STATUS || 'open')}
                                                onChange={(event, newValue) => {
                                                    handleStatusChange(request.ID, newValue ? newValue.value : 'open')
                                                }}
                                                renderInput={(params) => (
                                                    <TextField
                                                        {...params}
                                                        label="Status"
                                                        size="small"
                                                        disabled={updatingRequest === request.ID}
                                                        helperText="Status flow: Open → In Progress → Approved/Rejected → Completed"
                                                    />
                                                )}
                                                disableClearable
                                                sx={{ mb: 2 }}
                                            />
                                        </Box>

                                        {/* Admin Comment Field */}
                                        <Box className="textfield auto-complete ph2" mt={2}>
                                            <TextField
                                                fullWidth
                                                multiline
                                                rows={1}
                                                size="small"
                                                label="Admin Comment (Optional)"
                                                placeholder="Add your comment here..."
                                                value={request.ADMIN_COMMENT || ''}
                                                onChange={(e) => handleCommentChange(request.ID, e.target.value)}
                                                disabled={updatingRequest === request.ID}
                                                sx={{ mb: 2 }}
                                            />
                                        </Box>

                                        {/* Action Buttons */}
                                        <Box display="flex" gap={1}>
                                            <Button
                                                variant="contained"
                                                size="small"
                                                className='main-btn sm btn-primary'
                                                onClick={() => handleSaveChanges(request)}
                                                disabled={updatingRequest === request.ID}
                                                startIcon={updatingRequest === request.ID ? <CircularProgress size={16} /> : <Save />}
                                            >
                                                {updatingRequest === request.ID ? 'Saving...' : 'Save Changes'}
                                            </Button>
                                        </Box>

                                        {/* Email Notification Info */}
                                        <Box mt={1}>
                                            <Typography variant="caption" color="text.secondary">
                                                💡 Status changes will automatically send email notifications to requestors
                                            </Typography>
                                        </Box>
                                    </Box>
                                </CardContent>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            )}

            {/* Snackbar for notifications */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Container>
    )
}

export default MISRaisedRequests
