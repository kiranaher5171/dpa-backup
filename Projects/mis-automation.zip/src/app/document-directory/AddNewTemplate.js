"use client";
import React, { useState, useEffect } from "react";
import {
    Button,
    Box,
    Typography,
    Grid,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    Divider,
    IconButton,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    FormHelperText,
    Card,
    CardContent,
    Chip,
    Autocomplete,
    Avatar,
    CircularProgress,
    Alert,
    Snackbar
} from "@mui/material";
import { Add, CloudUpload, ColorLens, Close, AddCircle, RemoveCircle } from '@mui/icons-material';

export default function AddNewTemplate() {
    const [dialogOpen, setDialogOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [uploadingBanner, setUploadingBanner] = useState(false);

    // SSO Clients state
    const [ssoClients, setSsoClients] = useState([]);
    const [loadingSsoClients, setLoadingSsoClients] = useState(false);
    const [selectedSsoClient, setSelectedSsoClient] = useState(null);

    // Form state
    const [formData, setFormData] = useState({
        templateName: '',
        bannerUrl: '',
        themeColors: ['#1976d2', '#42a5f5', '#90caf9', '#e3f2fd', '#bbdefb', '#2196f3']
    });

    // Virtual scroll state
    const [filteredSsoClients, setFilteredSsoClients] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');

    const [errors, setErrors] = useState({});
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [snackbarSeverity, setSnackbarSeverity] = useState('success');

    // Function to fetch SSO clients
    const fetchSsoClients = async () => {
        try {
            setLoadingSsoClients(true);
            console.log('Fetching SSO clients...');

            // Get access token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            try {
                if (session) {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                }
            } catch (error) {
                console.error('Error parsing session data:', error);
            }

            if (!accessToken) {
                console.error('No access token available');
                return;
            }

            // Try the configured URL first, then fallback
            let url = process.env.NEXT_PUBLIC_SSO_GET_ALL_CLIENTS;
            if (!url) {
                url = 'https://api-timesheet.decimalpointanalytics.com/master/clients/';
                console.log('SSO Clients: Using fallback URL:', url);
            } else {
                console.log('SSO Clients: Using configured URL:', url);
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };

            const response = await fetch(url, {
                method: 'GET',
                headers: headers
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.log('SSO Clients Error:', errorText);

                // If the first URL fails, try the working API endpoint as fallback
                if (url !== 'https://api-timesheet.decimalpointanalytics.com/master/clients/') {
                    console.log('SSO Clients: Trying fallback URL...');
                    const fallbackUrl = 'https://api-timesheet.decimalpointanalytics.com/master/clients/';

                    const fallbackResponse = await fetch(fallbackUrl, {
                        method: 'GET',
                        headers: headers
                    });

                    if (fallbackResponse.ok) {
                        const fallbackData = await fallbackResponse.json();
                        const clientsArray = Object.values(fallbackData).filter(item =>
                            typeof item === 'object' && item && item.id && item.display_name
                        );
                        console.log('SSO Clients: Fallback Response:', clientsArray);
                        setSsoClients(clientsArray);
                        return;
                    } else {
                        const fallbackErrorText = await fallbackResponse.text();
                        console.log('SSO Clients: Fallback Error:', fallbackErrorText);
                    }
                }

                showSnackbar('Failed to fetch SSO clients', 'error');
                return;
            }

            const data = await response.json();
            const clientsArray = Object.values(data).filter(item =>
                typeof item === 'object' && item && item.id && item.display_name
            );
            console.log('SSO Clients Response:', clientsArray);
            setSsoClients(clientsArray);
            setFilteredSsoClients(clientsArray);

        } catch (error) {
            console.error('Error fetching SSO clients:', error);
            showSnackbar('Failed to fetch SSO clients', 'error');
        } finally {
            setLoadingSsoClients(false);
        }
    };

    // Function to handle banner upload
    const handleBannerUpload = async (file) => {
        try {
            setUploadingBanner(true);

            // Get access token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available');
            }

            const formData = new FormData();
            formData.append('file', file);
            formData.append('type', 'banner');

            const headers = {};
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch('/api/upload', {
                method: 'PUT',
                body: formData,
                headers: headers
            });

            if (!response.ok) {
                let errorMessage = 'Upload failed';
                try {
                    const errorText = await response.text();
                    console.error('Upload error response:', errorText);
                    try {
                        const errorData = JSON.parse(errorText);
                        errorMessage = errorData.error || errorMessage;
                    } catch (parseError) {
                        console.error('Failed to parse error response:', parseError);
                        errorMessage = `Upload failed: ${response.status} ${response.statusText}`;
                    }
                } catch (textError) {
                    console.error('Failed to read error response:', textError);
                    errorMessage = `Upload failed: ${response.status} ${response.statusText}`;
                }
                throw new Error(errorMessage);
            }

            let result;
            try {
                const responseText = await response.text();
                console.log('Upload response text:', responseText);
                result = JSON.parse(responseText);
            } catch (parseError) {
                console.error('Failed to parse upload response:', parseError);
                throw new Error('Invalid response from upload server');
            }

            console.log('Banner uploaded successfully:', result.filename);
            setFormData(prev => ({ ...prev, bannerUrl: result.filename }));
            showSnackbar('Banner uploaded successfully!', 'success');
        } catch (error) {
            console.error('Error uploading banner:', error);
            
            // Provide more specific error messages based on error type
            let errorMessage = 'Failed to upload banner';
            if (error.message.includes('Network error')) {
                errorMessage = 'Network error: Please check your internet connection and try again.';
            } else if (error.message.includes('Connection error')) {
                errorMessage = 'Connection error: Unable to reach the upload server. Please try again later.';
            } else if (error.message.includes('CORS error')) {
                errorMessage = 'Upload error: Please contact your administrator.';
            } else if (error.message.includes('No access token')) {
                errorMessage = 'Authentication error: Please refresh the page and try again.';
            } else {
                errorMessage = error.message || 'Failed to upload banner';
            }
            
            showSnackbar(errorMessage, 'error');
        } finally {
            setUploadingBanner(false);
        }
    };

    // Function to handle color change
    const handleColorChange = (index, color) => {
        setFormData(prev => ({
            ...prev,
            themeColors: prev.themeColors.map((c, i) => i === index ? color : c)
        }));
    };

    // Function to handle search filtering
    const handleSearchChange = (event, newValue) => {
        setSearchQuery(newValue);
        if (!newValue) {
            setFilteredSsoClients(ssoClients);
        } else {
            const filtered = ssoClients.filter(client =>
                client.display_name.toLowerCase().includes(newValue.toLowerCase()) ||
                client.id.toString().includes(newValue)
            );
            setFilteredSsoClients(filtered);
        }
    };

    // Function to handle form submission
    const handleSubmit = async () => {
        try {
            setLoading(true);
            setErrors({});

            // Comprehensive validation
            const newErrors = {};

            // SSO Client validation
            if (!selectedSsoClient) {
                newErrors.ssoClient = 'Please select a project';
            }

            // Template name validation
            if (!formData.templateName.trim()) {
                newErrors.templateName = 'Template name is required';
            } else if (formData.templateName.trim().length < 3) {
                newErrors.templateName = 'Template name must be at least 3 characters long';
            } else if (formData.templateName.trim().length > 100) {
                newErrors.templateName = 'Template name must be less than 100 characters';
            }

            // Banner URL validation
            if (!formData.bannerUrl.trim()) {
                newErrors.bannerUrl = 'Banner image is required';
            }

            // Theme colors validation
            if (!formData.themeColors || formData.themeColors.length === 0) {
                newErrors.themeColors = 'At least one theme color is required';
            } else {
                const invalidColors = formData.themeColors.filter(color =>
                    !color || !/^#[0-9A-F]{6}$/i.test(color)
                );
                if (invalidColors.length > 0) {
                    newErrors.themeColors = 'All theme colors must be valid hex colors (e.g., #1976d2)';
                }
            }

            if (Object.keys(newErrors).length > 0) {
                setErrors(newErrors);
                return;
            }

            // Get access token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            const headers = {
                'Content-Type': 'application/json',
            };
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const requestBody = {
                ssoClientId: selectedSsoClient.id,
                ssoClientName: selectedSsoClient.display_name,
                templateName: formData.templateName.trim(),
                bannerUrl: formData.bannerUrl,
                themeColors: formData.themeColors,
            };

            console.log('Creating template with data:', requestBody);

            const response = await fetch('/api/client-mis-templates', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(requestBody)
            });

            const data = await response.json();

            if (response.ok) {
                showSnackbar('Template created successfully!', 'success');
                setDialogOpen(false);
                resetForm();
                // Trigger a page refresh to show the new template
                if (typeof window !== 'undefined') {
                    window.location.reload();
                }
            } else {
                showSnackbar(data.error || 'Failed to create template', 'error');
            }
        } catch (error) {
            console.error('Error creating template:', error);
            showSnackbar('Failed to create template', 'error');
        } finally {
            setLoading(false);
        }
    };

    // Function to reset form
    const resetForm = () => {
        setFormData({
            templateName: '',
            bannerUrl: '',
            themeColors: ['#1976d2', '#42a5f5', '#90caf9', '#e3f2fd', '#bbdefb', '#2196f3']
        });
        setSelectedSsoClient(null);
        setErrors({});
        setSearchQuery('');
        setFilteredSsoClients(ssoClients);
    };

    // Function to show snackbar
    const showSnackbar = (message, severity = 'success') => {
        setSnackbarMessage(message);
        setSnackbarSeverity(severity);
        setSnackbarOpen(true);
    };

    // Function to get color label based on index
    const getColorLabel = (index) => {
        if (index === 0) {
            return 'Primary';
        } else if (index === 1) {
            return 'Secondary';
        } else {
            return `Color ${index + 1}`;
        }
    };

    // Function to handle dialog close
    const handleCloseDialog = () => {
        setDialogOpen(false);
        resetForm();
    };

    // Function to handle dialog open
    const handleOpenDialog = () => {
        setDialogOpen(true);
        fetchSsoClients();
    };

    return (
        <>
            <Button
                variant="contained"
                startIcon={<Add />}
                onClick={handleOpenDialog}
                className="main-btn btn-primary"
                data-testid="add-new-template-button"
            >
                New Template
            </Button>

            <Dialog
                open={dialogOpen}
                onClose={handleCloseDialog}
                maxWidth="md"
                fullWidth
                PaperProps={{
                    sx: {
                        borderRadius: 2,
                        boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
                    }
                }}
            >
                <DialogTitle className='custom-dialog-title'>
                    <Box display="flex" justifyContent="space-between" alignItems="center">
                        <Typography variant="h5" sx={{ fontWeight: 600, color: '#1a1a1a' }}>
                            Create New MIS Template
                        </Typography>
                        <IconButton onClick={handleCloseDialog} size="small">
                            <Close />
                        </IconButton>
                    </Box>
                </DialogTitle>

                <DialogContent sx={{ pt: 2 }}>
                    <Box p={3}>
                        <Grid container spacing={3}>
                            {/* SSO Client Selection */}
                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                <Box className="textfield auto-complete">
                                    <FormControl fullWidth error={!!errors.ssoClient}>
                                        <Autocomplete
                                            options={filteredSsoClients}
                                            getOptionLabel={(option) => {
                                                if (!option || !option.display_name) {
                                                    return '';
                                                }
                                                return `${option.display_name} (ID: ${option.id || 'N/A'})`;
                                            }}
                                            isOptionEqualToValue={(option, value) => {
                                                if (!option || !value) return false;
                                                return option.id === value.id;
                                            }}
                                            value={selectedSsoClient}
                                            onChange={(event, newValue) => {
                                                setSelectedSsoClient(newValue);
                                                if (errors.ssoClient) {
                                                    setErrors(prev => ({ ...prev, ssoClient: null }));
                                                }
                                            }}
                                            onInputChange={handleSearchChange}
                                            inputValue={searchQuery}
                                            loading={loadingSsoClients}
                                            ListboxProps={{
                                                style: { maxHeight: 300 }
                                            }}
                                            renderInput={(params) => (
                                                <TextField
                                                    {...params}
                                                    label="Select Project *"
                                                    placeholder="Search for a client..."
                                                    error={!!errors.ssoClient}
                                                    helperText={errors.ssoClient}
                                                    InputProps={{
                                                        ...params.InputProps,
                                                        endAdornment: (
                                                            <>
                                                                {loadingSsoClients ? <CircularProgress color="inherit" size={20} /> : null}
                                                                {params.InputProps.endAdornment}
                                                            </>
                                                        ),
                                                    }}
                                                />
                                            )}
                                            renderOption={(props, option) => {
                                                // Add null check for option
                                                if (!option || !option.display_name) {
                                                    return null;
                                                }

                                                // Destructure key from props to avoid React warning
                                                const { key, ...otherProps } = props;

                                                return (
                                                    <Box component="li" key={key} {...otherProps}>
                                                        <Box>
                                                            <Typography variant="body2" fontWeight={400} sx={{ fontSize: '12px' }}>
                                                                {option.display_name}
                                                            </Typography>
                                                            <Typography variant="caption" color="text.secondary" fontWeight={300} sx={{ fontSize: '10px' }}>
                                                                Client ID: {option.id || 'N/A'}
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                );
                                            }}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>

                            {/* Template Name */}
                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                <Box className="textfield auto-complete">
                                    <TextField
                                        fullWidth
                                        label="Template Name *"
                                        value={formData.templateName}
                                        onChange={(e) => {
                                            setFormData(prev => ({ ...prev, templateName: e.target.value }));
                                            if (errors.templateName) {
                                                setErrors(prev => ({ ...prev, templateName: null }));
                                            }
                                        }}
                                        error={!!errors.templateName}
                                        helperText={errors.templateName}
                                        placeholder="Enter template name (3-50 characters)"
                                        inputProps={{
                                            maxLength: 50
                                        }}
                                    />
                                </Box>
                            </Grid>

                            {/* Banner Upload */}
                            <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                <Card variant="outlined" sx={{ p: 2 }}>
                                    <Typography variant="subtitle2" gutterBottom>
                                        Template Banner *
                                    </Typography>
                                    <input
                                        accept="image/*"
                                        style={{ display: 'none' }}
                                        id="banner-upload"
                                        type="file"
                                        onChange={(e) => {
                                            const file = e.target.files[0];
                                            if (file) {
                                                // Validate file type
                                                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
                                                if (!allowedTypes.includes(file.type)) {
                                                    showSnackbar('Please select a valid image file (JPEG, PNG, GIF, WebP)', 'error');
                                                    return;
                                                }

                                                // Validate file size (max 1MB)
                                                const maxSize = 1 * 1024 * 1024; // 1MB
                                                if (file.size > maxSize) {
                                                    showSnackbar('File size must be less than 1MB', 'error');
                                                    return;
                                                }

                                                handleBannerUpload(file);
                                            }
                                        }}
                                    />
                                    <label htmlFor="banner-upload">
                                        <Button
                                            variant="outlined"
                                            component="span"
                                            startIcon={uploadingBanner ? <CircularProgress size={16} /> : <CloudUpload />}
                                            disabled={uploadingBanner}
                                            fullWidth
                                            sx={{ height: 56 }}
                                        >
                                            {uploadingBanner ? 'Uploading...' : 'Upload Banner'}
                                        </Button>
                                    </label>
                                    {formData.bannerUrl && (
                                        <Typography variant="caption" color="success.main" sx={{ mt: 1, display: 'block' }}>
                                            ✓ Banner uploaded: {formData.bannerUrl}
                                        </Typography>
                                    )}
                                    {errors.bannerUrl && (
                                        <Typography variant="caption" color="error" sx={{ mt: 1, display: 'block' }}>
                                            {errors.bannerUrl}
                                        </Typography>
                                    )}
                                </Card>
                            </Grid>

                            {/* Theme Colors */}
                            <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                <Card variant="outlined" sx={{ p: 2 }}>
                                    <Typography variant="subtitle2" gutterBottom>
                                        Theme Colors *
                                    </Typography>
                                    <Grid container spacing={2}>
                                        {formData.themeColors.map((color, index) => (
                                            <Grid size={{ xs: 6, sm: 4, md: 2 }} key={index}>
                                                <Box sx={{ textAlign: 'center' }}>
                                                    <Box
                                                        sx={{
                                                            width: 50,
                                                            height: 50,
                                                            borderRadius: 2,
                                                            backgroundColor: color,
                                                            border: '2px solid #e0e0e0',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            mb: 1,
                                                            margin: 'auto',
                                                            '&:hover': {
                                                                border: '2px solid #1976d2'
                                                            }
                                                        }}
                                                    >
                                                        <ColorLens sx={{ color: 'white', filter: 'drop-shadow(0 0 2px rgba(0,0,0,0.5))', fontSize: 20 }} />
                                                    </Box>
                                                    <Typography variant="caption" sx={{ fontWeight: 500, mb: 1, display: 'block' }}>
                                                        {getColorLabel(index)}
                                                    </Typography>
                                                    <TextField
                                                        size="small"
                                                        value={color}
                                                        onChange={(e) => {
                                                            handleColorChange(index, e.target.value);
                                                            if (errors.themeColors) {
                                                                setErrors(prev => ({ ...prev, themeColors: null }));
                                                            }
                                                        }}
                                                        placeholder="#000000"
                                                        error={!!errors.themeColors}
                                                        sx={{
                                                            '& .MuiInputBase-input': {
                                                                fontSize: '0.75rem',
                                                                textAlign: 'center',
                                                                padding: '4px 8px'
                                                            }
                                                        }}
                                                    />
                                                </Box>
                                            </Grid>
                                        ))}
                                    </Grid>
                                    {errors.themeColors && (
                                        <Typography variant="caption" color="error" sx={{ mt: 1, display: 'block' }}>
                                            {errors.themeColors}
                                        </Typography>
                                    )}
                                </Card>
                            </Grid>
                        </Grid>
                    </Box>
                </DialogContent>

                <DialogActions className='custom-dialog-action'>
                    <Button onClick={handleCloseDialog} disabled={loading}>
                        Cancel
                    </Button>
                    <Button
                        variant="contained"
                        onClick={handleSubmit}
                        disabled={loading || !selectedSsoClient || !formData.templateName.trim() || !formData.bannerUrl.trim()}
                        startIcon={loading ? <CircularProgress size={16} /> : <Add />}
                    >
                        {loading ? 'Creating...' : 'Create Template'}
                    </Button>
                </DialogActions>
            </Dialog>

            <Snackbar
                open={snackbarOpen}
                autoHideDuration={6000}
                onClose={() => setSnackbarOpen(false)}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert
                    onClose={() => setSnackbarOpen(false)}
                    severity={snackbarSeverity}
                    sx={{ width: '100%' }}
                >
                    {snackbarMessage}
                </Alert>
            </Snackbar>
        </>
    );
} 