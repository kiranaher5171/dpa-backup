"use client";
import React, { useState, useEffect, useMemo } from 'react';
import {
    Box,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TextField,
    InputAdornment,
    Pagination,
    Typography,
    CircularProgress,
    Alert,
    Paper,
    Grid,
    Chip,
    Button,
    IconButton,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Snackbar,
    Switch,
    Avatar,
    AvatarGroup,
    Tooltip,
    Container
} from '@mui/material';
import { Search, Refresh, Delete, Add, Visibility, Edit, VisibilityOff, People } from '@mui/icons-material';
import { useRouter } from 'next/navigation';
import AddNewTemplate from './AddNewTemplate';

const TemplatesTable = ({ templates, clients, loading, onRefresh, onDelete }) => {
    const router = useRouter();
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage] = useState(10);

    // Helper function to get initials from name
    const getInitials = (name) => {
        if (!name) return '?';
        const words = name.trim().split(' ');
        if (words.length === 1) {
            return words[0].substring(0, 2).toUpperCase();
        }
        return (words[0][0] + words[words.length - 1][0]).toUpperCase();
    };

    // Helper function to get avatar color based on name
    const getAvatarColor = (name) => {
        if (!name) return '#9e9e9e';
        const colors = [
            '#f44336', '#e91e63', '#9c27b0', '#673ab7',
            '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4',
            '#009688', '#4caf50', '#8bc34a', '#cddc39',
            '#ffeb3b', '#ffc107', '#ff9800', '#ff5722'
        ];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    };

    // Debug: Log template data to see access information
    React.useEffect(() => {
        console.log('🔍 TemplatesTable received templates:', templates?.map(t => ({
            id: t.ID,
            name: t.TEMPLATE_NAME,
            access: t.TEMPLATE_ACCESS_EMP_NAMES,
            allKeys: Object.keys(t)
        })));
    }, [templates]);

    // Delete confirmation dialog state
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [templateToDelete, setTemplateToDelete] = useState(null);

    // View template dialog state
    const [viewDialogOpen, setViewDialogOpen] = useState(false);
    const [templateToView, setTemplateToView] = useState(null);

    // Edit template dialog state
    const [editDialogOpen, setEditDialogOpen] = useState(false);
    const [templateToEdit, setTemplateToEdit] = useState(null);

    // Manage access dialog state
    const [manageAccessDialogOpen, setManageAccessDialogOpen] = useState(false);
    const [templateForAccess, setTemplateForAccess] = useState(null);
    const [employees, setEmployees] = useState([]);
    const [accessStates, setAccessStates] = useState({});
    const [accessUpdates, setAccessUpdates] = useState({});
    const [loadingEmployees, setLoadingEmployees] = useState(false);

    // Employee search and pagination state
    const [employeeSearchQuery, setEmployeeSearchQuery] = useState('');
    const [employeeCurrentPage, setEmployeeCurrentPage] = useState(1);
    const [employeeItemsPerPage] = useState(50);

    // Snackbar state
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [snackbarSeverity, setSnackbarSeverity] = useState('success');

    // Filter templates based on search query
    const filteredTemplates = useMemo(() => {
        if (!searchQuery.trim()) return templates;

        const query = searchQuery.toLowerCase();
        return templates.filter(template =>
            template.TEMPLATE_NAME?.toLowerCase().includes(query) ||
            template.SSO_CLIENT_NAME?.toLowerCase().includes(query) ||
            template.SSO_CLIENT_ID?.toLowerCase().includes(query)
        );
    }, [templates, searchQuery]);

    // Pagination
    const totalPages = Math.ceil(filteredTemplates.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedTemplates = filteredTemplates.slice(startIndex, startIndex + itemsPerPage);

    // Filter employees based on search query and sort by access status
    const filteredEmployees = useMemo(() => {
        let filtered = employees;

        // Apply search filter if query exists
        if (employeeSearchQuery.trim()) {
            const query = employeeSearchQuery.toLowerCase();
            filtered = employees.filter(employee =>
                employee.emp_code?.toLowerCase().includes(query) ||
                employee.display_name?.toLowerCase().includes(query)
            );
        }

        // Get current access list from template
        const currentAccessList = templateForAccess?.TEMPLATE_ACCESS_EMP_NAMES
            ? templateForAccess.TEMPLATE_ACCESS_EMP_NAMES.split(',').map(name => name.trim()).filter(name => name)
            : [];

        // Sort employees: those with access first, then those without access
        return filtered.sort((a, b) => {
            const aHasAccess = currentAccessList.includes(a.display_name);
            const bHasAccess = currentAccessList.includes(b.display_name);

            // If both have access or both don't have access, sort by name
            if (aHasAccess === bHasAccess) {
                return (a.display_name || '').localeCompare(b.display_name || '');
            }

            // Those with access come first
            return bHasAccess - aHasAccess;
        });
    }, [employees, employeeSearchQuery, templateForAccess]);

    // Employee pagination
    const employeeTotalPages = Math.ceil(filteredEmployees.length / employeeItemsPerPage);
    const employeeStartIndex = (employeeCurrentPage - 1) * employeeItemsPerPage;
    const paginatedEmployees = filteredEmployees.slice(employeeStartIndex, employeeStartIndex + employeeItemsPerPage);

    // Function to open delete confirmation dialog
    const handleDeleteClick = (template) => {
        setTemplateToDelete(template);
        setDeleteDialogOpen(true);
    };

    // Function to handle template deletion
    const handleDeleteTemplate = async () => {
        if (!templateToDelete) return;

        try {
            await onDelete(templateToDelete);
            setDeleteDialogOpen(false);
            setTemplateToDelete(null);
            showSnackbar('Template deleted successfully!', 'success');
        } catch (error) {
            console.error('Error deleting template:', error);
            showSnackbar('Failed to delete template', 'error');
        }
    };

    // Function to close delete confirmation dialog
    const handleCloseDeleteDialog = () => {
        setDeleteDialogOpen(false);
        setTemplateToDelete(null);
    };

    // Function to show snackbar
    const showSnackbar = (message, severity = 'success') => {
        setSnackbarMessage(message);
        setSnackbarSeverity(severity);
        setSnackbarOpen(true);
    };

    // Function to close snackbar
    const handleCloseSnackbar = () => {
        setSnackbarOpen(false);
    };

    // Function to handle template view
    const handleViewClick = (template) => {
        setTemplateToView(template);
        setViewDialogOpen(true);
    };

    // Function to handle template edit
    const handleEditClick = (template) => {
        setTemplateToEdit(template);
        setEditDialogOpen(true);
    };

    // Function to close view dialog
    const handleCloseViewDialog = () => {
        setViewDialogOpen(false);
        setTemplateToView(null);
    };

    // Function to close edit dialog
    const handleCloseEditDialog = () => {
        setEditDialogOpen(false);
        setTemplateToEdit(null);
    };

    // Function to handle manage access click
    const handleManageAccessClick = (template) => {
        setTemplateForAccess(template);
        setManageAccessDialogOpen(true);
        fetchEmployeesForAccess();
    };

    // Function to close manage access dialog
    const handleCloseManageAccessDialog = () => {
        setManageAccessDialogOpen(false);
        setTemplateForAccess(null);
        setEmployees([]);
        setAccessStates({});
        setAccessUpdates({});
        setEmployeeSearchQuery('');
        setEmployeeCurrentPage(1);
    };

    // Handle employee search
    const handleEmployeeSearchChange = (event) => {
        setEmployeeSearchQuery(event.target.value);
        setEmployeeCurrentPage(1); // Reset to first page when searching
    };

    // Handle employee page change
    const handleEmployeePageChange = (event, page) => {
        setEmployeeCurrentPage(page);
    };

    // Function to fetch employees for access management
    const fetchEmployeesForAccess = async () => {
        try {
            setLoadingEmployees(true);

            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available');
            }

            const response = await fetch('/api/get-all-employees', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`Failed to fetch employees: ${response.status} - ${response.statusText}`);
            }

            const data = await response.json();

            if (!data.success) {
                throw new Error(data.error || 'Failed to fetch employees');
            }

            // Filter out admins and process the data
            const employeesArray = data.employees
                .filter(employee => employee.IS_ADMIN !== 1) // Exclude admins
                .map(employee => ({
                    id: employee.ID,
                    emp_code: employee.EMP_CODE,
                    display_name: employee.EMP_NAME,
                    is_admin: employee.IS_ADMIN === 1
                }));

            setEmployees(employeesArray);

            // Initialize access states based on current template access
            const currentAccessList = templateForAccess?.TEMPLATE_ACCESS_EMP_NAMES
                ? templateForAccess.TEMPLATE_ACCESS_EMP_NAMES.split(',').map(name => name.trim()).filter(name => name)
                : [];

            const initialAccessStates = {};
            employeesArray.forEach(employee => {
                initialAccessStates[employee.emp_code] = currentAccessList.includes(employee.display_name);
            });
            setAccessStates(initialAccessStates);

        } catch (error) {
            console.error('Error fetching employees for access:', error);
            showSnackbar('Failed to load employees for access management', 'error');
        } finally {
            setLoadingEmployees(false);
        }
    };

    // Function to handle access toggle
    const handleAccessToggle = async (empCode, empName, currentHasAccess) => {
        try {
            const newHasAccess = !currentHasAccess;

            // Optimistically update the UI
            setAccessUpdates(prev => ({ ...prev, [empCode]: 'updating' }));
            setAccessStates(prev => ({ ...prev, [empCode]: newHasAccess }));

            // Get current access list from template
            const currentAccessList = templateForAccess?.TEMPLATE_ACCESS_EMP_NAMES
                ? templateForAccess.TEMPLATE_ACCESS_EMP_NAMES.split(',').map(name => name.trim()).filter(name => name)
                : [];

            console.log('Current access list:', currentAccessList);
            console.log('Template access data:', templateForAccess?.TEMPLATE_ACCESS_EMP_NAMES);
            console.log('Employee:', empName, 'Current has access:', currentHasAccess, 'New has access:', newHasAccess);

            let newAccessList;
            if (newHasAccess) {
                // Grant access - add employee name if not already present
                if (!currentAccessList.includes(empName)) {
                    newAccessList = [...currentAccessList, empName];
                } else {
                    newAccessList = currentAccessList;
                }
            } else {
                // Revoke access - remove employee name
                newAccessList = currentAccessList.filter(name => name !== empName);
            }

            // Convert back to comma-separated string
            const newAccessString = newAccessList.length > 0 ? newAccessList.join(',') : null;

            console.log('New access list:', newAccessList);
            console.log('New access string:', newAccessString);

            // Call API to update template access
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available');
            }

            const response = await fetch('/api/update-template-access', {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    templateId: templateForAccess.ID,
                    templateAccessEmpCodes: newAccessString
                })
            });

            if (!response.ok) {
                throw new Error(`Failed to update template access: ${response.status} - ${response.statusText}`);
            }

            const data = await response.json();

            if (!data.success) {
                throw new Error(data.error || 'Failed to update template access');
            }

            // Update the template object with new access data
            setTemplateForAccess(prev => ({
                ...prev,
                TEMPLATE_ACCESS_EMP_NAMES: newAccessString
            }));

            // Update access states to reflect the new state
            setAccessStates(prev => ({ ...prev, [empCode]: newHasAccess }));

            console.log(`Template access ${newHasAccess ? 'granted' : 'revoked'} for ${empName} (${empCode})`);
            showSnackbar(`Access ${newHasAccess ? 'granted' : 'revoked'} for ${empName}`, 'success');

            setAccessUpdates(prev => ({ ...prev, [empCode]: 'success' }));

            // Clear success status after 2 seconds
            setTimeout(() => {
                setAccessUpdates(prev => {
                    const newUpdates = { ...prev };
                    delete newUpdates[empCode];
                    return newUpdates;
                });
            }, 2000);

        } catch (error) {
            console.error('Error updating template access:', error);

            // Revert the optimistic update
            setAccessStates(prev => ({ ...prev, [empCode]: currentHasAccess }));
            setAccessUpdates(prev => ({ ...prev, [empCode]: 'error' }));

            showSnackbar(`Failed to ${currentHasAccess ? 'revoke' : 'grant'} access for ${empName}`, 'error');

            // Clear error status after 3 seconds
            setTimeout(() => {
                setAccessUpdates(prev => {
                    const newUpdates = { ...prev };
                    delete newUpdates[empCode];
                    return newUpdates;
                });
            }, 3000);
        }
    };

    // Handle page change
    const handlePageChange = (event, page) => {
        setCurrentPage(page);
    };

    // Handle search
    const handleSearchChange = (event) => {
        setSearchQuery(event.target.value);
        setCurrentPage(1); // Reset to first page when searching
    };

    // Handle refresh
    const handleRefresh = () => {
        if (onRefresh) {
            onRefresh();
        }
    };

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
                <CircularProgress />
                <Typography variant="body1" sx={{ ml: 2 }}>
                    Loading templates...
                </Typography>
            </Box>
        );
    }

    return (
        <>
            <Container maxWidth>
                {/* Header */}
                <Box mb={3} display="flex" justifyContent="space-between" alignItems="flex-start">
                    <Box>
                        <Typography variant="h4" className='page-heading'>
                            <Box className="decorator" /> MIS Templates Management
                            <Chip
                                label={`${templates.length} Total`}
                                color="primary"
                                variant="outlined"
                                size='small'
                            />
                        </Typography>
                        <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                            Manage and organize your MIS templates
                        </Typography>
                    </Box>
                    <Box display="flex" gap={2}>
                        <AddNewTemplate />
                        <Button
                            variant="outlined"
                            startIcon={<Refresh />}
                            onClick={handleRefresh}
                            disabled={loading}
                            size="small"
                        >
                            Refresh
                        </Button>

                        <Box className='textfield auto-complete ph2'>
                            <TextField
                                sx={{ width: '250px' }}
                                fullWidth
                                placeholder="Search by template name..."
                                value={searchQuery}
                                onChange={handleSearchChange}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search />
                                        </InputAdornment>
                                    ),
                                }}
                                size="small"
                            />
                        </Box>
                    </Box>
                </Box>

                {/* Search and Stats */}
                {/* <Grid container spacing={2} alignItems="center" mb={3}>
                    <Grid item xs={12} md={6}>
                        <TextField
                            fullWidth
                            placeholder="Search by template name, client name, or client code..."
                            value={searchQuery}
                            onChange={handleSearchChange}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <Search />
                                    </InputAdornment>
                                ),
                            }}
                            size="small"
                        />
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box display="flex" justifyContent="flex-end" alignItems="center" gap={2}>
                            <Typography variant="body2" color="text.secondary">
                                Showing {filteredTemplates.length} of {templates.length} templates
                            </Typography>
                            <Chip
                                label={`${templates.length} Total`}
                                color="primary"
                                variant="outlined"
                            />
                        </Box>
                    </Grid>
                </Grid> */}

                {/* Table */}
                <Box className="simple-table-card">
                    <TableContainer sx={{ maxHeight: 400 }}>
                        <Table stickyHeader>
                            <TableHead>
                                <TableRow>
                                    <TableCell sx={{
                                        backgroundColor: 'primary.main',
                                        color: 'white',
                                        fontWeight: 'bold',
                                        position: 'sticky',
                                        top: 0,
                                        zIndex: 1,
                                        minWidth: 80
                                    }}>
                                        Sr. No.
                                    </TableCell>
                                    <TableCell sx={{
                                        backgroundColor: 'primary.main',
                                        color: 'white',
                                        fontWeight: 'bold',
                                        position: 'sticky',
                                        top: 0,
                                        zIndex: 1,
                                        minWidth: 200
                                    }}>
                                        Template Name
                                    </TableCell>
                                    <TableCell sx={{
                                        backgroundColor: 'primary.main',
                                        color: 'white',
                                        fontWeight: 'bold',
                                        position: 'sticky',
                                        top: 0,
                                        zIndex: 1,
                                        minWidth: 150
                                    }}>
                                        Client Name
                                    </TableCell>
                                    <TableCell sx={{
                                        backgroundColor: 'primary.main',
                                        color: 'white',
                                        fontWeight: 'bold',
                                        position: 'sticky',
                                        top: 0,
                                        zIndex: 1,
                                        minWidth: 120
                                    }}>
                                        Client Code
                                    </TableCell>
                                    <TableCell sx={{
                                        backgroundColor: 'primary.main',
                                        color: 'white',
                                        fontWeight: 'bold',
                                        position: 'sticky',
                                        top: 0,
                                        zIndex: 1,
                                        minWidth: 120
                                    }}>
                                        Created Date
                                    </TableCell>
                                    <TableCell sx={{
                                        backgroundColor: 'primary.main',
                                        color: 'white',
                                        fontWeight: 'bold',
                                        position: 'sticky',
                                        top: 0,
                                        zIndex: 1,
                                        minWidth: 100
                                    }}>
                                        Has Access
                                    </TableCell>
                                    <TableCell sx={{
                                        backgroundColor: 'primary.main',
                                        color: 'white',
                                        fontWeight: 'bold',
                                        position: 'sticky',
                                        top: 0,
                                        zIndex: 1,
                                        minWidth: 150
                                    }}>
                                        Actions
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {paginatedTemplates.map((template, index) => {
                                    const globalIndex = startIndex + index + 1;

                                    return (
                                        <TableRow
                                            key={template.ID}
                                            hover
                                            sx={{
                                                '&:hover': {
                                                    backgroundColor: 'rgba(0, 0, 0, 0.04)'
                                                }
                                            }}
                                        >
                                            <TableCell>
                                                <Typography variant="body2" fontWeight="medium">
                                                    {globalIndex}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2" fontWeight="medium" color="primary">
                                                    {template.TEMPLATE_NAME || 'Unknown'}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2">
                                                    {template.SSO_CLIENT_NAME || 'Unknown'}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2" color="text.secondary">
                                                    {template.SSO_CLIENT_ID || 'N/A'}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Typography variant="body2" color="text.secondary">
                                                    {template.CREATED_AT ? (
                                                        <span dangerouslySetInnerHTML={{
                                                            __html: new Date(template.CREATED_AT).toLocaleDateString('en-US', {
                                                                year: 'numeric',
                                                                month: 'long',
                                                                day: 'numeric'
                                                            }) + ' <br/> ' + new Date(template.CREATED_AT).toLocaleTimeString('en-US', {
                                                                hour: '2-digit',
                                                                minute: '2-digit',
                                                                hour12: true
                                                            })
                                                        }} />
                                                    ) : 'N/A'}
                                                </Typography>
                                            </TableCell>
                                            <TableCell>
                                                <Box display="flex">
                                                    {/* <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                {template.TEMPLATE_ACCESS_EMP_NAMES ?
                                                    `${template.TEMPLATE_ACCESS_EMP_NAMES.split(',').filter(name => name.trim()).length} user${template.TEMPLATE_ACCESS_EMP_NAMES.split(',').filter(name => name.trim()).length !== 1 ? 's' : ''}`
                                                    : '0 users'
                                                }
                                            </Typography> */}
                                                    {template.TEMPLATE_ACCESS_EMP_NAMES && template.TEMPLATE_ACCESS_EMP_NAMES.trim() ? (
                                                        <AvatarGroup
                                                            max={4}
                                                            sx={{
                                                                justifyContent: 'flex-start',
                                                                '& .MuiAvatar-root': {
                                                                    width: 32,
                                                                    height: 32,
                                                                    fontSize: '0.75rem'
                                                                }
                                                            }}
                                                        >
                                                            {template.TEMPLATE_ACCESS_EMP_NAMES.split(',').map((name, index) => {
                                                                const trimmedName = name.trim();
                                                                return (
                                                                    <Tooltip
                                                                        key={index}
                                                                        title={trimmedName}
                                                                        arrow
                                                                        placement="top"
                                                                    >
                                                                        <Avatar
                                                                            sx={{
                                                                                bgcolor: getAvatarColor(trimmedName),
                                                                                fontSize: '0.75rem',
                                                                                fontWeight: 'bold'
                                                                            }}
                                                                        >
                                                                            {getInitials(trimmedName)}
                                                                        </Avatar>
                                                                    </Tooltip>
                                                                );
                                                            })}
                                                        </AvatarGroup>
                                                    ) : (
                                                        <Typography
                                                            variant="caption"
                                                            color="text.disabled"
                                                            sx={{ fontSize: '0.75rem', fontStyle: 'italic' }}
                                                        >
                                                            No users assigned
                                                        </Typography>
                                                    )}
                                                </Box>
                                            </TableCell>
                                            <TableCell>
                                                <Box display="flex" alignItems="center" gap={1}>
                                                    <IconButton
                                                        size="small"
                                                        color="primary"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleViewClick(template);
                                                        }}
                                                        sx={{ p: 0.5 }}
                                                        title="View Template"
                                                    >
                                                        <Visibility fontSize="small" />
                                                    </IconButton>
                                                    <IconButton
                                                        size="small"
                                                        color="secondary"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleEditClick(template);
                                                        }}
                                                        sx={{ p: 0.5 }}
                                                        title="Edit Template"
                                                    >
                                                        <Edit fontSize="small" />
                                                    </IconButton>
                                                    <IconButton
                                                        size="small"
                                                        color="info"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleManageAccessClick(template);
                                                        }}
                                                        sx={{ p: 0.5 }}
                                                        title="Manage User Access"
                                                    >
                                                        <People fontSize="small" />
                                                    </IconButton>
                                                    <IconButton
                                                        size="small"
                                                        color="error"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleDeleteClick(template);
                                                        }}
                                                        sx={{ p: 0.5 }}
                                                        title="Delete Template"
                                                    >
                                                        <Delete fontSize="small" />
                                                    </IconButton>
                                                </Box>
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    {/* Pagination */}
                    {totalPages > 1 && (
                        <Box display="flex" justifyContent="center" mt={3} mb={2}>
                            <Pagination
                                count={totalPages}
                                page={currentPage}
                                onChange={handlePageChange}
                                color="primary"
                                showFirstButton
                                showLastButton
                            />
                        </Box>
                    )}
                </Box>


                {/* Empty State */}
                {filteredTemplates.length === 0 && (
                    <Box textAlign="center" py={4}>
                        <Typography variant="h6" color="text.secondary">
                            No templates found
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {searchQuery ? 'Try adjusting your search criteria' : 'No templates available'}
                        </Typography>
                    </Box>
                )}

                {/* Delete Confirmation Dialog */}
                <Dialog
                    open={deleteDialogOpen}
                    onClose={handleCloseDeleteDialog}
                    aria-labelledby="delete-dialog-title"
                    aria-describedby="delete-dialog-description"
                    PaperProps={{
                        sx: {
                            borderRadius: 2,
                            boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
                        }
                    }}
                >
                    <DialogTitle id="delete-dialog-title" sx={{ pb: 1 }}>
                        <Box display="flex" alignItems="center" justifyContent="center" gap={2} mt={3}>
                            <Box
                                sx={{
                                    width: 48,
                                    height: 48,
                                    borderRadius: '50%',
                                    backgroundColor: '#ffebee',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}
                            >
                                <Delete sx={{ color: '#d32f2f', fontSize: 24 }} />
                            </Box>
                        </Box>
                    </DialogTitle>
                    <DialogContent sx={{ pt: 2 }}>
                        <Box textAlign="center" my={2}>
                            <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
                                Are you sure you want to delete this template?
                            </Typography>
                            <Typography variant="h6" sx={{ color: '#d32f2f', fontWeight: 600 }}>
                                "{templateToDelete?.TEMPLATE_NAME || 'Template'}"
                            </Typography>
                            <Typography variant="body1" sx={{ mt: 2, color: 'text.secondary' }}>
                                <em>This action cannot be undone.</em>
                            </Typography>
                        </Box>
                    </DialogContent>
                    <DialogActions sx={{ p: 3, gap: 2 }}>
                        <Button
                            onClick={handleCloseDeleteDialog}
                            variant="outlined"
                            sx={{ minWidth: 100 }}
                        >
                            Cancel
                        </Button>
                        <Button
                            onClick={handleDeleteTemplate}
                            variant="contained"
                            color="error"
                            startIcon={<Delete />}
                            sx={{ minWidth: 100 }}
                        >
                            Delete
                        </Button>
                    </DialogActions>
                </Dialog>

                {/* View Template Dialog */}
                <Dialog
                    open={viewDialogOpen}
                    onClose={handleCloseViewDialog}
                    maxWidth="md"
                    fullWidth
                    aria-labelledby="view-dialog-title"
                    PaperProps={{
                        sx: {
                            borderRadius: 2,
                            boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
                        }
                    }}
                >
                    <DialogTitle id="view-dialog-title" sx={{ pb: 1 }}>
                        <Box display="flex" alignItems="center" gap={2}>
                            <Visibility sx={{ color: 'primary.main' }} />
                            <Typography variant="h5" sx={{ fontWeight: 600 }}>
                                Template Details
                            </Typography>
                        </Box>
                    </DialogTitle>
                    <DialogContent sx={{ pt: 2 }}>
                        {templateToView && (
                            <Box>
                                {/* Banner Image */}
                                {templateToView.BANNER_URL && (
                                    <Box sx={{ mb: 3, textAlign: 'center' }}>
                                        <Box
                                            sx={{
                                                height: 200,
                                                backgroundImage: `url(${process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH}mis-banners/${templateToView.BANNER_URL})`,
                                                backgroundSize: 'contain',
                                                backgroundRepeat: 'no-repeat',
                                                backgroundPosition: 'center',
                                                borderRadius: 2,
                                                backgroundColor: '#f5f5f5',
                                                border: '1px solid #e0e0e0'
                                            }}
                                        />
                                    </Box>
                                )}

                                {/* Template Information */}
                                <Grid container spacing={2}>
                                    <Grid item xs={12} sm={6}>
                                        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                            Template Name
                                        </Typography>
                                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                                            {templateToView.TEMPLATE_NAME || 'N/A'}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                            Client Name
                                        </Typography>
                                        <Typography variant="body1">
                                            {templateToView.SSO_CLIENT_NAME || 'N/A'}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                            Client Code
                                        </Typography>
                                        <Typography variant="body1">
                                            {templateToView.SSO_CLIENT_ID || 'N/A'}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                            Created Date
                                        </Typography>
                                        <Typography variant="body1">
                                            {templateToView.CREATED_AT ? (
                                                <span dangerouslySetInnerHTML={{
                                                    __html: new Date(templateToView.CREATED_AT).toLocaleDateString('en-US', {
                                                        year: 'numeric',
                                                        month: 'long',
                                                        day: 'numeric'
                                                    }) + ' <br/> ' + new Date(templateToView.CREATED_AT).toLocaleTimeString('en-US', {
                                                        hour: '2-digit',
                                                        minute: '2-digit',
                                                        hour12: true
                                                    })
                                                }} />
                                            ) : 'N/A'}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                            Updated Date
                                        </Typography>
                                        <Typography variant="body1">
                                            {templateToView.UPDATED_AT ? (
                                                <span dangerouslySetInnerHTML={{
                                                    __html: new Date(templateToView.UPDATED_AT).toLocaleDateString('en-US', {
                                                        year: 'numeric',
                                                        month: 'long',
                                                        day: 'numeric'
                                                    }) + ' <br/> ' + new Date(templateToView.UPDATED_AT).toLocaleTimeString('en-US', {
                                                        hour: '2-digit',
                                                        minute: '2-digit',
                                                        hour12: true
                                                    })
                                                }} />
                                            ) : 'N/A'}
                                        </Typography>
                                    </Grid>

                                    {/* Additional Details */}
                                    {templateToView.DESCRIPTION && (
                                        <Grid item xs={12}>
                                            <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                                Description
                                            </Typography>
                                            <Typography variant="body1">
                                                {templateToView.DESCRIPTION}
                                            </Typography>
                                        </Grid>
                                    )}
                                </Grid>
                            </Box>
                        )}
                    </DialogContent>
                    <DialogActions sx={{ p: 3 }}>
                        <Button
                            onClick={handleCloseViewDialog}
                            variant="outlined"
                            sx={{ minWidth: 100 }}
                        >
                            Close
                        </Button>
                    </DialogActions>
                </Dialog>

                {/* Edit Template Dialog */}
                <Dialog
                    open={editDialogOpen}
                    onClose={handleCloseEditDialog}
                    maxWidth="md"
                    fullWidth
                    aria-labelledby="edit-dialog-title"
                    PaperProps={{
                        sx: {
                            borderRadius: 2,
                            boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
                        }
                    }}
                >
                    <DialogTitle id="edit-dialog-title" sx={{ pb: 1 }}>
                        <Box display="flex" alignItems="center" gap={2}>
                            <Edit sx={{ color: 'secondary.main' }} />
                            <Typography variant="h5" sx={{ fontWeight: 600 }}>
                                Edit Template
                            </Typography>
                        </Box>
                    </DialogTitle>
                    <DialogContent sx={{ pt: 2 }}>
                        {templateToEdit && (
                            <Box>
                                <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
                                    Template editing functionality will be implemented here.
                                    This will allow admins to update template details, banner, theme colors, and other properties.
                                </Typography>
                                <Typography variant="body2" color="primary.main" sx={{ fontWeight: 500 }}>
                                    Template: {templateToEdit.TEMPLATE_NAME}
                                </Typography>
                            </Box>
                        )}
                    </DialogContent>
                    <DialogActions sx={{ p: 3 }}>
                        <Button
                            onClick={handleCloseEditDialog}
                            variant="outlined"
                            sx={{ minWidth: 100 }}
                        >
                            Cancel
                        </Button>
                        <Button
                            onClick={handleCloseEditDialog}
                            variant="contained"
                            color="secondary"
                            sx={{ minWidth: 100 }}
                        >
                            Save Changes
                        </Button>
                    </DialogActions>
                </Dialog>

                {/* Manage Access Dialog */}
                <Dialog
                    open={manageAccessDialogOpen}
                    onClose={handleCloseManageAccessDialog}
                    maxWidth="lg"
                    fullWidth
                    aria-labelledby="manage-access-dialog-title"
                    PaperProps={{
                        sx: {
                            borderRadius: 2,
                            boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
                        }
                    }}
                >
                    <DialogTitle id="manage-access-dialog-title" sx={{ pb: 1 }}>
                        <Box display="flex" alignItems="center" gap={2}>
                            <People sx={{ color: 'info.main' }} />
                            <Typography variant="h5" sx={{ fontWeight: 600 }}>
                                Manage Template Access
                            </Typography>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                            Grant or revoke access to: <strong>{templateForAccess?.TEMPLATE_NAME}</strong>
                        </Typography>
                    </DialogTitle>
                    <DialogContent sx={{ pt: 2 }}>
                        {loadingEmployees ? (
                            <Box display="flex" justifyContent="center" alignItems="center" py={4}>
                                <CircularProgress />
                                <Typography variant="body1" sx={{ ml: 2 }}>
                                    Loading employees...
                                </Typography>
                            </Box>
                        ) : (
                            <Box>
                                {/* Employee Search */}
                                <Box mb={3}>
                                    <TextField
                                        fullWidth
                                        placeholder="Search by employee code or name..."
                                        value={employeeSearchQuery}
                                        onChange={handleEmployeeSearchChange}
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Search />
                                                </InputAdornment>
                                            ),
                                        }}
                                        size="small"
                                    />
                                </Box>

                                {/* Access Summary */}
                                {(() => {
                                    const currentAccessList = templateForAccess?.TEMPLATE_ACCESS_EMP_NAMES
                                        ? templateForAccess.TEMPLATE_ACCESS_EMP_NAMES.split(',').map(name => name.trim()).filter(name => name)
                                        : [];
                                    const hasAccessCount = currentAccessList.length;
                                    const totalEmployees = employees.length;

                                    return (
                                        <Box mb={3} p={2} sx={{ backgroundColor: 'rgba(25, 118, 210, 0.04)', borderRadius: 1, border: '1px solid rgba(25, 118, 210, 0.12)' }}>
                                            <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                                                <Typography variant="h6" color="primary" sx={{ fontWeight: 600 }}>
                                                    Access Summary
                                                </Typography>
                                                <Box display="flex" gap={2}>
                                                    <Chip
                                                        label={`${hasAccessCount} users have access`}
                                                        color="success"
                                                        variant="outlined"
                                                        size="small"
                                                    />
                                                    <Chip
                                                        label={`${totalEmployees - hasAccessCount} users without access`}
                                                        color="default"
                                                        variant="outlined"
                                                        size="small"
                                                    />
                                                </Box>
                                            </Box>
                                            <Typography variant="body2" color="text.secondary">
                                                Users with access are shown at the top of the table for easy identification
                                            </Typography>
                                        </Box>
                                    );
                                })()}

                                {/* Employee Stats */}
                                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                    <Typography variant="body2" color="text.secondary">
                                        Showing {filteredEmployees.length} of {employees.length} employees
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Page {employeeCurrentPage} of {employeeTotalPages}
                                    </Typography>
                                </Box>

                                {/* Employee Access Table */}
                                <TableContainer sx={{ maxHeight: 400, border: '1px solid #e0e0e0' }}>
                                    <Table stickyHeader>
                                        <TableHead>
                                            <TableRow>
                                                <TableCell sx={{
                                                    backgroundColor: 'primary.main',
                                                    color: 'white',
                                                    fontWeight: 'bold',
                                                    position: 'sticky',
                                                    top: 0,
                                                    zIndex: 1,
                                                    minWidth: 80
                                                }}>
                                                    Sr. No.
                                                </TableCell>
                                                <TableCell sx={{
                                                    backgroundColor: 'primary.main',
                                                    color: 'white',
                                                    fontWeight: 'bold',
                                                    position: 'sticky',
                                                    top: 0,
                                                    zIndex: 1,
                                                    minWidth: 120
                                                }}>
                                                    Employee Code
                                                </TableCell>
                                                <TableCell sx={{
                                                    backgroundColor: 'primary.main',
                                                    color: 'white',
                                                    fontWeight: 'bold',
                                                    position: 'sticky',
                                                    top: 0,
                                                    zIndex: 1,
                                                    minWidth: 200
                                                }}>
                                                    Employee Name
                                                </TableCell>
                                                <TableCell sx={{
                                                    backgroundColor: 'primary.main',
                                                    color: 'white',
                                                    fontWeight: 'bold',
                                                    position: 'sticky',
                                                    top: 0,
                                                    zIndex: 1,
                                                    minWidth: 150
                                                }}>
                                                    Action
                                                </TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {paginatedEmployees.map((employee, index) => {
                                                const globalIndex = employeeStartIndex + index + 1;

                                                // Check if employee has access
                                                const currentAccessList = templateForAccess?.TEMPLATE_ACCESS_EMP_NAMES
                                                    ? templateForAccess.TEMPLATE_ACCESS_EMP_NAMES.split(',').map(name => name.trim()).filter(name => name)
                                                    : [];
                                                const hasAccess = currentAccessList.includes(employee.display_name);

                                                return (
                                                    <TableRow
                                                        key={employee.id}
                                                        hover
                                                        sx={{
                                                            backgroundColor: hasAccess ? 'rgba(76, 175, 80, 0.04)' : 'transparent',
                                                            '&:hover': {
                                                                backgroundColor: hasAccess ? 'rgba(76, 175, 80, 0.08)' : 'rgba(0, 0, 0, 0.04)'
                                                            }
                                                        }}
                                                    >
                                                        <TableCell>
                                                            <Box display="flex" alignItems="center" gap={1}>
                                                                <Typography variant="body2" fontWeight="medium">
                                                                    {globalIndex}
                                                                </Typography>
                                                                {hasAccess && (
                                                                    <Chip
                                                                        label="Has Access"
                                                                        color="success"
                                                                        size="small"
                                                                        variant="outlined"
                                                                        sx={{ fontSize: '0.7rem', height: 20 }}
                                                                    />
                                                                )}
                                                            </Box>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography variant="body2" fontWeight="medium" color="primary">
                                                                {employee.emp_code}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Typography variant="body2">
                                                                {employee.display_name || 'Unknown'}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Box display="flex" alignItems="center" gap={1}>
                                                                <Typography variant="body2" color="text.secondary">
                                                                    Revoke
                                                                </Typography>
                                                                <Switch
                                                                    checked={hasAccess}
                                                                    onChange={() => handleAccessToggle(
                                                                        employee.emp_code,
                                                                        employee.display_name,
                                                                        hasAccess
                                                                    )}
                                                                    disabled={accessUpdates[employee.emp_code] === 'updating'}
                                                                    color="primary"
                                                                />
                                                                <Typography variant="body2" color="primary" fontWeight="medium">
                                                                    Grant
                                                                </Typography>
                                                                {accessUpdates[employee.emp_code] === 'updating' && (
                                                                    <CircularProgress size={16} />
                                                                )}
                                                                {accessUpdates[employee.emp_code] === 'success' && (
                                                                    <Chip label="Updated" color="success" size="small" />
                                                                )}
                                                                {accessUpdates[employee.emp_code] === 'error' && (
                                                                    <Chip label="Error" color="error" size="small" />
                                                                )}
                                                            </Box>
                                                        </TableCell>
                                                    </TableRow>
                                                );
                                            })}
                                        </TableBody>
                                    </Table>
                                </TableContainer>

                                {/* Employee Pagination */}
                                {employeeTotalPages > 1 && (
                                    <Box display="flex" justifyContent="center" mt={3}>
                                        <Pagination
                                            count={employeeTotalPages}
                                            page={employeeCurrentPage}
                                            onChange={handleEmployeePageChange}
                                            color="primary"
                                            showFirstButton
                                            showLastButton
                                            size="small"
                                        />
                                    </Box>
                                )}

                                {/* Empty State */}
                                {filteredEmployees.length === 0 && !loadingEmployees && (
                                    <Box textAlign="center" py={4}>
                                        <Typography variant="h6" color="text.secondary">
                                            {employeeSearchQuery ? 'No employees found' : 'No employees available'}
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            {employeeSearchQuery
                                                ? 'Try adjusting your search criteria'
                                                : 'No non-admin employees available for access management'
                                            }
                                        </Typography>
                                    </Box>
                                )}
                            </Box>
                        )}
                    </DialogContent>
                    <DialogActions sx={{ p: 3 }}>
                        <Button
                            onClick={handleCloseManageAccessDialog}
                            variant="outlined"
                            sx={{ minWidth: 100 }}
                        >
                            Close
                        </Button>
                    </DialogActions>
                </Dialog>

                {/* Snackbar for notifications */}
                <Snackbar
                    open={snackbarOpen}
                    autoHideDuration={6000}
                    onClose={handleCloseSnackbar}
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                >
                    <Alert
                        onClose={handleCloseSnackbar}
                        severity={snackbarSeverity}
                        sx={{ width: '100%' }}
                    >
                        {snackbarMessage}
                    </Alert>
                </Snackbar>

            </Container>
        </>
    );
};

export default TemplatesTable;
