'use client';
import React, { useMemo } from 'react';
import { Stack, Autocomplete, TextField, Box, Typography } from '@mui/material';

const statusOptions = [
    { value: 'Draft', label: 'Draft' },
    { value: 'In Progress', label: 'In Progress' },
    { value: 'Send for Approval', label: 'Send for Approval' },
];

export default function StatusUpdate({
    documentId,
    documentStatus,
    isFinalized,             // boolean for Approved/Rejected
    getAuthHeaders,
    showSnackbar,
    onLocalStatusChange,     // (newStatus) => void
}) {
    const currentOption = useMemo(
        () => statusOptions.find(s => s.value === documentStatus) || statusOptions[0],
        [documentStatus]
    );

    const updateStatus = async (newStatus) => {
        try {
            showSnackbar('Updating status...', 'info');
            const headers = getAuthHeaders();
            const res = await fetch(`/api/client-mis-documents/${documentId}/status`, {
                method: 'PUT',
                headers,
                credentials: 'include',
                body: JSON.stringify({ status: newStatus }),
            });
            if (!res.ok) throw new Error('Failed to update status');
            await res.json().catch(() => ({}));
            onLocalStatusChange?.(newStatus);
            showSnackbar(`Status updated to ${newStatus}`, 'success');
        } catch (e) {
            showSnackbar(e.message || 'Error updating status', 'error');
        }
    };

    return (
        <Box id="sm-autocomplete" className="textfield auto-complete no-clear">
            <Typography variant="h6" className="primary" sx={{ paddingBottom: '2px' }}>Status:</Typography>
            <Autocomplete
                sx={{ minWidth: 135 }}
                options={statusOptions}
                getOptionLabel={(option) => option.label}
                value={currentOption}
                disabled={isFinalized}
                onChange={(_, newValue) => {
                    if (!newValue) return;
                    if (isFinalized) {
                        showSnackbar('Cannot change status - document is already finalized', 'warning');
                        return;
                    }
                    // Only update if the status actually changed
                    if (newValue.value !== documentStatus) {
                        updateStatus(newValue.value);
                    }
                }}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        variant="standard"
                        size="small"
                        sx={{
                            '& .MuiInput-underline:before': {
                                borderBottomColor:
                                    documentStatus === 'Draft' ? 'grey.500' :
                                        documentStatus === 'In Progress' ? 'warning.main' :
                                            documentStatus === 'Send for Approval' ? 'info.main' :
                                                documentStatus === 'Approved' ? 'success.main' :
                                                    documentStatus === 'Rejected' ? 'error.main' : 'grey.500',
                                borderBottomWidth: 2
                            },
                            '& .MuiInput-underline:hover:before': {
                                borderBottomColor:
                                    documentStatus === 'Draft' ? 'grey.500' :
                                        documentStatus === 'In Progress' ? 'warning.main' :
                                            documentStatus === 'Send for Approval' ? 'info.main' :
                                                documentStatus === 'Approved' ? 'success.main' :
                                                    documentStatus === 'Rejected' ? 'error.main' : 'grey.500'
                            },
                            '& .MuiInput-underline:after': {
                                borderBottomColor:
                                    documentStatus === 'Draft' ? 'grey.500' :
                                        documentStatus === 'In Progress' ? 'warning.main' :
                                            documentStatus === 'Send for Approval' ? 'info.main' :
                                                documentStatus === 'Approved' ? 'success.main' :
                                                    documentStatus === 'Rejected' ? 'error.main' : 'grey.500'
                            }
                        }}
                    />
                )}
                isOptionEqualToValue={(option, value) => option.value === value.value}
            />
        </Box>
    );
}
