'use client';
import React, { useState, useEffect, useRef } from 'react';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Box,
  Typography,
  Chip,
  CircularProgress,
  Divider,
  Tooltip
} from '@mui/material';
import { CheckCircle, Cancel, Add, Close } from '@mui/icons-material';

/** Circular progress with % label */
function CircularProgressWithLabel({ value, size = 64 }) {
  return (
    <Box sx={{ position: 'relative', display: 'inline-flex' }}>
      <CircularProgress variant="determinate" value={value} size={size} />
      <Box
        sx={{
          top: 0, left: 0, bottom: 0, right: 0,
          position: 'absolute', display: 'flex',
          alignItems: 'center', justifyContent: 'center'
        }}
      >
        <Typography variant="caption" component="div" sx={{ color: 'text.secondary' }}>
          {`${Math.round(value)}%`}
        </Typography>
      </Box>
    </Box>
  );
}

/** Processing/result dialog */
function ProcessingDialog({
  open,
  status,              // 'processing' | 'success' | 'error'
  action,              // 'approve' | 'reject'
  progress,
  primaryRecipient,
  ccEmails = [],
  resultTitle,         // e.g., 'MIS Approved' | 'MIS Rejected' | error title
  resultMessage,       // extra line (e.g., email sent/failed)
  onClose,             // enabled when not 'processing'
}) {
  const isApprove = action === 'approve';
  const isProcessing = status === 'processing';
  const isSuccess = status === 'success';

  return (
    <Dialog
      open={open}
      onClose={isProcessing ? undefined : onClose}
      maxWidth="xs"
      fullWidth
      PaperProps={{ sx: { p: 2 } }}
    >
      <DialogTitle className="custom-dialog-title">
        {isProcessing ? (isApprove ? 'Processing Approval' : 'Processing Rejection') : resultTitle}
      </DialogTitle>

      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'center', textAlign: 'center' }}>
          {isProcessing ? (
            <>
              <CircularProgressWithLabel value={progress} />
              <Typography variant="body2" color="text.secondary">
                {progress < 100 ? 'Contacting server and processing request…' : 'Finalizing…'}
              </Typography>
            </>
          ) : (
            <>
              <CheckCircle
                color={isSuccess ? 'success' : 'error'}
                sx={{ fontSize: 48, mt: 1 }}
              />
              {resultMessage && (
                <Typography variant="body2" color="text.secondary">{resultMessage}</Typography>
              )}
            </>
          )}

          <Divider sx={{ my: 1, width: '100%' }} />

          <Box sx={{ width: '100%', textAlign: 'left' }}>
            <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Primary Recipient</Typography>
            <Chip label={primaryRecipient || '—'} size="small" />
          </Box>

          <Box sx={{ width: '100%', textAlign: 'left' }}>
            <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
              CC (optional) – recipients receive a copy only
            </Typography>
            {ccEmails?.length ? (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {ccEmails.map((e) => (
                  <Chip key={e} label={e} size="small" variant="outlined" />
                ))}
              </Box>
            ) : (
              <Typography variant="caption" color="text.secondary">No CC recipients</Typography>
            )}
          </Box>
        </Box>
      </DialogContent>

      <DialogActions className="custom-dialog-action" sx={{ pt: 1 }}>
        <Button
          onClick={onClose}
          disabled={isProcessing}
          className="main-btn btn-tertiary"
        >
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export default function ReviewComponent({
  documentId,
  isAdmin,
  documentStatus,                 // e.g., 'Send for Approval'
  documentData,                   // creator email + header info
  htmlContent,                    // HTML preview
  getAuthHeaders,                 // () => headers with auth
  onStatusLocallySet,             // (newStatus: 'Approved'|'Rejected') => void
  showSnackbar = () => { },        // (msg, severity) => void
  buttonClassName = 'main-btn sm btn-primary',
  buttonLabel = 'Review',
  buttonTooltip = 'Review document (Admin only)',
}) {
  const [open, setOpen] = useState(false);
  const [reviewComment, setReviewComment] = useState('');
  const [ccEmails, setCcEmails] = useState([]);
  const [ccInput, setCcInput] = useState('');
  const [ccError, setCcError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [recipientEmail, setRecipientEmail] = useState(''); // Editable recipient email
  const [reviewAction, setReviewAction] = useState(null); // 'approve' | 'reject' | null

  // processing dialog state
  const [processingOpen, setProcessingOpen] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('processing'); // 'processing' | 'success' | 'error'
  const [progress, setProgress] = useState(0);
  const [resultTitle, setResultTitle] = useState('');
  const [resultMessage, setResultMessage] = useState('');
  const progressTimerRef = useRef(null);

  const canReview = isAdmin && documentStatus === 'Send for Approval';

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric', month: 'long', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleAddCcEmail = () => {
    const email = ccInput.trim();
    if (!email) return setCcError('Please enter an email address');
    if (!validateEmail(email)) return setCcError('Please enter a valid email address');
    if (ccEmails.includes(email)) return setCcError('This email is already added');
    if (email === recipientEmail) return setCcError('This email is already the primary recipient');
    setCcEmails((prev) => [...prev, email]);
    setCcInput('');
    setCcError('');
  };

  const handleRemoveCcEmail = (emailToRemove) => {
    setCcEmails((prev) => prev.filter((e) => e !== emailToRemove));
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddCcEmail();
    }
  };

  const startProcessing = () => {
    setProcessingStatus('processing');
    setResultTitle('');
    setResultMessage('');
    setProgress(0);
    setProcessingOpen(true);

    if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    // Smooth progress up to ~90%
    progressTimerRef.current = setInterval(() => {
      setProgress((p) => (p < 90 ? p + 2 : 90));
    }, 120);
  };

  const setProcessingSuccess = (title, message) => {
    if (progressTimerRef.current) {
      clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
    setProgress(100);
    setProcessingStatus('success');
    setResultTitle(title);
    setResultMessage(message || '');
  };

  const setProcessingError = (title, message) => {
    if (progressTimerRef.current) {
      clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
    setProgress(100);
    setProcessingStatus('error');
    setResultTitle(title || 'Failed');
    setResultMessage(message || 'Something went wrong.');
  };

  const handleCloseMainDialog = () => {
    if (processingStatus === 'processing') return; // keep open if still processing (safety)
    // reset main dialog fields
    setReviewComment('');
    setReviewAction(null);
    setEmailError('');
    setRecipientEmail(''); // Reset recipient email
    setCcEmails([]);
    setCcInput('');
    setCcError('');
    setOpen(false);
  };

  const handleCloseProcessing = () => {
    // user closes the processing/result dialog manually
    setProcessingOpen(false);
  };

  const handleReview = async (action /* 'approve' | 'reject' */) => {
    setReviewAction(action);

    const emailToSend = recipientEmail || documentData?.CREATED_BY_EMAIL;
    if (!emailToSend || !validateEmail(emailToSend)) {
      setEmailError('Valid recipient email is required');
      setReviewAction(null);
      return;
    }
    setEmailError('');

    try {
      startProcessing();
      showSnackbar(`${action === 'approve' ? 'Approving' : 'Rejecting'} document...`, 'info');

      const headers = getAuthHeaders?.() || {};
      const res = await fetch(`/api/client-mis-documents/${documentId}/review`, {
        method: 'POST',
        headers,
        credentials: 'include',
        body: JSON.stringify({
          action,          // 'approve' | 'reject'
          reviewComment,
          recipientEmail: emailToSend, // Send the edited email
          // CCs are passed separately; backend should keep creator as primary recipient.
          ccEmails,
        }),
      });

      if (!res.ok) {
        const errText = await res.text().catch(() => '');
        throw new Error(errText || 'Review action failed');
      }

      const result = await res.json().catch(() => ({}));
      const newStatus = action === 'approve' ? 'Approved' : 'Rejected';
      onStatusLocallySet?.(newStatus);

      // Close the main dialog now that the action is done
      setOpen(false);

      // COMMENTED OUT FOR TESTING - Email status messages disabled
      // const emailStatus = result.emailSent ? 'Email notification sent.' : 'Email notification failed.';
      const title = newStatus === 'Approved' ? 'MIS Approved' : 'MIS Rejected';
      // setProcessingSuccess(title, emailStatus);
      setProcessingSuccess(title, 'Request processed successfully.');

      showSnackbar(`Document ${newStatus}. Request processed successfully.`, 'success');

      // reset main form bits (keep processing dialog open until user closes)
      setReviewComment('');
      setRecipientEmail('');
      setCcEmails([]);
      setReviewAction(null);
    } catch (e) {
      const title = reviewAction === 'approve' ? 'Approval Failed' : 'Rejection Failed';
      setProcessingError(title, e.message || 'Error performing review action');
      showSnackbar(e.message || 'Error performing review action', 'error');
      setReviewAction(null);
    }
  };

  // Initialize recipient email when dialog opens
  useEffect(() => {
    if (open && documentData?.CREATED_BY_EMAIL) {
      setRecipientEmail(documentData.CREATED_BY_EMAIL);
    }
  }, [open, documentData?.CREATED_BY_EMAIL]);

  useEffect(() => {
    return () => {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    };
  }, []);

  if (!canReview) return null;

  return (
    <>
      <Tooltip title={buttonTooltip} arrow>
        <Button
          variant="contained"
          color="primary"
          onClick={() => setOpen(true)}
          className={buttonClassName}
        >
          {buttonLabel}
        </Button>
      </Tooltip>

      {/* Main review dialog */}
      <Dialog
        open={open}
        onClose={handleCloseMainDialog}
        maxWidth="md"
        fullWidth
        PaperProps={{ sx: { maxHeight: '90vh', overflow: 'hidden' } }}
      >
        <DialogTitle className="custom-dialog-title">
          Review Document: <span className="fw7">{documentData?.MIS_DOCUMENT_NAME}</span>
        </DialogTitle>

        <DialogContent>
          {/* Document Information */}
          <Box sx={{ my: 3 }}>
            <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
              <strong>Client:</strong> {documentData?.SSO_CLIENT_NAME}
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
              <strong>Created by:</strong> {documentData?.CREATED_BY}
              &nbsp;|&nbsp;
              <strong>Created On:</strong> {formatDate(documentData?.CREATED_AT)}
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
              <strong>Email ID:</strong> {documentData?.CREATED_BY_EMAIL}
            </Typography>
          </Box>

          {/* Email Configuration */}
          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom>Email Configuration</Typography>

            <Box className="textfield auto-complete" mt={3} mb={2}>
              <TextField
                fullWidth
                label="Recipient (Primary Email)"
                value={recipientEmail}
                onChange={(e) => {
                  setRecipientEmail(e.target.value);
                  if (emailError) setEmailError(''); // Clear error on change
                }}
                error={!!emailError}
                helperText={emailError || 'Admin can edit this email address'}
                placeholder="Enter recipient email address"
              />
            </Box>

            <Divider sx={{ my: 2 }} />

            <Box sx={{ mb: 2 }}>
              <Typography variant="h6" gutterBottom>CC Recipients (Optional)</Typography>
              <Box sx={{ display: 'flex', gap: 1 }} mt={2} mb={2}>
                <Box className="textfield auto-complete w100">
                  <TextField
                    fullWidth
                    size="small"
                    label="Add CC email"
                    value={ccInput}
                    onChange={(e) => setCcInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Enter email address and press Enter or click Add"
                    error={!!ccError}
                    helperText={ccError}
                  />
                </Box>
                <Button
                  variant="outlined"
                  onClick={handleAddCcEmail}
                  disabled={!ccInput.trim()}
                  startIcon={<Add />}
                  sx={{ minWidth: 'auto', px: 2 }}
                >
                  Add
                </Button>
              </Box>

              {/* CC Email Chips */}
              {ccEmails.length > 0 && (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {ccEmails.map((email) => (
                    <Chip
                      key={email}
                      label={email}
                      onDelete={() => handleRemoveCcEmail(email)}
                      deleteIcon={<Close />}
                      color="primary"
                      variant="outlined"
                      size="small"
                    />
                  ))}
                </Box>
              )}
            </Box>
          </Box>

          <Divider sx={{ my: 2 }} />

          {/* Review Comment */}
          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom>Review Comment (Optional)</Typography>
            <Box className="textfield auto-complete w100" mt={2}>
              <TextField
                fullWidth
                multiline
                rows={2}
                label="Add any comments about your decision..."
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="Provide feedback or instructions for the document creator..."
              />
            </Box>
          </Box>

          <Divider sx={{ my: 2 }} />

          {/* Document Preview */}
          <Box sx={{ mb: 2, overflow: 'hidden' }}>
            <Typography variant="subtitle2" gutterBottom>Document Preview</Typography>
            <Box
              sx={{
                border: '1px solid #e0e0e0',
                borderRadius: 1,
                p: 2,
                maxHeight: '300px',
                overflow: 'auto',
                backgroundColor: '#fafafa',
                margin: 'auto',
                display: 'flex',
                justifyContent: 'center'
              }}
            >
              {htmlContent ? (
                <div
                  dangerouslySetInnerHTML={{ __html: htmlContent }}
                  style={{ transform: 'scale(0.5)', transformOrigin: 'top center', width: '200%' }}
                />
              ) : (
                <p>No content available</p>
              )}
            </Box>
          </Box>
        </DialogContent>

        <DialogActions className="custom-dialog-action" sx={{ pt: 1 }}>
          <Button onClick={() => setOpen(false)} className="main-btn btn-tertiary">
            Cancel
          </Button>
          <Button
            onClick={() => handleReview('reject')}
            color="error"
            variant="outlined"
            startIcon={<Cancel />}
            className="main-btn btn-error"
          >
            Reject
          </Button>
          <Button
            onClick={() => handleReview('approve')}
            color="success"
            variant="contained"
            startIcon={<CheckCircle />}
            className="main-btn btn-primary"
          >
            Approve
          </Button>
        </DialogActions>
      </Dialog>

      {/* Processing / Result dialog (stays until user closes) */}
      <ProcessingDialog
        open={processingOpen}
        status={processingStatus}
        action={reviewAction}
        progress={progress}
        primaryRecipient={recipientEmail || documentData?.CREATED_BY_EMAIL}
        ccEmails={ccEmails}
        resultTitle={resultTitle}
        resultMessage={resultMessage}
        onClose={handleCloseProcessing}
      />
    </>
  );
}
