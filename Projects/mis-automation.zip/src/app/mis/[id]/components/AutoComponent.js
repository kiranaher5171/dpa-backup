'use client';
import React, { useEffect, useRef, useCallback, useState } from 'react';
import { Stack, Button, Tooltip, Snackbar, Alert, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, CircularProgress, Typography, Box } from '@mui/material';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import DownloadIcon from '@mui/icons-material/Download';
import SaveIcon from '@mui/icons-material/Save';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import Link from 'next/link';


export default function AutoComponent({
    documentId,
    documentStatus,                 // to block autosave on Approved
    showHtmlPreview,                // to block autosave in preview
    initialLoadingComplete,
    isParsingExistingHTML,
    loadingData,
    dynamicElements,
    generateHTML,                   // () => string
    getAuthHeaders,
    onSaved,                        // (html) => void
    setSaveStatus,                  // 'saving' | 'saved' | 'error'
    showSnackbar,
    htmlContent,                    // current html for copy/download
}) {
    const timerRef = useRef(null);
    const lastSavedElementsRef = useRef(null);
    
    // PDF generation dialog state
    const [pdfDialogOpen, setPdfDialogOpen] = useState(false);
    const [pdfGenerationStatus, setPdfGenerationStatus] = useState('generating'); // 'generating' | 'success' | 'error'

    // Check if dynamicElements have actually changed
    const hasElementsChanged = useCallback(() => {
        if (!lastSavedElementsRef.current) {
            console.log('🔄 Auto-save: First save, elements have changed');
            return true;
        }

        if (lastSavedElementsRef.current.length !== dynamicElements.length) {
            console.log('🔄 Auto-save: Element count changed', {
                previous: lastSavedElementsRef.current.length,
                current: dynamicElements.length
            });
            return true;
        }

        // Quick check: compare stringified versions first
        const currentString = JSON.stringify(dynamicElements);
        const lastString = JSON.stringify(lastSavedElementsRef.current);

        if (currentString !== lastString) {
            console.log('🔄 Auto-save: Elements content changed');
            return true;
        }

        console.log('⏭️ Auto-save: No changes detected, skipping save');
        return false;
    }, [dynamicElements]);

    // Debounced autosave replicating your logic
    useEffect(() => {
        console.log('🔍 Auto-save useEffect triggered', {
            initialLoadingComplete,
            isParsingExistingHTML,
            loadingData,
            dynamicElementsLength: dynamicElements.length,
            documentStatus,
            showHtmlPreview,
            hasElementsChanged: hasElementsChanged()
        });

        if (!initialLoadingComplete || isParsingExistingHTML) {
            console.log('⏭️ Auto-save: Skipping - initial loading not complete or parsing in progress');
            return;
        }
        if (loadingData || dynamicElements.length === 0) {
            console.log('⏭️ Auto-save: Skipping - loading data or no elements');
            return;
        }
        if (documentStatus === 'Approved') {
            console.log('⏭️ Auto-save: Skipping - document is approved (no changes allowed)');
            return;
        }
        if (showHtmlPreview) {
            console.log('⏭️ Auto-save: Skipping - HTML preview is active');
            return;
        }
        if (!hasElementsChanged()) {
            console.log('⏭️ Auto-save: Skipping - no changes detected');
            return;
        }

        console.log('🚀 Auto-save: Starting debounced save...');
        timerRef.current && clearTimeout(timerRef.current);
        timerRef.current = setTimeout(async () => {
            try {
                console.log('💾 Auto-save: Executing save...');
                setSaveStatus?.('saving');
                const completeHTML = generateHTML();

                const headers = getAuthHeaders();
                const res = await fetch(`/api/client-mis-documents/${documentId}`, {
                    method: 'PUT',
                    headers,
                    body: JSON.stringify({
                        htmlTemplate: completeHTML,
                        status: documentStatus || 'Draft',
                        dynamicElements,
                    }),
                });

                if (!res.ok) throw new Error('Auto-save failed');
                console.log('✅ Auto-save: Successfully saved');
                setSaveStatus?.('saved');
                onSaved?.(completeHTML);

                // Update the last saved elements reference
                lastSavedElementsRef.current = JSON.parse(JSON.stringify(dynamicElements));
            } catch (e) {
                console.error('❌ Auto-save: Error occurred', e);
                setSaveStatus?.('error');
                showSnackbar(e.message || 'Error auto-saving', 'error');
            }
        }, 2000);

        return () => {
            if (timerRef.current) {
                clearTimeout(timerRef.current);
                timerRef.current = null;
            }
        };
    }, [
        documentId, documentStatus, showHtmlPreview, initialLoadingComplete,
        isParsingExistingHTML, loadingData, dynamicElements, generateHTML,
        getAuthHeaders, onSaved, setSaveStatus, showSnackbar, hasElementsChanged
    ]);

    const handleManualSave = async () => {
        // Prevent saving if document is approved
        if (documentStatus === 'Approved') {
            showSnackbar('Cannot save changes to an approved document', 'warning');
            return;
        }

        try {
            setSaveStatus?.('saving');
            const completeHTML = generateHTML();
            const headers = getAuthHeaders();
            const res = await fetch(`/api/client-mis-documents/${documentId}`, {
                method: 'PUT',
                headers,
                body: JSON.stringify({
                    htmlTemplate: completeHTML,
                    status: documentStatus || 'Draft',
                    dynamicElements,
                }),
            });
            if (!res.ok) throw new Error('Failed to save');
            setSaveStatus?.('saved');
            onSaved?.(completeHTML);
            showSnackbar('Saved successfully', 'success');
        } catch (e) {
            setSaveStatus?.('error');
            showSnackbar(e.message || 'Error saving document', 'error');
        }
    };

    const handleCopyCode = () => {
        navigator.clipboard.writeText(htmlContent || '');
        showSnackbar('Code copied to clipboard!', 'success');
    };

    const handleDownloadHTML = () => {
        const currentDate = new Date().toISOString().split('T')[0];
        const name = `MIS-Document-${currentDate}.html`;
        const file = new Blob([htmlContent || ''], { type: 'text/html' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(file);
        a.download = name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    const handleDownloadPDF = async () => {
        try {
            // Open dialog and set generating status
            setPdfDialogOpen(true);
            setPdfGenerationStatus('generating');
            
            const headers = getAuthHeaders();
            const response = await fetch('/api/generate-pdf', {
                method: 'POST',
                headers: {
                    ...headers,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    htmlContent: htmlContent || '',
                    documentId: documentId,
                }),
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                if (errorData.code === 'CHROME_LAUNCH_ERROR') {
                    throw new Error('PDF generation is temporarily unavailable due to server configuration. Please try again later or contact support.');
                }
                throw new Error(errorData.details || 'Failed to generate PDF');
            }

            const blob = await response.blob();
            const currentDate = new Date().toISOString().split('T')[0];
            const name = `MIS-Document-${currentDate}.pdf`;
            
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = name;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            // Update dialog to show success
            setPdfGenerationStatus('success');
        } catch (error) {
            console.error('Error generating PDF:', error);
            
            // If it's a Chrome launch error, try alternative method
            if (error.message.includes('server configuration') || error.message.includes('temporarily unavailable')) {
                try {
                    console.log('🔄 Trying alternative PDF generation method...');
                    
                    const altResponse = await fetch('/api/generate-pdf-alternative', {
                        method: 'POST',
                        headers: {
                            ...headers,
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            htmlContent: htmlContent || '',
                            documentId: documentId,
                        }),
                    });

                    if (altResponse.ok) {
                        const blob = await altResponse.blob();
                        const currentDate = new Date().toISOString().split('T')[0];
                        const name = `MIS-Document-${currentDate}.html`;
                        
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = name;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        window.URL.revokeObjectURL(url);
                        
                        setPdfGenerationStatus('success');
                        return;
                    }
                } catch (altError) {
                    console.error('Alternative PDF generation also failed:', altError);
                }
            }
            
            setPdfGenerationStatus('error');
        }
    };

    const handleClosePdfDialog = () => {
        setPdfDialogOpen(false);
        setPdfGenerationStatus('generating');
    };

    return (
        <>
            <Stack direction="row" spacing={1}>
                <Tooltip title="Copy HTML Code" arrow>
                    <IconButton size="small" className="action-ico-btn primary" onClick={handleCopyCode}>
                        <ContentCopyIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Download as a HTML" arrow>
                    <IconButton size="small" className="action-ico-btn pending" onClick={handleDownloadHTML}>
                        <DownloadIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Download as PDF" arrow>
                    <IconButton size="small" className="action-ico-btn success" onClick={handleDownloadPDF} disabled={documentStatus !== 'Approved'}>
                        <PictureAsPdfIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Save Manually" arrow>
                    <IconButton size="small" className="action-ico-btn success" onClick={handleManualSave} disabled={documentStatus === 'Approved'}>
                        <SaveIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Back to Dashboard" arrow>
                    <Link href="/main-dashboard">
                        <IconButton size="small" className="back-ico-btn">
                            <KeyboardBackspaceIcon />
                        </IconButton>
                    </Link>
                </Tooltip>
            </Stack>

            {/* PDF Generation Dialog */}
            <Dialog
                open={pdfDialogOpen}
                onClose={pdfGenerationStatus === 'success' ? handleClosePdfDialog : undefined}
                maxWidth="sm"
                fullWidth
                disableEscapeKeyDown={pdfGenerationStatus === 'generating'}
            >
                <DialogContent sx={{ textAlign: 'center', py: 4 }}>
                    {pdfGenerationStatus === 'generating' && (
                        <Box>
                            <CircularProgress size={60} sx={{ mb: 2, color: 'primary.main' }} />
                            <Typography variant="h6" sx={{ mb: 1, fontWeight: 600 }}>
                                Generating PDF
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                Please wait...
                            </Typography>
                        </Box>
                    )}
                    
                    {pdfGenerationStatus === 'success' && (
                        <Box>
                            <CheckCircleIcon 
                                sx={{ 
                                    fontSize: 60, 
                                    color: 'success.main', 
                                    mb: 2 
                                }} 
                            />
                            <Typography variant="h6" sx={{ mb: 1, fontWeight: 600, color: 'success.main' }}>
                                PDF Generated
                            </Typography>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                                Your PDF has been generated and downloaded successfully.
                            </Typography>
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={handleClosePdfDialog}
                                sx={{ minWidth: 100 }}
                            >
                                Close
                            </Button>
                        </Box>
                    )}
                    
                    {pdfGenerationStatus === 'error' && (
                        <Box>
                            <Typography variant="h6" sx={{ mb: 1, fontWeight: 600, color: 'error.main' }}>
                                Error Generating PDF
                            </Typography>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                                There was an error generating your PDF. Please try again.
                            </Typography>
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={handleClosePdfDialog}
                                sx={{ minWidth: 100 }}
                            >
                                Close
                            </Button>
                        </Box>
                    )}
                </DialogContent>
            </Dialog>
        </>
    );
}
