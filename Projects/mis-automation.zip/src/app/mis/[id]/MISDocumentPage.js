'use client'
import React, { useState, useEffect, useCallback, use } from "react";
import { elementTypes } from '@/config/elementTypes';
import SafeImage from '@/components/SafeImage';
import AutoComponent from './components/AutoComponent';
import StatusUpdate from './components/StatusUpdate';
import ReviewComponent from './components/ReviewComponent';
import {
    DndContext,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors,
    DragOverlay,
} from '@dnd-kit/core';
import {
    arrayMove,
    sortableKeyboardCoordinates,
} from '@dnd-kit/sortable';
import {
    Container,
    Typography,
    Box,
    Chip,
    Divider,
    Paper,
    CircularProgress,
    Alert,
    Button,
    Stack,
    Drawer,
    Dialog,
    DialogTitle,
    DialogContent,
    IconButton,
    FormControlLabel,
    Switch,
    Menu,
    Snackbar,
    Checkbox
} from '@mui/material'
import {
    Undo as UndoIcon,
    Redo as RedoIcon,
    ArrowBack,
    BarChart,
    PhotoLibrary,
    Visibility,
    ZoomIn,
    ZoomOut,
    Add,
    TableChart,
    Refresh,
    MoreVert as MoreVertIcon,
    Visibility as VisibilityIcon,
    KeyboardArrowUp,
    KeyboardArrowDown,
    ContentCopy,
    Delete as DeleteIcon,
    CheckCircle as CheckCircleIcon,
    Cancel as CancelIcon
} from '@mui/icons-material'
import ChartBuilder from "@/app/image_generate_components/ChartBuilder";
import TableBuilder from "@/app/image_generate_components/TableBuilder";
import ImageUploader from "@/app/image_generate_components/ImageUploader";
import { IoClose } from "react-icons/io5";
import { validateElement, createElement } from '@/config/elementTypes';

import BasicLayout from '../../layouts/BasicLayout'
import { useEmployeeStore } from '@/store/employeeStore'

import ElementToolbox from "@/components/ElementToolbox";
import DesignCanvas from "@/components/DesignCanvas";
import PropertiesPanel from "@/components/PropertiesPanel";
import ErrorBoundary from "@/components/ErrorBoundary";
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { styled } from '@mui/material/styles';
import SwipeableDrawer from '@mui/material/SwipeableDrawer';
import { grey } from '@mui/material/colors';
import { Global } from '@emotion/react';

const drawerWidth = 320;
const ITEM_HEIGHT = 48;
const propertiesPanelWidth = 320;

const drawerBleeding = 56;



const StyledBox = styled('div')(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.applyStyles('dark', {
        backgroundColor: grey[800],
    }),
}));

const Puller = styled('div')(({ theme }) => ({
    width: 30,
    height: 6,
    backgroundColor: grey[300],
    borderRadius: 3,
    position: 'absolute',
    top: 8,
    left: 'calc(50% - 15px)',
    ...theme.applyStyles('dark', {
        backgroundColor: grey[900],
    }),
}));

const MISDocumentPage = ({ params }) => {
    // Unwrap params Promise for Next.js 15 compatibility
    const unwrappedParams = use(params);

    // Authentication
    const { employeeDetails, userRole } = useEmployeeStore();

    // State declarations
    const [documentData, setDocumentData] = useState(null);
    const [loadingData, setLoadingData] = useState(true);
    const [error, setError] = useState(null);
    const [primaryColor, setPrimaryColor] = useState("#000000");
    const [htmlContent, setHtmlContent] = useState("");
    const [saveStatus, setSaveStatus] = useState('saved');
    const [documentStatus, setDocumentStatus] = useState('draft');
    const [hasParsedElements, setHasParsedElements] = useState(false);
    const [elementsLoadedFromDatabase, setElementsLoadedFromDatabase] = useState(false);
    const [initialLoadingComplete, setInitialLoadingComplete] = useState(false);

    // Editor states
    const [dynamicElements, setDynamicElements] = useState([]);
    const [selectedElementId, setSelectedElementId] = useState(null);
    const [zoom, setZoom] = useState(100);
    const [showGrid, setShowGrid] = useState(true);
    const [showHtmlPreview, setShowHtmlPreview] = useState(false);

    // History for undo/redo
    const [history, setHistory] = useState([]);
    const [historyIndex, setHistoryIndex] = useState(-1);

    // Dialog states
    const [openChart, setOpenChart] = useState(false);
    const [openTable, setOpenTable] = useState(false);
    const [openImage, setOpenImage] = useState(false);

    // Review states - now handled by ReviewComponent

    // Infographics state
    const [infographics, setInfographics] = useState([]);
    const [loadingInfographics, setLoadingInfographics] = useState(false);
    const [infographicsError, setInfographicsError] = useState(null);
    const [selectedInfographic, setSelectedInfographic] = useState(null);
    const [selectedInfographics, setSelectedInfographics] = useState(new Set());

    const [activeId, setActiveId] = useState(null);
    const [isDragging, setIsDragging] = useState(false);
    const [isParsingExistingHTML, setIsParsingExistingHTML] = useState(false);

    // Add new state for swipeable drawer
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [hoveredInfographic, setHoveredInfographic] = useState(null);

    // Properties panel state
    const [showProperties, setShowProperties] = useState(true);

    const [isInitializing, setIsInitializing] = useState(false);

    // Check for session on component mount
    useEffect(() => {
        console.log('🔐 MIS Document: Component mounted, checking session...');

        const sessionData = localStorage.getItem("session");
        if (!sessionData) {
            console.log('🔐 MIS Document: No session found, redirecting to login');
        } else {
            // If we have a session but no employee details, we might be initializing
            if (!employeeDetails) {
                console.log('🔐 MIS Document: Session found but no employee details, might be initializing...');
                setIsInitializing(true);
            } else {
                // Employee details are loaded, stop initializing
                setIsInitializing(false);
            }
        }

        // Cleanup function to reset state when component unmounts
        return () => {
            console.log('🔐 MIS Document: Component unmounting, cleaning up...');
            setIsInitializing(false);
        };
    }, [employeeDetails]);

    // Snackbar states
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'info' // 'error', 'warning', 'info', 'success'
    });

    // Snackbar handlers
    const showSnackbar = useCallback((message, severity = 'info') => {
        setSnackbar({
            open: true,
            message,
            severity
        });
    }, []);

    const handleCloseSnackbar = () => {
        setSnackbar(prev => ({
            ...prev,
            open: false
        }));
    };

    // Helper function to get authentication headers
    const getAuthHeaders = useCallback(() => {
        let accessToken = '';

        // Method 1: From session storage
        const session = localStorage.getItem('session');

        if (session) {
            try {
                const sessionData = JSON.parse(session);
                accessToken = sessionData.accessToken || '';
            } catch (parseError) {
                console.error('Error parsing session data:', parseError);
            }
        }

        // Method 2: Try to get from employee store if session method fails
        if (!accessToken) {
            const { employeeDetails } = useEmployeeStore.getState();
            if (employeeDetails && employeeDetails.accessToken) {
                accessToken = employeeDetails.accessToken;
            }
        }

        // Method 3: Try to get from userData if other methods fail
        if (!accessToken) {
            const userData = localStorage.getItem('userData');
            if (userData) {
                try {
                    const parsedUserData = JSON.parse(userData);
                    if (parsedUserData.accessToken) {
                        accessToken = parsedUserData.accessToken;
                    }
                } catch (parseError) {
                    console.error('Error parsing userData:', parseError);
                }
            }
        }

        const headers = {
            'Content-Type': 'application/json'
        };

        // Add Authorization header if we have a token
        if (accessToken) {
            headers['Authorization'] = `Bearer ${accessToken}`;
        } else {
            console.warn('⚠️ No access token found for authentication');
        }

        return headers;
    }, []);

    // Function to detect used infographics by checking HTML content
    const detectUsedInfographics = useCallback((infographics, htmlContent) => {
        if (!htmlContent || !infographics || infographics.length === 0) {
            return infographics;
        }

        return infographics.map(infographic => {
            const isUsed = htmlContent.includes(infographic.url) || htmlContent.includes(infographic.filename);
            return {
                ...infographic,
                isUsed: isUsed,
                usageDetectedAt: new Date().toISOString()
            };
        });
    }, []);

    // Fetch infographics for the current document
    const fetchInfographics = useCallback(async (documentName) => {
        if (!documentName) {
            console.log('No document name provided for infographics fetch');
            return;
        }

        setLoadingInfographics(true);
        setInfographicsError(null);

        try {
            // Get access token from localStorage
            const session = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('session') : null;
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            const response = await fetch(`/api/infographics?documentName=${encodeURIComponent(documentName)}`, {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`Failed to fetch infographics: ${response.status} ${response.statusText}`);
            }

            const data = await response.json();
            console.log('📊 Fetched infographics response:', data);
            console.log('📊 Response success:', data.success);
            console.log('📊 Response infographics:', data.infographics);
            console.log('📊 Response infographics type:', typeof data.infographics);

            // Process infographics and detect usage
            if (data.success && data.infographics) {
                console.log('📊 Setting infographics to:', data.infographics);
                console.log('📊 Infographics array length:', data.infographics.length);
                console.log('📊 Infographics array type:', Array.isArray(data.infographics) ? 'Array' : typeof data.infographics);

                // Detect used infographics based on current HTML content
                const processedInfographics = detectUsedInfographics(data.infographics, htmlContent);
                setInfographics(processedInfographics);

                console.log('📊 Processed infographics with usage detection:', processedInfographics);
            } else {
                console.warn('Unexpected infographics data format:', data);
                setInfographics([]);
            }
        } catch (error) {
            console.error('Error fetching infographics:', error);
            setInfographicsError(error.message);
            setInfographics([]);
        } finally {
            setLoadingInfographics(false);
        }
    }, [detectUsedInfographics, htmlContent]);



    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 5,
            },
        }),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    // const router = useRouter()



    // For Menu Opening 
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };


    // Check if user is admin
    const isAdmin = userRole === 'admin';

    // Log status changes for debugging
    useEffect(() => {
        console.log('📋 Document status changed to:', documentStatus);
    }, [documentStatus]);





    // Callback functions for new components
    const onSaved = useCallback((html) => {
        setHtmlContent(html);
    }, []);

    const onStatusLocallySet = useCallback((newStatus) => {
        setDocumentStatus(newStatus);
        setDocumentData(prev => prev ? { ...prev, STATUS: newStatus } : prev);
    }, []);

    // Utility function to convert CLOB data to string
    const convertClobToString = (clobData) => {
        if (!clobData) return '';

        if (typeof clobData === 'string') {
            return clobData;
        } else if (typeof clobData === 'object') {
            if (clobData.type === 'CLOB') {
                return clobData.toString();
            } else if (clobData.toString && clobData.toString() !== '[object Object]') {
                return clobData.toString();
            } else {
                // Try to get the actual content from the CLOB object
                return clobData.chunk || clobData.value || '';
            }
        }
        return String(clobData);
    };

    // Utility function to parse THEME_COLORS from various formats (string, array, CLOB object)
    const parseThemeColors = (themeColorsData) => {
        if (!themeColorsData) return [];

        if (typeof themeColorsData === 'string') {
            try {
                return JSON.parse(themeColorsData);
            } catch (e) {
                console.warn('Failed to parse THEME_COLORS string:', e.message);
                return [];
            }
        } else if (Array.isArray(themeColorsData)) {
            return themeColorsData;
        } else if (typeof themeColorsData === 'object') {
            let themeColorsStr = '';
            if (themeColorsData.type === 'CLOB') {
                themeColorsStr = themeColorsData.toString();
            } else if (themeColorsData.toString && themeColorsData.toString() !== '[object Object]') {
                themeColorsStr = themeColorsData.toString();
            } else {
                // Try to get the actual content from the CLOB object
                themeColorsStr = themeColorsData.chunk || themeColorsData.value || '';
            }

            try {
                return JSON.parse(themeColorsStr);
            } catch (e) {
                console.warn('Failed to parse THEME_COLORS CLOB object:', e.message);
                return [];
            }
        }
        return [];
    };

    // Update htmlContent when dynamicElements change
    useEffect(() => {
        // Don't update HTML content during initial loading
        if (!initialLoadingComplete || isParsingExistingHTML) {
            console.log('⏭️ Skipping HTML content update - initial loading not complete or parsing in progress');
            return;
        }

        if (dynamicElements.length > 0) {
            console.log('🔄 Dynamic elements changed, updating HTML content');
            console.log('Current elements count:', dynamicElements.length);
            console.log('Element types:', dynamicElements.map(el => el.type));
            console.log('Elements loaded from database:', elementsLoadedFromDatabase);

            // Always regenerate HTML when elements change to reflect updates
            const newHTML = generateHTML();
            console.log('Generated new HTML length:', newHTML.length);
            console.log('New HTML preview:', newHTML.substring(0, 200));

            setHtmlContent(newHTML);
            console.log('✅ HTML content updated with current elements');
        } else {
            console.log('⚠️ No dynamic elements, clearing HTML content');
            setHtmlContent('');
        }
    }, [dynamicElements, isParsingExistingHTML, initialLoadingComplete]);

    // Set HTML content only on initial document load
    useEffect(() => {
        if (documentData && !hasParsedElements && !loadingData) {
            console.log('🔄 Starting document data loading process...');
            console.log('Current state - hasParsedElements:', hasParsedElements, 'loadingData:', loadingData);
            console.log('Current dynamicElements count:', dynamicElements.length);

            // STEP 1: Load HTML template first
            let templateHTML = '';
            if (documentData.HTML_TEMPLATE) {
                templateHTML = convertClobToString(documentData.HTML_TEMPLATE);
                console.log('📄 HTML template loaded, length:', templateHTML.length);
                // Set the HTML template as the base content
                setHtmlContent(templateHTML);
            }

            // STEP 2: Load DYNAMIC_ELEMENTS from database
            if (documentData.DYNAMIC_ELEMENTS) {
                try {
                    console.log('Found DYNAMIC_ELEMENTS in database:', documentData.DYNAMIC_ELEMENTS);
                    console.log('DYNAMIC_ELEMENTS type:', typeof documentData.DYNAMIC_ELEMENTS);
                    console.log('DYNAMIC_ELEMENTS is array:', Array.isArray(documentData.DYNAMIC_ELEMENTS));

                    let storedElements;

                    // Check if DYNAMIC_ELEMENTS is already an array (from API)
                    if (Array.isArray(documentData.DYNAMIC_ELEMENTS)) {
                        console.log('✅ DYNAMIC_ELEMENTS is already an array from API');
                        storedElements = documentData.DYNAMIC_ELEMENTS;
                    } else {
                        // Convert CLOB to string and parse
                        const elementsData = convertClobToString(documentData.DYNAMIC_ELEMENTS);
                        console.log('Full DYNAMIC_ELEMENTS data:', elementsData);
                        console.log('DYNAMIC_ELEMENTS type:', typeof elementsData);
                        console.log('DYNAMIC_ELEMENTS length:', elementsData.length);

                        // Check if the data is already a string or needs parsing
                        if (typeof elementsData === 'string') {
                            try {
                                storedElements = JSON.parse(elementsData);
                                console.log('Successfully parsed JSON from string');
                            } catch (parseError) {
                                console.error('Error parsing JSON from string:', parseError);
                                console.log('Raw string data:', elementsData);
                                return;
                            }
                        } else {
                            storedElements = elementsData;
                            console.log('Using elementsData directly as object');
                        }
                    }

                    console.log('Parsed stored elements:', storedElements);
                    console.log('Stored elements type:', typeof storedElements);
                    console.log('Stored elements length:', Array.isArray(storedElements) ? storedElements.length : 'Not an array');

                    if (!Array.isArray(storedElements)) {
                        console.error('Stored elements is not an array:', storedElements);
                        return;
                    }

                    // Validate and process elements
                    const validationResults = storedElements.map(element => {
                        const result = validateElement(element);
                        console.log('Validating element:', element.type, 'Result:', result);
                        return result;
                    });

                    const validElements = validationResults
                        .filter(result => result.isValid)
                        .map(result => result.element);

                    console.log('Validation results:', validationResults);
                    console.log('Valid elements count:', validElements.length);

                    // TEMPORARY: Try loading elements without validation to debug
                    if (validElements.length === 0 && storedElements.length > 0) {
                        console.log('⚠️ Validation failed, trying to load elements without validation');
                        console.log('Original stored elements:', storedElements);

                        // Try to load elements directly without validation
                        const directElements = storedElements.map(element => ({
                            ...element,
                            primaryColor: element.primaryColor || '#000000',
                            timestamp: element.timestamp || new Date().toISOString()
                        }));

                        console.log('Direct elements to load:', directElements);

                        if (directElements.length > 0) {
                            console.log('✅ Loading', directElements.length, 'elements directly from DYNAMIC_ELEMENTS database column');
                            setDynamicElements(directElements);
                            setElementsLoadedFromDatabase(true);
                            setHasParsedElements(true);
                            setLoadingData(false);
                            setInitialLoadingComplete(true);
                            console.log('✅ Successfully loaded elements directly from database - ready for editing');
                            return;
                        }
                    }

                    if (validElements.length > 0) {
                        console.log('✅ Loading', validElements.length, 'elements from DYNAMIC_ELEMENTS database column');
                        setDynamicElements(validElements);
                        setElementsLoadedFromDatabase(true);
                        setHasParsedElements(true);
                        setLoadingData(false);
                        setInitialLoadingComplete(true); // Mark initial loading as complete
                        console.log('✅ Successfully loaded elements from database - ready for editing');
                        return; // Exit early since we have valid elements from database
                    } else {
                        console.log('⚠️ DYNAMIC_ELEMENTS found but no valid elements');
                        console.log('Invalid elements:', validationResults.filter(result => !result.isValid));
                    }
                } catch (error) {
                    console.error('Error parsing DYNAMIC_ELEMENTS:', error);
                }
            } else {
                console.log('📝 No DYNAMIC_ELEMENTS found in database');
            }

            // STEP 3: If no DYNAMIC_ELEMENTS, set empty state for new document
            console.log('🔄 No dynamic elements found, setting up for new document creation');
            setDynamicElements([]);
            setHasParsedElements(true);
            setLoadingData(false);
            setInitialLoadingComplete(true); // Mark initial loading as complete
            console.log('✅ Ready for new document creation');
        } else {
            console.log('⏭️ Skipping document loading - hasParsedElements:', hasParsedElements, 'loadingData:', loadingData);
            // Ensure loading is set to false even when skipping
            if (loadingData) {
                setLoadingData(false);
                setInitialLoadingComplete(true); // Mark initial loading as complete
            }
        }
    }, [documentData, loadingData]);

    // Ensure loading state is reset when parsing is complete
    useEffect(() => {
        if (hasParsedElements && loadingData) {
            console.log('🔄 Parsing complete, setting loadingData to false');
            setLoadingData(false);
        }
    }, [hasParsedElements, loadingData]);

    // Debug logging for hasParsedElements changes
    useEffect(() => {
        console.log('🔍 hasParsedElements changed to:', hasParsedElements);
    }, [hasParsedElements]);

    // Ensure loading state is cleared when elements are loaded
    useEffect(() => {
        if (dynamicElements.length > 0 && loadingData) {
            console.log('🔄 Elements loaded, clearing loading state');
            setLoadingData(false);
        }
    }, [dynamicElements, loadingData]);

    // Debug logging for initial loading completion
    useEffect(() => {
        console.log('🔍 initialLoadingComplete changed to:', initialLoadingComplete);
        if (initialLoadingComplete) {
            console.log('✅ Initial loading complete - auto-save now enabled');
            console.log('📄 HTML template loaded:', !!documentData?.HTML_TEMPLATE);
            console.log('📝 Dynamic elements loaded:', dynamicElements.length);
        }
    }, [initialLoadingComplete, documentData, dynamicElements]);



    // No auto-generation - we only use the existing HTML template from database

    // Generate HTML from dynamic elements with IDs
    const generateHTML = useCallback(() => {
        console.log('generateHTML called');
        console.log('dynamicElements:', dynamicElements);
        console.log('elementsLoadedFromDatabase:', elementsLoadedFromDatabase);
        console.log('initialLoadingComplete:', initialLoadingComplete);
        console.log('documentStatus:', documentStatus);
        console.log('documentData.STATUS:', documentData?.STATUS);

        // CRITICAL: If document is approved, use saved HTML_TEMPLATE instead of regenerating
        // This prevents breaking approved documents when elementTypes.js is updated
        if (documentStatus === 'Approved' || documentData?.STATUS === 'Approved') {
            if (documentData?.HTML_TEMPLATE) {
                const savedTemplate = convertClobToString(documentData.HTML_TEMPLATE);
                console.log('🔒 Document is APPROVED - Using saved HTML_TEMPLATE instead of regenerating');
                console.log('📄 Saved template length:', savedTemplate.length);
                return savedTemplate;
            } else {
                console.warn('⚠️ Document is approved but no HTML_TEMPLATE found - falling back to generation');
            }
        }

        // Don't generate HTML if initial loading is not complete
        if (!initialLoadingComplete) {
            console.log('⏭️ Skipping HTML generation - initial loading not complete');
            return '';
        }

        // Always generate HTML from current dynamic elements
        // This ensures that any changes to elements are reflected in the HTML
        let dynamicContent = '';
        if (dynamicElements.length > 0) {
            console.log('Generating HTML for elements:', dynamicElements);
            dynamicContent = dynamicElements.map(element => generateElementHTML(element)).join('\n');
            console.log('Generated dynamic content:', dynamicContent);
        }

        // Get document title
        const title = documentData?.MIS_DOCUMENT_NAME || 'MIS Report';

        // Always use the stored banner URL from document data for consistency
        let bannerUrl;
        if (documentData?.BANNER_URL) {
            const basePath = process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/';
            bannerUrl = `${basePath}mis-banners/${documentData.BANNER_URL}`;
        } else {
            bannerUrl = 'https://template.canva.com/EAGFHwDBy9o/1/0/1600w-r04Wz2uiHxE.jpg';
        }

        // Generate template structure matching ClientsAndTemplates.js format
        return `<!doctype html>
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
<head>
<meta charset="utf-8">
<title>${title}</title>
<!--[if mso]>
<style>
  v\:* { behavior: url(#default#VML); }
  o\:* { behavior: url(#default#VML); }
  w\:* { behavior: url(#default#VML); }
  .shape { behavior: url(#default#VML); }
</style>
<![endif]-->
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" style="font-family: calibri; background-color:#ffffff; ">
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#f2f2f2">
<tbody>
<tr>
<td>
<!-- Main TD -->

<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody>

<!-- Main MIS Content Here -->
${dynamicContent}
<!-- Main MIS Content Here -->

</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</body>
</html>`;
    }, [dynamicElements, elementsLoadedFromDatabase, initialLoadingComplete, documentData, documentStatus]);

    // Generate HTML for individual elements with ID
    const generateElementHTML = (element) => {
        console.log('generateElementHTML called for element:', element);
        console.log('Element type:', element.type);
        console.log('Element value:', element.value);
        console.log('Element ID:', element.id);

        // Create dynamic comment for element identification with ID
        const elementComment = `<!-- ${element.type}-element-${element.id} -->`;

        // Get the element type configuration from elementTypes.js
        const elementConfig = elementTypes[element.type];
        console.log('Element config found:', !!elementConfig);

        let htmlContent = '';
        if (elementConfig && elementConfig.htmlTemplate) {
            try {
                htmlContent = elementConfig.htmlTemplate(element);
            } catch (error) {
                console.error('Error generating HTML for element:', element);
                console.error('Error details:', error);
                // Fallback HTML for executive-summary elements
                if (element.type === 'executive-summary') {
                    htmlContent = `
                    <tr>
                        <td style="color: #163E64; font-size: 16px; line-height: 20px; text-align: justify;">
                            Executive Summary (Error loading content)
                        </td>
                    </tr>`;
                } else {
                    htmlContent = `
                    <tr>
                        <td style="color: #163E64; font-size: 16px; line-height: 20px; text-align: justify;">
                            ${element.value || 'Content'}
                        </td>
                    </tr>`;
                }
            }
        } else {
            htmlContent = `
            <tr>
                <td style="color: #163E64; font-size: 16px; line-height: 20px; text-align: justify;">
                    ${element.value || 'Content'}
                </td>
            </tr>`;
        }

        return `
${elementComment}
<!--dynamic_point_start-->
${htmlContent}
<!--dynamic_point_end-->
`;
    };





    // History management
    const addToHistory = useCallback((newElements) => {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push([...newElements]);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
    }, [history, historyIndex]);

    const undo = () => {
        if (historyIndex > 0) {
            setHistoryIndex(historyIndex - 1);
            setDynamicElements(history[historyIndex - 1]);
        }
    };

    const redo = () => {
        if (historyIndex < history.length - 1) {
            setHistoryIndex(historyIndex + 1);
            setDynamicElements(history[historyIndex + 1]);
        }
    };

    // Element management with template elements (one-time use) and dynamic elements (multiple use)
    const handleAddElement = (type, value = '', insertIndex = null) => {
        // Prevent adding elements if document is approved
        if (documentStatus === 'Approved' || documentData?.STATUS === 'Approved') {
            showSnackbar('Cannot modify approved documents. This document is read-only.', 'warning');
            return;
        }

        console.log('handleAddElement called with:', type, value, 'insertIndex:', insertIndex);

        // Define template elements that can only be used once
        const templateElements = ['date-header', 'banner-section', 'whats-new-dpa', 'disclaimer'];

        // Check if this is a template element that already exists
        if (templateElements.includes(type)) {
            const existingElement = dynamicElements.find(el => el.type === type);
            if (existingElement) {
                console.log(`Template element of type ${type} already exists, updating instead of adding`);
                // Update the existing template element
                const updatedElement = {
                    ...existingElement,
                    value: value || existingElement.value,
                    timestamp: new Date().toISOString()
                };
                handleUpdateElement(updatedElement);
                setSelectedElementId(existingElement.id);
                return;
            }
        }

        try {
            // Validate element type
            if (!type || typeof type !== 'string') {
                throw new Error('Invalid element type provided');
            }

            // Check if element type exists in elementTypes
            if (!elementTypes[type]) {
                throw new Error(`Element type '${type}' is not supported`);
            }

            // Create new element using the utility function
            const newElement = createElement(type, {
                value: value || '',
                primaryColor
            });

            // Validate the created element
            if (!newElement || !newElement.id) {
                throw new Error('Failed to create element - invalid element data');
            }

            // Handle specific element types with default values
            if (type === 'date-header') {
                // Extract date from document name or use current date
                let dateText = 'OCTOBER 2024'; // Default
                if (documentData?.MIS_DOCUMENT_NAME) {
                    const nameParts = documentData.MIS_DOCUMENT_NAME.split('-');
                    if (nameParts.length >= 2) {
                        const month = nameParts[nameParts.length - 2];
                        const year = nameParts[nameParts.length - 1];
                        if (month && year) {
                            dateText = `${month.toUpperCase()} ${year}`;
                        }
                    }
                }

                newElement.value = dateText;
                newElement.logoUrl = 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/creative_dpa/o/Media%2Fuploaded_imgs%2Fmonthly-mis%2Foct2024%2Fd-logo.png';
            } else if (type === 'banner-section') {
                // Use banner URL from document data if available
                if (documentData?.BANNER_URL) {
                    newElement.value = `${process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH}mis-banners/${documentData.BANNER_URL}`;
                    newElement.bannerFilename = documentData.BANNER_URL;
                } else {
                    newElement.value = 'https://template.canva.com/EAGFHwDBy9o/1/0/1600w-r04Wz2uiHxE.jpg';
                }
            } else if (type === 'whats-new-dpa') {
                // For Whats New in DPA, only set value if a valid image URL is provided
                newElement.value = value || null;
                newElement.caption = '';
                newElement.titleColor = primaryColor;
                newElement.borderColor = primaryColor;
            } else if (type === 'disclaimer') {
                // For disclaimer, use default text
                newElement.value = value || ' Decimal Point Analytics Pvt Ltd does not make any recommendation, solicitation, or offer for any securities and is not responsible for suitability of any securities for any purpose, investment or otherwise. It is the sole responsibility of the client, as a professional organization, to exercise professional due diligence in ensuring suitability of investment and ensuring that when the client publishes a part or full report under its own brand, the legal requirements for distribution of such material are complied with in all the jurisdiction in which it is published. Decimal Point Analytics Pvt. Ltd. shall not be responsible for any loss suffered by the user. The returns indicated, including future projections, in any investment report prepared by Decimal Point Analytics Pvt Ltd are not guaranteed in any manner and June not to be achieved. ';
            } else if (type === 'executive-summary') {
                newElement.value = value || JSON.stringify({
                    "headings": {
                        "operational-strengths": "OPERATIONAL STRENGTHS",
                        "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
                        "risk-mitigation": "RISK MITIGATION",
                        "operational-highlights": "OPERATIONAL HIGHLIGHTS"
                    },
                    "operational-strengths": [
                        {
                            "heading": "Sample Operational Strength",
                            "desc": ["Sample description 1", "Sample description 2"]
                        }
                    ],
                    "strategic-achievements": [
                        {
                            "heading": "Sample Strategic Achievement",
                            "desc": ["Sample description 3", "Sample description 4"]
                        }
                    ],
                    "risk-mitigation": [
                        {
                            "heading": "Sample Risk Mitigation",
                            "desc": ["Sample description 5", "Sample description 6"]
                        }
                    ],
                    "operational-highlights": [
                        {
                            "heading": "Sample Operational Highlight",
                            "desc": ["Sample description 7", "Sample description 8"]
                        }
                    ]
                }, null, 2);
                newElement.fontSize = 16;
                newElement.titleSize = 20;
                newElement.textAlign = 'justify';
                newElement.textColor = '#333333';
                newElement.titleColor = primaryColor;
            } else {
                // For ALL other element types, set appropriate default values
                const elementConfig = elementTypes[type];
                if (elementConfig) {
                    // Set default values based on element type
                    if (type === 'main-heading') {
                        newElement.value = value || 'Main Heading';
                        newElement.fontSize = 24;
                        newElement.textAlign = 'center';
                        newElement.primaryColor = primaryColor;
                    } else if (type === 'section-heading') {
                        newElement.value = value || 'Section Heading';
                        newElement.fontSize = 20;
                        newElement.textAlign = 'left';
                        newElement.primaryColor = primaryColor;
                    } else if (type === 'sub-heading') {
                        newElement.value = value || 'Sub Heading';
                        newElement.fontSize = 18;
                        newElement.textAlign = 'left';
                        newElement.textColor = '#333333';
                    } else if (type === 'description') {
                        newElement.value = value || 'Description text goes here...';
                        newElement.fontSize = 16;
                        newElement.textAlign = 'justify';
                        newElement.textColor = '#333333';
                        newElement.lineHeight = 1.6;
                    } else if (type === 'bullet-points') {
                        newElement.value = value || 'Bullet point 1\nBullet point 2\nBullet point 3';
                        newElement.fontSize = 16;
                        newElement.textColor = '#333333';
                        newElement.bulletColor = primaryColor;
                    } else if (type === 'simple-text') {
                        newElement.value = value || 'Text content goes here...';
                        newElement.fontSize = 16;
                        newElement.textAlign = 'left';
                        newElement.textColor = '#333333';
                    } else if (type === 'spacing') {
                        newElement.value = value || 20;
                    } else if (type === 'divider') {
                        newElement.thickness = 1;
                        newElement.color = primaryColor;
                        newElement.margin = 10;
                    } else if (type === 'image') {
                        newElement.value = value || null;
                        newElement.altText = 'Image';
                        newElement.align = 'center';
                        newElement.borderRadius = 4;
                    } else if (type === 'executive-summary') {
                        newElement.value = value || JSON.stringify({
                            "operational-strengths": [
                                {
                                    "heading": "Sample Operational Strength",
                                    "desc": ["Sample description 1", "Sample description 2"]
                                }
                            ],
                            "strategic-achievements": [
                                {
                                    "heading": "Sample Strategic Achievement",
                                    "desc": ["Sample description 3", "Sample description 4"]
                                }
                            ],
                            "risk-mitigation": [
                                {
                                    "heading": "Sample Risk Mitigation",
                                    "desc": ["Sample description 5", "Sample description 6"]
                                }
                            ],
                            "operational-highlights": [
                                {
                                    "heading": "Sample Operational Highlight",
                                    "desc": ["Sample description 7", "Sample description 8"]
                                }
                            ]
                        }, null, 2);
                        newElement.fontSize = 16;
                        newElement.titleSize = 20;
                        newElement.textAlign = 'justify';
                        newElement.textColor = '#333333';
                        newElement.titleColor = primaryColor;
                    } else if (type === 'highlight-box') {
                        newElement.value = value || 'Highlighted content goes here...';
                        newElement.fontSize = 16;
                        newElement.textColor = '#856404';
                        newElement.backgroundColor = '#fff3cd';
                        newElement.borderColor = primaryColor;
                    } else if (type === 'news-section') {
                        // Set default news section data
                        newElement.value = value || JSON.stringify([
                            {
                                title: "Sample News Title",
                                date: "Jul-25",
                                link: "https://example.com/news1",
                                heading: "Sample News Heading",
                                description: "Sample news description"
                            }
                        ], null, 2);
                        newElement.sectionTitle = 'Latest News';
                        newElement.fontSize = 16;
                        newElement.titleSize = 20;
                        newElement.textAlign = 'left';
                        newElement.textColor = '#333333';
                        newElement.titleColor = primaryColor;
                        newElement.backgroundColor = primaryColor;
                        newElement.borderColor = '#e0e0e0';
                    } else if (type === 'list-items') {
                        // Set default list items data
                        newElement.value = value || JSON.stringify([
                            {
                                hasHeading: false,
                                heading: "",
                                content: ["Sample content 1", "Sample content 2"]
                            }
                        ], null, 2);
                        newElement.fontSize = 16;
                        newElement.titleSize = 18;
                        newElement.textAlign = 'left';
                        newElement.textColor = '#333333';
                        newElement.titleColor = '#000000';
                        newElement.borderColor = '#e0e0e0';
                    } else {
                        // For any other element type, use the default from elementTypes
                        if (!newElement.value && elementConfig?.properties?.value?.default) {
                            newElement.value = elementConfig.properties.value.default;
                        }
                    }
                }
            }

            console.log('Created new element:', newElement);
            console.log('Element type:', type, 'Is template element:', templateElements.includes(type));

            // Insert element at specified index or at the end
            const newElements = [...dynamicElements];
            if (insertIndex !== null && insertIndex >= 0 && insertIndex <= newElements.length) {
                newElements.splice(insertIndex, 0, newElement);
                console.log('Inserted element at index:', insertIndex);
            } else {
                newElements.push(newElement);
                console.log('Added element at the end');
            }
            setDynamicElements(newElements);
            addToHistory(newElements);
            setSelectedElementId(newElement.id);

            // Update HTML content with the new element
            const newHTML = generateHTML();
            setHtmlContent(newHTML);

            console.log('Updated dynamicElements:', newElements);
            console.log('Updated HTML content with new element');
            console.log('Element ID for correlation:', newElement.id);
            console.log('Total elements after adding:', newElements.length);
            console.log('Element types in array:', newElements.map(el => el.type));
        } catch (error) {
            console.error('Error creating element:', error);
            showSnackbar(`Failed to create element: ${error.message}`, 'error');
        }
    };

    const handleUpdateElement = (updatedElement) => {
        // Prevent updating elements if document is approved
        if (documentStatus === 'Approved' || documentData?.STATUS === 'Approved') {
            showSnackbar('Cannot modify approved documents. This document is read-only.', 'warning');
            return;
        }

        console.log('🔄 Updating element:', updatedElement);
        console.log('Current elements count:', dynamicElements.length);

        const newElements = dynamicElements.map(el =>
            el.id === updatedElement.id ? updatedElement : el
        );

        console.log('Updated elements count:', newElements.length);
        console.log('Updated element details:', newElements.find(el => el.id === updatedElement.id));

        setDynamicElements(newElements);
        addToHistory(newElements);

        // Update HTML content with the updated element
        const newHTML = generateHTML();
        setHtmlContent(newHTML);

        console.log('✅ Element updated successfully');
        console.log('✅ HTML content updated with modified element');
    };

    const handleDeleteElement = (elementId) => {
        // Prevent deleting elements if document is approved
        if (documentStatus === 'Approved' || documentData?.STATUS === 'Approved') {
            showSnackbar('Cannot modify approved documents. This document is read-only.', 'warning');
            return;
        }

        console.log('🗑️ Deleting element:', elementId);
        console.log('Current elements count:', dynamicElements.length);

        const newElements = dynamicElements.filter(el => el.id !== elementId);

        console.log('Remaining elements count:', newElements.length);

        setDynamicElements(newElements);
        addToHistory(newElements);
        setSelectedElementId(null);

        // Update HTML content after deletion
        const newHTML = generateHTML();
        setHtmlContent(newHTML);

        console.log('✅ Element deleted successfully');
        console.log('✅ HTML content updated after deletion');
    };

    const handleCopyElement = (elementToCopy, insertAfterIndex) => {
        // Prevent copying elements if document is approved
        if (documentStatus === 'Approved' || documentData?.STATUS === 'Approved') {
            showSnackbar('Cannot modify approved documents. This document is read-only.', 'warning');
            return;
        }

        console.log('📋 Copying element:', elementToCopy.id);
        console.log('Insert after index:', insertAfterIndex);
        console.log('Current elements count:', dynamicElements.length);

        // Create a new element with a unique ID
        const copiedElement = {
            ...elementToCopy,
            id: `element-${Date.now()}-${Math.random().toString(36).substr(2, 9)}` // Generate unique ID
        };

        console.log('📋 Generated new ID for copied element:', copiedElement.id);

        // Create a new array with the copied element inserted after the specified index
        const newElements = [...dynamicElements];
        newElements.splice(insertAfterIndex + 1, 0, copiedElement);

        console.log('New elements count:', newElements.length);

        setDynamicElements(newElements);
        addToHistory(newElements);
        setSelectedElementId(copiedElement.id); // Select the newly copied element

        // Update HTML content after copying
        const newHTML = generateHTML();
        setHtmlContent(newHTML);

        console.log('✅ Element copied successfully with new ID');
        console.log('✅ HTML content updated after copying');
    };

    const handleSelectElement = (elementId) => {
        setSelectedElementId(elementId);
    };

    // We don't generate HTML - we only use the existing template from database

    // Drag and drop handlers
    const handleDragStart = (event) => {
        const { active } = event;
        console.log('Drag start:', active);
        setActiveId(active.id);
        setIsDragging(true);
    };

    const handleDragEnd = (event) => {
        try {
            const { active, over } = event;
            console.log('Drag end:', { active, over });
            console.log('Active data:', active.data?.current);
            setActiveId(null);
            setIsDragging(false);

            if (over && active.id !== over.id) {
                if (active.data?.current?.isToolboxItem) {
                    // Adding new element from toolbox
                    const elementType = active.data.current.type;
                    console.log('Adding element from toolbox:', elementType);
                    console.log('Element type from drag data:', elementType);
                    console.log('Element type type:', typeof elementType);
                    console.log('Over data:', over.data?.current);

                    // Validate element type before adding
                    if (!elementType || typeof elementType !== 'string') {
                        console.error('Invalid element type:', elementType);
                        showSnackbar('Invalid element type. Please try again.', 'error');
                        return;
                    }

                    // Check if dropped on a drop zone
                    let insertIndex = null;
                    if (over.data?.current?.isDropZone) {
                        insertIndex = over.data.current.insertIndex;
                        console.log('Dropped on drop zone, insert index:', insertIndex);
                    } else {
                        console.log('Dropped on canvas, will add at end');
                    }

                    handleAddElement(elementType, '', insertIndex);
                } else {
                    // Reordering existing elements - prevent if approved
                    if (documentStatus === 'Approved' || documentData?.STATUS === 'Approved') {
                        showSnackbar('Cannot reorder elements in approved documents. This document is read-only.', 'warning');
                        return;
                    }

                    // Reordering existing elements
                    setDynamicElements((items) => {
                        try {
                            const oldIndex = items.findIndex((item) => item.id === active.id);
                            const newIndex = items.findIndex((item) => item.id === over.id);

                            if (oldIndex === -1 || newIndex === -1) {
                                console.warn('Element not found for reordering:', {
                                    activeId: active.id,
                                    overId: over.id,
                                    availableIds: items.map(item => item.id)
                                });
                                return items;
                            }

                            const newElements = arrayMove(items, oldIndex, newIndex);
                            addToHistory(newElements);

                            // Update HTML content after reordering
                            const newHTML = generateHTML();
                            setHtmlContent(newHTML);

                            console.log('Reordered elements, updated HTML content');
                            return newElements;
                        } catch (error) {
                            console.error('Error during element reordering:', error);
                            showSnackbar('Error reordering elements. Please try again.', 'error');
                            return items;
                        }
                    });
                }
            }
        } catch (error) {
            console.error('Error in handleDragEnd:', error);
            setActiveId(null);
            setIsDragging(false);
            showSnackbar('An error occurred during drag and drop. Please try again.', 'error');
        }
    };

    const handleDragCancel = () => {
        setActiveId(null);
        setIsDragging(false);
    };



    // Chart dialog handlers
    const handleClickOpenChart = () => {
        setOpenChart(true);
    };


    // Table dialog handlers
    const handleClickOpenTable = () => {
        setOpenTable(true);
    };

    const handleCloseTable = () => {
        setOpenTable(false);
    };

    // Image dialog handlers
    const handleClickOpenImage = () => {
        setOpenImage(true);
    };

    const handleCloseImage = () => {
        setOpenImage(false);
    };

    // Infographic click handler
    const handleInfographicClick = (infographic) => {
        console.log('📊 Infographic clicked:', infographic);
        setSelectedInfographic(infographic);

        if (infographic.chartType) {
            // Open chart dialog with the infographic data
            setOpenChart(true);
        } else if (infographic.tableName) {
            // Open table dialog with the infographic data
            setOpenTable(true);
        } else if (infographic.imageType) {
            // Open image dialog with the infographic data
            setOpenImage(true);
        }
    };


    useEffect(() => {
        const fetchDocumentData = async () => {
            try {
                setLoadingData(true);
                setError(null);
                setHasParsedElements(false); // Reset parsing flag for new document
                setElementsLoadedFromDatabase(false); // Reset database loading flag for new document
                setInitialLoadingComplete(false); // Reset initial loading flag for new document
                setDynamicElements([]); // Clear existing elements for new document
                setHtmlContent(''); // Clear existing HTML content for new document

                console.log('🔄 Fetching document data for ID:', unwrappedParams.id);

                // Get authentication token from localStorage
                const session = localStorage.getItem('session');
                let accessToken = '';

                if (session) {
                    try {
                        const sessionData = JSON.parse(session);
                        accessToken = sessionData.accessToken || '';
                    } catch (parseError) {
                        console.error('Error parsing session data:', parseError);
                    }
                }

                const headers = {
                    'Content-Type': 'application/json'
                };

                // Add Authorization header if we have a token
                if (accessToken) {
                    headers['Authorization'] = `Bearer ${accessToken}`;
                }

                const response = await fetch(`/api/client-mis-documents/${unwrappedParams.id}`, {
                    headers: headers
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();
                console.log('📡 API Response received:', data);
                console.log('📄 Document data from API:', data.document);
                console.log('🔍 DYNAMIC_ELEMENTS from API:', data.document?.DYNAMIC_ELEMENTS);
                console.log('🔍 DYNAMIC_ELEMENTS type:', typeof data.document?.DYNAMIC_ELEMENTS);
                console.log('🔍 DYNAMIC_ELEMENTS length:', Array.isArray(data.document?.DYNAMIC_ELEMENTS) ? data.document?.DYNAMIC_ELEMENTS.length : 'Not an array');

                if (data.success && data.document) {
                    setDocumentData(data.document);
                    console.log('✅ Document data set successfully');

                    // Set document status from database
                    if (data.document.STATUS) {
                        console.log('📋 Setting document status from database:', data.document.STATUS);
                        // Use the exact status from database since it should match our constraint
                        setDocumentStatus(data.document.STATUS);

                        // Auto-enable HTML preview mode if document is approved
                        if (data.document.STATUS === 'Approved') {
                            console.log('📋 Document is approved - auto-enabling HTML preview mode');
                            setShowHtmlPreview(true);
                        }
                    } else {
                        console.log('⚠️ No STATUS found, using default status: Draft');
                        setDocumentStatus('Draft');
                    }

                    // Set primary color from THEME_COLORS if available (with CLOB support)
                    const themeColors = parseThemeColors(data.document.THEME_COLORS);
                    if (Array.isArray(themeColors) && themeColors.length > 0) {
                        console.log('🎨 Setting primary color from THEME_COLORS:', themeColors[0]);
                        setPrimaryColor(themeColors[0]);
                    } else {
                        console.log('⚠️ No valid THEME_COLORS found, using default primary color');
                    }

                    // Fetch infographics for this document
                    if (data.document.MIS_DOCUMENT_NAME) {
                        console.log('📊 Fetching infographics for document:', data.document.MIS_DOCUMENT_NAME);
                        fetchInfographics(data.document.MIS_DOCUMENT_NAME);
                    }
                } else {
                    throw new Error('Failed to fetch document data');
                }
            } catch (error) {
                console.error('❌ Error fetching document data:', error);
                setError(error.message);
            } finally {
                setLoadingData(false);
            }
        };

        if (employeeDetails && unwrappedParams.id) {
            fetchDocumentData();
        }
    }, [employeeDetails, unwrappedParams.id]);



    // Refresh infographics when chart/table dialogs close (in case new infographics were uploaded)
    useEffect(() => {
        if (!openChart && !openTable && documentData?.MIS_DOCUMENT_NAME) {
            // Small delay to ensure any upload operations have completed
            const timer = setTimeout(() => {
                if (documentData?.MIS_DOCUMENT_NAME) {
                    console.log('🔄 Refreshing infographics for document:', documentData.MIS_DOCUMENT_NAME);
                    console.log('🔄 Current infographics count before refresh:', infographics.length);
                    fetchInfographics(documentData.MIS_DOCUMENT_NAME);
                }
            }, 1000);

            return () => clearTimeout(timer);
        }
    }, [openChart, openTable, documentData?.MIS_DOCUMENT_NAME, fetchInfographics, infographics.length]);

    // Handle drawer toggle
    const toggleDrawer = (newOpen) => () => {
        setDrawerOpen(newOpen);
    };

    // Handle infographic hover
    const handleInfographicHover = (infographic) => {
        setHoveredInfographic(infographic);
    };

    const handleInfographicLeave = () => {
        setHoveredInfographic(null);
    };

    // Handle view/edit infographic
    const handleViewEditInfographic = (infographic) => {
        console.log('📊 View/Edit infographic:', infographic);
        setSelectedInfographic(infographic);

        if (infographic.chartType) {
            // Open chart dialog with the infographic data
            setOpenChart(true);
        } else if (infographic.tableName) {
            // Open table dialog with the infographic data
            setOpenTable(true);
        } else if (infographic.imageType) {
            // Open image dialog with the infographic data
            setOpenImage(true);
        }
    };

    // Handle add infographic to document
    const handleAddInfographicToDocument = async (infographic) => {
        console.log('📊 Adding infographic to document:', infographic);

        try {
            // Add the image element to the document with proper properties
            const altText = infographic.chartType ? `${infographic.chartType} Chart` : infographic.imageType ? `Uploaded Image: ${infographic.filename}` : infographic.tableName || 'Infographic';

            // Create a custom element with the infographic URL and properties
            const newElement = {
                id: `image-${Date.now()}`,
                type: 'image',
                value: infographic.url,
                altText: altText,
                align: 'center',
                borderRadius: 4,
                primaryColor,
                timestamp: new Date().toISOString()
            };

            // Add to dynamic elements
            const newElements = [...dynamicElements, newElement];
            setDynamicElements(newElements);
            addToHistory(newElements);
            setSelectedElementId(newElement.id);

            // Update HTML content
            const newHTML = generateHTML();
            setHtmlContent(newHTML);

            // Mark infographic as used
            await handleUpdateInfographicUsage(infographic, true);

            // Note: The infographic is already saved in the database when it was originally uploaded
            // We just need to refresh the infographics list to show it
            console.log('✅ Infographic added to document as image element');

            // Refresh the infographics list to show the newly added infographic
            if (documentData?.MIS_DOCUMENT_NAME) {
                setTimeout(() => {
                    fetchInfographics(documentData.MIS_DOCUMENT_NAME);
                }, 1000); // Small delay to ensure any database updates are complete
            }

            // Close the drawer
            setDrawerOpen(false);

            console.log('✅ Infographic added to document as image element');

            // Show success message
            showSnackbar(`✅ Infographic added to document successfully! Type: ${infographic.chartType ? 'Chart' : infographic.imageType ? 'Image' : 'Table'}, Name: ${infographic.chartType || infographic.imageType ? infographic.filename : infographic.tableName}`, 'success');
        } catch (error) {
            console.error('❌ Error adding infographic to document:', error);
            showSnackbar('❌ Failed to add infographic to document. Please try again.', 'error');
        }
    };

    // Handle copy infographic link to clipboard
    const handleCopyInfographicLink = async (infographic) => {
        console.log('📋 Copying infographic link to clipboard:', infographic.url);

        try {
            // Copy the URL to clipboard
            await navigator.clipboard.writeText(infographic.url);

            // Show success message
            const infographicType = infographic.chartType ? 'Chart' : infographic.imageType ? 'Image' : 'Table';
            const infographicName = infographic.chartType || infographic.imageType ? infographic.filename : infographic.tableName;
            showSnackbar(`✅ ${infographicType} link copied to clipboard: ${infographicName}`, 'success');

            // Close the drawer
            setDrawerOpen(false);

            console.log('✅ Infographic link copied to clipboard successfully');
        } catch (error) {
            console.error('❌ Error copying infographic link to clipboard:', error);
            showSnackbar('❌ Failed to copy link to clipboard. Please try again.', 'error');
        }
    };

    // Handle delete infographic
    const handleDeleteInfographic = async (infographic) => {
        console.log('🗑️ Deleting infographic:', infographic);

        try {
            // Get authentication token
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Call delete API
            const response = await fetch(`/api/infographics?documentName=${encodeURIComponent(documentData.MIS_DOCUMENT_NAME)}&filename=${encodeURIComponent(infographic.filename)}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Delete failed: ${response.status}`);
            }

            const result = await response.json();
            console.log('✅ Infographic deleted successfully:', result);

            // Refresh infographics list
            if (documentData?.MIS_DOCUMENT_NAME) {
                fetchInfographics(documentData.MIS_DOCUMENT_NAME);
            }

            // Show success message
            showSnackbar('Infographic deleted successfully', 'success');

        } catch (error) {
            console.error('❌ Error deleting infographic:', error);
            showSnackbar(`Failed to delete infographic: ${error.message}`, 'error');
        }
    };

    // Handle update infographic usage status
    const handleUpdateInfographicUsage = async (infographic, isUsed) => {
        console.log('🏷️ Updating infographic usage status:', infographic.filename, 'isUsed:', isUsed);

        try {
            // Get authentication token
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Call update API
            const response = await fetch('/api/infographics', {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`
                },
                body: JSON.stringify({
                    documentName: documentData.MIS_DOCUMENT_NAME,
                    filename: infographic.filename,
                    isUsed: isUsed
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Update failed: ${response.status}`);
            }

            const result = await response.json();
            console.log('✅ Infographic usage status updated:', result);

            // Refresh infographics list
            if (documentData?.MIS_DOCUMENT_NAME) {
                fetchInfographics(documentData.MIS_DOCUMENT_NAME);
            }

        } catch (error) {
            console.error('❌ Error updating infographic usage status:', error);
            showSnackbar(`Failed to update usage status: ${error.message}`, 'error');
        }
    };

    // Handle infographic selection
    const handleInfographicSelection = (infographic, isSelected) => {
        console.log('📋 Selection change:', infographic.filename, 'isSelected:', isSelected);

        if (infographic.isUsed) {
            console.log('📋 Cannot select used infographic:', infographic.filename);
            // Don't allow selection of used infographics
            return;
        }

        setSelectedInfographics(prev => {
            const newSelection = new Set(prev);
            if (isSelected) {
                newSelection.add(infographic.filename);
                console.log('📋 Added to selection:', infographic.filename);
            } else {
                newSelection.delete(infographic.filename);
                console.log('📋 Removed from selection:', infographic.filename);
            }
            console.log('📋 New selection:', Array.from(newSelection));
            return newSelection;
        });
    };

    // Handle select all infographics (only unused ones)
    const handleSelectAllInfographics = () => {
        const unusedInfographics = infographics.filter(inf => !inf.isUsed);
        setSelectedInfographics(new Set(unusedInfographics.map(inf => inf.filename)));
    };

    // Handle deselect all infographics
    const handleDeselectAllInfographics = () => {
        setSelectedInfographics(new Set());
    };

    // Handle bulk delete selected infographics
    const handleBulkDeleteInfographics = async () => {
        console.log('🗑️ Bulk delete initiated. Selected infographics:', Array.from(selectedInfographics));
        console.log('🗑️ Selected count:', selectedInfographics.size);

        if (selectedInfographics.size === 0) {
            showSnackbar('No infographics selected for deletion', 'warning');
            return;
        }

        const confirmMessage = `Are you sure you want to delete ${selectedInfographics.size} selected infographic(s)? This action cannot be undone.`;
        if (!window.confirm(confirmMessage)) {
            return;
        }

        try {
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Delete each selected infographic
            console.log('🗑️ Starting deletion of', selectedInfographics.size, 'infographics');
            const deletePromises = Array.from(selectedInfographics).map(filename => {
                console.log('🗑️ Deleting infographic:', filename);
                return fetch(`/api/infographics?documentName=${encodeURIComponent(documentData.MIS_DOCUMENT_NAME)}&filename=${encodeURIComponent(filename)}`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${accessToken}`
                    }
                });
            });

            console.log('🗑️ Executing', deletePromises.length, 'delete requests');
            const responses = await Promise.all(deletePromises);
            console.log('🗑️ Delete responses:', responses.map(r => ({ status: r.status, ok: r.ok })));

            const failedDeletions = responses.filter(response => !response.ok);
            console.log('🗑️ Failed deletions:', failedDeletions.length);

            if (failedDeletions.length > 0) {
                throw new Error(`Failed to delete ${failedDeletions.length} infographic(s)`);
            }

            // Store the count before clearing selection
            const deletedCount = selectedInfographics.size;
            console.log('🗑️ About to delete', deletedCount, 'infographics from state');

            // Update local state
            setInfographics(prev => {
                const filtered = prev.filter(inf => !selectedInfographics.has(inf.filename));
                console.log('🗑️ State update: removed', prev.length - filtered.length, 'infographics');
                console.log('🗑️ Remaining infographics:', filtered.length);
                return filtered;
            });
            setSelectedInfographics(new Set());

            console.log('🗑️ Bulk delete completed successfully');
            showSnackbar(`✅ Successfully deleted ${deletedCount} infographic(s)`, 'success');

            // Refresh infographics list
            if (documentData?.MIS_DOCUMENT_NAME) {
                setTimeout(() => {
                    fetchInfographics(documentData.MIS_DOCUMENT_NAME);
                }, 1000);
            }
        } catch (error) {
            console.error('❌ Error bulk deleting infographics:', error);
            showSnackbar(`Failed to delete infographics: ${error.message}`, 'error');
        }
    };

    if (isInitializing || loadingData) {
        return (
            <BasicLayout>
                <Container maxWidth="xl" sx={{ pt: '64px' }}>
                    <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh" flexDirection="column">
                        <CircularProgress size={40} />
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                            {loadingData ? 'Loading document...' : 'Initializing...'}
                        </Typography>
                    </Box>
                </Container>
            </BasicLayout>
        );
    }

    if (error) {
        return (
            <BasicLayout>
                <Container maxWidth="xl" sx={{ pt: '64px' }}>
                    <Box>
                        <Alert severity="error" sx={{ mb: 2 }}>
                            {error}
                        </Alert>
                    </Box>
                </Container>
            </BasicLayout>
        );
    }

    if (!employeeDetails) {
        return (
            <BasicLayout>
                <Container maxWidth="xl" sx={{ pt: '64px' }}>
                    <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                        <Typography>Please sign in to view MIS documents.</Typography>
                    </Box>
                </Container>
            </BasicLayout>
        );
    }

    const selectedElement = dynamicElements.find(el => el.id === selectedElementId);

    // Check if we're in template mode (has HTML template from database)
    const isTemplateMode = !!documentData?.HTML_TEMPLATE;

    return (
        <>
            <Global
                styles={{
                    '.MuiDrawer-root > .MuiPaper-root': {
                        height: `calc(100% - ${drawerBleeding}px)`,
                        overflow: 'visible',
                    },
                }}
            />


            <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
                onDragCancel={handleDragCancel}
            >
                <Box sx={{ display: "flex", height: 'calc(100vh - 200px)', paddingTop: '0px' }}>
                    {/* Left Sidebar - Element Toolbox */}
                    <Drawer
                        variant="permanent"
                        anchor="left"
                        sx={{
                            width: drawerWidth,
                            flexShrink: 0,
                            zIndex: 1199,
                            [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: "border-box", marginTop: '65px', paddingBottom: '70px' },
                        }}
                    >
                        <Box px={2} py={1}>
                            <Stack direction="row" spacing={1}>
                                <Chip
                                    label={`${dynamicElements.length} elements`}
                                    size="small"
                                    color="info"
                                    className="simple-chip"
                                    sx={{ width: '100%' }}
                                />
                                {documentData?.HTML_TEMPLATE && (
                                    <Chip
                                        label="Template Mode"
                                        size="small"
                                        color="success"
                                        variant="outlined"
                                        className="simple-chip"
                                        sx={{ width: '100%' }}
                                    />
                                )}

                                {showHtmlPreview && (
                                    <Chip
                                        label="Preview"
                                        size="small"
                                        color="success"
                                        variant="outlined"
                                        sx={{ width: '100%' }}
                                    />
                                )}
                            </Stack>
                        </Box>

                        <Divider />

                        <Box py={1} px={2}>
                            <Box className="fx_sb" mb={'12px'}>
                                <Typography variant="h6" sx={{ mb: 0, fontWeight: 600 }}>
                                    Infographics
                                </Typography>

                                <Button variant="contained" className="main-btn xs btn-secondary" startIcon={<VisibilityOutlinedIcon sx={{ fontSize: '12px' }} />} onClick={toggleDrawer(true)} disabled={infographics.length === 0}>
                                    Show Available
                                </Button>

                            </Box>

                            <Stack direction="row" spacing={1}>
                                {/* <Box className="infographic-ele-card" onClick={(showHtmlPreview || documentStatus === 'Approved') ? undefined : handleClickOpenChart} sx={{ opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, cursor: (showHtmlPreview || documentStatus === 'Approved') ? 'not-allowed' : 'pointer', pointerEvents: 'none' }}></Box> */}
                                <Box className="infographic-ele-card" onClick={(showHtmlPreview || documentStatus === 'Approved') ? undefined : handleClickOpenChart} sx={{ opacity: 0.5, userSelect: 'none', cursor: (showHtmlPreview || documentStatus === 'Approved') ? 'not-allowed' : 'pointer', pointerEvents: 'none' }}>
                                    <Box className="icon" sx={{ bgcolor: (showHtmlPreview || documentStatus === 'Approved') ? 'grey.400' : '#0a84ff', opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, }}>
                                        <BarChart fontSize="small" />
                                    </Box>
                                    <Box>
                                        <Typography variant="h6" sx={{ opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, }}>
                                            Add Chart
                                        </Typography>
                                    </Box>
                                </Box>


                                <Box className="infographic-ele-card" onClick={(showHtmlPreview || documentStatus === 'Approved') ? undefined : handleClickOpenImage} sx={{ opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, cursor: (showHtmlPreview || documentStatus === 'Approved') ? 'not-allowed' : 'pointer', }}>
                                    <Box className="icon" sx={{ bgcolor: (showHtmlPreview || documentStatus === 'Approved') ? 'grey.400' : 'primary.main', opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, }}>
                                        <PhotoLibrary fontSize="small" />
                                    </Box>
                                    <Box>
                                        <Typography variant="h6" sx={{ opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, }}>
                                            Upload Image
                                        </Typography>
                                    </Box>
                                </Box>


                                <Box className="infographic-ele-card" onClick={(showHtmlPreview || documentStatus === 'Approved') ? undefined : handleClickOpenTable} sx={{ opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, cursor: (showHtmlPreview || documentStatus === 'Approved') ? 'not-allowed' : 'pointer', }}>
                                    <Box className="icon" sx={{ bgcolor: (showHtmlPreview || documentStatus === 'Approved') ? 'grey.400' : 'primary.main', opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, }}>
                                        <TableChart fontSize="small" />
                                    </Box>
                                    <Box>
                                        <Typography variant="h6" sx={{ opacity: (showHtmlPreview || documentStatus === 'Approved') ? 0.5 : 1, }}>
                                            Add Table
                                        </Typography>
                                    </Box>
                                </Box>


                            </Stack>
                        </Box>

                        <Divider />

                        <ElementToolbox currentElements={dynamicElements} disabled={showHtmlPreview || documentStatus === 'Approved'} />
                    </Drawer>

                    {/* Main Canvas Area */}
                    <Box component="main" sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                        {/* Top Toolbar */}
                        <Box id="top-toolbar" px={2} py={1} sx={{
                            borderBottom: 1,
                            borderColor: 'divider',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 2,
                            position: 'sticky',
                            top: '65px !important',
                            zIndex: '999 !important',
                            background: '#d9d9d9 !important'
                        }}>

                            <IconButton
                                aria-label="more"
                                id="long-button"
                                aria-controls={open ? 'long-menu' : undefined}
                                aria-expanded={open ? 'true' : undefined}
                                aria-haspopup="true"
                                onClick={handleClick}
                                className="action-ico-btn menu"
                            >
                                <MoreVertIcon />
                            </IconButton>
                            <Menu
                                id="long-menu"
                                anchorEl={anchorEl}
                                open={open}
                                onClose={handleClose}
                                slotProps={{
                                    paper: {
                                        style: {
                                            maxHeight: ITEM_HEIGHT * 4.5,
                                            width: '20ch',
                                        },
                                    },
                                    list: {
                                        'aria-labelledby': 'long-button',
                                    },
                                }}
                            >
                                <Box p={1}>
                                    <Stack direction="column" alignItems="center" justifyContent="flex-start" spacing={1}>
                                        <Button className="menu-item-btn" variant="text" startIcon={<UndoIcon />} fullWidth
                                            onClick={(e) => { handleClose(); undo(); }} disabled={historyIndex <= 0 || showHtmlPreview || documentStatus === 'Approved'}>Undo</Button>
                                        <Button className="menu-item-btn" variant="text" startIcon={<RedoIcon />} fullWidth
                                            onClick={(e) => { handleClose(); redo(); }} disabled={historyIndex >= history.length - 1 || showHtmlPreview || documentStatus === 'Approved'}>Redo</Button>

                                        <Box sx={{ width: '100%', padding: '0px' }}>
                                            <FormControlLabel
                                                sx={{ margin: '0px', width: '100%' }}
                                                control={
                                                    <Checkbox
                                                        size="small"
                                                        checked={showGrid}
                                                        onChange={(e) => setShowGrid(e.target.checked)}
                                                        disabled={showHtmlPreview || documentStatus === 'Approved'}
                                                    />
                                                }
                                                label="Grid"
                                            />
                                        </Box>

                                        <Box sx={{ width: '100%', padding: '0px' }}>
                                            <FormControlLabel
                                                sx={{ margin: '0px', width: '100%' }}
                                                control={
                                                    <Checkbox
                                                        size="small"
                                                        checked={showProperties}
                                                        onChange={(e) => setShowProperties(e.target.checked)}
                                                        disabled={showHtmlPreview || documentStatus === 'Approved'}
                                                    />
                                                }
                                                label="Properties"
                                            />
                                        </Box>
                                    </Stack>
                                </Box>

                            </Menu>


                            <Divider orientation="vertical" flexItem />

                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <IconButton size="small" onClick={() => setZoom(Math.max(50, zoom - 10))} disabled={showHtmlPreview || documentStatus === 'Approved'}>
                                    <ZoomOut />
                                </IconButton>
                                <Typography variant="body2">{zoom}%</Typography>
                                <IconButton size="small" onClick={() => setZoom(Math.min(200, zoom + 10))} disabled={showHtmlPreview || documentStatus === 'Approved'}>
                                    <ZoomIn />
                                </IconButton>
                            </Box>

                            <Divider orientation="vertical" flexItem />

                            <FormControlLabel
                                control={
                                    <Switch
                                        size="small"
                                        checked={showHtmlPreview}
                                        onChange={(e) => setShowHtmlPreview(e.target.checked)}
                                        disabled={documentStatus === 'Approved'}
                                    />
                                }
                                label={documentStatus === 'Approved' ? "HTML Preview (Approved Document)" : "HTML Preview"}
                            />


                            {/* <Stack direction="row" alignItems="center" justifyContent="flex-end" spacing={2}>

</Stack> */}

                            {/* <Box sx={{ ml: 'auto', display: 'flex', alignItems: 'center', gap: 1 }}> */}
                            <Stack sx={{ ml: 'auto' }} direction="row" alignItems="center" justifyContent="flex-end" spacing={2}>
                                {/* Status and save functionality now handled by new components above */}

                                <Chip
                                    label={saveStatus}
                                    color={saveStatus === 'saved' ? 'success' : saveStatus === 'saving' ? 'warning' : 'error'}
                                    size="small"
                                    className="simple-chip"
                                />


                                {/* STATUS BAR */}
                                {!isAdmin && documentStatus !== 'Approved' ? <StatusUpdate
                                    documentId={unwrappedParams?.id}
                                    documentStatus={documentStatus}
                                    isFinalized={['approved', 'rejected'].includes((documentStatus || '').toLowerCase())}
                                    getAuthHeaders={getAuthHeaders}
                                    showSnackbar={showSnackbar}
                                    onLocalStatusChange={onStatusLocallySet}
                                /> :
                                    <Chip
                                        label={documentStatus}
                                        color={
                                            documentStatus === 'Draft' ? 'default' :
                                                documentStatus === 'In Progress' ? 'warning' :
                                                    documentStatus === 'Send for Approval' ? 'info' :
                                                        documentStatus === 'Approved' ? 'success' :
                                                            documentStatus === 'Rejected' ? 'error' : 'default'
                                        }
                                        size="small"
                                        className="simple-chip"
                                    />
                                }

                                {/* REVIEW */}
                                <ReviewComponent
                                    documentId={unwrappedParams?.id}
                                    isAdmin={isAdmin}
                                    documentData={documentData}
                                    htmlContent={htmlContent}
                                    documentStatus={documentStatus}
                                    getAuthHeaders={getAuthHeaders}
                                    onStatusLocallySet={onStatusLocallySet}
                                    showSnackbar={showSnackbar}
                                />

                                {/* TOOLBAR: AUTOSAVE / SAVE / COPY / DOWNLOAD */}
                                <AutoComponent
                                    documentId={unwrappedParams?.id}
                                    documentStatus={documentStatus}
                                    showHtmlPreview={showHtmlPreview}
                                    initialLoadingComplete={initialLoadingComplete}
                                    isParsingExistingHTML={isParsingExistingHTML}
                                    loadingData={loadingData}
                                    dynamicElements={dynamicElements}
                                    generateHTML={generateHTML}
                                    getAuthHeaders={getAuthHeaders}
                                    onSaved={onSaved}
                                    setSaveStatus={setSaveStatus}
                                    showSnackbar={showSnackbar}
                                    htmlContent={htmlContent}
                                />

                            </Stack>
                        </Box>

                        {/* Canvas and Preview */}
                        <Box sx={{ flexGrow: 1, display: 'flex', position: 'relative', paddingTop: '65px' }}>
                            {/* Canvas or HTML Preview */}
                            {/* <Box sx={{ flexGrow: 1, p: 2, overflow: 'auto', height: 'calc(100vh - 202px) !important' }}> */}
                            <Box sx={{ flexGrow: 1, p: 2 }}>
                                {loadingData ? (
                                    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                        <CircularProgress />
                                    </Box>
                                ) : showHtmlPreview ? (
                                    // HTML Preview Mode
                                    <Box sx={{
                                        border: '1px solid #e0e0e0',
                                        borderRadius: 2,
                                        bgcolor: 'white',
                                        // height: 'calc ( 100vh - 208px ) !important',
                                        // overflow: 'auto',
                                        position: 'relative'
                                    }}>
                                        <Box sx={{
                                            p: 1,
                                            bgcolor: 'grey.100',
                                            borderBottom: '1px solid #e0e0e0',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: 1
                                        }}>
                                            <Typography variant="caption" sx={{ fontWeight: 600 }}>
                                                HTML Preview
                                            </Typography>
                                            <Chip
                                                label={`${htmlContent.length} characters`}
                                                size="small"
                                                color="info"
                                                variant="outlined"
                                            />
                                        </Box>
                                        <Box sx={{
                                            p: 2,
                                            height: 'calc(100vh - 250px)',
                                            overflow: 'auto',
                                            '& img': { maxWidth: '100%', height: 'auto' }
                                        }}>
                                            <div
                                                dangerouslySetInnerHTML={{ __html: htmlContent || '<p>No content to preview</p>' }}
                                                style={{
                                                    fontFamily: 'Arial, sans-serif',
                                                    lineHeight: 1.6,
                                                    display: 'flex',
                                                    justifyContent: 'center'
                                                }}
                                            />
                                        </Box>
                                    </Box>
                                ) : (
                                    // Canvas Mode
                                    <Box sx={{ height: 'calc(100vh - 210px)', overflow: 'auto' }}>
                                        <DesignCanvas
                                            key={`canvas-${dynamicElements.map(el => `${el.id}-${el.primaryColor || ''}-${el.backgroundColor || ''}-${el.textColor || ''}-${el.borderColor || ''}`).join('-')}`}
                                            elements={dynamicElements}
                                            onElementsChange={(action) => {
                                                if (documentStatus === 'Approved') return; // Prevent changes if document is approved
                                                switch (action.type) {
                                                    case 'EDIT':
                                                        setSelectedElementId(action.element.id);
                                                        // Open edit dialog or inline edit
                                                        break;
                                                    case 'DELETE':
                                                        handleDeleteElement(action.id);
                                                        break;
                                                    case 'COPY':
                                                        handleCopyElement(action.element, action.insertAfterIndex);
                                                        break;
                                                    case 'INSERT':
                                                        handleCopyElement(action.element, action.insertAfterIndex);
                                                        break;
                                                }
                                            }}
                                            onAddElement={(elementType, insertIndex) => {
                                                if (documentStatus === 'Approved') return; // Prevent changes if document is approved
                                                handleAddElement(elementType, '', insertIndex);
                                            }}
                                            selectedElementId={selectedElementId}
                                            onSelectElement={documentStatus === 'Approved' ? undefined : handleSelectElement}
                                            primaryColor={primaryColor}
                                            showGrid={showGrid}
                                            zoom={zoom}
                                            documentData={documentData}
                                            loadingData={loadingData}
                                            hasParsedElements={hasParsedElements}
                                            elementsLoadedFromDatabase={elementsLoadedFromDatabase}
                                        />
                                    </Box>
                                )}
                            </Box>

                            {/* Right Sidebar - Properties Panel */}
                            {showProperties && !showHtmlPreview && (
                                <Drawer
                                    variant="permanent"
                                    anchor="right"
                                    sx={{
                                        width: propertiesPanelWidth,
                                        flexShrink: 0,
                                        [`& .MuiDrawer-paper`]: {
                                            width: propertiesPanelWidth,
                                            boxSizing: "border-box",
                                            position: 'relative',
                                            height: 'calc(100vh - 145px) !important',
                                            overflow: 'auto'
                                        },
                                    }}
                                >
                                    <ErrorBoundary>
                                        <PropertiesPanel
                                            selectedElement={selectedElement}
                                            onUpdate={handleUpdateElement}
                                            primaryColor={primaryColor}
                                            setPrimaryColor={setPrimaryColor}
                                            onDelete={handleDeleteElement}
                                            disabled={showHtmlPreview || documentStatus === 'Approved'}
                                            isTemplateMode={isTemplateMode}
                                            themeColors={parseThemeColors(documentData?.THEME_COLORS)}
                                        />
                                    </ErrorBoundary>
                                </Drawer>
                            )}
                        </Box>
                    </Box>
                </Box>

                <DragOverlay>
                    {activeId && isDragging ? (
                        <Paper sx={{
                            p: 2,
                            backgroundColor: 'background.paper',
                            boxShadow: 3,
                            opacity: 0.8,
                            maxWidth: 300,
                            border: '2px solid #1976d2'
                        }}>
                            <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
                                {activeId.startsWith('toolbox-')
                                    ? `Adding ${activeId.replace('toolbox-', '').replace('-', ' ')}`
                                    : 'Moving element'
                                }
                            </Typography>
                        </Paper>
                    ) : null}
                </DragOverlay>
            </DndContext>

            {/* Swipeable Drawer for Infographics */}
            <SwipeableDrawer
                anchor="bottom"
                open={drawerOpen}
                onClose={toggleDrawer(false)}
                onOpen={toggleDrawer(true)}
                swipeAreaWidth={drawerBleeding}
                disableSwipeToOpen={false}
                keepMounted
                sx={{
                    '& .MuiDrawer-paper': {
                        height: `calc(50% - ${drawerBleeding}px)`,
                        overflow: 'visible',
                    },
                }}
            >
                <StyledBox
                    sx={{
                        position: 'absolute',
                        top: -drawerBleeding,
                        borderTopLeftRadius: 8,
                        borderTopRightRadius: 8,
                        visibility: 'visible',
                        right: 0,
                        left: 0,
                        boxShadow: 'rgba(0, 0, 0, 0.16) 0px -4px 4px'
                    }}
                >
                    <Puller />
                    <Box sx={{
                        p: 2,
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                    }}>
                        <Typography variant="h6" sx={{ color: 'text.secondary' }}>
                            <span className="black fw8">{infographics.length}</span> Generated Infographics
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                            <IconButton
                                onClick={() => {
                                    if (documentData?.MIS_DOCUMENT_NAME) {
                                        console.log('🔄 Refreshing infographics for document:', documentData.MIS_DOCUMENT_NAME);
                                        fetchInfographics(documentData.MIS_DOCUMENT_NAME);
                                    }
                                }}
                                disabled={loadingInfographics}
                                size="small"
                                sx={{ color: 'primary.main' }}
                                title="Refresh Infographics"
                                className="action-ico-btn success"
                            >
                                <Refresh />
                            </IconButton>
                            <IconButton
                                onClick={toggleDrawer(false)}
                                size="small"
                                sx={{ color: 'primary.main' }}
                                className="action-ico-btn menu"
                                title="Close Infographics"
                            >
                                <KeyboardArrowDown />
                            </IconButton>
                        </Box>
                    </Box>
                </StyledBox>
                <Divider sx={{ py: 1 }} />
                <StyledBox sx={{ px: 2, pb: 2, height: '100%', overflow: 'auto' }}>
                    {loadingInfographics ? (
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, p: 2 }}>
                            <CircularProgress size={20} />
                            <Typography variant="body2" color="text.secondary">
                                Loading infographics...
                            </Typography>
                        </Box>
                    ) : infographicsError ? (
                        <Alert severity="error" sx={{ m: 2 }}>
                            {infographicsError}
                        </Alert>
                    ) : infographics.length === 0 ? (
                        <Typography variant="body2" color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
                            No infographics generated yet. Create charts or tables to generate infographics.
                        </Typography>
                    ) : (
                        <Box>
                            {/* Selection Controls Header */}
                            <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                p: 2,
                                borderBottom: '1px solid',
                                borderColor: 'divider',
                                bgcolor: 'background.paper'
                            }}>
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                    <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                        {selectedInfographics.size} of {infographics.filter(inf => !inf.isUsed).length} unused infographics selected
                                    </Typography>
                                    <Button
                                        size="small"
                                        variant="outlined"
                                        onClick={handleSelectAllInfographics}
                                        disabled={infographics.filter(inf => !inf.isUsed).length === 0}
                                    >
                                        Select All Unused
                                    </Button>
                                    <Button
                                        size="small"
                                        variant="outlined"
                                        onClick={handleDeselectAllInfographics}
                                        disabled={selectedInfographics.size === 0}
                                    >
                                        Deselect All
                                    </Button>
                                </Box>
                                <Button
                                    variant="contained"
                                    color="error"
                                    size="small"
                                    startIcon={<DeleteIcon />}
                                    onClick={handleBulkDeleteInfographics}
                                    disabled={selectedInfographics.size === 0}
                                >
                                    Delete Selected ({selectedInfographics.size})
                                </Button>
                            </Box>

                            {/* Infographics Grid */}
                            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 2, p: 2 }}>
                                {infographics
                                    .sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt)) // Sort by upload date, newest first
                                    .map((infographic, index) => (
                                        <Box
                                            key={index}
                                            sx={{
                                                position: 'relative',
                                                border: '2px solid',
                                                borderColor: infographic.isUsed ? 'success.main' : selectedInfographics.has(infographic.filename) ? 'primary.main' : 'divider',
                                                borderRadius: 2,
                                                overflow: 'hidden',
                                                transition: 'all 0.2s ease-in-out',
                                                cursor: infographic.isUsed ? 'not-allowed' : 'pointer',
                                                opacity: infographic.isUsed ? 0.7 : 1,
                                                '&:hover': {
                                                    borderColor: infographic.isUsed ? 'success.main' : 'primary.main',
                                                    transform: infographic.isUsed ? 'none' : 'scale(1.02)',
                                                    boxShadow: infographic.isUsed ? 1 : 2
                                                }
                                            }}
                                            onMouseEnter={() => !infographic.isUsed && handleInfographicHover(infographic)}
                                            onMouseLeave={handleInfographicLeave}
                                            onClick={() => !infographic.isUsed && handleViewEditInfographic(infographic)}
                                        >
                                            <Box sx={{ position: 'relative' }}>
                                                <SafeImage
                                                    src={infographic.url}
                                                    alt={infographic.filename}
                                                    style={{
                                                        width: '100%',
                                                        height: '120px',
                                                        objectFit: 'cover',
                                                        display: 'block'
                                                    }}
                                                />
                                                {/* Type Icon */}
                                                <Box
                                                    sx={{
                                                        position: 'absolute',
                                                        top: 4,
                                                        right: 4,
                                                        bgcolor: 'rgba(0,0,0,0.7)',
                                                        color: 'white',
                                                        borderRadius: '50%',
                                                        width: 24,
                                                        height: 24,
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        fontSize: '12px'
                                                    }}
                                                >
                                                    {infographic.chartType ? '📊' : infographic.imageType ? '🖼️' : '📋'}
                                                </Box>
                                                {/* Selection Checkbox */}
                                                {!infographic.isUsed && (
                                                    <Box
                                                        sx={{
                                                            position: 'absolute',
                                                            top: 4,
                                                            left: 4,
                                                            bgcolor: selectedInfographics.has(infographic.filename) ? 'primary.main' : 'rgba(255,255,255,0.9)',
                                                            borderRadius: '4px',
                                                            p: 0.5,
                                                            transition: 'all 0.2s ease'
                                                        }}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleInfographicSelection(infographic, !selectedInfographics.has(infographic.filename));
                                                        }}
                                                    >
                                                        <Checkbox
                                                            size="small"
                                                            checked={selectedInfographics.has(infographic.filename)}
                                                            onChange={(e) => {
                                                                e.stopPropagation();
                                                                handleInfographicSelection(infographic, e.target.checked);
                                                            }}
                                                            sx={{
                                                                p: 0,
                                                                color: selectedInfographics.has(infographic.filename) ? 'white' : 'inherit',
                                                                '&.Mui-checked': {
                                                                    color: 'white'
                                                                }
                                                            }}
                                                        />
                                                    </Box>
                                                )}
                                            </Box>
                                            <Box sx={{ p: 1, bgcolor: 'background.paper' }}>
                                                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
                                                    <Typography variant="caption" sx={{
                                                        display: 'block',
                                                        fontWeight: 600,
                                                        color: 'text.primary',
                                                        flex: 1
                                                    }}>
                                                        {infographic.chartType ? `Chart: ${infographic.chartType}` : infographic.imageType ? `Image: ${infographic.filename}` : `Table: ${infographic.tableName}`}
                                                    </Typography>
                                                    <Chip
                                                        size="small"
                                                        label={infographic.isUsed ? 'USED' : 'UNUSED'}
                                                        color={infographic.isUsed ? 'success' : 'default'}
                                                        sx={{
                                                            fontSize: '8px',
                                                            height: '16px',
                                                            fontWeight: 'bold'
                                                        }}
                                                    />
                                                </Box>
                                                <Typography variant="caption" sx={{
                                                    color: 'text.secondary',
                                                    fontSize: '10px'
                                                }}>
                                                    {new Date(infographic.uploadedAt).toLocaleDateString()}
                                                </Typography>
                                            </Box>

                                            {/* Hover Options */}
                                            {hoveredInfographic === infographic && (
                                                <Box
                                                    sx={{
                                                        position: 'absolute',
                                                        top: 0,
                                                        left: 0,
                                                        right: 0,
                                                        bottom: 0,
                                                        bgcolor: 'rgba(0,0,0,0.8)',
                                                        display: 'flex',
                                                        flexDirection: 'column',
                                                        justifyContent: 'center',
                                                        alignItems: 'center',
                                                        gap: 1,
                                                        p: 1
                                                    }}
                                                >
                                                    <Button
                                                        variant="contained"
                                                        size="small"
                                                        startIcon={<VisibilityIcon />}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleViewEditInfographic(infographic);
                                                        }}
                                                        sx={{ minWidth: '120px' }}
                                                    >
                                                        View/Edit
                                                    </Button>
                                                    <Button
                                                        variant="outlined"
                                                        size="small"
                                                        startIcon={<Add />}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleAddInfographicToDocument(infographic);
                                                        }}
                                                        sx={{
                                                            minWidth: '120px',
                                                            color: 'white',
                                                            borderColor: 'white',
                                                            '&:hover': {
                                                                borderColor: 'white',
                                                                bgcolor: 'rgba(255,255,255,0.1)'
                                                            }
                                                        }}
                                                    >
                                                        Add to Doc
                                                    </Button>
                                                    <Button
                                                        variant="outlined"
                                                        size="small"
                                                        startIcon={<ContentCopy />}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleCopyInfographicLink(infographic);
                                                        }}
                                                        sx={{
                                                            minWidth: '120px',
                                                            color: 'white',
                                                            borderColor: 'white',
                                                            '&:hover': {
                                                                borderColor: 'white',
                                                                bgcolor: 'rgba(255,255,255,0.1)'
                                                            }
                                                        }}
                                                    >
                                                        Copy Link
                                                    </Button>
                                                </Box>
                                            )}
                                        </Box>
                                    ))}
                            </Box>
                        </Box>
                    )}
                </StyledBox>
            </SwipeableDrawer>

            {/* Chart Dialog */}
            <Dialog open={openChart} fullWidth maxWidth="lg">
                <DialogTitle className="custom-dialog-title">
                    📄 Document: {documentData?.MIS_DOCUMENT_NAME || ""}
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setOpenChart(false)}
                    className="action-ico-btn menu"
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 12,
                        top: 14,
                        color: theme.palette.grey[500],
                    })}
                >
                    <IoClose />
                </IconButton>
                <DialogContent>
                    <ChartBuilder
                        themeColors={parseThemeColors(documentData?.THEME_COLORS)}
                        documentName={documentData?.MIS_DOCUMENT_NAME || ""}
                        selectedInfographic={selectedInfographic}
                    />
                </DialogContent>
            </Dialog>
            {/* ReviewDialog now handled by ReviewComponent */}

            {/* Table Dialog */}
            <Dialog open={openTable} fullWidth maxWidth="lg">
                <DialogTitle className="custom-dialog-title">
                    📄 Document: {documentData?.MIS_DOCUMENT_NAME || ""}
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setOpenTable(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 12,
                        top: 14,
                        color: theme.palette.grey[500],
                    })}
                >
                    <IoClose />
                </IconButton>
                <DialogContent>
                    <TableBuilder
                        themeColors={parseThemeColors(documentData?.THEME_COLORS)}
                        documentName={documentData?.MIS_DOCUMENT_NAME || ""}
                        selectedInfographic={selectedInfographic}
                    />
                </DialogContent>
            </Dialog>

            {/* Image Dialog */}
            <Dialog open={openImage} fullWidth maxWidth="sm">
                <DialogTitle className="custom-dialog-title">
                    Upload Image
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    className="action-ico-btn menu"
                    onClick={() => setOpenImage(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 12,
                        top: 14,
                        color: theme.palette.grey[500],
                    })}
                >
                    <IoClose />
                </IconButton>
                <DialogContent>
                    <ImageUploader
                        documentName={documentData?.MIS_DOCUMENT_NAME || ""}
                        selectedInfographic={selectedInfographic}
                        showSnackbar={showSnackbar}
                    />
                </DialogContent>
            </Dialog>

            {/* Snackbar for notifications */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>

        </>
    );
};

export default MISDocumentPage;