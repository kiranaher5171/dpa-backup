'use client'
import React from "react";
import { Container, Box, Skeleton } from '@mui/material';
import BasicLayout from '../../layouts/BasicLayout'
import { useEmployeeStore } from '@/store/employeeStore';
import { useRouter } from 'next/navigation';
import MISDocumentPage from "./MISDocumentPage";

// Loading skeleton component
const MISDocumentSkeleton = () => (
    <BasicLayout>
        <Container maxWidth="xl" sx={{ pt: '64px' }}>
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh" flexDirection="column" gap={3}>
                <Skeleton variant="rectangular" width={400} height={200} />
                <Skeleton variant="text" width={300} height={32} />
                <Skeleton variant="text" width={250} height={24} />
            </Box>
        </Container>
    </BasicLayout>
);

const Page = ({ params }) => {
    const router = useRouter();
    const { employeeDetails } = useEmployeeStore();
    const [checkingSession, setCheckingSession] = React.useState(true);
    const [hasSession, setHasSession] = React.useState(false);

    React.useEffect(() => {
        // run only on client
        try {
            const sessionData = localStorage.getItem('session');
            if (!sessionData) {
                router.push('/auth/sso-login');
                return;
            }
            setHasSession(true);
        } finally {
            setCheckingSession(false);
        }
    }, [router]);

    // While we don't know session status yet
    if (checkingSession) {
        return <MISDocumentSkeleton />;
    }

    // If we have session but employee details haven't hydrated yet, keep skeleton
    if (hasSession && !employeeDetails) {
        return <MISDocumentSkeleton />;
    }

    // Render the page; let the child manage its own fine-grained checks
    return (
        <BasicLayout>
            <MISDocumentPage params={params} />
        </BasicLayout>
    );
};

export default Page;
