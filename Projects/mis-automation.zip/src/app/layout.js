import "./globals.css";
import localFont from 'next/font/local';
import crypto from 'crypto';
import ThemeProviderComponent from "../_components/ThemeProviderComponent";
import { AppRouterCacheProvider } from '@mui/material-nextjs/v15-appRouter';
import SessionInitializer from "../_components/SessionInitializer";
import TokenExpirationHandler from "../_components/TokenExpirationHandler";
// Removed AuthProvider - using direct employee store approach
// import GlobalLoadingProvider from "../_components/GlobalLoadingProvider";



const poppins = localFont({
  src: [
    {
      path: '../../public/fonts/poppins/Poppins-ExtraLight.ttf',
      weight: '200',
      style: 'light',
    },
    {
      path: '../../public/fonts/poppins/Poppins-Light.ttf',
      weight: '300',
      style: 'light',
    },
    {
      path: '../../public/fonts/poppins/Poppins-Regular.ttf',
      weight: '400',
      style: 'regular',
    },
    {
      path: '../../public/fonts/poppins/Poppins-Bold.ttf',
      weight: '500',
      style: 'Bold',
    },
    {
      path: '../../public/fonts/poppins/Poppins-SemiBold.ttf',
      weight: '600',
      style: 'medium',
    },
    {
      path: '../../public/fonts/poppins/Poppins-ExtraBold.ttf',
      weight: '700',
      style: 'bold',
    },
  ],
});


export const metadata = {
  title: "DPA-MISBuilder - Effortless HTML Reports & Templates",
  description: "Streamline your digital content creation with DPA-MISBuilder. Build dynamic MIS reports, newsletters, and email templates effortlessly—no advanced coding required.",
};



export default function RootLayout({ children }) {
  const nonce = crypto.randomBytes(16).toString('base64');
  return (
    <html lang="en">
      <body className={poppins.className}>
        <ThemeProviderComponent nonce={nonce}>
          <AppRouterCacheProvider options={{ key: 'css' }}>
            <SessionInitializer />
            <TokenExpirationHandler />
            <main className="relative" style={{ minHeight: '100vh' }}>
              {children}
            </main>
          </AppRouterCacheProvider>
        </ThemeProviderComponent>
      </body>
    </html>
  );
}