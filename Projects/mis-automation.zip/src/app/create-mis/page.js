"use client";
import * as React from 'react';
import Box from '@mui/material/Box';
import { Container, Typography, Alert, Button, Skeleton } from '@mui/material';
import { ArrowBack } from '@mui/icons-material';
import { useRouter } from 'next/navigation';
import BasicLayout from '../layouts/BasicLayout'
import { useRoleAccess } from '@/hooks/useRoleAccess';
import { useEmployeeStore } from '@/store/employeeStore';
// Lazy load child components for better performance
const ClientsAndTemplates = React.lazy(() => import('./ClientsAndTemplates'));

// Loading skeleton component
const CreateMISSkeleton = () => (
    <BasicLayout>
        <Container maxWidth="xl" sx={{ pt: '64px' }}>
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh" flexDirection="column" gap={3}>
                <Skeleton variant="rectangular" width={400} height={200} />
                <Skeleton variant="text" width={300} height={32} />
                <Skeleton variant="text" width={250} height={24} />
            </Box>
        </Container>
    </BasicLayout>
);

const page = () => {
    const router = useRouter();
    const { isAdmin, isUser } = useRoleAccess();
    const { employeeDetails } = useEmployeeStore();
    const [isInitializing, setIsInitializing] = React.useState(false);

    // Check for session and authentication on component mount
    React.useEffect(() => {
        console.log('🔐 Create MIS: Component mounted, checking session...');
        
        const sessionData = localStorage.getItem("session");
        if (!sessionData) {
            console.log('🔐 Create MIS: No session found, redirecting to login');
            router.push('/auth/sso-login');
        } else {
            // If we have a session but no employee details, we might be initializing
            if (!employeeDetails) {
                console.log('🔐 Create MIS: Session found but no employee details, might be initializing...');
                setIsInitializing(true);
            } else {
                // Employee details are loaded, stop initializing
                setIsInitializing(false);
            }
        }
    }, [employeeDetails]);

    // Show loading skeleton if no employee details or if initializing
    if (!employeeDetails || isInitializing) {
        console.log('🔐 Create MIS: No employee details or initializing, showing skeleton');
        return <CreateMISSkeleton />;
    }

    // Check if user is admin - prevent access
    if (isAdmin()) {
        return (
            <BasicLayout>
                <Container maxWidth="xl" sx={{ pt: '64px' }}>
                    <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh" flexDirection="column" gap={3}>
                        <Alert severity="error" sx={{ maxWidth: 600 }}>
                            <Typography variant="h6" gutterBottom>
                                Access Denied
                            </Typography>
                            <Typography variant="body1">
                                This page is only accessible to regular users. Admin users cannot create MIS documents.
                            </Typography>
                        </Alert>
                        <Button
                            variant="outlined"
                            startIcon={<ArrowBack />}
                            onClick={() => router.push('/main-dashboard')}
                        >
                            Back to Dashboard
                        </Button>
                    </Box>
                </Container>
            </BasicLayout>
        );
    }

    // User is authenticated and is a regular user - allow access
    return (
        <>
            <BasicLayout>
                <Box className="main-box">
                    <ClientsAndTemplates />
                </Box>
            </BasicLayout>
        </>
    );
}

export default page