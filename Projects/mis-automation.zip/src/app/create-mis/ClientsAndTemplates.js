'use client'
import React, { useState } from 'react'
import {
    Autocomplete,
    TextField,
    Card,
    CardContent,
    Typography,
    Grid,
    Box,
    Chip,
    Button,
    Avatar,
    AvatarGroup,
    IconButton,
    Paper,
    Container,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    FormControl,
    CircularProgress,
    Skeleton,
    Snackbar,
    Alert,
    InputAdornment,
    Divider,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TablePagination,
    Tooltip
} from '@mui/material'
import {
    Search,
    Business,
    Description,
    CalendarToday,
    Person,
    ArrowForward,
    Add,
    FilterList,
    Sort,
    RequestPage as RequestAccessIcon,
    Visibility as ViewDocumentsIcon
} from '@mui/icons-material'
import { useRouter } from 'next/navigation'
import { useEmployeeStore } from '@/store/employeeStore'
import { useRoleAccess } from '@/hooks/useRoleAccess';
import { HiOutlineDocumentAdd } from "react-icons/hi";
import TemplateRequest from './TemplateRequest';
import ClientsAndTemplatesSkeleton from './ClientsAndTemplatesSkeleton'
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PostAddIcon from '@mui/icons-material/PostAdd';
import LockPersonIcon from '@mui/icons-material/LockPerson';



const ClientsAndTemplates = () => {
    const { employeeDetails, userRole } = useEmployeeStore()
    const router = useRouter()
    console.warn('Employee Details', employeeDetails);
    console.warn('User Role', userRole);

    const [selectedClient, setSelectedClient] = useState(null)
    const [searchQuery, setSearchQuery] = useState('')
    const [filterStatus, setFilterStatus] = useState('all')
    const [clients, setClients] = useState([])
    const [misTemplates, setMisTemplates] = useState([])
    const [loadingData, setLoadingData] = useState(true)

    // Dialog state
    const [dialogOpen, setDialogOpen] = useState(false)
    const [selectedTemplate, setSelectedTemplate] = useState(null)
    const [selectedMonth, setSelectedMonth] = useState('')
    const [selectedYear, setSelectedYear] = useState('')
    const [isCreating, setIsCreating] = useState(false)
    const [existingDocuments, setExistingDocuments] = useState([])

    // Template selection states
    const [availableTemplates, setAvailableTemplates] = useState([])
    const [selectedHtmlTemplate, setSelectedHtmlTemplate] = useState(null)
    const [loadingTemplates, setLoadingTemplates] = useState(false)

    // Table states
    const [allTemplates, setAllTemplates] = useState([])
    const [filteredTemplates, setFilteredTemplates] = useState([])
    const [searchTerm, setSearchTerm] = useState('')
    const [requestingTemplates, setRequestingTemplates] = useState(new Set())
    const [requestedTemplates, setRequestedTemplates] = useState(new Set())

    // Invoice Activity Details state
    const [invoiceDetails, setInvoiceDetails] = useState(null)

    // Template Requests state
    const [templateRequests, setTemplateRequests] = useState([])
    const [loadingRequests, setLoadingRequests] = useState(false)
    const [requestsError, setRequestsError] = useState(null)

    // Documents dialog state
    const [documentsDialogOpen, setDocumentsDialogOpen] = useState(false)
    const [selectedTemplateForDocuments, setSelectedTemplateForDocuments] = useState(null)
    const [templateDocuments, setTemplateDocuments] = useState([])
    const [loadingDocuments, setLoadingDocuments] = useState(false)


    // Snackbar states
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'info' // 'error', 'warning', 'info', 'success'
    })

    // Snackbar handlers
    const showSnackbar = (message, severity = 'info') => {
        setSnackbar({
            open: true,
            message,
            severity
        })
    }

    const handleCloseSnackbar = () => {
        setSnackbar(prev => ({
            ...prev,
            open: false
        }))
    }

    // Month options
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ]

    // Year options (previous year + current year + 5 years ahead)
    const currentYear = new Date().getFullYear()
    const years = Array.from({ length: 7 }, (_, i) => (currentYear - 1 + i).toString())

    // Fetch documents for a specific template
    const fetchTemplateDocuments = async (template) => {
        try {
            setLoadingDocuments(true);
            setTemplateDocuments([]);

            console.log('🔄 Fetching documents for template:', template.TEMPLATE_NAME);

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                console.error('❌ No access token available');
                return;
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            };

            const response = await fetch(`/api/client-mis-documents?templateId=${template.ID}`, {
                headers: headers
            });

            if (response.ok) {
                const data = await response.json();
                console.log('📊 Template documents data:', data);
                setTemplateDocuments(data.documents || []);
                console.log('✅ Template documents loaded:', data.documents?.length || 0);
            } else {
                const errorData = await response.json();
                console.error('❌ Failed to fetch template documents:', errorData);
                showSnackbar('Failed to fetch documents', 'error');
            }
        } catch (error) {
            console.error('❌ Error fetching template documents:', error);
            showSnackbar('Error connecting to documents service', 'error');
        } finally {
            setLoadingDocuments(false);
        }
    };

    // Fetch template requests
    const fetchTemplateRequests = async () => {
        try {
            setLoadingRequests(true);
            setRequestsError(null);

            console.log('🔄 Starting to fetch template requests...');

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                    console.log('🔐 Access token found:', accessToken ? 'Yes' : 'No');
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                setRequestsError('No authentication token available');
                console.error('❌ No access token available');
                return;
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            };

            // Always use user-specific API since this page is already secured
            const apiEndpoint = '/api/raise-template-request/get-user-requests';

            console.log('🔍 Fetching template requests from:', apiEndpoint);
            console.log('🔍 Headers:', headers);

            const response = await fetch(apiEndpoint, {
                headers: headers
            });

            console.log('📡 Response status:', response.status);
            console.log('📡 Response ok:', response.ok);

            if (response.ok) {
                const data = await response.json();
                console.log('📊 Template requests data:', data);
                setTemplateRequests(data.requests || []);
                console.log('✅ Template requests loaded:', data.requests?.length || 0);
            } else {
                const errorData = await response.json();
                console.error('❌ Failed to fetch template requests:', errorData);
                setRequestsError(errorData.error || 'Failed to fetch template requests');
            }
        } catch (error) {
            console.error('❌ Error fetching template requests:', error);
            setRequestsError('Error connecting to template requests service');
        } finally {
            setLoadingRequests(false);
        }
    };

    // Fetch invoice details
    const getInvoiceDetails = async () => {
        try {
            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                setInvoiceDetails({
                    error: 'No session or access token available',
                    details: 'Please login again'
                });
                return;
            }

            const url = process.env.NEXT_PUBLIC_SSO_TIMESHEET_INVOICE_DETAIL;

            if (!url) {
                setInvoiceDetails({
                    error: 'Invoice details API URL not configured',
                    details: 'Please check environment variables'
                });
                return;
            }

            console.log('Invoice Details URL:', url);

            // Get today's date in YYYY-MM-DD format
            const today = new Date().toISOString().split('T')[0];
            console.log('Requesting data for date:', today);

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };

            let response;
            try {
                response = await fetch(url, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ date: today })
                });
            } catch (fetchError) {
                console.error('Fetch error:', fetchError);
                setInvoiceDetails({
                    error: 'Network error',
                    details: 'Failed to connect to invoice activity service. Please check your internet connection.'
                });
                return;
            }

            if (response && response.ok) {
                const data = await response.json();
                setInvoiceDetails({ ...data, url, requestDate: today });
                console.log('Invoice Details Response:', data);
            } else {
                const errorText = response ? await response.text() : 'No response received';
                console.log('Invoice Details Error response:', errorText);

                // Try with a different date (yesterday) if today fails
                const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                console.log('Trying with yesterday\'s date:', yesterday);

                let retryResponse;
                try {
                    retryResponse = await fetch(url, {
                        method: 'POST',
                        headers: headers,
                        body: JSON.stringify({ date: yesterday })
                    });
                } catch (retryFetchError) {
                    console.error('Retry fetch error:', retryFetchError);
                    setInvoiceDetails({
                        error: 'Network error',
                        details: 'Failed to connect to invoice activity service on retry. Please check your internet connection.'
                    });
                    return;
                }

                if (retryResponse && retryResponse.ok) {
                    const retryData = await retryResponse.json();
                    setInvoiceDetails({ ...retryData, url, requestDate: yesterday });
                    console.log('Invoice Details Response (yesterday):', retryData);
                } else {
                    const retryErrorText = retryResponse ? await retryResponse.text() : 'No retry response received';
                    console.log('Invoice Details Retry Error:', retryErrorText);
                    setInvoiceDetails({
                        error: 'Invoice activity data not available',
                        details: 'Unable to fetch invoice activity data for the requested date.'
                    });
                }
            }

        } catch (error) {
            console.error('Error fetching invoice details:', error);
            setInvoiceDetails({
                error: 'Failed to fetch invoice activity',
                details: 'There was an error connecting to the invoice activity service.'
            });
        }
    };

    // Helper function to render structured invoice details
    const renderStructuredInvoiceDetails = (data) => {
        if (!data || data.error) return null;

        // Handle object format with numeric keys (0, 1, 2, etc.)
        const invoiceArray = Array.isArray(data) ? data : Object.values(data).filter(item =>
            typeof item === 'object' && item.invoice_id && item.invoice_name && item.client_name
        );

        if (invoiceArray.length > 0) {
            return (
                <Box>
                    <Box mb={3}>
                        <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                <Typography variant="h4" className='page-heading'>
                                    <Box className="decorator" /> Invoice Activities ({invoiceArray.length} invoices)
                                </Typography>
                                <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                                    (filtered)
                                </Typography>
                            </Grid>
                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                <Box className="fx_fe">
                                    <Typography variant="caption" color="text.secondary" display="block">
                                        Date: {data.requestDate}
                                    </Typography>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>
                    {/* <Typography variant="subtitle2" color="primary" gutterBottom>
                        Invoice Activities ({invoiceArray.length} invoices)
                        {data.requestDate && (
                            <Typography variant="caption" color="text.secondary" display="block">
                                Date: {data.requestDate}
                            </Typography>
                        )}
                    </Typography> */}
                    <Grid container spacing={1} justifyContent="space-between" alignItems="center">
                        {invoiceArray.map((invoice, index) => (
                            <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }} key={invoice.invoice_id || index}>
                                <Box sx={{ mb: 1, p: 1.5, bgcolor: '#ffffff', borderRadius: 1 }}>
                                    <Typography variant="body2" color="text.secondary">
                                        <strong>Invoice ID:</strong> {invoice.invoice_id || 'N/A'}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        <strong>Client:</strong> {invoice.client_name || 'N/A'}
                                    </Typography>
                                </Box>
                            </Grid>
                        ))}
                    </Grid>
                </Box>
            );
        }

        return (
            <Typography variant="body2" color="text.secondary">
                No structured invoice data available
            </Typography>
        );
    };

    // Function to fetch available templates and existing documents
    const fetchAvailableTemplates = async () => {
        try {
            setLoadingTemplates(true);
            console.log('Fetching available templates and existing documents...');

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            // Fetch existing documents for this template
            let existingDocs = [];
            if (selectedTemplate && selectedTemplate.ID) {
                try {
                    const docsResponse = await fetch(`/api/client-mis-documents?templateId=${selectedTemplate.ID}`, {
                        headers: headers
                    });

                    if (docsResponse.ok) {
                        const docsData = await docsResponse.json();
                        existingDocs = docsData.documents || [];
                        console.log('Existing documents for template:', existingDocs);
                    }
                } catch (error) {
                    console.error('Error fetching existing documents:', error);
                }
            }

            // Build template options based on existing documents
            const templates = [
                {
                    id: 'default',
                    MIS_DOCUMENT_NAME: 'Default Basic Template',
                    HTML_TEMPLATE: null, // Will use generateHTML() for default
                    CREATED_AT: new Date().toISOString(),
                    type: 'default'
                }
            ];

            // Add existing documents as options (if any exist)
            if (existingDocs.length > 0) {
                const existingDocOptions = existingDocs.map(doc => ({
                    id: doc.ID,
                    MIS_DOCUMENT_NAME: `${doc.MIS_DOCUMENT_NAME} (Existing Document)`,
                    HTML_TEMPLATE: doc.HTML_TEMPLATE,
                    CREATED_AT: doc.CREATED_AT,
                    BANNER_URL: doc.BANNER_URL,
                    THEME_COLORS: doc.THEME_COLORS,
                    DYNAMIC_ELEMENTS: doc.DYNAMIC_ELEMENTS,
                    GENERATED_INFOGRAPHICS: doc.GENERATED_INFOGRAPHICS, // Include infographics data
                    type: 'existing_document',
                    originalDocument: doc
                }));
                templates.push(...existingDocOptions);
                console.log('Added existing documents as template options:', existingDocOptions.length);
            }

            setAvailableTemplates(templates);
            console.log('Available templates and documents loaded:', templates);
        } catch (error) {
            console.error('Error fetching templates:', error);
        } finally {
            setLoadingTemplates(false);
        }
    };

    // Default HTML template
    const getDefaultHtmlTemplate = (title, date, bannerUrl, dynamicContent) => {
        return `<!doctype html>
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
<head>
    <meta charset="utf-8">
    <title>${title}</title>
    <!--[if mso]>
    <style>
      v\:* { behavior: url(#default#VML); }
      o\:* { behavior: url(#default#VML); }
      w\:* { behavior: url(#default#VML); }
      .shape { behavior: url(#default#VML); }
    </style>
    <![endif]-->
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" style="font-family: calibri; background-color:#ffffff; ">
    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#f2f2f2">
        <tbody>
            <tr>
                <td>
                    <!-- Main TD -->
                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tbody>
                            <!-- Main MIS Content Here -->
                            ${dynamicContent}
                            <!-- Main MIS Content Here -->
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>`;
    };

    // Function to handle template selection
    const handleHtmlTemplateSelect = async (template) => {
        if (!template) return;

        console.log('HTML Template selected:', template);

        if (template.id === 'default') {
            // Default template doesn't need to fetch HTML content
            setSelectedHtmlTemplate(template);
        } else if (template.type === 'existing_document') {
            // Handle existing document selection
            try {
                // Parse THEME_COLORS if it's a string (from CLOB)
                let themeColors = [];
                if (template.THEME_COLORS) {
                    if (Array.isArray(template.THEME_COLORS)) {
                        themeColors = template.THEME_COLORS;
                    } else if (typeof template.THEME_COLORS === 'string') {
                        try {
                            themeColors = JSON.parse(template.THEME_COLORS);
                        } catch (e) {
                            console.warn('Failed to parse THEME_COLORS as JSON:', template.THEME_COLORS);
                            themeColors = [];
                        }
                    }
                }

                // Parse DYNAMIC_ELEMENTS if it's a string (from CLOB)
                let dynamicElements = [];
                if (template.DYNAMIC_ELEMENTS) {
                    if (Array.isArray(template.DYNAMIC_ELEMENTS)) {
                        dynamicElements = template.DYNAMIC_ELEMENTS;
                    } else if (typeof template.DYNAMIC_ELEMENTS === 'string') {
                        try {
                            dynamicElements = JSON.parse(template.DYNAMIC_ELEMENTS);
                        } catch (e) {
                            console.warn('Failed to parse DYNAMIC_ELEMENTS as JSON:', template.DYNAMIC_ELEMENTS);
                            dynamicElements = [];
                        }
                    }
                }

                // Parse GENERATED_INFOGRAPHICS if it's a string (from CLOB)
                let generatedInfographics = [];
                if (template.GENERATED_INFOGRAPHICS) {
                    if (Array.isArray(template.GENERATED_INFOGRAPHICS)) {
                        generatedInfographics = template.GENERATED_INFOGRAPHICS;
                    } else if (typeof template.GENERATED_INFOGRAPHICS === 'string') {
                        try {
                            generatedInfographics = JSON.parse(template.GENERATED_INFOGRAPHICS);
                        } catch (e) {
                            console.warn('Failed to parse GENERATED_INFOGRAPHICS as JSON:', template.GENERATED_INFOGRAPHICS);
                            generatedInfographics = [];
                        }
                    }
                }

                const templateWithContent = {
                    ...template,
                    HTML_TEMPLATE: template.HTML_TEMPLATE,
                    BANNER_URL: template.BANNER_URL,
                    THEME_COLORS: themeColors,
                    DYNAMIC_ELEMENTS: dynamicElements,
                    GENERATED_INFOGRAPHICS: generatedInfographics
                };
                setSelectedHtmlTemplate(templateWithContent);
                console.log('HTML content loaded from existing document:', template.MIS_DOCUMENT_NAME);
                console.log('Banner URL:', template.BANNER_URL);
                console.log('Theme Colors:', themeColors);
                console.log('Dynamic Elements:', dynamicElements);
                console.log('Generated Infographics:', generatedInfographics);
            } catch (error) {
                console.error('Error processing existing document content:', error);
                showSnackbar('Error processing existing document content', 'error');
            }
        } else {
            // Handle template selection (from client-mis-templates)
            try {
                // Parse THEME_COLORS if it's a string (from CLOB)
                let themeColors = [];
                if (template.THEME_COLORS) {
                    if (Array.isArray(template.THEME_COLORS)) {
                        themeColors = template.THEME_COLORS;
                    } else if (typeof template.THEME_COLORS === 'string') {
                        try {
                            themeColors = JSON.parse(template.THEME_COLORS);
                        } catch (e) {
                            console.warn('Failed to parse THEME_COLORS as JSON:', template.THEME_COLORS);
                            themeColors = [];
                        }
                    }
                }

                const templateWithContent = {
                    ...template,
                    HTML_TEMPLATE: template.HTML_TEMPLATE || template.TEMPLATE_DATA,
                    BANNER_URL: template.BANNER_URL,
                    THEME_COLORS: themeColors,
                    DYNAMIC_ELEMENTS: [] // Default empty array for dynamic elements
                };
                setSelectedHtmlTemplate(templateWithContent);
                console.log('HTML content loaded for template:', template.MIS_DOCUMENT_NAME);
                console.log('Banner URL:', template.BANNER_URL);
                console.log('Theme Colors:', themeColors);
            } catch (error) {
                console.error('Error processing template content:', error);
                showSnackbar('Error processing template content', 'error');
            }
        }
    };

    // Fetch templates when dialog opens or selected template changes
    React.useEffect(() => {
        if (dialogOpen) {
            fetchAvailableTemplates();
        }
    }, [dialogOpen, selectedTemplate]);

    // Fetch data from API
    React.useEffect(() => {
        const fetchData = async () => {
            try {
                setLoadingData(true);

                console.log('🔄 Starting to fetch all templates with access info...');
                console.log('👤 Employee details:', employeeDetails);
                console.log('👤 User role:', userRole);

                // Get authentication token from localStorage
                const session = localStorage.getItem('session');
                let accessToken = '';

                if (session) {
                    try {
                        const sessionData = JSON.parse(session);
                        accessToken = sessionData.accessToken || '';
                    } catch (parseError) {
                        console.error('Error parsing session data:', parseError);
                    }
                }

                const headers = {
                    'Content-Type': 'application/json'
                };

                // Add Authorization header if we have a token
                if (accessToken) {
                    headers['Authorization'] = `Bearer ${accessToken}`;
                }

                // Only fetch clients if user is admin
                if (employeeDetails?.userRole === 'admin') {
                    const clientsResponse = await fetch('/api/clients?simple=true', {
                        credentials: 'include'
                    });

                    if (clientsResponse.ok) {
                        const clientsData = await clientsResponse.json();
                        console.log('Clients data received:', clientsData);
                        setClients(clientsData.clients || []);
                    } else {
                        console.error('Failed to fetch clients:', clientsResponse.status);
                    }
                }

                // Get the display name using the same logic as the header
                const getDisplayName = () => {
                    if (employeeDetails?.full_name) {
                        return employeeDetails.full_name;
                    }
                    if (employeeDetails?.name) {
                        return employeeDetails.name;
                    }
                    if (employeeDetails?.first_name && employeeDetails?.last_name) {
                        return `${employeeDetails.first_name} ${employeeDetails.last_name}`;
                    }
                    return 'User';
                };

                const requestBody = {
                    userName: getDisplayName(),
                    employeeCode: employeeDetails?.employee_code || ''
                };

                console.log('🔍 Request body for all templates:', requestBody);

                // Fetch all templates with access information
                const templatesResponse = await fetch('/api/client-mis-templates/all-with-access', {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify(requestBody)
                });

                console.log('📡 All templates response status:', templatesResponse.status);
                console.log('📡 All templates response ok:', templatesResponse.ok);

                if (templatesResponse.ok) {
                    const templatesData = await templatesResponse.json();
                    console.log('All templates with access data received:', templatesData);
                    console.log('Total templates:', templatesData.totalTemplates);
                    console.log('Accessible templates:', templatesData.accessibleTemplates);

                    if (templatesData.success && templatesData.templates) {
                        const processedTemplates = templatesData.templates.map((template, index) => {
                            console.log(`Processing template ${index + 1}/${templatesData.templates.length}:`, {
                                ID: template.ID,
                                NAME: template.TEMPLATE_NAME,
                                CLIENT: template.SSO_CLIENT_NAME,
                                HAS_ACCESS: template.USER_HAS_ACCESS,
                                ACCESS_COUNT: template.ACCESS_EMPLOYEE_COUNT
                            });

                            return {
                                ...template,
                                CLIENT_ID: template.SSO_CLIENT_ID,
                                CLIENT_NAME: template.SSO_CLIENT_NAME,
                                BANNER_URL: template.BANNER_URL
                            };
                        });

                        console.log('All templates processed:', processedTemplates);
                        setAllTemplates(processedTemplates);
                        setFilteredTemplates(processedTemplates);
                        setMisTemplates(processedTemplates); // Keep for backward compatibility
                    } else {
                        console.warn('No templates found or API error:', templatesData);
                        setAllTemplates([]);
                        setFilteredTemplates([]);
                        setMisTemplates([]);
                    }
                } else {
                    console.error('Failed to fetch all templates:', templatesResponse.status);
                    const errorText = await templatesResponse.text();
                    console.error('Error response:', errorText);
                    setAllTemplates([]);
                    setFilteredTemplates([]);
                    setMisTemplates([]);
                }

            } catch (error) {
                console.error('Error fetching data:', error);
            } finally {
                setLoadingData(false);
            }
        };

        if (employeeDetails) {
            fetchData();
            // Also fetch invoice details and template requests
            getInvoiceDetails();
            fetchTemplateRequests();
        }
    }, [employeeDetails?.userRole]);

    // Search and filter functionality
    React.useEffect(() => {
        if (!allTemplates.length) {
            setFilteredTemplates([]);
            return;
        }

        let filtered = allTemplates;

        // Filter by search term
        if (searchTerm.trim()) {
            const searchLower = searchTerm.toLowerCase();
            filtered = filtered.filter(template =>
                template.TEMPLATE_NAME?.toLowerCase().includes(searchLower) ||
                template.SSO_CLIENT_NAME?.toLowerCase().includes(searchLower)
            );
        }

        // Sort templates: access at top, then requested, then rest
        filtered.sort((a, b) => {
            const aHasAccess = a.USER_HAS_ACCESS;
            const bHasAccess = b.USER_HAS_ACCESS;
            const aRequested = requestedTemplates.has(a.ID);
            const bRequested = requestedTemplates.has(b.ID);

            // First priority: templates with access
            if (aHasAccess && !bHasAccess) return -1;
            if (!aHasAccess && bHasAccess) return 1;

            // Second priority: templates that have been requested
            if (aRequested && !bRequested && !aHasAccess && !bHasAccess) return -1;
            if (!aRequested && bRequested && !aHasAccess && !bHasAccess) return 1;

            // Third priority: alphabetical by template name
            return (a.TEMPLATE_NAME || '').localeCompare(b.TEMPLATE_NAME || '');
        });

        setFilteredTemplates(filtered);
    }, [allTemplates, searchTerm, requestedTemplates]);

    const getTypeColor = (type) => {
        switch (type) {
            case 'Sales': return '#2196F3'
            case 'Financial': return '#4CAF50'
            case 'Analytics': return '#FF9800'
            case 'Operations': return '#9C27B0'
            case 'Marketing': return '#F44336'
            case 'HR': return '#607D8B'
            default: return '#757575'
        }
    }

    // Helper function to generate initials from name
    const getInitials = (name) => {
        if (!name || typeof name !== 'string') return '?';
        const words = name.trim().split(/\s+/);
        if (words.length === 1) {
            return words[0].substring(0, 2).toUpperCase();
        }
        return (words[0][0] + words[words.length - 1][0]).toUpperCase();
    }

    // Helper function to get avatar color based on name
    const getAvatarColor = (name) => {
        if (!name) return '#757575';
        const colors = [
            '#f44336', '#e91e63', '#9c27b0', '#673ab7',
            '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4',
            '#009688', '#4caf50', '#8bc34a', '#cddc39',
            '#ffeb3b', '#ffc107', '#ff9800', '#ff5722'
        ];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }

    // Table handlers
    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    const handleRequestAccess = async (template) => {
        const templateId = template.ID;

        try {
            // Add template to requesting set
            setRequestingTemplates(prev => new Set([...prev, templateId]));

            // Get authentication token
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            // Get the display name using the same logic as the header
            const getDisplayName = () => {
                if (employeeDetails?.full_name) {
                    return employeeDetails.full_name;
                }
                if (employeeDetails?.name) {
                    return employeeDetails.name;
                }
                if (employeeDetails?.first_name && employeeDetails?.last_name) {
                    return `${employeeDetails.first_name} ${employeeDetails.last_name}`;
                }
                return 'User';
            };

            // Create template access request
            const requestBody = {
                templateName: template.TEMPLATE_NAME,
                requestorName: getDisplayName(),
                requestorEmpCode: employeeDetails?.employee_code || '',
                requestorEmail: employeeDetails?.email || ''
            };

            console.log('🚀 Sending template access request:', requestBody);

            const response = await fetch('/api/template-access-requests', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(requestBody)
            });

            if (response.ok) {
                const result = await response.json();
                console.log('✅ Template access request sent successfully:', result);
                showSnackbar(`Access request sent for "${template.TEMPLATE_NAME}"`, 'success');

                // Add template to requested set
                setRequestedTemplates(prev => new Set([...prev, templateId]));
            } else {
                const errorData = await response.json();
                console.error('❌ Failed to send template access request:', errorData);
                showSnackbar(`Failed to send access request: ${errorData.error || 'Unknown error'}`, 'error');
            }

        } catch (error) {
            console.error('❌ Error sending template access request:', error);
            showSnackbar(`Error sending access request: ${error.message}`, 'error');
        } finally {
            // Remove template from requesting set
            setRequestingTemplates(prev => {
                const newSet = new Set(prev);
                newSet.delete(templateId);
                return newSet;
            });
        }
    };

    const handleCreateDocument = (template) => {
        setSelectedTemplate(template);
        setDialogOpen(true);
    };

    const handleViewDocuments = (template) => {
        setSelectedTemplateForDocuments(template);
        setDocumentsDialogOpen(true);
        fetchTemplateDocuments(template);
    };

    const handleDocumentsDialogClose = () => {
        setDocumentsDialogOpen(false);
        setSelectedTemplateForDocuments(null);
        setTemplateDocuments([]);
    };

    const handleDocumentClick = (document) => {
        const documentUrl = `/mis/${document.MIS_DOCUMENT_NAME}`;
        console.log('Navigating to document:', documentUrl);
        router.push(documentUrl);
        handleDocumentsDialogClose();
    };


    // Filter templates based on search query only (API-level filtering is already applied)
    const filteredMIS = misTemplates.filter(report => {
        const matchesSearch = report.TEMPLATE_NAME.toLowerCase().includes(searchQuery.toLowerCase())
        return matchesSearch;
    })

    const handleMISClick = async (template) => {
        setSelectedTemplate(template)
        setDialogOpen(true)

        // Fetch existing documents for this template
        try {
            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch(`/api/client-mis-documents?templateId=${template.ID}`, {
                headers: headers
            })

            if (response.ok) {
                const data = await response.json()
                setExistingDocuments(data.documents || [])
            }
        } catch (error) {
            console.error('Error fetching existing documents:', error)
        }
    }

    const handleDialogClose = () => {
        setDialogOpen(false)
        setSelectedTemplate(null)
        setSelectedMonth('')
        setSelectedYear('')
        setSelectedHtmlTemplate(null)
    }

    const handleCreateMIS = async () => {
        if (!selectedMonth || !selectedYear) {
            showSnackbar('Please select both month and year', 'warning')
            return
        }

        if (!selectedHtmlTemplate) {
            showSnackbar('Please select an HTML template', 'warning')
            return
        }

        setIsCreating(true)

        try {
            // Format the document name with dashes and lowercase
            const monthYear = `${selectedMonth.toLowerCase()}-${selectedYear}`
            const templateName = selectedTemplate.TEMPLATE_NAME.replace(/\s+/g, '-').toLowerCase()
            const misDocumentName = `${templateName}-${monthYear}`

            console.log('Creating MIS document with name:', misDocumentName)
            console.log('Using HTML template:', selectedHtmlTemplate.MIS_DOCUMENT_NAME)

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            // Get the HTML template content and banner URL
            let htmlTemplateContent;
            let bannerUrl;
            let themeColors;

            // Helper function to parse theme colors from CLOB data
            const parseThemeColors = (themeColorsData) => {
                console.log('🎨 parseThemeColors called with:', themeColorsData);
                console.log('🎨 parseThemeColors type:', typeof themeColorsData);

                if (!themeColorsData) {
                    console.log('🎨 No THEME_COLORS data provided');
                    return [];
                }

                if (typeof themeColorsData === 'string') {
                    try {
                        const parsed = JSON.parse(themeColorsData);
                        console.log('🎨 Parsed THEME_COLORS from string:', parsed);
                        return parsed;
                    } catch (e) {
                        console.warn('Failed to parse THEME_COLORS as JSON:', themeColorsData, 'Error:', e.message);
                        return [];
                    }
                } else if (Array.isArray(themeColorsData)) {
                    console.log('🎨 THEME_COLORS is already an array:', themeColorsData);
                    return themeColorsData;
                } else if (typeof themeColorsData === 'object') {
                    let themeColorsStr = '';
                    if (themeColorsData.type === 'CLOB') {
                        themeColorsStr = themeColorsData.toString();
                        console.log('🎨 Extracted CLOB string:', themeColorsStr);
                    } else if (themeColorsData.toString && themeColorsData.toString() !== '[object Object]') {
                        themeColorsStr = themeColorsData.toString();
                        console.log('🎨 Extracted toString():', themeColorsStr);
                    } else {
                        // Try to get the actual content from the CLOB object
                        themeColorsStr = themeColorsData.chunk || themeColorsData.value || '';
                        console.log('🎨 Extracted from chunk/value:', themeColorsStr);
                    }

                    try {
                        const parsed = JSON.parse(themeColorsStr);
                        console.log('🎨 Parsed THEME_COLORS from object:', parsed);
                        return parsed;
                    } catch (e) {
                        console.warn('Failed to parse THEME_COLORS object as JSON:', e.message);
                        console.warn('Raw string that failed to parse:', themeColorsStr);
                        return [];
                    }
                }
                console.log('🎨 THEME_COLORS data type not recognized, returning empty array');
                return [];
            };

            // Get dynamic elements from the selected template
            let dynamicElements = [];
            if (selectedHtmlTemplate.id !== 'default' && selectedHtmlTemplate.DYNAMIC_ELEMENTS) {
                dynamicElements = selectedHtmlTemplate.DYNAMIC_ELEMENTS;
                console.log('📝 Using DYNAMIC_ELEMENTS from selected template:', dynamicElements.length, 'elements');
            } else if (selectedHtmlTemplate.type === 'existing_document' && selectedHtmlTemplate.DYNAMIC_ELEMENTS) {
                dynamicElements = selectedHtmlTemplate.DYNAMIC_ELEMENTS;
                console.log('📝 Using DYNAMIC_ELEMENTS from existing document:', dynamicElements.length, 'elements');
            } else {
                console.log('📝 No DYNAMIC_ELEMENTS to copy (using default template or empty)');
            }

            // Get generated infographics from the existing document
            let generatedInfographics = [];
            if (selectedHtmlTemplate.type === 'existing_document' && selectedHtmlTemplate.GENERATED_INFOGRAPHICS) {
                generatedInfographics = selectedHtmlTemplate.GENERATED_INFOGRAPHICS;
                console.log('📊 Using GENERATED_INFOGRAPHICS from existing document:', generatedInfographics.length, 'infographics');
                console.log('📊 Generated Infographics data:', generatedInfographics);
            } else {
                console.log('📊 No GENERATED_INFOGRAPHICS to copy (using default template or empty)');
            }

            console.log('📄 Final document creation data:', {
                documentName: misDocumentName,
                hasHtmlTemplate: !!htmlTemplateContent,
                hasDynamicElements: dynamicElements.length > 0,
                hasGeneratedInfographics: generatedInfographics.length > 0,
                dynamicElementsCount: dynamicElements.length,
                generatedInfographicsCount: generatedInfographics.length
            });

            if (selectedHtmlTemplate.id === 'default') {
                // Use default HTML template with placeholder values
                const defaultTitle = misDocumentName;
                const defaultDate = `${selectedMonth} ${selectedYear}`;
                const defaultBannerUrl = selectedTemplate.BANNER_URL ?
                    `${process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH}mis-banners/${selectedTemplate.BANNER_URL}` : '';
                const defaultDynamicContent = '<!-- Dynamic Content -->';

                htmlTemplateContent = getDefaultHtmlTemplate(defaultTitle, defaultDate, defaultBannerUrl, defaultDynamicContent);
                bannerUrl = selectedTemplate.BANNER_URL || '';
                themeColors = parseThemeColors(selectedTemplate.THEME_COLORS);
                console.log('🎨 Default template themeColors result:', themeColors);
            } else {
                // Use the selected HTML template's content and banner URL
                htmlTemplateContent = selectedHtmlTemplate.HTML_TEMPLATE;
                bannerUrl = selectedHtmlTemplate.BANNER_URL || selectedTemplate.BANNER_URL || '';
                themeColors = parseThemeColors(selectedHtmlTemplate.THEME_COLORS) || parseThemeColors(selectedTemplate.THEME_COLORS);
                console.log('🎨 HTML template themeColors result:', themeColors);
            }

            // Create the MIS document using the new create-new-mis endpoint
            const requestBody = {
                sso_client_id: selectedTemplate.SSO_CLIENT_ID,
                sso_client_name: selectedTemplate.SSO_CLIENT_NAME,
                template_id: selectedTemplate.ID,
                template_name: selectedTemplate.TEMPLATE_NAME,
                user_id: employeeDetails?.employee_code || '',
                mis_document_name: misDocumentName,
                html_template: htmlTemplateContent,
                status: 'Draft',
                banner_url: bannerUrl,
                theme_colors: themeColors,
                dynamic_elements: dynamicElements,
                generated_infographics: generatedInfographics,
                created_by: employeeDetails?.full_name || 'Unknown User',
                created_by_email: employeeDetails?.email || '',
                created_by_role: userRole === 'admin' ? 'Admin' : 'User'
            };

            console.log('📤 Sending document creation request:', {
                documentName: misDocumentName,
                hasHtmlTemplate: !!htmlTemplateContent,
                hasDynamicElements: dynamicElements.length > 0,
                hasGeneratedInfographics: generatedInfographics.length > 0,
                dynamicElementsCount: dynamicElements.length,
                generatedInfographicsCount: generatedInfographics.length,
                generatedInfographicsData: generatedInfographics
            });

            const response = await fetch('/api/create-new-mis', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(requestBody)
            })

            if (!response.ok) {
                const errorData = await response.json()

                // Handle duplicate document error specifically
                if (errorData.code === 'DUPLICATE_DOCUMENT') {
                    showSnackbar(errorData.error || 'A document for this template and period already exists. Please choose a different month/year.', 'error')
                    return
                }

                throw new Error(errorData.error || 'Failed to create MIS document')
            }

            const result = await response.json()
            console.log('MIS document created successfully:', result)

            // Use the document name for navigation (dash-separated format)
            const urlPath = `mis/${misDocumentName}`

            console.log('Redirecting to:', urlPath)
            router.push(urlPath)
            handleDialogClose()

        } catch (error) {
            console.error('Error creating MIS document:', error)
            showSnackbar(`Failed to create MIS document: ${error.message}`, 'error')
        } finally {
            setIsCreating(false)
        }
    }

    // Helper function to check if a month/year combination already exists
    const checkMonthYearExists = (month, year) => {
        if (!month || !year || !existingDocuments.length) return false

        const monthYear = `${month.toLowerCase()}-${year}`
        return existingDocuments.some(doc =>
            doc.MIS_DOCUMENT_NAME.toLowerCase().includes(monthYear)
        )
    }

    // Check if current selection already exists
    const currentMonthYearExists = checkMonthYearExists(selectedMonth, selectedYear)

    // If not authenticated, show message
    if (!employeeDetails) {
        return (
            <Container maxWidth>
                <Box pt={8} px={3} display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                    <Typography>Please sign in to access the MIS Templates.</Typography>
                </Box>
            </Container>
        )
    }

    console.log('✅ Authenticated - showing templates');

    return (
        <Container maxWidth>
            {/* Header Section */}
            <Box mb={4}>
                <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Typography variant="h4" className='page-heading'>
                            <Box className="decorator" /> MIS Templates
                        </Typography>
                        <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                            {filteredTemplates.length} templates found
                            {allTemplates.length > 0 && (
                                <span style={{ fontSize: '0.875rem', color: '#666' }}>
                                    {' '}({allTemplates.filter(t => t.USER_HAS_ACCESS).length} with access)
                                </span>
                            )}
                        </Typography>
                    </Grid>
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Box display="flex" justifyContent="flex-end" gap={2}>

                            <TemplateRequest
                                invoiceDetails={invoiceDetails}
                                onRequestSuccess={fetchTemplateRequests}
                                availableTemplates={misTemplates}
                                existingRequests={templateRequests}
                            />

                            {/* Search Field */}
                            <Box className="textfield ph2 auto-complete" sx={{ minWidth: 300 }}>
                                <TextField
                                    fullWidth
                                    size="small"
                                    placeholder="Search templates by name or client..."
                                    value={searchTerm}
                                    onChange={handleSearchChange}
                                    InputProps={{
                                        startAdornment: (
                                            <InputAdornment position="start">
                                                <Search />
                                            </InputAdornment>
                                        ),
                                        endAdornment: searchTerm && (
                                            <InputAdornment position="end">
                                                <IconButton
                                                    size="small"
                                                    onClick={() => setSearchTerm('')}
                                                    edge="end"
                                                >
                                                    <Box component="span" sx={{ fontSize: '1rem' }}>×</Box>
                                                </IconButton>
                                            </InputAdornment>
                                        )
                                    }}
                                />
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Box>

            {/* Templates Table */}
            {(employeeDetails?.userRole === 'admin' ? selectedClient : true) && (
                <Box className="simple-table-card">
                    {loadingData ? (
                        <ClientsAndTemplatesSkeleton />
                    ) : filteredTemplates.length === 0 ? (
                        <Card sx={{ p: 4, textAlign: 'center' }}>
                            <Description sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                            <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                                {employeeDetails?.userRole === 'admin' ? 'No MIS templates found' : 'No templates available'}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                {employeeDetails?.userRole === 'admin'
                                    ? (searchTerm
                                        ? 'Try adjusting your search criteria'
                                        : 'Create your first MIS template')
                                    : 'Contact your administrator to get assigned to MIS templates'
                                }
                            </Typography>
                        </Card>
                    ) : (
                        <TableContainer sx={{ height: 'calc(100vh - 300px)', overflow: 'auto' }}>
                            <Table stickyHeader>
                                <TableHead>
                                    <TableRow>
                                        <TableCell><strong>Template Name</strong></TableCell>
                                        <TableCell><strong>Client</strong></TableCell>
                                        <TableCell><strong>Access</strong></TableCell>
                                        <TableCell><strong>Created</strong></TableCell>
                                        <TableCell><strong>Actions</strong></TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {filteredTemplates
                                        .map((template) => (
                                            <TableRow
                                                key={template.ID}
                                                sx={{
                                                    backgroundColor: template.USER_HAS_ACCESS ? '#f8f9fa' : 'inherit',
                                                    '&:hover': { backgroundColor: template.USER_HAS_ACCESS ? '#e9ecef' : '#f5f5f5' }
                                                }}
                                            >
                                                <TableCell>
                                                    <Box display="flex" alignItems="center" gap={2}>
                                                        {template.BANNER_URL && (
                                                            <Avatar
                                                                src={`${process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH}mis-banners/${template.BANNER_URL}`}
                                                                sx={{ width: 120, height: 40 }}
                                                                variant="rounded"
                                                            />
                                                        )}
                                                        <Box className="fx_fs gap1">
                                                            {template.USER_HAS_ACCESS ? (
                                                                <CheckCircleIcon color="success" fontSize='small' />
                                                            ) : (
                                                                <CheckCircleIcon sx={{ opacity: 0.2 }} fontSize='small' />
                                                            )}
                                                            <Typography variant="h6" fontWeight="medium">
                                                                {template.TEMPLATE_NAME}
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </TableCell>
                                                <TableCell>
                                                    <Typography variant="body2">
                                                        {template.SSO_CLIENT_NAME}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell>
                                                    <Box display="flex">
                                                        {/* <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                            {template.ACCESS_EMPLOYEE_COUNT} user{template.ACCESS_EMPLOYEE_COUNT !== 1 ? 's' : ''}
                                                        </Typography> */}
                                                        {template.TEMPLATE_ACCESS_EMP_NAMES && template.TEMPLATE_ACCESS_EMP_NAMES.trim() ? (
                                                            <AvatarGroup
                                                                max={4}
                                                                sx={{
                                                                    justifyContent: 'flex-start',
                                                                    '& .MuiAvatar-root': {
                                                                        width: 32,
                                                                        height: 32,
                                                                        fontSize: '0.75rem'
                                                                    }
                                                                }}
                                                                renderSurplus={(surplus) => {
                                                                    const allNames = template.TEMPLATE_ACCESS_EMP_NAMES.split(',').map(name => name.trim());
                                                                    const remainingNames = allNames.slice(3); // Get names after the first 3
                                                                    const remainingNamesText = remainingNames.join(', ');

                                                                    return (
                                                                        <Tooltip
                                                                            title={remainingNamesText}
                                                                            arrow
                                                                            placement="top"
                                                                        >
                                                                            <Avatar
                                                                                sx={{
                                                                                    bgcolor: '#757575',
                                                                                    fontSize: '0.75rem',
                                                                                    fontWeight: 'bold'
                                                                                }}
                                                                            >
                                                                                +{surplus}
                                                                            </Avatar>
                                                                        </Tooltip>
                                                                    );
                                                                }}
                                                            >
                                                                {template.TEMPLATE_ACCESS_EMP_NAMES.split(',').map((name, index) => {
                                                                    const trimmedName = name.trim();
                                                                    return (
                                                                        <Tooltip
                                                                            key={index}
                                                                            title={trimmedName}
                                                                            arrow
                                                                            placement="top"
                                                                        >
                                                                            <Avatar
                                                                                sx={{
                                                                                    bgcolor: getAvatarColor(trimmedName),
                                                                                    fontSize: '0.75rem',
                                                                                    fontWeight: 'bold'
                                                                                }}
                                                                            >
                                                                                {getInitials(trimmedName)}
                                                                            </Avatar>
                                                                        </Tooltip>
                                                                    );
                                                                })}
                                                            </AvatarGroup>
                                                        ) : (
                                                            <Typography
                                                                variant="caption"
                                                                color="text.disabled"
                                                                sx={{ fontSize: '0.75rem', fontStyle: 'italic' }}
                                                            >
                                                                No users assigned
                                                            </Typography>
                                                        )}
                                                    </Box>
                                                </TableCell>
                                                <TableCell>
                                                    <Typography variant="body2" color="text.secondary">
                                                        {new Date(template.CREATED_AT).toLocaleDateString()}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell>
                                                    <Box display="flex" gap={1}>
                                                        {template.USER_HAS_ACCESS ? (
                                                            <>
                                                                <Tooltip title="Create Document">
                                                                    <IconButton
                                                                        color="primary"
                                                                        onClick={() => handleCreateDocument(template)}
                                                                        size="small"
                                                                    >
                                                                        <PostAddIcon />
                                                                    </IconButton>
                                                                </Tooltip>
                                                                <Tooltip title="View All Documents">
                                                                    <IconButton
                                                                        color="info"
                                                                        onClick={() => handleViewDocuments(template)}
                                                                        size="small"
                                                                    >
                                                                        <ViewDocumentsIcon />
                                                                    </IconButton>
                                                                </Tooltip>
                                                            </>
                                                        ) : requestedTemplates.has(template.ID) ? (
                                                            <>
                                                                <Tooltip title="Access Requested">
                                                                    <IconButton
                                                                        color="success"
                                                                        size="small"
                                                                        disabled
                                                                    >
                                                                        <LockPersonIcon />
                                                                    </IconButton>
                                                                </Tooltip>
                                                                <Tooltip title="View All Documents (No Access)">
                                                                    <IconButton
                                                                        color="info"
                                                                        size="small"
                                                                        disabled
                                                                    >
                                                                        <ViewDocumentsIcon />
                                                                    </IconButton>
                                                                </Tooltip>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <Tooltip title="Request Access">
                                                                    <IconButton
                                                                        color="secondary"
                                                                        onClick={() => handleRequestAccess(template)}
                                                                        size="small"
                                                                        disabled={requestingTemplates.has(template.ID)}
                                                                    >
                                                                        {requestingTemplates.has(template.ID) ? (
                                                                            <CircularProgress size={16} />
                                                                        ) : (
                                                                            <LockPersonIcon />
                                                                        )}
                                                                    </IconButton>
                                                                </Tooltip>
                                                                <Tooltip title="View All Documents (No Access)">
                                                                    <IconButton
                                                                        color="info"
                                                                        size="small"
                                                                        disabled
                                                                    >
                                                                        <ViewDocumentsIcon />
                                                                    </IconButton>
                                                                </Tooltip>
                                                            </>
                                                        )}
                                                    </Box>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    )}
                </Box>
            )}


            {/* <Box py={6}>
                <Divider />
            </Box> */}

            {/* Template Requests Section */}
            {/* <Box mt={0} mb={3}>
                <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Typography variant="h4" className='page-heading'>
                            <Box className="decorator" /> My Template Requests
                        </Typography>
                        <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                            (filtered)
                        </Typography>
                    </Grid>
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Box className="fx_fe">
                            <Button
                                variant="outlined"
                                size="small"
                                className='main-btn btn-secondary'
                                onClick={fetchTemplateRequests}
                                disabled={loadingRequests}
                                startIcon={loadingRequests ? <CircularProgress size={16} /> : null}
                            >
                                Refresh
                            </Button>
                        </Box>
                    </Grid>
                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                        <Box>
                            {loadingRequests ? (
                                <Box display="flex" justifyContent="center" alignItems="center" py={2}>
                                    <CircularProgress size={24} />
                                    <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                                        Loading your template requests...
                                    </Typography>
                                </Box>
                            ) : requestsError ? (
                                <Box>
                                    <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                                        {requestsError}
                                    </Alert>
                                </Box>
                            ) : templateRequests.length === 0 ? (
                                <Box textAlign="center" py={3}>
                                    <Typography variant="body2" color="text.secondary">
                                        You haven't raised any template requests yet.
                                    </Typography>
                                    <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                                        Use the "Raise New Request" button above to create your first template request.
                                    </Typography>
                                </Box>
                            ) : (
                                <Box>
                                    <Grid container spacing={2}>
                                        {templateRequests.map((request, index) => (
                                            <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }} key={request.ID || index}>
                                                <Card sx={{
                                                    height: '100%',
                                                    border: '1px solid #e0e0e0',
                                                    '&:hover': {
                                                        boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                                    }
                                                }}>
                                                    <CardContent sx={{ p: 2 }}>
                                                        <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
                                                            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                                                {request.MIS_REQ_CLIENT_NAME}
                                                            </Typography>
                                                            <Chip
                                                                label={request.STATUS.replace('_', ' ').toUpperCase()}
                                                                size="small"
                                                                color={
                                                                    request.STATUS === 'approved' ? 'success' :
                                                                        request.STATUS === 'rejected' ? 'error' :
                                                                            request.STATUS === 'in_progress' ? 'warning' :
                                                                                request.STATUS === 'completed' ? 'primary' : 'default'
                                                                }
                                                                variant="outlined"
                                                            />
                                                        </Box>

                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                            <strong>Invoice ID:</strong> {request.MIS_REQ_INVOICE_ID}
                                                        </Typography>

                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                            <strong>Requestor:</strong> {request.REQUESTOR_NAME} ({request.EMPLOYEE_CODE})
                                                        </Typography>

                                                        {request.REQUEST_COMMENT && (
                                                            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                                <strong>Comment:</strong> {request.REQUEST_COMMENT}
                                                            </Typography>
                                                        )}

                                                        {request.ADMIN_COMMENT && (
                                                            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                                <strong>Admin Comment:</strong> {request.ADMIN_COMMENT}
                                                            </Typography>
                                                        )}

                                                        <Typography variant="caption" color="text.secondary">
                                                            Created: {new Date(request.CREATED_AT).toLocaleDateString()}
                                                            {request.ADMIN_UPDATED_AT && (
                                                                <span> | Updated: {new Date(request.ADMIN_UPDATED_AT).toLocaleDateString()}</span>
                                                            )}
                                                        </Typography>
                                                    </CardContent>
                                                </Card>
                                            </Grid>
                                        ))}
                                    </Grid>
                                </Box>
                            )}
                        </Box>
                    </Grid>
                </Grid>
            </Box> */}




            {/* Create MIS Dialog */}
            <Dialog
                open={dialogOpen}
                onClose={handleDialogClose}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle className='custom-dialog-title' sx={{ pb: 1 }}>
                    Create MIS Report
                </DialogTitle>
                <DialogContent sx={{ pt: 2 }}>
                    {selectedTemplate && (
                        <Box mt={3}>
                            {/* Template Details */}
                            <Box sx={{ mb: 3, p: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
                                <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                                    Template Details
                                </Typography>
                                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                    <Description sx={{ mr: 1, color: 'primary.main' }} />
                                    <Typography variant="body1">
                                        <strong>Template:</strong> {selectedTemplate.TEMPLATE_NAME}
                                    </Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Business sx={{ mr: 1, color: 'primary.main' }} />
                                    <Typography variant="body1">
                                        <strong>Client:</strong> {selectedTemplate.SSO_CLIENT_NAME}
                                    </Typography>
                                </Box>
                            </Box>

                            {/* Month and Year Selection */}
                            <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
                                Creating for the Month of
                            </Typography>

                            <Grid container spacing={2}>
                                <Grid size={{ xs: 6 }}>
                                    <Box className="textfield auto-complete">
                                        <FormControl fullWidth>
                                            {/* <InputLabel>Month</InputLabel> */}
                                            <Autocomplete
                                                value={selectedMonth}
                                                onChange={(e, newValue) => setSelectedMonth(newValue)}
                                                options={months}
                                                renderInput={(params) => (
                                                    <TextField {...params} label="Month" />
                                                )}
                                            />
                                        </FormControl>
                                    </Box>
                                </Grid>
                                <Grid size={{ xs: 6 }}>
                                    <Box className="textfield auto-complete">
                                        <FormControl fullWidth>
                                            {/* <InputLabel>Year</InputLabel> */}
                                            <Autocomplete
                                                value={selectedYear}
                                                onChange={(e, newValue) => setSelectedYear(newValue)}
                                                options={years}
                                                renderInput={(params) => (
                                                    <TextField {...params} label="Year" />
                                                )}
                                            />
                                        </FormControl>
                                    </Box>
                                </Grid>
                                <Grid size={{ xs: 12 }}>
                                    <Box className="textfield auto-complete">
                                        <FormControl fullWidth>
                                            {/* <InputLabel>HTML Template</InputLabel> */}
                                            <Autocomplete
                                                value={selectedHtmlTemplate}
                                                onChange={(e, newValue) => handleHtmlTemplateSelect(newValue)}
                                                options={availableTemplates}
                                                loading={loadingTemplates}
                                                getOptionLabel={(option) => option.MIS_DOCUMENT_NAME || ''}
                                                isOptionEqualToValue={(option, value) => option.id === value.id}
                                                renderInput={(params) => (
                                                    <TextField
                                                        {...params}
                                                        label="HTML Template"
                                                        placeholder="Select a template or use Default Basic Template"
                                                    />
                                                )}
                                                renderOption={(props, option) => {
                                                    const { key, ...otherProps } = props;
                                                    return (
                                                        <Box component="li" key={key} {...otherProps}>
                                                            <Box>
                                                                <Typography variant="body2">
                                                                    {option.MIS_DOCUMENT_NAME}
                                                                </Typography>
                                                                {option.id !== 'default' && (
                                                                    <Typography variant="caption" color="text.secondary">
                                                                        {option.type === 'existing_document' ? 'Existing Document' : 'Template'} - Created: {new Date(option.CREATED_AT).toLocaleDateString()}
                                                                    </Typography>
                                                                )}
                                                            </Box>
                                                        </Box>
                                                    );
                                                }}
                                            />
                                        </FormControl>
                                    </Box>
                                </Grid>
                            </Grid>

                            {/* Template Selection Preview */}
                            {selectedHtmlTemplate && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#f3e5f5', borderRadius: 1 }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                        Selected HTML Template:
                                    </Typography>
                                    <Typography variant="body2" sx={{ color: '#7b1fa2' }}>
                                        {selectedHtmlTemplate.MIS_DOCUMENT_NAME}
                                        {selectedHtmlTemplate.id !== 'default' && (
                                            <span style={{ color: '#9e9e9e', fontSize: '0.75rem' }}>
                                                {' '}({selectedHtmlTemplate.type === 'existing_document' ? 'Existing Document' : 'Template'} - Created: {new Date(selectedHtmlTemplate.CREATED_AT).toLocaleDateString()})
                                            </span>
                                        )}
                                    </Typography>
                                    {selectedHtmlTemplate.type === 'existing_document' && (
                                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1, fontStyle: 'italic' }}>
                                            This will copy the HTML template, banner, theme colors, and dynamic elements from the existing document.
                                        </Typography>
                                    )}
                                </Box>
                            )}

                            {/* Preview URL */}
                            {selectedMonth && selectedYear && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#e3f2fd', borderRadius: 1 }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                        Generated URL:
                                    </Typography>
                                    <Typography variant="body2" sx={{ fontFamily: 'monospace', color: '#1976d2' }}>
                                        /mis/{selectedTemplate.TEMPLATE_NAME.replace(/\s+/g, '-').toLowerCase()}-{selectedMonth.toLowerCase()}-{selectedYear}
                                    </Typography>
                                </Box>
                            )}

                            {/* Specific Month/Year Warning */}
                            {currentMonthYearExists && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#ffebee', borderRadius: 1, border: '1px solid #f44336' }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, fontWeight: 600, color: '#d32f2f' }}>
                                        ❌ Document Already Exists:
                                    </Typography>
                                    <Typography variant="body2" sx={{ fontSize: '0.75rem', color: '#d32f2f' }}>
                                        A document for {selectedMonth} {selectedYear} already exists for this template. Please choose a different month/year.
                                    </Typography>
                                </Box>
                            )}

                            {/* Existing Documents Warning */}
                            {existingDocuments.length > 0 && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#fff3e0', borderRadius: 1, border: '1px solid #ff9800' }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, fontWeight: 600 }}>
                                        ⚠️ Existing Documents for this Template:
                                    </Typography>
                                    <Box sx={{ maxHeight: 100, overflowY: 'auto' }}>
                                        {existingDocuments.map((doc, index) => (
                                            <Typography key={index} variant="body2" sx={{ fontSize: '0.75rem', color: '#e65100' }}>
                                                • {doc.MIS_DOCUMENT_NAME} ({doc.STATUS}) - {new Date(doc.CREATED_AT).toLocaleDateString()}
                                            </Typography>
                                        ))}
                                    </Box>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1, fontStyle: 'italic' }}>
                                        You can create multiple documents for different months, but only one document per month/year for this template.
                                    </Typography>
                                </Box>
                            )}
                        </Box>
                    )}
                </DialogContent>
                <DialogActions className='custom-dialog-action'>
                    <Button onClick={handleDialogClose} color="inherit" disabled={isCreating} className='main-btn btn-tertiary'>
                        Cancel
                    </Button>
                    <Button
                        onClick={handleCreateMIS}
                        variant="contained"
                        className="main-btn btn-primary"
                        disabled={!selectedMonth || !selectedYear || !selectedHtmlTemplate || isCreating || currentMonthYearExists}
                    >
                        {isCreating ? 'Creating...' : 'Create MIS Report'}
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Documents Dialog */}
            <Dialog
                open={documentsDialogOpen}
                onClose={handleDocumentsDialogClose}
                maxWidth="md"
                fullWidth
            >
                <DialogTitle className='custom-dialog-title' sx={{ pb: 1 }}>
                    Documents for {selectedTemplateForDocuments?.TEMPLATE_NAME}
                </DialogTitle>
                <DialogContent sx={{ pt: 2 }}>
                    {selectedTemplateForDocuments && (
                        <Box mt={2}>
                            {/* Template Details */}
                            <Box sx={{ mb: 3, p: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
                                <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                                    Template Details
                                </Typography>
                                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                    <Description sx={{ mr: 1, color: 'primary.main' }} />
                                    <Typography variant="body1">
                                        <strong>Template:</strong> {selectedTemplateForDocuments.TEMPLATE_NAME}
                                    </Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Business sx={{ mr: 1, color: 'primary.main' }} />
                                    <Typography variant="body1">
                                        <strong>Client:</strong> {selectedTemplateForDocuments.SSO_CLIENT_NAME}
                                    </Typography>
                                </Box>
                            </Box>

                            {/* Documents List */}
                            {loadingDocuments ? (
                                <Box display="flex" justifyContent="center" alignItems="center" py={4}>
                                    <CircularProgress size={24} />
                                    <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                                        Loading documents...
                                    </Typography>
                                </Box>
                            ) : templateDocuments.length === 0 ? (
                                <Box textAlign="center" py={4}>
                                    <Description sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                                    <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                                        No documents found
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        No documents have been created for this template yet.
                                    </Typography>
                                </Box>
                            ) : (
                                <Box>
                                    <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
                                        Available Documents ({templateDocuments.length})
                                    </Typography>
                                    <Box className="simple-table-card">
                                        <TableContainer sx={{ maxHeight: 400, minHeight: 200, overflow: 'auto' }}>
                                            <Table stickyHeader>
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell><strong>Document Name</strong></TableCell>
                                                        <TableCell><strong>Status</strong></TableCell>
                                                        <TableCell><strong>Created</strong></TableCell>
                                                        <TableCell><strong>Created By</strong></TableCell>
                                                        <TableCell><strong>Actions</strong></TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {templateDocuments.map((document, index) => (
                                                        <TableRow
                                                            key={document.ID || index}
                                                            sx={{
                                                                '&:hover': { backgroundColor: '#f5f5f5' }
                                                            }}
                                                        >
                                                            <TableCell>
                                                                <Box display="flex" alignItems="center" gap={1}>
                                                                    <Description sx={{ color: 'primary.main' }} />
                                                                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                                                        {document.MIS_DOCUMENT_NAME}
                                                                    </Typography>
                                                                </Box>
                                                            </TableCell>
                                                            <TableCell>
                                                                <Chip
                                                                    label={document.STATUS || 'Unknown'}
                                                                    size="small"
                                                                    color={
                                                                        document.STATUS === 'Published' ? 'success' :
                                                                            document.STATUS === 'Draft' ? 'warning' :
                                                                                document.STATUS === 'Archived' ? 'default' : 'info'
                                                                    }
                                                                    variant="outlined"
                                                                />
                                                            </TableCell>
                                                            <TableCell>
                                                                <Typography variant="body2" color="text.secondary">
                                                                    {new Date(document.CREATED_AT).toLocaleDateString()}
                                                                </Typography>
                                                            </TableCell>
                                                            <TableCell>
                                                                <Typography variant="body2" color="text.secondary">
                                                                    {document.CREATED_BY || 'Unknown'}
                                                                </Typography>
                                                            </TableCell>
                                                            <TableCell>
                                                                <Tooltip title="Open Document">
                                                                    <IconButton
                                                                        color="primary"
                                                                        size="small"
                                                                        onClick={(e) => {
                                                                            e.stopPropagation();
                                                                            handleDocumentClick(document);
                                                                        }}
                                                                    >
                                                                        <ArrowForward />
                                                                    </IconButton>
                                                                </Tooltip>
                                                            </TableCell>
                                                        </TableRow>
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Box>
                                </Box>
                            )}
                        </Box>
                    )}
                </DialogContent>
                <DialogActions className='custom-dialog-action'>
                    <Button
                        onClick={handleDocumentsDialogClose}
                        color="inherit"
                        className='main-btn btn-tertiary'
                    >
                        Close
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Snackbar for notifications */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Container>
    )
}

export default ClientsAndTemplates