'use client'
import React from 'react'
import {
    Card,
    CardContent,
    Grid,
    Box,
    Container,
    Skeleton
} from '@mui/material'

// Skeleton component for ClientsAndTemplates
const ClientsAndTemplatesSkeleton = () => (
    <Container maxWidth>
        {/* Header Skeleton */}
        <Box mb={3}>
            <Skeleton variant="text" width="60%" height={40} />
            <Skeleton variant="text" width="40%" height={24} sx={{ mt: 1 }} />
        </Box>

        {/* Search and Filter Skeleton */}
        <Box mb={3}>
            <Grid container spacing={2}>
                <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                    <Skeleton variant="rectangular" width="100%" height={56} sx={{ borderRadius: 1 }} />
                </Grid>
                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                    <Skeleton variant="rectangular" width="100%" height={56} sx={{ borderRadius: 1 }} />
                </Grid>
                <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                    <Skeleton variant="rectangular" width="100%" height={56} sx={{ borderRadius: 1 }} />
                </Grid>
            </Grid>
        </Box>

        {/* Cards Skeleton */}
        <Grid container spacing={3}>
            {[...Array(6)].map((_, index) => (
                <Grid size={{ lg: 4, md: 6, sm: 6, xs: 12 }} key={index}>
                    <Card sx={{ height: 280 }}>
                        <CardContent>
                            <Box display="flex" alignItems="center" mb={2}>
                                <Skeleton variant="circular" width={40} height={40} />
                                <Box ml={2} flex={1}>
                                    <Skeleton variant="text" width="80%" height={24} />
                                    <Skeleton variant="text" width="60%" height={16} />
                                </Box>
                            </Box>
                            <Skeleton variant="rectangular" width="100%" height={120} sx={{ borderRadius: 1, mb: 2 }} />
                            <Box display="flex" justifyContent="space-between" alignItems="center">
                                <Skeleton variant="text" width="40%" height={20} />
                                <Skeleton variant="rectangular" width={80} height={32} sx={{ borderRadius: 1 }} />
                            </Box>
                        </CardContent>
                    </Card>
                </Grid>
            ))}
        </Grid>
    </Container >
);


export default ClientsAndTemplatesSkeleton