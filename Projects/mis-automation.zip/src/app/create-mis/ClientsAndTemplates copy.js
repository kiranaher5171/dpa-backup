'use client'
import React, { useState } from 'react'
import {
    Autocomplete,
    TextField,
    Card,
    CardContent,
    Typography,
    Grid,
    Box,
    Chip,
    Button,
    Avatar,
    IconButton,
    Paper,
    Container,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    FormControl,
    CircularProgress,
    Skeleton,
    Snackbar,
    Alert,
    InputAdornment,
    Divider
} from '@mui/material'
import {
    Search,
    Business,
    Description,
    CalendarToday,
    Person,
    ArrowForward,
    Add,
    FilterList,
    Sort
} from '@mui/icons-material'
import { useRouter } from 'next/navigation'
import { useEmployeeStore } from '@/store/employeeStore'
import { useRoleAccess } from '@/hooks/useRoleAccess';
import { HiOutlineDocumentAdd } from "react-icons/hi";
import TemplateRequest from './TemplateRequest';
import ClientsAndTemplatesSkeleton from './ClientsAndTemplatesSkeleton'


const ClientsAndTemplates = () => {
    const { employeeDetails, userRole } = useEmployeeStore()
    const router = useRouter()
    console.warn('Employee Details', employeeDetails);
    console.warn('User Role', userRole);

    const [selectedClient, setSelectedClient] = useState(null)
    const [searchQuery, setSearchQuery] = useState('')
    const [filterStatus, setFilterStatus] = useState('all')
    const [clients, setClients] = useState([])
    const [misTemplates, setMisTemplates] = useState([])
    const [loadingData, setLoadingData] = useState(true)

    // Dialog state
    const [dialogOpen, setDialogOpen] = useState(false)
    const [selectedTemplate, setSelectedTemplate] = useState(null)
    const [selectedMonth, setSelectedMonth] = useState('')
    const [selectedYear, setSelectedYear] = useState('')
    const [isCreating, setIsCreating] = useState(false)
    const [existingDocuments, setExistingDocuments] = useState([])

    // Template selection states
    const [availableTemplates, setAvailableTemplates] = useState([])
    const [selectedHtmlTemplate, setSelectedHtmlTemplate] = useState(null)
    const [loadingTemplates, setLoadingTemplates] = useState(false)

    // Invoice Activity Details state
    const [invoiceDetails, setInvoiceDetails] = useState(null)

    // Template Requests state
    const [templateRequests, setTemplateRequests] = useState([])
    const [loadingRequests, setLoadingRequests] = useState(false)
    const [requestsError, setRequestsError] = useState(null)


    // Snackbar states
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'info' // 'error', 'warning', 'info', 'success'
    })

    // Snackbar handlers
    const showSnackbar = (message, severity = 'info') => {
        setSnackbar({
            open: true,
            message,
            severity
        })
    }

    const handleCloseSnackbar = () => {
        setSnackbar(prev => ({
            ...prev,
            open: false
        }))
    }

    // Month options
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ]

    // Year options (current year + 5 years)
    const currentYear = new Date().getFullYear()
    const years = Array.from({ length: 6 }, (_, i) => (currentYear + i).toString())

    // Fetch template requests
    const fetchTemplateRequests = async () => {
        try {
            setLoadingRequests(true);
            setRequestsError(null);

            console.log('🔄 Starting to fetch template requests...');

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                    console.log('🔐 Access token found:', accessToken ? 'Yes' : 'No');
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                setRequestsError('No authentication token available');
                console.error('❌ No access token available');
                return;
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            };

            // Always use user-specific API since this page is already secured
            const apiEndpoint = '/api/raise-template-request/get-user-requests';

            console.log('🔍 Fetching template requests from:', apiEndpoint);
            console.log('🔍 Headers:', headers);

            const response = await fetch(apiEndpoint, {
                headers: headers
            });

            console.log('📡 Response status:', response.status);
            console.log('📡 Response ok:', response.ok);

            if (response.ok) {
                const data = await response.json();
                console.log('📊 Template requests data:', data);
                setTemplateRequests(data.requests || []);
                console.log('✅ Template requests loaded:', data.requests?.length || 0);
            } else {
                const errorData = await response.json();
                console.error('❌ Failed to fetch template requests:', errorData);
                setRequestsError(errorData.error || 'Failed to fetch template requests');
            }
        } catch (error) {
            console.error('❌ Error fetching template requests:', error);
            setRequestsError('Error connecting to template requests service');
        } finally {
            setLoadingRequests(false);
        }
    };

    // Fetch invoice details
    const getInvoiceDetails = async () => {
        try {
            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                setInvoiceDetails({
                    error: 'No session or access token available',
                    details: 'Please login again'
                });
                return;
            }

            const url = process.env.NEXT_PUBLIC_SSO_TIMESHEET_INVOICE_DETAIL;

            if (!url) {
                setInvoiceDetails({
                    error: 'Invoice details API URL not configured',
                    details: 'Please check environment variables'
                });
                return;
            }

            console.log('Invoice Details URL:', url);

            // Get today's date in YYYY-MM-DD format
            const today = new Date().toISOString().split('T')[0];
            console.log('Requesting data for date:', today);

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({ date: today })
            });

            if (response.ok) {
                const data = await response.json();
                setInvoiceDetails({ ...data, url, requestDate: today });
                console.log('Invoice Details Response:', data);
            } else {
                const errorText = await response.text();
                console.log('Invoice Details Error response:', errorText);

                // Try with a different date (yesterday) if today fails
                const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                console.log('Trying with yesterday\'s date:', yesterday);

                const retryResponse = await fetch(url, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ date: yesterday })
                });

                if (retryResponse.ok) {
                    const retryData = await retryResponse.json();
                    setInvoiceDetails({ ...retryData, url, requestDate: yesterday });
                    console.log('Invoice Details Response (yesterday):', retryData);
                } else {
                    const retryErrorText = await retryResponse.text();
                    console.log('Invoice Details Retry Error:', retryErrorText);
                    setInvoiceDetails({
                        error: 'Invoice activity data not available',
                        details: 'Unable to fetch invoice activity data for the requested date.'
                    });
                }
            }

        } catch (error) {
            console.error('Error fetching invoice details:', error);
            setInvoiceDetails({
                error: 'Failed to fetch invoice activity',
                details: 'There was an error connecting to the invoice activity service.'
            });
        }
    };

    // Helper function to render structured invoice details
    const renderStructuredInvoiceDetails = (data) => {
        if (!data || data.error) return null;

        // Handle object format with numeric keys (0, 1, 2, etc.)
        const invoiceArray = Array.isArray(data) ? data : Object.values(data).filter(item =>
            typeof item === 'object' && item.invoice_id && item.invoice_name && item.client_name
        );

        if (invoiceArray.length > 0) {
            return (
                <Box>
                    <Box mb={3}>
                        <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                <Typography variant="h4" className='page-heading'>
                                    <Box className="decorator" /> Invoice Activities ({invoiceArray.length} invoices)
                                </Typography>
                                <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                                    (filtered by your invoice activities at API level)
                                </Typography>
                            </Grid>
                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                <Box className="fx_fe">
                                    <Typography variant="caption" color="text.secondary" display="block">
                                        Date: {data.requestDate}
                                    </Typography>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>
                    {/* <Typography variant="subtitle2" color="primary" gutterBottom>
                        Invoice Activities ({invoiceArray.length} invoices)
                        {data.requestDate && (
                            <Typography variant="caption" color="text.secondary" display="block">
                                Date: {data.requestDate}
                            </Typography>
                        )}
                    </Typography> */}
                    <Grid container spacing={1} justifyContent="space-between" alignItems="center">
                        {invoiceArray.map((invoice, index) => (
                            <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }} key={invoice.invoice_id || index}>
                                <Box sx={{ mb: 1, p: 1.5, bgcolor: '#ffffff', borderRadius: 1 }}>
                                    <Typography variant="body2" color="text.secondary">
                                        <strong>Invoice ID:</strong> {invoice.invoice_id || 'N/A'}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        <strong>Client:</strong> {invoice.client_name || 'N/A'}
                                    </Typography>
                                </Box>
                            </Grid>
                        ))}
                    </Grid>
                </Box>
            );
        }

        return (
            <Typography variant="body2" color="text.secondary">
                No structured invoice data available
            </Typography>
        );
    };

    // Function to fetch available templates and existing documents
    const fetchAvailableTemplates = async () => {
        try {
            setLoadingTemplates(true);
            console.log('Fetching available templates and existing documents...');

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            // Fetch existing documents for this template
            let existingDocs = [];
            if (selectedTemplate && selectedTemplate.ID) {
                try {
                    const docsResponse = await fetch(`/api/client-mis-documents?templateId=${selectedTemplate.ID}`, {
                        headers: headers
                    });

                    if (docsResponse.ok) {
                        const docsData = await docsResponse.json();
                        existingDocs = docsData.documents || [];
                        console.log('Existing documents for template:', existingDocs);
                    }
                } catch (error) {
                    console.error('Error fetching existing documents:', error);
                }
            }

            // Build template options based on existing documents
            const templates = [
                {
                    id: 'default',
                    MIS_DOCUMENT_NAME: 'Default Basic Template',
                    HTML_TEMPLATE: null, // Will use generateHTML() for default
                    CREATED_AT: new Date().toISOString(),
                    type: 'default'
                }
            ];

            // Add existing documents as options (if any exist)
            if (existingDocs.length > 0) {
                const existingDocOptions = existingDocs.map(doc => ({
                    id: doc.ID,
                    MIS_DOCUMENT_NAME: `${doc.MIS_DOCUMENT_NAME} (Existing Document)`,
                    HTML_TEMPLATE: doc.HTML_TEMPLATE,
                    CREATED_AT: doc.CREATED_AT,
                    BANNER_URL: doc.BANNER_URL,
                    THEME_COLORS: doc.THEME_COLORS,
                    DYNAMIC_ELEMENTS: doc.DYNAMIC_ELEMENTS,
                    GENERATED_INFOGRAPHICS: doc.GENERATED_INFOGRAPHICS, // Include infographics data
                    type: 'existing_document',
                    originalDocument: doc
                }));
                templates.push(...existingDocOptions);
                console.log('Added existing documents as template options:', existingDocOptions.length);
            }

            setAvailableTemplates(templates);
            console.log('Available templates and documents loaded:', templates);
        } catch (error) {
            console.error('Error fetching templates:', error);
        } finally {
            setLoadingTemplates(false);
        }
    };

    // Default HTML template
    const getDefaultHtmlTemplate = (title, date, bannerUrl, dynamicContent) => {
        return `<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>${title}</title>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" style="font-family: calibri; background-color:#ffffff; ">
    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#f2f2f2">
        <tbody>
            <tr>
                <td>
                    <!-- Main TD -->
                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tbody>
                            <!-- Main MIS Content Here -->
                            ${dynamicContent}
                            <!-- Main MIS Content Here -->
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>`;
    };

    // Function to handle template selection
    const handleHtmlTemplateSelect = async (template) => {
        if (!template) return;

        console.log('HTML Template selected:', template);

        if (template.id === 'default') {
            // Default template doesn't need to fetch HTML content
            setSelectedHtmlTemplate(template);
        } else if (template.type === 'existing_document') {
            // Handle existing document selection
            try {
                // Parse THEME_COLORS if it's a string (from CLOB)
                let themeColors = [];
                if (template.THEME_COLORS) {
                    if (Array.isArray(template.THEME_COLORS)) {
                        themeColors = template.THEME_COLORS;
                    } else if (typeof template.THEME_COLORS === 'string') {
                        try {
                            themeColors = JSON.parse(template.THEME_COLORS);
                        } catch (e) {
                            console.warn('Failed to parse THEME_COLORS as JSON:', template.THEME_COLORS);
                            themeColors = [];
                        }
                    }
                }

                // Parse DYNAMIC_ELEMENTS if it's a string (from CLOB)
                let dynamicElements = [];
                if (template.DYNAMIC_ELEMENTS) {
                    if (Array.isArray(template.DYNAMIC_ELEMENTS)) {
                        dynamicElements = template.DYNAMIC_ELEMENTS;
                    } else if (typeof template.DYNAMIC_ELEMENTS === 'string') {
                        try {
                            dynamicElements = JSON.parse(template.DYNAMIC_ELEMENTS);
                        } catch (e) {
                            console.warn('Failed to parse DYNAMIC_ELEMENTS as JSON:', template.DYNAMIC_ELEMENTS);
                            dynamicElements = [];
                        }
                    }
                }

                // Parse GENERATED_INFOGRAPHICS if it's a string (from CLOB)
                let generatedInfographics = [];
                if (template.GENERATED_INFOGRAPHICS) {
                    if (Array.isArray(template.GENERATED_INFOGRAPHICS)) {
                        generatedInfographics = template.GENERATED_INFOGRAPHICS;
                    } else if (typeof template.GENERATED_INFOGRAPHICS === 'string') {
                        try {
                            generatedInfographics = JSON.parse(template.GENERATED_INFOGRAPHICS);
                        } catch (e) {
                            console.warn('Failed to parse GENERATED_INFOGRAPHICS as JSON:', template.GENERATED_INFOGRAPHICS);
                            generatedInfographics = [];
                        }
                    }
                }

                const templateWithContent = {
                    ...template,
                    HTML_TEMPLATE: template.HTML_TEMPLATE,
                    BANNER_URL: template.BANNER_URL,
                    THEME_COLORS: themeColors,
                    DYNAMIC_ELEMENTS: dynamicElements,
                    GENERATED_INFOGRAPHICS: generatedInfographics
                };
                setSelectedHtmlTemplate(templateWithContent);
                console.log('HTML content loaded from existing document:', template.MIS_DOCUMENT_NAME);
                console.log('Banner URL:', template.BANNER_URL);
                console.log('Theme Colors:', themeColors);
                console.log('Dynamic Elements:', dynamicElements);
                console.log('Generated Infographics:', generatedInfographics);
            } catch (error) {
                console.error('Error processing existing document content:', error);
                showSnackbar('Error processing existing document content', 'error');
            }
        } else {
            // Handle template selection (from client-mis-templates)
            try {
                // Parse THEME_COLORS if it's a string (from CLOB)
                let themeColors = [];
                if (template.THEME_COLORS) {
                    if (Array.isArray(template.THEME_COLORS)) {
                        themeColors = template.THEME_COLORS;
                    } else if (typeof template.THEME_COLORS === 'string') {
                        try {
                            themeColors = JSON.parse(template.THEME_COLORS);
                        } catch (e) {
                            console.warn('Failed to parse THEME_COLORS as JSON:', template.THEME_COLORS);
                            themeColors = [];
                        }
                    }
                }

                const templateWithContent = {
                    ...template,
                    HTML_TEMPLATE: template.HTML_TEMPLATE || template.TEMPLATE_DATA,
                    BANNER_URL: template.BANNER_URL,
                    THEME_COLORS: themeColors,
                    DYNAMIC_ELEMENTS: [] // Default empty array for dynamic elements
                };
                setSelectedHtmlTemplate(templateWithContent);
                console.log('HTML content loaded for template:', template.MIS_DOCUMENT_NAME);
                console.log('Banner URL:', template.BANNER_URL);
                console.log('Theme Colors:', themeColors);
            } catch (error) {
                console.error('Error processing template content:', error);
                showSnackbar('Error processing template content', 'error');
            }
        }
    };

    // Fetch templates when dialog opens or selected template changes
    React.useEffect(() => {
        if (dialogOpen) {
            fetchAvailableTemplates();
        }
    }, [dialogOpen, selectedTemplate]);

    // Fetch data from API
    React.useEffect(() => {
        const fetchData = async () => {
            try {
                setLoadingData(true);

                console.log('🔄 Starting to fetch main data...');
                console.log('👤 Employee details:', employeeDetails);
                console.log('👤 User role:', userRole);

                // Get authentication token from localStorage
                const session = localStorage.getItem('session');
                let accessToken = '';

                if (session) {
                    try {
                        const sessionData = JSON.parse(session);
                        accessToken = sessionData.accessToken || '';
                    } catch (parseError) {
                        console.error('Error parsing session data:', parseError);
                    }
                }

                const headers = {
                    'Content-Type': 'application/json'
                };

                // Add Authorization header if we have a token
                if (accessToken) {
                    headers['Authorization'] = `Bearer ${accessToken}`;
                }

                // Only fetch clients if user is admin
                if (employeeDetails?.userRole === 'admin') {
                    const clientsResponse = await fetch('/api/clients?simple=true', {
                        credentials: 'include'
                    });

                    if (clientsResponse.ok) {
                        const clientsData = await clientsResponse.json();
                        console.log('Clients data received:', clientsData);
                        setClients(clientsData.clients || []);
                    } else {
                        console.error('Failed to fetch clients:', clientsResponse.status);
                    }
                }

                // Fetch templates from invoice-based API for better security and performance
                console.log('🔍 Fetching templates from invoice-based API...');
                const templatesResponse = await fetch('/api/client-mis-templates/invoice-based', {
                    headers: headers
                });

                console.log('📡 Templates response status:', templatesResponse.status);
                console.log('📡 Templates response ok:', templatesResponse.ok);

                if (templatesResponse.ok) {
                    const templatesData = await templatesResponse.json();
                    console.log('Templates data received:', templatesData);
                    console.log('Number of templates:', templatesData.templates?.length || 0);

                    // Process templates from CLIENT_MIS_TEMPLATES table
                    console.log('=== PROCESSING ALL TEMPLATES FROM CLIENT_MIS_TEMPLATES ===');
                    console.log('Total templates received:', templatesData.templates?.length || 0);

                    const allTemplates = (templatesData.templates || []).map((template, index) => {
                        console.log(`=== FRONTEND PROCESSING TEMPLATE ${index + 1}/${templatesData.templates?.length} ===`);
                        console.log('Template ID:', template.ID);
                        console.log('Template name:', template.TEMPLATE_NAME);
                        console.log('Template client:', template.SSO_CLIENT_NAME);
                        console.log('Template BANNER_URL:', template.BANNER_URL);
                        console.log('Template THEME_COLORS:', template.THEME_COLORS);
                        console.log('Template THEME_COLORS type:', typeof template.THEME_COLORS);
                        console.log('Template THEME_COLORS length:', template.THEME_COLORS?.length);
                        console.log('Template THEME_COLORS is array:', Array.isArray(template.THEME_COLORS));
                        console.log('Template THEME_COLORS keys:', Object.keys(template.THEME_COLORS || {}));
                        console.log('Template THEME_COLORS stringified:', JSON.stringify(template.THEME_COLORS));
                        console.log('Template THEME_COLORS first color:', template.THEME_COLORS?.[0]);
                        console.log('Will show banner:', !!template.BANNER_URL);
                        console.log('Will show theme colors:', !!(template.THEME_COLORS && template.THEME_COLORS.length > 0));
                        console.log('Theme colors condition:', template.THEME_COLORS && template.THEME_COLORS.length > 0);
                        console.log('=====================================');

                        return {
                            ...template,
                            CLIENT_ID: template.SSO_CLIENT_ID,
                            CLIENT_NAME: template.SSO_CLIENT_NAME,
                            BANNER_URL: template.BANNER_URL
                        };
                    });

                    console.log('All processed templates:', allTemplates);
                    console.log('Total templates found:', allTemplates.length);

                    // Log each template's final data
                    allTemplates.forEach((template, index) => {
                        console.log(`Final template ${index + 1}:`, {
                            ID: template.ID,
                            NAME: template.TEMPLATE_NAME,
                            CLIENT: template.CLIENT_NAME,
                            BANNER_URL: template.BANNER_URL,
                            HAS_THEME_COLORS: !!template.THEME_COLORS,
                            THEME_COLORS_COUNT: template.THEME_COLORS?.length || 0
                        });
                    });

                    setMisTemplates(allTemplates);
                } else {
                    console.error('Failed to fetch templates:', templatesResponse.status);
                    const errorText = await templatesResponse.text();
                    console.error('Error response:', errorText);
                }

            } catch (error) {
                console.error('Error fetching data:', error);
            } finally {
                setLoadingData(false);
            }
        };

        if (employeeDetails) {
            fetchData();
            // Also fetch invoice details and template requests
            getInvoiceDetails();
            fetchTemplateRequests();
        }
    }, [employeeDetails?.userRole]);



    const getTypeColor = (type) => {
        switch (type) {
            case 'Sales': return '#2196F3'
            case 'Financial': return '#4CAF50'
            case 'Analytics': return '#FF9800'
            case 'Operations': return '#9C27B0'
            case 'Marketing': return '#F44336'
            case 'HR': return '#607D8B'
            default: return '#757575'
        }
    }

    // Filter templates based on search query only (API-level filtering is already applied)
    const filteredMIS = misTemplates.filter(report => {
        const matchesSearch = report.TEMPLATE_NAME.toLowerCase().includes(searchQuery.toLowerCase())
        return matchesSearch;
    })

    const handleMISClick = async (template) => {
        setSelectedTemplate(template)
        setDialogOpen(true)

        // Fetch existing documents for this template
        try {
            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch(`/api/client-mis-documents?templateId=${template.ID}`, {
                headers: headers
            })

            if (response.ok) {
                const data = await response.json()
                setExistingDocuments(data.documents || [])
            }
        } catch (error) {
            console.error('Error fetching existing documents:', error)
        }
    }

    const handleDialogClose = () => {
        setDialogOpen(false)
        setSelectedTemplate(null)
        setSelectedMonth('')
        setSelectedYear('')
        setSelectedHtmlTemplate(null)
    }

    const handleCreateMIS = async () => {
        if (!selectedMonth || !selectedYear) {
            showSnackbar('Please select both month and year', 'warning')
            return
        }

        if (!selectedHtmlTemplate) {
            showSnackbar('Please select an HTML template', 'warning')
            return
        }

        setIsCreating(true)

        try {
            // Format the document name with dashes and lowercase
            const monthYear = `${selectedMonth.toLowerCase()}-${selectedYear}`
            const templateName = selectedTemplate.TEMPLATE_NAME.replace(/\s+/g, '-').toLowerCase()
            const misDocumentName = `${templateName}-${monthYear}`

            console.log('Creating MIS document with name:', misDocumentName)
            console.log('Using HTML template:', selectedHtmlTemplate.MIS_DOCUMENT_NAME)

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            // Get the HTML template content and banner URL
            let htmlTemplateContent;
            let bannerUrl;
            let themeColors;

            // Helper function to parse theme colors from CLOB data
            const parseThemeColors = (themeColorsData) => {
                if (!themeColorsData) return [];

                if (typeof themeColorsData === 'string') {
                    try {
                        return JSON.parse(themeColorsData);
                    } catch (e) {
                        console.warn('Failed to parse THEME_COLORS as JSON:', themeColorsData, 'Error:', e.message);
                        return [];
                    }
                } else if (Array.isArray(themeColorsData)) {
                    return themeColorsData;
                } else if (typeof themeColorsData === 'object') {
                    let themeColorsStr = '';
                    if (themeColorsData.type === 'CLOB') {
                        themeColorsStr = themeColorsData.toString();
                    } else if (themeColorsData.toString && themeColorsData.toString() !== '[object Object]') {
                        themeColorsStr = themeColorsData.toString();
                    } else {
                        // Try to get the actual content from the CLOB object
                        themeColorsStr = themeColorsData.chunk || themeColorsData.value || '';
                    }

                    try {
                        return JSON.parse(themeColorsStr);
                    } catch (e) {
                        console.warn('Failed to parse THEME_COLORS object as JSON:', e.message);
                        return [];
                    }
                }
                return [];
            };

            // Get dynamic elements from the selected template
            let dynamicElements = [];
            if (selectedHtmlTemplate.id !== 'default' && selectedHtmlTemplate.DYNAMIC_ELEMENTS) {
                dynamicElements = selectedHtmlTemplate.DYNAMIC_ELEMENTS;
                console.log('📝 Using DYNAMIC_ELEMENTS from selected template:', dynamicElements.length, 'elements');
            } else if (selectedHtmlTemplate.type === 'existing_document' && selectedHtmlTemplate.DYNAMIC_ELEMENTS) {
                dynamicElements = selectedHtmlTemplate.DYNAMIC_ELEMENTS;
                console.log('📝 Using DYNAMIC_ELEMENTS from existing document:', dynamicElements.length, 'elements');
            } else {
                console.log('📝 No DYNAMIC_ELEMENTS to copy (using default template or empty)');
            }

            // Get generated infographics from the existing document
            let generatedInfographics = [];
            if (selectedHtmlTemplate.type === 'existing_document' && selectedHtmlTemplate.GENERATED_INFOGRAPHICS) {
                generatedInfographics = selectedHtmlTemplate.GENERATED_INFOGRAPHICS;
                console.log('📊 Using GENERATED_INFOGRAPHICS from existing document:', generatedInfographics.length, 'infographics');
                console.log('📊 Generated Infographics data:', generatedInfographics);
            } else {
                console.log('📊 No GENERATED_INFOGRAPHICS to copy (using default template or empty)');
            }

            console.log('📄 Final document creation data:', {
                documentName: misDocumentName,
                hasHtmlTemplate: !!htmlTemplateContent,
                hasDynamicElements: dynamicElements.length > 0,
                hasGeneratedInfographics: generatedInfographics.length > 0,
                dynamicElementsCount: dynamicElements.length,
                generatedInfographicsCount: generatedInfographics.length
            });

            if (selectedHtmlTemplate.id === 'default') {
                // Use default HTML template with placeholder values
                const defaultTitle = misDocumentName;
                const defaultDate = `${selectedMonth} ${selectedYear}`;
                const defaultBannerUrl = selectedTemplate.BANNER_URL ?
                    `${process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH}mis-banners/${selectedTemplate.BANNER_URL}` : '';
                const defaultDynamicContent = '<!-- Dynamic Content -->';

                htmlTemplateContent = getDefaultHtmlTemplate(defaultTitle, defaultDate, defaultBannerUrl, defaultDynamicContent);
                bannerUrl = selectedTemplate.BANNER_URL || '';
                themeColors = parseThemeColors(selectedTemplate.THEME_COLORS);
            } else {
                // Use the selected HTML template's content and banner URL
                htmlTemplateContent = selectedHtmlTemplate.HTML_TEMPLATE;
                bannerUrl = selectedHtmlTemplate.BANNER_URL || selectedTemplate.BANNER_URL || '';
                themeColors = parseThemeColors(selectedHtmlTemplate.THEME_COLORS) || parseThemeColors(selectedTemplate.THEME_COLORS);
            }

            // Create the MIS document using the new create-new-mis endpoint
            const requestBody = {
                sso_client_id: selectedTemplate.SSO_CLIENT_ID,
                sso_client_name: selectedTemplate.SSO_CLIENT_NAME,
                template_id: selectedTemplate.ID,
                template_name: selectedTemplate.TEMPLATE_NAME,
                user_id: employeeDetails?.employee_code || '',
                mis_document_name: misDocumentName,
                html_template: htmlTemplateContent,
                status: 'Draft',
                banner_url: bannerUrl,
                theme_colors: themeColors,
                dynamic_elements: dynamicElements,
                generated_infographics: generatedInfographics,
                created_by: employeeDetails?.full_name || 'Unknown User',
                created_by_email: employeeDetails?.email || '',
                created_by_role: userRole === 'admin' ? 'Admin' : 'User'
            };

            console.log('📤 Sending document creation request:', {
                documentName: misDocumentName,
                hasHtmlTemplate: !!htmlTemplateContent,
                hasDynamicElements: dynamicElements.length > 0,
                hasGeneratedInfographics: generatedInfographics.length > 0,
                dynamicElementsCount: dynamicElements.length,
                generatedInfographicsCount: generatedInfographics.length,
                generatedInfographicsData: generatedInfographics
            });

            const response = await fetch('/api/create-new-mis', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(requestBody)
            })

            if (!response.ok) {
                const errorData = await response.json()

                // Handle duplicate document error specifically
                if (errorData.code === 'DUPLICATE_DOCUMENT') {
                    showSnackbar(errorData.error || 'A document for this template and period already exists. Please choose a different month/year.', 'error')
                    return
                }

                throw new Error(errorData.error || 'Failed to create MIS document')
            }

            const result = await response.json()
            console.log('MIS document created successfully:', result)

            // Use the document name for navigation (dash-separated format)
            const urlPath = `mis/${misDocumentName}`

            console.log('Redirecting to:', urlPath)
            router.push(urlPath)
            handleDialogClose()

        } catch (error) {
            console.error('Error creating MIS document:', error)
            showSnackbar(`Failed to create MIS document: ${error.message}`, 'error')
        } finally {
            setIsCreating(false)
        }
    }

    // Helper function to check if a month/year combination already exists
    const checkMonthYearExists = (month, year) => {
        if (!month || !year || !existingDocuments.length) return false

        const monthYear = `${month.toLowerCase()}-${year}`
        return existingDocuments.some(doc =>
            doc.MIS_DOCUMENT_NAME.toLowerCase().includes(monthYear)
        )
    }

    // Check if current selection already exists
    const currentMonthYearExists = checkMonthYearExists(selectedMonth, selectedYear)

    // If not authenticated, show message
    if (!employeeDetails) {
        return (
            <Container maxWidth>
                <Box pt={8} px={3} display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                    <Typography>Please sign in to access the MIS Templates.</Typography>
                </Box>
            </Container>
        )
    }

    console.log('✅ Authenticated - showing templates');

    return (
        <Container maxWidth>
            {/* Header Section */}
            <Box mb={4}>
                <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Typography variant="h4" className='page-heading'>
                            <Box className="decorator" /> My Invoice ID-Based MIS Templates
                        </Typography>
                        <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                            {filteredMIS.length} templates found
                            <span style={{ fontSize: '0.875rem', color: '#666' }}>
                                {' '}(filtered by your invoice activities at API level)
                            </span>
                        </Typography>
                    </Grid>
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Box display="flex" justifyContent="flex-end" gap={2}>

                            <TemplateRequest
                                invoiceDetails={invoiceDetails}
                                onRequestSuccess={fetchTemplateRequests}
                                availableTemplates={misTemplates}
                                existingRequests={templateRequests}
                            />

                            {/* Search Field */}
                            <Box className="textfield ph2 auto-complete" sx={{ minWidth: 300 }}>
                                <TextField
                                    fullWidth
                                    size="small"
                                    placeholder="Search templates by Name..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    InputProps={{
                                        startAdornment: (
                                            <InputAdornment position="start">
                                                <Search />
                                            </InputAdornment>
                                        ),
                                        endAdornment: searchQuery && (
                                            <InputAdornment position="end">
                                                <IconButton
                                                    size="small"
                                                    onClick={() => setSearchQuery('')}
                                                    edge="end"
                                                >
                                                    <Box component="span" sx={{ fontSize: '1rem' }}>×</Box>
                                                </IconButton>
                                            </InputAdornment>
                                        )
                                    }}
                                />
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Box>

            {/* MIS Reports Grid */}
            {(employeeDetails?.userRole === 'admin' ? selectedClient : true) && (
                <Box>
                    {loadingData ? (
                        <ClientsAndTemplatesSkeleton />
                    ) : filteredMIS.length === 0 ? (
                        <Card sx={{ p: 4, textAlign: 'center' }}>
                            <Description sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                            <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                                {employeeDetails?.userRole === 'admin' ? 'No MIS reports found' : 'No templates assigned to you'}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                {employeeDetails?.userRole === 'admin'
                                    ? (searchQuery || filterStatus !== 'all'
                                        ? 'Try adjusting your search or filter criteria'
                                        : 'Create your first MIS report for this client')
                                    : 'Contact your administrator to get assigned to MIS templates'
                                }
                            </Typography>
                        </Card>
                    ) : (
                        <Grid container spacing={3}>
                            {filteredMIS.map((report, index) => {

                                return (
                                    <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }} key={report.ID}>
                                        <Card
                                            sx={{
                                                height: '100%',
                                                cursor: 'pointer',
                                                transition: 'all 0.3s ease',
                                                '&:hover': {
                                                    transform: 'translateY(-4px)',
                                                    boxShadow: '0 8px 25px rgba(0,0,0,0.15)'
                                                }
                                            }}
                                            onClick={() => handleMISClick(report)}
                                        >
                                            {/* Banner Image */}
                                            {report.BANNER_URL && (
                                                <Box
                                                    sx={{
                                                        height: 160,
                                                        backgroundImage: `url(${process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH}mis-banners/${report.BANNER_URL})`,
                                                        backgroundSize: 'contain',
                                                        backgroundRepeat: 'no-repeat',
                                                        backgroundPosition: 'center',
                                                        borderRadius: '8px 8px 0 0',
                                                        position: 'relative',
                                                        backgroundColor: '#f2f2f2'
                                                    }}
                                                    title={`Banner URL: (${process.env.NEXT_PUBLIC_OCI_GET_FILE_PATH}mis-banners/${report.BANNER_URL})`}
                                                />
                                            )}

                                            {report.BANNER_URL && console.log('Using banner URL for display:', report.BANNER_URL)}

                                            <CardContent sx={{ p: 3 }}>
                                                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                                                    <Avatar sx={{ mr: 2, bgcolor: getTypeColor('Sales') }}>
                                                        <Description />
                                                    </Avatar>
                                                    <Box>
                                                        <Typography variant="h6" sx={{ fontWeight: 600, color: '#1a1a1a' }}>
                                                            {report.TEMPLATE_NAME}
                                                        </Typography>
                                                        <Typography variant="body2" color="text.secondary">
                                                            {report.SSO_CLIENT_NAME}
                                                        </Typography>
                                                        <Typography variant="body2" color="text.secondary">
                                                            {report.SSO_CLIENT_ID}
                                                        </Typography>
                                                    </Box>
                                                </Box>

                                                {/* Theme Colors Display */}
                                                {(() => {
                                                    // Handle CLOB data and different formats for theme colors
                                                    let themeColorsArray = [];

                                                    if (report.THEME_COLORS) {
                                                        if (typeof report.THEME_COLORS === 'string') {
                                                            // Handle CLOB data converted to string
                                                            try {
                                                                themeColorsArray = JSON.parse(report.THEME_COLORS);
                                                            } catch (e) {
                                                                console.warn('Failed to parse THEME_COLORS as JSON:', report.THEME_COLORS, 'Error:', e.message);
                                                                themeColorsArray = [];
                                                            }
                                                        } else if (Array.isArray(report.THEME_COLORS)) {
                                                            // If it's already an array, use it directly
                                                            themeColorsArray = report.THEME_COLORS;
                                                        } else if (typeof report.THEME_COLORS === 'object') {
                                                            // Handle CLOB object
                                                            let themeColorsStr = '';
                                                            if (report.THEME_COLORS.type === 'CLOB') {
                                                                themeColorsStr = report.THEME_COLORS.toString();
                                                            } else if (report.THEME_COLORS.toString && report.THEME_COLORS.toString() !== '[object Object]') {
                                                                themeColorsStr = report.THEME_COLORS.toString();
                                                            } else {
                                                                // Try to get the actual content from the CLOB object
                                                                themeColorsStr = report.THEME_COLORS.chunk || report.THEME_COLORS.value || '';
                                                            }

                                                            try {
                                                                themeColorsArray = JSON.parse(themeColorsStr);
                                                            } catch (e) {
                                                                console.warn('Failed to parse THEME_COLORS object as JSON:', e.message);
                                                                themeColorsArray = [];
                                                            }
                                                        }
                                                    }

                                                    console.log('Processed theme colors array:', themeColorsArray);
                                                    console.log('Theme colors array length:', themeColorsArray.length);

                                                    return themeColorsArray.length > 0 ? (
                                                        <Box sx={{ mb: 2 }}>
                                                            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                                                Theme Colors ({themeColorsArray.length} colors):
                                                            </Typography>
                                                            <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                                                                {themeColorsArray.map((color, index) => (
                                                                    <Box
                                                                        key={index}
                                                                        sx={{
                                                                            width: 20,
                                                                            height: 20,
                                                                            borderRadius: '50%',
                                                                            backgroundColor: color,
                                                                            border: '1px solid #e0e0e0',
                                                                            cursor: 'pointer',
                                                                            '&:hover': {
                                                                                transform: 'scale(1.1)',
                                                                                boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
                                                                            }
                                                                        }}
                                                                        title={`${color} (${index + 1}/${themeColorsArray.length})`}
                                                                    />
                                                                ))}
                                                            </Box>
                                                        </Box>
                                                    ) : (
                                                        <Box sx={{ mb: 2 }}>
                                                            <Typography variant="caption" color="text.secondary">
                                                                No theme colors available
                                                            </Typography>
                                                        </Box>
                                                    );
                                                })()}

                                                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                        <CalendarToday sx={{ fontSize: 16, color: 'text.secondary', mr: 1 }} />
                                                        <Typography variant="caption" color="text.secondary">
                                                            {new Date(report.CREATED_AT).toLocaleDateString()}
                                                        </Typography>
                                                    </Box>
                                                    <IconButton size="small" sx={{ color: 'primary.main' }}>
                                                        <ArrowForward />
                                                    </IconButton>
                                                </Box>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                );
                            })}
                        </Grid>
                    )}
                </Box>
            )}

            <Box py={6}>
                <Divider />
            </Box>

            {/* Template Requests Section */}
            <Box mt={0} mb={0}>
                <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Typography variant="h4" className='page-heading'>
                            <Box className="decorator" /> My Template Requests
                        </Typography>
                        <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                            (filtered by your invoice activities at API level)
                        </Typography>
                    </Grid>
                    <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                        <Box className="fx_fe">
                            <Button
                                variant="outlined"
                                size="small"
                                className='main-btn btn-secondary'
                                onClick={fetchTemplateRequests}
                                disabled={loadingRequests}
                                startIcon={loadingRequests ? <CircularProgress size={16} /> : null}
                            >
                                Refresh
                            </Button>
                        </Box>
                    </Grid>
                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                        <Box>
                            {loadingRequests ? (
                                <Box display="flex" justifyContent="center" alignItems="center" py={2}>
                                    <CircularProgress size={24} />
                                    <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                                        Loading your template requests...
                                    </Typography>
                                </Box>
                            ) : requestsError ? (
                                <Box>
                                    <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                                        {requestsError}
                                    </Alert>
                                </Box>
                            ) : templateRequests.length === 0 ? (
                                <Box textAlign="center" py={3}>
                                    <Typography variant="body2" color="text.secondary">
                                        You haven't raised any template requests yet.
                                    </Typography>
                                    <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                                        Use the "Raise New Request" button above to create your first template request.
                                    </Typography>
                                </Box>
                            ) : (
                                <Box>
                                    <Grid container spacing={2}>
                                        {templateRequests.map((request, index) => (
                                            <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }} key={request.ID || index}>
                                                <Card sx={{
                                                    height: '100%',
                                                    border: '1px solid #e0e0e0',
                                                    '&:hover': {
                                                        boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                                    }
                                                }}>
                                                    <CardContent sx={{ p: 2 }}>
                                                        <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
                                                            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                                                {request.MIS_REQ_CLIENT_NAME}
                                                            </Typography>
                                                            <Chip
                                                                label={request.STATUS.replace('_', ' ').toUpperCase()}
                                                                size="small"
                                                                color={
                                                                    request.STATUS === 'approved' ? 'success' :
                                                                        request.STATUS === 'rejected' ? 'error' :
                                                                            request.STATUS === 'in_progress' ? 'warning' :
                                                                                request.STATUS === 'completed' ? 'primary' : 'default'
                                                                }
                                                                variant="outlined"
                                                            />
                                                        </Box>

                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                            <strong>Invoice ID:</strong> {request.MIS_REQ_INVOICE_ID}
                                                        </Typography>

                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                            <strong>Requestor:</strong> {request.REQUESTOR_NAME} ({request.EMPLOYEE_CODE})
                                                        </Typography>

                                                        {request.REQUEST_COMMENT && (
                                                            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                                <strong>Comment:</strong> {request.REQUEST_COMMENT}
                                                            </Typography>
                                                        )}

                                                        {request.ADMIN_COMMENT && (
                                                            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                                <strong>Admin Comment:</strong> {request.ADMIN_COMMENT}
                                                            </Typography>
                                                        )}

                                                        <Typography variant="caption" color="text.secondary">
                                                            Created: {new Date(request.CREATED_AT).toLocaleDateString()}
                                                            {request.ADMIN_UPDATED_AT && (
                                                                <span> | Updated: {new Date(request.ADMIN_UPDATED_AT).toLocaleDateString()}</span>
                                                            )}
                                                        </Typography>
                                                    </CardContent>
                                                </Card>
                                            </Grid>
                                        ))}
                                    </Grid>
                                </Box>
                            )}
                        </Box>
                    </Grid>
                </Grid>
            </Box>

            <Box py={6}>
                <Divider />
            </Box>

            {/* Invoice Activity Details Section */}
            <Box mb={4}>
                {invoiceDetails ? (
                    invoiceDetails.error ? (
                        <Box>
                            <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                                {invoiceDetails.error}
                            </Alert>
                            {invoiceDetails.details && (
                                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                    {invoiceDetails.details}
                                </Typography>
                            )}
                        </Box>
                    ) : (
                        renderStructuredInvoiceDetails(invoiceDetails)
                    )
                ) : (
                    <Box display="flex" justifyContent="center" alignItems="center" py={2}>
                        <CircularProgress size={24} />
                        <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                            Loading invoice activity details...
                        </Typography>
                    </Box>
                )}
            </Box>



            {/* Create MIS Dialog */}
            <Dialog
                open={dialogOpen}
                onClose={handleDialogClose}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle className='custom-dialog-title' sx={{ pb: 1 }}>
                    Create MIS Report
                </DialogTitle>
                <DialogContent sx={{ pt: 2 }}>
                    {selectedTemplate && (
                        <Box mt={3}>
                            {/* Template Details */}
                            <Box sx={{ mb: 3, p: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
                                <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                                    Template Details
                                </Typography>
                                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                    <Description sx={{ mr: 1, color: 'primary.main' }} />
                                    <Typography variant="body1">
                                        <strong>Template:</strong> {selectedTemplate.TEMPLATE_NAME}
                                    </Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Business sx={{ mr: 1, color: 'primary.main' }} />
                                    <Typography variant="body1">
                                        <strong>Client:</strong> {selectedTemplate.SSO_CLIENT_NAME}
                                    </Typography>
                                </Box>
                            </Box>

                            {/* Month and Year Selection */}
                            <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
                                Creating for the Month of
                            </Typography>

                            <Grid container spacing={2}>
                                <Grid size={{ xs: 6 }}>
                                    <Box className="textfield auto-complete">
                                        <FormControl fullWidth>
                                            {/* <InputLabel>Month</InputLabel> */}
                                            <Autocomplete
                                                value={selectedMonth}
                                                onChange={(e, newValue) => setSelectedMonth(newValue)}
                                                options={months}
                                                renderInput={(params) => (
                                                    <TextField {...params} label="Month" />
                                                )}
                                            />
                                        </FormControl>
                                    </Box>
                                </Grid>
                                <Grid size={{ xs: 6 }}>
                                    <Box className="textfield auto-complete">
                                        <FormControl fullWidth>
                                            {/* <InputLabel>Year</InputLabel> */}
                                            <Autocomplete
                                                value={selectedYear}
                                                onChange={(e, newValue) => setSelectedYear(newValue)}
                                                options={years}
                                                renderInput={(params) => (
                                                    <TextField {...params} label="Year" />
                                                )}
                                            />
                                        </FormControl>
                                    </Box>
                                </Grid>
                                <Grid size={{ xs: 12 }}>
                                    <Box className="textfield auto-complete">
                                        <FormControl fullWidth>
                                            {/* <InputLabel>HTML Template</InputLabel> */}
                                            <Autocomplete
                                                value={selectedHtmlTemplate}
                                                onChange={(e, newValue) => handleHtmlTemplateSelect(newValue)}
                                                options={availableTemplates}
                                                loading={loadingTemplates}
                                                getOptionLabel={(option) => option.MIS_DOCUMENT_NAME || ''}
                                                isOptionEqualToValue={(option, value) => option.id === value.id}
                                                renderInput={(params) => (
                                                    <TextField
                                                        {...params}
                                                        label="HTML Template"
                                                        placeholder="Select a template or use Default Basic Template"
                                                    />
                                                )}
                                                renderOption={(props, option) => {
                                                    const { key, ...otherProps } = props;
                                                    return (
                                                        <Box component="li" key={key} {...otherProps}>
                                                            <Box>
                                                                <Typography variant="body2">
                                                                    {option.MIS_DOCUMENT_NAME}
                                                                </Typography>
                                                                {option.id !== 'default' && (
                                                                    <Typography variant="caption" color="text.secondary">
                                                                        {option.type === 'existing_document' ? 'Existing Document' : 'Template'} - Created: {new Date(option.CREATED_AT).toLocaleDateString()}
                                                                    </Typography>
                                                                )}
                                                            </Box>
                                                        </Box>
                                                    );
                                                }}
                                            />
                                        </FormControl>
                                    </Box>
                                </Grid>
                            </Grid>

                            {/* Template Selection Preview */}
                            {selectedHtmlTemplate && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#f3e5f5', borderRadius: 1 }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                        Selected HTML Template:
                                    </Typography>
                                    <Typography variant="body2" sx={{ color: '#7b1fa2' }}>
                                        {selectedHtmlTemplate.MIS_DOCUMENT_NAME}
                                        {selectedHtmlTemplate.id !== 'default' && (
                                            <span style={{ color: '#9e9e9e', fontSize: '0.75rem' }}>
                                                {' '}({selectedHtmlTemplate.type === 'existing_document' ? 'Existing Document' : 'Template'} - Created: {new Date(selectedHtmlTemplate.CREATED_AT).toLocaleDateString()})
                                            </span>
                                        )}
                                    </Typography>
                                    {selectedHtmlTemplate.type === 'existing_document' && (
                                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1, fontStyle: 'italic' }}>
                                            This will copy the HTML template, banner, theme colors, and dynamic elements from the existing document.
                                        </Typography>
                                    )}
                                </Box>
                            )}

                            {/* Preview URL */}
                            {selectedMonth && selectedYear && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#e3f2fd', borderRadius: 1 }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                                        Generated URL:
                                    </Typography>
                                    <Typography variant="body2" sx={{ fontFamily: 'monospace', color: '#1976d2' }}>
                                        /mis/{selectedTemplate.TEMPLATE_NAME.replace(/\s+/g, '-').toLowerCase()}-{selectedMonth.toLowerCase()}-{selectedYear}
                                    </Typography>
                                </Box>
                            )}

                            {/* Specific Month/Year Warning */}
                            {currentMonthYearExists && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#ffebee', borderRadius: 1, border: '1px solid #f44336' }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, fontWeight: 600, color: '#d32f2f' }}>
                                        ❌ Document Already Exists:
                                    </Typography>
                                    <Typography variant="body2" sx={{ fontSize: '0.75rem', color: '#d32f2f' }}>
                                        A document for {selectedMonth} {selectedYear} already exists for this template. Please choose a different month/year.
                                    </Typography>
                                </Box>
                            )}

                            {/* Existing Documents Warning */}
                            {existingDocuments.length > 0 && (
                                <Box sx={{ mt: 2, p: 2, bgcolor: '#fff3e0', borderRadius: 1, border: '1px solid #ff9800' }}>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, fontWeight: 600 }}>
                                        ⚠️ Existing Documents for this Template:
                                    </Typography>
                                    <Box sx={{ maxHeight: 100, overflowY: 'auto' }}>
                                        {existingDocuments.map((doc, index) => (
                                            <Typography key={index} variant="body2" sx={{ fontSize: '0.75rem', color: '#e65100' }}>
                                                • {doc.MIS_DOCUMENT_NAME} ({doc.STATUS}) - {new Date(doc.CREATED_AT).toLocaleDateString()}
                                            </Typography>
                                        ))}
                                    </Box>
                                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1, fontStyle: 'italic' }}>
                                        You can create multiple documents for different months, but only one document per month/year for this template.
                                    </Typography>
                                </Box>
                            )}
                        </Box>
                    )}
                </DialogContent>
                <DialogActions className='custom-dialog-action'>
                    <Button onClick={handleDialogClose} color="inherit" disabled={isCreating} className='main-btn btn-tertiary'>
                        Cancel
                    </Button>
                    <Button
                        onClick={handleCreateMIS}
                        variant="contained"
                        className="main-btn btn-primary"
                        disabled={!selectedMonth || !selectedYear || !selectedHtmlTemplate || isCreating || currentMonthYearExists}
                    >
                        {isCreating ? 'Creating...' : 'Create MIS Report'}
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Snackbar for notifications */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Container>
    )
}

export default ClientsAndTemplates