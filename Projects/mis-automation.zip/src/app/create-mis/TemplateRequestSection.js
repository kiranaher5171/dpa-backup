'use client'
import React, { useState, useEffect } from 'react'
import {
    Card,
    CardContent,
    Typography,
    Grid,
    Box,
    Button,
    Chip,
    CircularProgress,
    Alert,
    Autocomplete,
    TextField
} from '@mui/material'
import TemplateRequest from './TemplateRequest'

const TemplateRequestSection = ({ invoiceDetails, availableTemplates, refreshTrigger = 0, onRequestsLoaded }) => {
    // Template Requests state
    const [templateRequests, setTemplateRequests] = useState([])
    const [loadingRequests, setLoadingRequests] = useState(false)
    const [requestsError, setRequestsError] = useState(null)

    // Filter state
    const [selectedFilter, setSelectedFilter] = useState('All')

    // Filter options
    const filterOptions = [
        'All',
        'Open',
        'In Progress',
        'Approved',
        'Rejected',
        'Completed'
    ]

    // Fetch template requests
    const fetchTemplateRequests = async () => {
        try {
            setLoadingRequests(true);
            setRequestsError(null);

            console.log('🔄 Starting to fetch template requests...');

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                    console.log('🔐 Access token found:', accessToken ? 'Yes' : 'No');
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                setRequestsError('No authentication token available');
                console.error('❌ No access token available');
                return;
            }

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            };

            // Always use user-specific API since this page is already secured
            const apiEndpoint = '/api/raise-template-request/get-user-requests';

            console.log('🔍 Fetching template requests from:', apiEndpoint);
            console.log('🔍 Headers:', headers);

            const response = await fetch(apiEndpoint, {
                headers: headers
            });

            console.log('📡 Response status:', response.status);
            console.log('📡 Response ok:', response.ok);

            if (response.ok) {
                const data = await response.json();
                console.log('📊 Template requests data:', data);
                const requests = data.requests || [];
                setTemplateRequests(requests);
                console.log('✅ Template requests loaded:', requests.length);
                
                // Notify parent component about loaded requests
                if (onRequestsLoaded && typeof onRequestsLoaded === 'function') {
                    onRequestsLoaded(requests);
                }
            } else {
                const errorData = await response.json();
                console.error('❌ Failed to fetch template requests:', errorData);
                setRequestsError(errorData.error || 'Failed to fetch template requests');
            }
        } catch (error) {
            console.error('❌ Error fetching template requests:', error);
            setRequestsError('Error connecting to template requests service');
        } finally {
            setLoadingRequests(false);
        }
    };

    // Filter requests based on selected filter
    const getFilteredRequests = () => {
        if (selectedFilter === 'All') {
            return templateRequests;
        }
        
        return templateRequests.filter(request => {
            const status = request.STATUS?.toLowerCase() || '';
            
            switch (selectedFilter) {
                case 'Open':
                    return status === 'open' || status === 'pending';
                case 'In Progress':
                    return status === 'in_progress' || status === 'in progress';
                case 'Approved':
                    return status === 'approved';
                case 'Rejected':
                    return status === 'rejected';
                case 'Completed':
                    return status === 'completed';
                default:
                    return true;
            }
        });
    };

    // Fetch template requests on component mount and when refreshTrigger changes
    useEffect(() => {
        fetchTemplateRequests();
    }, [refreshTrigger]);

    return (
        <Box mt={0} mb={3}>
            <Grid container spacing={3} justifyContent="space-between" alignItems="center">
                <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                    <Typography variant="h4" className='page-heading'>
                        <Box className="decorator" /> My Template Requests
                    </Typography>
                    <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                        (filtered)
                    </Typography>
                </Grid>
                <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                    <Box className="fx_fe" sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                        {/* Filter by Status */}
                        <Box className="textfield auto-complete" sx={{ minWidth: 200 }}>
                            <Autocomplete
                                value={selectedFilter}
                                onChange={(e, newValue) => setSelectedFilter(newValue || 'All')}
                                options={filterOptions}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Filter by Status"
                                        size="small"
                                        placeholder="Select status filter"
                                    />
                                )}
                                disableClearable
                            />
                        </Box>
                        
                        <Button
                            variant="outlined"
                            size="small"
                            className='main-btn btn-secondary'
                            onClick={fetchTemplateRequests}
                            disabled={loadingRequests}
                            startIcon={loadingRequests ? <CircularProgress size={16} /> : null}
                        >
                            Refresh
                        </Button>
                    </Box>
                </Grid>
                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box>
                        {loadingRequests ? (
                            <Box display="flex" justifyContent="center" alignItems="center" py={2}>
                                <CircularProgress size={24} />
                                <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                                    Loading your template requests...
                                </Typography>
                            </Box>
                        ) : requestsError ? (
                            <Box>
                                <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                                    {requestsError}
                                </Alert>
                            </Box>
                        ) : getFilteredRequests().length === 0 ? (
                            <Box textAlign="center" py={3}>
                                <Typography variant="body2" color="text.secondary">
                                    {templateRequests.length === 0 
                                        ? "You haven't raised any template requests yet."
                                        : `No template requests found for "${selectedFilter}" status.`
                                    }
                                </Typography>
                                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                                    {templateRequests.length === 0 
                                        ? "Use the \"Raise New Request\" button above to create your first template request."
                                        : "Try selecting a different filter or create a new request."
                                    }
                                </Typography>
                            </Box>
                        ) : (
                            <Box>  
                                <Grid container spacing={2}>
                                    {getFilteredRequests().map((request, index) => (
                                        <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }} key={request.ID || index}>
                                            <Card sx={{
                                                height: '100%',
                                                border: '1px solid #e0e0e0',
                                                '&:hover': {
                                                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                                                }
                                            }}>
                                                <CardContent sx={{ p: 2 }}>
                                                    <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
                                                        <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                                            {request.MIS_REQ_CLIENT_NAME}
                                                        </Typography>
                                                        <Chip
                                                            label={request.STATUS.replace('_', ' ').toUpperCase()}
                                                            size="small"
                                                            color={
                                                                request.STATUS === 'approved' ? 'success' :
                                                                    request.STATUS === 'rejected' ? 'error' :
                                                                        request.STATUS === 'in_progress' ? 'warning' :
                                                                            request.STATUS === 'completed' ? 'primary' : 'default'
                                                            }
                                                            variant="outlined"
                                                        />
                                                    </Box>

                                                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                        <strong>Invoice ID:</strong> {request.MIS_REQ_INVOICE_ID}
                                                    </Typography>

                                                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                        <strong>Requestor:</strong> {request.REQUESTOR_NAME} ({request.EMPLOYEE_CODE})
                                                    </Typography>

                                                    {request.REQUEST_COMMENT && (
                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                            <strong>Comment:</strong> {request.REQUEST_COMMENT}
                                                        </Typography>
                                                    )}

                                                    {request.ADMIN_COMMENT && (
                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                                            <strong>Admin Comment:</strong> {request.ADMIN_COMMENT}
                                                        </Typography>
                                                    )}

                                                    <Typography variant="caption" color="text.secondary">
                                                        Created: {new Date(request.CREATED_AT).toLocaleDateString()}
                                                        {request.ADMIN_UPDATED_AT && (
                                                            <span> | Updated: {new Date(request.ADMIN_UPDATED_AT).toLocaleDateString()}</span>
                                                        )}
                                                    </Typography>
                                                </CardContent>
                                            </Card>
                                        </Grid>
                                    ))}
                                </Grid>
                            </Box>
                        )}
                    </Box>
                </Grid>
            </Grid>
        </Box>
    )
}

export default TemplateRequestSection
