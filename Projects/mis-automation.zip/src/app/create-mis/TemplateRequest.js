'use client'
import React, { useState } from 'react'
import {
    TextField,
    Card,
    CardContent,
    Typography,
    Grid,
    Box,
    Chip,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    CircularProgress,
    Snackbar,
    Alert,
    Container,
    Autocomplete
} from '@mui/material'
import { useEmployeeStore } from '@/store/employeeStore'
import { HiOutlineDocumentAdd } from "react-icons/hi";
import { FaCheckCircle } from "react-icons/fa";

const TemplateRequest = ({ invoiceDetails: propInvoiceDetails, onRequestSuccess, availableTemplates = [], existingRequests = [] }) => {
    const { employeeDetails, userRole } = useEmployeeStore()
    // const router = useRouter()
    console.warn('Employee Details', employeeDetails);
    console.warn('User Role', userRole);

    // Template Request states
    const [selectedClient, setSelectedClient] = useState(null)
    const [templateName, setTemplateName] = useState('')
    const [requestComment, setRequestComment] = useState('')
    const [isSubmitting, setIsSubmitting] = useState(false)
    
    // SSO Clients state
    const [ssoClients, setSsoClients] = useState([])
    const [loadingSsoClients, setLoadingSsoClients] = useState(false)

    // Dialog state
    const [dialogOpen, setDialogOpen] = useState(false)

    // Invoice Activity Details state
    const [invoiceDetails, setInvoiceDetails] = useState(propInvoiceDetails || null)

    // Snackbar states
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'info' // 'error', 'warning', 'info', 'success'
    })

    // Snackbar handlers
    const showSnackbar = (message, severity = 'info') => {
        setSnackbar({
            open: true,
            message,
            severity
        })
    }

    const handleCloseSnackbar = () => {
        setSnackbar(prev => ({
            ...prev,
            open: false
        }))
    }

    // Process invoice details to get client list and filter based on existing templates and requests
    const availableInvoices = React.useMemo(() => {
        if (!invoiceDetails || invoiceDetails.error) return [];

        // Handle object format with numeric keys (0, 1, 2, etc.)
        const allInvoices = Array.isArray(invoiceDetails) ? invoiceDetails : Object.values(invoiceDetails).filter(item =>
            typeof item === 'object' && item.invoice_id && item.invoice_name && item.client_name
        );

        console.log('🔍 All invoices from invoice details:', allInvoices);
        console.log('🔍 Available templates:', availableTemplates);
        console.log('🔍 Existing requests:', existingRequests);

        // Get invoice IDs that already have templates (convert to strings for comparison)
        const templateInvoiceIds = availableTemplates.map(template => String(template.SSO_CLIENT_ID || template.CLIENT_ID || ''));
        console.log('🔍 Invoice IDs with existing templates:', templateInvoiceIds);

        // Get invoice IDs that already have requests raised (convert to strings for comparison)
        const requestedInvoiceIds = existingRequests.map(request => String(request.MIS_REQ_INVOICE_ID || ''));
        console.log('🔍 Invoice IDs with existing requests:', requestedInvoiceIds);

        // Filter out invoices that have templates or requests
        const filteredInvoices = allInvoices.filter(invoice => {
            const invoiceId = String(invoice.invoice_id || '');
            const hasTemplate = templateInvoiceIds.includes(invoiceId);
            const hasRequest = requestedInvoiceIds.includes(invoiceId);

            console.log(`🔍 Invoice ${invoice.invoice_id} (${invoice.client_name}):`, {
                hasTemplate,
                hasRequest,
                shouldShow: !hasTemplate && !hasRequest
            });

            return !hasTemplate && !hasRequest;
        });

        console.log('🔍 Filtered available invoices:', filteredInvoices);
        return filteredInvoices;
    }, [invoiceDetails, availableTemplates, existingRequests]);

    // Fetch invoice details
    const getInvoiceDetails = async () => {
        try {
            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                setInvoiceDetails({
                    error: 'No session or access token available',
                    details: 'Please login again'
                });
                return;
            }

            const url = process.env.NEXT_PUBLIC_SSO_TIMESHEET_INVOICE_DETAIL;

            if (!url) {
                setInvoiceDetails({
                    error: 'Invoice details API URL not configured',
                    details: 'Please check environment variables'
                });
                return;
            }

            console.log('Invoice Details URL:', url);

            // Get today's date in YYYY-MM-DD format
            const today = new Date().toISOString().split('T')[0];
            console.log('Requesting data for date:', today);

            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({ date: today })
            });

            // Check if response exists before accessing its properties
            if (response && response.ok) {
                const data = await response.json();
                setInvoiceDetails({ ...data, url, requestDate: today });
                console.log('Invoice Details Response:', data);
            } else if (response) {
                const errorText = await response.text();
                console.log('Invoice Details Error response:', errorText);

                // Try with a different date (yesterday) if today fails
                const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                console.log('Trying with yesterday\'s date:', yesterday);

                const retryResponse = await fetch(url, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ date: yesterday })
                });

                if (retryResponse && retryResponse.ok) {
                    const retryData = await retryResponse.json();
                    setInvoiceDetails({ ...retryData, url, requestDate: yesterday });
                    console.log('Invoice Details Response (yesterday):', retryData);
                } else {
                    const retryErrorText = retryResponse ? await retryResponse.text() : 'No response received';
                    console.log('Invoice Details Retry Error:', retryErrorText);
                    setInvoiceDetails({
                        error: 'Invoice activity data not available',
                        details: 'Unable to fetch invoice activity data for the requested date.'
                    });
                }
            } else {
                // Handle case where response is undefined (network error, CORS, etc.)
                console.error('Invoice Details: No response received from server');
                setInvoiceDetails({
                    error: 'Network error',
                    details: 'Unable to connect to invoice activity service. Please check your connection.'
                });
            }

        } catch (error) {
            console.error('Error fetching invoice details:', error);
            setInvoiceDetails({
                error: 'Failed to fetch invoice activity',
                details: `There was an error connecting to the invoice activity service: ${error.message || 'Unknown error'}`
            });
        }
    };




    // Function to fetch SSO clients
    const fetchSsoClients = async () => {
        try {
            setLoadingSsoClients(true);
            
            const session = localStorage.getItem('session');
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                console.error('No access token available');
                setSsoClients([]);
                return;
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const apiUrl = process.env.NEXT_PUBLIC_SSO_GET_ALL_CLIENTS || 'https://api-timesheet.decimalpointanalytics.com/master/clients/';
            console.log('Fetching SSO clients from:', apiUrl);
            console.log('Environment variable NEXT_PUBLIC_SSO_GET_ALL_CLIENTS:', process.env.NEXT_PUBLIC_SSO_GET_ALL_CLIENTS);

            // Create an AbortController for timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

            const response = await fetch(apiUrl, {
                headers: headers,
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            console.log('SSO Clients API Response:', {
                status: response?.status,
                statusText: response?.statusText,
                ok: response?.ok,
                url: response?.url
            });

            // Check if response exists and is ok
            if (response && response.ok) {
                const data = await response.json();
                console.log('SSO Clients loaded:', data);
                setSsoClients(data || []);
            } else {
                console.error('Failed to fetch SSO clients:', {
                    status: response?.status,
                    statusText: response?.statusText,
                    ok: response?.ok,
                    url: response?.url,
                    responseExists: !!response
                });
                // Set empty array as fallback
                setSsoClients([]);
                showSnackbar('Failed to load client list. Please try again.', 'warning');
            }
        } catch (error) {
            console.error('Error fetching SSO clients:', {
                error: error,
                message: error?.message,
                name: error?.name,
                stack: error?.stack,
                apiUrl: process.env.NEXT_PUBLIC_SSO_GET_ALL_CLIENTS || 'https://api-timesheet.decimalpointanalytics.com/master/clients/',
                isAbortError: error?.name === 'AbortError'
            });
            setSsoClients([]);
            
            // Show different messages based on error type
            if (error?.name === 'AbortError') {
                showSnackbar('Request timed out. Please check your connection and try again.', 'error');
            } else {
                showSnackbar('Error loading client list. Please check your connection and try again.', 'error');
            }
        } finally {
            setLoadingSsoClients(false);
        }
    };

    // Function to handle client selection
    const handleClientSelect = (client) => {
        setSelectedClient(client);
    };

    // Function to raise template request
    const handleRaiseTemplateRequest = async () => {
        if (!selectedClient) {
            showSnackbar('Please select a client', 'warning');
            return;
        }

        if (!templateName.trim()) {
            showSnackbar('Please enter a template name', 'warning');
            return;
        }

        setIsSubmitting(true);

        try {
            const requestBody = {
                requestorName: employeeDetails?.full_name || 'Unknown User',
                employeeCode: employeeDetails?.employee_code || '',
                misReqClientName: selectedClient.display_name || selectedClient.name,
                misReqInvoiceId: selectedClient.id || selectedClient.client_id,
                templateName: templateName.trim(),
                requestComment: requestComment.trim() || null,
                requestorEmail: employeeDetails?.email || null
            };

            console.log('Raising template request:', requestBody);

            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';

            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            if (!accessToken) {
                showSnackbar('No authentication token available. Please login again.', 'error');
                return;
            }

            const headers = {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
            };

            const response = await fetch('/api/raise-template-request', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to raise template request');
            }

            const result = await response.json();
            console.log('Template request raised successfully:', result);

            showSnackbar('Template request raised successfully!', 'success');
            handleDialogClose();

            // Call the callback to refresh the requests list
            if (onRequestSuccess && typeof onRequestSuccess === 'function') {
                onRequestSuccess();
            }

        } catch (error) {
            console.error('Error raising template request:', error);
            showSnackbar(`Failed to raise template request: ${error.message}`, 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    // Fetch invoice details if not provided as props
    React.useEffect(() => {
        if (!invoiceDetails && !propInvoiceDetails) {
            getInvoiceDetails();
        }
    }, [invoiceDetails, propInvoiceDetails]);

    const handleDialogOpen = () => {
        setDialogOpen(true)
        fetchSsoClients()
    }

    const handleDialogClose = () => {
        setDialogOpen(false)
        setSelectedClient(null)
        setTemplateName('')
        setRequestComment('')
    }



    // If not authenticated, show message
    if (!employeeDetails) {
        return (
            <Container maxWidth>
                <Box pt={8} px={3} display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                    <Typography>Please sign in to access the Template Request.</Typography>
                </Box>
            </Container>
        )
    }

    console.log('✅ Authenticated - showing template request form');

    return (
        <>
            <Button variant="outlined" onClick={handleDialogOpen} className='main-btn btn-primary' startIcon={<HiOutlineDocumentAdd />}>
                Template Request
            </Button>

            {/* Template Request Dialog */}
            <Dialog
                open={dialogOpen}
                onClose={handleDialogClose}
                maxWidth="md"
                fullWidth
            >
                <DialogTitle className='custom-dialog-title' sx={{ pb: 1 }}>
                    Raise Template Request
                </DialogTitle>
                <DialogContent sx={{ pt: 2 }}>
                    <Box mt={3}>
                        {/* Client Selection */}
                        <Box mb={4}>
                            <Typography variant="h6" gutterBottom>
                                Select Client
                            </Typography>
                            <Typography variant="body2" color="text.secondary" mb={2}>
                                Choose the client for which you want to raise a template request.
                            </Typography>
                            
                            <Box className="textfield auto-complete ph2">
                                <Autocomplete
                                    options={ssoClients}
                                    getOptionLabel={(option) => option.display_name || option.name || ''}
                                    value={selectedClient}
                                    onChange={(event, newValue) => {
                                        handleClientSelect(newValue);
                                    }}
                                    loading={loadingSsoClients}
                                    disabled={ssoClients.length === 0 && !loadingSsoClients}
                                    noOptionsText={loadingSsoClients ? "Loading clients..." : "No clients available"}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Select Client"
                                            placeholder={loadingSsoClients ? "Loading clients..." : "Search for a client..."}
                                            InputProps={{
                                                ...params.InputProps,
                                                endAdornment: (
                                                    <>
                                                        {loadingSsoClients ? <CircularProgress color="inherit" size={20} /> : null}
                                                        {params.InputProps.endAdornment}
                                                    </>
                                                ),
                                            }}
                                        />
                                    )}
                                    renderOption={(props, option) => {
                                        const { key, ...otherProps } = props;
                                        return (
                                            <Box component="li" key={key} {...otherProps}>
                                                <Box>
                                                    <Typography variant="body1">
                                                        {option.display_name || option.name}
                                                    </Typography>
                                                    <Typography variant="caption" color="text.secondary">
                                                        ID: {option.id || option.client_id}
                                                    </Typography>
                                                </Box>
                                            </Box>
                                        );
                                    }}
                                    isOptionEqualToValue={(option, value) => 
                                        (option.id || option.client_id) === (value?.id || value?.client_id)
                                    }
                                />
                            </Box>
                            
                            {ssoClients.length === 0 && !loadingSsoClients && (
                                <Box mt={1}>
                                    <Typography variant="body2" color="text.secondary">
                                        No clients available. Please check your connection or contact support.
                                    </Typography>
                                </Box>
                            )}
                        </Box>

                        {/* Template Name */}
                        <Box mb={4}>
                            <Typography variant="h6" gutterBottom>
                                Template Name
                            </Typography>
                            <Typography variant="body2" color="text.secondary" mb={2}>
                                Enter a descriptive name for the template you want to request.
                            </Typography>
                            
                            <Box className="textfield auto-complete ph2">
                                <TextField
                                    fullWidth
                                    variant="outlined"
                                    placeholder="e.g., Client_Name Monthly Report etc."
                                    value={templateName}
                                    onChange={(e) => setTemplateName(e.target.value)}
                                    helperText={`${templateName.length}/255 characters`}
                                    inputProps={{ maxLength: 255 }}
                                />
                            </Box>
                        </Box>

                        {/* Comment Section */}
                        <Box mb={4}>
                            <Typography variant="h6" gutterBottom>
                                Additional Comments (Optional)
                            </Typography>
                            <Typography variant="body2" color="text.secondary" mb={2}>
                                Provide any additional information or specific requirements for the template
                            </Typography>
                            <Box className="textfield auto-complete ph2">
                                <TextField
                                    fullWidth
                                    multiline
                                    rows={1}
                                    variant="outlined"
                                    placeholder="Enter your comments here..."
                                    value={requestComment}
                                    onChange={(e) => setRequestComment(e.target.value)}
                                    helperText={`${requestComment.length}/500 characters`}
                                    inputProps={{ maxLength: 500 }}
                                />
                            </Box>
                        </Box>
                    </Box>
                </DialogContent>
                <DialogActions className='custom-dialog-action'>
                    <Button onClick={handleDialogClose} color="inherit" disabled={isSubmitting} className='main-btn btn-tertiary'>
                        Cancel
                    </Button>


                    <Button
                        onClick={handleRaiseTemplateRequest}
                        variant="contained"
                        className="main-btn btn-primary"
                        disabled={!selectedClient || !templateName.trim() || isSubmitting}
                        startIcon={isSubmitting ? <CircularProgress size={20} /> : null}
                    >
                        {isSubmitting ? 'Raising Request...' : 'Raise Request'}
                    </Button>

                </DialogActions>
            </Dialog>

            {/* Snackbar for notifications */}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </>
    )
}

export default TemplateRequest