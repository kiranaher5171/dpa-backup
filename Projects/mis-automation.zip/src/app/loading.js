import React from 'react';
import { Box, Typography } from '@mui/material';

export default function Loading() {
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        backgroundColor: '#f5f5f5'
      }}
    >
     <div className="loader"></div>
      <Typography 
        variant="h6" 
        color="text.secondary"
        sx={{ 
          marginTop: 2,
          fontWeight: 500
        }}
      >
        Loading...
      </Typography>
    </Box>
  );
} 