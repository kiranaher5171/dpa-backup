'use client';
import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
    Box,
    Container,
    Typography,
    Card,
    CardContent,
    Grid,
    CircularProgress,
    Alert,
    Button,
    Chip,
    ToggleButton,
    ToggleButtonGroup,
    Divider,
    List,
    ListItem,
    ListItemText,
    Accordion,
    AccordionSummary,
    AccordionDetails
} from '@mui/material';
import { Refresh, ExpandMore, Code, ViewList } from '@mui/icons-material';
import { useEmployeeStore } from '@/store/employeeStore';
import BasicLayout from '../layouts/BasicLayout';

const SSODashboard = () => {
    const router = useRouter();
    const {
        employeeDetails,
        userRole,
        loading: employeeLoading,
        error: employeeError,
        isAuthenticated,
        getLoggedInUserDetails,
        clearEmployeeDetails
    } = useEmployeeStore();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [userDetails, setUserDetails] = useState(null);
    const [invoiceDetails, setInvoiceDetails] = useState(null);
    const [ssoClients, setSsoClients] = useState(null);
    const [allEmployees, setAllEmployees] = useState(null);
    const [session, setSession] = useState(null);
    const [displayMode, setDisplayMode] = useState('structured'); // 'structured' or 'unstructured'

    // Check if user is logged in
    useEffect(() => {
        const checkSession = () => {
            try {
                const sessionData = localStorage.getItem('session');
                const expireTime = localStorage.getItem('expireTime');

                if (!sessionData || !expireTime) {
                    router.push('/auth/sso-login');
                    return;
                }

                const session = JSON.parse(sessionData);
                const expireDate = new Date(expireTime);
                const currentDate = new Date();

                if (currentDate > expireDate) {
                    localStorage.clear();
                    router.push('/auth/sso-login');
                    return;
                }

                // Decode JWT token to check permissions
                try {
                    const tokenPayload = JSON.parse(atob(session.accessToken.split('.')[1]));
                    console.log('Token payload:', tokenPayload);
                    console.log('User permissions/roles:', tokenPayload);
                } catch (tokenError) {
                    console.log('Could not decode token payload:', tokenError);
                }

                setSession(session);
            } catch (error) {
                console.error('Session check error:', error);
                router.push('/auth/sso-login');
            }
        };

        checkSession();
    }, []);

    // Fetch user details
    const getUserDetails = async () => {
        try {
            // Check if session and access token are available
            if (!session || !session.accessToken) {
                throw new Error('No session or access token available');
            }

            const url = process.env.NEXT_PUBLIC_SSO_APP_TIMESHEET_USER_DETAILS;

            if (!url) {
                throw new Error('User details API URL not configured');
            }

            console.log('User Details URL:', url);

            const headers = {
                'Authorization': `Bearer ${session.accessToken}`,
                'Content-Type': 'application/json'
            };

            const response = await fetch(url, {
                method: 'GET',
                headers: headers
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`User details failed: ${response.status} - ${errorText}`);
            }

            const data = await response.json();
            setUserDetails({ ...data, url });
            console.log('User Details Response:', data);
        } catch (error) {
            console.error('Error fetching user details:', error);
            setError(`Failed to fetch user details: ${error.message}`);
        }
    };

    // Fetch invoice details
    const getInvoiceDetails = async () => {
        // Check if session and access token are available
        if (!session || !session.accessToken) {
            setInvoiceDetails({
                error: 'No session or access token available',
                details: 'Please login again',
                url: process.env.NEXT_PUBLIC_SSO_TIMESHEET_INVOICE_DETAIL
            });
            return;
        }

        const url = process.env.NEXT_PUBLIC_SSO_TIMESHEET_INVOICE_DETAIL;

        if (!url) {
            setInvoiceDetails({
                error: 'Invoice details API URL not configured',
                details: 'Please check environment variables',
                url: process.env.NEXT_PUBLIC_SSO_TIMESHEET_INVOICE_DETAIL
            });
            return;
        }

        console.log('Invoice Details URL:', url);

        // Get today's date in YYYY-MM-DD format
        const today = new Date().toISOString().split('T')[0];
        console.log('Requesting data for date:', today);

        const headers = {
            'Authorization': `Bearer ${session.accessToken}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({ date: today })
            });

            if (response.ok) {
                const data = await response.json();
                setInvoiceDetails({ ...data, url, requestDate: today });
                console.log('Invoice Details Response:', data);
            } else {
                const errorText = await response.text();
                console.log('Invoice Details Error response:', errorText);

                // Try with a different date (yesterday) if today fails
                const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                console.log('Trying with yesterday\'s date:', yesterday);

                const retryResponse = await fetch(url, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ date: yesterday })
                });

                if (retryResponse.ok) {
                    const retryData = await retryResponse.json();
                    setInvoiceDetails({ ...retryData, url, requestDate: yesterday });
                    console.log('Invoice Details Response (yesterday):', retryData);
                } else {
                    const retryErrorText = await retryResponse.text();
                    console.log('Invoice Details Retry Error:', retryErrorText);
                    setInvoiceDetails({
                        error: 'Invoice activity data not available',
                        details: 'Unable to fetch invoice activity data for the requested date.',
                        url
                    });
                }
            }

        } catch (error) {
            console.error('Error fetching invoice details:', error);
            setInvoiceDetails({
                error: 'Failed to fetch invoice activity',
                details: 'There was an error connecting to the invoice activity service.',
                url: url
            });
        }
    };

    // Fetch employee details using the store
    const getEmployeeDetails = async () => {
        if (session && session.accessToken) {
            const result = await getLoggedInUserDetails(session.accessToken);
            if (result && !result.success) {
                setError(result.error || 'Failed to fetch employee details');
            }
        }
    };


    // Fetch all employees
    const getAllEmployees = async () => {
        // Check if session and access token are available
        if (!session || !session.accessToken) {
            setAllEmployees({
                error: 'No session or access token available',
                details: 'Please login again',
                url: process.env.NEXT_PUBLIC_ALL_EMPLOYEES
            });
            return;
        }

        const url = process.env.NEXT_PUBLIC_ALL_EMPLOYEES;

        if (!url) {
            setAllEmployees({
                error: 'All employees API URL not configured',
                details: 'Please check environment variables',
                url: process.env.NEXT_PUBLIC_ALL_EMPLOYEES
            });
            return;
        }

        console.log('All Employees URL:', url);

        const headers = {
            'Authorization': `Bearer ${session.accessToken}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        try {
            console.log('All Employees: Making request to:', url);
            const response = await fetch(url, {
                method: 'GET',
                headers: headers
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.log('All Employees Error:', errorText);
                setAllEmployees({
                    error: 'Failed to fetch all employees',
                    details: `Status: ${response.status} - ${errorText}`,
                    url: url
                });
                return;
            }

            const data = await response.json();
            setAllEmployees({ ...data, url });
            console.log('All Employees Response:', data);
        } catch (error) {
            console.error('Error fetching all employees:', error);
            setAllEmployees({
                error: 'Failed to fetch all employees',
                details: error.message,
                url: url
            });
        }
    };

    // Fetch SSO clients
    const getSsoClients = async () => {
        // Check if session and access token are available
        if (!session || !session.accessToken) {
            setSsoClients({
                error: 'No session or access token available',
                details: 'Please login again',
                url: process.env.NEXT_PUBLIC_SSO_GET_ALL_CLIENTS
            });
            return;
        }

        // Try the configured URL first
        let url = process.env.NEXT_PUBLIC_SSO_GET_ALL_CLIENTS;

        // If no URL configured, try a fallback
        if (!url) {
            url = 'https://api-timesheet.decimalpointanalytics.com/master/clients/';
            console.log('SSO Clients: Using fallback URL:', url);
        } else {
            console.log('SSO Clients: Using configured URL:', url);
        }

        const headers = {
            'Authorization': `Bearer ${session.accessToken}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        try {
            console.log('SSO Clients: Making request to:', url);
            const response = await fetch(url, {
                method: 'GET',
                headers: headers
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.log('SSO Clients Error:', errorText);

                // If the first URL fails, try the working API endpoint as fallback
                if (url !== 'https://api-timesheet.decimalpointanalytics.com/master/clients/') {
                    console.log('SSO Clients: Trying fallback URL...');
                    const fallbackUrl = 'https://api-timesheet.decimalpointanalytics.com/master/clients/';

                    const fallbackResponse = await fetch(fallbackUrl, {
                        method: 'GET',
                        headers: headers
                    });

                    if (fallbackResponse.ok) {
                        const fallbackData = await fallbackResponse.json();
                        setSsoClients({ ...fallbackData, url: fallbackUrl, usedFallback: true });
                        console.log('SSO Clients: Fallback Response:', fallbackData);
                        return;
                    } else {
                        const fallbackErrorText = await fallbackResponse.text();
                        console.log('SSO Clients: Fallback Error:', fallbackErrorText);
                    }
                }

                setSsoClients({
                    error: 'Failed to fetch SSO clients',
                    details: `Status: ${response.status} - ${errorText}`,
                    url: url
                });
                return;
            }

            const data = await response.json();
            setSsoClients({ ...data, url });
            console.log('SSO Clients Response:', data);
        } catch (error) {
            console.error('Error fetching SSO clients:', error);
            setSsoClients({
                error: 'Failed to fetch SSO clients',
                details: error.message,
                url: url
            });
        }
    };

    // Fetch all data
    const fetchAllData = async () => {
        setLoading(true);
        setError(null);

        try {
            // Fetch APIs sequentially to better handle errors
            await getUserDetails();
            await getEmployeeDetails();

            // Fetch SSO clients (non-blocking - handles its own errors)
            await getSsoClients();

            // Fetch all employees (non-blocking - handles its own errors)
            await getAllEmployees();

            // Fetch invoice details (non-blocking - handles its own errors)
            await getInvoiceDetails();
        } catch (error) {
            console.error('Error fetching data:', error);
            setError('Failed to fetch data. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    // Fetch data when session is available
    useEffect(() => {
        if (session) {
            fetchAllData();
        }
    }, [session]);

    // Handle employee store errors
    useEffect(() => {
        if (employeeError) {
            setError(employeeError);
        }
    }, [employeeError]);

    // Cleanup employee details on unmount
    useEffect(() => {
        return () => {
            clearEmployeeDetails();
        };
    }, [clearEmployeeDetails]);

    // Helper function to render structured user details
    const renderStructuredUserDetails = (data) => {
        if (!data || data.error) return null;

        return (
            <Box>
                <Typography variant="subtitle2" color="primary" gutterBottom>
                    Personal Information
                </Typography>
                <List dense>
                    <ListItem>
                        <ListItemText
                            primary="Name"
                            secondary={`${data.first_name || ''} ${data.last_name || ''}`.trim() || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Department ID"
                            secondary={data.department_id || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="User Group"
                            secondary={data.user_group || 'N/A'}
                        />
                    </ListItem>
                </List>

                <Divider sx={{ my: 2 }} />

                <Typography variant="subtitle2" color="primary" gutterBottom>
                    Permissions & Roles
                </Typography>
                <List dense>
                    <ListItem>
                        <ListItemText
                            primary="Can Edit My Timesheet"
                            secondary={data.can_edit_my_ts ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Can Edit Back Timesheet"
                            secondary={data.can_edit_back_ts ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Can Edit Team"
                            secondary={data.can_edit_tm ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Staff Access"
                            secondary={data.is_staff ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="STL Access"
                            secondary={data.is_stl ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="HR Access"
                            secondary={data.is_hr ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Tech Lead"
                            secondary={data.is_tech_lead ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Functional Lead"
                            secondary={data.is_functional_lead ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="RM Access"
                            secondary={data.is_rm ? 'Yes' : 'No'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Super User"
                            secondary={data.is_superuser ? 'Yes' : 'No'}
                        />
                    </ListItem>
                </List>
            </Box>
        );
    };

    // Helper function to render structured invoice details
    const renderStructuredInvoiceDetails = (data) => {
        if (!data || data.error) return null;

        // Handle object format with numeric keys (0, 1, 2, etc.)
        const invoiceArray = Array.isArray(data) ? data : Object.values(data).filter(item =>
            typeof item === 'object' && item.invoice_id && item.invoice_name
        );

        if (invoiceArray.length > 0) {
            return (
                <Box>
                    <Typography variant="subtitle2" color="primary" gutterBottom>
                        Invoice Activities ({invoiceArray.length} invoices)
                        {data.requestDate && (
                            <Typography variant="caption" color="text.secondary" display="block">
                                Date: {data.requestDate}
                            </Typography>
                        )}
                    </Typography>
                    {invoiceArray.map((invoice, index) => (
                        <Accordion key={invoice.invoice_id || index} sx={{ mb: 1 }}>
                            <AccordionSummary expandIcon={<ExpandMore />}>
                                <Typography variant="subtitle2">
                                    {invoice.invoice_name || `Invoice ${invoice.invoice_id}`}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                    <strong>Client:</strong> {invoice.client_name || 'N/A'}
                                </Typography>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                    <strong>Invoice ID:</strong> {invoice.invoice_id || 'N/A'}
                                </Typography>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                    <strong>Activities:</strong> {invoice.activities?.length || 0} activities
                                </Typography>
                                {invoice.activities && invoice.activities.length > 0 && (
                                    <List dense sx={{ mt: 1 }}>
                                        {invoice.activities.map((activity, actIndex) => (
                                            <ListItem key={activity.id || actIndex} sx={{ py: 0 }}>
                                                <ListItemText
                                                    primary={activity.activity_name || 'Unknown Activity'}
                                                    secondary={`ID: ${activity.id || 'N/A'}`}
                                                />
                                            </ListItem>
                                        ))}
                                    </List>
                                )}
                            </AccordionDetails>
                        </Accordion>
                    ))}
                </Box>
            );
        }

        return (
            <Typography variant="body2" color="text.secondary">
                No structured invoice data available
            </Typography>
        );
    };

    // Helper function to render structured employee details
    const renderStructuredEmployeeDetails = (data) => {
        if (!data || data.error) return null;

        return (
            <Box>
                <Typography variant="subtitle2" color="primary" gutterBottom>
                    Employee Information
                </Typography>
                <List dense>
                    <ListItem>
                        <ListItemText
                            primary="Employee Code"
                            secondary={data.employee_code || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Full Name"
                            secondary={data.full_name || `${data.first_name || ''} ${data.last_name || ''}`.trim() || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Email"
                            secondary={data.email || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Location"
                            secondary={data.location || 'N/A'}
                        />
                    </ListItem>
                </List>

                <Divider sx={{ my: 2 }} />

                <Typography variant="subtitle2" color="primary" gutterBottom>
                    Work Details
                </Typography>
                <List dense>
                    <ListItem>
                        <ListItemText
                            primary="Shift Code"
                            secondary={data.shift_code || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Shift Name"
                            secondary={data.shift_name || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Holiday Calendar"
                            secondary={data.holiday_calendar_name || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="Holiday Calendar ID"
                            secondary={data.holiday_calendar || 'N/A'}
                        />
                    </ListItem>
                    <ListItem>
                        <ListItemText
                            primary="User ID"
                            secondary={data.user || 'N/A'}
                        />
                    </ListItem>
                </List>
            </Box>
        );
    };

    // Helper function to render structured all employees data
    const renderStructuredAllEmployees = (data) => {
        if (!data || data.error) return null;

        // Handle different possible data structures
        let employeesArray = [];

        if (Array.isArray(data)) {
            employeesArray = data;
        } else if (data.employees && Array.isArray(data.employees)) {
            employeesArray = data.employees;
        } else if (data.results && Array.isArray(data.results)) {
            employeesArray = data.results;
        } else if (typeof data === 'object') {
            // Handle object with numeric keys (0, 1, 2, etc.) - specific format: { "0": { "id": "tms_admin", "display_name": "" }, ... }
            const values = Object.values(data);
            employeesArray = values.filter(item =>
                typeof item === 'object' && item &&
                (item.id || item.employee_id || item.employee_code || item.display_name || item.full_name || item.first_name)
            );
        }

        if (employeesArray.length > 0) {
            return (
                <Box>
                    <Typography variant="subtitle2" color="primary" gutterBottom>
                        All Employees ({employeesArray.length} employees)
                    </Typography>
                    {employeesArray.slice(0, 10).map((employee, index) => (
                        <Accordion key={employee.id || employee.employee_id || index} sx={{ mb: 1 }}>
                            <AccordionSummary expandIcon={<ExpandMore />}>
                                <Typography variant="subtitle2">
                                    {employee.display_name || employee.full_name || `${employee.first_name || ''} ${employee.last_name || ''}`.trim() || `Employee ${index + 1}`}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                    <strong>Employee ID:</strong> {employee.id || employee.employee_id || employee.employee_code || 'N/A'}
                                </Typography>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                    <strong>Display Name:</strong> {employee.display_name || employee.full_name || `${employee.first_name || ''} ${employee.last_name || ''}`.trim() || 'N/A'}
                                </Typography>
                                {employee.email && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Email:</strong> {employee.email}
                                    </Typography>
                                )}
                                {employee.department && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Department:</strong> {employee.department}
                                    </Typography>
                                )}
                                {employee.location && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Location:</strong> {employee.location}
                                    </Typography>
                                )}
                                {employee.shift_name && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Shift:</strong> {employee.shift_name}
                                    </Typography>
                                )}
                                {employee.is_active !== undefined && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Active:</strong> {employee.is_active ? 'Yes' : 'No'}
                                    </Typography>
                                )}
                            </AccordionDetails>
                        </Accordion>
                    ))}
                    {employeesArray.length > 10 && (
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 2, fontStyle: 'italic' }}>
                            Showing first 10 employees. Total: {employeesArray.length} employees
                        </Typography>
                    )}
                </Box>
            );
        }

        return (
            <Typography variant="body2" color="text.secondary">
                No employees data available
            </Typography>
        );
    };

    // Helper function to render structured SSO clients data
    const renderStructuredSsoClients = (data) => {
        if (!data || data.error) return null;

        // Handle different possible data structures
        let clientsArray = [];

        if (Array.isArray(data)) {
            clientsArray = data;
        } else if (data.clients && Array.isArray(data.clients)) {
            clientsArray = data.clients;
        } else if (data.results && Array.isArray(data.results)) {
            clientsArray = data.results;
        } else if (typeof data === 'object') {
            // Handle object with numeric keys (0, 1, 2, etc.) - like your data
            const values = Object.values(data);
            clientsArray = values.filter(item =>
                typeof item === 'object' && item &&
                (item.id || item.client_id || item.display_name || item.client_name || item.name)
            );
        }

        if (clientsArray.length > 0) {
            return (
                <Box>
                    <Typography variant="subtitle2" color="primary" gutterBottom>
                        SSO Clients ({clientsArray.length} clients)
                    </Typography>
                    {clientsArray.slice(0, 10).map((client, index) => (
                        <Accordion key={client.id || client.client_id || index} sx={{ mb: 1 }}>
                            <AccordionSummary expandIcon={<ExpandMore />}>
                                <Typography variant="subtitle2">
                                    {client.display_name || client.client_name || client.name || `Client ${index + 1}`}
                                </Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                    <strong>Client ID:</strong> {client.id || client.client_id || 'N/A'}
                                </Typography>
                                <Typography variant="body2" color="text.secondary" gutterBottom>
                                    <strong>Display Name:</strong> {client.display_name || client.client_name || client.name || 'N/A'}
                                </Typography>
                                {client.industry && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Industry:</strong> {client.industry}
                                    </Typography>
                                )}
                                {client.status && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Status:</strong> {client.status}
                                    </Typography>
                                )}
                                {client.created_at && (
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        <strong>Created:</strong> {new Date(client.created_at).toLocaleDateString()}
                                    </Typography>
                                )}
                            </AccordionDetails>
                        </Accordion>
                    ))}
                    {clientsArray.length > 10 && (
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 2, fontStyle: 'italic' }}>
                            Showing first 10 clients. Total: {clientsArray.length} clients
                        </Typography>
                    )}
                </Box>
            );
        }

        return (
            <Typography variant="body2" color="text.secondary">
                No SSO clients data available
            </Typography>
        );
    };

    // Handle logout
    const handleLogout = () => {
        localStorage.clear();
        router.push('/auth/sso-login');
    };

    if (!session) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
                <CircularProgress />
            </Box>
        );
    }

    return (
        <>
            <BasicLayout>

                <Container maxWidth="lg" sx={{ py: 4 }}>
                    {/* Header */}
                    <Box mt={8} display="flex" justifyContent="space-between" alignItems="center" mb={4}>
                        <Typography variant="h4" component="h1" gutterBottom>
                            SSO Dashboard
                        </Typography>
                        <Box display="flex" alignItems="center" gap={2}>
                            <ToggleButtonGroup
                                value={displayMode}
                                exclusive
                                onChange={(e, newMode) => newMode && setDisplayMode(newMode)}
                                size="small"
                            >
                                <ToggleButton value="structured">
                                    <ViewList sx={{ mr: 1 }} />
                                    Structured
                                </ToggleButton>
                                <ToggleButton value="unstructured">
                                    <Code sx={{ mr: 1 }} />
                                    Raw JSON
                                </ToggleButton>
                            </ToggleButtonGroup>
                            <Button
                                variant="outlined"
                                startIcon={<Refresh />}
                                onClick={fetchAllData}
                                disabled={loading || employeeLoading}
                            >
                                Refresh Data
                            </Button>

                            <Button
                                variant="contained"
                                color="secondary"
                                onClick={handleLogout}
                            >
                                Logout
                            </Button>
                        </Box>
                    </Box>

                    {/* Welcome Message */}
                    <Card sx={{ mb: 4 }}>
                        <CardContent>
                            <Box display="flex" justifyContent="space-between" alignItems="center">
                                <Box>
                                    <Typography variant="h6" gutterBottom>
                                        Welcome, {session.employeeName}!
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Employee Code: {session.employeeCode}
                                    </Typography>
                                </Box>
                                {userRole && (
                                    <Chip
                                        label={`Role: ${userRole.toUpperCase()}`}
                                        color={userRole === 'admin' ? 'error' : 'primary'}
                                        variant="filled"
                                        size="medium"
                                    />
                                )}
                            </Box>
                        </CardContent>
                    </Card>

                    {/* Error Alert */}
                    {error && (
                        <Alert severity="error" sx={{ mb: 3 }}>
                            {error}
                        </Alert>
                    )}

                    {/* Loading State */}
                    {(loading || employeeLoading) && (
                        <Box display="flex" justifyContent="center" alignItems="center" py={4}>
                            <CircularProgress />
                        </Box>
                    )}

                    {/* Data Grid */}
                    {!loading && !employeeLoading && (
                        <Grid container spacing={3}>
                            {/* User Details */}
                            <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                <Card>
                                    <CardContent>
                                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                            <Typography variant="h6" gutterBottom>
                                                User Details
                                            </Typography>
                                        </Box>
                                        {userDetails ? (
                                            displayMode === 'structured' ? (
                                                renderStructuredUserDetails(userDetails)
                                            ) : (
                                                <Box>
                                                    <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                                                        API URL: {userDetails.url}
                                                    </Typography>
                                                    <Typography
                                                        variant="body2"
                                                        color="text.secondary"
                                                        sx={{
                                                            fontFamily: 'monospace',
                                                            fontSize: '0.75rem',
                                                            backgroundColor: '#f5f5f5',
                                                            p: 1,
                                                            borderRadius: 1,
                                                            overflow: 'auto',
                                                            maxHeight: '300px'
                                                        }}
                                                    >
                                                        {JSON.stringify(userDetails, null, 2)}
                                                    </Typography>
                                                </Box>
                                            )
                                        ) : (
                                            <Typography variant="body2" color="text.secondary">
                                                No user details available
                                            </Typography>
                                        )}
                                    </CardContent>
                                </Card>
                            </Grid>

                            {/* Invoice Activity Details */}
                            <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                <Card>
                                    <CardContent>
                                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                            <Typography variant="h6" gutterBottom>
                                                Invoice Activity Details
                                            </Typography>
                                        </Box>
                                        {invoiceDetails ? (
                                            invoiceDetails.error ? (
                                                <Box>
                                                    <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                                                        {invoiceDetails.error}
                                                    </Alert>
                                                    {invoiceDetails.details && (
                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                                            {invoiceDetails.details}
                                                        </Typography>
                                                    )}
                                                    <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.875rem' }}>
                                                        <strong>Your current permissions:</strong>
                                                    </Typography>
                                                    {userDetails && (
                                                        <Box sx={{ mt: 1 }}>
                                                            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                                                                • Can edit timesheet: {userDetails.can_edit_my_ts ? 'Yes' : 'No'}
                                                            </Typography>
                                                            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                                                                • Staff access: {userDetails.is_staff ? 'Yes' : 'No'}
                                                            </Typography>
                                                            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                                                                • HR access: {userDetails.is_hr ? 'Yes' : 'No'}
                                                            </Typography>
                                                            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                                                                • Tech Lead: {userDetails.is_tech_lead ? 'Yes' : 'No'}
                                                            </Typography>
                                                        </Box>
                                                    )}
                                                </Box>
                                            ) : (
                                                displayMode === 'structured' ? (
                                                    renderStructuredInvoiceDetails(invoiceDetails)
                                                ) : (
                                                    <Box>
                                                        <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                                                            API URL: {invoiceDetails.url}
                                                            {invoiceDetails.requestDate && ` | Date: ${invoiceDetails.requestDate}`}
                                                        </Typography>
                                                        <Typography
                                                            variant="body2"
                                                            color="text.secondary"
                                                            sx={{
                                                                fontFamily: 'monospace',
                                                                fontSize: '0.75rem',
                                                                backgroundColor: '#f5f5f5',
                                                                p: 1,
                                                                borderRadius: 1,
                                                                overflow: 'auto',
                                                                maxHeight: '300px'
                                                            }}
                                                        >
                                                            {JSON.stringify(invoiceDetails, null, 2)}
                                                        </Typography>
                                                    </Box>
                                                )
                                            )
                                        ) : (
                                            <Typography variant="body2" color="text.secondary">
                                                No invoice details available
                                            </Typography>
                                        )}
                                    </CardContent>
                                </Card>
                            </Grid>

                            {/* Employee Details */}
                            <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                <Card>
                                    <CardContent>
                                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                            <Typography variant="h6" gutterBottom>
                                                Employee Details
                                            </Typography>
                                        </Box>
                                        {employeeDetails ? (
                                            displayMode === 'structured' ? (
                                                renderStructuredEmployeeDetails(employeeDetails)
                                            ) : (
                                                <Box>
                                                    <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                                                        API URL: {employeeDetails.url}
                                                    </Typography>
                                                    <Typography
                                                        variant="body2"
                                                        color="text.secondary"
                                                        sx={{
                                                            fontFamily: 'monospace',
                                                            fontSize: '0.75rem',
                                                            backgroundColor: '#f5f5f5',
                                                            p: 1,
                                                            borderRadius: 1,
                                                            overflow: 'auto',
                                                            maxHeight: '300px'
                                                        }}
                                                    >
                                                        {JSON.stringify(employeeDetails, null, 2)}
                                                    </Typography>
                                                </Box>
                                            )
                                        ) : (
                                            <Typography variant="body2" color="text.secondary">
                                                No employee details available
                                            </Typography>
                                        )}
                                    </CardContent>
                                </Card>
                            </Grid>

                            {/* SSO Clients */}
                            <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                <Card>
                                    <CardContent>
                                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                            <Typography variant="h6" gutterBottom>
                                                SSO Clients
                                            </Typography>
                                        </Box>
                                        {ssoClients ? (
                                            ssoClients.error ? (
                                                <Box>
                                                    <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                                                        {ssoClients.error}
                                                    </Alert>
                                                    {ssoClients.details && (
                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                                            {ssoClients.details}
                                                        </Typography>
                                                    )}
                                                </Box>
                                            ) : (
                                                <Box>
                                                    {ssoClients.usedFallback && (
                                                        <Alert severity="info" sx={{ mt: 1, mb: 2 }}>
                                                            Using fallback API endpoint
                                                        </Alert>
                                                    )}
                                                    {displayMode === 'structured' ? (
                                                        renderStructuredSsoClients(ssoClients)
                                                    ) : (
                                                        <Box>
                                                            <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                                                                API URL: {ssoClients.url}
                                                            </Typography>
                                                            <Typography
                                                                variant="body2"
                                                                color="text.secondary"
                                                                sx={{
                                                                    fontFamily: 'monospace',
                                                                    fontSize: '0.75rem',
                                                                    backgroundColor: '#f5f5f5',
                                                                    p: 1,
                                                                    borderRadius: 1,
                                                                    overflow: 'auto',
                                                                    maxHeight: '300px'
                                                                }}
                                                            >
                                                                {JSON.stringify(ssoClients, null, 2)}
                                                            </Typography>
                                                        </Box>
                                                    )}
                                                </Box>
                                            )
                                        ) : (
                                            <Typography variant="body2" color="text.secondary">
                                                No SSO clients available
                                            </Typography>
                                        )}
                                    </CardContent>
                                </Card>
                            </Grid>

                            {/* All Employees */}
                            <Grid size={{ lg: 3, md: 6, sm: 12, xs: 12 }}>
                                <Card>
                                    <CardContent>
                                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                                            <Typography variant="h6" gutterBottom>
                                                All Employees
                                            </Typography>
                                        </Box>
                                        {allEmployees ? (
                                            allEmployees.error ? (
                                                <Box>
                                                    <Alert severity="warning" sx={{ mt: 1, mb: 2 }}>
                                                        {allEmployees.error}
                                                    </Alert>
                                                    {allEmployees.details && (
                                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                                            {allEmployees.details}
                                                        </Typography>
                                                    )}
                                                </Box>
                                            ) : (
                                                <Box>
                                                    {displayMode === 'structured' ? (
                                                        renderStructuredAllEmployees(allEmployees)
                                                    ) : (
                                                        <Box>
                                                            <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                                                                API URL: {allEmployees.url}
                                                            </Typography>
                                                            <Typography
                                                                variant="body2"
                                                                color="text.secondary"
                                                                sx={{
                                                                    fontFamily: 'monospace',
                                                                    fontSize: '0.75rem',
                                                                    backgroundColor: '#f5f5f5',
                                                                    p: 1,
                                                                    borderRadius: 1,
                                                                    overflow: 'auto',
                                                                    maxHeight: '300px'
                                                                }}
                                                            >
                                                                {JSON.stringify(allEmployees, null, 2)}
                                                            </Typography>
                                                        </Box>
                                                    )}
                                                </Box>
                                            )
                                        ) : (
                                            <Typography variant="body2" color="text.secondary">
                                                No employees data available
                                            </Typography>
                                        )}
                                    </CardContent>
                                </Card>
                            </Grid>
                        </Grid>
                    )}
                </Container>

            </BasicLayout>
        </>
    );
};

export default SSODashboard;