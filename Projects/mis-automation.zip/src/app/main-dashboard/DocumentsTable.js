"use client";
import React from 'react';
import {
    Box,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip, 
    IconButton,
    Avatar,
    Tooltip
} from '@mui/material';
import { Visibility } from '@mui/icons-material';
import { useRoleAccess } from '@/hooks/useRoleAccess';

const DocumentsTable = ({
    documents,
    loading,
    error,
    searchQuery,
    user,
    getStatusColor,
    formatDate,
    handleViewDocument
}) => {
    const { isAdmin } = useRoleAccess();

    // Helper function to generate initials from name
    const getInitials = (name) => {
        if (!name || typeof name !== 'string') return '?';
        const words = name.trim().split(/\s+/);
        if (words.length === 1) {
            return words[0].substring(0, 2).toUpperCase();
        }
        return (words[0][0] + words[words.length - 1][0]).toUpperCase();
    }

    // Helper function to get avatar color based on name
    const getAvatarColor = (name) => {
        if (!name) return '#757575';
        const colors = [
            '#f44336', '#e91e63', '#9c27b0', '#673ab7',
            '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4',
            '#009688', '#4caf50', '#8bc34a', '#cddc39',
            '#ffeb3b', '#ffc107', '#ff9800', '#ff5722'
        ];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }

 

    return (
        <TableContainer
            sx={{
                height: 400,
                overflow: 'auto'
            }}
        >
            <Table stickyHeader>
                <TableHead>
                    <TableRow>
                        <TableCell sx={{
                            backgroundColor: 'primary.main',
                            color: 'white',
                            fontWeight: 'bold',
                            position: 'sticky',
                            top: 0,
                            zIndex: 1
                        }}>
                            Client Name
                        </TableCell>
                        <TableCell sx={{
                            backgroundColor: 'primary.main',
                            color: 'white',
                            fontWeight: 'bold',
                            position: 'sticky',
                            top: 0,
                            zIndex: 1
                        }}>
                            Template Used
                        </TableCell>
                        <TableCell sx={{
                            backgroundColor: 'primary.main',
                            color: 'white',
                            fontWeight: 'bold',
                            position: 'sticky',
                            top: 0,
                            zIndex: 1
                        }}>
                            Document Name
                        </TableCell>
                        <TableCell sx={{
                            backgroundColor: 'primary.main',
                            color: 'white',
                            fontWeight: 'bold',
                            position: 'sticky',
                            top: 0,
                            zIndex: 1,
                            minWidth: '140px',
                            textAlign: 'center'
                        }}>
                            Created By
                        </TableCell>
                        <TableCell sx={{
                            backgroundColor: 'primary.main',
                            color: 'white',
                            fontWeight: 'bold',
                            position: 'sticky',
                            top: 0,
                            zIndex: 1,
                            minWidth: '160px'
                        }}>
                            Created On
                        </TableCell>
                        <TableCell sx={{
                            backgroundColor: 'primary.main',
                            color: 'white',
                            fontWeight: 'bold',
                            position: 'sticky',
                            top: 0,
                            zIndex: 1
                        }}>
                            Status
                        </TableCell>
                        <TableCell sx={{
                            backgroundColor: 'primary.main',
                            color: 'white',
                            fontWeight: 'bold',
                            position: 'sticky',
                            top: 0,
                            zIndex: 1
                        }}>
                            Actions
                        </TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {documents.map((doc) => (
                        <TableRow key={doc.ID} hover>
                            <TableCell>{doc.SSO_CLIENT_NAME}</TableCell>
                            <TableCell>{doc.TEMPLATE_NAME}</TableCell>
                            <TableCell>
                                {doc.MIS_DOCUMENT_NAME}
                            </TableCell>
                            <TableCell className='fx_c'>
                                <Tooltip 
                                    title={doc.CREATED_BY || 'Unknown'}
                                    arrow
                                    placement="top"
                                >
                                    <Avatar 
                                        sx={{ 
                                            bgcolor: getAvatarColor(doc.CREATED_BY || 'Unknown'),
                                            fontSize: '0.875rem',
                                            fontWeight: 'bold',
                                            width: 32,
                                            height: 32
                                        }}
                                    >
                                        {getInitials(doc.CREATED_BY || 'Unknown')}
                                    </Avatar>
                                </Tooltip>
                            </TableCell>
                            <TableCell>
                                <span dangerouslySetInnerHTML={{ __html: formatDate(doc.CREATED_AT) }} />
                            </TableCell>
                            <TableCell>
                                <Chip
                                    label={doc.STATUS || 'Draft'}
                                    size="small"
                                    className="status-chip"
                                    sx={{
                                        backgroundColor: getStatusColor(doc.STATUS),
                                        color: 'white',
                                        fontWeight: 'bold'
                                    }}
                                />
                            </TableCell>
                            <TableCell>
                                <Box className="center">
                                    <IconButton className="tb-sq-btn primary-act-btn" onClick={() => handleViewDocument(doc.MIS_DOCUMENT_NAME)}>
                                        <Visibility />
                                    </IconButton>
                                </Box>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default DocumentsTable;
