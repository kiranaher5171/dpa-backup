import React from 'react'
import BasicLayout from '../layouts/BasicLayout'
import DashboardStats from './DashboardStats';

const DashboardPage = () => {
    return (
        <BasicLayout>
            <DashboardStats />
        </BasicLayout>
    )
}

export default DashboardPage