"use client";
import React, { useState, useEffect } from 'react'
import { useEmployeeStore } from '@/store/employeeStore'
import { useRoleAccess } from '@/hooks/useRoleAccess';
import {
    Box,
    Grid,
    Card,
    CardContent,
    Typography,
    TextField,
    Avatar,
    Button,
    Autocomplete,
    Container,
    InputAdornment,
    Skeleton,
    Alert,
    CircularProgress,
    Backdrop
} from '@mui/material'
import {
    TrendingUp,
    PendingActions,
    Assignment,
    Search,
    CheckCircle,
    Error
} from '@mui/icons-material'
import { useRouter } from 'next/navigation'
import Link from 'next/link';
import SimpleDatePicker from '../components/SimpleDatePicker';
import DocumentsTable from './DocumentsTable';
import { TbMailFast } from "react-icons/tb";
import { HiOutlineDocumentPlus } from "react-icons/hi2";

// Dashboard Skeleton Component
const DashboardSkeleton = () => (
    <>
        <Box className="main-box">
            <Container maxWidth>
                {/* Header Skeleton */}
                <Box my={2}>
                    <Grid container spacing={2} alignItems="center" justifyContent="space-between">
                        <Grid size={{ lg: 8, md: 6, sm: 12, xs: 12 }}>
                            <Skeleton variant="text" width="60%" height={40} />
                        </Grid>
                        <Grid size={{ lg: 2, md: 6, sm: 12, xs: 12 }}>
                            <Skeleton variant="rectangular" width="100%" height={56} sx={{ borderRadius: 1 }} />
                        </Grid>
                        <Grid size={{ lg: 2, md: 6, sm: 12, xs: 12 }}>
                            <Skeleton variant="rectangular" width="100%" height={40} sx={{ borderRadius: 1 }} />
                        </Grid>
                    </Grid>
                </Box>

                {/* Tab Cards Skeleton */}
                <Box mt={2}>
                    <Grid container spacing={2} sx={{ mb: 4 }}>
                        {[...Array(5)].map((_, index) => (
                            <Grid size={{ lg: 2.4, md: 4, sm: 6, xs: 12 }} key={index}>
                                <Card sx={{ height: '100%' }}>
                                    <CardContent>
                                        <Box display="flex" justifyContent="space-between" alignItems="center">
                                            <Box sx={{ flex: 1 }}>
                                                <Skeleton variant="text" width="40%" height={32} />
                                                <Skeleton variant="text" width="60%" height={24} sx={{ mt: 1 }} />
                                            </Box>
                                            <Skeleton variant="circular" width={56} height={56} />
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>
                </Box>

                {/* Search Section Skeleton */}
                <Box mt={2} mb={2}>
                    <Grid container spacing={2} justifyContent="space-between" alignItems="center">
                        <Grid size={{ lg: 8, md: 7, sm: 8, xs: 12 }}>
                            <Skeleton variant="text" width="40%" height={32} />
                            <Skeleton variant="text" width="60%" height={20} sx={{ mt: 1 }} />
                        </Grid>
                        <Grid size={{ lg: 2, md: 3, sm: 4, xs: 12 }}>
                            <Skeleton variant="rectangular" width="100%" height={40} sx={{ borderRadius: 1 }} />
                        </Grid>
                        <Grid size={{ lg: 2, md: 2, sm: 12, xs: 12 }}>
                            <Skeleton variant="rectangular" width="100%" height={40} sx={{ borderRadius: 1 }} />
                        </Grid>
                    </Grid>
                </Box>

                {/* Table Skeleton */}
                <Box className="simple-table-card">
                    <Skeleton variant="rectangular" width="100%" height={400} sx={{ borderRadius: 1 }} />
                </Box>
            </Container>
        </Box>
    </>
);

const DashboardStats = () => {

    // const { isAdmin } = useRoleAccess();

    const { employeeDetails, userRole, error } = useEmployeeStore()

    // Check if user is admin
    // const isAdmin = userRole === 'admin';

    const router = useRouter()

    // Get the last selected tab from localStorage, default to 0 if not found
    const getInitialTab = () => {
        if (typeof window !== 'undefined' && window.localStorage) {
            const savedTab = localStorage.getItem('dashboardSelectedTab');
            return savedTab ? parseInt(savedTab, 10) : 0;
        }
        return 0;
    };

    const [selectedTab, setSelectedTab] = useState(getInitialTab)
    const [selectedTimePeriod, setSelectedTimePeriod] = useState('all')
    const [customStartDate, setCustomStartDate] = useState('')
    const [customEndDate, setCustomEndDate] = useState('')
    const [documents, setDocuments] = useState([])
    const [loadingData, setLoadingData] = useState(true)
    const [apiError, setApiError] = useState(null)
    const [searchQuery, setSearchQuery] = useState('')
    const [isInitializing, setIsInitializing] = useState(false)


    const { isAdmin, isUser } = useRoleAccess();



    // Helper function to get month name from index
    const getMonthName = (monthIndex) => {
        const monthNames = [
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
        ];
        return monthNames[monthIndex];
    };

    // Helper function to generate dynamic time period options with brackets
    const getTimePeriodOptions = () => {
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();
        
        // Calculate previous month
        const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
        const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
        
        // Calculate last 3 months range
        const startMonth3 = currentMonth - 2 < 0 ? currentMonth + 10 : currentMonth - 2;
        const startYear3 = currentMonth - 2 < 0 ? currentYear - 1 : currentYear;
        
        // Calculate last 6 months range
        const startMonth6 = currentMonth - 5 < 0 ? currentMonth + 7 : currentMonth - 5;
        const startYear6 = currentMonth - 5 < 0 ? currentYear - 1 : currentYear;
        
        return [
            { value: 'all', label: 'All' },
            { value: 'current_month', label: `Current Month (${getMonthName(currentMonth)})` },
            { value: 'prev_month', label: `Prev Month (${getMonthName(prevMonth)})` },
            { value: 'last_3_months', label: `Last 3 Months (${getMonthName(startMonth3)} - ${getMonthName(currentMonth)})` },
            { value: 'last_6_months', label: `Last 6 Months (${getMonthName(startMonth6)} - ${getMonthName(currentMonth)})` },
            { value: 'current_financial_year', label: 'Current Financial Year (Apr - Mar)' },
            { value: 'custom_month_range', label: 'Custom Month Range' }
        ];
    };

    const timePeriodOptions = getTimePeriodOptions();

    // Tab configuration
    const tabs = [
        {
            title: 'Total',
            value: 'all',
            color: '#4CAF50',
            icon: <TrendingUp />,
            description: 'All documents from the beginning'
        },
        {
            title: 'In Progress',
            value: 'in_progress',
            color: '#FF9800',
            icon: <PendingActions />,
            description: 'Documents in progress this month'
        },
        {
            title: 'Under Review',
            value: 'under_review',
            color: '#2196F3',
            icon: <Assignment />,
            description: 'Documents under review this month'
        },
        {
            title: 'Approved',
            value: 'approved',
            color: '#4CAF50',
            icon: <CheckCircle />,
            description: 'Approved documents this month'
        },
        {
            title: 'Rejected',
            value: 'rejected',
            color: '#F44336',
            icon: <Error />,
            description: 'Rejected documents this month'
        }
    ]

    // Check for session on component mount
    useEffect(() => {
        console.log('🔐 Dashboard: Component mounted, checking session...');

        const sessionData = localStorage.getItem("session");
        if (!sessionData) {
            console.log('🔐 Dashboard: No session found, redirecting to login');
            router.push('/auth/sso-login');
        } else {
            // If we have a session but no employee details, we might be initializing
            if (!employeeDetails) {
                console.log('🔐 Dashboard: Session found but no employee details, might be initializing...');
                setIsInitializing(true);
            } else {
                // Employee details are loaded, stop initializing
                setIsInitializing(false);
            }
        }
    }, [employeeDetails]);

    // Fetch documents effect - always call this hook
    useEffect(() => {
        const fetchDocuments = async () => {
            try {
                console.log('🔐 Dashboard: Fetching documents...');
                setLoadingData(true)
                setApiError(null)

                // Get access token from localStorage
                const session = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('session') : null;
                let accessToken = '';
                if (session) {
                    try {
                        const sessionData = JSON.parse(session);
                        accessToken = sessionData.accessToken || '';
                        console.log('🔐 Dashboard: Found access token in localStorage');
                    } catch (error) {
                        console.error('🔐 Dashboard: Error parsing session data:', error);
                    }
                }

                if (!accessToken) {
                    console.error('🔐 Dashboard: No access token available');
                    setApiError('No access token available. Please login again.');
                    return;
                }

                console.log('🔐 Dashboard: Using access token for API call');

                // Use appropriate API based on user role for better performance
                let apiEndpoint, requestBody;

                if (userRole === 'admin') {
                    // Admin: Get all documents (no role checking)
                    apiEndpoint = '/api/client-mis-documents/get_all_documents';
                    requestBody = null;
                } else {
                    // User: Get documents created from templates they have access to
                    apiEndpoint = '/api/client-mis-documents/user-accessible';

                    // Get the display name using the same logic as the header
                    const getDisplayName = () => {
                        if (employeeDetails?.full_name) {
                            return employeeDetails.full_name;
                        }
                        if (employeeDetails?.name) {
                            return employeeDetails.name;
                        }
                        if (employeeDetails?.first_name && employeeDetails?.last_name) {
                            return `${employeeDetails.first_name} ${employeeDetails.last_name}`;
                        }
                        return 'User';
                    };

                    requestBody = {
                        userName: getDisplayName(),
                        employeeCode: employeeDetails?.employee_code || ''
                    };
                }

                console.log('🔐 Dashboard: Using API for user role:', userRole, '->', apiEndpoint);

                const fetchOptions = {
                    headers: {
                        'Authorization': `Bearer ${accessToken}`,
                        'Content-Type': 'application/json'
                    }
                };

                // Add body for POST requests
                if (requestBody) {
                    fetchOptions.method = 'POST';
                    fetchOptions.body = JSON.stringify(requestBody);
                }

                const response = await fetch(apiEndpoint, fetchOptions);

                console.log('🔐 Dashboard: API Response status:', response.status);
                if (response.ok) {
                    const data = await response.json();
                    console.log('🔐 Dashboard: API Response data:', data);
                    console.log(`🔐 Dashboard: Retrieved ${data.documents?.length || 0} documents using ${data.dataType || 'unknown'} API`);
                    setDocuments(data.documents || []);
                } else {
                    const errorText = await response.text();
                    console.error('🔐 Dashboard: Failed to fetch documents:', response.status, errorText);
                    setApiError(`Failed to fetch documents: ${response.status}`);
                }
            } catch (error) {
                console.error('🔐 Dashboard: Error fetching documents:', error);
                setApiError(`Error fetching documents: ${error.message}`);
            } finally {
                setLoadingData(false);
            }
        };

        if (employeeDetails) {
            fetchDocuments()
        }
    }, [employeeDetails, userRole || ''])

    // Recalculate counts when time period changes - always call this hook
    useEffect(() => {
        // This will trigger a re-render when selectedTimePeriod changes
        // The getTabCounts function will be called again with the new time period
    }, [selectedTimePeriod, customStartDate, customEndDate])

    // Show loading skeleton if no employee details or if initializing
    if (!employeeDetails || isInitializing) {
        console.log('🔐 Dashboard: No employee details or initializing, showing skeleton');
        return <DashboardSkeleton />;
    }

    // Show loading backdrop when API is loading
    if (loadingData) {
        return (
            <>
                <Box className="main-box">
                    <Container maxWidth>
                        {/* Show the dashboard structure but with loading state */}
                        <Box my={2}>
                            <Grid container spacing={2} alignItems="center" justifyContent="space-between">
                                <Grid size={{ lg: 8, md: 6, sm: 12, xs: 12 }}>
                                    <Typography variant="h4" className='page-heading'>
                                        <Box className="decorator" /> Dashboard Overview
                                        {/* {userRole === 'admin' ? 'Admin' : 'User'} */}
                                    </Typography>
                                </Grid>
                                <Grid size={{ lg: 2, md: 6, sm: 12, xs: 12 }}>
                                    <Box className="textfield auto-complete">
                                        <Autocomplete
                                            value={timePeriodOptions.find(option => option.value === selectedTimePeriod) || null}
                                        onChange={(event, newValue) => {
                                            setSelectedTimePeriod(newValue?.value || 'all')
                                        }}
                                            options={timePeriodOptions}
                                            getOptionLabel={(option) => option.label}
                                            isOptionEqualToValue={(option, value) => option.value === value.value}
                                            size="small"
                                            fullWidth
                                            renderInput={(params) => (
                                                <TextField
                                                    {...params}
                                                    label="Filter Documents"
                                                    variant="outlined"
                                                    size="small"
                                                />
                                            )}
                                        />
                                    </Box>
                                </Grid>

                                {userRole === "admin" && (
                                    <Grid size={{ lg: 2, md: 6, sm: 12, xs: 12 }}>
                                        <Button variant="outlined" disabled className='main-btn btn-primary' fullWidth endIcon={<TbMailFast />}>
                                            Send Monthly Report
                                        </Button>
                                    </Grid>
                                )}


                            </Grid>
                        </Box>

                        {/* Tab Cards with loading state */}
                        <Box mt={2}>
                            <Grid container spacing={2} sx={{ mb: 4 }}>
                                {tabs.map((tab, index) => (
                                    <Grid size={{ lg: 2.4, md: 4, sm: 6, xs: 12 }} key={index}>
                                        <Card
                                            sx={{
                                                height: '100%',
                                                background: selectedTab === index
                                                    ? `linear-gradient(90deg, #ffffff, ${tab.color}50)`
                                                    : `linear-gradient(90deg, #ffffff, ${tab.color}15)`,
                                                border: selectedTab === index
                                                    ? `2px solid ${tab.color}`
                                                    : `1px solid ${tab.color}30`,
                                                cursor: 'pointer',
                                                opacity: 0.7
                                            }}
                                            onClick={() => {
                                                setSelectedTab(index);
                                                if (typeof window !== 'undefined' && window.localStorage) {
                                                    localStorage.setItem('dashboardSelectedTab', index.toString());
                                                }
                                            }}
                                        >
                                            <CardContent>
                                                <Box display="flex" justifyContent="space-between" alignItems="center">
                                                    <Box sx={{ flex: 1 }}>
                                                        <Box display="flex" alignItems="center" gap={1}>
                                                            <CircularProgress size={42} sx={{ color: tab.color }} />
                                                            {/* <Typography variant="h4" component="div" sx={{
                                                                color: tab.color,
                                                                fontWeight: 'bold'
                                                            }}>
                                                                Loading...
                                                            </Typography> */}
                                                        </Box>
                                                        <Typography variant="h6" color="text.secondary" className='fw6' sx={{ mt: 1 }}>
                                                            {tab.title}
                                                        </Typography>
                                                    </Box>
                                                    <Avatar sx={{
                                                        bgcolor: tab.color,
                                                        width: 56,
                                                        height: 56,
                                                        ml: 1
                                                    }}>
                                                        {tab.icon}
                                                    </Avatar>
                                                </Box>
                                            </CardContent>
                                        </Card>
                                    </Grid>
                                ))}
                            </Grid>
                        </Box>

                        {/* Search Bar with loading state */}
                        <Box mt={2} mb={2}>
                            <Grid container spacing={2} justifyContent="space-between" alignItems="center">
                                <Grid size={{ lg: 8, md: 7, sm: 8, xs: 12 }}>
                                    <Typography variant="h4" className='page-heading'>
                                        <Box className="decorator2" sx={{ backgroundColor: tabs[selectedTab].color }} />   {tabs[selectedTab].title}
                                    </Typography>
                                    <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                                        Loading documents...
                                    </Typography>
                                </Grid>
                                <Grid size={{ lg: 2, md: 3, sm: 4, xs: 12 }}>
                                    <Box className="textfield ph2">
                                        <TextField
                                            fullWidth
                                            size="small"
                                            placeholder="Search by Client/Template/Document Name..."
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <Search />
                                                    </InputAdornment>
                                                ),
                                            }}
                                            disabled
                                        />
                                    </Box>
                                </Grid>
                                {userRole === "user" && (
                                    <Grid size={{ lg: 2, md: 2, sm: 12, xs: 12 }}>
                                        <Box>
                                            <Link href="/create-mis">
                                                <Button variant='outlined' fullWidth className='main-btn btn-secondary' startIcon={<HiOutlineDocumentPlus />}>New Document</Button>
                                            </Link>
                                        </Box>
                                    </Grid>
                                )}


                            </Grid>
                        </Box>

                        {/* Loading Table */}
                        <Box className="simple-table-card">
                            <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
                                <Box textAlign="center">
                                    <CircularProgress size={60} sx={{ mb: 2, color: 'primary.main' }} />
                                    <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                                        Loading Dashboard Data
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Please wait while we fetch your documents...
                                    </Typography>
                                </Box>
                            </Box>
                        </Box>
                    </Container>
                </Box>
            </>
        );
    }

    const getStatusColor = (status) => {
        switch (status?.toLowerCase()) {
            case 'draft': return '#B6B6B6'
            case 'in progress': return '#FF9800'
            case 'send for approval': return '#2196F3'
            case 'approved': return '#4CAF50'
            case 'rejected': return '#F44336'
            case 'completed': return '#9C27B0'
            default: return '#B6B6B6'
        }
    }

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        const datePart = date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        const timePart = date.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        });
        return `${datePart} <br/> ${timePart}`;
    }

    // Helper function to extract month and year from document name
    const extractMonthYearFromDocumentName = (documentName) => {
        if (!documentName) return null;
        
        // Pattern: dolat-capital-september-2025 or dolat-capital-mis-august-2025
        const monthNames = [
            'january', 'february', 'march', 'april', 'may', 'june',
            'july', 'august', 'september', 'october', 'november', 'december'
        ];
        
        const name = documentName.toLowerCase();
        const yearMatch = name.match(/(\d{4})$/);
        const monthMatch = monthNames.find(month => name.includes(month));
        
        if (yearMatch && monthMatch) {
            const year = parseInt(yearMatch[1]);
            const monthIndex = monthNames.indexOf(monthMatch);
            return { month: monthIndex, year: year, monthName: monthMatch };
        }
        
        return null;
    }

    // Helper function to get month/year range for filtering
    const getMonthYearRangeForTimePeriod = (timePeriod) => {
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();

        switch (timePeriod) {
            case 'all':
                return null; // Show all documents

            case 'current_month':
                return { 
                    startMonth: currentMonth, 
                    startYear: currentYear, 
                    endMonth: currentMonth, 
                    endYear: currentYear 
                };

            case 'prev_month':
                const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
                const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
                return { 
                    startMonth: prevMonth, 
                    startYear: prevYear, 
                    endMonth: prevMonth, 
                    endYear: prevYear 
                };

            case 'last_3_months':
                const startMonth3 = currentMonth - 2 < 0 ? currentMonth + 10 : currentMonth - 2;
                const startYear3 = currentMonth - 2 < 0 ? currentYear - 1 : currentYear;
                return { 
                    startMonth: startMonth3, 
                    startYear: startYear3, 
                    endMonth: currentMonth, 
                    endYear: currentYear 
                };

            case 'last_6_months':
                const startMonth6 = currentMonth - 5 < 0 ? currentMonth + 7 : currentMonth - 5;
                const startYear6 = currentMonth - 5 < 0 ? currentYear - 1 : currentYear;
                return { 
                    startMonth: startMonth6, 
                    startYear: startYear6, 
                    endMonth: currentMonth, 
                    endYear: currentYear 
                };

            case 'current_financial_year':
                // Financial year: April (3) to March (2)
                const fyStartMonth = currentMonth >= 3 ? 3 : 3; // April
                const fyStartYear = currentMonth >= 3 ? currentYear : currentYear - 1;
                const fyEndMonth = currentMonth >= 3 ? 2 : 2; // March
                const fyEndYear = currentMonth >= 3 ? currentYear + 1 : currentYear;
                return { 
                    startMonth: fyStartMonth, 
                    startYear: fyStartYear, 
                    endMonth: fyEndMonth, 
                    endYear: fyEndYear 
                };

            case 'custom_month_range':
                if (customStartDate && customEndDate) {
                    const startDate = new Date(customStartDate);
                    const endDate = new Date(customEndDate);
                    return {
                        startMonth: startDate.getMonth(),
                        startYear: startDate.getFullYear(),
                        endMonth: endDate.getMonth(),
                        endYear: endDate.getFullYear()
                    };
                }
                return null;

            default:
                return null;
        }
    }

    const getFilteredDocuments = () => {
        let filtered = documents

        // Apply time period filter based on document name
        if (selectedTimePeriod && selectedTimePeriod !== 'all') {
            const monthYearRange = getMonthYearRangeForTimePeriod(selectedTimePeriod)
            if (monthYearRange) {
                filtered = filtered.filter(doc => {
                    const docMonthYear = extractMonthYearFromDocumentName(doc.MIS_DOCUMENT_NAME)
                    if (!docMonthYear) return false;
                    
                    const docMonth = docMonthYear.month;
                    const docYear = docMonthYear.year;
                    
                    // Check if document month/year falls within the range
                    if (docYear < monthYearRange.startYear || docYear > monthYearRange.endYear) {
                        return false;
                    }
                    
                    if (docYear === monthYearRange.startYear && docMonth < monthYearRange.startMonth) {
                        return false;
                    }
                    
                    if (docYear === monthYearRange.endYear && docMonth > monthYearRange.endMonth) {
                        return false;
                    }
                    
                    return true;
                })
            }
        }

        // Apply search filter
        if (searchQuery) {
            filtered = filtered.filter(doc =>
                doc.MIS_DOCUMENT_NAME.toLowerCase().includes(searchQuery.toLowerCase()) ||
                doc.SSO_CLIENT_NAME.toLowerCase().includes(searchQuery.toLowerCase()) ||
                doc.TEMPLATE_NAME.toLowerCase().includes(searchQuery.toLowerCase())
            )
        }

        // Apply tab-specific filters
        switch (tabs[selectedTab].value) {
            case 'all':
                // Show all documents (no additional filter for first tab)
                break
            case 'in_progress':
                filtered = filtered.filter(doc =>
                    doc.STATUS?.toLowerCase() === 'in progress'
                )
                break
            case 'under_review':
                filtered = filtered.filter(doc =>
                    doc.STATUS?.toLowerCase() === 'send for approval'
                )
                break
            case 'approved':
                filtered = filtered.filter(doc =>
                    doc.STATUS?.toLowerCase() === 'approved'
                )
                break
            case 'rejected':
                filtered = filtered.filter(doc =>
                    doc.STATUS?.toLowerCase() === 'rejected'
                )
                break
            default:
                break
        }

        return filtered
    }

    const handleViewDocument = (documentName) => {
        router.push(`/mis/${documentName}`)
    }

    const filteredDocuments = getFilteredDocuments()

    // Calculate counts for each tab
    const getTabCounts = () => {
        // Get time period filtered documents for all tabs based on document name
        let timePeriodDocs = documents
        if (selectedTimePeriod && selectedTimePeriod !== 'all') {
            const monthYearRange = getMonthYearRangeForTimePeriod(selectedTimePeriod)
            if (monthYearRange) {
                timePeriodDocs = documents.filter(doc => {
                    const docMonthYear = extractMonthYearFromDocumentName(doc.MIS_DOCUMENT_NAME)
                    if (!docMonthYear) return false;
                    
                    const docMonth = docMonthYear.month;
                    const docYear = docMonthYear.year;
                    
                    // Check if document month/year falls within the range
                    if (docYear < monthYearRange.startYear || docYear > monthYearRange.endYear) {
                        return false;
                    }
                    
                    if (docYear === monthYearRange.startYear && docMonth < monthYearRange.startMonth) {
                        return false;
                    }
                    
                    if (docYear === monthYearRange.endYear && docMonth > monthYearRange.endMonth) {
                        return false;
                    }
                    
                    return true;
                })
            }
        }

        return {
            all: timePeriodDocs.length,
            in_progress: timePeriodDocs.filter(doc =>
                doc.STATUS?.toLowerCase() === 'in progress'
            ).length,
            under_review: timePeriodDocs.filter(doc =>
                doc.STATUS?.toLowerCase() === 'send for approval'
            ).length,
            approved: timePeriodDocs.filter(doc =>
                doc.STATUS?.toLowerCase() === 'approved'
            ).length,
            rejected: timePeriodDocs.filter(doc =>
                doc.STATUS?.toLowerCase() === 'rejected'
            ).length
        }
    }

    // Function to get dynamic description based on time period
    const getDynamicDescription = (tabValue) => {
        const timePeriodLabel = timePeriodOptions.find(option => option.value === selectedTimePeriod)?.label || 'All'

        switch (tabValue) {
            case 'all':
                return selectedTimePeriod === 'all' ? 'All documents' : `All documents for ${timePeriodLabel}`
            case 'in_progress':
                return selectedTimePeriod === 'all' ? 'Documents in progress' : `Documents in progress for ${timePeriodLabel}`
            case 'under_review':
                return selectedTimePeriod === 'all' ? 'Documents under review' : `Documents under review for ${timePeriodLabel}`
            case 'approved':
                return selectedTimePeriod === 'all' ? 'Approved documents' : `Approved documents for ${timePeriodLabel}`
            case 'rejected':
                return selectedTimePeriod === 'all' ? 'Rejected documents' : `Rejected documents for ${timePeriodLabel}`
            default:
                return ''
        }
    }

    const tabCounts = getTabCounts()

    // Show error alert if there's an error
    if (error || apiError) {
        return (
            <>
                <Box className="main-box">
                    <Container maxWidth>
                        <Alert severity="error" sx={{ mt: 2, mb: 2 }}>
                            {error || apiError}
                        </Alert>
                    </Container>
                </Box>
            </>
        );
    }

    return (
        <>
            <Box className="main-box">
                <Container maxWidth>
                    {/* Dashboard Header */}
                    <Box my={2}>
                        <Grid container spacing={2} alignItems="center" justifyContent="space-between">
                            <Grid size={{ lg: selectedTimePeriod === 'custom_month_range' ? (userRole === 'admin' ? 4 : 6) : 8, md: 6, sm: 12, xs: 12 }}>
                                <Typography variant="h4" className='page-heading'>
                                    <Box className="decorator" /> Dashboard Overview
                                </Typography>
                            </Grid>
                            <Grid size={{ lg: 2, md: 6, sm: 12, xs: 12 }}>
                                <Box className="textfield auto-complete">
                                    <Autocomplete
                                        value={timePeriodOptions.find(option => option.value === selectedTimePeriod) || null}
                                        onChange={(event, newValue) => {
                                            setSelectedTimePeriod(newValue?.value || 'all')
                                        }}
                                        options={timePeriodOptions}
                                        getOptionLabel={(option) => option.label}
                                        isOptionEqualToValue={(option, value) => option.value === value.value}
                                        size="small"
                                        fullWidth
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="Filter Documents"
                                                variant="outlined"
                                                size="small"
                                            />
                                        )}
                                    />
                                </Box>
                            </Grid>

                            {/* Custom Month Range Fields */}
                            {selectedTimePeriod === 'custom_month_range' && (
                                <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                                    <Box display="flex" gap={2} mt={0} justifyContent="flex-end">
                                        <SimpleDatePicker
                                            label="Start Month"
                                            value={customStartDate}
                                            onChange={(date) => setCustomStartDate(date)}
                                            monthYearOnly={true}
                                        />
                                        <SimpleDatePicker
                                            label="End Month"
                                            value={customEndDate}
                                            onChange={(date) => setCustomEndDate(date)}
                                            monthYearOnly={true}
                                        />
                                    </Box>
                                </Grid>
                            )}
                            {userRole === "admin" && (
                                <Grid size={{ lg: 2, md: 6, sm: 12, xs: 12 }}>
                                    <Button variant="outlined" disabled className='main-btn btn-primary' fullWidth endIcon={<TbMailFast />}>
                                        Send Monthly Report
                                    </Button>
                                </Grid>
                            )}
                        </Grid>
                    </Box>

                    {/* Tab Cards */}
                    <Box mt={2}>
                        <Grid container spacing={2} sx={{ mb: 4 }}>
                            {tabs.map((tab, index) => (
                                <Grid size={{ lg: 2.4, md: 4, sm: 6, xs: 12 }} key={index}>
                                    <Card
                                        sx={{
                                            height: '100%',
                                            background: selectedTab === index
                                                ? `linear-gradient(90deg, #ffffff, ${tab.color}50)`
                                                : `linear-gradient(90deg, #ffffff, ${tab.color}15)`,
                                            border: selectedTab === index
                                                ? `2px solid ${tab.color}`
                                                : `1px solid ${tab.color}30`,
                                            cursor: 'pointer'
                                        }}
                                        onClick={() => {
                                            setSelectedTab(index);
                                            // Save the selected tab to localStorage
                                            if (typeof window !== 'undefined' && window.localStorage) {
                                                localStorage.setItem('dashboardSelectedTab', index.toString());
                                            }
                                        }}
                                    >
                                        <CardContent>
                                            <Box display="flex" justifyContent="space-between" alignItems="center">
                                                <Box sx={{ flex: 1 }}>
                                                    <Typography variant="h4" component="div" sx={{
                                                        color: tab.color,
                                                        fontWeight: 'bold'
                                                    }}>
                                                        {tabCounts[tab.value]}
                                                    </Typography>

                                                    <Typography variant="h6" color="text.secondary" className='fw6' sx={{ mt: 1 }}>
                                                        {tab.title}
                                                    </Typography>
                                                </Box>
                                                <Avatar sx={{
                                                    bgcolor: tab.color,
                                                    width: 56,
                                                    height: 56,
                                                    ml: 1
                                                }}>
                                                    {tab.icon}
                                                </Avatar>
                                            </Box>
                                        </CardContent>
                                    </Card>
                                </Grid>
                            ))}
                        </Grid>
                    </Box>

                    {/* Search Bar */}
                    <Box mt={2} mb={2}>
                        <Grid container spacing={2} justifyContent="space-between" alignItems="center">
                            <Grid size={{ lg: 8, md: 7, sm: 8, xs: 12 }}>
                                <Typography variant="h4" className='page-heading'>
                                    <Box className="decorator2" sx={{ backgroundColor: tabs[selectedTab].color }} />   {tabs[selectedTab].title}
                                </Typography>
                                <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                                    {getDynamicDescription(tabs[selectedTab].value)}
                                </Typography>
                            </Grid>
                            <Grid size={{ lg: 2, md: 3, sm: 4, xs: 12 }}>
                                <Box className="textfield ph2">
                                    <TextField
                                        fullWidth
                                        size="small"
                                        placeholder="Search by Document Name..."
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Search />
                                                </InputAdornment>
                                            ),
                                        }}
                                    />
                                </Box>
                            </Grid>
                            {userRole === "user" && (
                                <Grid size={{ lg: 2, md: 2, sm: 12, xs: 12 }}>
                                    <Box>
                                        <Link href="/create-mis">
                                            <Button variant='outlined' fullWidth className='main-btn btn-secondary' startIcon={<HiOutlineDocumentPlus />}>New Document</Button>
                                        </Link>
                                    </Box>
                                </Grid>
                            )}
                        </Grid>
                    </Box>

                    {/* Documents Table */}
                    <Box className="simple-table-card">
                        {loadingData ? (
                            <Box display="flex" justifyContent="center" alignItems="center" minHeight="300px">
                                <Box textAlign="center">
                                    <CircularProgress size={40} sx={{ mb: 2, color: 'primary.main' }} />
                                    <Typography variant="body1" color="text.secondary">
                                        Loading documents...
                                    </Typography>
                                </Box>
                            </Box>
                        ) : (
                            <>
                                <DocumentsTable
                                    documents={filteredDocuments}
                                    loading={loadingData}
                                    error={apiError}
                                    searchQuery={searchQuery}
                                    user={employeeDetails}
                                    getStatusColor={getStatusColor}
                                    formatDate={formatDate}
                                    handleViewDocument={handleViewDocument}
                                />

                                {filteredDocuments.length > 0 && (
                                    <Box px={2} py={1} className="fx_sb" sx={{ mt: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
                                        <Typography variant="h6" color="text.secondary">
                                            Showing <span className='black fw7'>{filteredDocuments.length}</span> of {documents.length} documents
                                        </Typography>
                                    </Box>
                                )}
                            </>
                        )}
                    </Box>
                </Container>
            </Box>
        </>
    )
}

export default DashboardStats