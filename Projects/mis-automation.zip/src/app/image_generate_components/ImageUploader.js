"use client";
import React, { useState, useRef } from "react";
import {
    Button,
    Box,
    Container,
    Typography,
    IconButton,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    CircularProgress,
    Alert,
    Paper,
    Stack
} from "@mui/material";
import { CheckCircle, Error, CloudUpload, Close } from '@mui/icons-material';
import { IoClose } from "react-icons/io5";

const ImageUploader = ({ documentName = "", selectedInfographic = null, showSnackbar = null }) => {
    const fileInputRef = useRef(null);
    const [selectedFile, setSelectedFile] = useState(null);
    const [previewUrl, setPreviewUrl] = useState(null);
    const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
    const [uploadStatus, setUploadStatus] = useState('idle'); // 'idle', 'loading', 'success', 'error'
    const [uploadMessage, setUploadMessage] = useState('');
    const [uploadResult, setUploadResult] = useState(null);

    // Load selected infographic data when available
    React.useEffect(() => {
        if (selectedInfographic && selectedInfographic.filename) {
            console.log('📷 Loading selected infographic data:', selectedInfographic);
            setPreviewUrl(selectedInfographic.url || selectedInfographic.fileUrl);
        }
    }, [selectedInfographic]);

    const handleFileSelect = (event) => {
        const file = event.target.files[0];
        if (file) {
            // Validate file type
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            if (!allowedTypes.includes(file.type)) {
                if (showSnackbar) {
                    showSnackbar('Please select a valid image file (JPEG, PNG, GIF, WebP)', 'error');
                } else {
                    alert('Please select a valid image file (JPEG, PNG, GIF, WebP)');
                }
                return;
            }

            // Validate file size (max 1MB)
            const maxSize = 1 * 1024 * 1024; // 1MB
            if (file.size > maxSize) {
                if (showSnackbar) {
                    showSnackbar('File size must be less than 1MB', 'error');
                } else {
                    alert('File size must be less than 1MB');
                }
                return;
            }

            setSelectedFile(file);

            // Create preview URL
            const url = URL.createObjectURL(file);
            setPreviewUrl(url);
        }
    };

    const handleDragOver = (event) => {
        event.preventDefault();
    };

    const handleDrop = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            // Validate file type
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            if (!allowedTypes.includes(file.type)) {
                if (showSnackbar) {
                    showSnackbar('Please select a valid image file (JPEG, PNG, GIF, WebP)', 'error');
                } else {
                    alert('Please select a valid image file (JPEG, PNG, GIF, WebP)');
                }
                return;
            }

            // Validate file size (max 1MB)
            const maxSize = 1 * 1024 * 1024; // 1MB
            if (file.size > maxSize) {
                if (showSnackbar) {
                    showSnackbar('File size must be less than 1MB', 'error');
                } else {
                    alert('File size must be less than 1MB');
                }
                return;
            }

            setSelectedFile(file);

            // Create preview URL
            const url = URL.createObjectURL(file);
            setPreviewUrl(url);
        }
    };

    const handleUploadToOCI = async () => {
        if (!selectedFile) return;

        // Open dialog and set loading state
        setUploadDialogOpen(true);
        setUploadStatus('loading');
        setUploadMessage('Preparing image for upload...');

        try {
            console.log('📷 Starting upload to OCI for document:', documentName);

            setUploadMessage('Uploading to OCI...');

            // Create FormData for upload
            const formData = new FormData();
            formData.append('file', selectedFile);
            formData.append('documentName', documentName);
            formData.append('imageType', 'uploaded');

            console.log('📷 Uploading file:', selectedFile.name, 'for document:', documentName);

            // Get access token from localStorage
            const session = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('session') : null;
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Upload to OCI via our API
            const uploadResponse = await fetch('/api/infographics', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                },
                body: formData
            });

            if (!uploadResponse.ok) {
                const errorData = await uploadResponse.json();
                throw new Error(errorData.error || `Upload failed: ${uploadResponse.status}`);
            }

            const result = await uploadResponse.json();
            console.log('✅ Upload successful:', result);

            // Set success state
            setUploadStatus('success');
            setUploadResult(result);
            setUploadMessage('Image uploaded successfully!');

        } catch (error) {
            console.error('❌ Upload failed:', error);
            setUploadStatus('error');
            setUploadMessage('Unable to upload the file to OCI, try again after some time.');
        }
    };

    const handleCloseUploadDialog = () => {
        setUploadDialogOpen(false);
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
    };

    const handleRetryUpload = () => {
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
        handleUploadToOCI();
    };

    const handleClearSelection = () => {
        setSelectedFile(null);
        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
            setPreviewUrl(null);
        }
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    return (
        <>


            {/* File Upload Area */}
            <Paper
                sx={{
                    p: 4,
                    textAlign: 'center',
                    border: '2px dashed',
                    borderColor: 'primary.main',
                    backgroundColor: 'background.paper',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                        borderColor: 'primary.dark',
                        backgroundColor: 'action.hover'
                    }
                }}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
            >
                <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    style={{ display: 'none' }}
                />

                <CloudUpload sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" gutterBottom>
                    Upload Image
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    Click to select or drag and drop an image file
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
                    Supported formats: JPEG, PNG, GIF, WebP (Max size: 10MB)
                </Typography>
            </Paper>

            {/* Preview Section */}
            {previewUrl && (
                <Box sx={{ mt: 3 }}>
                    <Typography variant="h6" gutterBottom>
                        Image Preview
                    </Typography>
                    <Paper sx={{ p: 2, textAlign: 'center' }}>
                        <img
                            src={previewUrl}
                            alt="Preview"
                            style={{
                                maxWidth: '100%',
                                maxHeight: '400px',
                                objectFit: 'contain',
                                borderRadius: '8px'
                            }}
                        />
                        <Box sx={{ mt: 2 }}>
                            <Typography variant="body2" color="text.secondary">
                                {selectedFile?.name} ({(selectedFile?.size / 1024 / 1024).toFixed(2)} MB)
                            </Typography>
                        </Box>
                    </Paper>
                </Box>
            )}

            {/* Upload Button */}
            {selectedFile && (
                <Box sx={{ mt: 3, textAlign: 'center' }}>
                    <Stack direction="row" spacing={2} justifyContent="flex-end">
                        <Button
                            variant="outlined"
                            onClick={handleClearSelection}
                            startIcon={<Close />}
                            className="main-btn btn-tertiary"
                        >
                            Clear Selection
                        </Button>
                        <Button
                            variant="contained"
                            onClick={handleUploadToOCI}
                            disabled={!documentName}
                            title={!documentName ? "Document name is required for upload" : "Upload image to OCI"}
                            startIcon={<CloudUpload />}
                            className="main-btn btn-primary"
                        >
                            Upload to OCI
                        </Button>
                    </Stack>
                </Box>
            )}

            {/* Upload Progress Dialog */}
            <Dialog open={uploadDialogOpen} maxWidth="xs" fullWidth>
                <DialogContent>
                    <Box sx={{ textAlign: 'center', py: 2 }}>
                        {uploadStatus === 'loading' && (
                            <>
                                <CircularProgress sx={{ mb: 2 }} />
                                <Typography variant="body1">
                                    {uploadMessage}
                                </Typography>
                            </>
                        )}

                        {uploadStatus === 'success' && (
                            <>
                                <CheckCircle sx={{ fontSize: 48, color: 'success.main', mb: 2 }} />
                                <Typography variant="h6" color="success.main" gutterBottom>
                                    Upload Successful!
                                </Typography>
                                <Typography variant="body1" gutterBottom>
                                    {uploadMessage}
                                </Typography>
                            </>
                        )}

                        {uploadStatus === 'error' && (
                            <>
                                <Error sx={{ fontSize: 48, color: 'error.main', mb: 2 }} />
                                <Typography variant="h6" color="error.main" gutterBottom>
                                    Upload Failed
                                </Typography>
                                <Typography variant="body1" gutterBottom>
                                    {uploadMessage}
                                </Typography>
                            </>
                        )}
                    </Box>
                </DialogContent>
                <DialogActions className="custom-dialog-action">
                    <Box className="fx_c gap2 w100">
                        {uploadStatus === 'success' && (
                            <Button onClick={handleCloseUploadDialog} className="main-btn btn-primary" variant="contained">
                                Close
                            </Button>
                        )}
                        {uploadStatus === 'error' && (
                            <>
                                <Button onClick={handleCloseUploadDialog} variant="contained" className="main-btn btn-tertiary">
                                    Close
                                </Button>
                                <Button onClick={handleRetryUpload} variant="contained" className="main-btn btn-primary">
                                    Retry
                                </Button>
                            </>
                        )}
                    </Box>
                </DialogActions>
            </Dialog>
            {/* // </Container> */}
        </>
    );
};

export default ImageUploader;
