"use client";
import React, { useRef, useState, useEffect } from "react";
import {
    Chart as ChartJS,
    BarElement,
    CategoryScale,
    LinearScale,
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    RadialLinearScale,
    Filler
} from "chart.js";
import { Bar, Pie, Line, PolarArea, Radar, Doughnut } from "react-chartjs-2";
// import * as htmlToImage from "html-to-image";
import * as htmlToImage from "dom-to-image-more";
import { Button, TextField, Box, Grid, Container, Typography, IconButton, Switch, FormControlLabel, Stack, Select, MenuItem, FormControl, InputLabel, Dialog, DialogTitle, DialogContent, DialogActions, CircularProgress, Alert, Autocomplete } from "@mui/material";
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { MdDeleteOutline } from "react-icons/md";
import { CheckCircle, Error, CloudUpload } from '@mui/icons-material';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';


ChartJS.register(
    BarElement,
    CategoryScale,
    LinearScale,
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    RadialLinearScale,
    Filler
);

const ChartBuilder = ({ themeColors = [], documentName = "", selectedInfographic = null }) => {
    // Log the document name when component mounts or documentName changes
    useEffect(() => {
        if (documentName) {
            console.log('📊 ChartBuilder received document name:', documentName);
        }
    }, [documentName]);

    // Load selected infographic data when available
    useEffect(() => {
        if (selectedInfographic && selectedInfographic.originalData) {
            console.log('📊 Loading selected infographic data:', selectedInfographic);

            // Load chart data from the selected infographic
            const originalData = selectedInfographic.originalData;

            if (originalData.dataPoints) {
                setDataPoints(originalData.dataPoints);
            }
            if (originalData.dataPoints2) {
                setDataPoints2(originalData.dataPoints2);
            }
            if (originalData.type) {
                setType(originalData.type);
            }
            if (originalData.colors) {
                setColors(originalData.colors);
            }
            if (originalData.selectedColors) {
                setSelectedColors(originalData.selectedColors);
            }
            if (originalData.chartName) {
                setChartName(originalData.chartName);
            }
            if (originalData.legendPosition) {
                setLegendPosition(originalData.legendPosition);
            }
            if (originalData.showLegends !== undefined) {
                setShowLegends(originalData.showLegends);
            }
        }
    }, [selectedInfographic]);

    const chartRef = useRef(null);
    const [dataPoints, setDataPoints] = useState([
        { label: "Label 1", value: 10, color: themeColors[0] || "#1930ab" },
        { label: "Label 2", value: 20, color: themeColors[1] || "#fa7604" },
        { label: "Label 3", value: 30, color: themeColors[2] || "#4CAF50" }
    ]);
    const [dataPoints2, setDataPoints2] = useState([
        { label: "Label 1", value: 15, color: themeColors[1] || "#fa7604" },
        { label: "Label 2", value: 25, color: themeColors[2] || "#4CAF50" },
        { label: "Label 3", value: 35, color: themeColors[0] || "#1930ab" }
    ]); // For combo charts
    const [type, setType] = useState("bar");
    const [colors, setColors] = useState(themeColors.length > 0 ? themeColors.slice(0, 3) : ["#1930ab", "#fa7604", "#4CAF50"]);
    const [selectedColors, setSelectedColors] = useState({
        dataset1: themeColors[0] || "#1930ab",
        dataset2: themeColors[1] || "#fa7604"
    });
    const [chartName, setChartName] = useState("Chart");
    const [legendPosition, setLegendPosition] = useState("top");
    const [showLegends, setShowLegends] = useState(true);
    const [labelPosition, setLabelPosition] = useState("inside"); // "inside" or "outside"
    const [showArrows, setShowArrows] = useState(false); // Show arrows for outside labels

    // Dialog states for upload
    const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
    const [uploadStatus, setUploadStatus] = useState('idle'); // 'idle', 'loading', 'success', 'error'
    const [uploadMessage, setUploadMessage] = useState('');
    const [uploadResult, setUploadResult] = useState(null);

    // Update colors when themeColors prop changes
    useEffect(() => {
        if (themeColors.length > 0) {
            // Use theme colors for the chart (use as many as needed for the data points)
            const colorsToUse = themeColors.slice(0, Math.max(dataPoints.length, dataPoints2.length));
            setColors(colorsToUse);

            // Update selected colors if they're not in theme colors
            setSelectedColors(prev => ({
                dataset1: themeColors[0] || prev.dataset1,
                dataset2: themeColors[1] || prev.dataset2
            }));

            // Update data points colors if they don't have colors or if theme colors changed
            setDataPoints(prev => prev.map((dp, index) => ({
                ...dp,
                color: dp.color || themeColors[index % themeColors.length] || "#1930ab"
            })));

            setDataPoints2(prev => prev.map((dp, index) => ({
                ...dp,
                color: dp.color || themeColors[index % themeColors.length] || "#fa7604"
            })));
        }
    }, [themeColors, dataPoints.length, dataPoints2.length]);

    // Force chart re-render when label position or arrow settings change
    useEffect(() => {
        // This will trigger a re-render of the chart when label settings change
    }, [labelPosition, showArrows]);

    const handleDownload = async () => {
        if (!chartRef.current) return;

        await new Promise(resolve => setTimeout(resolve, 300)); // Reduced delay

        // Get the actual dimensions of the chart content
        const chartElement = chartRef.current;
        const chartRect = chartElement.getBoundingClientRect();

        // Calculate dynamic dimensions based on content
        const contentWidth = chartRect.width;
        const contentHeight = chartRect.height;
        const minWidth = 400; // Minimum width for charts
        const minHeight = 300; // Minimum height for charts
        const dynamicWidth = Math.max(contentWidth, minWidth);
        const dynamicHeight = Math.max(contentHeight, minHeight);

        // Ultra-high quality settings with canvas scaling
        const scaleFactor = 4; // Scale up the canvas for ultra-crisp images
        const scaledWidth = dynamicWidth * scaleFactor;
        const scaledHeight = dynamicHeight * scaleFactor;

        const dataUrl = await htmlToImage.toPng(chartRef.current, {
            cacheBust: true,
            backgroundColor: "#ffffff",
            width: scaledWidth,
            height: scaledHeight,
            quality: 1.0, // Maximum quality
            pixelRatio: 1, // Use 1 since we're scaling manually
            skipAutoScale: false, // Allow scaling for better quality
            useCORS: true, // Enable CORS for better image handling
            allowTaint: true, // Allow tainted canvas for better compatibility
            foreignObjectRendering: true, // Better rendering for complex elements
            style: {
                transform: `scale(${scaleFactor})`,
                transformOrigin: 'top left',
                width: `${dynamicWidth}px`,
                height: `${dynamicHeight}px`
            },
            filter: (node) => {
                // Ensure all text and elements are rendered at high quality
                if (node.nodeType === Node.ELEMENT_NODE) {
                    node.style.imageRendering = 'high-quality';
                    node.style.textRendering = 'optimizeLegibility';
                    node.style.fontSmooth = 'always';
                    node.style.webkitFontSmoothing = 'antialiased';
                    node.style.mozOsxFontSmoothing = 'grayscale';
                    node.style.fontDisplay = 'swap';
                    node.style.fontVariantLigatures = 'none';
                }
                return true;
            }
        });

        const filename = chartName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";

        const link = document.createElement("a");
        link.download = filename;
        link.href = dataUrl;
        link.click();
    };

    const handleUploadToOCI = async () => {
        if (!chartRef.current) return;

        // Open dialog and set loading state
        setUploadDialogOpen(true);
        setUploadStatus('loading');
        setUploadMessage('Preparing chart for upload...');

        try {
            console.log('📁 Starting upload to OCI for document:', documentName);

            setUploadMessage('Generating chart image...');
            await new Promise(resolve => setTimeout(resolve, 300)); // Reduced delay

            // Get the actual dimensions of the chart content
            const chartElement = chartRef.current;
            const chartRect = chartElement.getBoundingClientRect();

            // Calculate dynamic dimensions based on content
            const contentWidth = chartRect.width;
            const contentHeight = chartRect.height;
            const minWidth = 400; // Minimum width for charts
            const minHeight = 300; // Minimum height for charts
            const dynamicWidth = Math.max(contentWidth, minWidth);
            const dynamicHeight = Math.max(contentHeight, minHeight);

            setUploadMessage('Converting chart to image...');

            // Ultra-high quality settings with canvas scaling
            const scaleFactor = 4; // Scale up the canvas for ultra-crisp images
            const scaledWidth = dynamicWidth * scaleFactor;
            const scaledHeight = dynamicHeight * scaleFactor;

            const dataUrl = await htmlToImage.toPng(chartRef.current, {
                cacheBust: true,
                backgroundColor: "#ffffff",
                width: scaledWidth,
                height: scaledHeight,
                quality: 1.0, // Maximum quality
                pixelRatio: 1, // Use 1 since we're scaling manually
                skipAutoScale: false, // Allow scaling for better quality
                useCORS: true, // Enable CORS for better image handling
                allowTaint: true, // Allow tainted canvas for better compatibility
                foreignObjectRendering: true, // Better rendering for complex elements
                style: {
                    transform: `scale(${scaleFactor})`,
                    transformOrigin: 'top left',
                    width: `${dynamicWidth}px`,
                    height: `${dynamicHeight}px`
                },
                filter: (node) => {
                    // Ensure all text and elements are rendered at high quality
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        node.style.imageRendering = 'high-quality';
                        node.style.textRendering = 'optimizeLegibility';
                        node.style.fontSmooth = 'always';
                        node.style.webkitFontSmoothing = 'antialiased';
                        node.style.mozOsxFontSmoothing = 'grayscale';
                        node.style.fontDisplay = 'swap';
                        node.style.fontVariantLigatures = 'none';
                    }
                    return true;
                }
            });

            // Convert data URL to blob
            const response = await fetch(dataUrl);
            const blob = await response.blob();

            // Create a file from the blob
            const filename = chartName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";
            const file = new File([blob], filename, { type: 'image/png' });

            // Create FormData for upload
            const formData = new FormData();
            formData.append('file', file);
            formData.append('documentName', documentName);
            formData.append('chartType', type);
            formData.append('originalData', JSON.stringify({
                dataPoints: dataPoints,
                dataPoints2: dataPoints2,
                type: type,
                colors: colors,
                selectedColors: selectedColors,
                chartName: chartName,
                legendPosition: legendPosition,
                showLegends: showLegends
            }));

            console.log('📁 Uploading file:', filename, 'for document:', documentName);
            setUploadMessage('Uploading to OCI...');

            // Get access token from localStorage
            const session = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('session') : null;
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Upload to OCI via our API
            const uploadResponse = await fetch('/api/infographics', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                },
                body: formData
            });

            if (!uploadResponse.ok) {
                const errorData = await uploadResponse.json();
                throw new Error(errorData.error || `Upload failed: ${uploadResponse.status}`);
            }

            const result = await uploadResponse.json();
            console.log('✅ Upload successful:', result);

            // Set success state
            setUploadStatus('success');
            setUploadResult(result);
            setUploadMessage('Chart uploaded successfully!');

        } catch (error) {
            console.error('❌ Upload failed:', error);
            setUploadStatus('error');
            setUploadMessage('Unable to upload the file to OCI, try again after some time.');
        }
    };

    const handleCloseUploadDialog = () => {
        setUploadDialogOpen(false);
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
    };

    const handleRetryUpload = () => {
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
        handleUploadToOCI();
    };

    const getChartData = () => {
        const baseData = {
            labels: dataPoints.map(dp => dp.label),
            datasets: []
        };

        switch (type) {
            case "stack":
                return {
                    ...baseData,
                    datasets: [
                        {
                            label: "Dataset 1",
                            data: dataPoints.map(dp => dp.value),
                            backgroundColor: dataPoints.map(dp => dp.color),
                            stack: "Stack 0",
                        },
                        {
                            label: "Dataset 2",
                            data: dataPoints2.map(dp => dp.value),
                            backgroundColor: dataPoints2.map(dp => dp.color),
                            stack: "Stack 0",
                        }
                    ]
                };
            case "combo":
                return {
                    ...baseData,
                    datasets: [
                        {
                            label: "Bar Data",
                            data: dataPoints.map(dp => dp.value),
                            backgroundColor: selectedColors.dataset1,
                            type: "bar",
                            order: 2,
                        },
                        {
                            label: "Line Data",
                            data: dataPoints2.map(dp => dp.value),
                            borderColor: selectedColors.dataset2,
                            backgroundColor: "transparent",
                            type: "line",
                            order: 1,
                            borderWidth: 2,
                            fill: false,
                            tension: 0.4,
                        }
                    ]
                };
            default:
                return {
                    ...baseData,
                    datasets: [
                        {
                            label: chartName || "Data",
                            data: dataPoints.map(dp => dp.value),
                            backgroundColor: dataPoints.map(dp => dp.color),
                            borderColor: type === "line" ? dataPoints.map(dp => dp.color) : dataPoints.map(dp => dp.color),
                            borderWidth: type === "line" ? 2 : 1,
                            fill: type === "line" ? false : undefined,
                            tension: type === "line" ? 0.4 : undefined,
                        },
                    ]
                };
        }
    };

    const chartData = getChartData();

    // Chart data and settings
    console.log('Chart Data:', chartData);
    console.log('Label Position:', labelPosition);

    // Calculate max value for axis configuration - Force 5 axes
    const maxDataValue = Math.max(...dataPoints.map(dp => dp.value), ...(dataPoints2.map(dp => dp.value)));
    const axisMax = Math.max(maxDataValue + 3, 5); // Ensure minimum of 5 axes
    const stepSize = Math.ceil(axisMax / 5); // Always 5 steps

    const chartOptions = {
        responsive: false, // Important to fix canvas size
        maintainAspectRatio: false,
        indexAxis: type === "bar" ? 'y' : 'x', // Horizontal for bar, vertical for column
        // High-DPI and quality settings
        devicePixelRatio: 4, // High DPI for crisp rendering
        animation: {
            duration: 0, // Disable animations for better quality
            onComplete: function () {
                console.log('Animation onComplete called');
                const chart = this;
                const ctx = chart.ctx;
                ctx.font = 'bold 12px Calibri, Arial, sans-serif';

                const isCircularChart = type === "pie" || type === "doughnut" || type === "polar" || type === "radar";
                console.log('Chart type:', type, 'Is circular:', isCircularChart);

                // Test: Draw a red dot to verify this is working
                ctx.fillStyle = 'red';
                ctx.fillRect(10, 10, 5, 5);

                // Set text properties
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';

                if (isCircularChart) {
                    // Handle circular charts
                    chart.data.datasets.forEach((dataset, datasetIndex) => {
                        chart.getDatasetMeta(datasetIndex).data.forEach((segment, index) => {
                            const data = dataset.data[index];
                            if (data !== null && data !== undefined) {
                                const segment = chart.getDatasetMeta(datasetIndex).data[index];
                                const position = segment.tooltipPosition();

                                if (labelPosition === 'inside') {
                                    ctx.fillStyle = '#fff';
                                    ctx.fillText(data.toString(), position.x, position.y);
                                } else {
                                    ctx.fillStyle = '#000';
                                    ctx.fillText(data.toString(), position.x, position.y);
                                }
                            }
                        });
                    });
                } else {
                    // Handle bar/column charts
                    console.log('Processing bar/column charts');
                    chart.data.datasets.forEach((dataset, datasetIndex) => {
                        console.log('Dataset:', datasetIndex, 'Data:', dataset.data);
                        chart.getDatasetMeta(datasetIndex).data.forEach((bar, index) => {
                            const data = dataset.data[index];
                            console.log('Bar data:', data, 'at index:', index, 'Position:', bar.x, bar.y);
                            if (data !== null && data !== undefined) {
                                const x = bar.x;
                                const y = bar.y;
                                const width = bar.width;
                                const height = bar.height;

                                console.log('Bar dimensions:', { x, y, width, height });

                                if (labelPosition === 'inside') {
                                    // Inside labels - ensure proper positioning
                                    console.log('Drawing inside label for data:', data, 'at position:', x, y);
                                    ctx.fillStyle = '#000'; // Changed to black for better visibility
                                    ctx.font = 'bold 14px Calibri, Arial, sans-serif';
                                    ctx.textAlign = 'center';
                                    ctx.textBaseline = 'middle';

                                    // For vertical bars, position in center of bar
                                    const labelX = x;
                                    const labelY = y;

                                    console.log('Drawing text at:', labelX, labelY);
                                    ctx.fillText(data.toString(), labelX, labelY);

                                    // Also draw a background circle for better visibility
                                    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
                                    ctx.beginPath();
                                    ctx.arc(labelX, labelY, 12, 0, 2 * Math.PI);
                                    ctx.fill();

                                    // Draw text again on top
                                    ctx.fillStyle = '#000';
                                    ctx.fillText(data.toString(), labelX, labelY);
                                } else {
                                    // Outside labels
                                    console.log('Drawing outside label for data:', data);
                                    ctx.fillStyle = '#000';
                                    ctx.font = 'bold 12px Calibri, Arial, sans-serif';

                                    if (type === 'bar') {
                                        // Horizontal bar chart - labels to the right
                                        ctx.textAlign = 'left';
                                        ctx.textBaseline = 'middle';
                                        ctx.fillText(data.toString(), x + (width / 2) + 10, y);
                                    } else {
                                        // Vertical bar chart - labels above
                                        ctx.textAlign = 'center';
                                        ctx.textBaseline = 'middle';
                                        ctx.fillText(data.toString(), x, y - (height / 2) - 10);
                                    }
                                }
                            }
                        });
                    });
                }
            }
        },
        interaction: {
            intersect: false
        },
        plugins: {
            legend: {
                position: legendPosition,
                display: showLegends,
                labels: {
                    font: {
                        family: 'Calibri, Arial, sans-serif',
                        size: 14, // Adjusted font size for better fit
                        weight: 'bold'
                    },
                    color: "#000",
                    usePointStyle: true, // Use point style for better visibility
                    boxWidth: 15, // Larger for better visibility
                    boxHeight: 15, // Larger for better visibility
                    padding: 15, // Increased padding for better spacing
                    generateLabels: function (chart) {
                        const data = chart.data;
                        if (data.labels.length && data.datasets.length) {
                            const dataset = data.datasets[0];
                            return data.labels.map((label, i) => {
                                const color = Array.isArray(dataset.backgroundColor) ? dataset.backgroundColor[i] : dataset.backgroundColor;
                                return {
                                    text: label, // Only show label, not value
                                    fillStyle: color,
                                    strokeStyle: color,
                                    lineWidth: 0,
                                    hidden: false,
                                    index: i
                                };
                            });
                        }
                        return [];
                    }
                },
                padding: 20, // Increased padding for better spacing
                margin: 20 // Increased margin for better spacing
            },
            tooltip: {
                callbacks: {
                    label: function (context) {
                        return `${context.dataset.label || ''}: ${context.parsed.y || context.parsed}`;
                    }
                }
            },
            // Custom plugin to display data labels
            customCanvasBackgroundColor: {
                color: 'white',
            },
            // Data labels - using Chart.js built-in functionality
            datalabels: {
                display: false // Disable if plugin not available
            }
        },
        scales: (type === "line" || type === "bar" || type === "stack" || type === "column" || type === "combo") ? {
            x: type === "bar" ? {
                // For horizontal bar chart, X axis shows values
                type: 'linear',
                position: 'bottom',
                ticks: {
                    font: {
                        family: 'Calibri, Arial, sans-serif',
                        size: 14, // Increased font size for better quality
                        weight: 'bold'
                    },
                    color: "#000",
                    maxTicksLimit: 5,
                    max: axisMax,
                    stepSize: stepSize,
                    callback: function (value, index, values) {
                        return value;
                    }
                },
                grid: {
                    display: true
                }
            } : {
                // For vertical charts, X axis shows labels
                type: 'category',
                position: 'bottom',
                ticks: {
                    font: {
                        family: 'Calibri, Arial, sans-serif',
                        size: 14, // Increased font size for better quality
                        weight: 'bold'
                    },
                    color: "#000",
                    maxTicksLimit: 5
                },
                grid: {
                    display: false
                }
            },
            y: type === "bar" ? {
                // For horizontal bar chart, Y axis shows labels
                type: 'category',
                position: 'left',
                ticks: {
                    font: {
                        family: 'Calibri, Arial, sans-serif',
                        size: 14, // Increased font size for better quality
                        weight: 'bold'
                    },
                    color: "#000",
                    maxTicksLimit: 5
                },
                grid: {
                    display: false
                }
            } : {
                // For vertical charts, Y axis shows values
                type: 'linear',
                position: 'left',
                ticks: {
                    font: {
                        family: 'Calibri, Arial, sans-serif',
                        size: 14, // Increased font size for better quality
                        weight: 'bold'
                    },
                    color: "#000",
                    maxTicksLimit: 5,
                    max: axisMax,
                    stepSize: stepSize,
                    callback: function (value, index, values) {
                        return value;
                    }
                },
                grid: {
                    display: true
                }
            }
        } : undefined,
        elements: {
            bar: {
                borderWidth: 0,
                borderRadius: 4,
                borderSkipped: false,
            }
        }
    };


    // High-quality rendering plugin
    const highQualityPlugin = {
        id: 'highQualityRendering',
        beforeDraw: function (chart) {
            const ctx = chart.ctx;
            // Set high-quality rendering context
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            ctx.textRenderingOptimization = 'optimizeQuality';
        }
    };

    // Create a proper data labels plugin
    const dataLabelsPlugin = {
        id: 'dataLabels',
        afterDraw: function (chart) {
            console.log('Data labels plugin called');
            const ctx = chart.ctx;
            ctx.font = 'bold 12px Calibri, Arial, sans-serif';

            const isCircularChart = type === "pie" || type === "doughnut" || type === "polar" || type === "radar";
            console.log('Chart type:', type, 'Is circular:', isCircularChart);

            // Test: Draw a red dot to verify this is working
            ctx.fillStyle = 'red';
            ctx.fillRect(10, 10, 5, 5);

            // Set text properties
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            if (isCircularChart) {
                // Handle circular charts
                chart.data.datasets.forEach((dataset, datasetIndex) => {
                    chart.getDatasetMeta(datasetIndex).data.forEach((segment, index) => {
                        const data = dataset.data[index];
                        if (data !== null && data !== undefined) {
                            const segment = chart.getDatasetMeta(datasetIndex).data[index];
                            const position = segment.tooltipPosition();

                            if (labelPosition === 'inside') {
                                ctx.fillStyle = '#fff';
                                ctx.fillText(data.toString(), position.x, position.y);
                            } else {
                                ctx.fillStyle = '#000';
                                ctx.fillText(data.toString(), position.x, position.y);
                            }
                        }
                    });
                });
            } else {
                // Handle bar/column charts
                console.log('Processing bar/column charts');
                chart.data.datasets.forEach((dataset, datasetIndex) => {
                    console.log('Dataset:', datasetIndex, 'Data:', dataset.data);
                    chart.getDatasetMeta(datasetIndex).data.forEach((bar, index) => {
                        const data = dataset.data[index];
                        console.log('Bar data:', data, 'at index:', index, 'Position:', bar.x, bar.y);
                        if (data !== null && data !== undefined) {
                            const x = bar.x;
                            const y = bar.y;
                            const width = bar.width;
                            const height = bar.height;

                            console.log('Bar dimensions:', { x, y, width, height });

                            if (labelPosition === 'inside') {
                                // Inside labels - ensure proper positioning
                                console.log('Drawing inside label for data:', data, 'at position:', x, y);
                                ctx.fillStyle = '#000'; // Changed to black for better visibility
                                ctx.font = 'bold 14px Calibri, Arial, sans-serif';
                                ctx.textAlign = 'center';
                                ctx.textBaseline = 'middle';

                                // For vertical bars, position in center of bar
                                const labelX = x;
                                const labelY = y;

                                console.log('Drawing text at:', labelX, labelY);
                                ctx.fillText(data.toString(), labelX, labelY);

                                // Also draw a background circle for better visibility
                                ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
                                ctx.beginPath();
                                ctx.arc(labelX, labelY, 12, 0, 2 * Math.PI);
                                ctx.fill();

                                // Draw text again on top
                                ctx.fillStyle = '#000';
                                ctx.fillText(data.toString(), labelX, labelY);
                            } else {
                                // Outside labels
                                console.log('Drawing outside label for data:', data);
                                ctx.fillStyle = '#000';
                                ctx.font = 'bold 12px Calibri, Arial, sans-serif';

                                if (type === 'bar') {
                                    // Horizontal bar chart - labels to the right
                                    ctx.textAlign = 'left';
                                    ctx.textBaseline = 'middle';
                                    ctx.fillText(data.toString(), x + (width / 2) + 10, y);
                                } else {
                                    // Vertical bar chart - labels above
                                    ctx.textAlign = 'center';
                                    ctx.textBaseline = 'middle';
                                    ctx.fillText(data.toString(), x, y - (height / 2) - 10);
                                }
                            }
                        }
                    });
                });
            }
        }
    };

    // Add plugins to options
    chartOptions.plugins.highQualityRendering = highQualityPlugin;
    chartOptions.plugins.dataLabels = dataLabelsPlugin;

    const renderChart = () => {
        // High-quality dimensions that fit within the container
        const isCircularChart = type === "pie" || type === "doughnut" || type === "polar" || type === "radar";
        const chartWidth = isCircularChart ? 350 : 700; // Adjusted to fit within 800px container with padding
        const chartHeight = isCircularChart ? 350 : 350; // Adjusted height for proper fit

        const commonProps = {
            data: chartData,
            options: chartOptions,
            width: chartWidth,
            height: chartHeight,
            // Add high-DPI support
            style: {
                imageRendering: 'high-quality',
                textRendering: 'optimizeLegibility'
            }
        };

        // Force re-render when data changes
        const chartKey = `${type}-${labelPosition}-${showArrows}-${JSON.stringify(dataPoints.map(dp => dp.color))}`;

        switch (type) {
            case "bar":
                return <Bar key={chartKey} {...commonProps} />;
            case "column":
            case "stack":
                return <Bar key={chartKey} {...commonProps} />;
            case "pie":
                return <Pie key={chartKey} {...commonProps} />;
            case "line":
                return <Line key={chartKey} {...commonProps} />;
            case "polar":
                return <PolarArea key={chartKey} {...commonProps} />;
            case "radar":
                return <Radar key={chartKey} {...commonProps} />;
            case "doughnut":
                return <Doughnut key={chartKey} {...commonProps} />;
            case "combo":
                return <Bar key={chartKey} {...commonProps} />;
            default:
                return <Bar key={chartKey} {...commonProps} />;
        }
    };

    const showSecondDataset = type === "stack" || type === "combo";
    const showColorSelection = type === "combo"; // Only show color selection for combo charts

    return (
        <>
            <Box>
                {/* {documentName && (
                    <Box sx={{ mb: 2, p: 2, bgcolor: 'primary.main', color: 'white', borderRadius: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                            📄 Document: {documentName}
                        </Typography>
                    </Box>
                )} */}
                {selectedInfographic && (
                    <Box sx={{
                        mb: 2,
                        p: 1,
                        color: '#000000',
                        borderRadius: 1,
                        borderLeft: '4px solid var(--success)',
                        backgroundColor: '#f2f2f2',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1
                    }}>
                        <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            Viewing: {selectedInfographic.filename}
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.8 }}>
                            (Click "Upload to OCI" to regenerate this chart)
                        </Typography>
                    </Box>
                )}
                <Grid container alignItems="stretch" spacing={2} mb={2}>
                    <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                        <Box sx={{ background: '#f2f2f2', padding: '20px', height: '100%' }}>
                            <Grid container spacing={2} mb={2}>
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box className="textfield auto-complete">
                                        <TextField
                                            label="Chart Name [use section name]"
                                            fullWidth
                                            size="small"
                                            value={chartName}
                                            onChange={(e) => setChartName(e.target.value)}
                                        />
                                    </Box>
                                </Grid>
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mb={0}>

                                        <Box mb={2}>
                                            <Typography variant="h6" className="black" gutterBottom>
                                                Data Points
                                            </Typography>
                                        </Box>

                                        {dataPoints.map((dp, index) => (
                                            <Box key={index} display="flex" alignItems="center" gap={1} mt={1} mb={2}>
                                                <Box className="textfield sm auto-complete">
                                                    <Autocomplete
                                                        size="small"
                                                        options={themeColors.map((color, colorIndex) => ({ color, label: `Color ${colorIndex + 1}` }))}
                                                        getOptionLabel={(option) => option.label}
                                                        value={themeColors.map((color, colorIndex) => ({ color, label: `Color ${colorIndex + 1}` })).find(option => option.color === dp.color)}
                                                        onChange={(event, newValue) => {
                                                            if (newValue) {
                                                                const newDataPoints = [...dataPoints];
                                                                newDataPoints[index] = { ...newDataPoints[index], color: newValue.color };
                                                                setDataPoints(newDataPoints);
                                                            }
                                                        }}
                                                        renderOption={(props, option) => (
                                                            <Box component="li" {...props}>
                                                                <Box
                                                                    sx={{
                                                                        width: 16,
                                                                        height: 16,
                                                                        borderRadius: '50%',
                                                                        backgroundColor: option.color,
                                                                        border: '1px solid #ddd',
                                                                        mr: 1
                                                                    }}
                                                                />
                                                                {option.label}
                                                            </Box>
                                                        )}
                                                        renderInput={(params) => (
                                                            <TextField
                                                                {...params}
                                                                size="small"
                                                                sx={{ minWidth: 80 }}
                                                                InputProps={{
                                                                    ...params.InputProps,
                                                                    startAdornment: (
                                                                        <Box
                                                                            sx={{
                                                                                width: 16,
                                                                                height: 16,
                                                                                borderRadius: '50%',
                                                                                backgroundColor: dp.color,
                                                                                border: '1px solid #ddd',
                                                                                mr: 1
                                                                            }}
                                                                        />
                                                                    )
                                                                }}
                                                            />
                                                        )}
                                                    />
                                                </Box>
                                                <Box className="textfield sm auto-complete">
                                                    <TextField
                                                        label={`Label ${index + 1}`}
                                                        fullWidth
                                                        size="small"
                                                        value={dp.label}
                                                        onChange={(e) => {
                                                            const newDataPoints = [...dataPoints];
                                                            newDataPoints[index] = { ...newDataPoints[index], label: e.target.value };
                                                            setDataPoints(newDataPoints);
                                                        }}
                                                    />
                                                </Box>
                                                <Box className="textfield sm auto-complete">
                                                    <TextField
                                                        label={`Value ${index + 1}`}
                                                        fullWidth
                                                        size="small"
                                                        value={dp.value}
                                                        onChange={(e) => {
                                                            const newDataPoints = [...dataPoints];
                                                            newDataPoints[index] = { ...newDataPoints[index], value: Number(e.target.value) };
                                                            setDataPoints(newDataPoints);
                                                        }}
                                                        type="number"
                                                        step="any"
                                                    />
                                                </Box>
                                                <IconButton
                                                    className="action-ico-btn error"
                                                    onClick={() => {
                                                        const newDataPoints = dataPoints.filter((_, i) => i !== index);
                                                        setDataPoints(newDataPoints);
                                                    }}
                                                    size="small"
                                                    color="error"
                                                    aria-label="delete"
                                                >
                                                    <MdDeleteOutline />
                                                </IconButton>
                                            </Box>
                                        ))}
                                        <Button
                                            variant="outlined"
                                            onClick={() => {
                                                const newColor = themeColors[dataPoints.length % themeColors.length] || "#1930ab";
                                                setDataPoints([...dataPoints, { label: "", value: 0, color: newColor }]);
                                            }}
                                            size="small"
                                            className="main-btn sm btn-primary"
                                            startIcon={<AddOutlinedIcon />}
                                        >
                                            Add Data Point
                                        </Button>
                                    </Box>
                                </Grid>
                                {showSecondDataset && (
                                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                        <Box mt={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                            <Box mt={2} mb={2}>
                                                <Typography variant="h6" className="black" gutterBottom>
                                                    Data Points 2
                                                </Typography>
                                            </Box>
                                            {dataPoints2.map((dp, index) => (
                                                <Box key={index} display="flex" alignItems="center" gap={1} mt={1} mb={2}>
                                                    <Autocomplete
                                                        size="small"
                                                        options={themeColors.map((color, colorIndex) => ({ color, label: `Color ${colorIndex + 1}` }))}
                                                        getOptionLabel={(option) => option.label}
                                                        value={themeColors.map((color, colorIndex) => ({ color, label: `Color ${colorIndex + 1}` })).find(option => option.color === dp.color)}
                                                        onChange={(event, newValue) => {
                                                            if (newValue) {
                                                                const newDataPoints2 = [...dataPoints2];
                                                                newDataPoints2[index] = { ...newDataPoints2[index], color: newValue.color };
                                                                setDataPoints2(newDataPoints2);
                                                            }
                                                        }}
                                                        renderOption={(props, option) => (
                                                            <Box component="li" {...props}>
                                                                <Box
                                                                    sx={{
                                                                        width: 16,
                                                                        height: 16,
                                                                        borderRadius: '50%',
                                                                        backgroundColor: option.color,
                                                                        border: '1px solid #ddd',
                                                                        mr: 1
                                                                    }}
                                                                />
                                                                {option.label}
                                                            </Box>
                                                        )}
                                                        renderInput={(params) => (
                                                            <TextField
                                                                {...params}
                                                                size="small"
                                                                sx={{ minWidth: 80 }}
                                                                InputProps={{
                                                                    ...params.InputProps,
                                                                    startAdornment: (
                                                                        <Box
                                                                            sx={{
                                                                                width: 16,
                                                                                height: 16,
                                                                                borderRadius: '50%',
                                                                                backgroundColor: dp.color,
                                                                                border: '1px solid #ddd',
                                                                                mr: 1
                                                                            }}
                                                                        />
                                                                    )
                                                                }}
                                                            />
                                                        )}
                                                    />
                                                    <Box className="textfield sm auto-complete">
                                                        <TextField
                                                            label={`Label ${index + 1}`}
                                                            fullWidth
                                                            size="small"
                                                            value={dp.label}
                                                            onChange={(e) => {
                                                                const newDataPoints2 = [...dataPoints2];
                                                                newDataPoints2[index] = { ...newDataPoints2[index], label: e.target.value };
                                                                setDataPoints2(newDataPoints2);
                                                            }}
                                                        />
                                                    </Box>
                                                    <Box className="textfield sm auto-complete">
                                                        <TextField
                                                            label={`Value ${index + 1}`}
                                                            fullWidth
                                                            size="small"
                                                            value={dp.value}
                                                            onChange={(e) => {
                                                                const newDataPoints2 = [...dataPoints2];
                                                                newDataPoints2[index] = { ...newDataPoints2[index], value: Number(e.target.value) };
                                                                setDataPoints2(newDataPoints2);
                                                            }}
                                                            type="number"
                                                            step="any"
                                                        />
                                                    </Box>
                                                    <IconButton
                                                        onClick={() => {
                                                            const newDataPoints2 = dataPoints2.filter((_, i) => i !== index);
                                                            setDataPoints2(newDataPoints2);
                                                        }}
                                                        size="small"
                                                        color="error"
                                                        aria-label="delete"
                                                        className="action-ico-btn error"
                                                    >
                                                        <MdDeleteOutline />
                                                    </IconButton>
                                                </Box>
                                            ))}
                                            <Button
                                                variant="outlined"
                                                onClick={() => {
                                                    const newColor = themeColors[dataPoints2.length % themeColors.length] || "#fa7604";
                                                    setDataPoints2([...dataPoints2, { label: "", value: 0, color: newColor }]);
                                                }}
                                                size="small"
                                                className="main-btn sm btn-primary"
                                                startIcon={<AddOutlinedIcon />}
                                            >
                                                Add Data Point
                                            </Button>
                                        </Box>
                                    </Grid>
                                )}
                                {showColorSelection && (
                                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                        <Box mt={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                            <Typography variant="h6" gutterBottom sx={{ pt: 2 }}>
                                                Dataset Colors
                                            </Typography>
                                            <Box display="flex" gap={2} flexWrap="wrap" alignItems="center" pt={1}>
                                                <Box display="flex" alignItems="center" gap={1} sx={{ minWidth: '200px' }}>
                                                    <Typography variant="body2">Dataset 1:</Typography>
                                                    <Autocomplete
                                                        size="small"
                                                        options={themeColors.map((color, index) => ({ color, label: `Color ${index + 1}` }))}
                                                        getOptionLabel={(option) => option.label}
                                                        value={themeColors.map((color, index) => ({ color, label: `Color ${index + 1}` })).find(option => option.color === selectedColors.dataset1)}
                                                        onChange={(event, newValue) => {
                                                            if (newValue) {
                                                                setSelectedColors(prev => ({ ...prev, dataset1: newValue.color }));
                                                            }
                                                        }}
                                                        renderOption={(props, option) => (
                                                            <Box component="li" {...props}>
                                                                <Box
                                                                    sx={{
                                                                        width: 16,
                                                                        height: 16,
                                                                        borderRadius: '50%',
                                                                        backgroundColor: option.color,
                                                                        border: '1px solid #ddd',
                                                                        mr: 1
                                                                    }}
                                                                />
                                                                {option.label}
                                                            </Box>
                                                        )}
                                                        renderInput={(params) => (
                                                            <TextField
                                                                {...params}
                                                                size="small"
                                                                sx={{ minWidth: 120 }}
                                                                InputProps={{
                                                                    ...params.InputProps,
                                                                    startAdornment: (
                                                                        <Box
                                                                            sx={{
                                                                                width: 16,
                                                                                height: 16,
                                                                                borderRadius: '50%',
                                                                                backgroundColor: selectedColors.dataset1,
                                                                                border: '1px solid #ddd',
                                                                                mr: 1
                                                                            }}
                                                                        />
                                                                    )
                                                                }}
                                                            />
                                                        )}
                                                    />
                                                </Box>
                                                <Box display="flex" alignItems="center" gap={1} sx={{ minWidth: '200px' }}>
                                                    <Typography variant="body2">Dataset 2:</Typography>
                                                    <Autocomplete
                                                        size="small"
                                                        options={themeColors.map((color, index) => ({ color, label: `Color ${index + 1}` }))}
                                                        getOptionLabel={(option) => option.label}
                                                        value={themeColors.map((color, index) => ({ color, label: `Color ${index + 1}` })).find(option => option.color === selectedColors.dataset2)}
                                                        onChange={(event, newValue) => {
                                                            if (newValue) {
                                                                setSelectedColors(prev => ({ ...prev, dataset2: newValue.color }));
                                                            }
                                                        }}
                                                        renderOption={(props, option) => (
                                                            <Box component="li" {...props}>
                                                                <Box
                                                                    sx={{
                                                                        width: 16,
                                                                        height: 16,
                                                                        borderRadius: '50%',
                                                                        backgroundColor: option.color,
                                                                        border: '1px solid #ddd',
                                                                        mr: 1
                                                                    }}
                                                                />
                                                                {option.label}
                                                            </Box>
                                                        )}
                                                        renderInput={(params) => (
                                                            <TextField
                                                                {...params}
                                                                size="small"
                                                                sx={{ minWidth: 120 }}
                                                                InputProps={{
                                                                    ...params.InputProps,
                                                                    startAdornment: (
                                                                        <Box
                                                                            sx={{
                                                                                width: 16,
                                                                                height: 16,
                                                                                borderRadius: '50%',
                                                                                backgroundColor: selectedColors.dataset2,
                                                                                border: '1px solid #ddd',
                                                                                mr: 1
                                                                            }}
                                                                        />
                                                                    )
                                                                }}
                                                            />
                                                        )}
                                                    />
                                                </Box>
                                            </Box>
                                        </Box>
                                    </Grid>
                                )}

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1} px={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                        <FormControlLabel
                                            sx={{ pt: 2 }}
                                            control={
                                                <Switch
                                                    size="small"
                                                    checked={showLegends}
                                                    onChange={(e) => setShowLegends(e.target.checked)}
                                                    color="primary"
                                                />
                                            }
                                            label="Show Legends"
                                        />
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1} px={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                        <Typography variant="h6" gutterBottom sx={{ pt: 2 }}>
                                            Label Position
                                        </Typography>
                                        <ToggleButtonGroup
                                            color="primary"
                                            value={labelPosition}
                                            exclusive
                                            onChange={(e, newPosition) => {
                                                if (newPosition !== null) setLabelPosition(newPosition);
                                            }}
                                            aria-label="label position"
                                            size="small"
                                            fullWidth
                                        >
                                            <ToggleButton value="inside">Inside</ToggleButton>
                                            <ToggleButton value="outside">Outside</ToggleButton>
                                        </ToggleButtonGroup>

                                        {labelPosition === 'outside' && (
                                            <FormControlLabel
                                                sx={{ mt: 2 }}
                                                control={
                                                    <Switch
                                                        size="small"
                                                        checked={showArrows}
                                                        onChange={(e) => setShowArrows(e.target.checked)}
                                                        color="primary"
                                                    />
                                                }
                                                label="Show Arrows"
                                            />
                                        )}
                                    </Box>
                                </Grid>

                                {showLegends && (
                                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                        <Box mt={1}>
                                            <Typography variant="h6" gutterBottom>
                                                Legend Position
                                            </Typography>
                                            <ToggleButtonGroup
                                                color="primary"
                                                value={legendPosition}
                                                exclusive
                                                onChange={(e, newPosition) => {
                                                    if (newPosition !== null) setLegendPosition(newPosition);
                                                }}
                                                aria-label="legend position"
                                                size="small"
                                                fullWidth
                                            >
                                                <ToggleButton value="top">Top</ToggleButton>
                                                <ToggleButton value="bottom">Bottom</ToggleButton>
                                                <ToggleButton value="left">Left</ToggleButton>
                                                <ToggleButton value="right">Right</ToggleButton>
                                            </ToggleButtonGroup>
                                        </Box>
                                    </Grid>
                                )}

                            </Grid>
                        </Box>
                    </Grid>
                    <Grid size={{ lg: 8, md: 6, sm: 12, xs: 12 }}>
                        <Box className="center" mb={2}>
                            <ToggleButtonGroup
                                color="primary"
                                value={type}
                                exclusive
                                fullWidth
                                onChange={(e, newType) => {
                                    if (newType !== null) setType(newType);
                                }}
                                aria-label="chart type"
                                size="small"
                            >
                                <ToggleButton value="bar">Bar</ToggleButton>
                                <ToggleButton value="column">Column</ToggleButton>
                                <ToggleButton value="stack">Stack</ToggleButton>
                                <ToggleButton value="line">Line</ToggleButton>
                                <ToggleButton value="combo">Combo</ToggleButton>
                                <ToggleButton value="pie">Pie</ToggleButton>
                                <ToggleButton value="doughnut">Doughnut</ToggleButton>
                                <ToggleButton value="polar">Polar</ToggleButton>
                                <ToggleButton value="radar">Radar</ToggleButton>
                            </ToggleButtonGroup>
                        </Box>

                        <Box className="fx_c" sx={{
                            border: '2px solid #000000',
                            background: '#ffffff',
                            borderRadius: '6px',
                            padding: '20px',
                            margin: 'auto',
                            width: 'fit-content',
                            minWidth: '840px' // Ensure container is wide enough
                        }}>
                            <Box ref={chartRef} className="fx_c" sx={{
                                border: '2px solid #ffffff',
                                width: '800px', // Increased width to accommodate larger chart
                                background: '#ffffff',
                                borderRadius: '6px',
                                padding: '20px', // Increased padding for better spacing
                                boxShadow: 'rgba(99, 99, 99, 0.2) 0px 2px 8px 0px',
                                // Ultra-high quality rendering optimizations
                                imageRendering: 'high-quality',
                                textRendering: 'optimizeLegibility',
                                fontSmooth: 'always',
                                WebkitFontSmoothing: 'antialiased',
                                MozOsxFontSmoothing: 'grayscale',
                                fontDisplay: 'swap',
                                fontVariantLigatures: 'none',
                                // Ensure crisp rendering with hardware acceleration
                                transform: 'translateZ(0)',
                                backfaceVisibility: 'hidden',
                                perspective: '1000px',
                                willChange: 'transform',
                                // Force high DPI rendering with proper dimensions
                                minHeight: '400px',
                                minWidth: '800px',
                                // Ensure content fits within container
                                overflow: 'visible',
                                position: 'relative'
                            }}>
                                <Box style={{
                                    background: "#fff",
                                    padding: "0px",
                                    // High-quality rendering styles
                                    imageRendering: 'high-quality',
                                    textRendering: 'optimizeLegibility',
                                    fontSmooth: 'always',
                                    WebkitFontSmoothing: 'antialiased',
                                    MozOsxFontSmoothing: 'grayscale'
                                }}>
                                    {renderChart()}
                                </Box>
                            </Box>
                        </Box>


                        <Stack mt={3} direction="row" alignItems="center" justifyContent="center" spacing={2}>
                            <Button variant="contained" onClick={handleDownload} className="main-btn btn-secondary">Download</Button>
                            <Button
                                variant="contained"
                                onClick={handleUploadToOCI}
                                disabled={!documentName}
                                className="main-btn btn-primary"
                                title={!documentName ? "Document name is required for upload" : "Upload chart to OCI"}
                            >
                                Upload to OCI
                            </Button>
                        </Stack>

                    </Grid>
                </Grid>

            </Box>

            {/* Upload Dialog */}
            <Dialog
                open={uploadDialogOpen}
                onClose={handleCloseUploadDialog}
                maxWidth="sm"
                fullWidth
                PaperProps={{
                    sx: {
                        borderRadius: 2,
                        minHeight: 200
                    }
                }}
            >
                <DialogTitle className='custom-dialog-title'>
                    {uploadStatus === 'loading' && <CircularProgress size={24} />}
                    {uploadStatus === 'success' && <CheckCircle color="success" />}
                    {uploadStatus === 'error' && <Error color="error" />}
                    {uploadStatus === 'loading' && 'Uploading to OCI...'}
                    {uploadStatus === 'success' && 'Upload Complete'}
                    {uploadStatus === 'error' && 'Upload Failed'}
                </DialogTitle>

                <DialogContent sx={{ p: 3 }}>
                    {uploadStatus === 'loading' && (
                        <Box sx={{ textAlign: 'center', py: 3 }}>
                            <CircularProgress size={60} sx={{ mb: 2 }} />
                            <Typography variant="body1" color="text.secondary">
                                {uploadMessage}
                            </Typography>
                        </Box>
                    )}

                    {uploadStatus === 'success' && uploadResult && (
                        <Box>
                            <Alert severity="success" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ✅ Chart uploaded successfully!
                                </Typography>
                            </Alert>

                            <Box sx={{ bgcolor: '#f8f9fa', p: 2, borderRadius: 1, mb: 2 }}>
                                <Typography variant="subtitle2" gutterBottom>
                                    Upload Details:
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>URL:</strong> {uploadResult.infographic.url}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Document:</strong> {uploadResult.infographic.documentName}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Filename:</strong> {uploadResult.infographic.filename}
                                </Typography>
                                <Typography variant="body2">
                                    <strong>Total infographics:</strong> {uploadResult.totalInfographics}
                                </Typography>
                            </Box>
                        </Box>
                    )}

                    {uploadStatus === 'error' && (
                        <Box>
                            <Alert severity="error" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ❌ Upload Failed
                                </Typography>
                                <Typography variant="body2">
                                    {uploadMessage}
                                </Typography>
                            </Alert>
                        </Box>
                    )}
                </DialogContent>

                <DialogActions className='custom-dialog-action'>
                    {uploadStatus === 'error' && (
                        <Button
                            onClick={handleRetryUpload}
                            variant="contained"
                            startIcon={<CloudUpload />}
                            sx={{ mr: 1 }}
                        >
                            Try Again
                        </Button>
                    )}

                    <Button
                        onClick={handleCloseUploadDialog}
                        variant={uploadStatus === 'error' ? 'outlined' : 'contained'}
                    >
                        {uploadStatus === 'loading' ? 'Cancel' : 'Close'}
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

export default ChartBuilder;
