"use client";
import React, { useRef, useState, useEffect } from "react";
import {
    Chart as ChartJS,
    BarElement,
    CategoryScale,
    LinearScale,
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    RadialLinearScale,
    Filler
} from "chart.js";
import { Bar, Pie, Line, PolarArea, Radar, Doughnut } from "react-chartjs-2";
// import * as htmlToImage from "html-to-image";
import * as htmlToImage from "dom-to-image-more";
import { Button, TextField, Box, Grid, Container, Typography, IconButton, Switch, FormControlLabel, Stack, Select, MenuItem, FormControl, InputLabel, Dialog, DialogTitle, DialogContent, DialogActions, CircularProgress, Alert } from "@mui/material";
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { MdDeleteOutline } from "react-icons/md";
import { CheckCircle, Error, CloudUpload } from '@mui/icons-material';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';


ChartJS.register(
    BarElement,
    CategoryScale,
    LinearScale,
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    PointElement,
    RadialLinearScale,
    Filler
);

const ChartBuilder = ({ themeColors = [], documentName = "", selectedInfographic = null }) => {
    // Log the document name when component mounts or documentName changes
    useEffect(() => {
        if (documentName) {
            console.log('📊 ChartBuilder received document name:', documentName);
        }
    }, [documentName]);

    // Load selected infographic data when available
    useEffect(() => {
        if (selectedInfographic && selectedInfographic.originalData) {
            console.log('📊 Loading selected infographic data:', selectedInfographic);

            // Load chart data from the selected infographic
            const originalData = selectedInfographic.originalData;

            if (originalData.dataPoints) {
                setDataPoints(originalData.dataPoints);
            }
            if (originalData.dataPoints2) {
                setDataPoints2(originalData.dataPoints2);
            }
            if (originalData.type) {
                setType(originalData.type);
            }
            if (originalData.colors) {
                setColors(originalData.colors);
            }
            if (originalData.selectedColors) {
                setSelectedColors(originalData.selectedColors);
            }
            if (originalData.chartName) {
                setChartName(originalData.chartName);
            }
            if (originalData.legendPosition) {
                setLegendPosition(originalData.legendPosition);
            }
            if (originalData.showLegends !== undefined) {
                setShowLegends(originalData.showLegends);
            }
        }
    }, [selectedInfographic]);

    const chartRef = useRef(null);
    const [dataPoints, setDataPoints] = useState([
        { label: "Label 1", value: 10, color: themeColors[0] || "#1930ab" },
        { label: "Label 2", value: 20, color: themeColors[1] || "#fa7604" },
        { label: "Label 3", value: 30, color: themeColors[2] || "#4CAF50" }
    ]);
    const [dataPoints2, setDataPoints2] = useState([
        { label: "Label 1", value: 15, color: themeColors[1] || "#fa7604" },
        { label: "Label 2", value: 25, color: themeColors[2] || "#4CAF50" },
        { label: "Label 3", value: 35, color: themeColors[0] || "#1930ab" }
    ]); // For combo charts
    const [type, setType] = useState("bar");
    const [colors, setColors] = useState(themeColors.length > 0 ? themeColors.slice(0, 3) : ["#1930ab", "#fa7604", "#4CAF50"]);
    const [selectedColors, setSelectedColors] = useState({
        dataset1: themeColors[0] || "#1930ab",
        dataset2: themeColors[1] || "#fa7604"
    });
    const [chartName, setChartName] = useState("Chart");
    const [legendPosition, setLegendPosition] = useState("top");
    const [showLegends, setShowLegends] = useState(true);

    // Dialog states for upload
    const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
    const [uploadStatus, setUploadStatus] = useState('idle'); // 'idle', 'loading', 'success', 'error'
    const [uploadMessage, setUploadMessage] = useState('');
    const [uploadResult, setUploadResult] = useState(null);

    // Update colors when themeColors prop changes
    useEffect(() => {
        if (themeColors.length > 0) {
            // Use theme colors for the chart (use as many as needed for the data points)
            const colorsToUse = themeColors.slice(0, Math.max(dataPoints.length, dataPoints2.length));
            setColors(colorsToUse);

            // Update selected colors if they're not in theme colors
            setSelectedColors(prev => ({
                dataset1: themeColors[0] || prev.dataset1,
                dataset2: themeColors[1] || prev.dataset2
            }));

            // Update data points colors if they don't have colors or if theme colors changed
            setDataPoints(prev => prev.map((dp, index) => ({
                ...dp,
                color: dp.color || themeColors[index % themeColors.length] || "#1930ab"
            })));

            setDataPoints2(prev => prev.map((dp, index) => ({
                ...dp,
                color: dp.color || themeColors[index % themeColors.length] || "#fa7604"
            })));
        }
    }, [themeColors, dataPoints.length, dataPoints2.length]);

    const handleDownload = async () => {
        if (!chartRef.current) return;

        await new Promise(resolve => setTimeout(resolve, 300)); // Reduced delay

        // Get the actual dimensions of the chart content
        const chartElement = chartRef.current;
        const chartRect = chartElement.getBoundingClientRect();

        // Calculate dynamic dimensions based on content
        const contentWidth = chartRect.width;
        const contentHeight = chartRect.height;
        const minWidth = 400; // Minimum width for charts
        const minHeight = 300; // Minimum height for charts
        const dynamicWidth = Math.max(contentWidth, minWidth);
        const dynamicHeight = Math.max(contentHeight, minHeight);

        const dataUrl = await htmlToImage.toPng(chartRef.current, {
            cacheBust: true,
            backgroundColor: "#ffffff",
            width: dynamicWidth,
            height: dynamicHeight,
            quality: 1.0, // Maximum quality
            pixelRatio: 3, // Higher pixel ratio for better quality
            skipAutoScale: true, // Prevent auto-scaling
            useCORS: true, // Enable CORS for better image handling
            allowTaint: true, // Allow tainted canvas for better compatibility
            foreignObjectRendering: true // Better rendering for complex elements
        });

        const filename = chartName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";

        const link = document.createElement("a");
        link.download = filename;
        link.href = dataUrl;
        link.click();
    };

    const handleUploadToOCI = async () => {
        if (!chartRef.current) return;

        // Open dialog and set loading state
        setUploadDialogOpen(true);
        setUploadStatus('loading');
        setUploadMessage('Preparing chart for upload...');

        try {
            console.log('📁 Starting upload to OCI for document:', documentName);

            setUploadMessage('Generating chart image...');
            await new Promise(resolve => setTimeout(resolve, 300)); // Reduced delay

            // Get the actual dimensions of the chart content
            const chartElement = chartRef.current;
            const chartRect = chartElement.getBoundingClientRect();

            // Calculate dynamic dimensions based on content
            const contentWidth = chartRect.width;
            const contentHeight = chartRect.height;
            const minWidth = 400; // Minimum width for charts
            const minHeight = 300; // Minimum height for charts
            const dynamicWidth = Math.max(contentWidth, minWidth);
            const dynamicHeight = Math.max(contentHeight, minHeight);

            setUploadMessage('Converting chart to image...');
            const dataUrl = await htmlToImage.toPng(chartRef.current, {
                cacheBust: true,
                backgroundColor: "#ffffff",
                width: dynamicWidth,
                height: dynamicHeight,
                quality: 1.0, // Maximum quality
                pixelRatio: 3, // Higher pixel ratio for better quality
                skipAutoScale: true, // Prevent auto-scaling
                useCORS: true, // Enable CORS for better image handling
                allowTaint: true, // Allow tainted canvas for better compatibility
                foreignObjectRendering: true // Better rendering for complex elements
            });

            // Convert data URL to blob
            const response = await fetch(dataUrl);
            const blob = await response.blob();

            // Create a file from the blob
            const filename = chartName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";
            const file = new File([blob], filename, { type: 'image/png' });

            // Create FormData for upload
            const formData = new FormData();
            formData.append('file', file);
            formData.append('documentName', documentName);
            formData.append('chartType', type);
            formData.append('originalData', JSON.stringify({
                dataPoints: dataPoints,
                dataPoints2: dataPoints2,
                type: type,
                colors: colors,
                selectedColors: selectedColors,
                chartName: chartName,
                legendPosition: legendPosition,
                showLegends: showLegends
            }));

            console.log('📁 Uploading file:', filename, 'for document:', documentName);
            setUploadMessage('Uploading to OCI...');

            // Get access token from localStorage
            const session = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('session') : null;
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Upload to OCI via our API
            const uploadResponse = await fetch('/api/infographics', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                },
                body: formData
            });

            if (!uploadResponse.ok) {
                const errorData = await uploadResponse.json();
                throw new Error(errorData.error || `Upload failed: ${uploadResponse.status}`);
            }

            const result = await uploadResponse.json();
            console.log('✅ Upload successful:', result);

            // Set success state
            setUploadStatus('success');
            setUploadResult(result);
            setUploadMessage('Chart uploaded successfully!');

        } catch (error) {
            console.error('❌ Upload failed:', error);
            setUploadStatus('error');
            setUploadMessage('Unable to upload the file to OCI, try again after some time.');
        }
    };

    const handleCloseUploadDialog = () => {
        setUploadDialogOpen(false);
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
    };

    const handleRetryUpload = () => {
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
        handleUploadToOCI();
    };

    const getChartData = () => {
        const baseData = {
            labels: dataPoints.map(dp => dp.label),
            datasets: []
        };

        switch (type) {
            case "stack":
                return {
                    ...baseData,
                    datasets: [
                        {
                            label: "Dataset 1",
                            data: dataPoints.map(dp => dp.value),
                            backgroundColor: dataPoints.map(dp => dp.color),
                            stack: "Stack 0",
                        },
                        {
                            label: "Dataset 2",
                            data: dataPoints2.map(dp => dp.value),
                            backgroundColor: dataPoints2.map(dp => dp.color),
                            stack: "Stack 0",
                        }
                    ]
                };
            case "combo":
                return {
                    ...baseData,
                    datasets: [
                        {
                            label: "Bar Data",
                            data: dataPoints.map(dp => dp.value),
                            backgroundColor: dataPoints.map(dp => dp.color),
                            type: "bar",
                            order: 2,
                        },
                        {
                            label: "Line Data",
                            data: dataPoints2.map(dp => dp.value),
                            borderColor: dataPoints2.map(dp => dp.color),
                            backgroundColor: "transparent",
                            type: "line",
                            order: 1,
                            borderWidth: 2,
                            fill: false,
                            tension: 0.4,
                        }
                    ]
                };
            default:
                return {
                    ...baseData,
                    datasets: [
                        {
                            label: "",
                            data: dataPoints.map(dp => dp.value),
                            backgroundColor: dataPoints.map(dp => dp.color),
                            borderColor: type === "line" ? dataPoints.map(dp => dp.color) : dataPoints.map(dp => dp.color),
                            borderWidth: type === "line" ? 2 : 1,
                            fill: type === "line" ? false : undefined,
                            tension: type === "line" ? 0.4 : undefined,
                        },
                    ]
                };
        }
    };

    const chartData = getChartData();

    // Calculate max value for axis configuration - Force 5 axes
    const maxDataValue = Math.max(...dataPoints.map(dp => dp.value), ...(dataPoints2.map(dp => dp.value)));
    const axisMax = Math.max(maxDataValue + 3, 5); // Ensure minimum of 5 axes
    const stepSize = Math.ceil(axisMax / 5); // Always 5 steps

    const chartOptions = {
        responsive: false, // Important to fix canvas size
        maintainAspectRatio: false,
        indexAxis: type === "bar" ? 'y' : 'x', // Horizontal for bar, vertical for column
        plugins: {
            legend: {
                position: legendPosition,
                display: showLegends,
                labels: {
                    font: {
                        family: 'Calibri',
                        size: 13 // Back to original font size
                    },
                    color: "#000",
                    usePointStyle: false,
                    boxWidth: 10, // Back to original box size
                    boxHeight: 10, // Back to original box size
                    padding: 10 // Back to original padding
                },
                padding: 15, // Back to original padding
                margin: 15 // Back to original margin
            },
            tooltip: {
                callbacks: {
                    label: function (context) {
                        return `${context.dataset.label || ''}: ${context.parsed.y || context.parsed}`;
                    }
                }
            },
            // Custom plugin to display data labels
            customCanvasBackgroundColor: {
                color: 'white',
            },
            // Data labels plugin
            datalabels: {
                display: true,
                color: '#000',
                anchor: 'center',
                align: 'center',
                font: {
                    family: 'Calibri',
                    size: 11,
                    weight: 'bold'
                },
                formatter: function (value, context) {
                    return value;
                }
            }
        },
        scales: (type === "line" || type === "bar" || type === "stack" || type === "column" || type === "combo") ? {
            x: type === "bar" ? {
                // For horizontal bar chart, X axis shows values
                type: 'linear',
                position: 'bottom',
                ticks: {
                    font: {
                        family: 'Calibri',
                        size: 12 // Back to original font size
                    },
                    color: "#000",
                    maxTicksLimit: 5,
                    max: axisMax,
                    stepSize: stepSize,
                    callback: function (value, index, values) {
                        return value;
                    }
                },
                grid: {
                    display: true
                }
            } : {
                // For vertical charts, X axis shows labels
                type: 'category',
                position: 'bottom',
                ticks: {
                    font: {
                        family: 'Calibri',
                        size: 12 // Back to original font size
                    },
                    color: "#000",
                    maxTicksLimit: 5
                },
                grid: {
                    display: false
                }
            },
            y: type === "bar" ? {
                // For horizontal bar chart, Y axis shows labels
                type: 'category',
                position: 'left',
                ticks: {
                    font: {
                        family: 'Calibri',
                        size: 12 // Back to original font size
                    },
                    color: "#000",
                    maxTicksLimit: 5
                },
                grid: {
                    display: false
                }
            } : {
                // For vertical charts, Y axis shows values
                type: 'linear',
                position: 'left',
                ticks: {
                    font: {
                        family: 'Calibri',
                        size: 12 // Back to original font size
                    },
                    color: "#000",
                    maxTicksLimit: 5,
                    max: axisMax,
                    stepSize: stepSize,
                    callback: function (value, index, values) {
                        return value;
                    }
                },
                grid: {
                    display: true
                }
            }
        } : undefined,
        elements: {
            bar: {
                borderWidth: 0,
                borderRadius: 4,
                borderSkipped: false,
            }
        }
    };

    // Custom plugin to draw data labels
    const customDataLabelsPlugin = {
        id: 'customDataLabels',
        afterDraw: function (chart) {
            const ctx = chart.ctx;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.font = 'bold 11px Calibri';
            ctx.fillStyle = '#000';

            chart.data.datasets.forEach((dataset, datasetIndex) => {
                chart.getDatasetMeta(datasetIndex).data.forEach((bar, index) => {
                    const data = dataset.data[index];
                    if (data !== null && data !== undefined) {
                        const x = bar.x;
                        const y = bar.y;

                        // For stack charts, adjust position based on dataset
                        let labelY = y;
                        if (type === 'stack' && datasetIndex === 1) {
                            // For second dataset in stack, position label at the top of the stack
                            const firstDatasetValue = chart.data.datasets[0].data[index];
                            const secondDatasetValue = data;
                            const totalHeight = firstDatasetValue + secondDatasetValue;
                            const firstHeight = (firstDatasetValue / totalHeight) * bar.height;
                            labelY = bar.y - (bar.height / 2) + firstHeight + (secondDatasetValue / totalHeight) * bar.height / 2;
                        }

                        ctx.fillText(data.toString(), x, labelY);
                    }
                });
            });
        }
    };

    // Add custom plugin to options
    chartOptions.plugins.customDataLabels = customDataLabelsPlugin;

    const renderChart = () => {
        // Different sizes for different chart types - back to original dimensions
        const isCircularChart = type === "pie" || type === "doughnut" || type === "polar" || type === "radar";
        const chartWidth = isCircularChart ? 400 : 600; // Back to original dimensions
        const chartHeight = isCircularChart ? 300 : 350; // Back to original dimensions

        const commonProps = { data: chartData, options: chartOptions, width: chartWidth, height: chartHeight };

        switch (type) {
            case "bar":
                return <Bar {...commonProps} />;
            case "column":
            case "stack":
                return <Bar {...commonProps} />;
            case "pie":
                return <Pie {...commonProps} />;
            case "line":
                return <Line {...commonProps} />;
            case "polar":
                return <PolarArea {...commonProps} />;
            case "radar":
                return <Radar {...commonProps} />;
            case "doughnut":
                return <Doughnut {...commonProps} />;
            case "combo":
                return <Bar {...commonProps} />;
            default:
                return <Bar {...commonProps} />;
        }
    };

    const showSecondDataset = type === "stack" || type === "combo";
    const showColorSelection = type === "stack" || type === "combo";

    return (
        <>
            <Box>
                {/* {documentName && (
                    <Box sx={{ mb: 2, p: 2, bgcolor: 'primary.main', color: 'white', borderRadius: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                            📄 Document: {documentName}
                        </Typography>
                    </Box>
                )} */}
                {selectedInfographic && (
                    <Box sx={{
                        mb: 2,
                        p: 1,
                        color: '#000000',
                        borderRadius: 1,
                        borderLeft: '4px solid var(--success)',
                        backgroundColor: '#f2f2f2',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1
                    }}>
                        <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            Viewing: {selectedInfographic.filename}
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.8 }}>
                            (Click "Upload to OCI" to regenerate this chart)
                        </Typography>
                    </Box>
                )}
                <Grid container alignItems="stretch" spacing={2} mb={2}>
                    {/* <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                        <Box className="center" mb={0}>
                            <ToggleButtonGroup
                                color="primary"
                                value={type}
                                exclusive
                                // fullWidth
                                onChange={(e, newType) => {
                                    if (newType !== null) setType(newType);
                                }}
                                aria-label="chart type"
                                size="small"
                            >
                                <ToggleButton value="bar">Bar</ToggleButton>
                                <ToggleButton value="column">Column</ToggleButton>
                                <ToggleButton value="stack">Stack</ToggleButton>
                                <ToggleButton value="line">Line</ToggleButton>
                                <ToggleButton value="combo">Combo</ToggleButton>
                                <ToggleButton value="pie">Pie</ToggleButton>
                                <ToggleButton value="doughnut">Doughnut</ToggleButton>
                                <ToggleButton value="polar">Polar</ToggleButton>
                                <ToggleButton value="radar">Radar</ToggleButton>
                            </ToggleButtonGroup>
                        </Box>
                    </Grid> */}

                    <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                        <Box sx={{ background: '#f2f2f2', padding: '20px', height: '100%' }}>
                            <Grid container spacing={2} mb={2}>
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box className="textfield auto-complete">
                                        <TextField
                                            label="Chart Name [use section name]"
                                            fullWidth
                                            size="small"
                                            value={chartName}
                                            onChange={(e) => setChartName(e.target.value)}
                                        />
                                    </Box>
                                </Grid>
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mb={0}>

                                        <Box mb={2}>
                                            <Typography variant="h6" className="black" gutterBottom>
                                                Data Points
                                            </Typography>
                                        </Box>

                                        {/* <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mb: 2 }}>
                                            💡 Add labels and values. Decimal values (like 22.5) are supported.
                                        </Typography> */}
                                        {dataPoints.map((dp, index) => (
                                            <Box key={index} display="flex" alignItems="center" gap={1} mt={1} mb={2}>
                                                <Box
                                                    sx={{
                                                        width: 20,
                                                        height: 20,
                                                        borderRadius: '2px',
                                                        backgroundColor: dp.color,
                                                        border: '1px solid #ddd',
                                                        cursor: 'pointer',
                                                        flexShrink: 0
                                                    }}
                                                    onClick={() => {
                                                        // Cycle through theme colors
                                                        const currentColorIndex = themeColors.indexOf(dp.color);
                                                        const nextColorIndex = (currentColorIndex + 1) % themeColors.length;
                                                        const newColor = themeColors[nextColorIndex] || dp.color;

                                                        const newDataPoints = [...dataPoints];
                                                        newDataPoints[index] = { ...newDataPoints[index], color: newColor };
                                                        setDataPoints(newDataPoints);
                                                    }}
                                                    title={`Click to change color. Current: ${dp.color}`}
                                                />
                                                <Box className="textfield sm auto-complete">
                                                    <TextField
                                                        label={`Label ${index + 1}`}
                                                        fullWidth
                                                        size="small"
                                                        value={dp.label}
                                                        onChange={(e) => {
                                                            const newDataPoints = [...dataPoints];
                                                            newDataPoints[index] = { ...newDataPoints[index], label: e.target.value };
                                                            setDataPoints(newDataPoints);
                                                        }}
                                                    />
                                                </Box>
                                                <Box className="textfield sm auto-complete">
                                                    <TextField
                                                        label={`Value ${index + 1}`}
                                                        fullWidth
                                                        size="small"
                                                        value={dp.value}
                                                        onChange={(e) => {
                                                            const newDataPoints = [...dataPoints];
                                                            newDataPoints[index] = { ...newDataPoints[index], value: Number(e.target.value) };
                                                            setDataPoints(newDataPoints);
                                                        }}
                                                        type="number"
                                                        step="any"
                                                    />
                                                </Box>
                                                <IconButton
                                                    className="action-ico-btn error"
                                                    onClick={() => {
                                                        const newDataPoints = dataPoints.filter((_, i) => i !== index);
                                                        setDataPoints(newDataPoints);
                                                    }}
                                                    size="small"
                                                    color="error"
                                                    aria-label="delete"
                                                >
                                                    <MdDeleteOutline />
                                                </IconButton>
                                            </Box>
                                        ))}
                                        <Button
                                            variant="outlined"
                                            onClick={() => {
                                                const newColor = themeColors[dataPoints.length % themeColors.length] || "#1930ab";
                                                setDataPoints([...dataPoints, { label: "", value: 0, color: newColor }]);
                                            }}
                                            size="small"
                                            className="main-btn sm btn-primary"
                                            startIcon={<AddOutlinedIcon />}
                                        >
                                            Add Data Point
                                        </Button>
                                    </Box>
                                </Grid>
                                {showSecondDataset && (
                                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                        <Box mt={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                            <Box mt={2} mb={2}>
                                                <Typography variant="h6" className="black" gutterBottom>
                                                    Data Points 2
                                                </Typography>
                                            </Box>
                                            {dataPoints2.map((dp, index) => (
                                                <Box key={index} display="flex" alignItems="center" gap={1} mt={1} mb={2}>
                                                    <Box
                                                        sx={{
                                                            width: 20,
                                                            height: 20,
                                                            borderRadius: '2px',
                                                            backgroundColor: dp.color,
                                                            border: '1px solid #ddd',
                                                            cursor: 'pointer',
                                                            flexShrink: 0
                                                        }}
                                                        onClick={() => {
                                                            // Cycle through theme colors
                                                            const currentColorIndex = themeColors.indexOf(dp.color);
                                                            const nextColorIndex = (currentColorIndex + 1) % themeColors.length;
                                                            const newColor = themeColors[nextColorIndex] || dp.color;

                                                            const newDataPoints2 = [...dataPoints2];
                                                            newDataPoints2[index] = { ...newDataPoints2[index], color: newColor };
                                                            setDataPoints2(newDataPoints2);
                                                        }}
                                                        title={`Click to change color. Current: ${dp.color}`}
                                                    />
                                                    <Box className="textfield sm auto-complete">
                                                        <TextField
                                                            label={`Label ${index + 1}`}
                                                            fullWidth
                                                            size="small"
                                                            value={dp.label}
                                                            onChange={(e) => {
                                                                const newDataPoints2 = [...dataPoints2];
                                                                newDataPoints2[index] = { ...newDataPoints2[index], label: e.target.value };
                                                                setDataPoints2(newDataPoints2);
                                                            }}
                                                        />
                                                    </Box>
                                                    <Box className="textfield sm auto-complete">
                                                        <TextField
                                                            label={`Value ${index + 1}`}
                                                            fullWidth
                                                            size="small"
                                                            value={dp.value}
                                                            onChange={(e) => {
                                                                const newDataPoints2 = [...dataPoints2];
                                                                newDataPoints2[index] = { ...newDataPoints2[index], value: Number(e.target.value) };
                                                                setDataPoints2(newDataPoints2);
                                                            }}
                                                            type="number"
                                                            step="any"
                                                        />
                                                    </Box>
                                                    <IconButton
                                                        onClick={() => {
                                                            const newDataPoints2 = dataPoints2.filter((_, i) => i !== index);
                                                            setDataPoints2(newDataPoints2);
                                                        }}
                                                        size="small"
                                                        color="error"
                                                        aria-label="delete"
                                                        className="action-ico-btn error"
                                                    >
                                                        <MdDeleteOutline />
                                                    </IconButton>
                                                </Box>
                                            ))}
                                            <Button
                                                variant="outlined"
                                                onClick={() => {
                                                    const newColor = themeColors[dataPoints2.length % themeColors.length] || "#fa7604";
                                                    setDataPoints2([...dataPoints2, { label: "", value: 0, color: newColor }]);
                                                }}
                                                size="small"
                                                className="main-btn sm btn-primary"
                                                startIcon={<AddOutlinedIcon />}
                                            >
                                                Add Data Point
                                            </Button>
                                        </Box>
                                    </Grid>
                                )}
                                {!showSecondDataset && (
                                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                        <Box mt={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                            <Typography variant="h6" gutterBottom sx={{ pt: 2 }}>
                                                Theme Colors (from document)
                                            </Typography>
                                            {/* <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mb: 2 }}>
                                                💡 Click on the color boxes next to each data point to change colors.
                                            </Typography> */}
                                            <Box display="flex" gap={1} flexWrap="wrap" alignItems="center" pt={1}>
                                                {themeColors.length > 0 ? (
                                                    themeColors.map((color, index) => (
                                                        <Box
                                                            key={index}
                                                            sx={{
                                                                width: 24,
                                                                height: 24,
                                                                borderRadius: '50%',
                                                                backgroundColor: color,
                                                                border: '2px solid #ddd',
                                                                cursor: 'pointer',
                                                                '&:hover': {
                                                                    transform: 'scale(1.1)',
                                                                    border: '2px solid #000'
                                                                }
                                                            }}
                                                            title={`Color ${index + 1}: ${color}`}
                                                        />
                                                    ))
                                                ) : (
                                                    <Typography variant="body2" color="textSecondary">
                                                        No theme colors available
                                                    </Typography>
                                                )}
                                            </Box>
                                        </Box>
                                    </Grid>
                                )}

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1} px={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                        <FormControlLabel
                                            sx={{ pt: 2 }}
                                            control={
                                                <Switch
                                                    size="small"
                                                    checked={showLegends}
                                                    onChange={(e) => setShowLegends(e.target.checked)}
                                                    color="primary"
                                                />
                                            }
                                            label="Show Legends"
                                        />
                                    </Box>
                                </Grid>

                                {showLegends && (
                                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                        <Box mt={1}>
                                            <Typography variant="h6" gutterBottom>
                                                Legend Position
                                            </Typography>
                                            <ToggleButtonGroup
                                                color="primary"
                                                value={legendPosition}
                                                exclusive
                                                onChange={(e, newPosition) => {
                                                    if (newPosition !== null) setLegendPosition(newPosition);
                                                }}
                                                aria-label="legend position"
                                                size="small"
                                                fullWidth
                                            >
                                                <ToggleButton value="top">Top</ToggleButton>
                                                <ToggleButton value="bottom">Bottom</ToggleButton>
                                                <ToggleButton value="left">Left</ToggleButton>
                                                <ToggleButton value="right">Right</ToggleButton>
                                            </ToggleButtonGroup>
                                        </Box>
                                    </Grid>
                                )}

                            </Grid>
                        </Box>
                    </Grid>
                    <Grid size={{ lg: 8, md: 6, sm: 12, xs: 12 }}>
                        <Box className="center" mb={2}>
                            <ToggleButtonGroup
                                color="primary"
                                value={type}
                                exclusive
                                fullWidth
                                onChange={(e, newType) => {
                                    if (newType !== null) setType(newType);
                                }}
                                aria-label="chart type"
                                size="small"
                            >
                                <ToggleButton value="bar">Bar</ToggleButton>
                                <ToggleButton value="column">Column</ToggleButton>
                                <ToggleButton value="stack">Stack</ToggleButton>
                                <ToggleButton value="line">Line</ToggleButton>
                                <ToggleButton value="combo">Combo</ToggleButton>
                                <ToggleButton value="pie">Pie</ToggleButton>
                                <ToggleButton value="doughnut">Doughnut</ToggleButton>
                                <ToggleButton value="polar">Polar</ToggleButton>
                                <ToggleButton value="radar">Radar</ToggleButton>
                            </ToggleButtonGroup>
                        </Box>

                        <Box className="fx_c" sx={{ border: '2px solid #000000', background: '#ffffff', borderRadius: '6px', padding: '18px', margin: 'auto' }}>
                            <Box ref={chartRef} className="fx_c" sx={{ border: '2px solid #ffffff', width: 'fit-content', background: '#ffffff', borderRadius: '6px', padding: '18px', boxShadow: 'rgba(99, 99, 99, 0.2) 0px 2px 8px 0px' }}>
                                <Box style={{ background: "#fff", padding: "0px" }}>
                                    {renderChart()}
                                </Box>
                            </Box>
                        </Box>


                        <Stack mt={3} direction="row" alignItems="center" justifyContent="center" spacing={2}>
                            <Button variant="contained" onClick={handleDownload} className="main-btn btn-secondary">Download</Button>
                            <Button
                                variant="contained"
                                onClick={handleUploadToOCI}
                                disabled={!documentName}
                                className="main-btn btn-primary"
                                title={!documentName ? "Document name is required for upload" : "Upload chart to OCI"}
                            >
                                Upload to OCI
                            </Button>
                        </Stack>

                    </Grid>
                </Grid>

            </Box>

            {/* Upload Dialog */}
            <Dialog
                open={uploadDialogOpen}
                onClose={handleCloseUploadDialog}
                maxWidth="sm"
                fullWidth
                PaperProps={{
                    sx: {
                        borderRadius: 2,
                        minHeight: 200
                    }
                }}
            >
                <DialogTitle className='custom-dialog-title'>
                    {uploadStatus === 'loading' && <CircularProgress size={24} />}
                    {uploadStatus === 'success' && <CheckCircle color="success" />}
                    {uploadStatus === 'error' && <Error color="error" />} 
                        {uploadStatus === 'loading' && 'Uploading to OCI...'}
                        {uploadStatus === 'success' && 'Upload Complete'}
                        {uploadStatus === 'error' && 'Upload Failed'} 
                </DialogTitle>

                <DialogContent sx={{ p: 3 }}>
                    {uploadStatus === 'loading' && (
                        <Box sx={{ textAlign: 'center', py: 3 }}>
                            <CircularProgress size={60} sx={{ mb: 2 }} />
                            <Typography variant="body1" color="text.secondary">
                                {uploadMessage}
                            </Typography>
                        </Box>
                    )}

                    {uploadStatus === 'success' && uploadResult && (
                        <Box>
                            <Alert severity="success" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ✅ Chart uploaded successfully!
                                </Typography>
                            </Alert>

                            <Box sx={{ bgcolor: '#f8f9fa', p: 2, borderRadius: 1, mb: 2 }}>
                                <Typography variant="subtitle2" gutterBottom>
                                    Upload Details:
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>URL:</strong> {uploadResult.infographic.url}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Document:</strong> {uploadResult.infographic.documentName}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Filename:</strong> {uploadResult.infographic.filename}
                                </Typography>
                                <Typography variant="body2">
                                    <strong>Total infographics:</strong> {uploadResult.totalInfographics}
                                </Typography>
                            </Box>
                        </Box>
                    )}

                    {uploadStatus === 'error' && (
                        <Box>
                            <Alert severity="error" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ❌ Upload Failed
                                </Typography>
                                <Typography variant="body2">
                                    {uploadMessage}
                                </Typography>
                            </Alert>
                        </Box>
                    )}
                </DialogContent>

                <DialogActions className='custom-dialog-action'>
                    {uploadStatus === 'error' && (
                        <Button
                            onClick={handleRetryUpload}
                            variant="contained"
                            startIcon={<CloudUpload />}
                            sx={{ mr: 1 }}
                        >
                            Try Again
                        </Button>
                    )}

                    <Button
                        onClick={handleCloseUploadDialog}
                        variant={uploadStatus === 'error' ? 'outlined' : 'contained'}
                    >
                        {uploadStatus === 'loading' ? 'Cancel' : 'Close'}
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

export default ChartBuilder;
