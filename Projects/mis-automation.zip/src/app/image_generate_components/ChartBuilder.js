"use client";
import React, { useRef, useState, useEffect } from "react";
import dynamic from "next/dynamic";

// Dynamically import Chart with SSR disabled
const Chart = dynamic(() => import("react-apexcharts").then(mod => mod.default), {
    ssr: false,
    loading: () => (
        <Box sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: 350,
            color: '#666'
        }}>
            <CircularProgress size={40} />
            <Typography variant="body2" sx={{ ml: 2 }}>Loading chart...</Typography>
        </Box>
    )
});
// import * as htmlToImage from "html-to-image";
import * as htmlToImage from "dom-to-image-more";
import { Button, TextField, Box, Grid, Container, Typography, IconButton, Switch, FormControlLabel, Stack, Select, MenuItem, FormControl, InputLabel, Dialog, DialogTitle, DialogContent, DialogActions, CircularProgress, Alert, Autocomplete } from "@mui/material";
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { MdDeleteOutline } from "react-icons/md";
import { CheckCircle, Error, CloudUpload } from '@mui/icons-material';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';



const ChartBuilder = ({ themeColors = [], documentName = "", selectedInfographic = null }) => {
    // Log the document name when component mounts or documentName changes
    useEffect(() => {
        if (documentName) {
            console.log('📊 ChartBuilder received document name:', documentName);
        }
    }, [documentName]);

    // Load selected infographic data when available
    useEffect(() => {
        if (selectedInfographic && selectedInfographic.originalData) {
            console.log('📊 Loading selected infographic data:', selectedInfographic);

            // Load chart data from the selected infographic
            const originalData = selectedInfographic.originalData;

            if (originalData.dataPoints) {
                setDataPoints(originalData.dataPoints);
            }
            if (originalData.dataPoints2) {
                setDataPoints2(originalData.dataPoints2);
            }
            if (originalData.type) {
                setType(originalData.type);
            }
            if (originalData.colors) {
                setColors(originalData.colors);
            }
            if (originalData.selectedColors) {
                setSelectedColors(originalData.selectedColors);
            }
            if (originalData.chartName) {
                setChartName(originalData.chartName);
            }
            if (originalData.legendPosition) {
                setLegendPosition(originalData.legendPosition);
            }
            if (originalData.showLegends !== undefined) {
                setShowLegends(originalData.showLegends);
            }
        }
    }, [selectedInfographic]);

    const chartRef = useRef(null);
    const [dataPoints, setDataPoints] = useState([
        { label: "Label 1", value: 10, color: themeColors[0] || "#1930ab" },
        { label: "Label 2", value: 20, color: themeColors[1] || "#fa7604" },
        { label: "Label 3", value: 30, color: themeColors[2] || "#4CAF50" }
    ]);
    const [dataPoints2, setDataPoints2] = useState([
        { label: "Label 1", value: 15, color: themeColors[1] || "#fa7604" },
        { label: "Label 2", value: 25, color: themeColors[2] || "#4CAF50" },
        { label: "Label 3", value: 35, color: themeColors[0] || "#1930ab" }
    ]); // For combo charts
    const [type, setType] = useState("bar");
    const [colors, setColors] = useState(themeColors.length > 0 ? themeColors.slice(0, 3) : ["#1930ab", "#fa7604", "#4CAF50"]);
    const [selectedColors, setSelectedColors] = useState({
        dataset1: themeColors[0] || "#1930ab",
        dataset2: themeColors[1] || "#fa7604"
    });
    const [chartName, setChartName] = useState("Chart");
    const [legendPosition, setLegendPosition] = useState("top");
    const [showLegends, setShowLegends] = useState(true);
    const [labelPosition, setLabelPosition] = useState("inside"); // "inside" or "outside"
    const [showArrows, setShowArrows] = useState(false); // Show arrows for outside labels

    // Dialog states for upload
    const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
    const [uploadStatus, setUploadStatus] = useState('idle'); // 'idle', 'loading', 'success', 'error'
    const [uploadMessage, setUploadMessage] = useState('');
    const [uploadResult, setUploadResult] = useState(null);

    // Update colors when themeColors prop changes
    useEffect(() => {
        if (themeColors.length > 0) {
            // Parse colors if they're in CLOB format (JSON string)
            let parsedColors = themeColors;
            if (typeof themeColors[0] === 'string' && themeColors[0].startsWith('[')) {
                try {
                    parsedColors = JSON.parse(themeColors[0]);
                } catch (e) {
                    console.warn('Failed to parse theme colors:', e);
                    parsedColors = themeColors;
                }
            }

            // Use theme colors for the chart (use as many as needed for the data points)
            const colorsToUse = parsedColors.slice(0, Math.max(dataPoints.length, dataPoints2.length));
            setColors(colorsToUse);

            // Update selected colors if they're not in theme colors
            setSelectedColors(prev => ({
                dataset1: parsedColors[0] || prev.dataset1,
                dataset2: parsedColors[1] || prev.dataset2
            }));

            // Update data points colors if they don't have colors or if theme colors changed
            setDataPoints(prev => prev.map((dp, index) => ({
                ...dp,
                color: dp.color || parsedColors[index % parsedColors.length] || "#1930ab"
            })));

            setDataPoints2(prev => prev.map((dp, index) => ({
                ...dp,
                color: dp.color || parsedColors[index % parsedColors.length] || "#fa7604"
            })));
        }
    }, [themeColors, dataPoints.length, dataPoints2.length]);

    // Force chart re-render when label position or arrow settings change
    useEffect(() => {
        // This will trigger a re-render of the chart when label settings change
    }, [labelPosition, showArrows]);

    const handleDownload = async () => {
        if (!chartRef.current) {
            console.error('Chart reference not available');
            return;
        }

        try {
            // Wait for chart to be fully rendered
            await new Promise(resolve => setTimeout(resolve, 500));

            // Get the chart container element
            const chartElement = chartRef.current;
            console.log('Chart element:', chartElement);

            // Find the actual ApexCharts canvas element with multiple strategies
            let canvasElement = null;

            // Strategy 1: Direct canvas search
            canvasElement = chartElement.querySelector('canvas');

            // Strategy 2: Look for ApexCharts specific containers
            if (!canvasElement) {
                const apexContainers = [
                    '.apexcharts-canvas',
                    '.apexcharts-svg',
                    '.apexcharts-inner',
                    '[class*="apexcharts"]'
                ];

                for (const selector of apexContainers) {
                    const container = chartElement.querySelector(selector);
                    if (container) {
                        canvasElement = container.querySelector('canvas') || container.querySelector('svg');
                        if (canvasElement) break;
                    }
                }
            }

            // Strategy 3: Look for any SVG or canvas in the chart area
            if (!canvasElement) {
                canvasElement = chartElement.querySelector('svg') || chartElement.querySelector('canvas');
            }

            // Strategy 4: Wait and retry with all strategies
            if (!canvasElement) {
                console.log('Canvas/SVG not found, waiting and retrying...');
                await new Promise(resolve => setTimeout(resolve, 1000));

                // Retry all strategies
                canvasElement = chartElement.querySelector('canvas') ||
                    chartElement.querySelector('svg') ||
                    chartElement.querySelector('.apexcharts-canvas canvas') ||
                    chartElement.querySelector('.apexcharts-svg svg');
            }

            if (!canvasElement) {
                console.warn('Canvas/SVG element not found after retry');
                console.log('Chart element HTML:', chartElement.innerHTML);
                console.log('Available elements:', {
                    canvas: chartElement.querySelectorAll('canvas').length,
                    svg: chartElement.querySelectorAll('svg').length,
                    apexContainers: chartElement.querySelectorAll('[class*="apexcharts"]').length
                });
                console.log('Proceeding with chart container...');
                // Continue with chart container if canvas not found
            } else {
                console.log('Canvas/SVG element found:', canvasElement.tagName, canvasElement.className);
            }

            console.log('Canvas element found:', canvasElement);

            // Get dimensions
            const chartRect = chartElement.getBoundingClientRect();
            const canvasRect = canvasElement ? canvasElement.getBoundingClientRect() : null;

            console.log('Chart rect:', chartRect);
            console.log('Canvas rect:', canvasRect);

            // Use canvas dimensions for better accuracy, with fallbacks
            const defaultWidth = (type === "pie" || type === "doughnut") ? 600 : 500;
            const contentWidth = (canvasRect ? canvasRect.width : null) || chartRect.width || defaultWidth;
            const defaultHeight = (type === "pie" || type === "doughnut") ? 250 : 350;
            const contentHeight = (canvasRect ? canvasRect.height : null) || chartRect.height || defaultHeight;
            const minWidth = (type === "pie" || type === "doughnut") ? 400 : 500;
            const minHeight = (type === "pie" || type === "doughnut") ? 250 : 350;
            const dynamicWidth = Math.max(contentWidth, minWidth);
            const dynamicHeight = Math.max(contentHeight, minHeight);

            console.log('Dynamic dimensions:', { dynamicWidth, dynamicHeight });

            // Ultra-high quality settings for enhanced image generation
            const dataUrl = await htmlToImage.toPng(chartElement, {
                cacheBust: true,
                backgroundColor: "#ffffff",
                width: dynamicWidth * 3, // 3x scaling for ultra-high quality
                height: dynamicHeight * 3, // 3x scaling for ultra-high quality
                quality: 1.0, // Maximum quality
                pixelRatio: 3, // High DPI for crisp rendering
                useCORS: true,
                allowTaint: true,
                skipAutoScale: false, // Allow manual scaling
                foreignObjectRendering: true, // Better rendering for complex elements
                style: {
                    transform: `scale(3)`,
                    transformOrigin: 'top left',
                    width: `${dynamicWidth}px`,
                    height: `${dynamicHeight}px`
                },
                filter: (node) => {
                    // Skip script tags and other non-visual elements
                    if (node.tagName === 'SCRIPT' || node.tagName === 'STYLE') {
                        return false;
                    }
                    // Enhance text rendering for better quality
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        node.style.imageRendering = 'high-quality';
                        node.style.textRendering = 'optimizeLegibility';
                        node.style.fontSmooth = 'always';
                        node.style.webkitFontSmoothing = 'antialiased';
                        node.style.mozOsxFontSmoothing = 'grayscale';
                        node.style.fontDisplay = 'swap';
                        node.style.fontVariantLigatures = 'none';
                    }
                    return true;
                }
            });

            console.log('Data URL generated successfully');

            const filename = chartName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";

            const link = document.createElement("a");
            link.download = filename;
            link.href = dataUrl;
            link.click();
        } catch (error) {
            console.error('Download failed:', error);
            console.error('Error details:', {
                message: error.message,
                stack: error.stack,
                name: error.name
            });
            alert(`Download failed: ${error.message || 'Unknown error'}`);
        }
    };

    const handleUploadToOCI = async () => {
        if (!chartRef.current) {
            console.error('Chart reference not available');
            return;
        }

        // Open dialog and set loading state
        setUploadDialogOpen(true);
        setUploadStatus('loading');
        setUploadMessage('Preparing chart for upload...');

        try {
            console.log('📁 Starting upload to OCI for document:', documentName);

            setUploadMessage('Generating chart image...');
            // Wait for chart to be fully rendered
            await new Promise(resolve => setTimeout(resolve, 500));

            // Get the chart container element
            const chartElement = chartRef.current;
            console.log('Chart element:', chartElement);

            // Find the actual ApexCharts canvas element with multiple strategies
            let canvasElement = null;

            // Strategy 1: Direct canvas search
            canvasElement = chartElement.querySelector('canvas');

            // Strategy 2: Look for ApexCharts specific containers
            if (!canvasElement) {
                const apexContainers = [
                    '.apexcharts-canvas',
                    '.apexcharts-svg',
                    '.apexcharts-inner',
                    '[class*="apexcharts"]'
                ];

                for (const selector of apexContainers) {
                    const container = chartElement.querySelector(selector);
                    if (container) {
                        canvasElement = container.querySelector('canvas') || container.querySelector('svg');
                        if (canvasElement) break;
                    }
                }
            }

            // Strategy 3: Look for any SVG or canvas in the chart area
            if (!canvasElement) {
                canvasElement = chartElement.querySelector('svg') || chartElement.querySelector('canvas');
            }

            // Strategy 4: Wait and retry with all strategies
            if (!canvasElement) {
                console.log('Canvas/SVG not found, waiting and retrying...');
                await new Promise(resolve => setTimeout(resolve, 1000));

                // Retry all strategies
                canvasElement = chartElement.querySelector('canvas') ||
                    chartElement.querySelector('svg') ||
                    chartElement.querySelector('.apexcharts-canvas canvas') ||
                    chartElement.querySelector('.apexcharts-svg svg');
            }

            if (!canvasElement) {
                console.warn('Canvas/SVG element not found after retry');
                console.log('Chart element HTML:', chartElement.innerHTML);
                console.log('Available elements:', {
                    canvas: chartElement.querySelectorAll('canvas').length,
                    svg: chartElement.querySelectorAll('svg').length,
                    apexContainers: chartElement.querySelectorAll('[class*="apexcharts"]').length
                });
                console.log('Proceeding with chart container...');
                // Continue with chart container if canvas not found
            } else {
                console.log('Canvas/SVG element found:', canvasElement.tagName, canvasElement.className);
            }

            console.log('Canvas element found:', canvasElement);

            // Get dimensions
            const chartRect = chartElement.getBoundingClientRect();
            const canvasRect = canvasElement ? canvasElement.getBoundingClientRect() : null;

            console.log('Chart rect:', chartRect);
            console.log('Canvas rect:', canvasRect);

            // Use canvas dimensions for better accuracy, with fallbacks
            const defaultWidth = (type === "pie" || type === "doughnut") ? 600 : 500;
            const contentWidth = (canvasRect ? canvasRect.width : null) || chartRect.width || defaultWidth;
            const defaultHeight = (type === "pie" || type === "doughnut") ? 250 : 350;
            const contentHeight = (canvasRect ? canvasRect.height : null) || chartRect.height || defaultHeight;
            const minWidth = (type === "pie" || type === "doughnut") ? 400 : 500;
            const minHeight = (type === "pie" || type === "doughnut") ? 250 : 350;
            const dynamicWidth = Math.max(contentWidth, minWidth);
            const dynamicHeight = Math.max(contentHeight, minHeight);

            console.log('Dynamic dimensions:', { dynamicWidth, dynamicHeight });

            setUploadMessage('Converting chart to image...');

            // Ultra-high quality settings for enhanced image generation
            const dataUrl = await htmlToImage.toPng(chartElement, {
                cacheBust: true,
                backgroundColor: "#ffffff",
                width: dynamicWidth * 3, // 3x scaling for ultra-high quality
                height: dynamicHeight * 3, // 3x scaling for ultra-high quality
                quality: 1.0, // Maximum quality
                pixelRatio: 3, // High DPI for crisp rendering
                useCORS: true,
                allowTaint: true,
                skipAutoScale: false, // Allow manual scaling
                foreignObjectRendering: true, // Better rendering for complex elements
                style: {
                    transform: `scale(3)`,
                    transformOrigin: 'top left',
                    width: `${dynamicWidth}px`,
                    height: `${dynamicHeight}px`
                },
                filter: (node) => {
                    // Skip script tags and other non-visual elements
                    if (node.tagName === 'SCRIPT' || node.tagName === 'STYLE') {
                        return false;
                    }
                    // Enhance text rendering for better quality
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        node.style.imageRendering = 'high-quality';
                        node.style.textRendering = 'optimizeLegibility';
                        node.style.fontSmooth = 'always';
                        node.style.webkitFontSmoothing = 'antialiased';
                        node.style.mozOsxFontSmoothing = 'grayscale';
                        node.style.fontDisplay = 'swap';
                        node.style.fontVariantLigatures = 'none';
                    }
                    return true;
                }
            });

            console.log('Data URL generated successfully');

            // Convert data URL to blob
            const response = await fetch(dataUrl);
            const blob = await response.blob();

            // Create a file from the blob
            const filename = chartName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";
            const file = new File([blob], filename, { type: 'image/png' });

            // Create FormData for upload
            const formData = new FormData();
            formData.append('file', file);
            formData.append('documentName', documentName);
            formData.append('chartType', type);
            formData.append('originalData', JSON.stringify({
                dataPoints: dataPoints,
                dataPoints2: dataPoints2,
                type: type,
                colors: colors,
                selectedColors: selectedColors,
                chartName: chartName,
                legendPosition: legendPosition,
                showLegends: showLegends
            }));

            console.log('📁 Uploading file:', filename, 'for document:', documentName);
            setUploadMessage('Uploading to OCI...');

            // Get access token from localStorage
            const session = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('session') : null;
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Upload to OCI via our API
            const uploadResponse = await fetch('/api/infographics', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                },
                body: formData
            });

            if (!uploadResponse.ok) {
                const errorData = await uploadResponse.json();
                throw new Error(errorData.error || `Upload failed: ${uploadResponse.status}`);
            }

            const result = await uploadResponse.json();
            console.log('✅ Upload successful:', result);

            // Set success state
            setUploadStatus('success');
            setUploadResult(result);
            setUploadMessage('Chart uploaded successfully!');

        } catch (error) {
            console.error('❌ Upload failed:', error);
            console.error('Error details:', {
                message: error.message,
                stack: error.stack,
                name: error.name
            });
            setUploadStatus('error');
            setUploadMessage(`Upload failed: ${error.message || 'Unknown error occurred'}`);
        }
    };

    const handleCloseUploadDialog = () => {
        setUploadDialogOpen(false);
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
    };

    const handleRetryUpload = () => {
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
        handleUploadToOCI();
    };

    // Function to calculate 5-axis scaling
    const calculateAxisScale = (values) => {
        if (!values || values.length === 0) return { min: 0, max: 10, step: 2 };
        
        const maxValue = Math.max(...values);
        const minValue = Math.min(...values);
        
        // Calculate a nice upper bound that's higher than max value
        let upperBound;
        if (maxValue <= 10) {
            upperBound = Math.ceil(maxValue / 2) * 2 + 2; // Round up to next even number + 2
        } else if (maxValue <= 50) {
            upperBound = Math.ceil(maxValue / 5) * 5 + 5; // Round up to next multiple of 5 + 5
        } else if (maxValue <= 100) {
            upperBound = Math.ceil(maxValue / 10) * 10 + 10; // Round up to next multiple of 10 + 10
        } else {
            upperBound = Math.ceil(maxValue / 20) * 20 + 20; // Round up to next multiple of 20 + 20
        }
        
        const step = upperBound / 5; // 5 steps from 0 to upperBound
        
        return {
            min: 0,
            max: upperBound,
            step: step
        };
    };

    const getApexChartOptions = () => {
        // Validate data points
        if (!dataPoints || dataPoints.length === 0) {
            return {
                series: [],
                options: {
                    chart: { type: 'bar' },
                    xaxis: { categories: [] },
                    yaxis: { min: 0, max: 10 }
                }
            };
        }

        const labels = dataPoints.map(dp => dp.label);
        const series = [];
        const colors = [];

        // Handle different chart types
        if (type === "pie" || type === "doughnut") {
            // For pie/doughnut charts, series should be an array of numbers
            series.push(...dataPoints.map(dp => dp.value));
            colors.push(...dataPoints.map(dp => dp.color));
        } else {
            // For bar, column charts - create separate series for individual colors
            dataPoints.forEach((dp, index) => {
                series.push({
                    name: dp.label,
                    data: [dp.value]
                });
                colors.push(dp.color);
            });
        }

        // Base options for all charts
        const baseOptions = {
            chart: {
                type: type === "bar" ? "bar" :
                    type === "column" ? "bar" :  // ApexCharts uses 'bar' for both bar and column
                        type === "pie" ? "pie" :
                            type === "doughnut" ? "donut" : "bar",
                height: (type === "pie" || type === "doughnut") ? 250 : 350,
                stacked: false,
                toolbar: {
                    show: false
                },
                animations: {
                    enabled: false
                },
                // High quality rendering settings
                fontFamily: 'Calibri, Arial, sans-serif',
                foreColor: '#000000',
                // Enhanced quality settings
                sparkline: {
                    enabled: false
                },
                // Force high DPI rendering
                redrawOnParentResize: true,
                redrawOnWindowResize: true
            },
            colors: colors,
            dataLabels: {
                enabled: true,
                style: {
                    fontSize: '12px',
                    fontWeight: 'bold',
                    colors: [labelPosition === 'inside' ? '#fff' : '#000']
                },
                formatter: function (val, opts) {
                    // For pie/doughnut charts, show actual value instead of percentage
                    if (type === "pie" || type === "doughnut") {
                        const actualValue = opts.w.config.series[opts.seriesIndex];
                        return actualValue;
                    }
                    return val;
                }
            },
            legend: {
                show: showLegends,
                position: legendPosition,
                fontSize: '14px',
                fontWeight: 'bold',
                labels: {
                    colors: '#000',
                    useSeriesColors: true
                },
                markers: {
                    width: 12,
                    height: 12,
                    radius: 6
                },
                itemMargin: {
                    horizontal: 5,
                    vertical: 5
                }
            },
            tooltip: {
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold'
                }
            }
        };

        // Add chart-specific options
        if (type === "pie" || type === "doughnut") {
            // Pie/Doughnut specific options
            baseOptions.labels = labels;
            baseOptions.plotOptions = {
                pie: {
                    dataLabels: {
                        offset: labelPosition === 'outside' ? 20 : 0,
                        formatter: function (val, opts) {
                            // Show actual value instead of percentage
                            const actualValue = opts.w.config.series[opts.seriesIndex];
                            const label = opts.w.config.labels[opts.seriesIndex];
                            return label + ": " + actualValue;
                        }
                    }
                },
                donut: {
                    dataLabels: {
                        offset: labelPosition === 'outside' ? 20 : 0,
                        formatter: function (val, opts) {
                            // Show actual value instead of percentage
                            const actualValue = opts.w.config.series[opts.seriesIndex];
                            const label = opts.w.config.labels[opts.seriesIndex];
                            return label + ": " + actualValue;
                        }
                    }
                }
            };
        } else {
            // Calculate axis scaling for bar/column charts
            const values = dataPoints.map(dp => dp.value);
            const axisScale = calculateAxisScale(values);
            
            // Bar/Column/Line/Stack/Combo specific options
            if (type === "bar") {
                // For horizontal bar charts: Y-axis has categories (labels), X-axis has values
                baseOptions.yaxis = {
                    categories: labels,
                    labels: {
                        style: {
                            fontSize: '14px',
                            fontWeight: 'bold',
                            colors: '#000'
                        }
                    }
                };
                baseOptions.xaxis = {
                    min: axisScale.min,
                    max: axisScale.max,
                    tickAmount: 4, // 4 intervals = 5 points (0, step1, step2, step3, step4)
                    labels: {
                        style: {
                            fontSize: '14px',
                            fontWeight: 'bold',
                            colors: '#000'
                        },
                        formatter: function(value) {
                            return Math.round(value);
                        }
                    }
                };
            } else {
                // For column charts: X-axis has categories (labels), Y-axis has values
                baseOptions.xaxis = {
                    categories: labels,
                    labels: {
                        style: {
                            fontSize: '14px',
                            fontWeight: 'bold',
                            colors: '#000'
                        }
                    }
                };
                baseOptions.yaxis = {
                    min: axisScale.min,
                    max: axisScale.max,
                    tickAmount: 4, // 4 intervals = 5 points (0, step1, step2, step3, step4)
                    labels: {
                        style: {
                            fontSize: '14px',
                            fontWeight: 'bold',
                            colors: '#000'
                        },
                        formatter: function(value) {
                            return Math.round(value);
                        }
                    }
                };
            }

            // Configure plotOptions for bar/column charts
            baseOptions.plotOptions = {
                bar: {
                    horizontal: type === "bar",
                    borderRadius: 4,
                    dataLabels: {
                        position: labelPosition === 'inside' ? 'center' : (type === "bar" ? 'right' : 'top'),
                        style: {
                            fontSize: '12px',
                            fontWeight: 'bold'
                        }
                    }
                }
            };
            
            // Keep bar charts simple with default ordering
            
            // Set colors for individual bars
            baseOptions.colors = colors;
        }

        return {
            series: series,
            options: baseOptions
        };
    };

    const chartData = getApexChartOptions();

    // Chart data and settings
    console.log('Chart Data:', chartData);
    console.log('Label Position:', labelPosition);

    const renderChart = () => {
        try {
            // Force re-render when data changes
            const chartKey = `${type}-${labelPosition}-${showArrows}-${JSON.stringify(dataPoints.map(dp => dp.color))}`;

            // Get the correct chart type for ApexCharts
            const chartType = type === "doughnut" ? "donut" :
                type === "column" ? "bar" :  // Column uses bar type
                    type;

            return (
                <Chart
                    key={chartKey}
                    series={chartData.series}
                    options={chartData.options}
                    type={chartType}
                    width={(type === "pie" || type === "doughnut") ? "100%" : 500}
                    height={(type === "pie" || type === "doughnut") ? 250 : 350}
                />
            );
        } catch (error) {
            console.error('Chart rendering error:', error);
            return (
                <Box sx={{ 
                    display: 'flex', 
                    justifyContent: 'center', 
                    alignItems: 'center', 
                    height: 350,
                    color: 'error.main',
                    flexDirection: 'column',
                    gap: 2
                }}>
                    <Typography variant="h6">Chart Error</Typography>
                    <Typography variant="body2">Please check your data and try again</Typography>
                </Box>
            );
        }
    };

    const showSecondDataset = false; // Removed combo charts
    const showColorSelection = false; // Removed combo charts

    return (
        <>
            <Box>
                {/* {documentName && (
                    <Box sx={{ mb: 2, p: 2, bgcolor: 'primary.main', color: 'white', borderRadius: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                            📄 Document: {documentName}
                        </Typography>
                    </Box>
                )} */}
                {selectedInfographic && (
                    <Box sx={{
                        mb: 2,
                        p: 1,
                        color: '#000000',
                        borderRadius: 1,
                        borderLeft: '4px solid var(--success)',
                        backgroundColor: '#f2f2f2',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1
                    }}>
                        <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            Viewing: {selectedInfographic.filename}
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.8 }}>
                            (Click "Upload to OCI" to regenerate this chart)
                        </Typography>
                    </Box>
                )}
                <Grid container alignItems="stretch" spacing={2} mb={2}>
                    <Grid size={{ lg: 4, md: 6, sm: 12, xs: 12 }}>
                        <Box sx={{ background: '#f2f2f2', padding: '20px', height: '100%' }}>
                            <Grid container spacing={2} mb={2}>
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box className="textfield auto-complete">
                                        <TextField
                                            label="Chart Name [use section name]"
                                            fullWidth
                                            size="small"
                                            value={chartName}
                                            onChange={(e) => setChartName(e.target.value)}
                                        />
                                    </Box>
                                </Grid>
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mb={0}>

                                        <Box mb={2}>
                                            <Typography variant="h6" className="black" gutterBottom>
                                                Data Points
                                            </Typography>
                                        </Box>

                                        {dataPoints.map((dp, index) => (
                                            <Box key={index} display="flex" alignItems="center" gap={1} mt={1} mb={2}>
                                                <Box className="textfield sm auto-complete">
                                                    <Autocomplete
                                                        size="small"
                                                        options={themeColors.map((color, colorIndex) => ({ color, label: `Color ${colorIndex + 1}` }))}
                                                        getOptionLabel={(option) => option.label}
                                                        value={themeColors.map((color, colorIndex) => ({ color, label: `Color ${colorIndex + 1}` })).find(option => option.color === dp.color)}
                                                        onChange={(event, newValue) => {
                                                            if (newValue) {
                                                                const newDataPoints = [...dataPoints];
                                                                newDataPoints[index] = { ...newDataPoints[index], color: newValue.color };
                                                                setDataPoints(newDataPoints);
                                                            }
                                                        }}
                                                        renderOption={(props, option) => {
                                                            const { key, ...otherProps } = props;
                                                            return (
                                                                <Box key={key} component="li" {...otherProps}>
                                                                    <Box
                                                                        sx={{
                                                                            width: 16,
                                                                            height: 16,
                                                                            borderRadius: '50%',
                                                                            backgroundColor: option.color,
                                                                            border: '1px solid #ddd',
                                                                            mr: 1
                                                                        }}
                                                                    />
                                                                    {option.label}
                                                                </Box>
                                                            );
                                                        }}
                                                        renderInput={(params) => (
                                                            <TextField
                                                                {...params}
                                                                size="small"
                                                                sx={{ minWidth: 80 }}
                                                                InputProps={{
                                                                    ...params.InputProps,
                                                                    startAdornment: (
                                                                        <Box
                                                                            sx={{
                                                                                width: 16,
                                                                                height: 16,
                                                                                borderRadius: '50%',
                                                                                backgroundColor: dp.color,
                                                                                border: '1px solid #ddd',
                                                                                mr: 1
                                                                            }}
                                                                        />
                                                                    )
                                                                }}
                                                            />
                                                        )}
                                                    />
                                                </Box>
                                                <Box className="textfield sm auto-complete">
                                                    <TextField
                                                        label={`Label ${index + 1}`}
                                                        fullWidth
                                                        size="small"
                                                        value={dp.label}
                                                        onChange={(e) => {
                                                            const newDataPoints = [...dataPoints];
                                                            newDataPoints[index] = { ...newDataPoints[index], label: e.target.value };
                                                            setDataPoints(newDataPoints);
                                                        }}
                                                    />
                                                </Box>
                                                <Box className="textfield sm auto-complete">
                                                    <TextField
                                                        label={`Value ${index + 1}`}
                                                        fullWidth
                                                        size="small"
                                                        value={dp.value}
                                                        onChange={(e) => {
                                                            const newDataPoints = [...dataPoints];
                                                            newDataPoints[index] = { ...newDataPoints[index], value: Number(e.target.value) };
                                                            setDataPoints(newDataPoints);
                                                        }}
                                                        type="number"
                                                        step="any"
                                                    />
                                                </Box>
                                                <IconButton
                                                    className="action-ico-btn error"
                                                    onClick={() => {
                                                        const newDataPoints = dataPoints.filter((_, i) => i !== index);
                                                        setDataPoints(newDataPoints);
                                                    }}
                                                    size="small"
                                                    color="error"
                                                    aria-label="delete"
                                                >
                                                    <MdDeleteOutline />
                                                </IconButton>
                                            </Box>
                                        ))}
                                        <Button
                                            variant="outlined"
                                            onClick={() => {
                                                const newColor = themeColors[dataPoints.length % themeColors.length] || "#1930ab";
                                                setDataPoints([...dataPoints, { label: "", value: 0, color: newColor }]);
                                            }}
                                            size="small"
                                            className="main-btn sm btn-primary"
                                            startIcon={<AddOutlinedIcon />}
                                        >
                                            Add Data Point
                                        </Button>
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1} px={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                        <FormControlLabel
                                            sx={{ pt: 2 }}
                                            control={
                                                <Switch
                                                    size="small"
                                                    checked={showLegends}
                                                    onChange={(e) => setShowLegends(e.target.checked)}
                                                    color="primary"
                                                />
                                            }
                                            label="Show Legends"
                                        />
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1} px={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                        <Typography variant="h6" gutterBottom sx={{ pt: 2 }}>
                                            Label Position
                                        </Typography>
                                        <ToggleButtonGroup
                                            color="primary"
                                            value={labelPosition}
                                            exclusive
                                            onChange={(e, newPosition) => {
                                                if (newPosition !== null) setLabelPosition(newPosition);
                                            }}
                                            aria-label="label position"
                                            size="small"
                                            fullWidth
                                        >
                                            <ToggleButton value="inside">Inside</ToggleButton>
                                            <ToggleButton value="outside">Outside</ToggleButton>
                                        </ToggleButtonGroup>

                                        {labelPosition === 'outside' && (
                                            <FormControlLabel
                                                sx={{ mt: 2 }}
                                                control={
                                                    <Switch
                                                        size="small"
                                                        checked={showArrows}
                                                        onChange={(e) => setShowArrows(e.target.checked)}
                                                        color="primary"
                                                    />
                                                }
                                                label="Show Arrows"
                                            />
                                        )}
                                    </Box>
                                </Grid>

                                {showLegends && (
                                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                        <Box mt={1}>
                                            <Typography variant="h6" gutterBottom>
                                                Legend Position
                                            </Typography>
                                            <ToggleButtonGroup
                                                color="primary"
                                                value={legendPosition}
                                                exclusive
                                                onChange={(e, newPosition) => {
                                                    if (newPosition !== null) setLegendPosition(newPosition);
                                                }}
                                                aria-label="legend position"
                                                size="small"
                                                fullWidth
                                            >
                                                <ToggleButton value="top">Top</ToggleButton>
                                                <ToggleButton value="bottom">Bottom</ToggleButton>
                                                <ToggleButton value="left">Left</ToggleButton>
                                                <ToggleButton value="right">Right</ToggleButton>
                                            </ToggleButtonGroup>
                                        </Box>
                                    </Grid>
                                )}

                            </Grid>
                        </Box>
                    </Grid>
                    <Grid size={{ lg: 8, md: 6, sm: 12, xs: 12 }}>
                        <Box className="center" mb={2}>
                            <ToggleButtonGroup
                                color="primary"
                                value={type}
                                exclusive
                                fullWidth
                                onChange={(e, newType) => {
                                    if (newType !== null) setType(newType);
                                }}
                                aria-label="chart type"
                                size="small"
                            >
                                <ToggleButton value="bar">Bar</ToggleButton>
                                <ToggleButton value="column">Column</ToggleButton>
                                <ToggleButton value="pie">Pie</ToggleButton>
                                <ToggleButton value="doughnut">Doughnut</ToggleButton>
                            </ToggleButtonGroup>
                        </Box>

                        <Box className="fx_c" sx={{
                            border: '2px solid #000000',
                            background: '#ffffff',
                            borderRadius: '6px',
                            padding: '20px',
                            margin: 'auto',
                            width: (type === "pie" || type === "doughnut") ? '100%' : 'fit-content',
                            maxWidth: (type === "pie" || type === "doughnut") ? '800px' : '600px'
                        }}>
                            <Box ref={chartRef} className="fx_c" sx={{
                                border: '2px solid #ffffff',
                                width: (type === "pie" || type === "doughnut") ? '100%' : '500px',
                                height: (type === "pie" || type === "doughnut") ? '290px' : '390px', // 250px/350px chart + 40px padding
                                background: '#ffffff',
                                borderRadius: '6px',
                                padding: '20px',
                                boxShadow: 'rgba(99, 99, 99, 0.2) 0px 2px 8px 0px',
                                // Ultra-high quality rendering optimizations
                                imageRendering: 'high-quality',
                                textRendering: 'optimizeLegibility',
                                fontSmooth: 'always',
                                WebkitFontSmoothing: 'antialiased',
                                MozOsxFontSmoothing: 'grayscale',
                                fontDisplay: 'swap',
                                fontVariantLigatures: 'none',
                                // Ensure crisp rendering with hardware acceleration
                                transform: 'translateZ(0)',
                                backfaceVisibility: 'hidden',
                                perspective: '1000px',
                                willChange: 'transform',
                                // Ensure content fits within container
                                overflow: 'visible',
                                position: 'relative',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                // Additional quality enhancements
                                shapeRendering: 'geometricPrecision',
                                colorInterpolation: 'sRGB',
                                colorRendering: 'optimizeQuality',
                                // Force high DPI rendering
                                minResolution: '192dpi',
                                resolution: '192dpi'
                            }}>
                                {renderChart()}
                            </Box>
                        </Box>


                        <Stack mt={3} direction="row" alignItems="center" justifyContent="center" spacing={2}>
                            <Button variant="contained" onClick={handleDownload} className="main-btn btn-secondary">Download</Button>
                            <Button
                                variant="contained"
                                onClick={handleUploadToOCI}
                                disabled={!documentName}
                                className="main-btn btn-primary"
                                title={!documentName ? "Document name is required for upload" : "Upload chart to OCI"}
                            >
                                Upload to OCI
                            </Button>
                        </Stack>

                    </Grid>
                </Grid>

            </Box>

            {/* Upload Dialog */}
            <Dialog
                open={uploadDialogOpen}
                onClose={handleCloseUploadDialog}
                maxWidth="sm"
                fullWidth
                PaperProps={{
                    sx: {
                        borderRadius: 2,
                        minHeight: 200
                    }
                }}
            >
                <DialogTitle className='custom-dialog-title'>
                    {uploadStatus === 'loading' && <CircularProgress size={24} />}
                    {uploadStatus === 'success' && <CheckCircle color="success" />}
                    {uploadStatus === 'error' && <Error color="error" />}
                    {uploadStatus === 'loading' && 'Uploading to OCI...'}
                    {uploadStatus === 'success' && 'Upload Complete'}
                    {uploadStatus === 'error' && 'Upload Failed'}
                </DialogTitle>

                <DialogContent sx={{ p: 3 }}>
                    {uploadStatus === 'loading' && (
                        <Box sx={{ textAlign: 'center', py: 3 }}>
                            <CircularProgress size={60} sx={{ mb: 2 }} />
                            <Typography variant="body1" color="text.secondary">
                                {uploadMessage}
                            </Typography>
                        </Box>
                    )}

                    {uploadStatus === 'success' && uploadResult && (
                        <Box>
                            <Alert severity="success" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ✅ Chart uploaded successfully!
                                </Typography>
                            </Alert>

                            <Box sx={{ bgcolor: '#f8f9fa', p: 2, borderRadius: 1, mb: 2 }}>
                                <Typography variant="subtitle2" gutterBottom>
                                    Upload Details:
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>URL:</strong> {uploadResult.infographic.url}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Document:</strong> {uploadResult.infographic.documentName}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Filename:</strong> {uploadResult.infographic.filename}
                                </Typography>
                                <Typography variant="body2">
                                    <strong>Total infographics:</strong> {uploadResult.totalInfographics}
                                </Typography>
                            </Box>
                        </Box>
                    )}

                    {uploadStatus === 'error' && (
                        <Box>
                            <Alert severity="error" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ❌ Upload Failed
                                </Typography>
                                <Typography variant="body2">
                                    {uploadMessage}
                                </Typography>
                            </Alert>
                        </Box>
                    )}
                </DialogContent>

                <DialogActions className='custom-dialog-action'>
                    {uploadStatus === 'error' && (
                        <Button
                            onClick={handleRetryUpload}
                            variant="contained"
                            startIcon={<CloudUpload />}
                            sx={{ mr: 1 }}
                        >
                            Try Again
                        </Button>
                    )}

                    <Button
                        onClick={handleCloseUploadDialog}
                        variant={uploadStatus === 'error' ? 'outlined' : 'contained'}
                    >
                        {uploadStatus === 'loading' ? 'Cancel' : 'Close'}
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

export default ChartBuilder;