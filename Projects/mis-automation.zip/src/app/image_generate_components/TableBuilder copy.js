"use client";
import React, { useRef, useState, useEffect } from "react";
import * as htmlToImage from "dom-to-image-more";
import {
    Button,
    TextField,
    Box,
    Grid,
    Container,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Checkbox,
    FormControlLabel,
    ToggleButton,
    ToggleButtonGroup,
    IconButton,
    Stack,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    CircularProgress,
    Alert
} from "@mui/material";
import { MdDeleteOutline } from "react-icons/md";
import { CheckCircle, Error, CloudUpload } from '@mui/icons-material';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';


const TableBuilder = ({ themeColors = [], documentName = "", selectedInfographic = null }) => {
    // Log the document name when component mounts or documentName changes
    useEffect(() => {
        if (documentName) {
            console.log('📋 TableBuilder received document name:', documentName);
        }
    }, [documentName]);

    // Load selected infographic data when available
    useEffect(() => {
        if (selectedInfographic && selectedInfographic.originalData) {
            console.log('📋 Loading selected infographic data:', selectedInfographic);

            // Load table data from the selected infographic
            const originalData = selectedInfographic.originalData;

            if (originalData.headers) {
                setHeaders(originalData.headers);
            }
            if (originalData.rows) {
                setRows(originalData.rows);
            }
            if (originalData.colors) {
                setColors(originalData.colors);
            }
            if (originalData.headerBgColor) {
                setHeaderBgColor(originalData.headerBgColor);
            }
            if (originalData.showBorders !== undefined) {
                setShowBorders(originalData.showBorders);
            }
            if (originalData.showStripes !== undefined) {
                setShowStripes(originalData.showStripes);
            }
            if (originalData.tableSize) {
                setTableSize(originalData.tableSize);
            }
            if (originalData.headerTextColor) {
                setHeaderTextColor(originalData.headerTextColor);
            }
            if (originalData.cellTextColor) {
                setCellTextColor(originalData.cellTextColor);
            }
            if (originalData.columnWidths) {
                setColumnWidths(originalData.columnWidths);
            }
            if (originalData.tableName) {
                setTableName(originalData.tableName);
            }
        }
    }, [selectedInfographic]);

    const tableRef = useRef(null);
    const [tableName, setTableName] = useState("Table");
    const [headers, setHeaders] = useState(["Update", "Compliance Status", "Data Security Measures"]);
    const [rows, setRows] = useState([
        ["Memory Leaks", "Meets internal standards", "Regular monitoring and writing efficient code to avoid any leak"],
        ["Login-Based Access", "Meets internal standards", "Secure authentication ensures access is limited to authorized users only."],
        ["Role-Based Access", "On track", "Access to functionalities and data restricted based on user roles."]
    ]);
    const [colors, setColors] = useState(themeColors.length > 0 ? themeColors.slice(0, 3) : ["#1930ab", "#fa7604", "#4CAF50"]);
    const [headerBgColor, setHeaderBgColor] = useState(themeColors.length > 0 ? themeColors[0] : "#1930ab");
    const [showBorders, setShowBorders] = useState(true);
    const [showStripes, setShowStripes] = useState(true);
    const [tableSize, setTableSize] = useState("full");
    const [headerTextColor, setHeaderTextColor] = useState("#ffffff");
    const [cellTextColor, setCellTextColor] = useState("#000000");
    const [columnWidths, setColumnWidths] = useState({});

    // Dialog states for upload
    const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
    const [uploadStatus, setUploadStatus] = useState('idle'); // 'idle', 'loading', 'success', 'error'
    const [uploadMessage, setUploadMessage] = useState('');
    const [uploadResult, setUploadResult] = useState(null);

    const handleCloseUploadDialog = () => {
        setUploadDialogOpen(false);
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
    };

    const handleRetryUpload = () => {
        setUploadStatus('idle');
        setUploadMessage('');
        setUploadResult(null);
        handleUploadToOCI();
    };

    const tableSizes = [
        { label: "Full", value: "full", width: 590 }, // Back to original dimensions
        { label: "Half", value: "half", width: 280 }, // Back to original dimensions
        { label: "1/3rd", value: "third", width: 180 } // Back to original dimensions
    ];

    // Update colors when themeColors prop changes
    useEffect(() => {
        if (themeColors.length > 0) {
            const colorsToUse = themeColors.slice(0, Math.max(headers.length, 3));
            setColors(colorsToUse);
            if (themeColors[0]) {
                setHeaderBgColor(themeColors[0]);
            }
        }
    }, [themeColors, headers.length]);

    const handleDownload = async () => {
        if (!tableRef.current) return;

        await new Promise(resolve => setTimeout(resolve, 300)); // Reduced delay

        // Get the actual dimensions of the table content
        const tableElement = tableRef.current;
        const tableRect = tableElement.getBoundingClientRect();

        // Calculate dynamic height based on content
        const contentHeight = tableRect.height;
        const minHeight = 200; // Minimum height for small tables
        const dynamicHeight = Math.max(contentHeight, minHeight);

        // Ultra-high quality settings with canvas scaling
        const scaleFactor = 4; // Scale up the canvas for ultra-crisp images
        const tableWidth = 600; // Original width for tables
        const scaledWidth = tableWidth * scaleFactor;
        const scaledHeight = dynamicHeight * scaleFactor;

        const dataUrl = await htmlToImage.toPng(tableRef.current, {
            cacheBust: true,
            backgroundColor: "#ffffff",
            width: scaledWidth,
            height: scaledHeight,
            quality: 1.0, // Maximum quality
            pixelRatio: 1, // Use 1 since we're scaling manually
            skipAutoScale: false, // Allow scaling for better quality
            useCORS: true, // Enable CORS for better image handling
            allowTaint: true, // Allow tainted canvas for better compatibility
            foreignObjectRendering: true, // Better rendering for complex elements
            style: {
                transform: `scale(${scaleFactor})`,
                transformOrigin: 'top left',
                width: `${tableWidth}px`,
                height: `${dynamicHeight}px`
            },
            filter: (node) => {
                // Ensure all text and elements are rendered at high quality
                if (node.nodeType === Node.ELEMENT_NODE) {
                    node.style.imageRendering = 'high-quality';
                    node.style.textRendering = 'optimizeLegibility';
                    node.style.fontSmooth = 'always';
                    node.style.webkitFontSmoothing = 'antialiased';
                    node.style.mozOsxFontSmoothing = 'grayscale';
                    node.style.fontDisplay = 'swap';
                    node.style.fontVariantLigatures = 'none';
                }
                return true;
            }
        });

        const filename = tableName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";

        const link = document.createElement("a");
        link.download = filename;
        link.href = dataUrl;
        link.click();
    };

    const handleUploadToOCI = async () => {
        if (!tableRef.current) return;

        // Open dialog and set loading state
        setUploadDialogOpen(true);
        setUploadStatus('loading');
        setUploadMessage('Preparing table for upload...');

        try {
            console.log('📁 Starting upload to OCI for document:', documentName);

            setUploadMessage('Generating table image...');
            await new Promise(resolve => setTimeout(resolve, 300)); // Reduced delay

            // Get the actual dimensions of the table content
            const tableElement = tableRef.current;
            const tableRect = tableElement.getBoundingClientRect();

            // Calculate dynamic height based on content
            const contentHeight = tableRect.height;
            const minHeight = 200; // Minimum height for small tables
            const dynamicHeight = Math.max(contentHeight, minHeight);

            setUploadMessage('Converting table to image...');
            
            // Ultra-high quality settings with canvas scaling
            const scaleFactor = 4; // Scale up the canvas for ultra-crisp images
            const tableWidth = 600; // Original width for tables
            const scaledWidth = tableWidth * scaleFactor;
            const scaledHeight = dynamicHeight * scaleFactor;

            const dataUrl = await htmlToImage.toPng(tableRef.current, {
                cacheBust: true,
                backgroundColor: "#ffffff",
                width: scaledWidth,
                height: scaledHeight,
                quality: 1.0, // Maximum quality
                pixelRatio: 1, // Use 1 since we're scaling manually
                skipAutoScale: false, // Allow scaling for better quality
                useCORS: true, // Enable CORS for better image handling
                allowTaint: true, // Allow tainted canvas for better compatibility
                foreignObjectRendering: true, // Better rendering for complex elements
                style: {
                    transform: `scale(${scaleFactor})`,
                    transformOrigin: 'top left',
                    width: `${tableWidth}px`,
                    height: `${dynamicHeight}px`
                },
                filter: (node) => {
                    // Ensure all text and elements are rendered at high quality
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        node.style.imageRendering = 'high-quality';
                        node.style.textRendering = 'optimizeLegibility';
                        node.style.fontSmooth = 'always';
                        node.style.webkitFontSmoothing = 'antialiased';
                        node.style.mozOsxFontSmoothing = 'grayscale';
                        node.style.fontDisplay = 'swap';
                        node.style.fontVariantLigatures = 'none';
                    }
                    return true;
                }
            });

            // Convert data URL to blob
            const response = await fetch(dataUrl);
            const blob = await response.blob();

            // Create a file from the blob
            const filename = tableName.trim().toLowerCase().replace(/\s+/g, "-") + ".png";
            const file = new File([blob], filename, { type: 'image/png' });

            // Create FormData for upload
            const formData = new FormData();
            formData.append('file', file);
            formData.append('documentName', documentName);
            formData.append('tableName', tableName);
            formData.append('originalData', JSON.stringify({
                headers: headers,
                rows: rows,
                colors: colors,
                headerBgColor: headerBgColor,
                showBorders: showBorders,
                showStripes: showStripes,
                tableSize: tableSize,
                headerTextColor: headerTextColor,
                cellTextColor: cellTextColor,
                columnWidths: columnWidths
            }));

            console.log('📁 Uploading file:', filename, 'for document:', documentName);
            setUploadMessage('Uploading to OCI...');

            // Get access token from localStorage
            const session = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('session') : null;
            let accessToken = '';
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (error) {
                    console.error('Error parsing session data:', error);
                }
            }

            if (!accessToken) {
                throw new Error('No access token available. Please login again.');
            }

            // Upload to OCI via our API
            const uploadResponse = await fetch('/api/infographics', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                },
                body: formData
            });

            if (!uploadResponse.ok) {
                const errorData = await uploadResponse.json();
                throw new Error(errorData.error || `Upload failed: ${uploadResponse.status}`);
            }

            const result = await uploadResponse.json();
            console.log('✅ Upload successful:', result);

            // Set success state
            setUploadStatus('success');
            setUploadResult(result);
            setUploadMessage('Table uploaded successfully!');

        } catch (error) {
            console.error('❌ Upload failed:', error);
            setUploadStatus('error');
            setUploadMessage('Unable to upload the file to OCI, try again after some time.');
        }
    };

    const addRow = () => {
        // Create a new row with the same number of columns as headers
        const newRow = new Array(headers.length).fill("New Cell");
        setRows([...rows, newRow]);
    };

    const removeRow = (index) => {
        if (rows.length > 1) {
            const newRows = rows.filter((_, i) => i !== index);
            setRows(newRows);
        }
    };

    const updateRow = (rowIndex, colIndex, value) => {
        const newRows = [...rows];
        newRows[rowIndex][colIndex] = value;
        setRows(newRows);
    };

    const addColumn = () => {
        setHeaders([...headers, `Column ${headers.length + 1}`]);
        const newRows = rows.map(row => [...row, "New Cell"]);
        setRows(newRows);
    };

    const removeColumn = (colIndex) => {
        if (headers.length > 1) {
            const newHeaders = headers.filter((_, i) => i !== colIndex);
            setHeaders(newHeaders);
            const newRows = rows.map(row => row.filter((_, i) => i !== colIndex));
            setRows(newRows);

            // Remove the column width for the deleted column and adjust remaining column indices
            const newColumnWidths = {};
            Object.keys(columnWidths).forEach(key => {
                const keyIndex = parseInt(key);
                if (keyIndex < colIndex) {
                    newColumnWidths[keyIndex] = columnWidths[keyIndex];
                } else if (keyIndex > colIndex) {
                    newColumnWidths[keyIndex - 1] = columnWidths[keyIndex];
                }
            });
            setColumnWidths(newColumnWidths);
        }
    };

    const updateHeader = (index, value) => {
        const newHeaders = [...headers];
        newHeaders[index] = value;
        setHeaders(newHeaders);
    };

    const updateColumnWidth = (columnIndex, width) => {
        // Convert to percentage if it's a valid number
        let widthValue = width;
        if (width && !isNaN(width) && width > 0 && width <= 100) {
            widthValue = `${width}%`;
        } else if (width === '' || width === 'auto') {
            widthValue = 'auto';
        }

        setColumnWidths(prev => ({
            ...prev,
            [columnIndex]: widthValue
        }));
    };

    const getColumnWidth = (columnIndex) => {
        return columnWidths[columnIndex] || 'auto';
    };

    const getColumnWidthPercentage = (columnIndex) => {
        const width = getColumnWidth(columnIndex);
        if (width && width.includes('%')) {
            return width.replace('%', '');
        }
        return '';
    };

    const resetColumnWidths = () => {
        setColumnWidths({});
    };

    const renderTable = () => {
        const selectedSize = tableSizes.find(size => size.value === tableSize) || tableSizes[0];

        return (
            <Box sx={{
                width: selectedSize.width,
                maxWidth: '100%',
                minHeight: 'fit-content'
            }}>
                <TableContainer className="tbcontainer" sx={{
                    margin: '0',
                    height: 'fit-content'
                }}>
                    <Table sx={{
                        minWidth: selectedSize.width * 0.8,
                        margin: '0',
                        height: 'fit-content'
                    }}>
                        <TableHead>
                            <TableRow>
                                {headers.map((header, index) => (
                                    <TableCell
                                        key={index}
                                        sx={{
                                            backgroundColor: headerBgColor,
                                            color: headerTextColor,
                                            fontWeight: 'bold',
                                            textAlign: 'center',
                                            border: showBorders ? '4px solid #fff' : 'none',
                                            padding: '8px 6px', // Back to original padding
                                            whiteSpace: 'normal',
                                            wordWrap: 'break-word',
                                            width: getColumnWidth(index),
                                            minWidth: getColumnWidth(index) === 'auto' ? 'auto' : getColumnWidth(index),
                                            fontSize: '14px' // Back to original font size
                                        }}
                                    >
                                        {header}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.map((row, rowIndex) => (
                                <TableRow
                                    key={rowIndex}
                                    sx={{
                                        backgroundColor: showStripes && rowIndex % 2 === 1 ? '#f5f5f5' : '#ffffff',
                                        '&:hover': {
                                            backgroundColor: '#f0f0f0'
                                        },
                                        height: 'fit-content'
                                    }}
                                >
                                    {row.map((cell, colIndex) => (
                                        <TableCell
                                            key={colIndex}
                                            sx={{
                                                color: cellTextColor,
                                                border: showBorders ? '4px solid #fff' : 'none',
                                                backgroundColor: '#f2f2f2',
                                                padding: '6px 8px', // Back to original padding
                                                textAlign: 'left',
                                                verticalAlign: 'top',
                                                whiteSpace: 'normal',
                                                wordWrap: 'break-word',
                                                height: 'fit-content',
                                                width: getColumnWidth(colIndex),
                                                minWidth: getColumnWidth(colIndex) === 'auto' ? 'auto' : getColumnWidth(colIndex),
                                                fontSize: '12px' // Back to original font size
                                            }}
                                        >
                                            {cell}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Box>
        );
    };

    return (
        <>
            <Box>
                {/* {documentName && (
                    <Box sx={{ mb: 2, p: 2, bgcolor: 'primary.main', color: 'white', borderRadius: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                            📄 Document: {documentName}
                        </Typography>
                    </Box>
                )} */}
                {selectedInfographic && (
                    <Box sx={{
                        mb: 2,
                        p: 1,
                        color: '#000000',
                        borderRadius: 1,
                        borderLeft: '4px solid var(--success)',
                        backgroundColor: '#f2f2f2',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1
                    }}>
                        <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            📋 Viewing: {selectedInfographic.filename}
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.8 }}>
                            (Click "Upload to OCI" to regenerate this table)
                        </Typography>
                    </Box>
                )}
                <Grid container alignItems="stretch" spacing={2} mb={2}>


                    <Grid size={{ lg: 5, md: 6, sm: 12, xs: 12 }}>
                        <Box sx={{ background: '#f2f2f2', padding: '15px', height: '65vh', overflow: 'auto' }}>
                            <Grid container spacing={2} mb={1}>

                                {/* Headers Section */}
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={0}>
                                        <Typography variant="h6" className="fw5" gutterBottom>
                                            Headers <strong>({headers.length})</strong>
                                        </Typography>
                                        {headers.map((header, index) => (
                                            <Box key={index} mt={2} sx={{ display: 'flex', gap: 1, mb: 2, alignItems: 'center' }}>
                                                <Box className="textfield sm auto-complete w100">
                                                    <TextField
                                                        label={`Header ${index + 1}`}
                                                        size="small"
                                                        fullWidth
                                                        value={header}
                                                        onChange={(e) => updateHeader(index, e.target.value)}
                                                    />
                                                </Box>

                                                <Box className="textfield sm auto-complete">
                                                    <TextField
                                                        label="Width %"
                                                        type="number"
                                                        size="small"
                                                        placeholder="Auto"
                                                        value={getColumnWidthPercentage(index)}
                                                        onChange={(e) => updateColumnWidth(index, e.target.value)}
                                                        sx={{ width: '80px' }}
                                                        inputProps={{
                                                            min: 1,
                                                            max: 100,
                                                            step: 1,
                                                            style: { fontSize: '0.75rem' }
                                                        }}
                                                    />
                                                </Box>

                                                <IconButton onClick={() => removeColumn(index)} disabled={headers.length <= 1} className="action-ico-btn error" size="small">
                                                    <MdDeleteOutline />
                                                </IconButton>
                                            </Box>
                                        ))}
                                        <Button size="small" variant="outlined" onClick={addColumn} className="main-btn sm btn-primary" startIcon={<AddOutlinedIcon />}>
                                            Add Column
                                        </Button>
                                    </Box>
                                </Grid>

                                {/* Rows Section */}
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1} sx={{ borderTop: '2px solid #d9d9d9' }}>
                                        <Typography variant="h6" className="fw5" gutterBottom sx={{ mt: 2, mb: 2 }}>
                                            Rows <strong>({rows.length})</strong>
                                        </Typography>
                                        {rows.map((row, rowIndex) => (
                                            <Box key={rowIndex} sx={{ mb: 2, px: 2, border: '1px solid #ddd', borderRadius: 1 }}>
                                                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1, mt: 1 }}>
                                                    <Typography variant="h6" fontWeight="bold">
                                                        Row {rowIndex + 1}
                                                    </Typography>
                                                    <Button
                                                        size="small"
                                                        variant="outlined"
                                                        color="error"
                                                        onClick={() => removeRow(rowIndex)}
                                                        disabled={rows.length <= 1}
                                                        className="main-btn xs btn-error"
                                                    >
                                                        Remove
                                                    </Button>
                                                </Box>
                                                {row.map((cell, colIndex) => (
                                                    <Box key={colIndex} className="textfield sm auto-complete">
                                                        <TextField
                                                            label={`Cell ${rowIndex + 1}-${colIndex + 1}`}
                                                            size="small"
                                                            value={cell}
                                                            onChange={(e) => updateRow(rowIndex, colIndex, e.target.value)}
                                                            fullWidth
                                                            multiline
                                                            rows={1}
                                                            sx={{ mb: 2 }}
                                                        />
                                                    </Box>
                                                ))}
                                            </Box>
                                        ))}
                                        <Button size="small" variant="outlined" onClick={addRow} className="main-btn sm btn-primary" startIcon={<AddOutlinedIcon />}>
                                            Add Row
                                        </Button>
                                    </Box>
                                </Grid>

                            </Grid>
                        </Box>
                    </Grid>

                    <Grid size={{ lg: 7, md: 6, sm: 12, xs: 12 }}>

                        <Box mt={1} mb={4}>
                            <Grid container spacing={2} mb={1}>
                                <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                    <Box mt={0} className="textfield auto-complete">
                                        <TextField
                                            label="Table Heading [use section name]"
                                            fullWidth
                                            size="small"
                                            value={tableName}
                                            onChange={(e) => setTableName(e.target.value)}
                                        />
                                    </Box>
                                </Grid>

                                {/* Header Background Color */}
                                {/* <Grid size={{ lg: 3, md: 3, sm: 6, xs: 12 }}>
                                    <Box mt={1} className="textfield auto-complete">
                                        <TextField
                                            label="Header Background Color"
                                            fullWidth
                                            size="small"
                                            value={headerBgColor}
                                            onChange={(e) => setHeaderBgColor(e.target.value)}
                                        />
                                    </Box>
                                </Grid> */}

                                {/* Header Text Color */}
                                <Grid size={{ lg: 3, md: 3, sm: 6, xs: 12 }}>
                                    <Box mt={0} className="textfield auto-complete">
                                        <TextField
                                            label="Header Text Color"
                                            fullWidth
                                            size="small"
                                            value={headerTextColor}
                                            onChange={(e) => setHeaderTextColor(e.target.value)}
                                        />
                                    </Box>
                                </Grid>

                                {/* Cell Text Color */}
                                <Grid size={{ lg: 3, md: 3, sm: 6, xs: 12 }}>
                                    <Box mt={0} className="textfield auto-complete">
                                        <TextField
                                            label="Cell Text Color"
                                            fullWidth
                                            size="small"
                                            value={cellTextColor}
                                            onChange={(e) => setCellTextColor(e.target.value)}
                                        />
                                    </Box>
                                </Grid>


                                {/* Theme Colors */}
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={0}>
                                        <Typography variant="h6">
                                            Select Header Background (from document)
                                        </Typography>
                                        <Box display="flex" gap={1} flexWrap="wrap" alignItems="center" pt={1}>
                                            {themeColors.length > 0 ? (
                                                themeColors.map((color, index) => (
                                                    <Box
                                                        key={index}
                                                        sx={{
                                                            width: 16,
                                                            height: 16,
                                                            borderRadius: '50%',
                                                            backgroundColor: color,
                                                            border: '1px solid #ddd',
                                                            cursor: 'pointer',
                                                            '&:hover': {
                                                                transform: 'scale(1.1)',
                                                                border: '1px solid #000'
                                                            }
                                                        }}
                                                        title={`Color ${index + 1}: ${color}`}
                                                        onClick={() => setHeaderBgColor(color)}
                                                    />
                                                ))
                                            ) : (
                                                <Typography variant="body2" color="textSecondary">
                                                    No theme colors available
                                                </Typography>
                                            )}
                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>


                        <Box id="mis-table" mt={4} className="fx_c" sx={{ border: '2px solid #000000', background: '#ffffff', borderRadius: '6px', padding: '18px', margin: 'auto' }}>

                            <Box ref={tableRef} className="fx_c" sx={{ 
                                border: '2px solid #ffffff', 
                                width: 'fit-content', 
                                background: '#ffffff', 
                                borderRadius: '6px', 
                                padding: '2px', 
                                boxShadow: 'rgba(99, 99, 99, 0.2) 0px 2px 8px 0px',
                                // Ultra-high quality rendering optimizations
                                imageRendering: 'high-quality',
                                textRendering: 'optimizeLegibility',
                                fontSmooth: 'always',
                                WebkitFontSmoothing: 'antialiased',
                                MozOsxFontSmoothing: 'grayscale',
                                fontDisplay: 'swap',
                                fontVariantLigatures: 'none',
                                // Ensure crisp rendering with hardware acceleration
                                transform: 'translateZ(0)',
                                backfaceVisibility: 'hidden',
                                perspective: '1000px',
                                willChange: 'transform',
                                // Force high DPI rendering
                                minHeight: '200px',
                                minWidth: '600px'
                            }}>
                                {renderTable()}
                            </Box>

                        </Box>


                        <Box>
                            <Stack mt={1} direction="row" alignItems="center" justifyContent="center" spacing={2}>
                                <Button variant="contained" onClick={handleDownload} className="main-btn btn-secondary">Download</Button>
                                <Button
                                    variant="contained"
                                    onClick={handleUploadToOCI}
                                    disabled={!documentName}
                                    className="main-btn btn-primary"
                                    title={!documentName ? "Document name is required for upload" : "Upload table to OCI"}
                                >
                                    Upload to OCI
                                </Button>
                            </Stack>
                        </Box>


                    </Grid>


                </Grid>


            </Box>

            {/* Upload Dialog */}
            <Dialog
                open={uploadDialogOpen}
                onClose={handleCloseUploadDialog}
                maxWidth="sm"
                fullWidth
                PaperProps={{
                    sx: {
                        borderRadius: 2,
                        minHeight: 200
                    }
                }}
            >
                <DialogTitle className='custom-dialog-title'>
                    {uploadStatus === 'loading' && <CircularProgress size={24} />}
                    {uploadStatus === 'success' && <CheckCircle color="success" />}
                    {uploadStatus === 'error' && <Error color="error" />}
                        {uploadStatus === 'loading' && 'Uploading to OCI...'}
                        {uploadStatus === 'success' && 'Upload Complete'}
                        {uploadStatus === 'error' && 'Upload Failed'}
                </DialogTitle>

                <DialogContent sx={{ p: 3 }}>
                    {uploadStatus === 'loading' && (
                        <Box sx={{ textAlign: 'center', py: 3 }}>
                            <CircularProgress size={60} sx={{ mb: 2 }} />
                            <Typography variant="body1" color="text.secondary">
                                {uploadMessage}
                            </Typography>
                        </Box>
                    )}

                    {uploadStatus === 'success' && uploadResult && (
                        <Box>
                            <Alert severity="success" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ✅ Table uploaded successfully!
                                </Typography>
                            </Alert>

                            <Box sx={{ bgcolor: '#f8f9fa', p: 2, borderRadius: 1, mb: 2 }}>
                                <Typography variant="subtitle2" gutterBottom>
                                    Upload Details:
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>URL:</strong> {uploadResult.infographic.url}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Document:</strong> {uploadResult.infographic.documentName}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    <strong>Filename:</strong> {uploadResult.infographic.filename}
                                </Typography>
                                <Typography variant="body2">
                                    <strong>Total infographics:</strong> {uploadResult.totalInfographics}
                                </Typography>
                            </Box>
                        </Box>
                    )}

                    {uploadStatus === 'error' && (
                        <Box>
                            <Alert severity="error" sx={{ mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    ❌ Upload Failed
                                </Typography>
                                <Typography variant="body2">
                                    {uploadMessage}
                                </Typography>
                            </Alert>
                        </Box>
                    )}
                </DialogContent>

                <DialogActions className='custom-dialog-action'>
                    {uploadStatus === 'error' && (
                        <Button
                            onClick={handleRetryUpload}
                            variant="contained"
                            startIcon={<CloudUpload />}
                            sx={{ mr: 1 }}
                        >
                            Try Again
                        </Button>
                    )}

                    <Button
                        onClick={handleCloseUploadDialog}
                        variant={uploadStatus === 'error' ? 'outlined' : 'contained'}
                    >
                        {uploadStatus === 'loading' ? 'Cancel' : 'Close'}
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

export default TableBuilder;