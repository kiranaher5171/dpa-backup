'use client';
import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useEmployeeStore } from '@/store/employeeStore';
import { Box, Button, Container, Grid, TextField, Typography, IconButton, InputAdornment, FormControlLabel, Checkbox, CircularProgress } from '@mui/material';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import Image from 'next/image';
import BG from "../../../../public/auth/auth-bg.jpg";
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import BLOGO from "../../../../public/logos/dpa-black.svg"
import NewLogo from "../../../../public/logos/new-logo-sm.png"

const validationSchema = Yup.object({
    employeeCode: Yup.string()
        .required("Employee ID can't be blank.")
        .matches(/^\d+$/, "Enter valid Employee ID.")
        .matches(/^\d{1,4}$/, "Enter valid Employee ID."),
    password: Yup.string().required('Password is required'),
});

// Helper functions to reduce cognitive complexity
const calculateExpiryTime = (rememberMe) => {
    const currentTime = new Date();
    if (rememberMe) {
        return new Date(currentTime.getTime() + 24 * 60 * 60 * 1000); // 1 day
    }
    return new Date(currentTime.getTime() + 4 * 60 * 60 * 1000); // 4 hours
};

const saveUserData = (values) => {
    if (values.rememberMe) {
        localStorage.setItem("userData", JSON.stringify({
            employeeCode: values.employeeCode,
            rememberMe: values.rememberMe,
        }));
    } else {
        localStorage.removeItem("userData");
    }
};

const saveSessionData = (token, employee_code, name, rememberMe) => {
    const expirationTime = calculateExpiryTime(rememberMe);
    localStorage.setItem("session", JSON.stringify({
        accessToken: token,
        employeeCode: employee_code,
        employeeName: name,
    }));
    localStorage.setItem("expireTime", expirationTime.toISOString());
};

const getAccessToken = async (values) => {
    // Validate environment variables
    if (!process.env.NEXT_PUBLIC_SSO_APP_ACCESS_TOKEN_URL) {
        throw new Error('SSO authentication configuration is missing. Please contact administrator.');
    }

    if (!process.env.NEXT_PUBLIC_SSO_APP_GET_ACCESS_KEY_TOKEN) {
        throw new Error('SSO authentication configuration is missing. Please contact administrator.');
    }

    const formData = new FormData();
    formData.append("employee_code", values.employeeCode);
    formData.append("password", values.password);
    formData.append("secret_key", process.env.NEXT_PUBLIC_SSO_APP_GET_ACCESS_KEY_TOKEN);

    try {
        const response = await fetch(process.env.NEXT_PUBLIC_SSO_APP_ACCESS_TOKEN_URL, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`SSO authentication failed: ${response.status} - ${errorText}`);
        }

        return await response.json();
    } catch (fetchError) {
        if (fetchError.name === 'TypeError' && fetchError.message.includes('fetch')) {
            throw new Error('Network error. Please check your internet connection and try again.');
        }
        throw fetchError;
    }
};

const getTimesheetToken = async (accessToken) => {
    // Validate environment variables
    if (!process.env.NEXT_PUBLIC_SSO_APP_TIMESHEET_TOKEN_URL) {
        throw new Error('Timesheet authentication configuration is missing. Please contact administrator.');
    }

    const formData = new FormData();
    formData.append("C-X-ssoJwt", accessToken);

    try {
        const response = await fetch(process.env.NEXT_PUBLIC_SSO_APP_TIMESHEET_TOKEN_URL, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Timesheet authentication failed: ${response.status} - ${errorText}`);
        }

        return await response.json();
    } catch (fetchError) {
        if (fetchError.name === 'TypeError' && fetchError.message.includes('fetch')) {
            throw new Error('Network error. Please check your internet connection and try again.');
        }
        throw fetchError;
    }
};

const fetchEmployeeDetails = async (token, getLoggedInUserDetails, setEmployeeDetails, setUserRole) => {
    try {
        console.log('🔐 Login: Fetching employee details and checking role...');
        const employeeResult = await getLoggedInUserDetails(token);
        if (employeeResult.success) {
            setEmployeeDetails(employeeResult.data);
            setUserRole(employeeResult.role);
            console.log(`🔐 Login: Role set to ${employeeResult.role} for employee ${employeeResult.data.employee_code}`);
        }
    } catch (error) {
        // Log error for debugging but don't show technical details to user
        if (process.env.NODE_ENV === 'development') {
            console.warn('Error fetching employee details (development):', error.message);
        }
        // Don't fail login if employee details fetch fails
    }
};

const getErrorMessage = (error) => {
    // Handle configuration errors
    if (error.message.includes('configuration is missing')) {
        return error.message;
    }

    // Handle network errors
    if (error.message.includes('Network error')) {
        return error.message;
    }

    // Parse the error message to extract more specific information
    if (error.message.includes('SSO authentication failed')) {
        try {
            // Try to parse the JSON error response
            const errorMatch = error.message.match(/\{.*\}/);
            if (errorMatch) {
                const errorData = JSON.parse(errorMatch[0]);
                if (errorData.detail) {
                    return errorData.detail;
                }
            }
        } catch (parseError) {
            // If JSON parsing fails, fall back to default message
        }
        return 'Invalid employee code or password. Please check your credentials and try again.';
    }
    if (error.message.includes('Timesheet authentication failed')) {
        return 'Timesheet authentication failed. Please check your credentials and try again.';
    }
    if (error.message.includes('fetch')) {
        return 'Network error. Please check your internet connection and try again.';
    }
    return 'Incorrect combination of employee code & password. Please try again.';
};

export default function SSOLoginPage() {
    const router = useRouter();
    const { getLoggedInUserDetails, setEmployeeDetails, setUserRole } = useEmployeeStore();
    const [showPassword, setShowPassword] = React.useState(false);
    const [isLoading, setLoading] = useState(false);
    const [open, setOpen] = React.useState(false);
    const [alertSeverity, setAlertSeverity] = React.useState('success');
    const [alertMessage, setAlertMessage] = React.useState('');
    const [loginData, setLoginData] = useState(null);

    // Get saved user data from localStorage
    const savedUserData = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem("userData") || "{}") : {};

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    // Simplified SSO authentication flow
    useEffect(() => {
        if (!loginData) return;

        const performSSOAuth = async () => {
            const { values } = loginData;
            saveUserData(values);

            try {
                setLoading(true);

                // Get access token
                const accessTokenData = await getAccessToken(values);

                // Get timesheet token
                const timesheetData = await getTimesheetToken(accessTokenData.access_token);

                const { token, employee_code, name } = timesheetData;
                saveSessionData(token, employee_code, name, values.rememberMe);

                // Fetch employee details
                await fetchEmployeeDetails(token, getLoggedInUserDetails, setEmployeeDetails, setUserRole);

                setAlertSeverity('success');
                setAlertMessage('Login successful!');
                setOpen(true);

                setTimeout(() => {
                    router.push('/main-dashboard');
                }, 1500);

            } catch (error) {
                // Log error for debugging but don't show technical details to user
                if (process.env.NODE_ENV === 'development') {
                    console.warn("SSO Login error (development):", error.message);
                }
                setAlertSeverity('error');
                setAlertMessage(getErrorMessage(error));
                setOpen(true);
            } finally {
                setLoading(false);
                setLoginData(null);
            }
        };

        performSSOAuth();
    }, [loginData, getLoggedInUserDetails, setEmployeeDetails, setUserRole, router]);

    const formik = useFormik({
        initialValues: {
            employeeCode: savedUserData.employeeCode || '',
            password: '',
            rememberMe: savedUserData.rememberMe || false,
        },
        validationSchema,
        onSubmit: async (values, { setSubmitting }) => {
            try {
                setLoginData({ values });
            } catch (err) {
                // Log error for debugging but don't show technical details to user
                if (process.env.NODE_ENV === 'development') {
                    console.warn('Form submission error (development):', err.message);
                }
                setAlertSeverity('error');
                setAlertMessage('Something went wrong. Please try again.');
                setOpen(true);
            } finally {
                setSubmitting(false);
            }
        },
    });

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') return;
        setOpen(false);
    };

    // Check for existing session and redirect if valid
    useEffect(() => {
        const sessionData = localStorage.getItem("session");
        if (sessionData) {
            router.push('/main-dashboard');
        }
    }, [router]);

    // If session exists, don't render the login form
    const sessionData = typeof window !== 'undefined' ? localStorage.getItem("session") : null;
    if (sessionData) {
        return (
            <Box className="auth-page">
                <Image
                    src={BG}
                    alt="Background Image"
                    fill
                    style={{ objectFit: 'cover', objectPosition: 'center', minHeight: '100vh' }}
                    draggable={false}
                    className=""
                />
                <Box className="white-overlay" />
                <Container maxWidth="xs" sx={{ position: 'relative', zIndex: '+999' }}>
                    <Box className='form-card'>
                        <Box className="center" pt={4}>
                            <CircularProgress size={60} />
                            <Typography variant="h6" sx={{ mt: 2 }}>
                                Redirecting to dashboard...
                            </Typography>
                        </Box>
                    </Box>
                </Container>
            </Box>
        );
    }

    return (
        <Box className="auth-page">
            <Image
                src={BG}
                alt="Background Image"
                fill
                style={{ objectFit: 'cover', objectPosition: 'center', minHeight: '100vh' }}
                draggable={false}
            />

            <Box className="white-overlay" />

            <Container maxWidth="xs" sx={{ position: 'relative', zIndex: '+999' }}>
                <Box className='form-card'>
                    <Box className="center" pt={1}>
                        {/* <Typography variant="h1" className='form-heading' gutterBottom>
                            Welcome Back!
                        </Typography> */}
                        <Box mb={2} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <Image
                                src={NewLogo}
                                alt="logo"
                                height={50}
                                // width={auto} 
                                priority
                            />
                        </Box>
                        <Box sx={{ width: '100px', height: '4px', background: '#1930ab', fontSize: '0px', margin: 'auto', borderRadius: '26px' }}></Box>
                        <Box pt={2}>
                            <Typography variant="h6" className='form-subheading' gutterBottom>
                                Please enter Timesheet login <br /> details to sign in
                            </Typography>
                        </Box>
                    </Box>

                    <Box mt={4}>
                        <form onSubmit={formik.handleSubmit} noValidate>
                            <Grid container spacing={2}>
                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box className="textfield">
                                        <TextField
                                            fullWidth
                                            size="small"
                                            label="Employee ID"
                                            name="employeeCode"
                                            variant="outlined"
                                            value={formik.values.employeeCode}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                            error={formik.touched.employeeCode && Boolean(formik.errors.employeeCode)}
                                            helperText={formik.touched.employeeCode && formik.errors.employeeCode}
                                            placeholder="Enter Employee ID"
                                        />
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1} className="textfield">
                                        <TextField
                                            fullWidth
                                            size="small"
                                            label="Password"
                                            name="password"
                                            type={showPassword ? 'text' : 'password'}
                                            variant="outlined"
                                            value={formik.values.password}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                            error={formik.touched.password && Boolean(formik.errors.password)}
                                            helperText={formik.touched.password && formik.errors.password}
                                            InputProps={{
                                                endAdornment: (
                                                    <InputAdornment position="end">
                                                        <IconButton
                                                            aria-label="toggle password visibility"
                                                            onClick={handleClickShowPassword}
                                                            onMouseDown={handleMouseDownPassword}
                                                            edge="end"
                                                            size='medium'
                                                        >
                                                            {showPassword ? <VisibilityOff fontSize='small' /> : <Visibility fontSize='small' />}
                                                        </IconButton>
                                                    </InputAdornment>
                                                )
                                            }}
                                        />
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1}>
                                        <FormControlLabel
                                            control={
                                                <Checkbox
                                                    size="small"
                                                    checked={formik.values.rememberMe}
                                                    onChange={(e) => formik.setFieldValue("rememberMe", e.target.checked)}
                                                    name="rememberMe"
                                                />
                                            }
                                            label="Remember me"
                                        />
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box mt={1}>
                                        <Typography variant="body2" color="textSecondary" align="center">
                                            Note: Use Timesheet Credentials for Login
                                        </Typography>
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                    <Box>
                                        <Button
                                            variant="contained"
                                            color="primary"
                                            type="submit"
                                            fullWidth
                                            className='auth-btn'
                                            disabled={formik.isSubmitting || isLoading || !formik.isValid || !formik.dirty}
                                        >
                                            {isLoading ? (
                                                <CircularProgress size={24} color="inherit" />
                                            ) : (
                                                'Sign in'
                                            )}
                                        </Button>
                                    </Box>
                                </Grid>
                            </Grid>
                        </form>
                    </Box>
                </Box>
            </Container>

            <Snackbar open={open} autoHideDuration={4000} onClose={handleClose}>
                <Alert onClose={handleClose} severity={alertSeverity} variant="filled" sx={{ width: '100%' }}>
                    {alertMessage}
                </Alert>
            </Snackbar>
        </Box>
    );
}