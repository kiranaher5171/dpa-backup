import React from 'react'
import UsersTable from './UsersTable'
import { Box } from '@mui/material'
import BasicLayout from '../layouts/BasicLayout'

const page = () => {
    return (
        <BasicLayout>
            <Box className="main-box">
                <UsersTable />
            </Box>
        </BasicLayout>
    )
}

export default page