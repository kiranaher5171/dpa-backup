"use client";
import React, { useState, useEffect, useMemo } from 'react';
import {
    Box,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TextField,
    InputAdornment,
    Pagination,
    Typography,
    CircularProgress,
    Alert,
    Paper,
    Grid,
    Chip,
    Button,
    Switch,
    FormControlLabel,
    Container
} from '@mui/material';
import { Search, Refresh, Login, Person, Sync } from '@mui/icons-material';
import { useRoleAccess } from '@/hooks/useRoleAccess';
import { useRouter } from 'next/navigation';

const UsersTable = () => {
    const { isAdmin } = useRoleAccess();
    const router = useRouter();
    const [employees, setEmployees] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage] = useState(10);
    // Role management state removed for now
    const [usingMockData, setUsingMockData] = useState(false); // Track if using mock data
    const [roleStates, setRoleStates] = useState({}); // Track role states for each employee
    const [roleUpdates, setRoleUpdates] = useState({}); // Track pending role updates
    const [session, setSession] = useState(null); // Track session state
    const [syncing, setSyncing] = useState(false); // Track sync status
    const [syncMessage, setSyncMessage] = useState(''); // Track sync messages

    // Function to fetch employees only (simplified) - following SSO dashboard pattern
    const fetchEmployees = async () => {
        // Check if session and access token are available (following SSO dashboard pattern)
        if (!session || !session.accessToken) {
            setEmployees([]);
            setError('No session or access token available. Please login again.');
            return;
        }

        try {
            setLoading(true);
            setError(null);
            setUsingMockData(false);

            console.log('🔍 Fetching all employees from local database...');

            // Fetch employees from local database
            const response = await fetch('/api/get-all-employees', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${session.accessToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`Failed to fetch employees from database: ${response.status} - ${response.statusText}`);
            }

            const data = await response.json();
            console.log('🔍 Database response:', data);

            if (!data.success) {
                throw new Error(data.error || 'Failed to fetch employees from database');
            }

            // Process the data to match our expected format
            const employeesArray = data.employees.map(employee => ({
                id: employee.ID,
                emp_code: employee.EMP_CODE,
                display_name: employee.EMP_NAME,
                is_admin: employee.IS_ADMIN === 1
            }));

            setEmployees(employeesArray);
            console.log('🔍 Processed employees from database:', employeesArray);

        } catch (err) {
            console.error('❌ Error fetching employees:', err);

            // If it's an authentication or session error, try using mock data as fallback
            if (err.message.includes('Authentication failed') ||
                err.message.includes('401') ||
                err.message.includes('No session found') ||
                err.message.includes('No access token')) {
                console.warn('⚠️ Authentication/Session failed, falling back to mock data');
                const mockData = {
                    "0": { "id": "501", "display_name": "Amol Patil" },
                    "1": { "id": "1949", "display_name": "Admin User" },
                    "2": { "id": "1001", "display_name": "John Doe" },
                    "3": { "id": "1002", "display_name": "Jane Smith" },
                    "4": { "id": "1003", "display_name": "Bob Johnson" },
                    "5": { "id": "1004", "display_name": "Alice Brown" }
                };

                const employeesArray = Object.values(mockData).map((employee, index) => ({
                    id: employee.id || `emp_${index}`,
                    emp_code: employee.id || `emp_${index}`,
                    display_name: employee.display_name || 'Unknown'
                }));

                setEmployees(employeesArray);
                setUsingMockData(true);
                console.log('🔍 Using mock employees data as fallback:', employeesArray);
            } else {
                setError(err.message);
            }
        } finally {
            setLoading(false);
        }
    };

    // Check session and fetch employees on component mount (following SSO dashboard pattern)
    useEffect(() => {
        const checkSession = () => {
            try {
                const sessionData = localStorage.getItem('session');
                const expireTime = localStorage.getItem('expireTime');

                if (!sessionData || !expireTime) {
                    console.warn('⚠️ No session or expire time found, redirecting to login');
                    router.push('/auth/sso-login');
                    return;
                }

                const session = JSON.parse(sessionData);
                const expireDate = new Date(expireTime);
                const currentDate = new Date();

                if (currentDate > expireDate) {
                    console.warn('⚠️ Session expired, clearing storage and redirecting to login');
                    localStorage.clear();
                    router.push('/auth/sso-login');
                    return;
                }

                if (!session.accessToken) {
                    console.warn('⚠️ No access token in session, redirecting to login');
                    router.push('/auth/sso-login');
                    return;
                }

                // Session is valid, set it (fetchEmployees will be called by useEffect)
                setSession(session);
            } catch (error) {
                console.error('❌ Session check error:', error);
                router.push('/auth/sso-login');
            }
        };

        checkSession();
    }, []);

    // Fetch employees when session is available (following SSO dashboard pattern)
    useEffect(() => {
        if (session && session.accessToken) {
            fetchEmployees();
        }
    }, [session]);

    // Set role states when employees are loaded
    useEffect(() => {
        if (employees.length > 0) {
            setRoleStatesFromEmployees();
        }
    }, [employees.length]); // Only depend on length, not the entire array

    // Refresh function
    const handleRefresh = () => {
        if (session && session.accessToken) {
            fetchEmployees();
        }
    };

    // Handle login redirect
    const handleLoginRedirect = () => {
        router.push('/auth/sso-login');
    };

    // Filter and sort employees based on search query and admin status
    const filteredEmployees = useMemo(() => {
        let filtered = employees;

        // Apply search filter if query exists
        if (searchQuery.trim()) {
            const query = searchQuery.toLowerCase();
            filtered = employees.filter(emp =>
                emp.emp_code.toLowerCase().includes(query) ||
                emp.display_name.toLowerCase().includes(query)
            );
        }

        // Sort: Admins first, then by name alphabetically
        return filtered.sort((a, b) => {
            // First sort by admin status (admins first)
            const aIsAdmin = roleStates[a.emp_code] || false;
            const bIsAdmin = roleStates[b.emp_code] || false;

            if (aIsAdmin && !bIsAdmin) return -1; // a is admin, b is not
            if (!aIsAdmin && bIsAdmin) return 1;  // b is admin, a is not

            // If both have same admin status, sort by name alphabetically
            return (a.display_name || '').localeCompare(b.display_name || '');
        });
    }, [employees, searchQuery, roleStates]);

    // Pagination
    const totalPages = Math.ceil(filteredEmployees.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const paginatedEmployees = filteredEmployees.slice(startIndex, startIndex + itemsPerPage);

    // Function to set role states from employee data (simplified since we have is_admin from database)
    const setRoleStatesFromEmployees = () => {
        console.log('🔍 Setting role states from employee data...');

        // Create role states from the is_admin property we already have
        const roleStates = {};
        employees.forEach(employee => {
            roleStates[employee.emp_code] = employee.is_admin || false;
        });

        setRoleStates(roleStates);
        console.log('🔍 Role states set from employee data:', roleStates);
    };

    // Function to sync employees from external API
    const handleSyncEmployees = async () => {
        if (!session || !session.accessToken) {
            setSyncMessage('No session available. Please login again.');
            return;
        }

        try {
            setSyncing(true);
            setSyncMessage('Syncing employees from external API...');

            console.log('🔄 Starting manual employee sync...');

            const response = await fetch('/api/sync-employees', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${session.accessToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`Sync failed: ${response.status} - ${response.statusText}`);
            }

            const data = await response.json();
            console.log('✅ Sync completed:', data);

            if (data.success) {
                setSyncMessage(`Sync completed! Inserted: ${data.data.inserted}, Updated: ${data.data.updated}, Total: ${data.data.total_employees}`);

                // Refresh the employee list after successful sync
                await fetchEmployees();
            } else {
                throw new Error(data.error || 'Sync failed');
            }

        } catch (error) {
            console.error('❌ Sync error:', error);
            setSyncMessage(`Sync failed: ${error.message}`);
        } finally {
            setSyncing(false);

            // Clear sync message after 5 seconds
            setTimeout(() => {
                setSyncMessage('');
            }, 5000);
        }
    };

    // Function to handle role toggle
    const handleRoleToggle = async (empCode, empName, currentIsAdmin) => {
        // Check if session is available (following SSO dashboard pattern)
        if (!session || !session.accessToken) {
            setError('No session or access token available. Please login again.');
            return;
        }

        try {
            const newIsAdmin = !currentIsAdmin;

            // Optimistically update the UI
            setRoleUpdates(prev => ({ ...prev, [empCode]: 'updating' }));
            setRoleStates(prev => ({ ...prev, [empCode]: newIsAdmin }));

            let response;

            try {
                if (newIsAdmin) {
                    // Add as admin
                    response = await fetch('/api/admin-role', {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${session.accessToken}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            emp_code: empCode,
                            emp_name: empName
                        })
                    });
                } else {
                    // Remove from admin
                    response = await fetch(`/api/admin-role?emp_code=${empCode}`, {
                        method: 'DELETE',
                        headers: {
                            'Authorization': `Bearer ${session.accessToken}`,
                            'Content-Type': 'application/json'
                        }
                    });
                }
            } catch (fetchError) {
                console.error('❌ Error in role toggle fetch:', fetchError);
                throw new Error(`Network error updating role: ${fetchError.message}`);
            }

            if (!response) {
                throw new Error('No response received from role update API');
            }

            if (response.ok) {
                const result = await response.json();
                console.log('✅ Role update successful:', result);

                setRoleUpdates(prev => ({ ...prev, [empCode]: 'success' }));

                // Refresh role states from employee data to ensure consistency
                setRoleStatesFromEmployees();

                // Clear success status after 2 seconds
                setTimeout(() => {
                    setRoleUpdates(prev => {
                        const newUpdates = { ...prev };
                        delete newUpdates[empCode];
                        return newUpdates;
                    });
                }, 2000);
            } else {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to update role');
            }
        } catch (err) {
            console.error('❌ Error updating role:', err);

            // Revert the optimistic update
            setRoleStates(prev => ({ ...prev, [empCode]: currentIsAdmin }));
            setRoleUpdates(prev => ({ ...prev, [empCode]: 'error' }));

            // If it's a session-related error, redirect to login
            if (err.message.includes('No session found') ||
                err.message.includes('No access token') ||
                err.message.includes('session is null')) {
                console.warn('⚠️ Session error, redirecting to login');
                router.push('/auth/sso-login');
                return;
            }

            // Clear error status after 3 seconds
            setTimeout(() => {
                setRoleUpdates(prev => {
                    const newUpdates = { ...prev };
                    delete newUpdates[empCode];
                    return newUpdates;
                });
            }, 3000);
        }
    };

    // Handle page change
    const handlePageChange = (event, page) => {
        setCurrentPage(page);
    };

    // Handle search
    const handleSearchChange = (event) => {
        setSearchQuery(event.target.value);
        setCurrentPage(1); // Reset to first page when searching
    };

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
                <CircularProgress />
                <Typography variant="body1" sx={{ ml: 2 }}>
                    Loading employees...
                </Typography>
            </Box>
        );
    }

    if (error) {
        return (
            <Paper elevation={2} sx={{ p: 3 }}>
                <Alert
                    severity="error"
                    sx={{ mb: 2 }}
                    action={
                        (error.includes('Authentication failed') ||
                            error.includes('No session found') ||
                            error.includes('No access token')) ? (
                            <Button
                                color="inherit"
                                size="small"
                                startIcon={<Login />}
                                onClick={handleLoginRedirect}
                            >
                                Login
                            </Button>
                        ) : null
                    }
                >
                    <Typography variant="body1" gutterBottom>
                        Error loading employees: {error}
                    </Typography>
                    {(error.includes('Authentication failed') ||
                        error.includes('No session found') ||
                        error.includes('No access token')) && (
                            <Typography variant="body2">
                                Please login to access employee data.
                            </Typography>
                        )}
                </Alert>
            </Paper>
        );
    }

    return (
        <Container maxWidth>
            {/* Header */}
            <Box mb={3} display="flex" justifyContent="space-between" alignItems="flex-start">
                <Box>  
                    <Typography variant="h4" className='page-heading'>
                        <Box className="decorator" /> Role Management 
                        <Chip
                            label={`${Object.values(roleStates).filter(isAdmin => isAdmin).length} Admins out of ${employees.length} employees`}
                            color="primary"
                            variant="filled"
                            sx={{ fontWeight: 'bold' }}
                        />
                    </Typography>
                    <Typography variant="h6" color="text.secondary" sx={{ paddingLeft: '16px', paddingTop: '6px' }}>
                    Manage employee roles and permissions across the system
                    </Typography>
                </Box>

                <Box display="flex" gap={2}>
                    <Button
                        variant="contained"
                        startIcon={syncing ? <CircularProgress size={16} /> : <Sync />}
                        onClick={handleSyncEmployees}
                        disabled={syncing || loading}
                        color="primary"
                        size="small"
                    >
                        {syncing ? 'Syncing...' : 'Sync from Timesheet'}
                    </Button>
                    <Button
                        variant="outlined"
                        startIcon={<Refresh />}
                        onClick={handleRefresh}
                        disabled={loading}
                        size="small"
                    >
                        Refresh
                    </Button>

                    <Box>
                        <TextField
                            fullWidth
                            placeholder="Search by employee code or name..."
                            value={searchQuery}
                            onChange={handleSearchChange}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <Search />
                                    </InputAdornment>
                                ),
                            }}
                            size="small"
                        />
                    </Box>
                </Box>
            </Box>

            {/* Mock Data Warning */}
            {usingMockData && (
                <Alert severity="warning" sx={{ mb: 2 }}>
                    <Typography variant="body2">
                        <strong>Demo Mode:</strong> Using mock employee data. This could be due to:
                        <br />• Missing NEXT_PUBLIC_ALL_EMPLOYEES configuration
                        <br />• Authentication issues with the employee API
                        <br />• Network connectivity problems
                    </Typography>
                </Alert>
            )}

            {/* Sync Message */}
            {syncMessage && (
                <Alert
                    severity={syncMessage.includes('failed') ? 'error' : 'success'}
                    sx={{ mb: 2 }}
                >
                    <Typography variant="body2">
                        {syncMessage}
                    </Typography>
                </Alert>
            )}

            {/* Search and Stats */}
            {/* <Grid container spacing={2} alignItems="center" mb={3}>
                <Grid item xs={12} md={6}>
                    <TextField
                        fullWidth
                        placeholder="Search by employee code or name..."
                        value={searchQuery}
                        onChange={handleSearchChange}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Search />
                                </InputAdornment>
                            ),
                        }}
                        size="small"
                    />
                </Grid>
                <Grid item xs={12} md={6}>
                    <Box display="flex" justifyContent="flex-end" alignItems="center" gap={2}>
                        <Typography variant="body2" color="text.secondary">
                            Showing {filteredEmployees.length} of {employees.length} employees
                        </Typography>
                        <Chip
                            label={`${Object.values(roleStates).filter(isAdmin => isAdmin).length} Admins`}
                            color="primary"
                            variant="filled"
                            sx={{ fontWeight: 'bold' }}
                        />
                    </Box>
                </Grid>
            </Grid> */}

            {/* Table */}
            <Box className="simple-table-card">
                <TableContainer sx={{ maxHeight: 600 }}>
                    <Table stickyHeader>
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{
                                    backgroundColor: 'primary.main',
                                    color: 'white',
                                    fontWeight: 'bold',
                                    position: 'sticky',
                                    top: 0,
                                    zIndex: 1,
                                    minWidth: 80
                                }}>
                                    Sr. No.
                                </TableCell>
                                <TableCell sx={{
                                    backgroundColor: 'primary.main',
                                    color: 'white',
                                    fontWeight: 'bold',
                                    position: 'sticky',
                                    top: 0,
                                    zIndex: 1,
                                    minWidth: 120
                                }}>
                                    Employee Code
                                </TableCell>
                                <TableCell sx={{
                                    backgroundColor: 'primary.main',
                                    color: 'white',
                                    fontWeight: 'bold',
                                    position: 'sticky',
                                    top: 0,
                                    zIndex: 1,
                                    minWidth: 200
                                }}>
                                    Employee Name
                                </TableCell>
                                <TableCell sx={{
                                    backgroundColor: 'primary.main',
                                    color: 'white',
                                    fontWeight: 'bold',
                                    position: 'sticky',
                                    top: 0,
                                    zIndex: 1,
                                    minWidth: 150
                                }}>
                                    Role
                                </TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {paginatedEmployees.map((employee, index) => {
                                const globalIndex = startIndex + index + 1;
                                const isAdmin = roleStates[employee.emp_code] || false;

                                return (
                                    <TableRow
                                        key={employee.id}
                                        hover
                                        sx={{
                                            backgroundColor: isAdmin ? 'rgba(25, 118, 210, 0.04)' : 'inherit',
                                            '&:hover': {
                                                backgroundColor: isAdmin ? 'rgba(25, 118, 210, 0.08)' : 'rgba(0, 0, 0, 0.04)'
                                            }
                                        }}
                                    >
                                        <TableCell>
                                            <Typography variant="body2" fontWeight="medium">
                                                {globalIndex}
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2" fontWeight="medium" color="primary">
                                                {employee.emp_code}
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Box display="flex" alignItems="center" gap={1}>
                                                <Typography variant="body2">
                                                    {employee.display_name || 'Unknown'}
                                                </Typography>
                                                {(roleStates[employee.emp_code] || false) && (
                                                    <Chip
                                                        label="ADMIN"
                                                        size="small"
                                                        color="primary"
                                                        variant="filled"
                                                        sx={{
                                                            fontSize: '0.7rem',
                                                            height: '20px',
                                                            fontWeight: 'bold'
                                                        }}
                                                    />
                                                )}
                                            </Box>
                                        </TableCell>
                                        <TableCell>
                                            <Box display="flex" alignItems="center" gap={1}>
                                                <Typography variant="body2" color="text.secondary">
                                                    User
                                                </Typography>
                                                <FormControlLabel
                                                    control={
                                                        <Switch
                                                            checked={roleStates[employee.emp_code] || false}
                                                            onChange={() => handleRoleToggle(
                                                                employee.emp_code,
                                                                employee.display_name,
                                                                roleStates[employee.emp_code] || false
                                                            )}
                                                            disabled={roleUpdates[employee.emp_code] === 'updating'}
                                                            color="primary"
                                                        />
                                                    }
                                                />
                                                <Typography variant="body2" color="primary" fontWeight="medium">
                                                    Admin
                                                </Typography>
                                                {roleUpdates[employee.emp_code] === 'updating' && (
                                                    <CircularProgress size={16} />
                                                )}
                                                {roleUpdates[employee.emp_code] === 'success' && (
                                                    <Chip label="Updated" color="success" size="small" />
                                                )}
                                                {roleUpdates[employee.emp_code] === 'error' && (
                                                    <Chip label="Error" color="error" size="small" />
                                                )}
                                            </Box>
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
                {/* Pagination */}
                {totalPages > 1 && (
                    <Box display="flex" justifyContent="center" mt={3}>
                        <Pagination
                            count={totalPages}
                            page={currentPage}
                            onChange={handlePageChange}
                            color="primary"
                            showFirstButton
                            showLastButton
                        />
                    </Box>
                )}
            </Box>


            {/* Empty State */}
            {filteredEmployees.length === 0 && (
                <Box textAlign="center" py={4}>
                    <Typography variant="h6" color="text.secondary">
                        No employees found
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        {searchQuery ? 'Try adjusting your search criteria' : 'No employees available'}
                    </Typography>
                </Box>
            )}
        </Container>
    );
};

export default UsersTable;
