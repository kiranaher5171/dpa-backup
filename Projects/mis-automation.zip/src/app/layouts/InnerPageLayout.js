import React from 'react';
import LinearScrollProgress from './Basic-Layout-Components/LinearScrollProgress';
import BackToTop from './Basic-Layout-Components/BackToTop';
import InnerHeader from './Basic-Layout-Components/InnerHeader';
import Footer from '../../_landingPageComponents/Footer';

const InnerPageLayout = ({ children }) => {

    return (
        <>
            <InnerHeader />
            <LinearScrollProgress />
            <main className="relative">{children}</main>
            <BackToTop />
            <Footer />
        </>
    );
};

export default InnerPageLayout;
