import React from 'react';
import LinearScrollProgress from './Basic-Layout-Components/LinearScrollProgress';
import Header from './Basic-Layout-Components/Header';
import BackToTop from './Basic-Layout-Components/BackToTop';

const BasicLayout = ({ children }) => {

    return (
        <>
            <Header />
            <LinearScrollProgress />
            <main className="relative" style={{  minHeight: '100vh' }}>{children}</main>
            <BackToTop />
        </>
    );
};

export default BasicLayout;
