"use client";
import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Link from 'next/link';
import "./header.css";
import { useMediaQuery } from '@mui/material';
import WLOGO from "../../../../public/logos/dpa-white.svg"
import BLOGO from "../../../../public/logos/dpa-black.svg"
import SMBLOGO from "../../../../public/logos/sm-dpa-black.svg"
import SMWLOGO from "../../../../public/logos/sm-dpa-white.svg"
import NewLogo from "../../../../public/logos/new-logo-sm.png"
import Image from 'next/image';
import { Stack, Avatar, Menu, MenuItem, Typography, Divider, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Chip } from '@mui/material';
import { useRouter, usePathname } from 'next/navigation';
import { useEmployeeStore } from '@/store/employeeStore';
import { useRoleAccess } from '@/hooks/useRoleAccess';
import { FaRegUser } from "react-icons/fa6";
import { LuIdCard } from "react-icons/lu";
import { MdOutlineEmail } from "react-icons/md";
import { LuLogOut } from "react-icons/lu";

export default function Header() {
    const router = useRouter();
    const pathname = usePathname();
    const isSmallScreen = useMediaQuery('(max-width:600px)');
    const [scrollClass, setScrollClass] = React.useState('scrolled');
    const [anchorEl, setAnchorEl] = React.useState(null);

    // Zustand stores
    const { employeeDetails, userRole, clearEmployeeDetails } = useEmployeeStore();
    const { isAdmin } = useRoleAccess();

    React.useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 0) {
                setScrollClass('scrolled');
            } else {
                setScrollClass('scrolled'); //adding here cause i want default scrolled class
            }
        };
        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const handleProfileMenuOpen = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleProfileMenuClose = () => {
        setAnchorEl(null);
    };

    const handleLogout = async () => {
        try {
            console.log('🔄 Starting logout process...');

            // Clear employee details and session
            clearEmployeeDetails();
            localStorage.clear();
            setAnchorEl(null);

            // Call server-side logout cleanup API
            try {
                await fetch('/api/auth/logout', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                console.log('✅ Server-side logout cleanup completed');
            } catch (cleanupError) {
                console.warn('⚠️ Database cleanup failed:', cleanupError);
            }

            // Navigate to login page
            router.push('/auth/sso-login');

            console.log('✅ Logout process completed');
        } catch (error) {
            console.error('❌ Logout error:', error);
            // Still navigate to login even if there's an error
            router.push('/auth/sso-login');
        }
    };

    const LoginRoute = () => {
        router.push('/auth/sso-login');
    };

    // Helper function to determine the logo based on screen size and scroll state
    const getLogo = () => {
        if (isSmallScreen) {
            return scrollClass === 'scrolled' ? NewLogo : NewLogo;
        } else {
            return scrollClass === 'scrolled' ? NewLogo : NewLogo;
        }
    };

    // Get user initials for avatar
    const getUserInitials = (fullName) => {
        if (!fullName) return 'U';
        const names = fullName.split(' ');
        // Get first and last name initials
        const firstInitial = names[0]?.charAt(0) || '';
        const lastInitial = names[names.length - 1]?.charAt(0) || '';
        return (firstInitial + lastInitial).toUpperCase();
    };

    // Get display name from employee details
    const getDisplayName = () => {
        if (employeeDetails?.full_name) {
            return employeeDetails.full_name;
        }
        if (employeeDetails?.name) {
            return employeeDetails.name;
        }
        if (employeeDetails?.first_name && employeeDetails?.last_name) {
            return `${employeeDetails.first_name} ${employeeDetails.last_name}`;
        }
        return 'User';
    };

    // Get employee code from employee details
    const getEmployeeCode = () => {
        return employeeDetails?.employee_code || 'N/A';
    };

    // Get email from employee details
    const getEmail = () => {
        return employeeDetails?.email || 'N/A';
    };

    // Helper function to check if menu is active
    const isMenuActive = (path) => {
        return pathname.startsWith(path);
    };

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar id="basic-appbar" position="fixed" className={scrollClass}>
                <Toolbar>
                    <Box className="w100">
                        <Box className="fx_sb">
                            <Link href="/">
                                <Box className="gap1" sx={{ display: 'flex', alignItems: 'baseline', cursor: 'pointer' }}>
                                    <Image
                                        src={getLogo()}
                                        alt="logo"
                                        height={isSmallScreen ? 40 : undefined}
                                        width={isSmallScreen ? 'auto' : undefined}
                                        className={isSmallScreen ? 'smlogo' : 'lglogo'}
                                        priority
                                    />
                                </Box>
                            </Link>

                            <Stack direction={"row"} justifyContent={"flex-end"} alignContent={"center"} spacing={2}>
                                {employeeDetails ? (
                                    // Logged in state
                                    <>
                                        <Link href="/main-dashboard" style={{ display: 'flex', alignItems: 'center' }}>
                                            <Button variant='text' disableRipple className={`main-menu ${isMenuActive('/main-dashboard') ? 'active-menu' : ''}`}>Main Dashboard</Button>
                                        </Link>

                                        {!isAdmin() && (
                                            <Link href="/create-mis" style={{ display: 'flex', alignItems: 'center' }}>
                                                <Button variant='text' disableRipple className={`main-menu ${isMenuActive('/create-mis') ? 'active-menu' : ''}`}>Create MIS</Button>
                                            </Link>
                                        )}

                                        {isAdmin() && (
                                            <>
                                                <Link href="/document-directory" style={{ display: 'flex', alignItems: 'center' }}>
                                                    <Button variant='text' disableRipple className={`main-menu ${isMenuActive('/document-directory') ? 'active-menu' : ''}`}>Document Directory</Button>
                                                </Link>
                                            </>
                                        )}

                                        {isAdmin() && (
                                            <>
                                                <Link href="/manage-role" style={{ display: 'flex', alignItems: 'center' }}>
                                                    <Button variant='text' disableRipple className={`main-menu ${isMenuActive('/manage-role') ? 'active-menu' : ''}`}>Role Management</Button>
                                                </Link>
                                            </>
                                        )}

                                        <List id="user-profile">
                                            <ListItem disablePadding disableGutters>
                                                <ListItemButton onClick={handleProfileMenuOpen} disableGutters>
                                                    <Avatar
                                                        sx={{
                                                            width: 30,
                                                            height: 30,
                                                            bgcolor: isAdmin() ? 'warning.main' : 'primary.main'
                                                        }}
                                                    >
                                                        {getUserInitials(getDisplayName())}
                                                    </Avatar>
                                                    <ListItemText
                                                        primary={<><span className="welcome">Welcome</span> {getDisplayName().split(' ')[0]}</>}
                                                        secondary={userRole ? userRole.toUpperCase() : 'User'}
                                                    />
                                                </ListItemButton>
                                            </ListItem>
                                        </List>

                                        <Menu
                                            anchorEl={anchorEl}
                                            open={Boolean(anchorEl)}
                                            onClose={handleProfileMenuClose}
                                            anchorOrigin={{
                                                vertical: 'bottom',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                        >
                                            <List id="profile-menus">
                                                <ListItem>
                                                    <ListItemIcon>
                                                        <FaRegUser />
                                                    </ListItemIcon>
                                                    <ListItemText
                                                        primary={getDisplayName()}
                                                    />
                                                </ListItem>

                                                <ListItem>
                                                    <ListItemIcon>
                                                        <LuIdCard />
                                                    </ListItemIcon>
                                                    <ListItemText
                                                        primary={getEmployeeCode()}
                                                    />
                                                </ListItem>

                                                <ListItem>
                                                    <ListItemIcon>
                                                        <MdOutlineEmail />
                                                    </ListItemIcon>
                                                    <ListItemText
                                                        primary={getEmail()}
                                                    />
                                                </ListItem>

                                                {employeeDetails && (
                                                    <>
                                                        {employeeDetails.department && (
                                                            <ListItem>
                                                                <ListItemIcon>
                                                                    <LuIdCard />
                                                                </ListItemIcon>
                                                                <ListItemText
                                                                    primary={`Department: ${employeeDetails.department}`}
                                                                />
                                                            </ListItem>
                                                        )}
                                                        {employeeDetails.designation && (
                                                            <ListItem>
                                                                <ListItemIcon>
                                                                    <LuIdCard />
                                                                </ListItemIcon>
                                                                <ListItemText
                                                                    primary={`Designation: ${employeeDetails.designation}`}
                                                                />
                                                            </ListItem>
                                                        )}
                                                        {employeeDetails.location && (
                                                            <ListItem>
                                                                <ListItemIcon>
                                                                    <LuIdCard />
                                                                </ListItemIcon>
                                                                <ListItemText
                                                                    primary={`${employeeDetails.location}`}
                                                                />
                                                            </ListItem>
                                                        )}
                                                    </>
                                                )}

                                                <Box py={1}>
                                                    <Divider />
                                                </Box>
                                            </List>

                                            <MenuItem onClick={handleLogout} sx={{ marginTop: '0px' }}>
                                                <Typography variant="body2" color="error" sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                                    <LuLogOut /> Sign Out
                                                </Typography>
                                            </MenuItem>
                                        </Menu>
                                    </>
                                ) : (
                                    // Logged out state
                                    <>
                                        <Button variant='contained' className='sq-btn'>Contact Sales</Button>
                                        <Button variant='contained' className='sq-btn' onClick={LoginRoute}>Sign In</Button>
                                    </>
                                )}
                            </Stack>
                        </Box>
                    </Box>
                </Toolbar>
            </AppBar>
        </Box>
    );
}
