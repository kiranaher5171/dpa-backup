"use client";
import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Link from 'next/link';
import "./header.css";
import { useMediaQuery } from '@mui/material';
import WLOGO from "../../../../public/logos/hw-logo.png"
import BLOGO from "../../../../public/logos/hb-logo.png"
import SMBLOGO from "../../../../public/logos/smb-logo.png"
import SMWLOGO from "../../../../public/logos/smw-logo.png"
import Image from 'next/image';
import { Container, Stack } from '@mui/material';
import { useRouter } from 'next/navigation';
import { MdLogout } from "react-icons/md";

export default function InnerHeader() {
    const router = useRouter();
    const isSmallScreen = useMediaQuery('(max-width:600px)');
    const [scrollClass, setScrollClass] = React.useState('scrolled');

    React.useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 0) {
                setScrollClass('scrolled');
            } else {
                setScrollClass('scrolled');
            }
        };
        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);


    const LogOutRoute = () => {
        router.push('/');
    };

    // Helper function to determine the logo based on screen size and scroll state
    const getLogo = () => {
        if (isSmallScreen) {
            return scrollClass === 'scrolled' ? SMBLOGO : SMWLOGO;
        } else {
            return scrollClass === 'scrolled' ? BLOGO : WLOGO;
        }
    };

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar id="basic-appbar" position="fixed" className={scrollClass}>
                <Toolbar>
                    <Container maxWidth>
                        <Box className="fx_sb">
                            <Link href="/">
                                <Box className="left">
                                    <Image
                                        src={getLogo()}
                                        alt="logo"
                                        height={isSmallScreen ? 40 : undefined}
                                        width={isSmallScreen ? 'auto' : undefined}
                                        className={isSmallScreen ? 'smlogo' : 'lglogo'}
                                        loading="lazy"
                                    />
                                </Box>
                            </Link>

                            <Stack direction={"row"} justifyContent={"flex-end"} alignContent={"center"} spacing={1}>
                                <Button variant='contained' className='sq-btn'>Contact Sales</Button>
                                <Button variant='contained' className='sq-btn' endIcon={<MdLogout />} onClick={LogOutRoute}>Log Out</Button>
                            </Stack>
                        </Box>
                    </Container>
                </Toolbar>
            </AppBar>
        </Box>
    );
}
