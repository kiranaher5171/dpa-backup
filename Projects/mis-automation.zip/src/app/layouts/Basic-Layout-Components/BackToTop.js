"use client";
import IconButton from '@mui/material/IconButton';
import React, { useState, useEffect } from 'react';
import { styled } from '@mui/material/styles';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import Box from '@mui/material/Box';

// Prevent isScrollButtonVisible from being passed to the DOM
const ButtonContainer = styled(Box, {
  shouldForwardProp: (prop) => prop !== 'isScrollButtonVisible',
})(({ theme, isScrollButtonVisible }) => ({
  position: 'fixed',
  bottom: 25,
  right: 25,
  alignItems: 'center',
  height: 50,
  width: 50,
  justifyContent: 'center',
  zIndex: 1000,
  cursor: 'pointer',
  animation: 'fadeIn 0.3s',
  opacity: isScrollButtonVisible ? 1 : 0.5,
  display: isScrollButtonVisible ? 'flex' : 'none',
  borderRadius: '50%',
  backgroundColor: '#e9eaf8',
  '&:hover': {
    opacity: 1,
  },
}));

const CircularProgressBar = styled('svg')({
  width: 50,
  height: 50,
  position: 'absolute',
  transform: 'rotate(-90deg)', // Rotate to start at 0 degrees
});

const Circle = styled('circle')(({ scrollPercentage }) => ({
  fill: 'none',
  stroke: '#f0c24c',
  strokeWidth: 5,
  strokeDasharray: 360, // Circumference of the circle
  strokeDashoffset: 360 - (285 * scrollPercentage) / 100,
  transition: 'stroke-dashoffset 1s',
}));

export default function BackToTop() {
  const [scroll, setScroll] = useState(0);
  const [showButton, setShowButton] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);

  useEffect(() => {
    const checkScrollHeight = () => {
      const currentPosition = window.scrollY;
      if (!showButton && currentPosition > 0) {
        setShowButton(true);
      } else if (showButton && currentPosition <= 0) {
        setShowButton(false);
      }
      setScrollPosition(currentPosition);
    };

    window.addEventListener('scroll', checkScrollHeight);
    return () => {
      window.removeEventListener('scroll', checkScrollHeight);
    };
  }, [showButton]);

  useEffect(() => {
    const progressBarHandler = () => {
      const totalScroll = document.documentElement.scrollTop;
      const windowHeight =
        document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scroll = totalScroll / windowHeight;
      setScroll(scroll);
    };

    window.addEventListener('scroll', progressBarHandler);

    return () => window.removeEventListener('scroll', progressBarHandler);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <ButtonContainer isScrollButtonVisible={showButton} onClick={scrollToTop}>
        <IconButton style={{ backgroundColor: '#8f63EE', padding: '8px' }} size='large'>
          <KeyboardArrowUpIcon fontSize='medium' className='white' />
        </IconButton>
      </ButtonContainer>
    </>
  );
}
