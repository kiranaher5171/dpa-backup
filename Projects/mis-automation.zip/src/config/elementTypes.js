// Element Types Configuration for MIS Editor
// This file defines all available element types with their HTML templates and properties

import { markdownToHtml } from '../utils/markdownToHtml.js';

export const elementTypes = {
  // Major Elements
  'main-heading': {
    name: 'Main Heading',
    category: 'headings',
    icon: 'Title',
    description: 'Large prominent heading with background color',
    htmlTemplate: (element) => `
    <tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>
<tr><td style="height:25px; font-size: 1px; background-color:transparent;">&nbsp;</td></tr>

<tr>
  <td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td style="background-color: ${element.primaryColor || '#1976d2'}; color: #ffffff; padding: 15px; text-align: ${element.textAlign || 'center'}; font-size: 20px; font-weight: bold; line-height: 28px;">
          ${markdownToHtml(element.value || 'Main Heading')}
        </td>
      </tr>
    </table>
  </td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'text', label: 'Heading Text', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 16, max: 48, default: 24 },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right'], default: 'center' },
      primaryColor: { type: 'color', label: 'Background Color', default: '#1930ab' }
    },
    parseRules: {
      selectors: ['background-color', 'color: #ffffff'],
      extractText: true,
      extractStyles: ['font-size', 'text-align', 'background-color']
    }
  },

  'section-heading': {
    name: 'Section Heading',
    category: 'headings',
    icon: 'SubdirectoryArrowRight',
    description: 'Section heading with colored border',
    htmlTemplate: (element) => `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
		<td height="50" align="center" valign="middle" style="background-color: #ffffff;color: ${element.primaryColor || '#1976d2'};font-size: 20px;font-weight: bold;line-height: 30px;border-left: 4px solid ${element.primaryColor || '#1976d2'};text-align: left;padding-left: 10px;">
		${markdownToHtml(element.value || 'Section Heading')}
		</td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'text', label: 'Heading Text', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 14, max: 32, default: 20 },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right'], default: 'left' },
      primaryColor: { type: 'color', label: 'Border Color', default: '#1930ab' }
    },
    parseRules: {
      selectors: ['border-left: 4px solid'],
      extractText: true,
      extractStyles: ['font-size', 'text-align', 'border-left']
    }
  },

  'sub-heading': {
    name: 'Sub Heading',
    category: 'headings',
    icon: 'TextFields',
    description: 'Medium-sized sub heading',
    htmlTemplate: (element) => `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td style="padding: 8px 15px; font-size: ${element.fontSize || 18}px; font-weight: 600; line-height: ${Math.round((element.fontSize || 18) * 1.4)}px; color: ${element.textColor || '#333333'}; text-align: ${element.textAlign || 'left'};">
          ${markdownToHtml(element.value || 'Sub Heading')}
        </td>
      </tr>
    </table>
  </td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'text', label: 'Heading Text', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 12, max: 24, default: 18 },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right'], default: 'left' },
      textColor: { type: 'color', label: 'Text Color', default: '#000000' }
    },
    parseRules: {
      selectors: ['font-weight: 600', 'font-size'],
      extractText: true,
      extractStyles: ['font-size', 'text-align', 'color']
    }
  },

  'highlighted-heading': {
    name: 'Highlighted Heading',
    category: 'headings',
    icon: 'Highlight',
    description: 'Heading with gray background highlight',
    htmlTemplate: (element) => `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tbody><tr>
        <td style="background-color: ${element.backgroundColor || '#d2d2d2'}; color: ${element.textColor || '#333333'}; padding: ${element.padding || '4px'}; text-align: ${element.textAlign || 'left'}; font-size: ${element.fontSize || '20px'}; font-weight: bold; padding-left: ${element.paddingLeft || '12px'};">
          ${markdownToHtml(element.value || 'Highlighted Heading', false)}
        </td>
      </tr>
    </tbody></table>
  </td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'text', label: 'Heading Text', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 14, max: 32, default: 20 },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right'], default: 'left' },
      textColor: { type: 'color', label: 'Text Color', default: '#000000' },
      backgroundColor: { type: 'color', label: 'Background Color', default: '#d2d2d2' },
      padding: { type: 'text', label: 'Padding', default: '4px' },
      paddingLeft: { type: 'text', label: 'Left Padding', default: '12px' }
    },
    parseRules: {
      selectors: ['background-color:', 'font-weight: bold'],
      extractText: true,
      extractStyles: ['font-size', 'text-align', 'color', 'background-color', 'padding']
    }
  },

  // Content Elements
  'description': {
    name: 'Description Text',
    category: 'content',
    icon: 'TextFields',
    description: 'Regular paragraph text',
    htmlTemplate: (element) => `
    <tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td style="padding: 10px 15px; font-size: ${element.fontSize || 16}px; line-height: ${Math.round((element.fontSize || 16) * (element.lineHeight || 1.6))}px; text-align: ${element.textAlign || 'justify'}; color: ${element.textColor || '#333333'};">
          ${markdownToHtml(element.value || 'Description text goes here...')}
        </td>
      </tr>
    </table>
  </td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'textarea', label: 'Text Content', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 12, max: 20, default: 16 },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right', 'justify'], default: 'justify' },
      textColor: { type: 'color', label: 'Text Color', default: '#000000' },
      lineHeight: { type: 'range', label: 'Line Height', min: 1.2, max: 2.0, step: 0.1, default: 1.6 }
    },
    parseRules: {
      selectors: ['line-height', 'text-align'],
      extractText: true,
      extractStyles: ['font-size', 'text-align', 'color', 'line-height']
    }
  },

  'bullet-points': {
    name: 'Bullet Points',
    category: 'content',
    icon: 'FormatListBulleted',
    description: 'Bulleted list with custom styling',
    htmlTemplate: (element) => {
      const points = element.value ? element.value.split('\n').filter(point => point.trim()) : ['Bullet point 1', 'Bullet point 2'];
      const bulletColor = element.bulletColor || '#1976d2';

      return `
      <tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td style="padding: 10px 15px;">
          ${points.map(point => `
            <table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td style="font-size: ${element.fontSize || 16}px; line-height: ${Math.round((element.fontSize || 16) * 1.5)}px; color: ${element.textColor || '#333333'}; padding-bottom: 8px;">
                  <span style="color: ${bulletColor}; margin-right: 8px;">•</span>
                  ${markdownToHtml(point.trim(), false)}
                </td>
              </tr>
            </table>
          `).join('')}
        </td>
      </tr>
    </table>
  </td>
</tr>


</tbody>
</table>
</td>
</tr>`;
    },
    properties: {
      value: { type: 'textarea', label: 'Bullet Points (one per line)', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 12, max: 20, default: 16 },
      textColor: { type: 'color', label: 'Text Color', default: '#000000' },
      bulletColor: { type: 'color', label: 'Bullet Color', default: '#1930ab' }
    },
    parseRules: {
      selectors: ['•', 'margin-bottom: 8px'],
      extractText: true,
      extractStyles: ['font-size', 'color']
    }
  },

  'simple-text': {
    name: 'Simple Text',
    category: 'content',
    icon: 'TextFields',
    description: 'Basic text content',
    htmlTemplate: (element) => `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td style="padding: 10px 15px; font-size: ${element.fontSize || 16}px; line-height: ${Math.round((element.fontSize || 16) * 1.6)}px; text-align: ${element.textAlign || 'justify'}; color: ${element.textColor || '#333333'};">
          ${markdownToHtml(element.value || 'Description text goes here...')}
        </td>
      </tr>
    </table>
  </td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'textarea', label: 'Text Content', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 12, max: 20, default: 16 },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right', 'justify'], default: 'justify' },
      textColor: { type: 'color', label: 'Text Color', default: '#000000' }
    },
    parseRules: {
      selectors: ['text-align', 'font-size'],
      extractText: true,
      extractStyles: ['font-size', 'text-align', 'color']
    }
  },

  // Spacing Elements
  'spacing': {
    name: 'Spacing',
    category: 'layout',
    icon: 'Height',
    description: 'Vertical spacing element',
    htmlTemplate: (element) => `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td style="height: ${element.value || 20}px; font-size: 1px; background-color: transparent;">&nbsp;</td>
</tr>


</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'number', label: 'Height (px)', min: 10, max: 100, default: 20, step: 1 }
    },
    parseRules: {
      selectors: ['height:', 'font-size: 1px'],
      extractValue: 'height'
    }
  },

  'divider': {
    name: 'Divider Line',
    category: 'layout',
    icon: 'Remove',
    description: 'Horizontal divider line',
    htmlTemplate: (element) => `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>


<tr>
  <td style="padding: ${element.margin || 10}px 0;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td style="height: ${element.thickness || 1}px; font-size: 1px; background-color: ${element.color || '#e0e0e0'};"></td>
      </tr>
    </table>
  </td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      thickness: { type: 'number', label: 'Thickness (px)', min: 1, max: 10, default: 1, step: 1 },
      color: { type: 'color', label: 'Line Color', default: '#000000' },
      margin: { type: 'number', label: 'Margin (px)', min: 0, max: 30, default: 10, step: 1 }
    },
    parseRules: {
      selectors: ['background-color:', 'height:'],
      extractStyles: ['height', 'background-color', 'margin']
    }
  },



  // Media Elements
  'image': {
    name: 'Image',
    category: 'media',
    icon: 'Image',
    description: 'Responsive image with optional link',
    htmlTemplate: (element) => {
      const imageTag = `<img src="${element.value || ''}" alt="${element.altText || 'Image'}" style="display:block !important; height: auto; float: none; width: 100%; max-width:100%;" width="100%">`;
      const imageWithLink = element.has_link && element.link
        ? `<a href="${element.link}" target="_blank" style="display:block;">${imageTag}</a>`
        : imageTag;

      return `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>
<tr>
<td style="padding: 0;">
${imageWithLink}
</td>
</tr>
</tbody>
</table>
</td>
</tr>`;
    },
    properties: {
      value: { type: 'text', label: 'Image URL', required: true },
      altText: { type: 'text', label: 'Alt Text', default: 'Image' },
      align: { type: 'select', label: 'Alignment', options: ['left', 'center', 'right'], default: 'center' },
      has_link: { type: 'boolean', label: 'Has Link', default: false },
      link: { type: 'text', label: 'Link URL', default: '', condition: { property: 'has_link', value: true } }
    },
    parseRules: {
      selectors: ['<img'],
      extractAttributes: ['src', 'alt'],
      extractStyles: ['text-align']
    }
  },

  // Special Elements
  'executive-summary': {
    name: 'Executive Summary',
    category: 'special',
    icon: 'Summarize',
    description: 'Executive summary with structured layout',
    htmlTemplate: (element) => {
      // Parse the structured content
      let content;

      // Debug logging
      console.log('Executive summary element:', element);
      console.log('Element value type:', typeof element.value);
      console.log('Element value:', element.value);

      try {
        if (element.value && typeof element.value === 'string') {
          // Check if it's already a valid JSON string
          if (element.value.trim().startsWith('{')) {
            content = JSON.parse(element.value);
          } else {
            // If it's not JSON, use default structure
            console.log('Element value is not JSON, using default structure');
            content = {
              "headings": {
                "operational-strengths": "OPERATIONAL STRENGTHS",
                "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
                "risk-mitigation": "RISK MITIGATION",
                "operational-highlights": "OPERATIONAL HIGHLIGHTS"
              },
              "operational-strengths": [
                {
                  "content": "**Sample Item**\n\nSample content with markdown support."
                }
              ],
              "strategic-achievements": [
                {
                  "content": "**Sample Item**\n\nSample content with markdown support."
                }
              ],
              "risk-mitigation": [
                {
                  "content": "**Sample Item**\n\nSample content with markdown support."
                }
              ],
              "operational-highlights": [
                {
                  "content": "**Sample Item**\n\nSample content with markdown support."
                }
              ]
            };
          }
        } else {
          // No value or not a string, use default structure
          content = {
            "headings": {
              "operational-strengths": "OPERATIONAL STRENGTHS",
              "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
              "risk-mitigation": "RISK MITIGATION",
              "operational-highlights": "OPERATIONAL HIGHLIGHTS"
            },
            "operational-strengths": [
              {
                "content": "**Sample Item**\n\nSample content with markdown support."
              }
            ],
            "strategic-achievements": [
              {
                "content": "**Sample Item**\n\nSample content with markdown support."
              }
            ],
            "risk-mitigation": [
              {
                "content": "**Sample Item**\n\nSample content with markdown support."
              }
            ],
            "operational-highlights": [
              {
                "content": "**Sample Item**\n\nSample content with markdown support."
              }
            ]
          };
        }
      } catch (e) {
        console.error('Error parsing executive summary JSON:', e);
        console.error('Failed value:', element.value);
        // If parsing fails, use default structure
        content = {
          "headings": {
            "operational-strengths": "OPERATIONAL STRENGTHS",
            "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
            "risk-mitigation": "RISK MITIGATION",
            "operational-highlights": "OPERATIONAL HIGHLIGHTS"
          },
          "operational-strengths": [
            {
              "content": "**Sample Item**\n\nSample content with markdown support."
            }
          ],
          "strategic-achievements": [
            {
              "content": "**Sample Item**\n\nSample content with markdown support."
            }
          ],
          "risk-mitigation": [
            {
              "content": "**Sample Item**\n\nSample content with markdown support."
            }
          ],
          "operational-highlights": [
            {
              "content": "**Sample Item**\n\nSample content with markdown support."
            }
          ]
        };
      }

      const colorMap = {
        "operational-strengths": "#1930ab",
        "strategic-achievements": "#1e693a",
        "risk-mitigation": "#8b0000",
        "operational-highlights": "#fa7604"
      };
      const bgMap = {
        "operational-strengths": "#e6f0fe",
        "strategic-achievements": "#e5fcec",
        "risk-mitigation": "#fde8e8",
        "operational-highlights": "#fef0de"
      };
      const borderMap = {
        "operational-strengths": "#83cbeb",
        "strategic-achievements": "#b4e5a2",
        "risk-mitigation": "#fca6a6",
        "operational-highlights": "#ffca89"
      };

      const renderBlock = (key) => {
        const section = content[key] || [];
        const heading = (content.headings?.[key] || key.replace(/-/g, " ")).toUpperCase();
        return ` 
          <td width="290" align="left" valign="top" style="background-color: ${bgMap[key]}; border: 1px solid ${borderMap[key]}; border-radius: 12px;">
            <table width="290" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
              <tbody>
                <tr>
                  <td style="font-size: 18px; font-weight: bold; line-height: 30px; text-align: center; color: ${colorMap[key]} !important; padding-top: 10px;">
                    ${heading}
                  </td>
                </tr>
                <tr><td style="height:5px; font-size: 1px; background-color:transparent;">&nbsp;</td></tr>
                ${section.map(item => {
          // Handle both old and new data structures for backward compatibility
          const content = item.content || item.heading || '';
          const hasContent = content && content.trim() !== '';

          // Debug logging
          console.log('Rendering item:', item);
          console.log('Has content:', hasContent);
          console.log('Content value:', content);

          return `
                   <tr>
                     <td style="padding: 0px;">
                       ${hasContent ? `
                       <ul style="margin: 0; padding: 0 0 0 20px; list-style-type: disc; font-size: 22px; line-height: 22px; color: ${colorMap[key]};">
                         <li style="color: #000000; font-size: 14px; line-height: 20px;"> 
                            ${markdownToHtml(content)} 
                         </li>
                       </ul>
                       ` : `
                       <table width="100%" cellpadding="0" cellspacing="0" border="0">
                         <tr>
                           <td style="height: 8px; font-size: 1px; background-color: transparent;">&nbsp;</td>
                         </tr>
                       </table>
                       `}
                     </td>
                   </tr>
                  <tr><td style="height:8px; font-size: 1px; background-color:transparent;">&nbsp;</td></tr>
                `}).join("")}
              </tbody>
            </table>
          </td>
          `;
      };

      return `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>


        <tr>
          <td height="50" align="center" valign="middle" style="background-color:  ${element.primaryColor || '#1976d2'}; color: #ffffff; font-size: 20px; font-weight: bold; line-height: 30px; border-left: 5px solid  ${element.primaryColor || '#1976d2'}; border-right: 5px solid  ${element.primaryColor || '#1976d2'};">
             Executive Summary
          </td>
        </tr>
        <tr><td style="height:20px; font-size: 1px; background-color:transparent;">&nbsp;</td></tr>
        
        <tr>
          <td>
            <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
              <tbody>
                <tr>
                  ${renderBlock("operational-strengths")}
                  <td width="20" align="center" valign="top" style="background-color: #f2f2f2;">&nbsp;</td>
                  ${renderBlock("strategic-achievements")}
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr><td style="height:20px; font-size: 1px; background-color:transparent;">&nbsp;</td></tr>
        <tr>
          <td>
            <table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
              <tbody>
                <tr>
                  ${renderBlock("risk-mitigation")}
                  <td width="20" align="center" valign="top" style="background-color: #f2f2f2;">&nbsp;</td>
                  ${renderBlock("operational-highlights")}
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr><td style="height:20px; font-size: 1px; background-color:transparent;">&nbsp;</td></tr>
</tbody>
</table>
</td>
</tr> 
      `;
    },
    properties: {
      value: {
        type: 'textarea',
        label: 'Executive Summary Data (JSON)',
        required: true,
        default: JSON.stringify({
          "operational-strengths": [
            {
              "content": "**Sample Heading 1**\n\nSample description with *italic text* and **bold formatting**"
            },
            {
              "content": "**Another Item**\n\nThis supports markdown formatting like **bold**, *italic*, and more."
            }
          ],
          "strategic-achievements": [
            {
              "content": "**Strategic Achievement 1**\n\nDescription with markdown support for formatting."
            },
            {
              "content": "**Strategic Achievement 2**\n\nAnother item with *emphasized* text."
            }
          ],
          "risk-mitigation": [
            {
              "content": "**Risk Mitigation Item 1**\n\nRisk description with **important** details."
            },
            {
              "content": "**Risk Mitigation Item 2**\n\nAdditional risk information."
            }
          ],
          "operational-highlights": [
            {
              "content": "**Operational Highlight 1**\n\nHighlight description with markdown formatting."
            },
            {
              "content": "**Operational Highlight 2**\n\nAnother highlight with *special* emphasis."
            }
          ]
        }, null, 2)
      },
      fontSize: { type: 'range', label: 'Content Font Size', min: 12, max: 20, default: 16 },
      titleSize: { type: 'range', label: 'Title Font Size', min: 16, max: 28, default: 20 },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right', 'justify'], default: 'justify' },
      textColor: { type: 'color', label: 'Text Color', default: '#000000' },
      titleColor: { type: 'color', label: 'Title Color', default: '#1930ab' }
    },
    parseRules: {
      selectors: ['Executive Summary', 'background-color'],
      extractText: true,
      extractStyles: ['font-size', 'text-align', 'color', 'background-color']
    }
  },

  'highlight-box': {
    name: 'Highlight Box',
    category: 'special',
    icon: 'Highlight',
    description: 'Highlighted content box',
    htmlTemplate: (element) => `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td style="padding: 15px; background-color: ${element.backgroundColor || '#fff3cd'}; border-left: 4px solid ${element.borderColor || '#ffc107'}; border-radius: 4px;">
          <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
              <td style="font-size: ${element.fontSize || 16}px; line-height: ${Math.round((element.fontSize || 16) * 1.6)}px; color: ${element.textColor || '#856404'};">
                ${markdownToHtml(element.value || 'Highlighted content goes here...')}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </td>
</tr>

</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'textarea', label: 'Content', required: true },
      fontSize: { type: 'range', label: 'Font Size', min: 12, max: 20, default: 16 },
      textColor: { type: 'color', label: 'Text Color', default: '#000000' },
      backgroundColor: { type: 'color', label: 'Background Color', default: '#fff3cd' },
      borderColor: { type: 'color', label: 'Border Color', default: '#ffc107' }
    },
    parseRules: {
      selectors: ['border-left: 4px solid', 'background-color'],
      extractText: true,
      extractStyles: ['font-size', 'color', 'background-color', 'border-left']
    }
  },

  // Template Structure Elements
  'date-header': {
    name: 'Date Header',
    category: 'template',
    icon: 'DateRange',
    description: 'Header section with date and logo',
    htmlTemplate: (element) => `
<!-- Header Section which contains the Date and Logo -->
<tr>
<td bgcolor="#ffffff">
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>
<tr>
<td width="600" height="70" align="left" valign="middle" style="color: #3A3A3A;font-weight: bold;text-transform: uppercase;letter-spacing: 4px;">${element.value || 'OCTOBER 2024'}</td>

<td width="80" height="70" align="right" valign="middle" style="padding: 0;">
<img src="https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/common-graphics%2Fnew-logo-sm.png"
alt="Logo"
width="80"
height="auto"
style="display:block; height: auto; width: 80px; max-width: 80px; border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic;">
</td>
</tr>
</tbody>
</table>
</td>
</tr>`,
    properties: {
      value: { type: 'text', label: 'Date Text', required: true, default: 'OCTOBER 2024' },
      logoUrl: { type: 'text', label: 'Logo URL', default: 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/creative_dpa/o/Media%2Fuploaded_imgs%2Fmonthly-mis%2Foct2024%2Fd-logo.png' }
    },
    parseRules: {
      selectors: ['Header Section which contains the Date and Logo'],
      extractText: true,
      extractAttributes: ['src']
    }
  },

  'banner-section': {
    name: 'Banner Section',
    category: 'template',
    icon: 'Image',
    description: 'Banner image section',
    htmlTemplate: (element) => `
<!-- Banner Here -->
<tr>
<td align="center" valign="middle" style="padding: 0;">
<img src="${element.value || 'https://template.canva.com/EAGFHwDBy9o/1/0/1600w-r04Wz2uiHxE.jpg'}" alt="Banner" style="display:block !important; height: auto; float: none; width: 100%; max-width:100%;" width="100%">
</td>
</tr>
<!-- Banner Here -->`,
    properties: {
      value: { type: 'text', label: 'Banner URL', required: true },
      bannerFilename: { type: 'text', label: 'Banner Filename', description: 'Just the filename (e.g., banner.jpg)' }
    },
    parseRules: {
      selectors: ['Banner Here'],
      extractAttributes: ['src']
    }
  },

  'whats-new-dpa': {
    name: 'What\'s New in DPA',
    category: 'template',
    icon: 'NewReleases',
    description: 'What\'s New in DPA section with image',
    htmlTemplate: (element) => {
      const imageTag = `<img src="${element.value || ''}"
			alt="${element.caption || 'What\'s New at DPA'}"
			style="display:block !important; height: auto; float: none; width: 100%; max-width:100%;"
			width="100%">`;
      const imageWithLink = element.has_link && element.link
        ? `<a href="${element.link}" target="_blank" style="display:block;">${imageTag}</a>`
        : imageTag;

      return `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
	<td height="50" align="center" valign="middle"
		style="background-color: #ffffff; color: ${element.titleColor || '#1976d2'}; font-size: 20px;font-weight: bold;line-height: 30px;border-left: 4px solid ${element.borderColor || '#333333'};text-align: left;padding-left: 10px;">
		Whats New at DPA!!!
	</td>
</tr>
<!--space-->
<tr>
	<td style="height:10px; font-size: 1px; background-color:transparent;">&nbsp;</td>
</tr><!--space-->

<tr>
	<td style="padding: 0;">
		${imageWithLink}
	</td>
</tr>

</tbody>
</table>
</td>
</tr>
`;
    },
    properties: {
      value: { type: 'text', label: 'Image URL', required: true },
      caption: { type: 'text', label: 'Caption' },
      textAlign: { type: 'select', label: 'Text Alignment', options: ['left', 'center', 'right'], default: 'center' },
      titleSize: { type: 'range', label: 'Title Font Size', min: 16, max: 28, default: 20 },
      titleColor: { type: 'color', label: 'Title Color', default: '#1930ab' },
      has_link: { type: 'boolean', label: 'Has Link', default: false },
      link: { type: 'text', label: 'Link URL', default: '', condition: { property: 'has_link', value: true } }
    },
    parseRules: {
      selectors: ['What\'s New in DPA'],
      extractAttributes: ['src'],
      extractStyles: ['text-align']
    }
  },

  'disclaimer': {
    name: 'Disclaimer',
    category: 'template',
    icon: 'Gavel',
    description: 'Disclaimer section at the bottom',
    htmlTemplate: (element) => `
<!-- Static Footer -->
<tr>
<td bgcolor="#ffffff">
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>
<!--space-->
<tr>
<td style="height:20px; font-size: 1px; background-color:transparent;">
&nbsp;
</td>
</tr><!--space-->

<tr>
<td>
<table width="160" border="0" align="left" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td>
<img src="${element.logoUrl || 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/common-graphics%2Fnew-logo.jpg'}"
alt="DPA Logo"
width="160"
height="auto"
style="display:block; height: auto; width: 160px; max-width: 160px; border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic;">
</td>
</tr>
</tbody>
</table>
</td>
</tr>

<!--space-->
<tr>
<td style="height:15px; font-size: 1px; background-color:transparent;">
&nbsp;</td>
</tr><!--space-->

<tr>
<td style="color: #333333;font-size: 16px;line-height: 20px;text-align: justify;">
<strong>Disclaimer</strong>
</td>
</tr>

<!--space-->
<tr>
<td style="height:10px; font-size: 1px; background-color:transparent;">
&nbsp;</td>
</tr><!--space-->

<tr>
<td style="color: #333333;font-size: 14px;line-height:18px;text-align: justify;">
${markdownToHtml(element.value || 'Decimal Point Analytics Pvt Ltd does not make any recommendation, solicitation, or offer for any securities and is not responsible for suitability of any securities for any purpose, investment or otherwise. It is the sole responsibility of the client, as a professional organization, to exercise professional due diligence in ensuring suitability of investment and ensuring that when the client publishes a part or full report under its own brand, the legal requirements for distribution of such material are complied with in all the jurisdiction in which it is published. Decimal Point Analytics Pvt. Ltd. shall not be responsible for any loss suffered by the user. The returns indicated, including future projections, in any investment report prepared by Decimal Point Analytics Pvt Ltd are not guaranteed in any manner and June not to be achieved.')}
</td>
</tr>

<!--space-->
<tr>
<td style="height:15px; font-size: 1px; background-color:transparent;">
&nbsp;</td>
</tr><!--space-->

<tr>
<td style="color: #333333;font-size: 16px;line-height: 20px;text-align: left;">
<a href="https://decimalpointanalytics.com/" style="color: #1930ab;font-size: 14px;text-decoration: none;letter-spacing: 1px;">www.decimalpointanalytics.com</a>
</td>
</tr>

<!--space-->
<tr>
<td style="height:15px; font-size: 1px; background-color:transparent;">
&nbsp;</td>
</tr><!--space-->

</tbody>
</table>
</td>
</tr>
<!-- Static Footer -->`,
    properties: {
      value: { type: 'textarea', label: 'Disclaimer Text', required: true, default: 'Decimal Point Analytics Pvt Ltd does not make any recommendation, solicitation, or offer for any securities and is not responsible for suitability of any securities for any purpose, investment or otherwise. It is the sole responsibility of the client, as a professional organization, to exercise professional due diligence in ensuring suitability of investment and ensuring that when the client publishes a part or full report under its own brand, the legal requirements for distribution of such material are complied with in all the jurisdiction in which it is published. Decimal Point Analytics Pvt. Ltd. shall not be responsible for any loss suffered by the user.' },
      logoUrl: { type: 'text', label: 'Logo URL', default: 'https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/common-graphics%2Fnew-logo.jpg' }
    },
    parseRules: {
      selectors: ['Static Footer', 'Disclaimer'],
      extractText: true,
      extractAttributes: ['src']
    }
  },

  'news-section': {
    name: 'News Section',
    category: 'content',
    icon: 'Newspaper',
    description: 'News section with multiple news items',
    htmlTemplate: (element) => {
      // Parse the news data
      let newsData;
      try {
        if (element.value && typeof element.value === 'string') {
          if (element.value.trim().startsWith('[')) {
            newsData = JSON.parse(element.value);
          } else {
            newsData = [];
          }
        } else {
          newsData = [];
        }
      } catch (e) {
        console.error('Error parsing news data:', e);
        newsData = [];
      }

      // If no news data, provide default structure
      if (!Array.isArray(newsData) || newsData.length === 0) {
        newsData = [
          {
            title: "News Title",
            date: "Jul-25",
            link: "https://example.com/news1",
            heading: "News Main Heading",
            description: "News Description"
          }
        ];
      }

      const renderNewsItem = (news, index, isLast) => `
        <!-- News ${index + 1} -->
        <tr>
          <td>
            <table width="650" border="0" align="center" cellpadding="0" cellspacing="0"
              style="margin: auto; background-color: #ffffff; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
              <tbody>
                <tr>
                  <td style="padding: 5px;">
                    <table width="640" border="0" align="center" cellpadding="0" cellspacing="0"
                      style="margin: auto; background-color: #ffffff; border-radius: 5px;">
                      <tbody>
                        <tr>
                          <td style="padding: 5px 10px;">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td width="400" align="left" valign="top">
                                    <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                      <tbody>
                                        <tr>
                                          <td
                                            style="font-size: 16px; font-weight: bold; line-height: 30px; text-align: left; color: ${element.primaryColor || '#225FA0'}B3 !important; padding-left: 2px; padding-top: 0px;">
                                            ${news.title || 'News Title'}
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>

                                  <td width="150" align="center" valign="top"
                                    style="border-left: 2px solid #d9d9d9;">
                                    <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                      <tbody>
                                        <tr>
                                          <td
                                            style="font-size: 16px; font-weight: bold; line-height: 30px; text-align: left; color: #000000 !important; padding-left: 10px;">
                                            Date: ${news.date || 'Jul-25'}
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>

                                  <td width="50" align="left" valign="top">
                                    <a href="${news.link || '#'}" target="_blank"
                                      style="color: #1930ab;font-size: 16px;text-decoration: none;letter-spacing: 5px;">
                                      <img
                                        src="https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/common-graphics%2Flink.png"
                                        alt="Link"
                                        width="30"
                                        height="30"
                                        style="display:block; height: 30px; width: 30px; max-width: 30px; border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic;">
                                    </a>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>

<tr>
<td style="height: 2px; font-size: 1px; background-color: ${element.primaryColor || '#d9d9d9'};"></td>
</tr>

<!--space-->
<tr>
<td style="height:10px; font-size: 1px; background-color:#ffffff;">
&nbsp;
</td>
</tr>
<!--space-->


                <tr>
                  <td style="padding: 0; background-color: #ffffff;">
                    <table width="630" border="0" align="center" cellpadding="0" cellspacing="0"
                      style="margin: auto; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                      <tbody>
                        <tr>
                          <td style="color: ${element.primaryColor || '#225FA0'};font-size: 16px;line-height: 20px; mso-line-height-rule: exactly; text-align: left; padding: 0 10px; margin: 0; background-color: #ffffff;">
                            <strong>${news.heading || 'News Main Heading'}</strong>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>

                <tr>
                  <td style="height: 10px; font-size: 1px; line-height: 10px; mso-line-height-rule: exactly; background-color: #ffffff; padding: 0; margin: 0;">&nbsp;</td>
                </tr>

                <tr>
                  <td style="padding: 0; background-color: #ffffff;">
                    <table width="630" border="0" align="center" cellpadding="0" cellspacing="0"
                      style="margin: auto; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                      <tbody>
                        <tr>
                          <td
                            style="color: #333333;font-size: 16px;line-height: 20px; mso-line-height-rule: exactly; text-align: justify; padding: 0 10px; margin: 0; background-color: #ffffff;">
                            ${news.description ? markdownToHtml(news.description, false) : 'Description of the news item goes here...'}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>

                <tr>
                  <td style="height: 15px; font-size: 1px; line-height: 15px; mso-line-height-rule: exactly; background-color: #ffffff; padding: 0; margin: 0;">&nbsp;</td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
 

        ${!isLast ? `
        <!-- Spacing between news items -->
        <tr>
          <td style="height: 10px; font-size: 1px; line-height: 10px; mso-line-height-rule: exactly; background-color: #f2f2f2; padding: 0; margin: 0;">&nbsp;</td>
        </tr>` : ''}
        <!-- News ${index + 1} -->`;

      return `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>

<tr>
  <td style="height:10px; font-size: 1px; background-color:transparent;">&nbsp;</td>
</tr>

<tr>
		<td height="50" align="center" valign="middle" style="background-color: #ffffff;color: ${element.primaryColor || '#1976d2'};font-size: 20px;font-weight: bold;line-height: 30px;border-left: 4px solid ${element.primaryColor || '#1976d2'};text-align: left;padding-left: 10px;">
		${element.sectionTitle || 'Sector Title'}
		</td>
</tr>

<tr>
  <td style="height:10px; font-size: 1px; background-color:transparent;">&nbsp;</td>
</tr>

${newsData.map((news, index) => renderNewsItem(news, index, index === newsData.length - 1)).join('')}

<tr>
  <td style="height:10px; font-size: 1px; background-color:transparent;">&nbsp;</td>
</tr>

</tbody>
</table>
</td>
</tr>`;
    },
    properties: {
      value: {
        type: 'textarea',
        label: 'News Data (JSON Array)',
        required: true,
        default: JSON.stringify([
          {
            "title": "News Title",
            "date": "Jul-25",
            "link": "https://example.com/news1",
            "heading": "News Main Heading",
            "description": "Report redesign To enhance the report's appeal and improve user experience, the client has suggested redesigning it in a new, more engaging format. The redesign process is currently underway, with the team actively working on creating updated design prototypes. Implementation of the new format will commence upon receiving the client's approval of the proposed designs, ensuring alignment with their expectations and requirements."
          }
        ], null, 2)
      },
      sectionTitle: { type: 'text', label: 'Section Title', default: 'Sector Title' }
    },
    parseRules: {
      selectors: ['Sector Title', 'News Title'],
      extractText: true,
      extractStyles: ['font-size', 'color', 'background-color']
    }
  },

  'list-items': {
    name: 'List Items',
    category: 'content',
    icon: 'FormatListBulleted',
    description: 'List items with headings and multiple content items',
    htmlTemplate: (element) => {
      // Parse the list items data
      let listData;
      try {
        if (element.value && typeof element.value === 'string') {
          if (element.value.trim().startsWith('[')) {
            listData = JSON.parse(element.value);
          } else {
            listData = [];
          }
        } else {
          listData = [];
        }
      } catch (e) {
        console.error('Error parsing list items data:', e);
        listData = [];
      }

      // If no list data, provide default structure
      if (!Array.isArray(listData) || listData.length === 0) {
        listData = [
          {
            hasHeading: false,
            heading: "",
            content: ["Content 1", "Content 2"]
          }
        ];
      }

      // Generate HTML for all list items
      let listItemsHTML = '';
      listData.forEach((item, index) => {
        listItemsHTML += `
        <!-- Listitem ${index + 1} -->
        <tr>
          <td style="height:10px; font-size: 1px; background-color:transparent;">&nbsp;</td>
        </tr>`;

        // Only add heading if hasHeading is true and heading exists
        if (item.hasHeading && item.heading) {
          listItemsHTML += `
        <tr>
          <td style="color: #333333;font-size: 16px;line-height: 20px;text-align: left;">
            <strong>${item.heading}</strong>:
          </td>
        </tr>
        <tr>
          <td style="height:5px; font-size: 1px; background-color:transparent;">&nbsp;</td>
        </tr>`;
        }

        // Add content items
        (item.content || []).forEach(content => {
          listItemsHTML += `
          <tr>
            <td style="color: #333333;font-size: 16px;line-height: 20px;text-align: left;">
              ${content}
            </td>
          </tr>
          <tr>
            <td style="height:5px; font-size: 1px; background-color:transparent;">&nbsp;</td>
          </tr>`;
        });

        listItemsHTML += `<!-- Listitem ${index + 1} -->`;
      });

      return `
<tr>
<td>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="margin: auto;">
<tbody>
${listItemsHTML}
</tbody>
</table>
</td>
</tr>`;
    },
    properties: {
      value: {
        type: 'textarea',
        label: 'List Items Data (JSON Array)',
        required: true,
        default: JSON.stringify([
          {
            "hasHeading": false,
            "heading": "",
            "content": ["Content 1", "Content 2"]
          },
          {
            "hasHeading": true,
            "heading": "ListItem Heading",
            "content": ["Content"]
          }
        ], null, 2)
      }
    },
    parseRules: {
      selectors: ['ListItem Heading'],
      extractText: true,
      extractStyles: ['font-size', 'color', 'text-align']
    }
  },


};

// Element categories for organization
export const elementCategories = {
  template: {
    name: 'Template Structure',
    icon: 'ViewModule',
    description: 'Template structure elements'
  },
  headings: {
    name: 'Headings',
    icon: 'Title',
    description: 'Various heading styles'
  },
  content: {
    name: 'Content',
    icon: 'TextFields',
    description: 'Text and content elements'
  },
  layout: {
    name: 'Layout',
    icon: 'ViewColumn',
    description: 'Spacing and layout elements'
  },
  media: {
    name: 'Media',
    icon: 'Image',
    description: 'Images and media elements'
  },
  special: {
    name: 'Special',
    icon: 'Star',
    description: 'Specialized content elements'
  }
};

// Helper function to get element by type
export const getElementType = (type) => {
  return elementTypes[type] || null;
};

// Helper function to get all elements in a category
export const getElementsByCategory = (category) => {
  return Object.entries(elementTypes)
    .filter(([_, element]) => element.category === category)
    .map(([type, element]) => ({ type, ...element }));
};

// Helper function to get all categories
export const getAllCategories = () => {
  return elementCategories;
};

// Helper function to validate and normalize an element
export const validateElement = (element) => {
  if (!element || typeof element !== 'object') {
    return { isValid: false, error: 'Element is not a valid object' };
  }

  if (!element.type || !elementTypes[element.type]) {
    return { isValid: false, error: `Invalid element type: ${element.type}` };
  }

  const elementConfig = elementTypes[element.type];
  const normalizedElement = { ...element };

  // Set default values for missing properties
  if (elementConfig.properties) {
    Object.entries(elementConfig.properties).forEach(([prop, config]) => {
      if (normalizedElement[prop] === undefined && config.default !== undefined) {
        normalizedElement[prop] = config.default;
      }
    });
  }

  // Ensure required properties exist
  const requiredProps = Object.entries(elementConfig.properties || {})
    .filter(([_, config]) => config.required)
    .map(([prop, _]) => prop);

  for (const prop of requiredProps) {
    if (normalizedElement[prop] === undefined || normalizedElement[prop] === '') {
      return { isValid: false, error: `Missing required property: ${prop}` };
    }
  }

  return { isValid: true, element: normalizedElement };
};

// Helper function to create a new element with proper defaults
export const createElement = (type, properties = {}) => {
  const elementConfig = elementTypes[type];
  if (!elementConfig) {
    throw new Error(`Unknown element type: ${type}`);
  }

  const elementId = `element-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  const newElement = {
    id: elementId,
    type,
    ...properties,
    timestamp: new Date().toISOString()
  };

  // Set default values
  if (elementConfig.properties) {
    Object.entries(elementConfig.properties).forEach(([prop, config]) => {
      if (newElement[prop] === undefined && config.default !== undefined) {
        newElement[prop] = config.default;
      }
    });
  }

  return newElement;
}; 