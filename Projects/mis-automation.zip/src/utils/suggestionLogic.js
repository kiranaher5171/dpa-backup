// Suggestion logic for the design canvas
// This file contains the logic to determine what suggestions to show based on element types

export const getSuggestionForElement = (elementType, previousElements = []) => {
  // Define suggestion rules based on element type and context
  const suggestionRules = {
    // Heading elements
    'main-heading': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the main heading for better visual separation'
    },
    'section-heading': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the section heading for better visual separation'
    },
    'sub-heading': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the sub heading for better visual separation'
    },
    'highlighted-heading': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the highlighted heading for better visual separation'
    },

    // Content elements
    'description': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 2,
      description: 'Add spacing after the description for better layout'
    },
    'simple-text': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 2,
      description: 'Add spacing after the text for better layout'
    },
    'bullet-points': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 2,
      description: 'Add spacing after the bullet points for better layout'
    },

    // Spacing elements - no suggestion needed to avoid double spacing
    'spacing': null,

    // Media elements
    'image': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the image for better layout'
    },
    'banner-section': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the banner section for better layout'
    },
    'whats-new-dpa': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the What\'s New section'
    },

    // Special elements
    'executive-summary': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the executive summary'
    },
    'news-section': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the news section'
    },
    'list-items': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the list items'
    },

    // Template elements
    'date-header': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing after the date header for better layout'
    },
    'disclaimer': {
      text: 'Add Spacing',
      type: 'spacing',
      priority: 1,
      description: 'Add spacing before the disclaimer'
    }
  };

  return suggestionRules[elementType] || null;
};

// Get the next logical suggestion based on the current element and previous elements
export const getNextSuggestion = (currentElement, allElements, currentIndex) => {
  if (!currentElement) return null;

  // Don't suggest anything after spacing elements to avoid double spacing
  if (currentElement.type === 'spacing') {
    return null;
  }

  // Get the basic suggestion for the current element type
  let suggestion = getSuggestionForElement(currentElement.type, allElements);

  // If no suggestion found, return null
  if (!suggestion) return null;

  // Check if the suggested element already exists after the current element
  const elementsAfter = allElements.slice(currentIndex + 1);
  const hasSuggestedElement = elementsAfter.some(el => el.type === suggestion.type);

  // If the suggested element already exists, try to find an alternative
  if (hasSuggestedElement) {
    // For headings, suggest spacing if not already present
    if (['main-heading', 'section-heading', 'sub-heading', 'highlighted-heading'].includes(currentElement.type)) {
      const hasSpacing = elementsAfter.some(el => el.type === 'spacing');
      if (!hasSpacing) {
        return {
          text: 'Add Spacing',
          type: 'spacing',
          priority: 1,
          description: 'Add spacing after the heading for better visual separation'
        };
      }
    }

    // For descriptions, suggest spacing if not already present
    if (['description', 'simple-text'].includes(currentElement.type)) {
      const hasSpacing = elementsAfter.some(el => el.type === 'spacing');
      if (!hasSpacing) {
        return {
          text: 'Add Spacing',
          type: 'spacing',
          priority: 1,
          description: 'Add spacing after the text for better layout'
        };
      }
    }

    // If all common suggestions are already present, return null
    return null;
  }

  return suggestion;
};

// Check if a suggestion should be shown based on context
export const shouldShowSuggestion = (element, allElements, currentIndex, ignoredSuggestions = new Set()) => {
  // Don't show suggestions for spacing elements to avoid double spacing
  if (element.type === 'spacing') {
    return false;
  }

  // Don't show suggestions for template structure elements in the middle
  if (['date-header', 'banner-section', 'disclaimer'].includes(element.type) && 
      currentIndex > 0 && currentIndex < allElements.length - 1) {
    return false;
  }

  // Don't show suggestions if there are already many elements (to avoid clutter)
  if (allElements.length > 15) {
    return false;
  }

  // Don't show suggestions for elements that already have the suggested element after them
  const elementsAfter = allElements.slice(currentIndex + 1);
  const commonSuggestions = ['spacing', 'description'];
  
  // Check if there are already common elements after this one
  const hasCommonElements = commonSuggestions.some(type => 
    elementsAfter.some(el => el.type === type)
  );

  // If there are already common elements and this is not a heading, don't show suggestion
  if (hasCommonElements && !['main-heading', 'section-heading', 'sub-heading', 'highlighted-heading'].includes(element.type)) {
    return false;
  }

  // Check if this specific suggestion type has been ignored for this element type
  const suggestion = getSuggestionForElement(element.type, allElements);
  if (suggestion && ignoredSuggestions.has(`${element.type}-${suggestion.type}`)) {
    return false;
  }

  return true;
};

// Get suggestion configuration for creating a new element
export const getSuggestionElementConfig = (suggestionType) => {
  const configs = {
    'spacing': {
      type: 'spacing',
      value: 20,
      properties: {
        value: 20
      }
    },
    'description': {
      type: 'description',
      value: 'Add your description text here...',
      properties: {
        value: 'Add your description text here...',
        fontSize: 16,
        textAlign: 'justify',
        textColor: '#333333'
      }
    },
    'main-heading': {
      type: 'main-heading',
      value: 'Main Heading',
      properties: {
        value: 'Main Heading',
        fontSize: 24,
        textAlign: 'center',
        primaryColor: '#1976d2'
      }
    },
    'section-heading': {
      type: 'section-heading',
      value: 'Section Heading',
      properties: {
        value: 'Section Heading',
        fontSize: 20,
        textAlign: 'left',
        primaryColor: '#1976d2'
      }
    },
    'small-text': {
      type: 'small-text',
      value: 'Image caption text...',
      properties: {
        value: 'Image caption text...',
        fontSize: 14,
        textColor: '#666666',
        textAlign: 'center',
        italic: true
      }
    },
    'banner-section': {
      type: 'banner-section',
      value: 'https://via.placeholder.com/650x120/1976d2/ffffff?text=Banner+Image',
      properties: {
        value: 'https://via.placeholder.com/650x120/1976d2/ffffff?text=Banner+Image'
      }
    }
  };

  return configs[suggestionType] || null;
};

// Create a new element from suggestion
export const createElementFromSuggestion = (suggestion, primaryColor = '#1976d2') => {
  console.log('🔧 Creating element from suggestion:', suggestion);
  
  const config = getSuggestionElementConfig(suggestion.type);
  console.log('⚙️ Element config:', config);
  
  if (!config) {
    console.error('❌ No config found for suggestion type:', suggestion.type);
    return null;
  }

  const elementId = `element_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const newElement = {
    id: elementId,
    type: config.type,
    value: config.value,
    ...config.properties,
    primaryColor,
    timestamp: new Date().toISOString()
  };
  
  console.log('✨ Created new element:', newElement);
  return newElement;
};
