/**
 * Utility functions for converting markdown to HTML
 */

import ReactMarkdown from 'react-markdown';

/**
 * Helper function to determine if content needs spacing
 * @param {string} content - The content to analyze
 * @returns {boolean} - True if content needs spacing
 */
const needsSpacing = (content) => {
  // Check if content has multiple lines or intentional spacing
  const lines = content.split('\n');
  if (lines.length <= 1) return false;
  
  // Check if there are empty lines or multiple non-empty lines
  const nonEmptyLines = lines.filter(line => line.trim() !== '');
  return nonEmptyLines.length > 1 || lines.some(line => line.trim() === '');
};

/**
 * Convert markdown text to HTML string
 * @param {string} markdownText - The markdown text to convert
 * @param {boolean} wrapInParagraphs - Whether to wrap content in paragraph tags (default: true)
 * @returns {string} - HTML string
 */
export const markdownToHtml = (markdownText, wrapInParagraphs = true) => {
  if (!markdownText) return '';

  // Custom renderer to convert React elements to HTML strings
  const customComponents = {
    // Handle HTML tags that aren't standard markdown
    u: ({ children }) => `<u>${children}</u>`,
    strong: ({ children }) => `<strong>${children}</strong>`,
    em: ({ children }) => `<em>${children}</em>`,
    del: ({ children }) => `<del>${children}</del>`,
    code: ({ children }) => `<code style="background-color: #f5f5f5; padding: 2px 4px; border-radius: 3px; font-family: monospace;">${children}</code>`,
    a: ({ href, children }) => `<a href="${href}" target="_blank" rel="noopener noreferrer" style="color: #1930ab;">${children}</a>`,
    p: ({ children }) => `<p style="margin: 0px;">${children}</p>`,
    h1: ({ children }) => `<h1>${children}</h1>`,
    h2: ({ children }) => `<h2>${children}</h2>`,
    h3: ({ children }) => `<h3>${children}</h3>`,
    h4: ({ children }) => `<h4>${children}</h4>`,
    h5: ({ children }) => `<h5>${children}</h5>`,
    h6: ({ children }) => `<h6>${children}</h6>`,
    ul: ({ children }) => `<ul>${children}</ul>`,
    ol: ({ children }) => `<ol>${children}</ol>`,
    li: ({ children }) => `<li>${children}</li>`,
    blockquote: ({ children }) => `<blockquote>${children}</blockquote>`,
    hr: () => `<hr>`,
    br: () => `<br>`
  };

  // For now, we'll use a simple conversion approach
  // In a production environment, you might want to use a more robust markdown-to-HTML converter
  let html = markdownText;

  // Convert markdown syntax to HTML
  html = html
    // Bold text (both markdown and HTML formats)
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic text (both markdown and HTML formats)
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Underline (custom markdown syntax)
    .replace(/__(.*?)__/g, '<u>$1</u>')
    // Strikethrough (both markdown and HTML formats)
    .replace(/~~(.*?)~~/g, '<del>$1</del>')
    // Color text (custom markdown syntax: [color:#1930ab]text[/color])
    .replace(/\[color:(#[a-fA-F0-9]{6})\](.*?)\[\/color\]/g, '<span style="color: $1;">$2</span>')
    // Color text from HTML spans (for editor compatibility)
    .replace(/<span style="color: ([^"]+);">(.*?)<\/span>/g, '<span style="color: $1;">$2</span>')
    // Short color syntax: [c:#1930ab]text[/c]
    .replace(/\[c:(#[a-fA-F0-9]{6})\](.*?)\[\/c\]/g, '<span style="color: $1;">$2</span>')
    // Links
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" style="color: #1976d2;">$1</a>');

  // Handle bullet points - convert lines starting with • to HTML list
  const lines = html.split('\n');
  const processedLines = [];
  let inList = false;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmedLine = line.trim();
    
    if (trimmedLine.startsWith('•')) {
      // This is a bullet point
      if (!inList) {
        processedLines.push('<ul style="margin: 0px !important;padding: 0px !important;padding-left: 14px !important;">');
        inList = true;
      }
      const listItem = trimmedLine.substring(1).trim(); // Remove the bullet point
      processedLines.push(`<li>${listItem}</li>`);
    } else {
      // This is not a bullet point
      if (inList) {
        processedLines.push('</ul>');
        inList = false;
      }
      processedLines.push(line);
    }
  }
  
  // Close any remaining list
  if (inList) {
    processedLines.push('</ul>');
  }
  
  html = processedLines.join('\n');

  // Handle line breaks and paragraph wrapping based on the wrapInParagraphs parameter
  if (wrapInParagraphs) {
    // Check if content actually needs spacing
    if (needsSpacing(html)) {
      // Split content into lines to analyze spacing needs
      const lines = html.split('\n');
      const processedLines = [];
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        const nextLine = i < lines.length - 1 ? lines[i + 1].trim() : '';
        
        if (line === '') {
          // Skip empty lines - don't add any HTML for them
          continue;
        } else if (nextLine === '') {
          // Current line has content, next line is empty - add margin-bottom
          processedLines.push(`<p style="margin: 0px; margin-bottom: 2px;">${line}</p>`);
        } else if (i === lines.length - 1) {
          // Last line - no margin-bottom
          processedLines.push(`<p style="margin: 0px;">${line}</p>`);
        } else {
          // Regular line with content - add margin-bottom
          processedLines.push(`<p style="margin: 0px; margin-bottom: 2px;">${line}</p>`);
        }
      }
      
      html = processedLines.join('');
    } else {
      // If no spacing needed, just wrap in a single paragraph without margin-bottom
      html = `<p style="margin: 0px;">${html}</p>`;
    }
  } else {
    // For inline content (like bullet points), remove line breaks but keep br tags for proper formatting
    html = html.replace(/\n/g, '').replace(/<br\s*\/?>/g, '');
  }

  return html;
};

/**
 * Convert markdown text to plain text (removes all formatting)
 * @param {string} markdownText - The markdown text to convert
 * @returns {string} - Plain text string
 */
export const markdownToPlainText = (markdownText) => {
  if (!markdownText) return '';

  return markdownText
    // Remove markdown formatting
    .replace(/\*\*(.*?)\*\*/g, '$1') // Bold
    .replace(/\*(.*?)\*/g, '$1') // Italic
    .replace(/~~(.*?)~~/g, '$1') // Strikethrough
    .replace(/`(.*?)`/g, '$1') // Code
    .replace(/\[color:(#[a-fA-F0-9]{6})\](.*?)\[\/color\]/g, '$2') // Color
    .replace(/\[c:(#[a-fA-F0-9]{6})\](.*?)\[\/c\]/g, '$2') // Short color
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1') // Links
    .replace(/<[^>]*>/g, ''); // Remove HTML tags
};

/**
 * Get a preview of the markdown text (first 100 characters)
 * @param {string} markdownText - The markdown text
 * @returns {string} - Preview text
 */
export const getMarkdownPreview = (markdownText) => {
  if (!markdownText) return '';
  
  const plainText = markdownToPlainText(markdownText);
  return plainText.length > 100 ? plainText.substring(0, 100) + '...' : plainText;
};

/**
 * Validate markdown text for potential issues
 * @param {string} markdownText - The markdown text to validate
 * @returns {object} - Validation result with isValid and issues
 */
export const validateMarkdown = (markdownText) => {
  const issues = [];
  
  if (!markdownText) {
    return { isValid: true, issues: [] };
  }

  // Check for unclosed formatting
  const boldCount = (markdownText.match(/\*\*/g) || []).length;
  if (boldCount % 2 !== 0) {
    issues.push('Unclosed bold formatting (**)');
  }

  const italicCount = (markdownText.match(/\*/g) || []).length;
  if (italicCount % 2 !== 0) {
    issues.push('Unclosed italic formatting (*)');
  }

  const strikethroughCount = (markdownText.match(/~~/g) || []).length;
  if (strikethroughCount % 2 !== 0) {
    issues.push('Unclosed strikethrough formatting (~~)');
  }

  const codeCount = (markdownText.match(/`/g) || []).length;
  if (codeCount % 2 !== 0) {
    issues.push('Unclosed code formatting (`)');
  }

  // Check for unclosed color formatting
  const colorOpenCount = (markdownText.match(/\[color:/g) || []).length;
  const colorCloseCount = (markdownText.match(/\[\/color\]/g) || []).length;
  const shortColorOpenCount = (markdownText.match(/\[c:/g) || []).length;
  const shortColorCloseCount = (markdownText.match(/\[\/c\]/g) || []).length;
  
  if (colorOpenCount !== colorCloseCount) {
    issues.push('Unclosed color formatting ([color:...][/color])');
  }
  if (shortColorOpenCount !== shortColorCloseCount) {
    issues.push('Unclosed short color formatting ([c:...][/c])');
  }

  // Check for malformed links
  const linkPattern = /\[([^\]]*)\]\(([^)]*)\)/g;
  let match;
  while ((match = linkPattern.exec(markdownText)) !== null) {
    if (!match[1] || !match[2]) {
      issues.push('Malformed link detected');
    }
  }

  // Check for malformed color tags
  const colorPattern = /\[color:(#[a-fA-F0-9]{6})\](.*?)\[\/color\]/g;
  while ((match = colorPattern.exec(markdownText)) !== null) {
    if (!match[1] || !match[2]) {
      issues.push('Malformed color formatting detected');
    }
  }

  // Check for malformed short color tags
  const shortColorPattern = /\[c:(#[a-fA-F0-9]{6})\](.*?)\[\/c\]/g;
  while ((match = shortColorPattern.exec(markdownText)) !== null) {
    if (!match[1] || !match[2]) {
      issues.push('Malformed short color formatting detected');
    }
  }

  return {
    isValid: issues.length === 0,
    issues
  };
};
