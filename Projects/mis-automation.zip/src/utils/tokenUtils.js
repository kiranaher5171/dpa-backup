/**
 * Token utility functions for consistent token validation across the application
 */

/**
 * Check if a JWT token is expired
 * @param {string} token - The JWT token to check
 * @returns {boolean} - True if token is expired, false otherwise
 */
export const isTokenExpired = (token) => {
  if (!token) return true;
  
  try {
    const tokenPayload = JSON.parse(atob(token.split('.')[1]));
    const currentTime = Math.floor(Date.now() / 1000);
    return tokenPayload.exp && tokenPayload.exp < currentTime;
  } catch (error) {
    console.log('🔐 TokenUtils: Could not decode token for expiration check:', error.message);
    return false; // If we can't decode, assume it's valid and let the API handle it
  }
};

/**
 * Check if session is expired using expireTime from localStorage
 * @returns {boolean} - True if session is expired, false otherwise
 */
export const isSessionExpired = () => {
  if (typeof window === 'undefined') return true;
  
  try {
    const expireTime = localStorage.getItem('expireTime');
    if (!expireTime) return true;
    
    const expireDate = new Date(expireTime);
    const currentDate = new Date();
    return currentDate > expireDate;
  } catch (error) {
    console.log('🔐 TokenUtils: Error checking session expiration:', error.message);
    return true; // If we can't check, assume expired for security
  }
};

/**
 * Get current session data from localStorage
 * @returns {object|null} - Session data or null if not found/invalid
 */
export const getCurrentSession = () => {
  if (typeof window === 'undefined') return null;
  
  try {
    const session = localStorage.getItem('session');
    if (!session) return null;
    
    const sessionData = JSON.parse(session);
    return sessionData;
  } catch (error) {
    console.error('🔐 TokenUtils: Error getting current session:', error);
    return null;
  }
};

/**
 * Validate session and token
 * @returns {object} - Validation result with isValid, isExpired, and session properties
 */
export const validateSession = () => {
  const session = getCurrentSession();
  
  if (!session || !session.accessToken) {
    return {
      isValid: false,
      isExpired: true,
      session: null,
      reason: 'No session or access token found'
    };
  }

  // Check session expiration first (this is our main session timeout)
  const sessionExpired = isSessionExpired();
  if (sessionExpired) {
    return {
      isValid: false,
      isExpired: true,
      session: session,
      reason: 'Session expired (4 hour timeout)'
    };
  }

  // Only check JWT token expiration if session is still valid
  // This allows the session to continue even if the JWT token expires,
  // as long as the 4-hour session window is still active
  const tokenExpired = isTokenExpired(session.accessToken);
  if (tokenExpired) {
    console.log('🔐 TokenUtils: JWT token expired but session is still valid - session will continue');
  }

  return {
    isValid: !sessionExpired, // Only session expiration matters for overall validity
    isExpired: sessionExpired,
    session: session,
    reason: sessionExpired ? 'Session expired (4 hour timeout)' : null
  };
};

/**
 * Clear session data from localStorage
 */
export const clearSession = () => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('session');
    localStorage.removeItem('expireTime');
  }
};

/**
 * Decode JWT token payload without verification
 * @param {string} token - The JWT token to decode
 * @returns {object|null} - Decoded token payload or null if invalid
 */
export const decodeToken = (token) => {
  if (!token) return null;
  
  try {
    return JSON.parse(atob(token.split('.')[1]));
  } catch (error) {
    console.log('🔐 TokenUtils: Could not decode token:', error.message);
    return null;
  }
};
