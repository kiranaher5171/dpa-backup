/**
 * URL validation and sanitization utilities to prevent XSS attacks
 */

/**
 * Validates if a URL is safe for use in img src attributes
 * @param {string} url - The URL to validate
 * @returns {boolean} - True if the URL is safe, false otherwise
 */
export const isValidImageUrl = (url) => {
    if (!url || typeof url !== 'string') {
        return false;
    }

    try {
        const urlObj = new URL(url);
        
        // Only allow HTTP and HTTPS protocols
        if (!['http:', 'https:'].includes(urlObj.protocol)) {
            return false;
        }

        // Check for common XSS patterns
        const dangerousPatterns = [
            'javascript:',
            'data:',
            'vbscript:',
            'onload=',
            'onerror=',
            'onclick=',
            'onmouseover=',
            'onfocus=',
            'onblur=',
            'onchange=',
            'onsubmit=',
            'onreset=',
            'onselect=',
            'onunload=',
            'onbeforeunload=',
            'onresize=',
            'onabort=',
            'onbeforeprint=',
            'onafterprint=',
            'onbeforecopy=',
            'onbeforecut=',
            'onbeforepaste=',
            'oncopy=',
            'oncut=',
            'onpaste=',
            'onsearch=',
            'onselectionchange=',
            'onstorage=',
            'oncontextmenu=',
            'oninput=',
            'oninvalid=',
            'onselectstart=',
            'onstart=',
            'onstop=',
            'onhelp=',
            'onkeydown=',
            'onkeypress=',
            'onkeyup=',
            'onmousedown=',
            'onmouseenter=',
            'onmouseleave=',
            'onmousemove=',
            'onmouseout=',
            'onmouseup=',
            'onwheel=',
            'onbeforeinput=',
            'oncompositionend=',
            'oncompositionstart=',
            'oncompositionupdate=',
            'oncanplay=',
            'oncanplaythrough=',
            'oncuechange=',
            'ondurationchange=',
            'onemptied=',
            'onended=',
            'onloadeddata=',
            'onloadedmetadata=',
            'onloadstart=',
            'onpause=',
            'onplay=',
            'onplaying=',
            'onprogress=',
            'onratechange=',
            'onseeked=',
            'onseeking=',
            'onstalled=',
            'onsuspend=',
            'ontimeupdate=',
            'onvolumechange=',
            'onwaiting=',
            'onanimationend=',
            'onanimationiteration=',
            'onanimationstart=',
            'ontransitionend=',
            'onwebkitanimationend=',
            'onwebkitanimationiteration=',
            'onwebkitanimationstart=',
            'onwebkittransitionend=',
            'onabort=',
            'onbeforeunload=',
            'onerror=',
            'onhashchange=',
            'onmessage=',
            'onoffline=',
            'ononline=',
            'onpagehide=',
            'onpageshow=',
            'onpopstate=',
            'onrejectionhandled=',
            'onstorage=',
            'onunhandledrejection=',
            'onunload='
        ];

        const urlLower = url.toLowerCase();
        for (const pattern of dangerousPatterns) {
            if (urlLower.includes(pattern)) {
                return false;
            }
        }

        // Check for script injection patterns
        const scriptPatterns = [
            '<script',
            'javascript:',
            'data:text/html',
            'data:application/javascript',
            'vbscript:',
            'expression(',
            'url(',
            'eval(',
            'setTimeout(',
            'setInterval(',
            'Function(',
            'constructor(',
            'prototype.',
            '__proto__',
            'toString(',
            'valueOf(',
            'hasOwnProperty(',
            'isPrototypeOf(',
            'propertyIsEnumerable(',
            'toLocaleString('
        ];

        for (const pattern of scriptPatterns) {
            if (urlLower.includes(pattern)) {
                return false;
            }
        }

        return true;
    } catch (error) {
        // If URL parsing fails, it's not a valid URL
        return false;
    }
};

/**
 * Sanitizes a URL for safe use in img src attributes
 * @param {string} url - The URL to sanitize
 * @returns {string|null} - The sanitized URL or null if invalid
 */
export const sanitizeImageUrl = (url) => {
    if (!url || typeof url !== 'string') {
        return null;
    }

    // Trim whitespace
    const trimmedUrl = url.trim();
    
    // Check if it's a valid image URL
    if (!isValidImageUrl(trimmedUrl)) {
        return null;
    }

    return trimmedUrl;
};

/**
 * Creates a safe fallback URL for broken images
 * @returns {string} - A safe placeholder image URL
 */
export const getFallbackImageUrl = () => {
    // Return a safe placeholder image URL
    return 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjEyMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlPC90ZXh0Pjwvc3ZnPg==';
};

/**
 * Validates and sanitizes multiple URLs
 * @param {Array} urls - Array of URLs to validate
 * @returns {Array} - Array of sanitized URLs
 */
export const sanitizeImageUrls = (urls) => {
    if (!Array.isArray(urls)) {
        return [];
    }

    return urls.map(url => sanitizeImageUrl(url)).filter(url => url !== null);
};
