import React, { useState } from 'react';
import { Box, Typography, Paper, IconButton, Tooltip, Accordion, AccordionSummary, AccordionDetails, Chip } from '@mui/material';
import { useDraggable } from '@dnd-kit/core';
import { elementTypes, getAllCategories, getElementsByCategory } from '../config/elementTypes';
import {
  LuLayoutList,
  LuHeading1,
  LuHeading2
} from "react-icons/lu";
import {
  RxTextAlignJustify,
  RxRowSpacing
} from "react-icons/rx";
import {
  FaImage,
  FaCode
} from "react-icons/fa6";
import { IoBarChartOutline } from "react-icons/io5";
import {
  FormatListBulleted,
  FormatQuote,
  Highlight,
  Summarize,
  Remove,
  DateRange,
  NewReleases,
  Gavel,
  ViewModule,
  CheckCircle,
  Newspaper
} from '@mui/icons-material';
import KeyboardArrowDownOutlinedIcon from '@mui/icons-material/KeyboardArrowDownOutlined';
import KeyboardArrowUpOutlinedIcon from '@mui/icons-material/KeyboardArrowUpOutlined';




const ToolboxItem = ({ type, icon: Icon, label, description, disabled, disabledReason }) => {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `toolbox-${type}`,
    data: {
      type,
      isToolboxItem: true
    },
    disabled: disabled
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    zIndex: isDragging ? 1000 : 'auto',
  } : undefined;

  return (
    // <Tooltip title={disabled ? disabledReason : `Add ${label.toLowerCase()}`} placement="right">
    <Paper
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      style={style}
      sx={{
        p: 1,
        mb: 1.5,
        display: 'flex',
        alignItems: 'center',
        cursor: disabled ? 'not-allowed' : 'grab',
        transition: 'all 0.2s ease',
        border: '1px solid transparent',
        opacity: disabled ? 0.5 : 1,
        '&:hover': {
          backgroundColor: disabled ? 'transparent' : 'action.hover',
          borderColor: disabled ? 'transparent' : 'primary.main',
          transform: disabled ? 'none' : 'translateY(-2px)',
          boxShadow: disabled ? 1 : 3
        },
        '&:active': {
          cursor: disabled ? 'not-allowed' : 'grabbing',
          transform: disabled ? 'none' : 'translateY(0px)'
        }
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 40,
          height: 40,
          borderRadius: 1,
          bgcolor: disabled ? 'grey.400' : '#deefff',
          color: '#0a84ff',
          mr: '12px',
          flexShrink: 0
        }}
      >
        {disabled ? <CheckCircle className='green' /> : <Icon />}
      </Box>
      <Box sx={{ flexGrow: 1 }}>
        <Typography variant="h6" sx={{ fontWeight: 600, color: disabled ? 'text.disabled' : 'text.primary' }}>
          {label}
        </Typography>
        {description && (
          <Typography variant="body1" color="text.secondary" sx={{ fontSize: '10px !important', lineHeight: 'normal !important' }}>
            {description}
          </Typography>
        )}
        {/* {disabled && (
          <Chip
            label="Added"
            size="small"
            color="success"
            variant="outlined"
            sx={{ mt: 0.5 }}
          />
        )} */}
      </Box>
      {/* <IconButton size="small" sx={{ opacity: disabled ? 0.3 : 0.5 }}>
        <LuLayoutList fontSize="small" />
      </IconButton> */}
    </Paper>
    // </Tooltip>
  );
};

const ElementToolbox = ({ currentElements = [], disabled = false }) => {
  const categories = getAllCategories();

  // Define single instance elements
  const singleInstanceElements = ['date-header', 'banner-section', 'whats-new-dpa', 'disclaimer'];

  return (
    <Box px={2} py={1} sx={{ height: '100%', overflow: 'auto', opacity: disabled ? 0.6 : 1 }}>
      <Typography variant="h6" sx={{ mb: '8px', fontWeight: 600 }}>
        Elements
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 1, fontSize: '12px !important', lineHeight: 'normal !important' }}>
        {disabled ? 'HTML Preview mode - editing disabled' : 'Drag elements to the canvas to build your document'}
      </Typography>

      {Object.entries(categories).map(([categoryKey, category]) => {
        const elements = getElementsByCategory(categoryKey);

        const [expanded, setExpanded] = useState(true);

        return (
          <Accordion
            id="element-accordion"
            key={categoryKey}
            expanded={expanded}
            onChange={(event, isExpanded) => setExpanded(isExpanded)}
            sx={{ mb: 2 }}
          >
            <AccordionSummary
              expandIcon={null}
              sx={{
                '& .MuiAccordionSummary-content': {
                  margin: 0
                }
              }}
            >
              <Typography variant="h6" className='primary fw6'>
                {category.name}
              </Typography>

              <Box sx={{ position: 'absolute', right: 10, top: 6 }}>
                {expanded ? <KeyboardArrowUpOutlinedIcon fontSize='small' /> : <KeyboardArrowDownOutlinedIcon fontSize='small' />}
              </Box>

            </AccordionSummary>
            <AccordionDetails>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 1, display: 'block' }}>
                {category.description}
              </Typography>

              {elements.map((element) => {
                // Check if this is a single instance element that already exists
                const isSingleInstance = singleInstanceElements.includes(element.type);
                const alreadyExists = currentElements.some(el => el.type === element.type);
                const isDisabled = isSingleInstance && alreadyExists;
                const disabledReason = isSingleInstance && alreadyExists
                  ? `${element.name} already added (single instance only)`
                  : null;

                return (
                  <ToolboxItem
                    key={element.type}
                    type={element.type}
                    icon={getIconComponent(element.icon)}
                    label={element.name}
                    description={element.description}
                    disabled={disabled || isDisabled}
                    disabledReason={disabled ? 'HTML Preview mode - editing disabled' : disabledReason}
                  />
                );
              })}
            </AccordionDetails>
          </Accordion>
        );
      })}

      <Box sx={{ mt: 4, p: 2, bgcolor: 'action.hover', borderRadius: 1 }}>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
          💡 Tip
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Double-click elements on the canvas to edit their content directly
        </Typography>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
          Template elements (Date Header, Banner, What's New, Disclaimer) can only be added once
        </Typography>
      </Box>
    </Box>
  );
};

// Helper function to get icon component
const getIconComponent = (iconName) => {
  const iconMap = {
    'Title': LuHeading1,
    'SubdirectoryArrowRight': LuHeading2,
    'TextFields': RxTextAlignJustify,
    'Height': RxRowSpacing,
    'Image': FaImage,
    'Code': FaCode,
    'BarChart': IoBarChartOutline,
    'LayoutList': LuLayoutList,
    'FormatListBulleted': FormatListBulleted,
    'Remove': Remove,
    'Summarize': Summarize,
    'Highlight': Highlight,
    'FormatQuote': FormatQuote,
    'DateRange': DateRange,
    'NewReleases': NewReleases,
    'Gavel': Gavel,
    'ViewModule': ViewModule,
    'Newspaper': Newspaper,
    'FormatListBulleted': FormatListBulleted
  };

  return iconMap[iconName] || LuLayoutList;
};

export default ElementToolbox;
