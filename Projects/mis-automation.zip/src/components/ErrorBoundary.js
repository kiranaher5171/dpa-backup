import React from 'react';
import { Box, Typography, Button, Alert } from '@mui/material';
import { Refresh, BugReport } from '@mui/icons-material';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // Log the error to console for debugging
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    // Update state with error details
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  handleReport = () => {
    // You can implement error reporting logic here
    console.log('Error reported:', this.state.error);
    alert('Error has been logged. Please check the console for details.');
  };

  render() {
    if (this.state.hasError) {
      return (
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '400px',
            p: 4,
            textAlign: 'center',
            bgcolor: 'background.paper',
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'error.main',
          }}
        >
          <BugReport sx={{ fontSize: 64, color: 'error.main', mb: 2 }} />
          
          <Typography variant="h5" component="h2" gutterBottom color="error.main">
            Something went wrong
          </Typography>
          
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3, maxWidth: 500 }}>
            An unexpected error occurred while rendering this component. This might be due to a temporary issue or corrupted data.
          </Typography>

          <Alert severity="error" sx={{ mb: 3, maxWidth: 500, textAlign: 'left' }}>
            <Typography variant="body2" component="div">
              <strong>Error:</strong> {this.state.error?.message || 'Unknown error'}
            </Typography>
            {process.env.NODE_ENV === 'development' && this.state.errorInfo && (
              <Typography variant="body2" component="div" sx={{ mt: 1, fontFamily: 'monospace', fontSize: '0.8rem' }}>
                <strong>Component Stack:</strong> {this.state.errorInfo.componentStack}
              </Typography>
            )}
          </Alert>

          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', justifyContent: 'center' }}>
            <Button
              variant="contained"
              startIcon={<Refresh />}
              onClick={this.handleRetry}
              sx={{ minWidth: 120 }}
            >
              Try Again
            </Button>
            
            <Button
              variant="outlined"
              startIcon={<BugReport />}
              onClick={this.handleReport}
              sx={{ minWidth: 120 }}
            >
              Report Issue
            </Button>
          </Box>

          {process.env.NODE_ENV === 'development' && (
            <Box sx={{ mt: 3, p: 2, bgcolor: 'grey.100', borderRadius: 1, maxWidth: 500 }}>
              <Typography variant="caption" component="div" sx={{ fontFamily: 'monospace' }}>
                <strong>Development Mode:</strong> Check the browser console for more detailed error information.
              </Typography>
            </Box>
          )}
        </Box>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
