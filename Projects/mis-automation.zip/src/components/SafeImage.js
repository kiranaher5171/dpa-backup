import React, { useState } from 'react';
import { sanitizeImageUrl, getFallbackImageUrl } from '@/utils/urlValidation';

/**
 * SafeImage component that prevents XSS attacks by sanitizing image URLs
 * @param {Object} props - Component props
 * @param {string} props.src - Image source URL
 * @param {string} props.alt - Alt text for the image
 * @param {Object} props.style - CSS styles
 * @param {Function} props.onError - Error handler
 * @param {Function} props.onLoad - Load handler
 * @param {Object} props.rest - Additional props to pass to img element
 */
const SafeImage = ({ 
    src, 
    alt = '', 
    style = {}, 
    onError, 
    onLoad, 
    ...rest 
}) => {
    const [imageSrc, setImageSrc] = useState(() => {
        // Sanitize the URL on component mount
        return sanitizeImageUrl(src) || getFallbackImageUrl();
    });
    
    const [hasError, setHasError] = useState(false);

    // Handle image load errors
    const handleError = (event) => {
        if (!hasError) {
            setHasError(true);
            setImageSrc(getFallbackImageUrl());
        }
        
        if (onError) {
            onError(event);
        }
    };

    // Handle successful image load
    const handleLoad = (event) => {
        setHasError(false);
        if (onLoad) {
            onLoad(event);
        }
    };

    // Update image source when src prop changes
    React.useEffect(() => {
        const sanitizedUrl = sanitizeImageUrl(src);
        if (sanitizedUrl) {
            setImageSrc(sanitizedUrl);
            setHasError(false);
        } else {
            setImageSrc(getFallbackImageUrl());
            setHasError(true);
        }
    }, [src]);

    return (
        <img
            src={imageSrc}
            alt={alt}
            style={style}
            onError={handleError}
            onLoad={handleLoad}
            {...rest}
        />
    );
};

export default SafeImage;
