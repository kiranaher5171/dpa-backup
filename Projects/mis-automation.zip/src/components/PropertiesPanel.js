import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  TextField,
  Slider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  IconButton,
  Button,
  Divider,
  Chip,
  Switch,
  FormControlLabel,
  Autocomplete
} from '@mui/material';
import { elementTypes, getElementType } from '../config/elementTypes';
import RichTextEditor from './RichTextEditor';
import ThemeColorPicker from './ThemeColorPicker';
import WhatsNewDPAImageSelector from './WhatsNewDPAImageSelector';
import Settings from '@mui/icons-material/Settings';
import TextFields from '@mui/icons-material/TextFields';
import FormatBold from '@mui/icons-material/FormatBold';
import FormatItalic from '@mui/icons-material/FormatItalic';
import FormatAlignLeft from '@mui/icons-material/FormatAlignLeft';
import FormatAlignCenter from '@mui/icons-material/FormatAlignCenter';
import FormatAlignRight from '@mui/icons-material/FormatAlignRight';
import FormatAlignJustify from '@mui/icons-material/FormatAlignJustify';
import ColorLens from '@mui/icons-material/ColorLens';
import Crop from '@mui/icons-material/Crop';
import Add from '@mui/icons-material/Add';
import AspectRatio from '@mui/icons-material/AspectRatio';
import Opacity from '@mui/icons-material/Opacity';
import Delete from '@mui/icons-material/Delete';
import ContentCopy from '@mui/icons-material/ContentCopy';

// Helper function to sanitize input and prevent HTML tags
const sanitizeInput = (input) => {
  if (typeof input !== 'string') return input;

  // Only prevent < and > characters to avoid HTML tag issues
  // Allow other characters like &, ", ' to be used normally
  return input
    .replace(/</g, '&lt;')  // Escape less than
    .replace(/>/g, '&gt;')  // Escape greater than
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/vbscript:/gi, '') // Remove vbscript: protocol
    .replace(/data:/gi, '') // Remove data: protocol
    .replace(/on\w+\s*=/gi, '') // Remove event handlers
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '') // Remove iframe tags
    .replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, '') // Remove object tags
    .replace(/<embed\b[^<]*(?:(?!<\/embed>)<[^<]*)*<\/embed>/gi, ''); // Remove embed tags
};

// Helper function to validate input before updating
const validateAndSanitizeInput = (value, fieldName, setSanitizationWarnings) => {
  if (typeof value !== 'string') return value;

  const originalLength = value.length;
  const sanitized = sanitizeInput(value);

  // If sanitization changed the input, log a warning and update state
  if (sanitized !== value) {
    console.warn(`⚠️ Potentially harmful content detected in ${fieldName}. Content has been sanitized.`);
    if (setSanitizationWarnings) {
      setSanitizationWarnings(prev => ({
        ...prev,
        [fieldName]: `Content was sanitized to prevent security issues. Original: "${value.substring(0, 50)}${value.length > 50 ? '...' : ''}"`
      }));
    }
  } else {
    // Clear warning if content is clean
    if (setSanitizationWarnings) {
      setSanitizationWarnings(prev => {
        const newWarnings = { ...prev };
        delete newWarnings[fieldName];
        return newWarnings;
      });
    }
  }

  // Check for common XSS patterns
  const xssPatterns = [
    /<script/i,
    /javascript:/i,
    /on\w+\s*=/i,
    /<iframe/i,
    /<object/i,
    /<embed/i,
    /vbscript:/i,
    /data:/i
  ];

  const hasXSSPattern = xssPatterns.some(pattern => pattern.test(value));
  if (hasXSSPattern) {
    console.warn(`⚠️ XSS pattern detected in ${fieldName}. Input has been sanitized.`);
  }

  return sanitized;
};

// Helper function to render text/textarea fields with validation
const renderTextField = (propName, propConfig, selectedElement, handlePropertyChange, disabled, sanitizationWarnings, setSanitizationWarnings, themeColors = []) => {
  const handleInputChange = (e) => {
    const rawValue = e.target.value;
    const sanitizedValue = validateAndSanitizeInput(rawValue, propName, setSanitizationWarnings);

    // Only update if the value is valid
    if (sanitizedValue === rawValue || sanitizedValue.length <= rawValue.length) {
      handlePropertyChange(propName, sanitizedValue);
    } else {
      // If sanitization removed content, show a warning but still update
      handlePropertyChange(propName, sanitizedValue);
    }
  };

  const handleRichTextChange = (value) => {
    // For rich text, we don't sanitize as aggressively since we want to allow markdown formatting
    handlePropertyChange(propName, value);
  };

  const warning = sanitizationWarnings[propName];

  // Check if this is a disabled disclaimer field (only logoUrl is disabled now)
  const isDisclaimerField = selectedElement.type === 'disclaimer' && propName === 'logoUrl';
  const disclaimerHelperText = isDisclaimerField ? 'Logo URL is not editable for disclaimer elements' : undefined;

  // Check if this field should use rich text editor
  const shouldUseRichText = propConfig.richText ||
    (propConfig.type === 'textarea' && (
      propName.includes('content') ||
      propName.includes('description') ||
      propName.includes('text') ||
      propName.includes('heading') ||
      propName.includes('title') ||
      propName === 'value' // Add 'value' property for textarea fields
    ));


  if (shouldUseRichText) {
    return (
      <Box key={propName} className="textfield auto-complete" sx={{ mb: 2 }}>
        <RichTextEditor
          value={selectedElement[propName] || ''}
          onChange={handleRichTextChange}
          label={propConfig.label}
          multiline={propConfig.type === 'textarea'}
          rows={propConfig.type === 'textarea' ? 4 : 1}
          disabled={disabled}
          placeholder={propConfig.placeholder}
          themeColors={themeColors}
        />
        {warning && (
          <Typography variant="caption" color="error" sx={{ mt: 1, display: 'block' }}>
            {warning}
          </Typography>
        )}
        {disclaimerHelperText && (
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
            {disclaimerHelperText}
          </Typography>
        )}
      </Box>
    );
  }

  return (
    <Box key={propName} className="textfield auto-complete">
      <TextField
        fullWidth
        multiline={propConfig.type === 'textarea'}
        rows={propConfig.type === 'textarea' ? 4 : 1}
        label={propConfig.label}
        value={selectedElement[propName] || ''}
        onChange={handleInputChange}
        required={propConfig.required}
        placeholder={propConfig.placeholder}
        disabled={disabled}
        sx={{ mb: 2 }}
        helperText={warning || disclaimerHelperText || (propConfig.type === 'textarea' ? 'HTML tags (< and >) are not allowed for security reasons' : undefined)}
        error={!!warning}
      />
    </Box>
  );
};

// Helper function to render range/slider fields
const renderRangeField = (propName, propConfig, selectedElement, handlePropertyChange, disabled) => {
  return (
    <Box key={propName} sx={{ mb: 2 }}>
      <Typography variant="body2" sx={{ mb: 1 }}>
        {propConfig.label}: {selectedElement[propName] || propConfig.default}
      </Typography>
      <Slider
        value={selectedElement[propName] || propConfig.default}
        onChange={(_, value) => handlePropertyChange(propName, value)}
        min={propConfig.min}
        max={propConfig.max}
        step={propConfig.step || 1}
        marks
        valueLabelDisplay="auto"
        disabled={disabled}
      />
    </Box>
  );
};

// Helper function to render number fields
const renderNumberField = (propName, propConfig, selectedElement, handlePropertyChange, disabled) => {
  return (
    <Box key={propName} className="textfield auto-complete">
      <TextField
        fullWidth
        type="number"
        label={propConfig.label}
        value={selectedElement[propName] || propConfig.default || 0}
        onChange={(e) => handlePropertyChange(propName, parseInt(e.target.value) || 0)}
        required={propConfig.required}
        placeholder={propConfig.placeholder}
        disabled={false}
        inputProps={{
          min: propConfig.min || 0,
          max: propConfig.max || 100,
          step: propConfig.step || 1
        }}
        sx={{ mb: 2 }}
      />
    </Box>
  );
};

// Helper function to render select/autocomplete fields
const renderSelectField = (propName, propConfig, selectedElement, handlePropertyChange, disabled) => {
  return (
    <FormControl key={propName} fullWidth sx={{ mb: 2 }}>
      <Box className="textfield auto-complete">
        <Autocomplete
          value={selectedElement[propName] || propConfig.default}
          onChange={(_, newValue) => handlePropertyChange(propName, newValue)}
          options={propConfig.options}
          renderInput={(params) => (
            <TextField
              {...params}
              label={propConfig.label}
            />
          )}
          disabled={disabled}
        />
      </Box>
    </FormControl>
  );
};

// Helper function to render color fields
const renderColorField = (propName, propConfig, selectedElement, handlePropertyChange, disabled, themeColors = []) => {
  // All color properties should use theme color picker
  return (
    <Box key={propName} sx={{ mb: 2 }}>
      <ThemeColorPicker
        value={selectedElement[propName] || propConfig.default}
        onChange={(color) => handlePropertyChange(propName, color)}
        label={propConfig.label}
        disabled={disabled}
        themeColors={themeColors}
      />
    </Box>
  );
};

// Helper function to render boolean/switch fields
const renderBooleanField = (propName, propConfig, selectedElement, handlePropertyChange, disabled) => {
  // Handle undefined values - use default if property doesn't exist
  const currentValue = selectedElement[propName] !== undefined 
    ? selectedElement[propName] 
    : (propConfig.default !== undefined ? propConfig.default : false);
  
  return (
    <FormControlLabel
      key={propName}
      control={
        <Switch
          checked={currentValue}
          onChange={(e) => handlePropertyChange(propName, e.target.checked)}
          disabled={disabled}
        />
      }
      label={propConfig.label}
      sx={{ mb: 2, display: 'block' }}
    />
  );
};

// Helper function to get default executive summary structure
const getDefaultExecutiveSummaryStructure = () => {
  return {
    "headings": {
      "operational-strengths": "OPERATIONAL STRENGTHS",
      "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
      "risk-mitigation": "RISK MITIGATION",
      "operational-highlights": "OPERATIONAL HIGHLIGHTS"
    },
    "operational-strengths": [
      {
        "content": "**Sample Item**\n\nSample content with markdown support."
      }
    ],
    "strategic-achievements": [
      {
        "content": "**Sample Item**\n\nSample content with markdown support."
      }
    ],
    "risk-mitigation": [
      {
        "content": "**Sample Item**\n\nSample content with markdown support."
      }
    ],
    "operational-highlights": [
      {
        "content": "**Sample Item**\n\nSample content with markdown support."
      }
    ]
  };
};

// Helper function to parse news data
const parseNewsData = (element) => {
  try {
    if (!element || !element.value) {
      return [];
    }

    if (typeof element.value === 'string') {
      const trimmedValue = element.value.trim();
      if (trimmedValue.startsWith('[')) {
        const parsed = JSON.parse(trimmedValue);
        return Array.isArray(parsed) ? parsed : [];
      } else {
        return [];
      }
    } else if (Array.isArray(element.value)) {
      return element.value;
    } else {
      return [];
    }
  } catch (e) {
    console.error('Error parsing news data in PropertiesPanel:', e);
    return [];
  }
};

// Helper function to parse executive summary data
const parseExecutiveSummaryData = (selectedElement) => {
  try {
    if (selectedElement.value && typeof selectedElement.value === 'string') {
      // Check if it's already a valid JSON string
      if (selectedElement.value.trim().startsWith('{')) {
        const parsed = JSON.parse(selectedElement.value);
        // Ensure headings exist for backward compatibility
        if (!parsed.headings) {
          parsed.headings = {
            "operational-strengths": "OPERATIONAL STRENGTHS",
            "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
            "risk-mitigation": "RISK MITIGATION",
            "operational-highlights": "OPERATIONAL HIGHLIGHTS"
          };
        }
        return parsed;
      } else {
        console.log('Element value is not JSON, using default structure');
        return getDefaultExecutiveSummaryStructure();
      }
    } else {
      return getDefaultExecutiveSummaryStructure();
    }
  } catch (e) {
    console.error('Error parsing executive summary JSON in PropertiesPanel:', e);
    console.error('Failed value:', selectedElement.value);
    return getDefaultExecutiveSummaryStructure();
  }
};

// Helper function to render property based on its type
const renderProperty = (propName, propConfig, selectedElement, handlePropertyChange, disabled, isTemplateMode, sanitizationWarnings, setSanitizationWarnings, themeColors = []) => {
  // No special skipping - all properties render in Content section

  // Check for conditional properties - only render if condition is met
  if (propConfig.condition) {
    const conditionProperty = propConfig.condition.property;
    const conditionValue = propConfig.condition.value;
    const currentValue = selectedElement[conditionProperty];
    
    // If condition is not met, don't render this property
    // For boolean conditions, check if current value matches condition value
    if (currentValue !== conditionValue) {
      return null;
    }
  }

  // Disable disclaimer logo URL field only
  const isDisclaimerField = selectedElement.type === 'disclaimer' && propName === 'logoUrl';
  const fieldDisabled = disabled || isDisclaimerField;

  // In template mode, allow editing of spacing, divider, color, and boolean properties (for has_link)
  if (isTemplateMode && propConfig.type !== 'text' && propConfig.type !== 'textarea' && propConfig.type !== 'number' && propConfig.type !== 'color' && propConfig.type !== 'boolean') {
    return null;
  }

  // Special handling for whats-new-dpa value property - use image selector dropdown
  if (selectedElement.type === 'whats-new-dpa' && propName === 'value') {
    // Get current value - could be URL string or image object
    const currentValue = selectedElement[propName];
    
    // The selector will handle matching URL strings to image objects
    // We pass the current value (URL string) and the selector will find the matching image
    return (
      <Box key={propName} sx={{ mb: 2 }}>
        <WhatsNewDPAImageSelector
          value={currentValue}
          onChange={(image) => {
            // Handle both object and string values
            if (image && typeof image === 'object' && image.url) {
              // Store the URL string in the value property
              handlePropertyChange(propName, image.url);
            } else if (typeof image === 'string') {
              handlePropertyChange(propName, image);
            } else {
              handlePropertyChange(propName, '');
            }
          }}
          label={propConfig.label || 'Select Image'}
          placeholder="Choose an image from the dropdown..."
          disabled={fieldDisabled}
          showPreview={true}
        />
      </Box>
    );
  }

  switch (propConfig.type) {
    case 'text':
    case 'textarea':
      return renderTextField(propName, propConfig, selectedElement, handlePropertyChange, fieldDisabled, sanitizationWarnings, setSanitizationWarnings, themeColors);
    case 'range':
      return renderRangeField(propName, propConfig, selectedElement, handlePropertyChange, fieldDisabled);
    case 'number':
      return renderNumberField(propName, propConfig, selectedElement, handlePropertyChange, fieldDisabled);
    case 'select':
      return renderSelectField(propName, propConfig, selectedElement, handlePropertyChange, fieldDisabled);
    case 'color':
      return renderColorField(propName, propConfig, selectedElement, handlePropertyChange, fieldDisabled, themeColors);
    case 'boolean':
      // Debug log for boolean properties
      if (propName === 'has_link') {
        console.log('Rendering has_link boolean field:', {
          propName,
          currentValue: selectedElement[propName],
          default: propConfig.default,
          elementType: selectedElement.type
        });
      }
      return renderBooleanField(propName, propConfig, selectedElement, handlePropertyChange, fieldDisabled);
    default:
      console.warn('Unknown property type:', propConfig.type, 'for property:', propName);
      return null;
  }
};

// Helper function to parse list items data
const parseListItemsData = (selectedElement) => {
  try {
    if (!selectedElement || !selectedElement.value) {
      return [];
    }

    if (typeof selectedElement.value === 'string') {
      const trimmedValue = selectedElement.value.trim();
      if (trimmedValue.startsWith('[')) {
        const parsed = JSON.parse(trimmedValue);
        return Array.isArray(parsed) ? parsed : [];
      } else {
        return [];
      }
    } else if (Array.isArray(selectedElement.value)) {
      return selectedElement.value;
    } else {
      return [];
    }
  } catch (e) {
    console.error('Error parsing list items data in PropertiesPanel:', e);
    return [];
  }
};

const PropertiesPanel = ({
  selectedElement,
  onUpdate,
  primaryColor,
  setPrimaryColor,
  onDelete,
  disabled = false,
  isTemplateMode = false,
  themeColors = []
}) => {
  const [sanitizationWarnings, setSanitizationWarnings] = useState({});

  const [executiveSummaryData, setExecutiveSummaryData] = useState(() => {
    // Initialize with parsed data if this is an executive summary element
    if (selectedElement?.type === 'executive-summary') {
      return parseExecutiveSummaryData(selectedElement);
    }
    return getDefaultExecutiveSummaryStructure();
  });

  // Add state for news and list data
  const [newsData, setNewsData] = useState(() => {
    if (selectedElement?.type === 'news-section') {
      return parseNewsData(selectedElement);
    }
    return [];
  });

  const [listData, setListData] = useState(() => {
    if (selectedElement?.type === 'list-items') {
      return parseListItemsData(selectedElement);
    }
    return [];
  });

  // Update executive summary data when selected element changes
  useEffect(() => {
    if (selectedElement?.type === 'executive-summary') {
      setExecutiveSummaryData(parseExecutiveSummaryData(selectedElement));
    } else {
      // Reset data when not an executive summary element
      setExecutiveSummaryData(getDefaultExecutiveSummaryStructure());
    }
  }, [selectedElement]);

  // Update news and list data when selected element changes
  useEffect(() => {
    if (selectedElement?.type === 'news-section') {
      setNewsData(parseNewsData(selectedElement));
    } else {
      // Reset data when not a news section element
      setNewsData([]);
    }
  }, [selectedElement]);

  useEffect(() => {
    if (selectedElement?.type === 'list-items') {
      setListData(parseListItemsData(selectedElement));
    } else {
      // Reset data when not a list items element
      setListData([]);
    }
  }, [selectedElement]);
  if (!selectedElement) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Settings sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
        <Typography variant="h6" sx={{ mb: 1 }}>Properties</Typography>
        <Typography color="text.secondary">
          {disabled ? 'HTML Preview mode - editing disabled' : 'Select an element to edit its properties'}
        </Typography>
      </Box>
    );
  }

  const handlePropertyChange = (property, value) => {
    if (disabled) return; // Don't allow changes in preview mode

    // Prevent editing of disclaimer logo URL field only
    if (selectedElement.type === 'disclaimer' && property === 'logoUrl') {
      console.warn('⚠️ Disclaimer logo URL is not editable');
      return;
    }

    // Sanitize text-based properties to prevent XSS
    let sanitizedValue = value;
    const textProperties = ['value', 'caption', 'sectionTitle', 'text', 'content', 'heading', 'title', 'description'];

    if (textProperties.includes(property) && typeof value === 'string') {
      // Don't sanitize URLs for image elements or link fields
      if (selectedElement.type === 'image' || selectedElement.type === 'whats-new-dpa' || property === 'link') {
        // Only basic sanitization for URLs
        sanitizedValue = value.replace(/javascript:/gi, '').replace(/vbscript:/gi, '').replace(/data:/gi, '');
      } else {
        sanitizedValue = validateAndSanitizeInput(value, property, setSanitizationWarnings);
      }
    }

    const updatedElement = {
      ...selectedElement,
      [property]: sanitizedValue
    };

    // Special handling for banner URL changes
    if (property === 'value' && selectedElement.type === 'banner-section') {
      // Extract filename from the URL
      const filename = sanitizedValue.split('/').pop();
      updatedElement.bannerFilename = filename;
    }

    // Special handling removed - all properties handled uniformly

    onUpdate(updatedElement);
  };

  const renderContentSection = () => {
    const elementConfig = getElementType(selectedElement.type);
    if (!elementConfig || !elementConfig.properties) return null;

    // Special handling for executive-summary
    if (selectedElement.type === 'executive-summary') {
      return renderExecutiveSummarySection();
    }

    // Special handling for news-section
    if (selectedElement.type === 'news-section') {
      return renderNewsSection();
    }

    // Special handling for list-items
    if (selectedElement.type === 'list-items') {
      return renderListItemsSection();
    }

    return (
      <Accordion defaultExpanded>
        <AccordionSummary expandIcon={<Settings />}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            Content
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          {Object.entries(elementConfig.properties).map(([propName, propConfig]) => {
            const rendered = renderProperty(propName, propConfig, selectedElement, handlePropertyChange, disabled, isTemplateMode, sanitizationWarnings, setSanitizationWarnings, themeColors);
            // Debug: Log if has_link or link properties are being filtered out
            if ((propName === 'has_link' || propName === 'link') && !rendered) {
              console.warn('Property filtered out:', propName, 'Type:', propConfig.type, 'Element:', selectedElement.type, 'TemplateMode:', isTemplateMode);
            }
            return rendered;
          })}
        </AccordionDetails>
      </Accordion>
    );
  };



  // Helper function to update executive summary data
  const updateExecutiveSummaryData = (newData, setData) => {
    setData(newData);
    handlePropertyChange('value', JSON.stringify(newData, null, 2));
  };

  // Helper function to add content item to executive summary
  const addExecutiveSummaryContent = (sectionKey, data, setData) => {
    const newData = {
      ...data,
      [sectionKey]: [
        ...(data[sectionKey] || []),
        {
          content: '**New Item**\n\nEnter your content here with markdown support.'
        }
      ]
    };
    updateExecutiveSummaryData(newData, setData);
  };

  // Helper function to update content in executive summary
  const updateExecutiveSummaryContent = (sectionKey, index, content, data, setData) => {
    // For content field, we don't sanitize as aggressively since we want to allow markdown formatting
    const newData = {
      ...data,
      [sectionKey]: data[sectionKey].map((item, i) =>
        i === index ? { ...item, content: content } : item
      )
    };
    updateExecutiveSummaryData(newData, setData);
  };

  // Helper function to remove content item from executive summary
  const removeExecutiveSummaryContent = (sectionKey, index, data, setData) => {
    const newData = {
      ...data,
      [sectionKey]: data[sectionKey].filter((_, i) => i !== index)
    };
    updateExecutiveSummaryData(newData, setData);
  };

  // Helper function to render executive summary section item
  const renderExecutiveSummaryItem = (item, contentIndex, section, data, setData) => {
    return (
      <Box key={contentIndex} sx={{ mb: 2, p: 1, bgcolor: 'white', borderRadius: 1, border: '1px solid #ddd' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ flex: 1 }}>
            Content Item {contentIndex + 1}
          </Typography>
          <IconButton
            size="small"
            color="error"
            onClick={() => removeExecutiveSummaryContent(section.key, contentIndex, data, setData)}
            disabled={disabled}
          >
            <Delete fontSize="small" />
          </IconButton>
        </Box>

        <Box sx={{ mb: 2 }}>
          <RichTextEditor
            value={item.content || ''}
            onChange={(value) => updateExecutiveSummaryContent(section.key, contentIndex, value, data, setData)}
            label="Content with Markdown Support"
            multiline={true}
            rows={4}
            disabled={disabled}
            placeholder="Enter your content here with markdown support. Use **bold**, *italic*, etc."
            themeColors={themeColors}
          />
        </Box>
      </Box>
    );
  };

  const renderExecutiveSummarySection = () => {
    // Use the state from the top level component
    const data = executiveSummaryData;
    const setData = setExecutiveSummaryData;


    const sectionConfigs = [
      {
        key: 'operational-strengths',
        title: 'Operational Strengths',
        color: '#1930ab',
        bgColor: '#e6f0fe'
      },
      {
        key: 'strategic-achievements',
        title: 'Strategic Achievements',
        color: '#1e693a',
        bgColor: '#e5fcec'
      },
      {
        key: 'risk-mitigation',
        title: 'Risk Mitigation',
        color: '#8b0000',
        bgColor: '#fde8e8'
      },
      {
        key: 'operational-highlights',
        title: 'Operational Highlights',
        color: '#fa7604',
        bgColor: '#fef0de'
      }
    ];

    const handleHeadingChange = (sectionKey, newHeading) => {
      const updatedData = {
        ...data,
        headings: {
          ...data.headings,
          [sectionKey]: newHeading
        }
      };
      setData(updatedData);
      onUpdate({ ...selectedElement, value: JSON.stringify(updatedData) });
    };

    return (
      <Accordion defaultExpanded>
        <AccordionSummary expandIcon={<Settings />}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            Executive Summary Content
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          {sectionConfigs.map((section) => (
            <Box key={section.key} sx={{ mb: 3, p: 1, border: `1px solid ${section.color}`, borderRadius: 1, bgcolor: section.bgColor }}>
              <TextField
                fullWidth
                label="Section Heading"
                value={data.headings?.[section.key] || section.title}
                onChange={(e) => handleHeadingChange(section.key, e.target.value)}
                disabled={disabled}
                sx={{
                  mb: 2,
                  mt: 2,
                  '& .MuiInputBase-input': {
                    color: section.color,
                    fontWeight: 'bold',
                    fontSize: '1.1rem'
                  },
                  '& .MuiInputLabel-root': {
                    color: section.color
                  },
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: section.color
                    },
                    '&:hover fieldset': {
                      borderColor: section.color
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: section.color
                    }
                  }
                }}
              />

              {(data[section.key] || []).map((item, contentIndex) =>
                renderExecutiveSummaryItem(item, contentIndex, section, data, setData)
              )}

              {/* Show message if no content items exist */}
              {(!data[section.key] || data[section.key].length === 0) && (
                <Box sx={{ textAlign: 'center', py: 2, color: '#666' }}>
                  <Typography variant="body2">
                    No content items yet. Click "Add Content Item" to get started.
                  </Typography>
                </Box>
              )}

              <Button
                variant="contained"
                onClick={() => addExecutiveSummaryContent(section.key, data, setData)}
                disabled={disabled}
                sx={{
                  bgcolor: section.color,
                  '&:hover': { bgcolor: section.color },
                  mt: 1
                }}
              >
                Add Content Item
              </Button>
            </Box>
          ))}
        </AccordionDetails>
      </Accordion>
    );
  };


  // Helper function to update news data
  const updateNewsData = (newData, setNewsData) => {
    setNewsData(newData);
    handlePropertyChange('value', JSON.stringify(newData, null, 2));
  };

  // Helper function to add news item
  const addNewsItem = (newsData, setNewsData) => {
    const newItem = {
      title: 'News Title',
      date: 'Jul-25',
      link: 'https://example.com/news',
      heading: 'News Main Heading',
      description: 'News Content'
    };
    updateNewsData([...newsData, newItem], setNewsData);
  };

  // Helper function to update news item
  const updateNewsItem = (index, field, value, newsData, setNewsData) => {
    // Sanitize text fields but allow URLs for link field
    let sanitizedValue = value;
    if (field !== 'link') {
      sanitizedValue = validateAndSanitizeInput(value, `news-${field}`, setSanitizationWarnings);
    } else {
      // For link field, only allow valid URLs and basic sanitization
      sanitizedValue = value.replace(/javascript:/gi, '').replace(/vbscript:/gi, '').replace(/data:/gi, '');
    }

    const newData = newsData.map((item, i) =>
      i === index ? { ...item, [field]: sanitizedValue } : item
    );
    updateNewsData(newData, setNewsData);
  };

  // Helper function to remove news item
  const removeNewsItem = (index, newsData, setNewsData) => {
    const newData = newsData.filter((_, i) => i !== index);
    updateNewsData(newData, setNewsData);
  };

  // Helper function to render news item
  const renderNewsItem = (news, index, newsData, setNewsData) => {
    // Validate news item data
    if (!news || typeof news !== 'object') {
      console.warn('Invalid news item data:', news);
      return null;
    }

    // Ensure all required fields exist with fallbacks
    const safeNews = {
      title: news.title || '',
      date: news.date || '',
      link: news.link || '',
      heading: news.heading || '',
      description: news.description || ''
    };

    return (
      <Box key={index} sx={{ mb: 3, p: 2, border: '1px solid #ddd', borderRadius: 1, bgcolor: '#f8f9fa' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
            News Item {index + 1}
          </Typography>
          <IconButton
            size="small"
            color="error"
            onClick={() => removeNewsItem(index, newsData, setNewsData)}
            disabled={disabled}
          >
            <Delete fontSize="small" />
          </IconButton>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Box className="textfield auto-complete">
            <TextField
              fullWidth
              size="small"
              label="News Type"
              value={safeNews.title}
              onChange={(e) => updateNewsItem(index, 'title', e.target.value, newsData, setNewsData)}
              disabled={disabled}
              sx={{ mb: 1 }}
            />
          </Box>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Box className="textfield auto-complete">
            <TextField
              fullWidth
              size="small"
              label="Date"
              value={safeNews.date}
              onChange={(e) => updateNewsItem(index, 'date', e.target.value, newsData, setNewsData)}
              placeholder="Jul-25 or any date format"
              helperText="Enter date in any format (e.g., Jul-25, 2024-07-25, July 25, 2024)"
              disabled={disabled}
              sx={{ mb: 1 }}
            />
          </Box>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Box className="textfield auto-complete">
            <TextField
              fullWidth
              size="small"
              label="Link URL"
              value={safeNews.link}
              onChange={(e) => updateNewsItem(index, 'link', e.target.value, newsData, setNewsData)}
              placeholder="https://example.com/news"
              helperText="The link icon will be static, only the URL is editable"
              disabled={disabled}
              sx={{ mb: 1 }}
            />
          </Box>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Box className="textfield auto-complete">
            <TextField
              fullWidth
              size="small"
              label="News Main Heading"
              value={safeNews.heading}
              onChange={(e) => updateNewsItem(index, 'heading', e.target.value, newsData, setNewsData)}
              disabled={disabled}
              sx={{ mb: 1 }}
            />
          </Box>
        </Box>

        <Box sx={{ mb: 2 }}>
          <RichTextEditor
            value={safeNews.description}
            onChange={(value) => updateNewsItem(index, 'description', value, newsData, setNewsData)}
            label="Description (Markdown Supported)"
            multiline={true}
            rows={3}
            disabled={disabled}
            placeholder="Enter news description with markdown support. Use **bold**, *italic*, etc."
            themeColors={themeColors}
          />
        </Box>
      </Box>
    );
  };

  const renderNewsSection = () => {
    return (
      <Accordion defaultExpanded>
        <AccordionSummary expandIcon={<Settings />}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            News Content
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Section Title</Typography>
            <Box className="textfield auto-complete">
              <TextField
                fullWidth
                size="small"
                label="Section Title"
                value={selectedElement.sectionTitle || 'Sector Title'}
                onChange={(e) => {
                  const sanitizedValue = validateAndSanitizeInput(e.target.value, 'news-section-title', setSanitizationWarnings);
                  handlePropertyChange('sectionTitle', sanitizedValue);
                }}
                disabled={disabled}
                helperText="HTML tags (< and >) are not allowed for security reasons"
              />
            </Box>
          </Box>

          {Array.isArray(newsData) && newsData.map((news, index) =>
            renderNewsItem(news, index, newsData, setNewsData)
          )}

          <Button
            variant="contained"
            onClick={() => addNewsItem(newsData, setNewsData)}
            disabled={disabled}
            sx={{ mt: 1 }}
          >
            Add News Item
          </Button>
        </AccordionDetails>
      </Accordion>
    );
  };


  // Helper function to update list items data
  const updateListItemsData = (newData, setListData) => {
    setListData(newData);
    handlePropertyChange('value', JSON.stringify(newData, null, 2));
  };

  // Helper function to add list item
  const addListItem = (listData, setListData) => {
    const newItem = {
      hasHeading: false,
      heading: '',
      content: ['Content 1', 'Content 2']
    };
    updateListItemsData([...listData, newItem], setListData);
  };

  // Helper function to remove list item
  const removeListItem = (index, listData, setListData) => {
    const newData = listData.filter((_, i) => i !== index);
    updateListItemsData(newData, setListData);
  };

  // Helper function to update list item
  const updateListItem = (index, field, value, listData, setListData) => {
    const sanitizedValue = validateAndSanitizeInput(value, `list-item-${field}`, setSanitizationWarnings);
    const newData = [...listData];
    newData[index] = { ...newData[index], [field]: sanitizedValue };
    updateListItemsData(newData, setListData);
  };

  // Helper function to add content item
  const addContentItem = (listIndex, listData, setListData) => {
    const newData = [...listData];
    newData[listIndex].content = [...(newData[listIndex].content || []), 'New Content'];
    updateListItemsData(newData, setListData);
  };

  // Helper function to remove content item
  const removeContentItem = (listIndex, contentIndex, listData, setListData) => {
    const newData = [...listData];
    newData[listIndex].content = newData[listIndex].content.filter((_, i) => i !== contentIndex);
    updateListItemsData(newData, setListData);
  };

  // Helper function to update content item
  const updateContentItem = (listIndex, contentIndex, value, listData, setListData) => {
    const sanitizedValue = validateAndSanitizeInput(value, 'list-item-content', setSanitizationWarnings);
    const newData = [...listData];
    newData[listIndex].content[contentIndex] = sanitizedValue;
    updateListItemsData(newData, setListData);
  };

  // Helper function to render list item
  const renderListItem = (item, listIndex, listData, setListData) => {
    // Validate list item data
    if (!item || typeof item !== 'object') {
      console.warn('Invalid list item data:', item);
      return null;
    }

    // Ensure all required fields exist with fallbacks
    const safeItem = {
      hasHeading: item.hasHeading !== undefined ? item.hasHeading : false,
      heading: item.heading || '',
      content: Array.isArray(item.content) ? item.content : []
    };

    return (
      <Box key={listIndex} sx={{ mb: 3, p: 2, bgcolor: 'white', borderRadius: 1, border: '1px solid #ddd' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Typography variant="subtitle2" sx={{ flex: 1 }}>
            List Item {listIndex + 1}
          </Typography>
          <IconButton
            size="small"
            color="error"
            onClick={() => removeListItem(listIndex, listData, setListData)}
            disabled={disabled}
          >
            <Delete />
          </IconButton>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
            <FormControlLabel
              control={
                <Switch
                  checked={safeItem.hasHeading}
                  onChange={(e) => updateListItem(listIndex, 'hasHeading', e.target.checked, listData, setListData)}
                  disabled={disabled}
                  size="small"
                />
              }
              label="Include Heading"
              sx={{ mb: 0 }}
            />
          </Box>

          {safeItem.hasHeading && (
            <Box className="textfield auto-complete">
              <TextField
                fullWidth
                size="small"
                label="List Item Heading"
                value={safeItem.heading}
                onChange={(e) => updateListItem(listIndex, 'heading', e.target.value, listData, setListData)}
                disabled={disabled}
                sx={{ mb: 1 }}
              />
            </Box>
          )}
        </Box>

        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
            <Typography variant="subtitle2">Content Items:</Typography>
            <Button
              variant="outlined"
              size="small"
              onClick={() => addContentItem(listIndex, listData, setListData)}
              disabled={disabled}
            >
              Add Content
            </Button>
          </Box>

          {safeItem.content.map((content, contentIndex) => (
            <Box key={contentIndex} sx={{ mb: 2, p: 2, bgcolor: '#f8f9fa', borderRadius: 1, border: '1px solid #e0e0e0' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <Typography variant="subtitle2" sx={{ flex: 1 }}>
                  Content {contentIndex + 1}
                </Typography>
                <IconButton
                  size="small"
                  color="error"
                  onClick={() => removeContentItem(listIndex, contentIndex, listData, setListData)}
                  disabled={disabled}
                >
                  <Delete />
                </IconButton>
              </Box>
              <Box className="textfield auto-complete">
                <RichTextEditor
                  value={content}
                  onChange={(value) => updateContentItem(listIndex, contentIndex, value, listData, setListData)}
                  label={`Content ${contentIndex + 1} (Markdown Supported)`}
                  multiline={true}
                  rows={3}
                  disabled={disabled}
                />
              </Box>
            </Box>
          ))}

          {/* Add Content button at the end */}
          <Box sx={{ mt: 2, textAlign: 'center' }}>
            <Button
              variant="outlined"
              size="small"
              onClick={() => addContentItem(listIndex, listData, setListData)}
              disabled={disabled}
              sx={{ 
                borderStyle: 'dashed',
                borderColor: '#1976d2',
                color: '#1976d2',
                '&:hover': {
                  borderStyle: 'solid',
                  backgroundColor: '#f3f8ff'
                }
              }}
            >
              + Add Content
            </Button>
          </Box>
        </Box>
      </Box>
    );
  };

  const renderListItemsSection = () => {
    return (
      <Box sx={{ p: 2 }}>
        <Typography variant="h6" sx={{ mb: 2, color: '#163E64', fontWeight: 'bold' }}>
          List Items Configuration
        </Typography>

        <Box sx={{ mb: 2 }}>
          <Button
            variant="outlined"
            size="small"
            onClick={() => addListItem(listData, setListData)}
            disabled={disabled}
            sx={{ mb: 2 }}
          >
            Add List Item
          </Button>
        </Box>

        {Array.isArray(listData) && listData.map((item, listIndex) =>
          renderListItem(item, listIndex, listData, setListData)
        )}

        {listData.length === 0 && (
          <Box sx={{ textAlign: 'center', py: 3, color: '#666' }}>
            <Typography variant="body2">
              No list items added yet. Click "Add List Item" to get started.
            </Typography>
          </Box>
        )}
      </Box>
    );
  };

  const renderTypographySection = () => {
    // Only show typography section for elements that have text content
    const textElements = ['main-heading', 'section-heading', 'sub-heading', 'description', 'simple-text', 'bullet-points', 'executive-summary', 'highlight-box', 'whats-new-dpa', 'news-section', 'list-items'];
    if (!textElements.includes(selectedElement.type)) {
      return null;
    }

    return (
      <Accordion>
        <AccordionSummary expandIcon={<TextFields />}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            Typography
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Font Size</Typography>
            <Slider
              value={selectedElement.fontSize || 16}
              onChange={(e, value) => handlePropertyChange('fontSize', value)}
              min={12}
              max={48}
              step={1}
              marks
              valueLabelDisplay="auto"
              sx={{ mb: 2 }}
            />
            <Typography variant="caption" color="text.secondary">
              {selectedElement.fontSize || 16}px
            </Typography>
          </Box>

          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Text Alignment</Typography>
            <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
              {[
                { value: 'left', icon: FormatAlignLeft },
                { value: 'center', icon: FormatAlignCenter },
                { value: 'right', icon: FormatAlignRight },
                { value: 'justify', icon: FormatAlignJustify }
              ].map(({ value, icon: Icon }) => (
                <IconButton
                  key={value}
                  size="small"
                  onClick={() => handlePropertyChange('textAlign', value)}
                  sx={{
                    bgcolor: selectedElement.textAlign === value ? 'primary.main' : 'transparent',
                    color: selectedElement.textAlign === value ? 'white' : 'inherit',
                    '&:hover': {
                      bgcolor: selectedElement.textAlign === value ? 'primary.dark' : 'action.hover'
                    }
                  }}
                >
                  <Icon fontSize="small" />
                </IconButton>
              ))}
            </Box>
          </Box>

          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Font Weight</Typography>
            <FormControl fullWidth size="small">
              <Box className="textfield auto-complete">
                <Autocomplete
                  value={selectedElement.fontWeight || 'normal'}
                  onChange={(_, newValue) => handlePropertyChange('fontWeight', newValue)}
                  options={['normal', 'bold', 'lighter']}
                  renderInput={(params) => (
                    <TextField {...params} />
                  )}
                />
              </Box>
            </FormControl>
          </Box>
        </AccordionDetails>
      </Accordion>
    );
  };

  const renderColorsSection = () => (
    <Accordion>
      <AccordionSummary expandIcon={<ColorLens />}>
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          Colors
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Primary Color</Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            <input
              type="color"
              value={primaryColor}
              onChange={(e) => setPrimaryColor(e.target.value)}
              style={{
                width: 40,
                height: 40,
                border: 'none',
                borderRadius: 4,
                cursor: 'pointer'
              }}
            />
            <TextField
              size="small"
              value={primaryColor}
              onChange={(e) => setPrimaryColor(e.target.value)}
              placeholder="#000000"
            />
          </Box>
        </Box>

        {selectedElement.type !== 'main-heading' && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Text Color</Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <input
                type="color"
                value={selectedElement.textColor || '#163E64'}
                onChange={(e) => handlePropertyChange('textColor', e.target.value)}
                style={{
                  width: 40,
                  height: 40,
                  border: 'none',
                  borderRadius: 4,
                  cursor: 'pointer'
                }}
              />
              <TextField
                size="small"
                value={selectedElement.textColor || '#000000'}
                onChange={(e) => handlePropertyChange('textColor', e.target.value)}
                placeholder="#000000"
              />
            </Box>
          </Box>
        )}
      </AccordionDetails>
    </Accordion>
  );

  // Image section removed - all properties now in Content section

  const renderAdvancedSection = () => (
    <Accordion>
      <AccordionSummary expandIcon={<Settings />}>
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          Advanced
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Custom CSS Classes</Typography>
          <Box className="textfield auto-complete">
            <TextField
              fullWidth
              size="small"
              label="CSS Classes"
              value={selectedElement.cssClasses || ''}
              onChange={(e) => handlePropertyChange('cssClasses', e.target.value)}
              placeholder="custom-class another-class"
            />
          </Box>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Element ID</Typography>
          <Box className="textfield auto-complete">
            <TextField
              fullWidth
              size="small"
              label="Element ID"
              value={selectedElement.elementId || ''}
              onChange={(e) => handlePropertyChange('elementId', e.target.value)}
              placeholder="unique-id"
            />
          </Box>
        </Box>

        <FormControlLabel
          control={
            <Switch
              checked={selectedElement.hidden || false}
              onChange={(e) => handlePropertyChange('hidden', e.target.checked)}
            />
          }
          label="Hidden"
        />
      </AccordionDetails>
    </Accordion>
  );

  return (
    <Box sx={{ height: '100%', overflow: 'auto', opacity: disabled ? 0.6 : 1 }}>
      {/* Header */}
      <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Chip
            label={selectedElement.type.replace('-', ' ')}
            size="small"
            color={disabled ? 'default' : 'primary'}
            className='simple-chip'
          />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            {/* Properties */}
            # {selectedElement.id.slice(-8)}
          </Typography>
        </Box>
        {/* <Typography variant="body2" color="text.secondary">
          Element ID: {selectedElement.id.slice(-8)}
        </Typography> */}
        {disabled && (
          <Typography variant="caption" color="warning.main" sx={{ display: 'block', mt: 1 }}>
            HTML Preview mode - editing disabled
          </Typography>
        )}
        {isTemplateMode && (
          <Typography variant="caption" color="info.main" sx={{ display: 'block', mt: 1 }}>
            Template mode - text editing only
          </Typography>
        )}
      </Box>

      {/* Content */}
      <Box sx={{ p: 2 }}>

        <Box mb={1}>
          <Typography variant="h6" color="text.secondary">
            Properties
          </Typography>
        </Box>

        {renderContentSection()}
        {!isTemplateMode && (
          <>
            {renderTypographySection()}
            {renderColorsSection()}
            {renderAdvancedSection()}
          </>
        )}

      </Box>
    </Box>
  );
};

export default PropertiesPanel; 