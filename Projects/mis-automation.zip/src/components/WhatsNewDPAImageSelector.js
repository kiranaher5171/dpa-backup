import React, { useState, useEffect } from 'react';
import {
    Autocomplete,
    TextField,
    CircularProgress,
    Box,
    Typography,
    Chip,
    Alert
} from '@mui/material';
import { Image as ImageIcon } from '@mui/icons-material';
import SafeImage from '@/components/SafeImage';

const WhatsNewDPAImageSelector = ({
    value,
    onChange,
    label = "Select Image",
    placeholder = "Choose an image...",
    error: propError,
    helperText,
    disabled = false,
    multiple = false,
    showPreview = true
}) => {
    const [images, setImages] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // Load images from API
    useEffect(() => {
        loadImages();
    }, []);

    // Auto-select first option when images are loaded and no value is selected
    useEffect(() => {
        console.log('Auto-selection check:', {
            imagesLength: images.length,
            loading,
            hasOnChange: !!onChange,
            currentValue: value,
            hasValue: value && (
                (typeof value === 'string' && value.trim() !== '') ||
                (typeof value === 'object' && (value.filename || value.url))
            )
        });

        if (images.length > 0 && !loading && onChange) {
            // Check if value is truly empty (null, undefined, or empty string)
            const hasValue = value && (
                (typeof value === 'string' && value.trim() !== '') ||
                (typeof value === 'object' && (value.filename || value.url))
            );
            
            if (!hasValue) {
                const firstImage = images[0];
                console.log('🎯 Auto-selecting first image:', firstImage);
                console.log('Current value:', value);
                console.log('Images available:', images.length);
                
                // Add a small delay to ensure the component is fully mounted
                const timer = setTimeout(() => {
                    console.log('🚀 Calling onChange with first image');
                    onChange(firstImage);
                }, 100);
                
                return () => clearTimeout(timer);
            } else {
                console.log('✅ Value already selected, skipping auto-selection');
            }
        }
    }, [images, value, loading, onChange]);

    const loadImages = async () => {
        setLoading(true);
        setError('');

        try {
            // Get authentication token from localStorage
            const session = localStorage.getItem('session');
            let accessToken = '';
            
            if (session) {
                try {
                    const sessionData = JSON.parse(session);
                    accessToken = sessionData.accessToken || '';
                } catch (parseError) {
                    console.error('Error parsing session data:', parseError);
                }
            }

            const headers = {
                'Content-Type': 'application/json'
            };

            // Add Authorization header if we have a token
            if (accessToken) {
                headers['Authorization'] = `Bearer ${accessToken}`;
            }

            const response = await fetch('/api/whats-new-dpa', {
                method: 'GET',
                headers: headers,
                credentials: 'include' // Include cookies for fallback authentication
            });

            if (response.ok) {
                const data = await response.json();
                const imagesData = data.images || [];
                
                console.log('Raw API response:', data);
                console.log('Images data:', imagesData);
                
                // Log each image URL for debugging
                imagesData.forEach((image, index) => {
                    console.log(`🖼️ Image ${index + 1}: ${image.filename}`);
                    console.log(`   URL: ${image.url}`);
                    console.log(`   Expected format: https://objectstorage.ap-mumbai-1.oraclecloud.com/n/bmexgnkisxsv/b/bucket_dev_dpa_mis_automation/o/new-at-dpa%2F${image.filename}`);
                });
                
                // Remove duplicates based on filename to prevent key conflicts
                const uniqueImages = imagesData.filter((image, index, self) => 
                    index === self.findIndex(img => img.filename === image.filename)
                );
                
                console.log(`📊 Loaded ${imagesData.length} images, ${uniqueImages.length} unique`);
                console.log('Unique images with properly encoded URLs:', uniqueImages);
                setImages(uniqueImages);
            } else {
                const errorData = await response.json();
                setError(errorData.error || 'Failed to load images');
            }
        } catch (error) {
            console.error('Error loading images:', error);
            setError('Failed to load images');
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (event, newValue) => {
        console.log('🔄 handleChange called:', {
            newValue,
            hasOnChange: !!onChange,
            eventType: event?.type
        });
        
        if (onChange) {
            console.log('📞 Calling onChange with:', newValue);
            onChange(newValue);
        }
    };

    const getOptionLabel = (option) => {
        if (typeof option === 'string') {
            return option;
        }
        return option?.filename || option?.originalName || '';
    };

    const isOptionEqualToValue = (option, value) => {
        if (typeof option === 'string' && typeof value === 'string') {
            return option === value;
        }
        // If value is a URL string, try to match with option's URL
        if (typeof value === 'string' && option?.url) {
            return option.url === value || option.url.includes(value) || value.includes(option.url);
        }
        // If option is a URL string, try to match with value's URL
        if (typeof option === 'string' && value?.url) {
            return value.url === option || value.url.includes(option) || option.includes(value.url);
        }
        // Compare by filename, URL, or object reference
        if (option?.filename && value?.filename) {
            return option.filename === value.filename;
        }
        if (option?.url && value?.url) {
            return option.url === value.url;
        }
        return option === value;
    };

    // Find matching image object from URL string
    const findImageByUrl = (urlString) => {
        if (!urlString || typeof urlString !== 'string') return null;
        return images.find(img => 
            img.url === urlString || 
            img.url.includes(urlString) || 
            urlString.includes(img.url) ||
            img.url.includes(encodeURIComponent(urlString))
        );
    };

    // Get the actual value to use - convert URL string to image object if needed
    const getActualValue = () => {
        if (!value) return null;
        if (typeof value === 'object') return value;
        if (typeof value === 'string') {
            const matchedImage = findImageByUrl(value);
            return matchedImage || value; // Return matched image or keep as string
        }
        return value;
    };

    const renderOption = (props, option, index) => {
        const { key, ...otherProps } = props;
        // Create a unique key using filename and index to handle duplicates
        const uniqueKey = `${option.filename}-${index}`;
        return (
            <Box component="li" key={uniqueKey} {...otherProps} sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <ImageIcon sx={{ fontSize: 20, color: 'text.secondary' }} />
                <Box sx={{ flex: 1 }}>
                    <Typography variant="h6" sx={{ fontWeight: 'medium' }}>
                        {option.filename}
                    </Typography>
                    {option.originalName !== option.filename && (
                        <Typography variant="h6" color="text.secondary">
                            {option.originalName}
                        </Typography>
                    )}
                </Box>
                {/* <Chip 
                label={option.filename.split('.').pop().toUpperCase()} 
                size="small" 
                variant="outlined"
            /> */}
            </Box>
        );
    };

    const renderInput = (params) => (
        <TextField
            {...params}
            label={label}
            placeholder={error ? 'Failed to load images' : placeholder}
            error={!!error || !!propError}
            helperText={error || propError || helperText || (images.length === 0 && !loading ? 'No images available' : '')}
            disabled={disabled}
            InputProps={{
                ...params.InputProps,
                endAdornment: (
                    <>
                        {loading ? <CircularProgress color="inherit" size={20} /> : null}
                        {params.InputProps.endAdornment}
                    </>
                ),
            }}
        />
    );

    // Show preview if enabled and value is selected
    const renderPreview = () => {
        if (!showPreview || !value) return null;

        const selectedImage = multiple ? value[0] : value;
        if (!selectedImage?.url) {
            console.log('No URL found for selected image:', selectedImage);
            return null;
        }

        console.log('Rendering preview for image:', selectedImage);

        return (
            <Box sx={{ mt: 2, p: 2, border: '1px solid #e0e0e0', borderRadius: 1, bgcolor: '#fafafa' }}>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Preview:
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <SafeImage
                        src={selectedImage.url}
                        alt={selectedImage.filename}
                        style={{
                            width: 60,
                            height: 60,
                            objectFit: 'cover',
                            borderRadius: '4px'
                        }}
                        onError={(e) => {
                            console.error('Image failed to load:', selectedImage.url);
                        }}
                        onLoad={() => {
                            console.log('Image loaded successfully:', selectedImage.url);
                        }}
                    />
                    <Box>
                        <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                            {selectedImage.filename}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                            {selectedImage.originalName}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                            URL: {selectedImage.url}
                        </Typography>
                    </Box>
                </Box>
            </Box>
        );
    };

    const actualValue = getActualValue();

    return (
        <Box>
            <Autocomplete
                value={actualValue}
                onChange={handleChange}
                options={images}
                getOptionLabel={getOptionLabel}
                isOptionEqualToValue={isOptionEqualToValue}
                renderOption={renderOption}
                renderInput={renderInput}
                loading={loading}
                disabled={disabled}
                multiple={multiple}
                clearOnBlur
                selectOnFocus
                handleHomeEndKeys
                fullWidth
            />
            {renderPreview()}
            {images.length === 0 && !loading && !error && (
                <Alert severity="info" sx={{ mt: 1 }}>
                    No images available. Please upload images first.
                </Alert>
            )}
        </Box>
    );
};

export default WhatsNewDPAImageSelector;
