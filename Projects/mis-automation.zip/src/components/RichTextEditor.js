import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Box,
  TextField,
  IconButton,
  Tooltip,
  Paper,
  Typography,
  Divider,
  Button,
  Stack,
  ButtonGroup
} from '@mui/material';
import {
  FormatBold,
  FormatItalic,
  FormatUnderlined,
  FormatStrikethrough,
  Link,
  FormatColorText,
  Palette,
  FormatListBulleted
} from '@mui/icons-material';

const RichTextEditor = ({
  value = '',
  onChange,
  label = 'Text Content',
  multiline = true,
  rows = 4,
  disabled = false,
  placeholder = 'Enter text...',
  themeColors = ['#1930ab', '#fa7604', '#4CAF50', '#f44336', '#9c27b0', '#ff9800']
}) => {
  const textFieldRef = useRef(null);
  const [history, setHistory] = useState([value]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const debounceTimeoutRef = useRef(null);
  const isUndoRedoRef = useRef(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const colorPickerRef = useRef(null);

  // Initialize history when value changes externally
  useEffect(() => {
    if (value !== history[historyIndex] && !isUndoRedoRef.current) {
      setHistory([value]);
      setHistoryIndex(0);
    }
    isUndoRedoRef.current = false;
  }, [value, history, historyIndex]);

  // Formatting functions
  const applyFormatting = (format, openTag, closeTag) => {
    if (!textFieldRef.current) return;

    const textField = textFieldRef.current.querySelector('textarea');
    if (!textField) return;

    const start = textField.selectionStart;
    const end = textField.selectionEnd;
    const selectedText = value.substring(start, end);

    let newText;
    if (selectedText) {
      // If text is selected, wrap it with formatting
      newText = value.substring(0, start) + openTag + selectedText + closeTag + value.substring(end);
    } else {
      // If no text selected, insert formatting tags at cursor position
      newText = value.substring(0, start) + openTag + closeTag + value.substring(start);
    }

    onChange(newText);

    // Add to history immediately for formatting actions
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newText);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    // Restore cursor position
    setTimeout(() => {
      const newCursorPos = selectedText ? start + openTag.length + selectedText.length + closeTag.length : start + openTag.length;
      textField.setSelectionRange(newCursorPos, newCursorPos);
      textField.focus();
    }, 0);
  };

  const formatBold = () => applyFormatting('bold', '**', '**');
  const formatItalic = () => applyFormatting('italic', '*', '*');
  const formatUnderline = () => applyFormatting('underline', '__', '__');
  const formatStrikethrough = () => applyFormatting('strikethrough', '~~', '~~');
  const formatBulletPoints = () => {
    if (!textFieldRef.current) return;

    const textField = textFieldRef.current.querySelector('textarea');
    if (!textField) return;

    const start = textField.selectionStart;
    const end = textField.selectionEnd;
    const selectedText = value.substring(start, end);

    let newText;
    if (selectedText) {
      // If text is selected, convert it to a bullet point list
      const lines = selectedText.split('\n');
      const bulletLines = lines.map(line => line.trim() ? `• ${line.trim()}` : '').join('\n');
      newText = value.substring(0, start) + bulletLines + value.substring(end);
    } else {
      // If no text selected, insert a bullet point at cursor position
      newText = value.substring(0, start) + '• ' + value.substring(start);
    }

    onChange(newText);

    // Add to history immediately for formatting actions
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newText);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    setTimeout(() => {
      const newCursorPos = selectedText ? start + selectedText.length + (selectedText.split('\n').length * 2) : start + 2;
      textField.setSelectionRange(newCursorPos, newCursorPos);
      textField.focus();
    }, 0);
  };
  const formatLink = () => {
    if (!textFieldRef.current) return;

    const textField = textFieldRef.current.querySelector('textarea');
    if (!textField) return;

    const start = textField.selectionStart;
    const end = textField.selectionEnd;
    const selectedText = value.substring(start, end);

    let newText;
    if (selectedText) {
      newText = value.substring(0, start) + `[${selectedText}](url)` + value.substring(end);
    } else {
      newText = value.substring(0, start) + '[link text](url)' + value.substring(start);
    }

    onChange(newText);

    // Add to history immediately for formatting actions
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newText);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    setTimeout(() => {
      const newCursorPos = selectedText ? start + selectedText.length + 3 : start + 11;
      textField.setSelectionRange(newCursorPos, newCursorPos);
      textField.focus();
    }, 0);
  };

  const formatColor = (color) => {
    if (!textFieldRef.current) return;

    const textField = textFieldRef.current.querySelector('textarea');
    if (!textField) return;

    const start = textField.selectionStart;
    const end = textField.selectionEnd;
    const selectedText = value.substring(start, end);

    let newText;
    if (selectedText) {
      // Wrap selected text with short color markdown syntax
      newText = value.substring(0, start) + `[c:${color}]${selectedText}[/c]` + value.substring(end);
    } else {
      // Insert color markdown at cursor position
      newText = value.substring(0, start) + `[c:${color}]text[/c]` + value.substring(start);
    }

    onChange(newText);

    // Add to history immediately for formatting actions
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newText);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    // Close color picker
    setShowColorPicker(false);

    setTimeout(() => {
      const newCursorPos = selectedText ? start + 15 + selectedText.length : start + 15;
      textField.setSelectionRange(newCursorPos, newCursorPos);
      textField.focus();
    }, 0);
  };

  // Debounced add to history
  const addToHistory = useCallback((newValue) => {
    // Clear existing timeout
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }

    // Set new timeout to add to history after 500ms of inactivity
    debounceTimeoutRef.current = setTimeout(() => {
      if (newValue !== history[historyIndex]) {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newValue);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
      }
    }, 500);
  }, [history, historyIndex]);

  // Undo function
  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      isUndoRedoRef.current = true;
      setHistoryIndex(newIndex);
      onChange(history[newIndex]);
    }
  }, [historyIndex, history, onChange]);

  // Redo function
  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      isUndoRedoRef.current = true;
      setHistoryIndex(newIndex);
      onChange(history[newIndex]);
    }
  }, [historyIndex, history, onChange]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, []);

  // Click outside handler for color picker
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (colorPickerRef.current && !colorPickerRef.current.contains(event.target)) {
        setShowColorPicker(false);
      }
    };

    if (showColorPicker) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showColorPicker]);

  const handleTextChange = (e) => {
    const newValue = e.target.value;
    onChange(newValue);
    addToHistory(newValue);
  };

  const handleKeyDown = (e) => {
    // Handle keyboard shortcuts
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case 'b':
          e.preventDefault();
          formatBold();
          break;
        case 'i':
          e.preventDefault();
          formatItalic();
          break;
        case 'u':
          e.preventDefault();
          formatUnderline();
          break;
        case 'k':
          e.preventDefault();
          formatLink();
          break;
        case 'l':
          e.preventDefault();
          formatBulletPoints();
          break;
        case 'z':
          e.preventDefault();
          if (e.shiftKey) {
            redo();
          } else {
            undo();
          }
          break;
        case 'y':
          e.preventDefault();
          redo();
          break;
        default:
          break;
      }
    }
  };


  return (
    <Box>
      {/* Toolbar */}
      <Box sx={{ position: 'relative' }}>
        <Stack direction={"row"} spacing={1} sx={{ border: '2px solid #d9d9d9', marginBottom: '15px', padding: "4px 12px", borderRadius: '6px', overflow: 'auto' }}>
        <ButtonGroup size="small" variant="outlined">
          <Tooltip title="Bold (Ctrl+B)">
            <IconButton onClick={formatBold} size="small">
              <FormatBold fontSize='small' />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          <Tooltip title="Italic (Ctrl+I)">
            <IconButton onClick={formatItalic} size="small">
              <FormatItalic fontSize='small' />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          <Tooltip title="Underline (Ctrl+U)">
            <IconButton onClick={formatUnderline} size="small">
              <FormatUnderlined fontSize='small' />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          <Tooltip title="Strikethrough">
            <IconButton onClick={formatStrikethrough} size="small">
              <FormatStrikethrough fontSize='small' />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          <Tooltip title="Bullet Points (Ctrl+L)">
            <IconButton onClick={formatBulletPoints} size="small">
              <FormatListBulleted fontSize='small' />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          <Tooltip title="Link (Ctrl+K)">
            <IconButton onClick={formatLink} size="small">
              <Link fontSize='small' />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          <Tooltip title="Text Color">
            <IconButton 
              onClick={() => setShowColorPicker(!showColorPicker)} 
              size="small"
              sx={{ 
                bgcolor: showColorPicker ? 'primary.light' : 'transparent',
                color: showColorPicker ? 'primary.contrastText' : 'inherit'
              }}
            >
              <FormatColorText fontSize='small' />
            </IconButton>
          </Tooltip>
        </ButtonGroup>

        {/* Color Picker */}
        {showColorPicker && (
          <Box
            ref={colorPickerRef}
            sx={{
              position: 'absolute',
              top: '100%',
              left: 0,
              zIndex: 1000,
              bgcolor: 'white',
              border: '1px solid #ccc',
              borderRadius: 1,
              p: 1,
              boxShadow: 3,
              display: 'flex',
              gap: 1,
              flexWrap: 'wrap',
              maxWidth: 200,
              mt: 1
            }}
          >
            {themeColors.map((color, index) => (
              <Tooltip key={index} title={`Color ${index + 1}`}>
                <Box
                  onClick={() => formatColor(color)}
                  sx={{
                    width: 24,
                    height: 24,
                    bgcolor: color,
                    borderRadius: '50%',
                    cursor: 'pointer',
                    border: '2px solid #fff',
                    boxShadow: '0 0 0 1px #ccc',
                    '&:hover': {
                      transform: 'scale(1.1)',
                      boxShadow: '0 0 0 2px #1976d2'
                    },
                    transition: 'all 0.2s ease'
                  }}
                />
              </Tooltip>
            ))}
          </Box>
        )}
        </Stack>
      </Box>

      {/* Editor */}
      <Box className="textfield sm auto-complete">
        <TextField
          ref={textFieldRef}
          fullWidth
          multiline={multiline}
          rows={rows}
          label={label}
          value={value}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          placeholder={placeholder}
          variant="outlined"
          sx={{
            '& .MuiOutlinedInput-root': {
              fontFamily: 'monospace',
              fontSize: '14px'
            }
          }}
        />
      </Box>

    </Box>
  );
};

export default RichTextEditor;
