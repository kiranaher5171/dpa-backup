import React from 'react';
import { markdownToHtml } from '../utils/markdownToHtml';

/**
 * Component to render markdown content as HTML preview
 * This shows the HTML tags that would be generated from markdown
 */
const HtmlPreviewRenderer = ({ 
  content = '', 
  className = '',
  style = {}
}) => {
  if (!content) return null;

  // Use the centralized markdown conversion utility
  const htmlContent = markdownToHtml(content, true); // true = wrap in paragraphs for proper line break handling

  return (
    <div 
      className={className} 
      style={style}
      dangerouslySetInnerHTML={{ __html: htmlContent }}
    />
  );
};

export default HtmlPreviewRenderer;
