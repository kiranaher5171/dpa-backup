import React from 'react';
import { Box, Typography, Paper, IconButton } from '@mui/material';
import { useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Add, DragIndicator, Edit, Delete, DragHandle, ContentCopy } from '@mui/icons-material';
import HtmlPreviewRenderer from './HtmlPreviewRenderer';
import SuggestionChip from './SuggestionChip';
import { getNextSuggestion, shouldShowSuggestion, createElementFromSuggestion } from '../utils/suggestionLogic';
import { markdownToHtml } from '../utils/markdownToHtml';

// Drop Zone Component for inserting elements between existing elements
const DropZone = ({ index, onInsertElement, isOver }) => {
  const { setNodeRef, isOver: isOverThisZone } = useDroppable({
    id: `drop-zone-${index}`,
    data: {
      isDropZone: true,
      insertIndex: index
    }
  });

  return (
    <Box
      ref={setNodeRef}
      sx={{
        height: isOverThisZone || isOver ? 8 : 4,
        bgcolor: isOverThisZone || isOver ? 'primary.main' : 'transparent',
        borderRadius: 1,
        transition: 'all 0.2s ease',
        my: 1,
        mx: 2,
        opacity: isOverThisZone || isOver ? 1 : 0.3,
        '&:hover': {
          height: 8,
          bgcolor: 'primary.light',
          opacity: 1
        }
      }}
    />
  );
};

// Sortable Element Component
const SortableElement = ({ 
  element, 
  onSelect, 
  onEdit, 
  onDelete, 
  onCopy, 
  isSelected, 
  primaryColor,
  suggestion,
  onApplySuggestion,
  onDismissSuggestion,
  onIgnoreSuggestion
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: element.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <Box
      ref={setNodeRef}
      style={style}
      sx={{
        position: 'relative',
        mb: 2,
        '&:hover': {
          '& .element-actions': {
            opacity: 1,
          },
        },
      }}
    >
      {/* Element Actions */}
      <Box
        className="element-actions"
        sx={{
          position: 'absolute',
          top: -8,
          right: -8,
          display: 'flex',
          gap: 0.5,
          opacity: isSelected ? 1 : 0,
          transition: 'opacity 0.2s ease',
          zIndex: 10,
          bgcolor: 'background.paper',
          borderRadius: 1,
          boxShadow: 2,
          p: 0.5
        }}
      >
        <IconButton
          size="small"
          {...listeners}
          {...attributes}
          sx={{ color: 'primary.main', cursor: 'grab' }}
        >
          <DragHandle fontSize="small" />
        </IconButton>
        <IconButton
          size="small"
          onClick={() => onEdit(element.id)}
          sx={{ color: 'primary.main' }}
        >
          <Edit fontSize="small" />
        </IconButton>
        <IconButton
          size="small"
          onClick={() => onCopy(element.id)}
          sx={{ color: 'secondary.main' }}
          title="Copy Element"
        >
          <ContentCopy fontSize="small" />
        </IconButton>
        <IconButton
          size="small"
          onClick={() => onDelete(element.id)}
          sx={{ color: 'error.main' }}
        >
          <Delete fontSize="small" />
        </IconButton>
      </Box>

      {/* Element Content */}
      <Paper
        sx={{
          p: 1,
          border: isSelected ? '2px solid #1976d2' : '1px solid transparent',
          borderRadius: 1,
          cursor: 'pointer',
          transition: 'all 0.2s ease',
          '&:hover': {
            borderColor: isSelected ? '#1976d2' : '#e0e0e0',
            boxShadow: 2
          }
        }}
        onClick={() => onSelect(element.id)}
      >
        {renderElementPreview(element, primaryColor)}
      </Paper>

      {/* Suggestion Chip */}
      {suggestion && (
        <SuggestionChip
          suggestion={suggestion}
          onApply={onApplySuggestion}
          onDismiss={onDismissSuggestion}
          onIgnore={onIgnoreSuggestion}
          position="below"
        />
      )}
    </Box>
  );
};

const DesignCanvas = ({
  elements,
  onElementsChange,
  onAddElement,
  selectedElementId,
  onSelectElement,
  primaryColor,
  showGrid = true,
  zoom = 100,
  documentData,
  loadingData = false,
  hasParsedElements = false,
  elementsLoadedFromDatabase = false
}) => {
  const { setNodeRef, isOver } = useDroppable({
    id: 'canvas',
  });

  // Suggestion state management
  const [suggestions, setSuggestions] = React.useState({});
  const [dismissedSuggestions, setDismissedSuggestions] = React.useState(new Set());
  const [ignoredSuggestions, setIgnoredSuggestions] = React.useState(new Set());

  // Add cleanup effect for component unmount
  React.useEffect(() => {
    return () => {
      console.log('🎨 DesignCanvas: Component unmounting, cleaning up...');
      // Any cleanup logic can be added here if needed
    };
  }, []);

  // Update suggestions when elements change
  React.useEffect(() => {
    console.log('🔄 Updating suggestions for elements:', elements.length);
    const newSuggestions = {};
    
    elements.forEach((element, index) => {
      const elementId = element.id;
      
      // Skip if suggestion was dismissed for this element
      if (dismissedSuggestions.has(elementId)) {
        console.log('⏭️ Skipping dismissed element:', elementId);
        return;
      }

      // Check if we should show a suggestion for this element
      if (shouldShowSuggestion(element, elements, index, ignoredSuggestions)) {
        const suggestion = getNextSuggestion(element, elements, index);
        if (suggestion) {
          console.log('💡 Adding suggestion for element:', elementId, suggestion);
          newSuggestions[elementId] = suggestion;
        }
      }
    });

    console.log('📋 Final suggestions:', newSuggestions);
    setSuggestions(newSuggestions);
  }, [elements, dismissedSuggestions, ignoredSuggestions]);

  const handleElementEdit = (elementId) => {
    const element = elements.find(el => el.id === elementId);
    if (element) {
      onElementsChange({
        type: 'EDIT',
        element
      });
    }
  };

  const handleElementDelete = (elementId) => {
    onElementsChange({
      type: 'DELETE',
      id: elementId
    });
  };

  const handleElementCopy = (elementId) => {
    const elementToCopy = elements.find(el => el.id === elementId);
    if (elementToCopy) {
      // Create a new element with all the same properties but a new ID
      const newElement = {
        ...elementToCopy,
        id: `element_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      };
      
      // Find the index of the current element
      const currentIndex = elements.findIndex(el => el.id === elementId);
      
      onElementsChange({
        type: 'COPY',
        element: newElement,
        insertAfterIndex: currentIndex
      });
    }
  };

  const handleElementSelect = (elementId) => {
    onSelectElement(elementId);
  };

  // Suggestion handlers
  const handleApplySuggestion = (elementId, suggestion) => {
    console.log('🎯 Applying suggestion:', suggestion, 'for element:', elementId);
    
    const newElement = createElementFromSuggestion(suggestion, primaryColor);
    console.log('🆕 Created new element:', newElement);
    
    if (newElement) {
      // Find the index of the current element
      const currentIndex = elements.findIndex(el => el.id === elementId);
      console.log('📍 Current element index:', currentIndex);
      
      // Add the new element after the current one
      onElementsChange({
        type: 'INSERT',
        element: newElement,
        insertAfterIndex: currentIndex
      });

      // Remove the suggestion for this element
      setSuggestions(prev => {
        const newSuggestions = { ...prev };
        delete newSuggestions[elementId];
        return newSuggestions;
      });
      
      console.log('✅ Suggestion applied successfully');
    } else {
      console.error('❌ Failed to create element from suggestion');
    }
  };

  const handleDismissSuggestion = (elementId) => {
    // Add to dismissed suggestions
    setDismissedSuggestions(prev => new Set([...prev, elementId]));
    
    // Remove the suggestion
    setSuggestions(prev => {
      const newSuggestions = { ...prev };
      delete newSuggestions[elementId];
      return newSuggestions;
    });
    
    console.log('❌ Suggestion dismissed for element:', elementId);
  };

  const handleIgnoreSuggestion = (elementId, suggestion) => {
    console.log('🚫 Ignoring suggestion for element:', elementId, suggestion);
    
    // Create a unique key for this element type and suggestion type combination
    const ignoreKey = `${elementId}-${suggestion.type}`;
    
    // Add to ignored suggestions
    setIgnoredSuggestions(prev => new Set([...prev, ignoreKey]));
    
    // Remove the suggestion
    setSuggestions(prev => {
      const newSuggestions = { ...prev };
      delete newSuggestions[elementId];
      return newSuggestions;
    });
    
    console.log('🚫 Suggestion ignored permanently for element type:', suggestion.type);
  };

  // Determine if we should show loading state
  const showLoadingState = loadingData || (!hasParsedElements && documentData?.HTML_TEMPLATE && elements.length === 0 && !elementsLoadedFromDatabase);

  // Debug logging for loading state
  console.log('🎨 DesignCanvas - loadingData:', loadingData, 'hasParsedElements:', hasParsedElements, 'elements.length:', elements.length, 'elementsLoadedFromDatabase:', elementsLoadedFromDatabase, 'showLoadingState:', showLoadingState);

  // Determine if we should show empty state
  const showEmptyState = !loadingData && hasParsedElements && elements.length === 0 && !isOver;

  return (
    <Box
      ref={setNodeRef}
      sx={{
        width: '100%',
        maxWidth: 800,
        margin: '0 auto',
        transform: `scale(${zoom / 100})`,
        transformOrigin: 'top center',
        bgcolor: 'white',
        minHeight: '100vh',
        // height: 'calc(100vh - 210px)',
        overflow: 'auto',
        p: 3,
        border: '1px solid #e0e0e0',
        borderRadius: 1,
        position: 'relative',
        transition: 'all 0.2s ease',
        '&:hover': {
          borderColor: isOver ? 'primary.main' : '#e0e0e0'
        }
      }}
    >
      {/* Grid Background */}
      {showGrid && (
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: `
              linear-gradient(rgba(0,0,0,0.05) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0,0,0,0.05) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px',
            pointerEvents: 'none',
            zIndex: 0
          }}
        />
      )}

      {/* Drop Zone Indicator */}
      {isOver && elements.length === 0 && !showLoadingState && (
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            zIndex: 10,
            textAlign: 'center',
            color: 'primary.main'
          }}
        >
          <DragIndicator sx={{ fontSize: 48, mb: 2 }} />
          <Typography variant="h6">Drop elements here</Typography>
        </Box>
      )}

      {/* Loading State */}
      {showLoadingState && (
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            zIndex: 10,
            textAlign: 'center',
            color: 'text.secondary'
          }}
        >
          <Typography variant="h6" sx={{ mb: 1 }}>
            {loadingData ? 'Loading document...' : 'Loading template content...'}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {loadingData ? 'Please wait while we fetch your document' : 'Parsing existing elements from template'}
          </Typography>
        </Box>
      )}

      {/* Empty State */}
      {showEmptyState && (
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: 400,
            color: 'text.secondary',
            textAlign: 'center'
          }}
        >
          <Typography variant="h6" sx={{ mb: 2 }}>
            Start building your document
          </Typography>
          <Typography variant="body2" sx={{ mb: 3 }}>
            Drag elements from the toolbox to begin
          </Typography>
          <Paper
            sx={{
              p: 3,
              border: '2px dashed #ccc',
              borderRadius: 2,
              bgcolor: 'transparent',
              '&:hover': {
                borderColor: 'primary.main',
                bgcolor: 'action.hover'
              }
            }}
          >
            <Typography variant="body2">
              Drop zone for new elements
            </Typography>
          </Paper>
        </Box>
      )}

      {/* Elements Container */}
      <Box sx={{ position: 'relative', zIndex: 1 }}>
        {elements.length > 0 ? (
          <SortableContext items={elements} strategy={verticalListSortingStrategy}>
            {elements.map((element, index) => (
              <React.Fragment key={`fragment-${element.id}`}>
                {/* Drop zone before each element */}
                <DropZone 
                  index={index} 
                  onInsertElement={onAddElement}
                  isOver={isOver}
                />
                <SortableElement
                  key={element.id}
                  element={element}
                  onSelect={handleElementSelect}
                  onEdit={handleElementEdit}
                  onDelete={handleElementDelete}
                  onCopy={handleElementCopy}
                  isSelected={selectedElementId === element.id}
                  primaryColor={primaryColor}
                  suggestion={suggestions[element.id]}
                  onApplySuggestion={(suggestion) => handleApplySuggestion(element.id, suggestion)}
                  onDismissSuggestion={() => handleDismissSuggestion(element.id)}
                  onIgnoreSuggestion={(suggestion) => handleIgnoreSuggestion(element.id, suggestion)}
                />
              </React.Fragment>
            ))}
            {/* Drop zone after the last element */}
            <DropZone 
              index={elements.length} 
              onInsertElement={onAddElement}
              isOver={isOver}
            />
          </SortableContext>
        ) : (
          /* Drop zone for empty canvas */
          <DropZone 
            index={0} 
            onInsertElement={onAddElement}
            isOver={isOver}
          />
        )}
      </Box>
    </Box>
  );
};

// Element Preview Renderer
const renderElementPreview = (element, primaryColor) => {
  switch (element.type) {
    case 'main-heading':
      return (
        <Box
          sx={{
            p: 1,
            bgcolor: primaryColor,
            color: 'white',
            textAlign: 'center',
            fontSize: element.fontSize || 24,
            fontWeight: 'bold',
            borderRadius: 1,
            textAlign: element.textAlign || 'center'
          }}
        >
          <HtmlPreviewRenderer 
            content={element.value || 'Main Heading'}
            style={{ color: 'white' }}
          />
        </Box>
      );

    case 'section-heading':
      return (
        <Box
          sx={{
            p: 1,
            borderLeft: `4px solid ${primaryColor}`,
            fontSize: element.fontSize || 20,
            fontWeight: 'bold',
            textAlign: element.textAlign || 'left'
          }}
        >
          <HtmlPreviewRenderer 
            content={element.value || 'Section Heading'}
          />
        </Box>
      );

    case 'sub-heading':
      return (
        <Box
          sx={{
            p: 1,
            fontSize: element.fontSize || 18,
            fontWeight: 600,
            color: element.textColor || '#333333',
            textAlign: element.textAlign || 'left'
          }}
        >
          {element.value || 'Sub Heading'}
        </Box>
      );

    case 'highlighted-heading':
      return (
        <Box
          sx={{
            p: 1,
            bgcolor: element.backgroundColor || '#d2d2d2',
            color: element.textColor || '#000',
            fontSize: element.fontSize || 20,
            fontWeight: 'bold',
            textAlign: element.textAlign || 'left',
            borderRadius: 1,
            border: '1px solid #e0e0e0'
          }}
        >
          <HtmlPreviewRenderer 
            content={element.value || 'Highlighted Heading'}
            style={{ margin: 0 }}
          />
        </Box>
      );

    case 'description':
      return (
        <Box
          sx={{
            p: 1,
            fontSize: element.fontSize || 16,
            lineHeight: 1.6,
            textAlign: element.textAlign || 'justify',
            color: element.textColor || '#333333'
          }}
        >
          <HtmlPreviewRenderer 
            content={element.value || 'Description text goes here...'}
          />
        </Box>
      );

    case 'simple-text':
      return (
        <Box
          sx={{
            p: 1,
            fontSize: element.fontSize || 16,
            lineHeight: 1.6,
            textAlign: element.textAlign || 'justify',
            color: element.textColor || '#333333'
          }}
        >
          <HtmlPreviewRenderer 
            content={element.value || 'Description text goes here...'}
          />
        </Box>
      );

    case 'bullet-points':
      const points = element.value ? element.value.split('\n').filter(point => point.trim()) : ['Bullet point 1', 'Bullet point 2'];
      return (
        <Box sx={{ p: 1 }}>
          {points.map((point, index) => (
            <Box
              key={index}
              sx={{
                display: 'flex',
                alignItems: 'flex-start',
                mb: 1,
                fontSize: element.fontSize || 16,
                lineHeight: 1.5,
                color: element.textColor || '#333333'
              }}
            >
              <Box
                sx={{
                  color: element.bulletColor || primaryColor,
                  mr: 1,
                  mt: 0.5,
                  fontSize: '1.2em',
                  flexShrink: 0
                }}
              >
                •
              </Box>
              <Box sx={{ flex: 1 }}>
                <HtmlPreviewRenderer content={point.trim()} />
              </Box>
            </Box>
          ))}
        </Box>
      );

    case 'small-text':
      return (
        <Box
          sx={{
            p: 1,
            fontSize: element.fontSize || 14,
            color: element.textColor || '#666666',
            textAlign: element.textAlign || 'left',
            fontStyle: element.italic ? 'italic' : 'normal'
          }}
        >
          {element.value || 'Small text content...'}
        </Box>
      );

    case 'quote':
      return (
        <Box
          sx={{
            p: 1,
            borderLeft: `3px solid ${element.borderColor || primaryColor}`,
            bgcolor: element.backgroundColor || '#f8f9fa',
            fontStyle: 'italic',
            fontSize: element.fontSize || 16,
            lineHeight: 1.6,
            color: element.textColor || '#333333'
          }}
        >
          "{element.value || 'Quote text goes here...'}"
          {element.author && (
            <Box sx={{ mt: 1, textAlign: 'right', fontSize: 14, color: '#666' }}>
              — {element.author}
            </Box>
          )}
        </Box>
      );

    case 'highlight-box':
      return (
        <Box
          sx={{
            p: 1,
            bgcolor: element.backgroundColor || '#fff3cd',
            borderLeft: `4px solid ${element.borderColor || '#ffc107'}`,
            borderRadius: 1,
            fontSize: element.fontSize || 16,
            lineHeight: 1.6,
            color: element.textColor || '#856404'
          }}
        >
          {element.value || 'Highlighted content goes here...'}
        </Box>
      );

    case 'divider':
      return (
        <Box
          sx={{
            p: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <Box
            sx={{
              height: element.thickness || 1,
              bgcolor: element.color || '#e0e0e0',
              width: '100%',
              // my: element.margin || 1
            }}
          />
        </Box>
      );

    case 'spacing':
      return (
        <Box
          sx={{
            height: `${element.value || 20}px`,
            bgcolor: '#f0f0f0',
            border: '1px dashed #ccc',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <Typography variant="caption" color="textSecondary">
            {element.value || 20}px spacing
          </Typography>
        </Box>
      );

    case 'image':
      return (
        <Box sx={{ p: 1 }}>
          {element.value ? (
            <img
              src={element.value}
              alt="Content"
              style={{
                maxWidth: '100%',
                height: 'auto',
                borderRadius: '4px'
              }}
            />
          ) : (
            <Box
              sx={{
                height: 200,
                bgcolor: '#f0f0f0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '2px dashed #ccc',
                borderRadius: 1
              }}
            >
              <Typography color="textSecondary">
                Click to add image
              </Typography>
            </Box>
          )}
        </Box>
      );

    case 'executive-summary':
      // Parse the executive summary data
      let content;
      try {
        if (element.value && typeof element.value === 'string') {
          if (element.value.trim().startsWith('{')) {
            content = JSON.parse(element.value);
          } else {
            content = {
              "headings": {
                "operational-strengths": "OPERATIONAL STRENGTHS",
                "strategic-achievements": "STRATEGIC ACHIEVEMENTS", 
                "risk-mitigation": "RISK MITIGATION",
                "operational-highlights": "OPERATIONAL HIGHLIGHTS"
              },
              "operational-strengths": [],
              "strategic-achievements": [],
              "risk-mitigation": [],
              "operational-highlights": []
            };
          }
        } else {
          content = {
            "headings": {
              "operational-strengths": "OPERATIONAL STRENGTHS",
              "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
              "risk-mitigation": "RISK MITIGATION", 
              "operational-highlights": "OPERATIONAL HIGHLIGHTS"
            },
            "operational-strengths": [],
            "strategic-achievements": [],
            "risk-mitigation": [],
            "operational-highlights": []
          };
        }
      } catch (e) {
        console.error('Error parsing executive summary in DesignCanvas:', e);
        content = {
          "headings": {
            "operational-strengths": "OPERATIONAL STRENGTHS",
            "strategic-achievements": "STRATEGIC ACHIEVEMENTS",
            "risk-mitigation": "RISK MITIGATION",
            "operational-highlights": "OPERATIONAL HIGHLIGHTS"
          },
          "operational-strengths": [],
          "strategic-achievements": [],
          "risk-mitigation": [],
          "operational-highlights": []
        };
      }

      const sectionConfigs = [
        {
          key: 'operational-strengths',
          title: (content.headings?.['operational-strengths'] || 'OPERATIONAL STRENGTHS').toUpperCase(),
          color: '#1930ab',
          bgColor: '#e6f0fe',
          borderColor: '#83cbeb'
        },
        {
          key: 'strategic-achievements',
          title: (content.headings?.['strategic-achievements'] || 'STRATEGIC ACHIEVEMENTS').toUpperCase(),
          color: '#1e693a',
          bgColor: '#e5fcec',
          borderColor: '#b4e5a2'
        },
        {
          key: 'risk-mitigation',
          title: (content.headings?.['risk-mitigation'] || 'RISK MITIGATION').toUpperCase(),
          color: '#8b0000',
          bgColor: '#fde8e8',
          borderColor: '#fca6a6'
        },
        {
          key: 'operational-highlights',
          title: (content.headings?.['operational-highlights'] || 'OPERATIONAL HIGHLIGHTS').toUpperCase(),
          color: '#fa7604',
          bgColor: '#fef0de',
          borderColor: '#ffca89'
        }
      ];

      return (
        <Box sx={{ p: 1 }}>
          <Typography
            variant="h6"
            sx={{
              mb: 2,
              fontSize: element.titleSize || 20,
              fontWeight: 'bold',
              color: element.titleColor || primaryColor,
              textAlign: 'center',
              bgcolor: '#1930ab',
              color: '#ffffff',
              py: 1,
              px: 2,
              borderRadius: 1
            }}
          >
            Executive Summary
          </Typography>

          {/* Preview of the four sections */}
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1, mt: 2 }}>
            {sectionConfigs.map((section) => {
              const sectionData = content[section.key] || [];
              const hasContent = sectionData.length > 0;

              return (
                <Box key={section.key} sx={{
                  bgcolor: section.bgColor,
                  border: `1px solid ${section.borderColor}`,
                  borderRadius: 1,
                  p: 1,
                  minHeight: 80
                }}>
                  <Typography variant="caption" sx={{
                    fontWeight: 'bold',
                    // color: section.color,
                    color: "#000",
                    display: 'block',
                    textAlign: 'center',
                    mb: 1
                  }}>
                    {section.title}
                  </Typography>
                  {hasContent ? (
                    <Box>
                      {sectionData.slice(0, 2).map((item, index) => (
                        <Box key={index} sx={{ mb: 0.5 }}>
                          <Typography variant="caption" sx={{
                            fontWeight: 'bold',
                            color: section.color,
                            fontSize: '10px'
                          }}>
                            {item.heading || 'Heading'}
                          </Typography>
                          {item.desc && item.desc[0] && (
                            <Typography variant="caption" color="textSecondary" sx={{
                              fontSize: '9px',
                              display: 'block',
                              lineHeight: 1.2
                            }}>
                              {item.desc[0].length > 30 ? item.desc[0].substring(0, 30) + '...' : item.desc[0]}
                            </Typography>
                          )}
                        </Box>
                      ))}
                      {sectionData.length > 2 && (
                        <Typography variant="caption" color="textSecondary" sx={{ fontSize: '9px' }}>
                          +{sectionData.length - 2} more...
                        </Typography>
                      )}
                    </Box>
                  ) : (
                    <Typography variant="caption" color="textSecondary">
                      No content yet
                    </Typography>
                  )}
                </Box>
              );
            })}
          </Box>

          <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 1, textAlign: 'center' }}>
            {Object.values(content).some(section => section.length > 0) ? 'Content updated' : 'Add content in properties'}
          </Typography>
        </Box>
      );

    case 'date-header':
      return (
        <Box
          sx={{
            p: 1,
            bgcolor: '#ffffff',
            border: '1px solid #e0e0e0',
            borderRadius: 1
          }}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography
              sx={{
                fontSize: 16,
                fontWeight: 'bold',
                textTransform: 'uppercase',
                letterSpacing: 2,
                color: '#3A3A3A'
              }}
            >
              {element.value || 'OCTOBER 2024'}
            </Typography>
            {element.logoUrl ? (
              <img
                src={element.logoUrl}
                alt="Logo"
                style={{
                  width: 40,
                  height: 40,
                  objectFit: 'contain',
                  borderRadius: 4
                }}
              />
            ) : (
              <Box sx={{ width: 40, height: 40, bgcolor: '#f0f0f0', borderRadius: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Typography variant="caption" color="textSecondary">Logo</Typography>
              </Box>
            )}
          </Box>
        </Box>
      );

    case 'banner-section':
      return (
        <Box sx={{ p: 1 }}>
          {element.value ? (
            <img
              src={element.value}
              alt="Banner"
              style={{
                width: '100%',
                height: 120,
                objectFit: 'cover',
                borderRadius: 4
              }}
            />
          ) : (
            <Box
              sx={{
                height: 120,
                bgcolor: '#f0f0f0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '2px dashed #ccc',
                borderRadius: 1
              }}
            >
              <Typography color="textSecondary">
                Banner Image
              </Typography>
            </Box>
          )}
        </Box>
      );

    case 'whats-new-dpa':
      console.log('Rendering whats-new-dpa element:', element);
      return (
        <Box sx={{ p: 1 }}>
          <Typography
            variant="h6"
            sx={{
              mb: 1,
              fontSize: element.titleSize || 20,
              fontWeight: 'bold',
              color: element.titleColor || primaryColor,
              textAlign: element.textAlign || 'center'
            }}
          >
            What's New in DPA
          </Typography>
          {element.value ? (
            <Box
              sx={{
                width: '100%',
                height: 150,
                borderRadius: 1,
                overflow: 'hidden',
                mb: 1
              }}
            >
              <img
                src={element.value}
                alt="What's New in DPA"
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  display: 'block'
                }}
                onError={(e) => {
                  console.error('Whats New DPA image failed to load:', element.value);
                  // Hide the broken image and show the fallback
                  e.target.style.display = 'none';
                  const fallbackElement = e.target.nextSibling;
                  if (fallbackElement) {
                    fallbackElement.style.display = 'flex';
                  }
                }}
                onLoad={() => {
                  console.log('Whats New DPA image loaded successfully:', element.value);
                }}
              />
              <Box
                sx={{
                  height: 150,
                  bgcolor: '#f0f0f0',
                  display: 'none',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '2px dashed #ccc',
                  borderRadius: 1
                }}
              >
                <Typography color="textSecondary">
                  Image not found
                </Typography>
              </Box>
            </Box>
          ) : (
            <Box
              sx={{
                height: 150,
                bgcolor: '#f0f0f0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '2px dashed #ccc',
                borderRadius: 1,
                mb: 1
              }}
            >
              <Typography color="textSecondary">
                What's New Image
              </Typography>
            </Box>
          )}
          {element.caption && (
            <Typography variant="caption" color="textSecondary" sx={{ textAlign: element.textAlign || 'center' }}>
              {element.caption}
            </Typography>
          )}
        </Box>
      );

    case 'disclaimer':
      return (
        <Box
          sx={{
            p: 1,
            bgcolor: '#ffffff',
            border: '1px solid #e0e0e0',
            borderRadius: 1
          }}
        >
          <Typography variant="h6" sx={{ mb: 1, fontWeight: 'bold', color: '#163E64' }}>
            Disclaimer
          </Typography>
          <Typography
            variant="body2"
            sx={{
              fontSize: 12,
              lineHeight: 1.4,
              color: '#163E64',
              textAlign: 'justify'
            }}
          >
            {element.value ? element.value.substring(0, 100) + '...' : 'Decimal Point Analytics Pvt Ltd does not make any recommendation...'}
          </Typography>
          <Box sx={{ mt: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box sx={{ width: 30, height: 20, bgcolor: '#f0f0f0', borderRadius: 0.5 }} />
            <Typography variant="caption" color="primary">
              www.decimalpointanalytics.com
            </Typography>
          </Box>
        </Box>
      );

    case 'news-section':
      // Parse the news data for preview
      let newsData;
      try {
        if (element.value && typeof element.value === 'string') {
          const trimmedValue = element.value.trim();
          if (trimmedValue.startsWith('[')) {
            const parsed = JSON.parse(trimmedValue);
            newsData = Array.isArray(parsed) ? parsed : [];
          } else {
            newsData = [];
          }
        } else if (Array.isArray(element.value)) {
          newsData = element.value;
        } else {
          newsData = [];
        }
      } catch (e) {
        console.error('Error parsing news data in DesignCanvas:', e);
        newsData = [];
      }

      // If no news data, provide default structure
      if (!Array.isArray(newsData) || newsData.length === 0) {
        newsData = [
          {
            title: "Sample News Title",
            date: "2024-01-15",
            link: "https://example.com/news1",
            heading: "Sample News Heading",
            description: "This is a sample news description that provides details about the news item."
          }
        ];
      }

      return (
        <Box sx={{ p: 1 }}>
          <Typography
            variant="h6"
            sx={{
              mb: 2,
              fontSize: element.titleSize || 20,
              fontWeight: 'bold',
              color: '#ffffff',
              textAlign: 'center',
              bgcolor: element.backgroundColor || primaryColor,
              py: 1,
              px: 2,
              borderRadius: 1
            }}
          >
            {element.sectionTitle || 'Latest News'}
          </Typography>

          <Box sx={{
            bgcolor: '#ffffff',
            border: `1px solid ${element.borderColor || '#e0e0e0'}`,
            borderRadius: 1,
            overflow: 'hidden'
          }}>
            {Array.isArray(newsData) && newsData.slice(0, 3).map((news, index) => (
              <Box
                key={index}
                sx={{
                  p: 1.5,
                  borderBottom: Array.isArray(newsData) && index < newsData.length - 1 ? `1px solid ${element.borderColor || '#e0e0e0'}` : 'none'
                }}
              >
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontSize: element.titleSize || 14,
                    fontWeight: 'bold',
                    color: element.titleColor || `${primaryColor}70`, // Primary color with 0.7 opacity (70 in hex)
                    mb: 0.5
                  }}
                >
                  {news.title || 'News Title'}
                </Typography>
                <Typography
                  variant="caption"
                  sx={{
                    fontSize: element.dateSize || 10,
                    color: element.dateColor || '#666666',
                    display: 'block',
                    mb: 0.5
                  }}
                >
                  {news.date || 'Date'}
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    fontSize: element.headingSize || 12,
                    fontWeight: 600,
                    color: element.headingColor || primaryColor, // Primary color with full opacity (1.0)
                    mb: 0.5
                  }}
                >
                  {news.heading || 'News Heading'}
                </Typography>
                <Box
                  sx={{
                    fontSize: element.descriptionSize || 10,
                    color: element.descriptionColor || '#555555',
                    lineHeight: 1.4,
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                    '& strong': { fontWeight: 'bold' },
                    '& em': { fontStyle: 'italic' },
                    '& u': { textDecoration: 'underline' },
                    '& del': { textDecoration: 'line-through' },
                    '& a': { color: '#1976d2', textDecoration: 'none' },
                    '& a:hover': { textDecoration: 'underline' },
                    '& ul': { margin: '0px !important', padding: '0px !important', paddingLeft: '14px !important' },
                    '& li': { margin: '2px 0', listStyleType: 'disc' }
                  }}
                  dangerouslySetInnerHTML={{
                    __html: news.description ? markdownToHtml(news.description, false) : 'News description goes here...'
                  }}
                />
              </Box>
            ))}
            {newsData.length > 3 && (
              <Box sx={{ p: 1, textAlign: 'center', bgcolor: '#f8f9fa' }}>
                <Typography variant="caption" color="textSecondary">
                  +{newsData.length - 3} more news items
                </Typography>
              </Box>
            )}
          </Box>

          <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 1, textAlign: 'center' }}>
            {Array.isArray(newsData) && newsData.length > 0 ? `${newsData.length} news item(s)` : 'Add news items in properties'}
          </Typography>
        </Box>
      );

    case 'list-items':
      // Parse the list items data for preview
      let listData;
      try {
        if (element.value && typeof element.value === 'string') {
          const trimmedValue = element.value.trim();
          if (trimmedValue.startsWith('[')) {
            const parsed = JSON.parse(trimmedValue);
            listData = Array.isArray(parsed) ? parsed : [];
          } else {
            listData = [];
          }
        } else if (Array.isArray(element.value)) {
          listData = element.value;
        } else {
          listData = [];
        }
      } catch (e) {
        console.error('Error parsing list items data in DesignCanvas:', e);
        listData = [];
      }

      // If no list data, provide default structure
      if (!Array.isArray(listData) || listData.length === 0) {
        listData = [
          {
            hasHeading: false,
            heading: "",
            content: ["Sample content 1", "Sample content 2"]
          }
        ];
      }

      return (
        <Box sx={{ p: 1 }}>
          <Typography
            variant="h6"
            sx={{
              mb: 2,
              fontSize: element.titleSize || 16,
              fontWeight: 'bold',
              color: '#333333',
              textAlign: 'left'
            }}
          >
            List Items
          </Typography>

          <Box sx={{
            bgcolor: '#ffffff',
            border: `1px solid ${element.borderColor || '#e0e0e0'}`,
            borderRadius: 1,
            overflow: 'hidden'
          }}>
            {Array.isArray(listData) && listData.slice(0, 3).map((item, index) => (
              <Box
                key={index}
                sx={{
                  p: 1.5,
                  borderBottom: Array.isArray(listData) && index < listData.length - 1 ? `1px solid ${element.borderColor || '#e0e0e0'}` : 'none'
                }}
              >
                {item.hasHeading && item.heading && (
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontSize: element.headingSize || 14,
                      fontWeight: 'bold',
                      color: element.headingColor || '#000000',
                      mb: 0.5
                    }}
                  >
                    {item.heading}:
                  </Typography>
                )}
                {Array.isArray(item.content) && item.content.slice(0, 2).map((content, contentIndex) => (
                  <Typography
                    key={contentIndex}
                    variant="caption"
                    sx={{
                      fontSize: element.contentSize || 12,
                      color: element.contentColor || '#000000',
                      lineHeight: 1.4,
                      display: 'block',
                      mb: 0.5,
                      pl: 1
                    }}
                  >
                    {content}
                  </Typography>
                ))}
                {Array.isArray(item.content) && item.content.length > 2 && (
                  <Typography variant="caption" color="textSecondary" sx={{ pl: 1 }}>
                    +{item.content.length - 2} more content items
                  </Typography>
                )}
              </Box>
            ))}
            {Array.isArray(listData) && listData.length > 3 && (
              <Box sx={{ p: 1, textAlign: 'center', bgcolor: '#f8f9fa' }}>
                <Typography variant="caption" color="textSecondary">
                  +{listData.length - 3} more list items
                </Typography>
              </Box>
            )}
          </Box>

          <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 1, textAlign: 'center' }}>
            {Array.isArray(listData) && listData.length > 0 ? `${listData.length} list item(s)` : 'Add list items in properties'}
          </Typography>
        </Box>
      );

    default:
      return (
        <Box sx={{ p: 1, bgcolor: '#f0f0f0' }}>
          <Typography>Unknown element type: {element.type}</Typography>
        </Box>
      );
  }
};

export default DesignCanvas;