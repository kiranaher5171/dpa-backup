import React from 'react';
import { Box, Chip, Typography, keyframes, IconButton, Tooltip } from '@mui/material';
import { Add, Lightbulb, Close, Block } from '@mui/icons-material';

const pulse = keyframes`
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0.7;
  }
  100% {
    opacity: 1;
  }
`;

const SuggestionChip = ({ 
  suggestion, 
  onApply, 
  onDismiss, 
  onIgnore,
  position = 'below' // 'below' or 'above'
}) => {
  if (!suggestion) return null;

  const handleApply = () => {
    console.log('🖱️ SuggestionChip Apply clicked:', suggestion);
    if (onApply) {
      onApply(suggestion);
    } else {
      console.error('❌ onApply function not provided');
    }
  };

  const handleDismiss = (e) => {
    e.stopPropagation();
    console.log('🖱️ SuggestionChip Dismiss clicked');
    if (onDismiss) {
      onDismiss();
    }
  };

  const handleIgnore = (e) => {
    e.stopPropagation();
    console.log('🖱️ SuggestionChip Ignore clicked:', suggestion);
    if (onIgnore) {
      onIgnore(suggestion);
    } else {
      console.error('❌ onIgnore function not provided');
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        my: 1,
        px: 2,
        position: 'relative',
        zIndex: 5,
        animation: `${pulse} 2s infinite`
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          bgcolor: 'primary.light',
          color: 'primary.contrastText',
          border: '1px solid',
          borderColor: 'primary.main',
          borderRadius: '16px',
          px: 1,
          py: 0.5,
          '&:hover': {
            bgcolor: 'primary.main',
            color: 'white',
            transform: 'scale(1.02)',
            boxShadow: 2
          },
          transition: 'all 0.2s ease',
          cursor: 'pointer',
          fontWeight: 500,
          fontSize: '0.875rem'
        }}
      >
        {/* Main suggestion chip */}
        <Chip
          icon={<Lightbulb fontSize="small" />}
          label={
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                Suggested:
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {suggestion.text}
              </Typography>
            </Box>
          }
          onClick={handleApply}
          sx={{
            bgcolor: 'transparent',
            color: 'inherit',
            border: 'none',
            '&:hover': {
              bgcolor: 'rgba(255, 255, 255, 0.1)',
            },
            '& .MuiChip-icon': {
              color: 'inherit'
            },
            '& .MuiChip-label': {
              px: 1
            }
          }}
          clickable
        />
        
        {/* Action buttons */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          {/* Apply button */}
          <Tooltip title="Apply suggestion">
            <IconButton
              size="small"
              onClick={handleApply}
              sx={{
                color: 'inherit',
                '&:hover': {
                  bgcolor: 'rgba(255, 255, 255, 0.2)',
                  color: 'white'
                },
                width: 28,
                height: 28
              }}
            >
              <Add fontSize="small" />
            </IconButton>
          </Tooltip>
          
          {/* Ignore button */}
          <Tooltip title="Ignore this suggestion permanently">
            <IconButton
              size="small"
              onClick={handleIgnore}
              sx={{
                color: 'inherit',
                '&:hover': {
                  bgcolor: 'rgba(255, 193, 7, 0.2)',
                  color: '#ffc107'
                },
                width: 28,
                height: 28
              }}
            >
              <Block fontSize="small" />
            </IconButton>
          </Tooltip>
          
          {/* Dismiss button */}
          <Tooltip title="Dismiss suggestion">
            <IconButton
              size="small"
              onClick={handleDismiss}
              sx={{
                color: 'inherit',
                '&:hover': {
                  bgcolor: 'rgba(244, 67, 54, 0.2)',
                  color: '#f44336'
                },
                width: 28,
                height: 28
              }}
            >
              <Close fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>
    </Box>
  );
};

export default SuggestionChip;
