import React from 'react';
import { Box, Typography, Tooltip } from '@mui/material';

const ThemeColorPicker = ({ 
  value, 
  onChange, 
  label, 
  disabled = false,
  themeColors = []
}) => {
  // Only 8 colors: 6 theme colors + black + white
  const defaultThemeColors = [
    '#000000', // Black
    '#ffffff', // White
    '#1930ab', // Blue
    '#fa7604', // Orange
    '#4CAF50', // Green
    '#f44336', // Red
    '#9c27b0', // Purple
    '#ff9800'  // Amber
  ];

  // Use only the first 6 theme colors from the provided theme, then add black and white
  const limitedThemeColors = themeColors.slice(0, 6);
  const allColors = [...new Set([...limitedThemeColors, ...defaultThemeColors])].slice(0, 8);

  const colorNames = {
    '#000000': 'Black',
    '#ffffff': 'White', 
    '#1930ab': 'Blue',
    '#fa7604': 'Orange',
    '#4CAF50': 'Green',
    '#f44336': 'Red',
    '#9c27b0': 'Purple',
    '#ff9800': 'Amber'
  };

  return (
    <Box>
      <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
        {label}
      </Typography>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
        {allColors.map((color, index) => (
          <Tooltip 
            key={color} 
            title={colorNames[color] || color}
            arrow
            placement="top"
          >
            <Box
              onClick={() => !disabled && onChange(color)}
              sx={{
                width: 32,
                height: 32,
                backgroundColor: color,
                borderRadius: '50%',
                cursor: disabled ? 'default' : 'pointer',
                border: value === color ? '3px solid #1976d2' : '2px solid #e0e0e0',
                boxShadow: value === color ? '0 0 0 2px rgba(25, 118, 211, 0.2)' : 'none',
                transition: 'all 0.2s ease',
                opacity: disabled ? 0.5 : 1,
                '&:hover': {
                  transform: disabled ? 'none' : 'scale(1.1)',
                  boxShadow: disabled ? 'none' : '0 2px 8px rgba(0,0,0,0.3)'
                }
              }}
            />
          </Tooltip>
        ))}
      </Box>
    </Box>
  );
};

export default ThemeColorPicker;
