'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useEmployeeStore } from '@/store/employeeStore';
import { validateSession } from '@/utils/tokenUtils';

export default function SessionInitializer() {
  const { initializeFromSession, employeeDetails, clearSession } = useEmployeeStore();
  const router = useRouter();

  const handleSessionValidation = () => {
    try {
      const validation = validateSession();
      
      if (!validation.isValid) {
        console.log(`🔐 SessionInitializer: Session validation failed: ${validation.reason}`);
        clearSession();
        if (validation.isExpired) {
          router.push('/auth/sso-login');
        }
        return false;
      }
      
      return true;
    } catch (error) {
      console.error('🔐 SessionInitializer: Error during session validation:', error);
      clearSession();
      return false;
    }
  };

  const handleSessionInitialization = async () => {
    try {
      console.log('🔐 SessionInitializer: Session and token valid, initializing from session...');
      
      const result = await initializeFromSession();
      
      if (result.success) {
        console.log('🔐 SessionInitializer: Successfully initialized from session');
        return;
      }
      
      console.log('🔐 SessionInitializer: Failed to initialize from session:', result.error);
      
      if (result.isTokenExpired) {
        console.log('🔐 SessionInitializer: Token expired during API call, clearing session');
        clearSession();
        router.push('/auth/sso-login');
      }
    } catch (error) {
      console.error('🔐 SessionInitializer: Error during session initialization:', error);
      clearSession();
    }
  };

  const initializeSession = () => {
    if (!handleSessionValidation()) {
      return;
    }
    
    handleSessionInitialization();
  };

  useEffect(() => {
    if (employeeDetails) {
      console.log('🔐 SessionInitializer: Employee details already exist, skipping initialization');
      return;
    }

    console.log('🔐 SessionInitializer: No employee details found, checking session...');
    
    const timer = setTimeout(initializeSession, 100);
    return () => clearTimeout(timer);
  }, [initializeFromSession, employeeDetails, clearSession]);

  return null; // This component doesn't render anything
}
