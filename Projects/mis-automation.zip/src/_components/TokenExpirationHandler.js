'use client';
import { useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useEmployeeStore } from '@/store/employeeStore';

export default function TokenExpirationHandler() {
  const { clearSession } = useEmployeeStore();
  const router = useRouter();

  // Stabilize the clearSession function to prevent useEffect dependency issues
  const stableClearSession = useCallback(() => {
    clearSession();
  }, [clearSession]);

  useEffect(() => {
    // Intercept fetch requests to handle 401 responses
    const originalFetch = window.fetch;
    
    window.fetch = async (...args) => {
      try {
        const response = await originalFetch(...args);
        
        // Check if response is 401 (Unauthorized)
        if (response.status === 401) {
          console.log('🔐 TokenExpirationHandler: Received 401 response, checking session validity...');
          
          // Check if this is a critical authentication endpoint that should trigger logout
          const url = args[0];
          const isCriticalAuthEndpoint = url && (
            url.includes('/api/auth/') ||
            url.includes('/api/check-user-role') ||
            url.includes('/api/check-admin-roles') ||
            url.includes('/api/get-all-employees') ||
            url.includes('/api/sync-employees')
          );
          
          console.log('🔐 TokenExpirationHandler: URL:', url);
          console.log('🔐 TokenExpirationHandler: Is critical auth endpoint:', isCriticalAuthEndpoint);
          
          // Check if our session is still valid (4-hour timeout)
          const expireTime = localStorage.getItem('expireTime');
          const currentTime = new Date();
          const sessionExpireTime = new Date(expireTime);
          
          // Only redirect to login if:
          // 1. It's a critical auth endpoint, OR
          // 2. The session has actually expired
          const shouldRedirect = isCriticalAuthEndpoint || !expireTime || currentTime > sessionExpireTime;
          
          if (shouldRedirect) {
            if (isCriticalAuthEndpoint) {
              console.log('🔐 TokenExpirationHandler: Critical auth endpoint returned 401, redirecting to login');
            } else {
              console.log('🔐 TokenExpirationHandler: Session expired, logging out user');
            }
            
            // Clear session and redirect
            stableClearSession();
            router.push('/auth/sso-login');
            
            // Return a rejected promise to prevent further processing
            throw new Error('Token expired - user logged out');
          } else {
            console.log('🔐 TokenExpirationHandler: Session still valid, JWT token expired - allowing API to handle gracefully');
            // Session is still valid but JWT token expired
            // Let the calling code handle this gracefully (e.g., show error message, use fallback data)
            // Don't redirect to login for non-critical endpoints
          }
        }
        
        return response;
      } catch (error) {
        // Re-throw the error if it's not our token expiration error
        if (error.message !== 'Token expired - user logged out') {
          throw error;
        }
      }
    };

    // Cleanup function to restore original fetch
    return () => {
      window.fetch = originalFetch;
    };
  }, [stableClearSession, router]);

  // Set up a periodic check for session expiration (not JWT token expiration)
  useEffect(() => {
    const checkSessionExpiration = () => {
      try {
        const session = localStorage.getItem('session');
        const expireTime = localStorage.getItem('expireTime');
        
        if (!session || !expireTime) {
          console.log('🔐 TokenExpirationHandler: No session or expire time found');
          return;
        }

        const currentTime = new Date();
        const sessionExpireTime = new Date(expireTime);
        
        console.log('🔐 TokenExpirationHandler: Checking session expiration...');
        console.log('🔐 Current time:', currentTime);
        console.log('🔐 Session expires at:', sessionExpireTime);
        console.log('🔐 Time until expiration:', Math.floor((sessionExpireTime - currentTime) / (1000 * 60)), 'minutes');
        
        if (currentTime > sessionExpireTime) {
          console.log('🔐 TokenExpirationHandler: Session expired during periodic check');
          stableClearSession();
          router.push('/auth/sso-login');
        } else {
          console.log('🔐 TokenExpirationHandler: Session is still valid');
        }
      } catch (error) {
        console.log('🔐 TokenExpirationHandler: Error during periodic session check:', error.message);
        // If there's an error parsing the session, clear it for security
        stableClearSession();
        router.push('/auth/sso-login');
      }
    };

    // Check every 5 minutes (more frequent to catch expiration closer to the actual time)
    const interval = setInterval(checkSessionExpiration, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [stableClearSession, router]);

  return null; // This component doesn't render anything
}
