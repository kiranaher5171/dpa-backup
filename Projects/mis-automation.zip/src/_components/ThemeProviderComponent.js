"use client";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';
import PropTypes from 'prop-types';
import { usePathname } from 'next/navigation';

const theme = createTheme({
  typography: {
    fontFamily: 'Poppins, sans-serif',
  },
});

const ThemeProviderComponent = ({ children }) => {
  const cache = createCache({
    key: 'nik',
    nonce: "123",
    prepend: true,
  });

  const pathname = usePathname();
  const noLayoutRoutes = ['/', '/sign-in']; // Pages without layout
  const isNoLayoutPage = noLayoutRoutes.includes(pathname);

  return (
    <CacheProvider value={cache}>
      <ThemeProvider theme={theme}>
        {isNoLayoutPage ? (
          <>{children}</>
        ) : (
          <>{children}</>
        )}
      </ThemeProvider>
    </CacheProvider>
  );
};

ThemeProviderComponent.propTypes = {
  children: PropTypes.node.isRequired,
};

export default ThemeProviderComponent;
