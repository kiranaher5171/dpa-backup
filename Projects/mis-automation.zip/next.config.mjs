/** @type {import('next').NextConfig} */
const nextConfig = {
    productionBrowserSourceMaps: false, // Disable source maps in production
    
    // Handle Node.js modules that are not available in the browser
    webpack: (config, { isServer }) => {
        if (!isServer) {
            // Don't attempt to load these modules on the client side
            config.resolve.fallback = {
                ...config.resolve.fallback,
                net: false,
                dns: false,
                fs: false,
                tls: false,
                crypto: false,
                stream: false,
                url: false,
                zlib: false,
                http: false,
                https: false,
                assert: false,
                os: false,
                path: false,
            };
        }
        return config;
    },
    
    async headers() {
        return [
            // Cache for _next/static (hashed assets)
            {
                source: '/_next/static/:path*',
                headers: [
                    {
                        key: 'Cache-Control',
                        value: 'public, max-age=2592000, immutable', 
                        // 1 month cache (30 days), safe because files are hashed
                    },
                ],
            },
            // Cache for public/static (non-hashed assets)
            {
                source: '/static/:path*',
                headers: [
                    {
                        key: 'Cache-Control',
                        value: 'public, max-age=3600, must-revalidate', // Cache for 1 hour, revalidate to ensure freshness
                    },
                ],
            },
        ];
    },
};

export default nextConfig;
