import { Box, Container } from '@mui/material'
import React from 'react'
import { HeroSection } from './LandingPageSections/HeroSection'
import { VideoSection } from './LandingPageSections/VideoSection'
import { FeaturesSection } from './LandingPageSections/FeaturesSection'
import { StepsSection } from './LandingPageSections/StepsSection'
import { WhoCanUseIt } from './LandingPageSections/WhoCanUseIt'
import { ComparisonTable } from './LandingPageSections/ComparisonTable'
import { PricingSection } from './LandingPageSections/PricingSection'
import { FooterSection } from './LandingPageSections/FooterSection'
import { UsersTestimonials } from './LandingPageSections/UsersTestimonials'
import { PressReleases } from './LandingPageSections/PressReleases'
import { LandingFAQs } from './LandingPageSections/LandingFAQs'

export const Home = () => {


    return (
        <>

            <Box className="pageStart">
                <Container maxWidth="xl">
                    <HeroSection />
                </Container>
            </Box>

            <Box id="why-pdfquery">
                <VideoSection />
            </Box>

            <Box id="how-it-works">
                <FeaturesSection />
            </Box>

            <Box>
                <StepsSection />
            </Box>

            {/* New Sections Added */}
            <Box>
                <UsersTestimonials />
            </Box>

            <Box>
                <PressReleases />
            </Box>

            <Box>
                <LandingFAQs/>
            </Box>
            {/* New Sections Added */}


            <Box id="who-can-use-it">
                <WhoCanUseIt />
            </Box>

            <Box id="compare-with-chatgpt">
                <ComparisonTable />
            </Box>

            <Box id="pricing">
                <PricingSection />
            </Box>

            <Box id="contact-us">
                <FooterSection />
            </Box>

        </>
    )
}
