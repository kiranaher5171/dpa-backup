import React, { useState } from 'react';
import { Typography, Button, Box } from '@mui/material';

const Testimonial = ({ name, designation, content }) => {
    const [expanded, setExpanded] = useState(false);

    const renderContent = (content) => {
        const maxLines = 1; // Maximum number of lines before "Read More" button appears
        const contentLines = content.split('\n');
        const isLongContent = contentLines.length > maxLines;

        if (isLongContent && !expanded) {
            const visibleContent = contentLines.slice(0, maxLines).join('\n');
            return (
                <>
                    {visibleContent}
                    <span id="read-more-ellipsis">...</span>
                    <Button onClick={() => setExpanded(true)} variant="text" color="primary">Read More</Button>
                </>
            );
        } else {
            return content;
        }
    };

    return (
        <Box className="testimonial_bx">
            <Box>
                <Typography variant='h5' className='black'>{name}</Typography>
                <Typography variant='h5' className='gry'>{designation}</Typography>
            </Box>
            <Box>
                <Typography variant='h5' className='black'>
                    {renderContent(content)}
                </Typography>
            </Box>
        </Box>
    );
};

export default Testimonial;
