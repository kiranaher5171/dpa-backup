import { Box, Button, Container, Grid, Typography, Dialog, DialogContent, DialogContentText, IconButton } from '@mui/material'
import CloseIcon from '@mui/icons-material/Close';
import React, { useState } from 'react'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import { Link } from 'react-router-dom';

export const UsersTestimonials = () => {

  const responsiveOptions = {
    0: { items: 1 },
    600: { items: 2 },
    1000: { items: 3 },
  };

  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [open3, setOpen3] = useState(false);
  const [open4, setOpen4] = useState(false);

  return (
    <Box id="users-love" className="subsection">
      <Container maxWidth="lg">
        <Box pb={3}>
          <Typography variant='h2' className='bl fw4 al_center'>
            Discover Why Our <span className='col1'>Users Love Us</span>
          </Typography>
        </Box>
        <Box pb={6} mt={4} position="relative">
          <Grid container justifyContent='center'>
            <OwlCarousel
              className='owl-theme reportinfo'
              loop
              margin={10}
              nav={true}
              dots={false}
              autoplayHoverPause={true}
              autoplay
              responsive={responsiveOptions}
              navText={[
                "<span class='custom-nav-arrow'>&larr;</span>",
                "<span class='custom-nav-arrow'>&rarr;</span>"
              ]}
            >
              {[
                {
                  name: "Santosh Pandit",
                  role: "Cybersecurity expert",
                  desc: "This tool amazed me with its ability to extract specific information from the PDF...",
                  openDialog: () => setOpen(true)
                },
                {
                  name: "Sandeep",
                  role: "Marketing",
                  desc: "As an entrepreneur, PDFquery has transformed the way I manage information...",
                  openDialog: () => setOpen2(true)
                },
                {
                  name: "Anant",
                  role: "Workxogo",
                  desc: "As the founder of Worxogo, PDFquery has been exceptional in streamlining...",
                  openDialog: () => setOpen3(true)
                },
                {
                  name: "Piyush Sharma",
                  role: "Distinguished Professor",
                  desc: "This saves significant time and acts as a powerful accelerator for learning...",
                  openDialog: () => setOpen4(true)
                }
              ].map((item, index) => (
                <Box key={index} className="testimonial_bx">
                  <Typography variant='h5' className='bl fw5'>{item.name}</Typography>
                  <Typography variant='h5' className='h5v2 fw5 content'>{item.role}</Typography>
                  <Box pt={2}>
                    <Typography variant='h5' className='h5v2 fw4 bl ellip_desc'>{item.desc}</Typography>
                  </Box>
                  <Box pt={1} className="al_right">
                    <Button variant='text' className="read-more" onClick={item.openDialog}>Read more</Button>
                  </Box>
                </Box>
              ))}
            </OwlCarousel>
          </Grid>
        </Box>
      </Container>

      {/* Dialogs */}
      {[open, open2, open3, open4].map((isOpen, i) => (
        <Dialog key={i} fullWidth maxWidth={'xs'} open={isOpen} onClose={() => [setOpen, setOpen2, setOpen3, setOpen4][i](false)}>
          <IconButton aria-label="close" onClick={() => [setOpen, setOpen2, setOpen3, setOpen4][i](false)} sx={{ position: 'absolute', right: 8, top: 8, color: '#000' }}>
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
              <Typography variant='h5' className='bl fw5'>
                {[ "Santosh Pandit", "Sandeep", "Anant", "Piyush Sharma" ][i]}
              </Typography>
              <Typography variant='h5' className='h5v2 fw5 content'>
                {[ "Cybersecurity expert", "Marketing", "Workxogo", "Distinguished Professor" ][i]}
              </Typography>
              <Box pt={2}>
                <Typography variant='h5' className='h5v2 fw4 bl'>
                  {/* Full testimonial text can go here */}
                  Full testimonial text for {["Santosh", "Sandeep", "Anant", "Piyush"][i]} goes here...
                </Typography>
              </Box>
            </DialogContentText>
          </DialogContent>
        </Dialog>
      ))}
    </Box>
  );
};
