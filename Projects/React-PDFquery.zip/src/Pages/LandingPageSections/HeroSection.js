import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'

// import Hero from "../../Assets/Images/hero.png";
import { RBtn } from '../../Component/Buttons/RBtn';
import LandingVideo from "../../Assets/landingvdo.m4v";


export const HeroSection = () => {
    return (
        <>

            <Box id="hero" className="hero_section">
                <Container maxWidth="xl">
                    <Grid container alignItems="center" justifyContent='space-between' spacing={2}>
                        <Grid item lg={7} md={6} sm={6} xs={12}>
                            <Box className='al_left'>
                                <Typography variant='h1' className='fw4'>
                                    Struggling to Find
                                </Typography>
                                <Typography variant='h1' className='fw4'>
                                    Information in PDFs?
                                </Typography>
                                <Typography variant='h1' className='fw3'>
                                    <span className='col1'>PDF</span>query <span className='fw5 col1'>is Your Guide!</span>
                                </Typography>
                            </Box>
                            <Box className='al_left' pt={2}>
                                <Typography variant='h4' className='content'>
                                    Experience the magic of AI. Chat with your documents.
                                </Typography>
                            </Box>
                            <Box pt={2}>
                                <RBtn btn_name="Explore for Free" />
                            </Box>
                        </Grid>
                        <Grid item lg={5} md={6} sm={6} xs={12}>
                            <Box className='al_center'>
                                {/* <img src={Hero} className='herobanner' alt='Video Here' /> */}
                                <video autoPlay loop muted >
                                    <source src={LandingVideo} type="video/webm" />
                                </video>
                            </Box>
                        </Grid>
                    </Grid>
                </Container>
            </Box>


        </>
    )
}
