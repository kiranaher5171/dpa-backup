import { Box, Container, Divider, Grid, Typography, Button } from '@mui/material'
import React from 'react'

import Check from "../../Assets/Images/check.svg";
import Check2 from "../../Assets/Images/check2.svg";

import { TypeAnimation } from 'react-type-animation';


export const PricingSection = () => {
    return (
        <>

            <Box id="pricing" className="subsection">

                <Box pb={3}>
                    <Container maxWidth="lg">
                        <Box>
                            <Typography variant='h2' className='col1 fw4 al_center'>
                                Pricing
                            </Typography>
                        </Box>
                        <Box>
                            <Typography variant='h2' className='black fw4 al_center'>
                                Save Hours of Effort for a Price of a Pizza
                            </Typography>
                        </Box>
                    </Container>
                </Box>



                <Box pb={3} pt={3} className="sec_bg_2">
                    <Container maxWidth="lg">
                        <Box>
                            <Typography variant='h3' className='col1 fw5 al_center'>
                                {/* Lifetime Deal: $7/month */}Paid Plans
                            </Typography>
                        </Box>
                        {/* <Box pt={1}>
                            <Typography variant='h5' className='black fw5 al_center blink_text'>
                                Sign Up Now! 
                            </Typography>
                        </Box> */}
                        <Box pt={2} pb={1}>
                            <TypeAnimation
                                sequence={[
                                    ' Coming Soon!!',
                                    1000,
                                    'Coming Soon!!',
                                    1000,
                                    'Coming Soon!!',
                                    1000,
                                ]}
                                wrapper="h5"
                                speed={50}
                                className='black al_center fw5 m0'
                                repeat={Infinity}
                            />
                        </Box>
                        {/* <Box pt={1}>
                            <Typography variant='h5' className='content fw4 al_center'>
                                Price Double from 22nd Feb 2024
                            </Typography>
                        </Box> */}
                    </Container>
                </Box>



                <Container maxWidth="lg">

                    <Box pb={6} className="pricing-cards" pt={5}>
                        <Grid container alignItems="flex-start" justifyContent='center' spacing={6}>
                            <Grid item lg={4} md={4} sm={6} xs={10}>
                                <Box className="pricingBx_wh">
                                    <Box className='al_center' pt={2} pb={1}>
                                        <Typography variant='h4' className='fw5'>
                                            FREE
                                        </Typography>
                                    </Box>


                                    <Box className='al_center' pt={2} pb={2}>
                                        <Typography variant='h3' className='fw5 col1'>
                                            <sup>$</sup>0/month
                                        </Typography>
                                    </Box>


                                    <Box className='al_center' pt={5}>
                                        <Box pt={'12px'} pb={'12px'}>
                                            <Typography variant='h5' className='fw5 black fx_fs' gutterBottom>
                                                <img src={Check} alt='checkbox_icon' /> &nbsp;  &nbsp;
                                                <span className='al_left'> 50 Questions/month </span>
                                            </Typography>
                                        </Box>

                                        <Divider />

                                        <Box pt={'12px'} pb={'12px'}>
                                            <Typography variant='h5' className='fw5 black fx_fs' gutterBottom>
                                                <img src={Check} alt='checkbox_icon' /> &nbsp;   &nbsp;
                                                <span className='al_left'> 5 Files/month </span>
                                            </Typography>
                                        </Box>

                                        <Divider />

                                        <Box pt={'12px'} pb={'12px'}>
                                            <Typography variant='h5' className='fw5 black fx_fs' gutterBottom>
                                                <img src={Check} alt='checkbox_icon' /> &nbsp;   &nbsp;
                                                <span className='al_left'> 10 MB/file </span>
                                            </Typography>
                                        </Box>

                                    </Box>

                                    <Box mt={6} className="al_center pricingBtnBx">
                                        <Button variant='outlined' className='pricingBtn'> GET STARTED </Button>
                                    </Box>


                                </Box>
                            </Grid>


                            {/* <Grid item lg={4} md={4} sm={6} xs={10}>
                                <Box className="pricingBx_rd">
                                    <Box className='al_center' pt={2}>
                                        <Typography variant='h4' className='fw5 wh'>
                                            PRO
                                        </Typography>
                                    </Box>


                                    <Box className='al_center' pt={2}>
                                        <Typography variant='h3' className='fw5 wh'>
                                            <sup>$</sup>7/month
                                        </Typography>
                                    </Box>


                                    <Box className='al_center' pt={4}>
                                        <Box pt={'12px'} pb={'12px'}>
                                            <Typography variant='h5' className='fw5 wh fx_fs' gutterBottom>
                                                <img src={Check2} alt='checkbox_icon' /> &nbsp;  &nbsp;  
                                                <span className='al_left'> 100 Questions/month </span>
                                            </Typography>
                                        </Box>

                                        <Divider className='wh_div'/>

                                        <Box pt={'12px'} pb={'12px'}>
                                            <Typography variant='h5' className='fw5 wh fx_fs' gutterBottom>
                                                <img src={Check2} alt='checkbox_icon' /> &nbsp;   &nbsp;
                                                <span className='al_left'> $8 for every additional 50 Questions. </span>
                                            </Typography>
                                        </Box>

                                        <Divider className='wh_div'/>

                                        <Box pt={'12px'} pb={'12px'}>
                                            <Typography variant='h5' className='fw5 wh fx_fs' gutterBottom>
                                                <img src={Check2} alt='checkbox_icon' /> &nbsp;  &nbsp;
                                                <span className='al_left'> 32 MB/file </span>
                                            </Typography>
                                        </Box>

                                    </Box>

                                    <Box mt={6} className="al_center pricingBtnBx">
                                        <Button variant='outlined' className='pricingBtn2'> UPGRADE NOW </Button>
                                    </Box>


                                </Box>
                            </Grid> */}




                            {/* <Grid item lg={4} md={4} sm={6} xs={10}>
                                <Box className="pricingBx_wh" mt={5}>
                                    <Box className='al_center' pt={2} pb={1}>
                                        <Typography variant='h4' className='fw5'>
                                            Enterprise
                                        </Typography>
                                    </Box>


                                    <Box className='al_center' pt={2} pb={2}>
                                        <Typography variant='h3' className='fw5 col1'>
                                            Custom Price
                                        </Typography>
                                    </Box>


                                    <Box className='al_center' pt={4}>
                                        <Box pt={1} pb={1}>
                                            <Typography variant='h5' className='fw5 black fx_fs' gutterBottom>
                                                <img src={Check} alt='checkbox_icon' /> &nbsp; &nbsp;  
                                                <span className='al_left'>Have larger, custom requirements?</span>
                                            </Typography>
                                        </Box>
                                    </Box>

                                    <Box mt={2} className="al_center pricingBtnBx">
                                        <Button variant='outlined' className='pricingBtn'> CONTACT SALES </Button>
                                    </Box>


                                </Box>
                            </Grid> */}

                        </Grid>
                    </Box>


                </Container>
            </Box>


        </>
    )
}
