import { Box, Grid, Typography } from '@mui/material'
import React, {useState} from 'react'

// import Hero from "../../Assets/Images/hero.png";
import { RBtn } from '../../Component/Buttons/RBtn';
import { Link } from 'react-router-dom';



import ModalVideo from "react-modal-video";
import "react-modal-video/scss/modal-video.scss";
// import "react-modal-video/scss/modal-video.scss";
 


export const VideoSection = () => {


    const [isOpen, setIsOpen] = useState(false);

    const openModal = () => {
        setIsOpen(true);
    };


    return (
        <>
            <Box className="relative">
                <Grid container alignItems="center" justifyContent='space-between' spacing={0}>
                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='video_bg'>
                            <Link>
                                <Box className="play_btn_1" onClick={openModal} ></Box>
                            </Link>
                        </Box>
                        <Box className="vdo_btm_content" pt={5}>
                            <Box className="al_center">
                                <Typography variant='h4' className='black fw5' gutterBottom>
                                    “<span className='col1'>PDF</span>query saves hours worth of effort and gives instant insight when needed.”
                                </Typography>
                                <Typography variant='h4' className='col1 fw5'>
                                    Research Analyst
                                </Typography>
                            </Box>
                            <Box className="al_center" pt={1} pb={4}>
                                <RBtn btn_name="Try Now" />
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Box>




            <ModalVideo
                channel="youtube"
                isOpen={isOpen}
                videoId="1o7DlE35IS4"
                onClose={() => setIsOpen(false)}
            />

        </>
    )
}
