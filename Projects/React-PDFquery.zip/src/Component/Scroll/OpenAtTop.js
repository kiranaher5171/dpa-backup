import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const scrollToElement = (id) => {
  const element = document.getElementById(id);
  if (element) {
    setTimeout(() => {
      const offset = element.offsetTop;
      window.scrollTo({ top: offset, behavior: 'smooth' });
    }, 100); // Adjust delay time as needed
  }
};

const OpenAtTop = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        const hash = window.location.hash;

        if (hash) {
            scrollToElement(hash.substring(1)); // Remove '#' from the hash
        } else {
            const element = document.documentElement || document.body;

            const openAtTopWithDelay = () => {
                setTimeout(() => {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 10);
            };

            openAtTopWithDelay();
        }
    }, [pathname]);

    return null;
};

export default OpenAtTop;
