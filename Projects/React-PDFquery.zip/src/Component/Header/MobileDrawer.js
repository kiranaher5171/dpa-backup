import * as React from 'react';
import { useState } from 'react';
import { Drawer, IconButton, Divider, Button, Stack, } from '@mui/material';
import { styled } from '@mui/material/styles';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';

import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { Link } from 'react-router-dom';






export default function MobileDrawer() {
    const [state, setState] = useState({ right: false });

    const toggleDrawer = (anchor, open) => () => {
        setState({ ...state, [anchor]: open });
    };



    const isDrawerOpen = state['right'];

    const DrawerHeader = styled('div')(({ theme }) => ({
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        ...theme.mixins.toolbar,
    }));



    const [expanded, setExpanded] = React.useState(false);

    const handleChange = (panel) => (event, isExpanded) => {
        setExpanded(isExpanded ? panel : false);
    };



    const scrollToSection = (id) => {
        const element = document.getElementById(id);
        if (element) {
            setTimeout(() => {
                const offset = element.offsetTop;
                window.scrollTo({ top: offset, behavior: 'smooth' });
            }, 100);
        }
    };

    const handleButtonClick = (sectionId) => {
        scrollToSection(sectionId);
        toggleDrawer('right', false)();
    };




    return (
        <>
            <IconButton
                className='drawer_btn'
                size='medium'
                onClick={toggleDrawer('right', !isDrawerOpen)}
            >
                {isDrawerOpen ? <CloseIcon fontSize='small' /> : <MenuIcon fontSize='small' />}
            </IconButton>

            <Drawer id="mobile-drawer" anchor="right" open={isDrawerOpen} onClose={toggleDrawer('right', false)}>
                <DrawerHeader>
                    <IconButton className='' variant="contained" onClick={toggleDrawer('right', false)}>
                        <CloseIcon fontSize='small' className='col1' />
                    </IconButton>
                </DrawerHeader>

                <Divider />


                <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
                    <AccordionSummary
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                    >
                        <Link to="/#pricing">
                            <Button className="menus" color="inherit" disableRipple onClick={() => handleButtonClick('pricing')} > Pricing </Button>
                        </Link>
                    </AccordionSummary>
                </Accordion>

                <Divider />

                <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
                    <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2bh-content"
                        id="panel2bh-header"
                    >
                        <Button variant="text" className='menus' disableRipple fullWidth> Information </Button>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Stack direction="column" spacing={0}>

                            <Link to="/#why-pdfquery">
                                <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { handleButtonClick('why-pdfquery'); }}>  Why PDFquery? </Button>
                            </Link>

                            <Link to="/#how-it-works">
                                <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { handleButtonClick('how-it-works'); }}>  How it works? </Button>
                            </Link>

                            <Link to="/#who-can-use-it">
                                <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { handleButtonClick('who-can-use-it'); }}>  Who can use it? </Button>
                            </Link>

                            <Link to="/#compare-with-chatgpt">
                                <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { handleButtonClick('compare-with-chatgpt'); }}> Compare with ChatGPT </Button>
                            </Link>
                        </Stack>
                    </AccordionDetails>
                </Accordion>


                <Divider />


                <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
                    <AccordionSummary
                        aria-controls="panel3bh-content"
                        id="panel3bh-header"
                    >
                        <Link to="/#contact-us">
                            <Button className="menus" color="inherit" disableRipple onClick={() => handleButtonClick('contact-us')} > Contact Us </Button>
                        </Link>

                    </AccordionSummary>
                </Accordion>

                <Divider />


                <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
                    <AccordionSummary
                        aria-controls="panel3bh-content"
                        id="panel3bh-header"
                    >
                        <Link to="/#faq">
                            <Button className="menus" color="inherit" disableRipple onClick={() => handleButtonClick('faq')}> FAQ's </Button>
                        </Link>
                    </AccordionSummary>
                </Accordion>

                <Divider />



                <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
                    <AccordionSummary
                        aria-controls="panel3bh-content"
                        id="panel3bh-header"
                    >
                        <Button variant="text" className='menus' disableRipple fullWidth onClick={toggleDrawer("right", false)}> Sign In </Button>
                    </AccordionSummary>
                </Accordion>

                <Divider />

            </Drawer>
        </>
    );
}
