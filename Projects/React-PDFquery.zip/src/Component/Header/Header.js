import * as React from 'react';
import { useState } from 'react';
import "./Header.css";
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import { Link } from 'react-router-dom';
import { Menu, Button, Stack } from '@mui/material';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';


import MobileDrawer from './MobileDrawer';
import LOGO from '../../Assets/Images/pdf-query-logo.svg';



export default function Header() {

  const [activePage, setActivePage] = useState('');
  const handleSetActivePage = (pageName) => { setActivePage(pageName); };


  const [anchorE2, setAnchorE2] = React.useState(null);
  const handleClick = (event) => { setAnchorE2(event.currentTarget); };
  const handleClose = () => { setAnchorE2(null); };


  const scrollToElement = (id) => {
    const element = document.getElementById(id);
    if (element) {
      setTimeout(() => {
        const offset = element.offsetTop;
        window.scrollTo({ top: offset, behavior: 'smooth' });
      }, 100);
    }
  };



  const handleLogoClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setActivePage('home');
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar id='Appbar' position="fixed">
        <Toolbar className='Appbar_height'>

          <Box component="div" sx={{ flexGrow: 1 }}>
            <Link to="/" className={activePage === 'home' ? 'active' : ''} onClick={handleLogoClick}>
              <img src={LOGO} alt="PDF Query" className='appbar_logo' />
            </Link>
          </Box>

          <Box component="span" className='fx_fe'>

            <Box className="desktop_menus">

              <Link to="/#pricing" className={activePage === 'Pricing' ? 'active' : ''} onClick={() => handleSetActivePage('Pricing')}>
                <Button className="menus" color="inherit" disableRipple onClick={() => scrollToElement('pricing')} > Pricing </Button>
              </Link>

              <Link to="#" className={activePage === 'Information' ? 'active' : ''} onClick={() => handleSetActivePage('Information')}>
                <Button variant="text" className='menus' disableRipple endIcon={<ArrowDropDownIcon />} onClick={handleClick}> Information </Button>
              </Link>


              <Menu
                id="menuId"
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                anchorEl={anchorE2}
                keepMounted
                open={Boolean(anchorE2)}
                onClose={handleClose} className="menuitem"
              >
                <Stack direction="column" spacing={0}>
                  <Link to="/#why-pdfquery" className={activePage === 'why-pdfquery' ? 'active' : ''} onClick={() => handleSetActivePage('Information')}>
                    <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { scrollToElement('why-pdfquery'); handleClose(); }}>  Why PDFquery? </Button>
                  </Link>

                  <Link to="/#how-it-works" className={activePage === 'how-it-works' ? 'active' : ''} onClick={() => handleSetActivePage('Information')}>
                    <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { scrollToElement('how-it-works'); handleClose(); }}>  How it works? </Button>
                  </Link>

                  <Link to="/#who-can-use-it" className={activePage === 'who-can-use-it' ? 'active' : ''} onClick={() => handleSetActivePage('Information')}>
                    <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { scrollToElement('who-can-use-it'); handleClose(); }}>  Who can use it? </Button>
                  </Link>

                  <Link to="/#compare-with-chatgpt" className={activePage === 'compare-with-chatgpt' ? 'active' : ''} onClick={() => handleSetActivePage('Information')}>
                    <Button variant="text" className='menus dropmenus' disableRipple onClick={() => { scrollToElement('compare-with-chatgpt'); handleClose(); }}> Compare with ChatGPT </Button>
                  </Link>

                </Stack>
              </Menu>



              <Link to="/#contact-us" className={activePage === 'contact-us' ? 'active' : ''} onClick={() => handleSetActivePage('contact-us')}>
                <Button className="menus" color="inherit" disableRipple onClick={() => scrollToElement('contact-us')} > Contact Us </Button>
              </Link>

              <Link to="/#faq" className={activePage === 'faq' ? 'active' : ''} onClick={() => handleSetActivePage('faq')}>
                <Button className="menus" color="inherit" disableRipple onClick={() => scrollToElement('faq')}> FAQ's </Button>
              </Link>


              <Link to="/#" className={activePage === 'Sign' ? 'active' : ''} onClick={() => handleSetActivePage('Sign')}>
                <Button variant="text" className='menus' disableRipple> Sign In </Button>
              </Link>
            </Box>


            <Box className="mobile_menus">
              <MobileDrawer />
            </Box>

          </Box>

        </Toolbar>
      </AppBar>
    </Box>

  );
}
