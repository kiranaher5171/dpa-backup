import { Button } from '@mui/material'
import React from 'react'
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';

export const RBtn = ({btn_name}) => {
  return (
    <>
 
    <Button variant='contained' className='rbtn' endIcon={<ArrowForwardIcon/>}>{btn_name}</Button>
    
    </>
  )
}
