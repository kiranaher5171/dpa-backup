import Header from './Component/Header/Header';
import './Root.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import BackToTop from './Component/Scroll/BackToTop';
import { Home } from './Pages/Home';
import FAQ from './Pages/FAQ/FAQ';
import OpenAtTop from './Component/Scroll/OpenAtTop';


function App() {
  return (
    <>

      <Router>
        <Header />
        <BackToTop />
        <OpenAtTop/>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/frequently-asked-questions" element={<FAQ />} />
        </Routes>
      </Router>

    </>
  );
}

export default App;
