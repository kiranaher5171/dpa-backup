import React from 'react';
import SpinWheel from './SpinWheel';

const SpinTheWheel = () => {

  return (
    <>
      <SpinWheel />
    </>
  );
};

export default SpinTheWheel;
