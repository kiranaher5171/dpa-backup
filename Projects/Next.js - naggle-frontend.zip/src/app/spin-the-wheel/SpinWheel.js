'use client';

import React, { useRef, useState } from 'react';
import {
    Box,
    Button,
    Typography,
    Paper,
    Grid,
    Dialog,
    DialogContent,
    Slide,
    Radio,
    RadioGroup,
    FormControlLabel,
} from '@mui/material';
import Link from 'next/link';
import Confetti from 'react-confetti-boom';
import { useWindowSize } from 'react-use';
import MainLayout from '@/layouts/MainLayout';
import { useRouter } from 'next/navigation';




const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

export default function SpinWheel() {
    const wheelRef = useRef(null);
    const [spinning, setSpinning] = useState(false);
    const [rotation, setRotation] = useState(0);
    const [result, setResult] = useState(null);
    const [open, setOpen] = useState(false);
    const [selectedOption, setSelectedOption] = useState('');

    const router = useRouter();

    const { width, height } = useWindowSize();

    // 🎯 Wheel data
    const colors = ['#ff6b6b', '#ffb86b', '#ffd86b', '#6bffb8', '#6b8cff', '#ff88ff', '#00ff88', '#ffaa00', '#8855ff', '#00ffff'];
    const options = ['1', '2', '3', '4', '5'];

    // 🧠 Questions and answers
    const questions = {
        1: {
            question: 'Guess the amount of principal balance of all 7(a) loans',
            options: ['$50-100 Bn', '$100-150 Bn', '$150-200 Bn', '$250-350 Bn'],
        },
        2: {
            question: 'Top 3 states having most 7(a) loan approvals?',
            options: ['TX, NY, NJ', 'FL, GA, NC', 'CA, TX, FL', 'CA, OH, CO'],
        },
        3: {
            question: 'Percent of approvals in 2024 for women owned business:',
            options: ['8%', '25%', '15%', '40%'],
        },
        4: {
            question: 'In 2025, Hotels and Restaurants were the top two NAICS categories by gross 7(a) approvals. Which is the third category?',
            options: ['Dentists', 'Sports Centers', 'Auto Repair', 'Child Day Care'],
        },
        5: {
            question: 'In which interest rate bucket did most amount of 7(a) loans got approved in 2025?',
            options: ['10-10.5%', '9-9.5%', '10.5-11%', '8.5-9%'],
        },
    };

    const SEGMENTS = options.length;
    const DEG_PER_SEGMENT = 360 / SEGMENTS;

    // 🎡 Spin logic
    const spin = () => {
        if (spinning) return;
        setSpinning(true);
        setResult(null);
        setSelectedOption('');

        const pickedIndex = Math.floor(Math.random() * SEGMENTS);
        const fullSpins = 4;
        const segmentCenter = pickedIndex * DEG_PER_SEGMENT + DEG_PER_SEGMENT / 2;
        const rotationNeeded = fullSpins * 360 + (360 - segmentCenter);
        const finalRotation = rotation + rotationNeeded;
        setRotation(finalRotation);

        const onTransitionEnd = () => {
            const topAngle = 270;
            let bestIdx = 0;
            let bestDiff = 360;

            for (let i = 0; i < SEGMENTS; i++) {
                const originalCenter = i * DEG_PER_SEGMENT + DEG_PER_SEGMENT / 2;
                const displayed = (originalCenter + finalRotation) % 360;
                let diff = Math.abs(displayed - topAngle);
                if (diff > 180) diff = 360 - diff;
                if (diff < bestDiff) {
                    bestDiff = diff;
                    bestIdx = i;
                }
            }

            const chosenOption = options[bestIdx];
            setResult(chosenOption);
            setSpinning(false);
            setOpen(true);

            if (wheelRef.current) {
                wheelRef.current.removeEventListener('transitionend', onTransitionEnd);
            }
        };

        if (wheelRef.current) {
            wheelRef.current.addEventListener('transitionend', onTransitionEnd);
        }
    };

    const getWheelBackground = () => {
        return `conic-gradient(
            ${options.map((_, idx) => {
            const start = DEG_PER_SEGMENT * idx;
            const end = DEG_PER_SEGMENT * (idx + 1);
            const color = colors[idx % colors.length]; // cycle if options > colors
            return `${color} ${start}deg ${end}deg`;
        }).join(',\n')}
        )`;
    };


    const handleSubmitAnswer = () => {
        if (!selectedOption) {
            alert('Please select an option!');
            return;
        }
        console.log(`Question ${result} answered: ${selectedOption}`);
        // Redirect user after closing dialog
        setTimeout(() => {
            setOpen(false);
            router.push('/sba');
        }, 300); // small delay for smooth UX
    };

    // 🎨 Styles
    const wheelStyle = {
        width: 400,
        height: 400,
        borderRadius: '50%',
        border: '6px solid #ddd',
        //     background: `conic-gradient(
        //   #ff6b6b 0deg ${DEG_PER_SEGMENT}deg,
        //   #ffb86b ${DEG_PER_SEGMENT}deg ${DEG_PER_SEGMENT * 2}deg,
        //   #ffd86b ${DEG_PER_SEGMENT * 2}deg ${DEG_PER_SEGMENT * 3}deg,
        //   #6bffb8 ${DEG_PER_SEGMENT * 3}deg ${DEG_PER_SEGMENT * 4}deg,
        //   #6b8cff ${DEG_PER_SEGMENT * 4}deg 360deg
        // )`,
        background: getWheelBackground(),
        transform: `rotate(${rotation}deg)`,
        transition: spinning ? 'transform 3s cubic-bezier(0.25, 0.1, 0.25, 1)' : 'none',
        position: 'relative',
    };




    const labelCommon = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transformOrigin: '0 0',
        fontWeight: 700,
        color: '#111',
    };

    const spinButtonStyle = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        color: '#fff',
        cursor: spinning ? 'not-allowed' : 'pointer',
        zIndex: 5,
        boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    };

    return (
        <>
            {/* 🎉 Confetti */}
            {open && (
                <Confetti
                    mode="boom"
                    width={width}
                    height={height}
                    particleCount={400}
                    recycle={false}
                    gravity={0.3}
                    colors={['#1930AB', '#00B0F0', '#F9D923', '#FF5C8D', '#00FF9C']}
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        zIndex: 9999,
                        pointerEvents: 'none',
                    }}
                />
            )}

            <MainLayout>
                <Box py={5}>
                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <Grid size={10}>
                            <Box className="whitebox">
                                <Grid container spacing={2} justifyContent="center" alignItems="center">
                                    <Grid size={12}>
                                        <Paper
                                            sx={{
                                                p: 0,
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                flexDirection: 'column',
                                                boxShadow: 'none',
                                            }}
                                        >
                                            <Typography variant="h5" className="fw4 center black" mb={4} data-aos="fade-up" data-aos-duration="1000">
                                                Let's have a fun-check of your SBA Loan related knowledge. Spin the wheel for a surprize question.
                                            </Typography>

                                            <Box sx={{ display: 'flex', alignItems: 'center', position: 'relative' }} mb={4} data-aos="zoom-in" data-aos-duration="1200">
                                                <Box ref={wheelRef} style={wheelStyle}>
                                                    {/* {options.map((opt, idx) => {
                                                        const angle = idx * DEG_PER_SEGMENT + DEG_PER_SEGMENT / 2;
                                                        return (
                                                            <Box
                                                                key={opt}
                                                                sx={{
                                                                    ...labelCommon,
                                                                    transform: `rotate(${angle}deg) translate(120px) rotate(-${angle}deg)`,
                                                                    fontSize: 20,
                                                                }}
                                                            >
                                                                {opt}
                                                            </Box>
                                                        );
                                                    })} */}
                                                    {options.map((opt, idx) => {
                                                        const angle = idx * DEG_PER_SEGMENT + DEG_PER_SEGMENT / 3;
                                                        const radius = 165; // distance from center, adjust as needed

                                                        return (
                                                            <Box
                                                                key={opt}
                                                                sx={{
                                                                    ...labelCommon,
                                                                    transform: `rotate(${angle}deg) translate(${radius}px) rotate(-${angle}deg)`,
                                                                    fontSize: 20,
                                                                    textAlign: 'center',   // center text horizontally
                                                                }}
                                                            >
                                                                {opt}
                                                            </Box>
                                                        );
                                                    })}

                                                </Box>

                                                <Button className="spin-btn" onClick={spin} sx={spinButtonStyle} disableRipple>
                                                    <div className="triangle-up"></div>
                                                    <span className="btn-text">{spinning ? '...' : 'Spin'}</span>
                                                </Button>
                                            </Box>
                                        </Paper>
                                    </Grid>
                                </Grid>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>
            </MainLayout>

            {/* 🎯 Question Dialog */}
            <Dialog
                open={open}
                // onClose={() => setOpen(false)}
                TransitionComponent={Transition}
                keepMounted
                PaperProps={{
                    sx: {
                        borderRadius: '16px',
                        p: 2,
                        textAlign: 'center',
                        boxShadow: '0 8px 24px rgba(0,0,0,0.3)',
                    },
                }}
            >
                <DialogContent>
                    {result && (
                        <>
                            <Typography variant="h4" className='left fw6 black' mb={2}>
                                Question {result}:
                            </Typography>
                            <Typography variant="h5" className='center fw4 black' mb={4}>
                                {questions[result].question}
                            </Typography>

                            <RadioGroup
                                name={`question-${result}`}
                                value={selectedOption}
                                onChange={(e) => setSelectedOption(e.target.value)}
                            >
                                <Grid container spacing={2} justifyContent="center" alignItems="center">
                                    {questions[result].options.map((opt, idx) => (
                                        <Grid size={6} key={idx}>
                                            <FormControlLabel
                                                value={opt}
                                                control={<Radio color="primary" />}
                                                label={opt}
                                                sx={{ display: 'block', textAlign: 'left', mx: 2 }}
                                            />
                                        </Grid>
                                    ))}
                                </Grid>
                            </RadioGroup>

                            {/* <Box mt={5}>
                                <Button variant="contained" onClick={handleSubmitAnswer} className="primary-btn">
                                    Submit
                                </Button>
                            </Box> */}

                            <Box mt={5}>
                                {selectedOption && (
                                    <Button
                                        variant="contained"
                                        onClick={handleSubmitAnswer}
                                        className="primary-btn"
                                        disabled={!selectedOption}
                                        sx={{
                                            opacity: selectedOption ? 1 : 0.6,
                                            cursor: selectedOption ? 'pointer' : 'not-allowed',
                                        }}
                                    >
                                        Submit
                                    </Button>
                                )}
                            </Box>

                        </>
                    )}
                </DialogContent>
            </Dialog>
        </>
    );
}
