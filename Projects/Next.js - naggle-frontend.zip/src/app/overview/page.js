'use client';
import React from 'react';
import {
  Box,
  Typography,
  Container,
  Grid,
} from '@mui/material';
import MainLayout from '@/layouts/MainLayout';
import LOGO from '../../../public/assets/docuagentic.svg'
import Image from 'next/image';
import ProgressBar from '@/components/ProgressBar';


const Overview = () => {

  return (
    <>
      <MainLayout>
        <ProgressBar totalTime={8000} redirectTo="/quiz" />

        <Box py={5}>
          <Container maxWidth="lg">
            <Box sx={{ position: 'relative', zIndex: 10 }}>
              <Grid container spacing={2} justifyContent="center" alignItems="center">

                <Grid size={10}>
                  <Box className="left">
                    <Box pt={4} pb={3}>
                      <Image src={LOGO} height={50} width={'auto'} priority alt="Logo" data-aos="zoom-in" data-aos-duration="500"/>
                    </Box>

                    <Box>
                      <Typography variant='h5' className='fw4 black left' gutterBottom data-aos="fade-up" data-aos-duration="800">
                        We have developed a Agentic AI based solution - DocuAgentIQ - to automate your document verification and validation during the loan processing phase.
                      </Typography>
                    </Box>
                    <Box pt={2}>
                      <Typography variant='h5' className='fw4 black left' gutterBottom data-aos="fade-up" data-aos-duration="1000">
                        Before we show you how DocuAgentIQ does that, here's a fun activity for you to get acquainted with DocuagentIQ's capabilities!
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>

          </Container>
        </Box>

      </MainLayout>
    </>
  );
};

export default Overview;
