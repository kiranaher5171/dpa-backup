'use client';

import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  Grid,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Paper,
} from '@mui/material';
import MainLayout from '@/layouts/MainLayout';
import Link from 'next/link';
import { CgProfile } from "react-icons/cg";
import { MdOutlineEmail } from "react-icons/md";
import { HiOutlineIdentification } from "react-icons/hi";
import { GoOrganization } from "react-icons/go";
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import Leaderboard from '@/components/Leaderboard';

const VisitorForm = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    designation: '',
    organization: '',
  });

  const [openLeaderboard, setOpenLeaderboard] = useState(false);

  // ✅ Show leaderboard automatically on page load
  useEffect(() => {
    setOpenLeaderboard(true);
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handlePhoneChange = (phone) => {
    setForm({ ...form, phone });
  };

  // ✅ Sample leaderboard data
  const leaderboard = [
    { rank: 1, name: 'Amit Sharma', time: '12.4s' },
    { rank: 2, name: 'Priya Patel', time: '13.1s' },
    { rank: 3, name: 'Rohit Verma', time: '14.0s' },
    { rank: 4, name: 'Neha Singh', time: '14.9s' },
    { rank: 5, name: 'Arjun Mehta', time: '15.2s' },
  ];

  return (
    <MainLayout>
      {/* ✅ Leaderboard Dialog */}
      <Dialog
        id='dialog-2'
        open={openLeaderboard}
        // onClose={() => setOpenLeaderboard(false)}
        fullWidth
        maxWidth="xs"
        PaperProps={{
          sx: {
            borderRadius: '16px',
            p: 2,
            textAlign: 'center',
          },
        }}
      >
        <DialogContent>
          <Leaderboard />
        </DialogContent>

        <DialogActions sx={{ justifyContent: 'center', pb: 2 }}>
          <Button
            variant="contained"
            className="primary-btn"
            onClick={() => setOpenLeaderboard(false)}
          >
            Let's Play!
          </Button>
        </DialogActions>
      </Dialog>

      {/* ✅ Registration Form */}
      <Box py={5}>
        <Grid container spacing={3} justifyContent="center" alignItems="center">
          <Grid size={{ lg: 4, md: 6, sm: 9, xs: 10 }}>
            <Box className="whitebox" data-aos="fade-up" data-aos-duration="800">
              <Box mt={0} mb={4} className="center">
                <Typography variant="h5" className="fw5 center">
                  Registration
                </Typography>
              </Box>

              <Grid container spacing={4} justifyContent="center" alignItems="center">
                {/* Name */}
                <Grid size={12}>
                  <Box className="textfield">
                    <TextField
                      placeholder="Full Name"
                      variant="outlined"
                      fullWidth
                      autoFocus
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="end">
                            <CgProfile />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>

                {/* Email */}
                <Grid size={12}>
                  <Box className="textfield">
                    <TextField
                      placeholder="Email"
                      variant="outlined"
                      fullWidth
                      name="email"
                      type="email"
                      value={form.email}
                      onChange={handleChange}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="end">
                            <MdOutlineEmail />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>

                {/* Phone */}
                <Grid size={12}>
                  <Box>
                    <PhoneInput
                      country={'us'}
                      value={form.phone}
                      onChange={handlePhoneChange}
                      inputProps={{
                        name: 'phone',
                        required: true,
                        autoFocus: false,
                      }}
                      inputStyle={{
                        width: '100%',
                        height: '56px',
                        fontSize: '16px',
                        borderRadius: '4px',
                        borderColor: '#c4c4c4',
                      }}
                    />
                  </Box>
                </Grid>

                {/* Designation */}
                <Grid size={12}>
                  <Box className="textfield">
                    <TextField
                      placeholder="Designation"
                      variant="outlined"
                      fullWidth
                      name="designation"
                      value={form.designation}
                      onChange={handleChange}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="end">
                            <HiOutlineIdentification />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>

                {/* Organization */}
                <Grid size={12}>
                  <Box className="textfield">
                    <TextField
                      placeholder="Organization Name"
                      variant="outlined"
                      fullWidth
                      name="organization"
                      value={form.organization}
                      onChange={handleChange}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="end">
                            <GoOrganization />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>

                {/* Submit Button */}
                <Grid size={12}>
                  <Box className="center" py={1}>
                    <Link href="/overview">
                      <Button variant="contained" className="primary-btn">
                        Submit
                      </Button>
                    </Link>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </MainLayout>
  );
};

export default VisitorForm;
