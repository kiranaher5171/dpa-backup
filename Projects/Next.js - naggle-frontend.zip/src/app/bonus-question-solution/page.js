'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Box,
  Typography,
  Paper,
  Grid,
} from '@mui/material';
import MainLayout from '@/layouts/MainLayout';
import Image from 'next/image';
import ANSWER from '../../../public/assets/correct.png';

const page = () => {
  const router = useRouter();
  const [count, setCount] = useState(5); // countdown starts at 5 seconds

  useEffect(() => {
    const timer = setInterval(() => {
      setCount(prev => prev - 1);
    }, 1000);

    // Redirect after 5 seconds
    const redirectTimeout = setTimeout(() => {
      router.replace('/register');
    }, 5000);

    return () => {
      clearInterval(timer);
      clearTimeout(redirectTimeout);
    };
  }, [router]);

  return (
    <MainLayout>
      <Grid container spacing={2} justifyContent="center" alignItems="center">
        <Grid item xs={12} md={10}>
          <Box mt={'50px'}>
            <Paper
              sx={{
                p: 4,
                position: 'relative',
                zIndex: 10,
                width: '100%',
                margin: 'auto',
                borderRadius: 3,
                backgroundColor: 'transparent',
                boxShadow: 'none',
              }}
            >
              <Grid container spacing={2} justifyContent="center" alignItems="stretch">
                <Grid item xs={10}>
                  <Box className="center" mt={'-60px'}>

                    <Image src={ANSWER} alt='Solution Answer' style={{ height: '450px', width: 'auto', margin: 'auto' }} data-aos="zoom-in" data-aos-duration="1200" />

                    <Box mt={4}>
                      <Typography variant="h5" className="fw4 black center" gutterBottom data-aos="fade-up" data-aos-duration="1500">
                        Thank you for participating!
                      </Typography>
                      <Typography variant="h6" className="fw4 black center" data-aos="fade-up" data-aos-duration="1600">
                        Redirecting to the register page in <strong>{count}</strong> seconds...
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Paper>
          </Box>
        </Grid>
      </Grid>
    </MainLayout>
  );
};

export default page;
