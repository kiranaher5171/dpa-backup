'use client';

import React, { useState } from 'react';
import {
  Box,
  Button,
  Typography,
  Grid,
  Container,
  LinearProgress,
} from '@mui/material';
import MainLayout from '@/layouts/MainLayout';
import Link from 'next/link';
import ReactPlayer from 'react-player';

// ✅ Import the ProgressBar component
import ProgressBar from '@/components/ProgressBar'; // update this path as per your project

const SBA = () => {
  const [showVideo, setShowVideo] = useState(false);

  return (
    <MainLayout>
      <ProgressBar
        totalTime={4000} // 4 seconds
        redirectTo={null} // disable redirect
        onComplete={() => setShowVideo(true)} // custom callback
      />

      <Box my={5}>
        <Container maxWidth>

          {/* ✅ Default View (visible first) */}
          {!showVideo && (
            <Box>
              <Grid container spacing={2} justifyContent="center" alignItems="center">
                <Grid size={10}>
                  <Box className="whitebo" sx={{ position: 'relative', zIndex: 10 }}>
                    <Box className="center" pt={16}>
                      <Typography variant="h5" className="fw4 black center" gutterBottom data-aos="fade-up" data-aos-duration="800">
                        Before we tell you the right answer, here's a quick overview of our SBA services!
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          )}

          {/* ✅ Video View (visible after progress completes) */}
          {showVideo && (
            <>
              <Box className="whitebox-2">
                <Box className="center">
                  <ReactPlayer src='https://youtu.be/L7La07dcgOI?si=QAtSujda8EmFnW4b' controls={true} autoPlay={true}
                    style={{
                      width: "100%",
                      height: 'auto', aspectRatio: '16/9',
                    }} />
                </Box>
              </Box>

              <Box mt={4} className="center" sx={{ position: 'relative', zIndex: 10 }}>
                <Link href="/bonus-question-solution">
                  <Button variant="contained" className="primary-btn">
                    See Your Answer
                  </Button>
                </Link>
              </Box>
            </>
          )}

        </Container>
      </Box>
    </MainLayout>
  );
};

export default SBA;
