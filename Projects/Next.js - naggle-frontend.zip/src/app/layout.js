import "./globals.css";
import ThemeProviderComponent from "@/components/ThemeProviderComponent";
import localFont from "next/font/local";
import Image from "next/image";
import Shape1 from "../../public/assets/body-shape1.svg"
import Shape2 from "../../public/assets/body-shape2.svg"

// Consolidate Poppins fonts into one variable with only needed weights
const poppins = localFont({
  src: [
    {
      path: "../../public/fonts/Poppins-Thin.ttf",
      weight: "100",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins-Light.ttf",
      weight: "300",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins-Regular.ttf",
      weight: "400",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins-SemiBold.ttf",
      weight: "500",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins-Bold.ttf",
      weight: "600",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins-ExtraBold.ttf",
      weight: "700",
      style: "normal",
    },
  ],
  display: "swap", // This tells the browser to use fallback fonts until the custom font is loaded
  variable: "--font-poppins",
});

// Export a viewport function to configure the viewport meta tag
export const viewport = "width=device-width, initial-scale=1";

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${poppins.variable}`}>
      <body className={poppins.className}>
        <ThemeProviderComponent>
          <Image src={Shape1} className="body-shape-1" alt="Shape 1" />
          <Image src={Shape2} className="body-shape-2" alt="Shape 2" />
          {children}
        </ThemeProviderComponent>
      </body>
    </html>
  );
}
