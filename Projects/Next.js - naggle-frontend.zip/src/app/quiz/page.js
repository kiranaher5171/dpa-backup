'use client';

import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Typography,
  Grid,
  RadioGroup,
} from '@mui/material';
import MainLayout from '@/layouts/MainLayout';
import Link from 'next/link';
// import OptionBox from '@/components/OptionBox';

import IA1 from '../../../public/assets/quiz/icon-01.png';
import IA2 from '../../../public/assets/quiz/icon-02.png';
import IA3 from '../../../public/assets/quiz/icon-03.png';
import IA4 from '../../../public/assets/quiz/icon-04.png';

import IB1 from '../../../public/assets/quiz/q2-1.png';
import IB2 from '../../../public/assets/quiz/q2-2.png';
import IB3 from '../../../public/assets/quiz/q2-3.png';
import IB4 from '../../../public/assets/quiz/q2-4.png';


import OptionBox from './OptionBox';

const Quiz = () => {
  const [selectedValue, setSelectedValue] = useState('');
  const [questionData, setQuestionData] = useState(null);


  const options = [
    { value: '0x Faster', label: '0x Faster', frontImg: IA1 },
    { value: '2x Faster', label: '2x Faster', frontImg: IA2 },
    { value: '4x Faster', label: '4x Faster', frontImg: IA3 },
    { value: '6x Faster', label: '6x Faster', frontImg: IA4 },
  ];


  // Define your quiz questions and options
  const questions = [
    {
      id: 1,
      question:
        'How much faster can a broker review loan documents using DocuAgentIQ compared to doing it manually?',
      options: [
        { value: '0x Faster', label: '0x Faster', frontImg: IA1 },
        { value: '2x Faster', label: '2x Faster', frontImg: IA2 },
        { value: '4x Faster', label: '4x Faster', frontImg: IA3 },
        { value: '6x Faster', label: '6x Faster', frontImg: IA4 },
      ],
    },
    {
      id: 2,
      question:
        'How many document errors does DocuAgentIQ typically catch before a broker even sees the file?',
      options: [
        { value: '30% of errors', label: '30% of errors', frontImg: IB1 },
        { value: '50% of errors', label: '50% of errors', frontImg: IB2 },
        { value: '65% of errors', label: '65% of errors', frontImg: IB3 },
        { value: '85% of errors', label: '85% of errors', frontImg: IB4 },
      ],
    },
  ];

  // Pick a random question on page load
  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * questions.length);
    setQuestionData(questions[randomIndex]);
  }, []);

  if (!questionData) return null; // wait till question loads



  return (
    <MainLayout>
      <Box py={5}>
        <Grid container spacing={2} justifyContent="center" alignItems="center">
          <Grid size={10}>
            <Box className="whitebox">
              <Box className="center">
                <Typography variant="h5" className="fw4 black center" gutterBottom data-aos="fade-up" data-aos-duration="800">
                  {questionData.question}
                </Typography>

                <Box className="options_box">
                  <RadioGroup
                    row
                    aria-label="quiz"
                    name="quiz"
                    value={selectedValue}
                    onChange={(e) => setSelectedValue(e.target.value)}
                  >
                    <Grid container spacing={1} justifyContent="center">
                      {questionData.options.map((opt) => (
                        <Grid size={6} key={opt.value} data-aos="fade-up" data-aos-duration="1200">
                          <OptionBox
                            {...opt}
                            selectedValue={selectedValue}
                            setSelectedValue={setSelectedValue}
                          />
                        </Grid>
                      ))}
                    </Grid>
                  </RadioGroup>
                </Box>

                {selectedValue && (
                  <Link href="/docu-agentic">
                    <Button
                      variant="contained"
                      className="primary-btn"
                      disabled={!selectedValue}
                    >
                      Submit
                    </Button>
                  </Link>
                )}

              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </MainLayout>
  );
};

export default Quiz;
