'use client';

import React from 'react';
import { Box, FormControlLabel, Radio } from '@mui/material';
import Image from 'next/image';

export default function OptionBox({
  frontImg,
  // backImg,
  value,
  label,
  selectedValue,
  setSelectedValue,
}) {
  const handleSelect = () => {
    setSelectedValue(value);
  };

  return (
    <Box
      className="option_box1 al_center"
      onClick={handleSelect} // 👈 entire box clickable
      sx={{
        cursor: 'pointer',
        userSelect: 'none',
        p: 1,
        borderRadius: 2,
        transition: '0.3s ease',
      }}
    >
      <Box>
        <Box>
          <Image src={frontImg} className="front" height={110} width={'auto'} alt="flipper front" />
        </Box>

        <FormControlLabel
          value={value}
          control={
            <Radio
              color="primary"
              checked={selectedValue === value}
              onChange={handleSelect}
            />
          }
          label={label}
          labelPlacement="bottom"
        />
      </Box>
    </Box>
  );
}
