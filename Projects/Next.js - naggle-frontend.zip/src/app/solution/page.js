'use client';

import React, { useState } from 'react';
import {
  Box,
  Button,
  Typography,
  Grid,
} from '@mui/material';
import MainLayout from '@/layouts/MainLayout';
import Link from 'next/link';
import Image from 'next/image';
import ANSWER from '../../../public/assets/correct.png';


const Solution = () => {


  return (
    <>
      <MainLayout>


        <Box my={5}>
          <Grid container spacing={2} justifyContent="center" alignItems="center">
            <Grid size={10}>
              <Box className="whitebox10" sx={{ position: 'relative', zIndex: 10 }}>
                <Box className="center" mt={'-60px'}>
                  <Image src={ANSWER} alt='Solution Answer' style={{ height: '450px', width: 'auto', margin: 'auto' }} data-aos="zoom-in" data-aos-duration="1200" />

                  <Typography variant='h5' className='fw4 black center' gutterBottom data-aos="fade-up" data-aos-duration="1500">
                    Here's a bonus question for you to try winning again!
                  </Typography>
                </Box>
                <Box mt={4} className="center" data-aos="fade-up" data-aos-duration="1500">
                  <Link href={'/spin-the-wheel'}>
                    <Button variant='contained' className='primary-btn'>Let's Start</Button>
                  </Link>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Box>

      </MainLayout>

    </>
  );
};

export default Solution;
