'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Box,
  Button,
  TextField,
  Typography,
  Paper,
  Snackbar,
  Alert,
  CircularProgress,
  InputAdornment,
  IconButton,
  Grid,
} from '@mui/material';
import { AiOutlineEye, AiOutlineEyeInvisible } from 'react-icons/ai';
import Link from 'next/link';
import { FaRegUser } from "react-icons/fa6";
import { RiUserLine } from "react-icons/ri";
import { RiLockPasswordLine } from "react-icons/ri";
import Image from 'next/image';
import LOGO from '../../public/assets/logo.svg'

import Shape1 from "../../public/assets/body-shape1.svg"
import Shape2 from "../../public/assets/body-shape2.svg"



const LoginPage = () => {
  const router = useRouter();

  const [form, setForm] = useState({ empCode: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'info',
  });
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };


  const toggleShowPassword = () => setShowPassword((prev) => !prev);

  return (
    <Box className="auth-page">

      <Grid container spacing={2} justifyContent="center" alignItems="stretch">
        <Grid size={8}>
          <Box className="whitebox center">

            <Image src={LOGO} height={80} width={'auto'} alt="Logo" priority style={{ margin: 'auto' }} />

            <Typography variant="h2" className='fw5' mt={3} mb={5}>
              Login
            </Typography>

            <Box p={3}>
              <Grid container spacing={4} justifyContent="center" alignItems="center">
                <Grid size={12}>
                  <Box className="textfield">
                    <TextField
                      placeholder="Employee Code"
                      variant="outlined"
                      fullWidth
                      autoFocus
                      name="empCode"
                      value={form.empCode}
                      onChange={handleChange}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="end">
                            <RiUserLine />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>

                <Grid size={12}>
                  <Box className="textfield">
                    <TextField
                      placeholder="Password"
                      variant="outlined"
                      fullWidth
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      value={form.password}
                      onChange={handleChange}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="end">
                            <RiLockPasswordLine />
                          </InputAdornment>
                        ),
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton onClick={toggleShowPassword} edge="end">
                              {showPassword ? (
                                <AiOutlineEyeInvisible />
                              ) : (
                                <AiOutlineEye />
                              )}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>

                <Grid size={12}>
                  <Box py={3}>
                    <Link href="/register">
                      <Button
                        fullWidth
                        variant="contained"
                        className='primary-btn'
                        disabled={loading}
                      >
                        {loading ? <CircularProgress size={24} color="inherit" /> : 'Login'}
                      </Button>
                    </Link>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Grid>
      </Grid>

    </Box>
  );
};

export default LoginPage;
