import { Typography } from '@mui/material'
import React from 'react'

const Footer = () => {
    return (
        <>
            <Typography variant='h6' className='footer-line'>
                ©2025 <a href="https://decimalpointanalytics.com/" target='_blank' className='fw6 primary'>Decimal Point Analytics</a> Pvt. Ltd.
            </Typography>
        </>
    )
}

export default Footer