import React from 'react';
import {
    Box,
    Typography,
    Paper,
} from '@mui/material';

const Leaderboard = () => {

    // ✅ Sample leaderboard data
    const leaderboard = [
        { rank: 1, name: 'Amit Sharma', time: '12.4s' },
        { rank: 2, name: 'Priya Patel', time: '13.1s' },
        { rank: 3, name: 'Rohit Verma', time: '14.0s' },
        { rank: 4, name: 'Neha Singh', time: '14.9s' },
        { rank: 5, name: 'Arjun Mehta', time: '15.2s' },
    ];

    return (
        <>
            <Box pb={3}>
                <Typography variant="h5" className="fw5 center" gutterBottom>
                    🏆 Leaderboard
                </Typography>
                <Typography variant="h6" color="text.secondary">
                    Top 5 performers so far!
                </Typography>
            </Box>

            {leaderboard.map((player) => (
                <Paper
                    key={player.rank}
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        p: 2,
                        mb: 2,
                        borderRadius: '12px',
                        backgroundColor:
                            player.rank === 1
                                ? '#FFF7D1'
                                : player.rank === 2
                                    ? '#E6F3FF'
                                    : player.rank === 3
                                        ? '#FCE4EC'
                                        : '#F8F9FA',
                    }}
                >
                    <Typography variant="h4" className='fw5 black'>
                        #{player.rank} {player.name}
                    </Typography>
                    <Typography variant="h4" className='fw5 black'>
                        ⏱ {player.time}
                    </Typography>
                </Paper>
            ))}
        </>
    );
};

export default Leaderboard;
