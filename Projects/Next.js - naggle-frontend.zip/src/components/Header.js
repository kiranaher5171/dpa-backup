import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Image from 'next/image';
import LOGO from '../../public/assets/logo.svg'
import { FiLogOut } from "react-icons/fi";
import Link from 'next/link';
import Leaderboard from './Leaderboard';
import { Dialog, DialogActions, DialogContent } from '@mui/material';

export default function Header() {
    const [openLeaderboard, setOpenLeaderboard] = React.useState(false);

    return (
        <>
            <Box sx={{ flexGrow: 1 }}>
                <AppBar position="fixed">
                    <Toolbar>
                        <>
                            <Link href={"/"}>
                                <Image src={LOGO} height={60} width={'auto'} priority alt="Logo" />
                            </Link>
                        </>
                        {/* Right Side - Employee Info */}
                        <Box sx={{ width: '100%', textAlign: 'right', display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 2 }}>
                            <Button onClick={() => setOpenLeaderboard(true)} className='secondary-btn'>🏆 Leaderboard</Button>
                            <Link href={"/"}>
                                <IconButton className='log-out'>
                                    <FiLogOut />
                                </IconButton>
                            </Link>
                        </Box>
                    </Toolbar>
                </AppBar>
            </Box>

            <Dialog
                id='dialog-2'
                open={openLeaderboard}
                fullWidth
                maxWidth="xs"
                PaperProps={{
                    sx: {
                        borderRadius: '16px',
                        p: 2,
                        textAlign: 'center',
                    },
                }}
            >
                <DialogContent>
                    <Leaderboard />
                </DialogContent>

                <DialogActions sx={{ justifyContent: 'center', pb: 2 }}>
                    <Button
                        variant="contained"
                        className="primary-btn"
                        onClick={() => setOpenLeaderboard(false)}
                    >
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
}
