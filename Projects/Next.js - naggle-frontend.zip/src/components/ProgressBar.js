'use client';

import React, { useEffect, useState } from 'react';
import LinearProgress from '@mui/material/LinearProgress';
import Box from '@mui/material/Box';
import { useRouter } from 'next/navigation';

const ProgressBar = ({ totalTime = 5000, redirectTo = '/', onComplete }) => {
    const [progress, setProgress] = useState(0);
    const router = useRouter();

    useEffect(() => {
        const intervalTime = 50;
        const increment = (intervalTime / totalTime) * 100;

        const interval = setInterval(() => {
            setProgress((oldProgress) => {
                const newProgress = oldProgress + increment;
                return newProgress > 100 ? 100 : newProgress;
            });
        }, intervalTime);

        return () => clearInterval(interval);
    }, [totalTime]);

    // ✅ When done: trigger callback or redirect
    useEffect(() => {
        if (progress >= 100) {
            if (onComplete) onComplete();
            else if (redirectTo) router.push(redirectTo);
        }
    }, [progress, redirectTo, router, onComplete]);

    return (
        <Box sx={{ width: '100%' }} mt={'-2px'}>
            <LinearProgress variant="determinate" value={progress} />
        </Box>
    );
};

export default ProgressBar;
