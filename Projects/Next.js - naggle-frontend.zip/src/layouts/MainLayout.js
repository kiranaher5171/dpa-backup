"use client";
import React, { useEffect } from 'react'
import Footer from '@/components/Footer'
import Header from '@/components/Header'
import { Box, Container, Grid, Typography } from '@mui/material'
import AOS from "aos";
import "aos/dist/aos.css";

const MainLayout = ({ children }) => {

    useEffect(() => {
        AOS.init();
    }, []);


    return (
        <>
            <Header />
            <Box className="main-layout-bg">

                <Box className="main-heading-box">
                    {/* <Box className="main-overlay" /> */}
                    <Container maxWidth className='zIndex2'>
                        <Grid container spacing={2} justifyContent="center" alignItems="center">
                            <Grid size={{ lg: 8, md: 8, sm: 10, xs: 10 }}>
                                <Box pt={3} pb={3}>
                                    <Typography variant='h2' className='fw6 white center' data-aos="fade-down" data-aos-duration="500" >
                                        Welcome to Decimal Point Analytics
                                    </Typography>
                                    <Typography variant='h4' className='fw4 white center' data-aos="fade-down" data-aos-duration="600" >
                                        From Data to Decisions: <br />
                                        <strong>AI</strong>-Driven Analytics, Tailored for Your Business
                                    </Typography>
                                </Box>
                            </Grid>
                        </Grid>
                    </Container>
                </Box>

                {children}

            </Box>
            <Footer />
        </>
    )
}

export default MainLayout