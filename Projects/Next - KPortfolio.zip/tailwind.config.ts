import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-syne)', 'serif'],
        body: ['var(--font-dm-sans)', 'sans-serif'],
        mono: ['var(--font-dm-mono)', 'monospace'],
      },
      colors: {
        ink: {
          950: '#080808',
          900: '#0f0f0f',
          800: '#161616',
          700: '#1e1e1e',
          600: '#2a2a2a',
          500: '#3a3a3a',
          400: '#555555',
          300: '#888888',
          200: '#aaaaaa',
          100: '#cccccc',
          50:  '#f0f0f0',
        },
        gold: {
          DEFAULT: '#C9972B',
          light:   '#E8B84B',
          dark:    '#9A6F14',
          muted:   '#7A5A28',
          faint:   '#2A1E08',
        },
      },
      keyframes: {
        'fade-up': {
          '0%':   { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        shimmer: {
          '0%':   { backgroundPosition: '-200% center' },
          '100%': { backgroundPosition: '200% center' },
        },
        'line-grow': {
          '0%':   { scaleX: '0' },
          '100%': { scaleX: '1' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%':      { transform: 'translateY(-8px)' },
        },
      },
      animation: {
        'fade-up':   'fade-up 0.7s ease forwards',
        'fade-in':   'fade-in 0.6s ease forwards',
        shimmer:     'shimmer 3s linear infinite',
        'line-grow': 'line-grow 0.8s ease forwards',
        float:       'float 6s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}

export default config
