import Navbar     from '@/components/Navbar'
import Hero        from '@/components/Hero'
import About       from '@/components/About'
import Skills      from '@/components/Skills'
import Experience  from '@/components/Experience'
import Projects    from '@/components/Projects'
import Education   from '@/components/Education'
import Contact     from '@/components/Contact'

/**
 * Root page — composes every portfolio section.
 * The static export (output: 'export' in next.config.js) means
 * `next build` produces a fully self-contained /out directory.
 */
export default function Home() {
  return (
    <main className="font-body text-ink-50 bg-ink-900 overflow-x-hidden">
      <Navbar />
      <Hero />
      <About />
      <Skills />
      <Experience />
      <Projects />
      <Education />
      <Contact />
    </main>
  )
}
