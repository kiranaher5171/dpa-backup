import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Kiran Aher — Executive Frontend Developer',
  description:
    'Executive Frontend Developer specializing in React JS, Angular, Next.js, and building high-performance, responsive web applications.',
  keywords: ['React', 'Next.js', 'Angular', 'Frontend Developer', 'UI Developer', 'Kiran Aher'],
  authors: [{ name: 'Kiran Atmaram Aher' }],
  openGraph: {
    title: 'Kiran Aher — Executive Frontend Developer',
    description: 'Building high-performance, responsive web applications.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
