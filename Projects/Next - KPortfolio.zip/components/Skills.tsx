'use client'

import { useReveal } from './useReveal'

const skillGroups = [
  {
    category: 'Frontend',
    icon: '⬡',
    skills: [
      'HTML5', 'CSS3', 'Tailwind CSS', 'Bootstrap',
      'Material UI', 'JavaScript (ES6+)', 'React JS',
      'Next JS', 'Angular', 'HTML Email Templates',
    ],
  },
  {
    category: 'Tools & Workflow',
    icon: '◈',
    skills: [
      'Git', 'GitHub', 'Bitbucket', 'ClickUp',
      'AG-Grid', 'Responsive Design', 'SonarQube',
      'Code Review', 'Figma (handoff)',
    ],
  },
  {
    category: 'Backend / Data (Learning)',
    icon: '◇',
    skills: ['Python', 'SQL'],
  },
]

export default function Skills() {
  const ref = useReveal()

  return (
    <section id="skills" className="py-28 bg-ink-900 relative overflow-hidden">
      {/* Decorative blobs */}
      <div
        className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(201,151,43,0.05) 0%, transparent 70%)' }}
      />

      <div ref={ref as React.RefObject<HTMLDivElement>} className="max-w-7xl mx-auto px-6 lg:px-12 reveal">
        <div className="section-eyebrow mb-5">Technical Skills</div>
        <h2 className="font-display font-bold text-4xl lg:text-5xl text-ink-50 mb-14 leading-tight">
          My Toolkit
        </h2>

        <div className="flex flex-col gap-12">
          {skillGroups.map((group) => (
            <div key={group.category}>
              {/* Category header */}
              <div className="flex items-center gap-3 mb-5">
                <span className="text-gold font-mono text-lg">{group.icon}</span>
                <h3 className="font-display font-semibold text-ink-200 text-lg tracking-wide">
                  {group.category}
                </h3>
                <div className="flex-1 h-px bg-ink-700 ml-2" />
              </div>

              {/* Chips */}
              <div className="flex flex-wrap gap-2.5">
                {group.skills.map((skill) => (
                  <span key={skill} className="skill-chip">{skill}</span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Progress visual for key skills */}
        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { name: 'React JS',   pct: 90 },
            { name: 'Next.js',    pct: 82 },
            { name: 'Angular',    pct: 75 },
            { name: 'TypeScript', pct: 72 },
          ].map(item => (
            <div key={item.name} className="card-dark p-5 rounded-md">
              <div className="flex justify-between items-end mb-2">
                <span className="font-body text-sm font-medium text-ink-100">{item.name}</span>
                <span className="font-mono text-xs text-gold">{item.pct}%</span>
              </div>
              <div className="h-1 bg-ink-700 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${item.pct}%`,
                    background: 'linear-gradient(90deg, #9A6F14, #E8B84B)',
                    transition: 'width 1s ease',
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
