'use client'

import { Mountain, Cpu } from 'lucide-react'
import { useReveal } from './useReveal'

export default function About() {
  const ref = useReveal()

  return (
    <section id="about" className="py-28 bg-ink-950 relative">
      {/* Side decoration */}
      <div
        className="absolute right-0 top-0 bottom-0 w-px opacity-20"
        style={{ background: 'linear-gradient(to bottom, transparent, #C9972B 40%, transparent)' }}
      />

      <div ref={ref as React.RefObject<HTMLDivElement>} className="max-w-7xl mx-auto px-6 lg:px-12 reveal">
        <div className="grid lg:grid-cols-2 gap-16 items-start">

          {/* Left column */}
          <div>
            <div className="section-eyebrow mb-5">About Me</div>
            <h2 className="font-display font-bold text-4xl lg:text-5xl text-ink-50 mb-8 leading-tight">
              Crafting interfaces <br />
              <span className="shimmer-text">people love to use</span>
            </h2>

            <p className="font-body text-ink-300 leading-relaxed mb-5 text-base">
              I&apos;m a Frontend Developer with <span className="text-gold font-medium">2.9+ years of hands-on experience</span> designing
              and engineering responsive web applications. My work sits at the intersection of engineering
              and design — I translate complex requirements and design mockups into polished, production-ready
              interfaces.
            </p>
            <p className="font-body text-ink-300 leading-relaxed mb-5 text-base">
              Proficient with <span className="text-gold font-medium">Bootstrap</span> and{' '}
              <span className="text-gold font-medium">Material-UI</span>, I bring a strong UI/UX sensibility
              to every project — building reusable component libraries, optimizing rendering performance, and
              maintaining code quality through regular reviews and automated scans.
            </p>
            <p className="font-body text-ink-300 leading-relaxed text-base">
              I&apos;m actively expanding toward full-stack development, deepening my knowledge in{' '}
              <span className="text-gold font-medium">Python</span> and{' '}
              <span className="text-gold font-medium">SQL</span>, and staying at the frontier of modern
              web technologies to deliver end-to-end solutions.
            </p>
          </div>

          {/* Right column */}
          <div className="flex flex-col gap-6">
            {/* Beyond Coding card */}
            <div className="card-dark p-7 rounded-md">
              <h3 className="font-display font-semibold text-lg text-ink-50 mb-4 flex items-center gap-2">
                <span className="text-gold">✦</span> Beyond Coding
              </h3>
              <div className="flex flex-col gap-5">
                {/* Trekking */}
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-9 h-9 rounded-sm bg-gold-faint border border-gold/20 flex items-center justify-center mt-0.5">
                    <Mountain size={16} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="font-body font-semibold text-ink-100 text-sm mb-1">High-Altitude Trekking</h4>
                    <p className="font-body text-ink-400 text-sm leading-relaxed">
                      Passionate about the mountains — I&apos;ve trekked routes across Maharashtra and completed
                      the Hampta Pass crossing in Himachal Pradesh. The discipline and patience trekking demands
                      translates directly into my engineering mindset.
                    </p>
                  </div>
                </div>

                {/* AI & Tourism */}
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-9 h-9 rounded-sm bg-gold-faint border border-gold/20 flex items-center justify-center mt-0.5">
                    <Cpu size={16} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="font-body font-semibold text-ink-100 text-sm mb-1">AI & Smart Tourism</h4>
                    <p className="font-body text-ink-400 text-sm leading-relaxed">
                      Fascinated by the intersection of artificial intelligence and tourism — exploring how
                      AI can personalise travel experiences and help discover hidden destinations.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick facts */}
            <div className="card-dark p-7 rounded-md">
              <h3 className="font-display font-semibold text-lg text-ink-50 mb-5 flex items-center gap-2">
                <span className="text-gold">✦</span> Quick Facts
              </h3>
              <dl className="grid grid-cols-2 gap-x-6 gap-y-4">
                {[
                  { label: 'Location',     value: 'Nashik, India' },
                  { label: 'Experience',   value: '2.9+ Years' },
                  { label: 'Focus',        value: 'Frontend / UI' },
                  { label: 'Availability', value: 'Open to Roles' },
                ].map(f => (
                  <div key={f.label}>
                    <dt className="font-mono text-xs text-ink-500 tracking-widest uppercase mb-1">{f.label}</dt>
                    <dd className="font-body text-ink-100 text-sm font-medium">{f.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
