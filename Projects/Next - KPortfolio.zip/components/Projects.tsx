'use client'

import { ExternalLink, Github, Globe, ShoppingCart, BarChart3 } from 'lucide-react'
import { useReveal } from './useReveal'

const projects = [
  {
    title:    'PoliceMart',
    subtitle: 'E-Commerce Portal — Next.js',
    icon:     <ShoppingCart size={22} className="text-gold" />,
    tags:     ['Next.js', 'React', 'TypeScript', 'Material UI', 'REST API'],
    description:
      'A specialised procurement portal for law enforcement — enabling officers and departments to order authorised equipment, uniforms, and supplies. Built with Next.js App Router, server-side rendering for SEO, and a fully responsive Material UI design system.',
    highlights: [
      'Built with Next.js 14 App Router and server components for optimal performance',
      'Role-based access control for officers, admins, and procurement teams',
      'Integrated inventory management and order tracking dashboards',
      'Responsive design across desktop, tablet, and mobile form factors',
    ],
    status:   'Live',
    statusColor: 'text-emerald-400',
    live:     '#',
    github:   null,
  },
  {
    title:    'Analytics Dashboard',
    subtitle: 'Data Visualisation Platform — React',
    icon:     <BarChart3 size={22} className="text-gold" />,
    tags:     ['React JS', 'AG-Grid', 'Material UI', 'Recharts', 'REST API'],
    description:
      'A high-performance analytics dashboard for financial data analysis. Features large dataset handling via AG-Grid with virtual scrolling, custom chart components using Recharts, and complex filtering UX. Reduced load time by 30% through code-splitting and memoisation.',
    highlights: [
      'AG-Grid integration for handling 100k+ row datasets with virtual scroll',
      'Real-time chart updates with Recharts and custom hooks',
      'Advanced filter panels with compound query support',
      'Sonar-clean codebase with 90%+ test coverage',
    ],
    status:   'In Development',
    statusColor: 'text-amber-400',
    live:     '#',
    github:   '#',
  },
]

export default function Projects() {
  const ref = useReveal()

  return (
    <section id="projects" className="py-28 bg-ink-900 relative overflow-hidden">
      {/* Decorative */}
      <div
        className="absolute top-0 right-0 w-96 h-96 pointer-events-none"
        style={{ background: 'radial-gradient(circle at 100% 0%, rgba(201,151,43,0.05) 0%, transparent 60%)' }}
      />

      <div ref={ref as React.RefObject<HTMLDivElement>} className="max-w-7xl mx-auto px-6 lg:px-12 reveal">
        <div className="section-eyebrow mb-5">Selected Work</div>
        <h2 className="font-display font-bold text-4xl lg:text-5xl text-ink-50 mb-4 leading-tight">
          Projects
        </h2>
        <p className="font-body text-ink-400 text-base mb-14 max-w-xl">
          A selection of production projects and experiments — each one a lesson in craft, performance, and user experience.
        </p>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((p) => (
            <article key={p.title} className="card-dark rounded-lg overflow-hidden flex flex-col">
              {/* Card header band */}
              <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, #9A6F14, #E8B84B, #9A6F14)' }} />

              <div className="p-7 flex flex-col flex-1">
                {/* Icon + title */}
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-sm bg-gold-faint border border-gold/20 flex items-center justify-center flex-shrink-0">
                      {p.icon}
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-xl text-ink-50">{p.title}</h3>
                      <p className="font-mono text-xs text-ink-500 tracking-wider">{p.subtitle}</p>
                    </div>
                  </div>
                  <span className={`font-mono text-xs ${p.statusColor} flex items-center gap-1.5 flex-shrink-0 mt-1`}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
                    {p.status}
                  </span>
                </div>

                {/* Description */}
                <p className="font-body text-ink-400 text-sm leading-relaxed mb-5">{p.description}</p>

                {/* Highlights */}
                <ul className="flex flex-col gap-2 mb-6 flex-1">
                  {p.highlights.map((h, i) => (
                    <li key={i} className="flex gap-2.5 text-xs text-ink-400 leading-relaxed">
                      <span className="text-gold/60 mt-0.5 flex-shrink-0">◆</span>
                      {h}
                    </li>
                  ))}
                </ul>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 mb-6">
                  {p.tags.map(t => (
                    <span
                      key={t}
                      className="font-mono text-xs bg-ink-800 border border-ink-600 text-ink-300 px-2.5 py-1 rounded-sm"
                    >
                      {t}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="flex gap-3 mt-auto pt-4 border-t border-ink-700">
                  {p.live && (
                    <a href={p.live} className="flex items-center gap-1.5 text-xs font-mono text-gold hover:text-gold-light transition-colors">
                      <Globe size={12} /> Live Site
                    </a>
                  )}
                  {p.github && (
                    <a href={p.github} className="flex items-center gap-1.5 text-xs font-mono text-ink-400 hover:text-ink-100 transition-colors">
                      <Github size={12} /> Source
                    </a>
                  )}
                  <span className="ml-auto">
                    <ExternalLink size={14} className="text-ink-600" />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
