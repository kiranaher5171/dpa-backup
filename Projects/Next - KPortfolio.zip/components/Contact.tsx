'use client'

import { Mail, Phone, Linkedin, Send, MapPin, ArrowUpRight } from 'lucide-react'
import { useReveal } from './useReveal'

export default function Contact() {
  const ref = useReveal()

  return (
    <>
      {/* ── Contact ── */}
      <section id="contact" className="py-28 bg-ink-900 relative overflow-hidden">
        {/* Background glow */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full pointer-events-none"
          style={{ background: 'radial-gradient(circle, rgba(201,151,43,0.04) 0%, transparent 65%)' }}
        />

        <div ref={ref as React.RefObject<HTMLDivElement>} className="max-w-7xl mx-auto px-6 lg:px-12 reveal">
          <div className="max-w-2xl mx-auto text-center mb-16">
            <div className="section-eyebrow mb-5 justify-center">
              <span className="flex-1 h-px bg-gold max-w-12" />
              Get In Touch
            </div>
            <h2 className="font-display font-bold text-4xl lg:text-5xl text-ink-50 mb-5 leading-tight">
              Let&apos;s Build Something
              <br />
              <span className="shimmer-text">Great Together</span>
            </h2>
            <p className="font-body text-ink-400 text-base leading-relaxed">
              I&apos;m currently open to new opportunities — whether it&apos;s a full-time role,
              freelance collaboration, or just a conversation about frontend craft.
            </p>
          </div>

          {/* Contact cards */}
          <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto mb-12">
            {[
              {
                icon:    <Mail size={20} className="text-gold" />,
                label:   'Email',
                value:   'kiranaher5171@gmail.com',
                href:    'mailto:kiranaher5171@gmail.com',
              },
              {
                icon:    <Phone size={20} className="text-gold" />,
                label:   'Phone',
                value:   '+91 72649 65171',
                href:    'tel:+917264965171',
              },
              {
                icon:    <Linkedin size={20} className="text-gold" />,
                label:   'LinkedIn',
                value:   'kiran-aher-96k',
                href:    'https://www.linkedin.com/in/kiran-aher-96k/',
              },
            ].map(c => (
              <a
                key={c.label}
                href={c.href}
                target={c.label === 'LinkedIn' ? '_blank' : undefined}
                rel="noopener noreferrer"
                className="card-dark rounded-lg p-6 flex flex-col items-center text-center group"
              >
                <div className="w-11 h-11 rounded-sm bg-gold-faint border border-gold/20 flex items-center justify-center mb-3 group-hover:bg-gold/10 transition-colors">
                  {c.icon}
                </div>
                <span className="font-mono text-xs text-ink-500 tracking-widest uppercase mb-1">{c.label}</span>
                <span className="font-body text-ink-200 text-sm font-medium break-all">{c.value}</span>
                <ArrowUpRight size={12} className="text-gold/0 group-hover:text-gold/60 mt-2 transition-colors" />
              </a>
            ))}
          </div>

          {/* Location */}
          <div className="flex items-center justify-center gap-2 text-ink-500 text-sm">
            <MapPin size={14} className="text-gold/40" />
            <span className="font-body">Based in Nashik, Maharashtra, India — open to remote &amp; hybrid roles</span>
          </div>

          {/* Email CTA */}
          <div className="text-center mt-12">
            <a
              href="mailto:kiranaher5171@gmail.com"
              className="btn-gold text-sm px-8 py-3.5 rounded-sm inline-flex items-center gap-2"
            >
              <Send size={14} /> Send Me a Message
            </a>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="bg-ink-950 border-t border-ink-800 py-8">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="shimmer-text font-display font-extrabold text-lg">KA</span>
            <span className="text-ink-600 font-body text-sm">Kiran Atmaram Aher</span>
          </div>
          <p className="font-mono text-xs text-ink-600 tracking-wide">
            © {new Date().getFullYear()} — Designed &amp; Built with care
          </p>
          <div className="flex items-center gap-5">
            <a href="mailto:kiranaher5171@gmail.com" className="text-ink-500 hover:text-gold transition-colors">
              <Mail size={15} />
            </a>
            <a href="tel:+917264965171" className="text-ink-500 hover:text-gold transition-colors">
              <Phone size={15} />
            </a>
            <a
              href="https://www.linkedin.com/in/kiran-aher-96k/"
              target="_blank" rel="noopener noreferrer"
              className="text-ink-500 hover:text-gold transition-colors"
            >
              <Linkedin size={15} />
            </a>
          </div>
        </div>
      </footer>
    </>
  )
}
