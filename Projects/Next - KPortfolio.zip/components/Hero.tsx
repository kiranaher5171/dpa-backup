'use client'

import { useEffect, useRef } from 'react'
import { ArrowDown, Download, ChevronRight } from 'lucide-react'

export default function Hero() {
  const glowRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (!glowRef.current) return
      glowRef.current.style.left = `${e.clientX}px`
      glowRef.current.style.top  = `${e.clientY}px`
    }
    window.addEventListener('mousemove', move)
    return () => window.removeEventListener('mousemove', move)
  }, [])

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
    >
      {/* Cursor glow */}
      <div ref={glowRef} className="cursor-glow" />

      {/* Background geometric decoration */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
        {/* Large faint ring */}
        <div
          className="absolute rounded-full border border-gold/5"
          style={{ width: 700, height: 700, right: -200, top: -100 }}
        />
        <div
          className="absolute rounded-full border border-gold/5"
          style={{ width: 500, height: 500, right: -100, top: 0 }}
        />
        {/* Grid dots */}
        <svg
          className="absolute right-0 top-0 opacity-10"
          width="400" height="400" viewBox="0 0 400 400"
          fill="none" xmlns="http://www.w3.org/2000/svg"
        >
          {Array.from({ length: 10 }).map((_, row) =>
            Array.from({ length: 10 }).map((_, col) => (
              <circle
                key={`${row}-${col}`}
                cx={col * 40 + 20} cy={row * 40 + 20}
                r="1.5" fill="#C9972B"
              />
            ))
          )}
        </svg>
        {/* Bottom-left accent */}
        <div
          className="absolute"
          style={{
            left: -80, bottom: 60,
            width: 320, height: 320,
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(201,151,43,0.06) 0%, transparent 70%)',
          }}
        />
      </div>

      {/* Main content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 pt-24 pb-16">
        {/* Eyebrow */}
        <div
          className="section-eyebrow mb-8 opacity-0 animate-fade-up"
          style={{ animationDelay: '0.1s', animationFillMode: 'forwards' }}
        >
          Available for new opportunities
        </div>

        {/* Name */}
        <h1
          className="font-display font-extrabold leading-none mb-4 opacity-0 animate-fade-up"
          style={{ animationDelay: '0.2s', animationFillMode: 'forwards', fontSize: 'clamp(3rem, 8vw, 6.5rem)' }}
        >
          <span className="text-ink-50">Kiran </span>
          <span className="shimmer-text">Aher</span>
        </h1>

        {/* Title */}
        <h2
          className="font-body font-light text-ink-300 mb-6 opacity-0 animate-fade-up tracking-wide"
          style={{ animationDelay: '0.3s', animationFillMode: 'forwards', fontSize: 'clamp(1rem, 2.5vw, 1.5rem)' }}
        >
          Executive Frontend Developer
          <span className="mx-3 text-gold/40">|</span>
          UI Developer
        </h2>

        {/* Tagline */}
        <p
          className="font-body text-ink-300 max-w-xl leading-relaxed mb-10 opacity-0 animate-fade-up"
          style={{ animationDelay: '0.4s', animationFillMode: 'forwards', fontSize: 'clamp(0.9rem, 1.5vw, 1.05rem)' }}
        >
          Specializing in{' '}
          <span className="text-gold font-medium">React JS</span>,{' '}
          <span className="text-gold font-medium">Angular</span>, and{' '}
          <span className="text-gold font-medium">Next.js</span> — building
          high-performance, responsive web applications that merge design precision
          with engineering craft.
        </p>

        {/* CTAs */}
        <div
          className="flex flex-wrap gap-4 mb-16 opacity-0 animate-fade-up"
          style={{ animationDelay: '0.5s', animationFillMode: 'forwards' }}
        >
          <a href="#projects" className="btn-gold">
            View My Work <ChevronRight size={15} />
          </a>
          <a href="/resume.pdf" download className="btn-outline">
            <Download size={14} /> Download Resume
          </a>
        </div>

        {/* Stats row */}
        <div
          className="flex flex-wrap gap-8 opacity-0 animate-fade-up"
          style={{ animationDelay: '0.65s', animationFillMode: 'forwards' }}
        >
          {[
            { value: '2.9+', label: 'Years Experience' },
            { value: '20+', label: 'Responsive UIs Built' },
            { value: '30%', label: 'Performance Gains' },
            { value: '50+', label: 'Vulnerabilities Fixed' },
          ].map(stat => (
            <div key={stat.label} className="flex flex-col">
              <span className="font-display font-bold text-2xl text-gold">{stat.value}</span>
              <span className="font-mono text-xs text-ink-400 tracking-wider uppercase mt-0.5">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-float opacity-60">
        <span className="font-mono text-xs text-ink-400 tracking-widest uppercase">Scroll</span>
        <ArrowDown size={14} className="text-gold" />
      </div>

      {/* Horizontal rule */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />
    </section>
  )
}
