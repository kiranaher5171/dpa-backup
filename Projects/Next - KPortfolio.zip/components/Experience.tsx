'use client'

import { Briefcase, Calendar, MapPin } from 'lucide-react'
import { useReveal } from './useReveal'

const experiences = [
  {
    role:     'Executive Frontend Developer (UI) — React',
    company:  'Decimal Point Analytics',
    location: 'Nashik, India',
    period:   'Aug 2023 – Present',
    type:     'Full-time',
    current:  true,
    highlights: [
      'Designed <strong>20+ responsive UIs</strong> and built <strong>15+ interactive web apps</strong> using React JS and Material-UI, improving team velocity and UI consistency.',
      'Converted <strong>10+ UI/UX mockups</strong> into pixel-perfect, accessible components — reducing design-to-dev handoff friction significantly.',
      'Managed PRs, conducted weekly code reviews, and resolved <strong>50+ high-severity vulnerabilities</strong> via SonarQube scans, strengthening overall code health.',
      'Optimised application performance by up to <strong>30%</strong> through lazy loading, code splitting, and component memoisation strategies.',
    ],
  },
  {
    role:     'Frontend Developer Intern',
    company:  'Manasvi Tech Solution Pvt Ltd',
    location: 'Nashik, India',
    period:   'Mar 2023 – Aug 2023',
    type:     'Internship',
    current:  false,
    highlights: [
      'Resolved critical code issues and enhanced responsive design implementation across multiple client projects.',
      'Participated in structured industry training programmes covering modern frontend practices.',
      'Contributed to improving cross-browser compatibility and mobile-first design approaches.',
    ],
  },
]

export default function Experience() {
  const ref = useReveal()

  return (
    <section id="experience" className="py-28 bg-ink-950 relative">
      <div ref={ref as React.RefObject<HTMLDivElement>} className="max-w-7xl mx-auto px-6 lg:px-12 reveal">
        <div className="section-eyebrow mb-5">Career Timeline</div>
        <h2 className="font-display font-bold text-4xl lg:text-5xl text-ink-50 mb-16 leading-tight">
          Work Experience
        </h2>

        <div className="relative pl-8">
          {/* Vertical timeline spine */}
          <div
            className="absolute left-2.5 top-3 bottom-0 w-px"
            style={{ background: 'linear-gradient(to bottom, #C9972B 60%, transparent)' }}
          />

          <div className="flex flex-col gap-16">
            {experiences.map((exp, i) => (
              <div key={i} className="relative">
                {/* Timeline dot */}
                <div
                  className={`absolute -left-8 top-2 w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    exp.current
                      ? 'border-gold bg-gold-faint shadow-[0_0_12px_rgba(201,151,43,0.4)]'
                      : 'border-ink-500 bg-ink-800'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full ${exp.current ? 'bg-gold' : 'bg-ink-500'}`} />
                </div>

                {/* Card */}
                <div className="card-dark rounded-lg p-7">
                  {/* Header */}
                  <div className="flex flex-wrap gap-4 items-start justify-between mb-5">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        {exp.current && (
                          <span className="font-mono text-xs text-gold bg-gold-faint border border-gold/20 px-2 py-0.5 rounded-sm tracking-wider uppercase">
                            Current
                          </span>
                        )}
                        <span className="font-mono text-xs text-ink-500 tracking-wider uppercase">{exp.type}</span>
                      </div>
                      <h3 className="font-display font-bold text-xl text-ink-50 mb-1">{exp.role}</h3>
                      <div className="flex flex-wrap gap-4 text-sm">
                        <span className="flex items-center gap-1.5 text-gold font-medium">
                          <Briefcase size={12} /> {exp.company}
                        </span>
                        <span className="flex items-center gap-1.5 text-ink-400">
                          <MapPin size={12} /> {exp.location}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 text-ink-400 text-sm font-mono">
                      <Calendar size={13} />
                      {exp.period}
                    </div>
                  </div>

                  {/* Highlights */}
                  <ul className="flex flex-col gap-3">
                    {exp.highlights.map((h, j) => (
                      <li key={j} className="flex gap-3 text-sm text-ink-300 leading-relaxed">
                        <span className="text-gold mt-0.5 flex-shrink-0">▸</span>
                        <span dangerouslySetInnerHTML={{ __html: h.replace(/<strong>/g, '<strong class="text-ink-100 font-semibold">') }} />
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
