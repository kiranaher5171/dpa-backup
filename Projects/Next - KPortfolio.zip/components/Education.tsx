'use client'

import { GraduationCap, Award, Users } from 'lucide-react'
import { useReveal } from './useReveal'

const achievements = [
  {
    icon: <Award size={18} className="text-gold" />,
    title: 'Intern of the Month',
    org:   'Manasvi Tech Solution Pvt Ltd',
    description: 'Recognised for consistently exceeding project deadlines and delivering quality work during the internship programme.',
  },
  {
    icon: <Users size={18} className="text-gold" />,
    title: 'NSS Volunteer — 3 Years',
    org:   'National Service Scheme',
    description:
      'Served as an active NSS volunteer for three consecutive years, contributing to community development, social campaigns, and rural outreach programmes.',
  },
]

export default function Education() {
  const ref = useReveal()

  return (
    <section id="education" className="py-28 bg-ink-950 relative">
      <div ref={ref as React.RefObject<HTMLDivElement>} className="max-w-7xl mx-auto px-6 lg:px-12 reveal">
        <div className="section-eyebrow mb-5">Academic & Achievements</div>
        <h2 className="font-display font-bold text-4xl lg:text-5xl text-ink-50 mb-16 leading-tight">
          Education
        </h2>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Education */}
          <div>
            <div className="card-dark rounded-lg p-7 relative overflow-hidden">
              {/* Accent corner */}
              <div
                className="absolute top-0 right-0 w-24 h-24 pointer-events-none"
                style={{ background: 'radial-gradient(circle at 100% 0%, rgba(201,151,43,0.12) 0%, transparent 70%)' }}
              />

              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 rounded-sm bg-gold-faint border border-gold/20 flex items-center justify-center flex-shrink-0">
                  <GraduationCap size={22} className="text-gold" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-xl text-ink-50 mb-1">
                    Bachelor of Computer Science
                  </h3>
                  <p className="font-body text-gold text-sm font-medium">ACS College Kalwan</p>
                  <p className="font-body text-ink-400 text-sm">Nashik, Maharashtra</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 border-t border-ink-700 pt-5">
                {[
                  { label: 'Graduation Year', value: '2021' },
                  { label: 'Degree',          value: 'B.Sc. Computer Science' },
                  { label: 'Specialisation',  value: 'Computer Science' },
                  { label: 'University',      value: 'SPPU, Pune' },
                ].map(f => (
                  <div key={f.label}>
                    <dt className="font-mono text-xs text-ink-500 tracking-widest uppercase mb-1">{f.label}</dt>
                    <dd className="font-body text-ink-100 text-sm font-medium">{f.value}</dd>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div>
            <h3 className="font-display font-semibold text-2xl text-ink-50 mb-7">
              Achievements & Involvement
            </h3>
            <div className="flex flex-col gap-5">
              {achievements.map((a) => (
                <div key={a.title} className="card-dark rounded-lg p-6 flex gap-4 items-start">
                  <div className="w-9 h-9 rounded-sm bg-gold-faint border border-gold/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    {a.icon}
                  </div>
                  <div>
                    <h4 className="font-display font-semibold text-ink-100 text-base mb-0.5">{a.title}</h4>
                    <p className="font-mono text-xs text-gold mb-2 tracking-wider">{a.org}</p>
                    <p className="font-body text-ink-400 text-sm leading-relaxed">{a.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
