'use client'

import { useState, useEffect } from 'react'
import { Menu, X } from 'lucide-react'

const links = [
  { label: 'About',      href: '#about'      },
  { label: 'Skills',     href: '#skills'     },
  { label: 'Experience', href: '#experience' },
  { label: 'Projects',   href: '#projects'   },
  { label: 'Education',  href: '#education'  },
  { label: 'Contact',    href: '#contact'    },
]

export default function Navbar() {
  const [scrolled, setScrolled]   = useState(false)
  const [menuOpen, setMenuOpen]   = useState(false)
  const [activeSection, setActive] = useState('')

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40)

      // highlight active section
      const sections = links.map(l => l.href.slice(1))
      for (const id of [...sections].reverse()) {
        const el = document.getElementById(id)
        if (el && window.scrollY >= el.offsetTop - 120) {
          setActive(id)
          break
        }
      }
    }
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const handleNav = (href: string) => {
    setMenuOpen(false)
    const el = document.querySelector(href)
    el?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-ink-900/90 backdrop-blur-md border-b border-ink-700/50' : ''
      }`}
    >
      <nav className="max-w-7xl mx-auto px-6 lg:px-12 h-16 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="font-display font-800 text-lg tracking-tight text-ink-50 flex items-center gap-2"
        >
          <span className="shimmer-text font-display font-extrabold text-xl">KA</span>
          <span className="hidden sm:block text-ink-300 font-body font-light text-sm tracking-widest uppercase">
            Kiran Aher
          </span>
        </button>

        {/* Desktop links */}
        <ul className="hidden md:flex items-center gap-7">
          {links.map(l => (
            <li key={l.href}>
              <button
                onClick={() => handleNav(l.href)}
                className={`nav-link font-body ${activeSection === l.href.slice(1) ? '!text-gold' : ''}`}
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="#contact"
          onClick={e => { e.preventDefault(); handleNav('#contact') }}
          className="hidden md:flex btn-gold text-xs py-2.5 px-5 rounded-sm"
        >
          Hire Me
        </a>

        {/* Mobile menu toggle */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="md:hidden text-ink-200 hover:text-gold transition-colors"
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="md:hidden bg-ink-900 border-t border-ink-700 px-6 py-6 flex flex-col gap-5">
          {links.map(l => (
            <button
              key={l.href}
              onClick={() => handleNav(l.href)}
              className="nav-link text-left text-base"
            >
              {l.label}
            </button>
          ))}
          <button onClick={() => handleNav('#contact')} className="btn-gold mt-2 w-full justify-center">
            Hire Me
          </button>
        </div>
      )}
    </header>
  )
}
