import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './Root.css';
import { ThemeProvider } from "@mui/material";
import { createTheme } from "@mui/material"; 
import FormLayout from './Layouts/FormLayout';
import MainLayout from './Layouts/MainLayout'; 
import Login from './Forms/Login';
import Home from './Pages/Home';
import Inventory from './Pages/Inventory';
import Items from './Pages/Items';
import Stock from './Pages/Stock';
import User from './Pages/User';
import Branch from './Pages/Branch';
import Allocate from './Pages/Allocate';
import Settings from './Pages/Settings';
import ForgotPassword from './Forms/ForgotPassword';
import EmailSend from './Forms/EmailSend';
import ResetPassword from './Forms/ResetPassword';
import PasswordChanged from './Forms/PasswordChanged';

function App() {

  const theme = createTheme({
    typography: {
      fontFamily: "Roboto, sans-serif",
    },
  });

  return (
    <>
      <ThemeProvider theme={theme}>
        <BrowserRouter>
          <Routes>
            <Route exact path='/'  element={<FormLayout><Login/></FormLayout>}></Route>
            <Route exact path='/forgotpassword'  element={<FormLayout><ForgotPassword/></FormLayout>}></Route>
            <Route exact path='/emailsend'  element={<FormLayout><EmailSend/></FormLayout>}></Route>
            <Route exact path='/resetpassword'  element={<FormLayout><ResetPassword/></FormLayout>}></Route>
            <Route exact path='/changepassword'  element={<FormLayout><PasswordChanged/></FormLayout>}></Route>


            <Route exact path='/dashboard'  element={<MainLayout><Home/></MainLayout>}></Route>
            <Route exact path='/inventory-management'  element={<MainLayout><Inventory/></MainLayout>}></Route>
            <Route exact path='/items'  element={<MainLayout><Items/></MainLayout>}></Route>
            <Route exact path='/stock-management'  element={<MainLayout><Stock/></MainLayout>}></Route>
            <Route exact path='/users'  element={<MainLayout><User/></MainLayout>}></Route>
            <Route exact path='/branches'  element={<MainLayout><Branch/></MainLayout>}></Route>
            <Route exact path='/inventory-management-allocate-asset'  element={<MainLayout><Allocate/></MainLayout>}></Route>
            <Route exact path='/settings'  element={<MainLayout><Settings/></MainLayout>}></Route>
          </Routes>
        </BrowserRouter>
      </ThemeProvider>
    </>
  );
}

export default App;
