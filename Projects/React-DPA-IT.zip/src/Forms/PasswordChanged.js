import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';
import { Button, Container, } from '@mui/material';
import done from "../Asset/Images/done.gif"

function PasswordChanged() {

    const [showPassword, setShowPassword] = React.useState(false);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    return (
        <>
            <Box id="login">

                <Container maxWidth="lg">


                    <Box className="login_bx">
                        <Grid container alignItems="center" justifyContent='center' >
                            <Grid item lg={7} md={7} sm={6} xs={12}>
                                <Box className="left_side grid_c" >
                                    <Box className='left_side_content'>
                                        <Box pb={2}>
                                            <Typography variant='h1' className='heading fw5 txt_shd'>
                                                Great to have you back!
                                            </Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw5 wh txt_shd'>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>

                            <Grid item lg={5} md={5} sm={6} xs={12}>
                                <Box className="login_form">
                                    <Box className="al_center " mt={1}>
                                        <Box >
                                            <img src={done} alt='Done' className='form_logo' />
                                        </Box>
                                        <Box className="al_center" mt={2}>
                                            <Typography variant='h2' className='col1 fw6'> Password Changed </Typography>
                                        </Box>
                                        <Box mt={1}>
                                            <Typography variant='h6' className='content fw5'> You've successfully changed your password. Please log in with the new password. </Typography>
                                        </Box>


                                        <Box mt={2}>
                                            <Link to="/">
                                                <Button variant='contained' className='form_btn' fullWidth>Sign In</Button>
                                            </Link>
                                        </Box>


                                        {/* <Box mt={2}>
                                            <Typography variant='h6' className='content fw5'> Doesn't have an account? <Link className='col2'>Sign Up</Link> </Typography>
                                        </Box> */}

                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>

                </Container>

            </Box>
        </>
    )
}

export default PasswordChanged;
