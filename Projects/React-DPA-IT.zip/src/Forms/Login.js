import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';
import IconButton from '@mui/material/IconButton';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { Button, Checkbox, Container, FormControlLabel, OutlinedInput } from '@mui/material';
import logo from "../Asset/Images/logo.png"

function Login() {

    const [showPassword, setShowPassword] = React.useState(false);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    return (
        <>
            <Box id="login">

                <Container maxWidth="lg">


                    <Box className="login_bx">
                        <Grid container alignItems="center" justifyContent='center' >
                            <Grid item lg={7} md={7} sm={6} xs={12}>
                                <Box className="left_side grid_c" >
                                    <Box className='left_side_content'>
                                        <Box pb={2}>
                                            <Typography variant='h1' className='heading fw5 txt_shd'>
                                                Great to have you back!
                                            </Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw5 wh txt_shd'>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>

                            <Grid item lg={5} md={5} sm={6} xs={12}>
                                <Box className="login_form">
                                    <Box className="al_center " mt={1}>
                                        <Box >
                                            <img src={logo} alt='Logo' className='logo' />
                                        </Box>
                                        <Box className="al_center" mt={2}>
                                            <Typography variant='h2' className='col1 fw6'> Sign In </Typography>
                                            <Typography variant='h5' className='content fw5'> to access Inventory </Typography>
                                        </Box>

                                        <Box mt={3}>
                                            <TextField
                                                id="filled-password-input"
                                                type="Email id"
                                                fullWidth
                                                className='input_field'
                                                placeholder='Emp Code / Email address'
                                            />
                                        </Box>

                                        <Box mt={2}>
                                            <FormControl fullWidth className='input_field'>
                                                <OutlinedInput
                                                    id="outlined-adornment-password"
                                                    placeholder='Password'
                                                    type={showPassword ? 'text' : 'password'}
                                                    endAdornment={
                                                        <InputAdornment position="end">
                                                            <IconButton
                                                                aria-label="toggle password visibility"
                                                                onClick={handleClickShowPassword}
                                                                onMouseDown={handleMouseDownPassword}
                                                                edge="end"
                                                            >
                                                                {showPassword ? <VisibilityOff /> : <Visibility />}
                                                            </IconButton>
                                                        </InputAdornment>
                                                    }
                                                />
                                            </FormControl>
                                        </Box>

                                        <Box className='fx_sb'>
                                            <Box mt={2} className='al_left checkbox_with_label'>
                                                <FormControlLabel control={<Checkbox defaultChecked />} label="Remember Me" />
                                            </Box>
                                            <Box mt={2} className='al_left checkbox_with_label'>
                                                <Link to='/forgotpassword' className='col2'>
                                                    <Typography variant='h6' className='fw5'> Forgot Password? </Typography>
                                                </Link>
                                            </Box>
                                        </Box>

                                        <Box mt={2}>
                                            <Link to="/dashboard">
                                                <Button variant='contained' className='form_btn' fullWidth>Log In</Button>
                                            </Link>
                                        </Box>


                                        {/* <Box mt={2}>
                                            <Typography variant='h6' className='content fw5'> Doesn't have an account? <Link className='col2'>Sign Up</Link> </Typography>
                                        </Box> */}

                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>

                </Container>

            </Box>
        </>
    )
}

export default Login;
