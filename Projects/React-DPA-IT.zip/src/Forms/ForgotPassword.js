import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';
import { Button, Container, } from '@mui/material';
import lock from "../Asset/Images/forgot_pass.gif"

function ForgotPassword() {



    return (
        <>
            <Box id="login">

                <Container maxWidth="lg">


                    <Box className="login_bx">
                        <Grid container alignItems="center" justifyContent='center' >
                            <Grid item lg={7} md={7} sm={6} xs={12}>
                                <Box className="left_side grid_c" >
                                    <Box className='left_side_content'>
                                        <Box pb={2}>
                                            <Typography variant='h1' className='heading fw5 txt_shd'>
                                                Great to have you back!
                                            </Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw5 wh txt_shd'>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>

                            <Grid item lg={5} md={5} sm={6} xs={12}>
                                <Box className="login_form">
                                    <Box className="al_center " mt={1}>
                                        <Box >
                                            <img src={lock} alt='Forgot Password' className='form_logo' />
                                        </Box>
                                        <Box className="al_center" mt={2}>
                                            <Typography variant='h2' className='col1 fw6'> Forgot Your Password? </Typography>
                                        </Box>
                                        <Box>
                                            <Typography variant='h6' className='content fw5' mt={1}> Enter your email so that we can send you password reset link </Typography>
                                        </Box>

                                        <Box mt={3}>
                                            <TextField
                                                id="filled-password-input"
                                                type="Email id"
                                                fullWidth
                                                className='input_field'
                                                placeholder='Email address'
                                            />
                                        </Box>

                                        <Box mt={2}>
                                            <Link to="/emailsend">
                                                <Button variant='contained' className='form_btn' fullWidth>Send Email</Button>
                                            </Link>
                                        </Box>


                                        <Box mt={2}>
                                            <Link to='/' className='col2'>
                                                <Typography variant='h6' className='fw5'> Back to login </Typography>
                                            </Link>
                                        </Box>

                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>

                </Container >

            </Box >
        </>
    )
}

export default ForgotPassword;
