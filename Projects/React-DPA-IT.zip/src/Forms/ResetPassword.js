import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';
import IconButton from '@mui/material/IconButton';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { Button, Container,  OutlinedInput } from '@mui/material';
import lock from "../Asset/Images/forgot_pass.gif"

function ResetPassword() {

    const [showPassword, setShowPassword] = React.useState(false);

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    const [showPassword2, setShowPassword2] = React.useState(false);

    const handleClickShowPassword2 = () => setShowPassword2((show) => !show);

    const handleMouseDownPassword2 = (event) => {
        event.preventDefault();
    };

    return (
        <>
            <Box id="login">

                <Container maxWidth="lg">


                    <Box className="login_bx">
                        <Grid container alignItems="center" justifyContent='center' >
                            <Grid item lg={7} md={7} sm={6} xs={12}>
                                <Box className="left_side grid_c" >
                                    <Box className='left_side_content'>
                                        <Box pb={2}>
                                            <Typography variant='h1' className='heading fw5 txt_shd'>
                                                Great to have you back!
                                            </Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw5 wh txt_shd'>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>

                            <Grid item lg={5} md={5} sm={6} xs={12}>
                                <Box className="login_form">
                                    <Box className="al_center " mt={1}>
                                        <Box >
                                            <img src={lock} alt='Reset Password' className='form_logo' />
                                        </Box>
                                        <Box className="al_center" mt={2}>
                                            <Typography variant='h2' className='col1 fw6'> Reset Password </Typography>
                                        </Box>


                                        <Box mt={2}>
                                            <FormControl fullWidth className='input_field'>
                                                <OutlinedInput
                                                    id="outlined-adornment-password"
                                                    placeholder='Password'
                                                    type={showPassword ? 'text' : 'password'}
                                                    endAdornment={
                                                        <InputAdornment position="end">
                                                            <IconButton
                                                                aria-label="toggle password visibility"
                                                                onClick={handleClickShowPassword}
                                                                onMouseDown={handleMouseDownPassword}
                                                                edge="end"
                                                            >
                                                                {showPassword ? <VisibilityOff /> : <Visibility />}
                                                            </IconButton>
                                                        </InputAdornment>
                                                    }
                                                />
                                            </FormControl>
                                        </Box>

                                        <Box mt={2}>
                                            <FormControl fullWidth className='input_field'>
                                                <OutlinedInput
                                                    id="outlined-adornment-password"
                                                    placeholder='Confirm Password'
                                                    type={showPassword2 ? 'text' : 'password'}
                                                    endAdornment={
                                                        <InputAdornment position="end">
                                                            <IconButton
                                                                aria-label="toggle password visibility"
                                                                onClick={handleClickShowPassword2}
                                                                onMouseDown={handleMouseDownPassword2}
                                                                edge="end"
                                                            >
                                                                {showPassword2 ? <VisibilityOff /> : <Visibility />}
                                                            </IconButton>
                                                        </InputAdornment>
                                                    }
                                                />
                                            </FormControl>
                                        </Box>

                                        <Box mt={1}>
                                            <Typography variant='h6' className='content fw5'> Must be 8 or more characters, contain at least one capital letter, one number, and one special character </Typography>
                                        </Box>


                                        <Box mt={2}>
                                            <Link to="/changepassword">
                                                <Button variant='contained' className='form_btn' fullWidth>Set Password</Button>
                                            </Link>
                                        </Box>


                                        {/* <Box mt={2}>
                                            <Typography variant='h6' className='content fw5'> Doesn't have an account? <Link className='col2'>Sign Up</Link> </Typography>
                                        </Box> */}

                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>

                </Container>

            </Box>
        </>
    )
}

export default ResetPassword;
