import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';
import { Button, Container, } from '@mui/material';
import email from "../Asset/Images/email.gif"

function EmailSend() {


    return (
        <>
            <Box id="login">

                <Container maxWidth="lg">


                    <Box className="login_bx">
                        <Grid container alignItems="center" justifyContent='center' >
                            <Grid item lg={7} md={7} sm={6} xs={12}>
                                <Box className="left_side grid_c" >
                                    <Box className='left_side_content'>
                                        <Box pb={2}>
                                            <Typography variant='h1' className='heading fw5 txt_shd'>
                                                Great to have you back!
                                            </Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw5 wh txt_shd'>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>

                            <Grid item lg={5} md={5} sm={6} xs={12}>
                                <Box className="login_form">
                                    <Box className="al_center " mt={1}>
                                        <Box >
                                            <img src={email} alt='Email' className='form_logo' />
                                        </Box>
                                        <Box className="al_center" mt={2}>
                                            <Typography variant='h2' className='col1 fw6'> Email Send </Typography>
                                        </Box>
                                        <Box mt={1}>
                                            <Typography variant='h6' className='content fw5'> An email has been sent to your registered email address, <span className='col2'>abcd*****@mail.com</span> Follow the instruction in the email to reset your password. </Typography>
                                            <Typography variant='h6' className='content fw5' mt={1}> The link in the email will expire in 2 hours. </Typography>
                                        </Box>


                                        <Box mt={2}>
                                            <Link to="/resetpassword">
                                                <Button variant='contained' className='form_btn' fullWidth>Done</Button>
                                            </Link>
                                        </Box>


                                        {/* <Box mt={2}>
                                            <Typography variant='h6' className='content fw5'> Doesn't have an account? <Link className='col2'>Sign Up</Link> </Typography>
                                        </Box> */}

                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>

                </Container>

            </Box>
        </>
    )
}

export default EmailSend;
