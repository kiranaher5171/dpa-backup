import React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import IconButton from '@mui/material/IconButton';
import SegmentIcon from '@mui/icons-material/Segment';
import { Link, useLocation } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import SpaceDashboardOutlinedIcon from '@mui/icons-material/SpaceDashboardOutlined';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import CategoryIcon from '@mui/icons-material/Category';
import DonutSmallIcon from '@mui/icons-material/DonutSmall';
import GroupIcon from '@mui/icons-material/Group';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import { Tooltip } from '@mui/material';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';


const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
}));

export default function MobileDrawer() {
    const [open, setOpen] = React.useState(true);

    const location = useLocation();
    const isActive = (...paths) => {
        return paths.some(path => location.pathname.startsWith(path));
    };


    const [state, setState] = React.useState({
        left: false,
    });

    const toggleDrawer = (anchor, open) => (event) => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }

        setState({ ...state, [anchor]: open });
    };


    const list = (anchor) => (
        <Box
            sx={{ width: anchor === 'top' || anchor === 'bottom' ? 'auto' : 240 }}
            role="presentation"
            onClick={toggleDrawer(anchor, false)}
            onKeyDown={toggleDrawer(anchor, false)}
        >
            <DrawerHeader>
                <Tooltip title="Collapse" arrow placement="right">
                    <IconButton>
                        <MenuOpenIcon fontSize='small' className='col1' />
                    </IconButton>
                </Tooltip>
            </DrawerHeader>
            <Divider />
            <List>
                <Link to='/dashboard'>
                    <ListItem disablePadding>
                        <ListItemButton selected={isActive('/dashboard')} button>
                            <Tooltip title="Dashboard" arrow placement="right">
                                <ListItemIcon>
                                    <SpaceDashboardOutlinedIcon fontSize='small' />
                                </ListItemIcon>
                            </Tooltip>
                            <ListItemText primary='Dashboard' sx={{ opacity: open ? 1 : 0 }} />
                        </ListItemButton>
                    </ListItem>
                </Link>

                <Link to='/inventory-management'>
                    <ListItem disablePadding>
                        <ListItemButton selected={isActive('/inventory-management', '/inventory-management-allocate-asset')} button>
                            <Tooltip title="Inventory Management" arrow placement="right">
                                <ListItemIcon>
                                    <ManageAccountsIcon fontSize='small' />
                                </ListItemIcon>
                            </Tooltip>
                            <ListItemText primary='Inventory Management' sx={{ opacity: open ? 1 : 0 }} />
                        </ListItemButton>
                    </ListItem>
                </Link>


                <Link to='/items'>
                    <ListItem disablePadding>
                        <ListItemButton selected={isActive('/items')} button>
                            <Tooltip title="Items" arrow placement="right">
                                <ListItemIcon>
                                    <CategoryIcon fontSize='small' />
                                </ListItemIcon>
                            </Tooltip>
                            <ListItemText primary='Items' sx={{ opacity: open ? 1 : 0 }} />
                        </ListItemButton>
                    </ListItem>
                </Link>

                <Link to='/stock-management'>
                    <ListItem disablePadding>
                        <ListItemButton selected={isActive('/stock-management')} button>
                            <Tooltip title="Stock Management" arrow placement="right">
                                <ListItemIcon>
                                    <DonutSmallIcon fontSize='small' />
                                </ListItemIcon>
                            </Tooltip>
                            <ListItemText primary='Stock Management' sx={{ opacity: open ? 1 : 0 }} />
                        </ListItemButton>
                    </ListItem>
                </Link>

                <Link to='/users'>
                    <ListItem disablePadding>
                        <ListItemButton selected={isActive('/users')} button>
                            <Tooltip title="Users" arrow placement="right">
                                <ListItemIcon>
                                    <GroupIcon fontSize='small' />
                                </ListItemIcon>
                            </Tooltip>
                            <ListItemText primary='Users' sx={{ opacity: open ? 1 : 0 }} />
                        </ListItemButton>
                    </ListItem>
                </Link>

                <Link to='/branches'>
                    <ListItem disablePadding>
                        <ListItemButton selected={isActive('/branches')} button>
                            <Tooltip title="Branches" arrow placement="right">
                                <ListItemIcon>
                                    <AccountTreeIcon fontSize='small' />
                                </ListItemIcon>
                            </Tooltip>
                            <ListItemText primary='Branches' sx={{ opacity: open ? 1 : 0 }} />
                        </ListItemButton>
                    </ListItem>
                </Link>

            </List>
        </Box>
    );

    return (
        <div className='mobile_view'>

            {['left',].map((anchor) => (
                <React.Fragment key={anchor}>

                    <Drawer
                        anchor={anchor}
                        open={state[anchor]}
                        onClose={toggleDrawer(anchor, false)}

                    >

                        {list(anchor)}
                    </Drawer>

                    <Tooltip title="Expand" arrow placement="right">
                        <IconButton
                            color="inherit"
                            aria-label="open drawer"

                            edge="start"
                            className='segmentIcon'
                            // onClick={toggleDrawer(anchor, true)}
                            onClick={toggleDrawer(anchor, !state[anchor])}
                        >
                            <SegmentIcon className='mobile_view_icon col1' />
                        </IconButton>
                    </Tooltip>
                </React.Fragment>
            ))}
        </div>
    );
}
