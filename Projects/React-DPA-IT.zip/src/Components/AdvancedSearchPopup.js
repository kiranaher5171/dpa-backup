import { Autocomplete, Box, Button, Dialog, DialogContent, DialogContentText, DialogTitle, Divider, FormControl, Grid, IconButton, InputLabel, MenuItem, Select, TextField, Tooltip, Typography } from '@mui/material'
import React from 'react';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import SyncIcon from '@mui/icons-material/Sync';
import DeleteIcon from '@mui/icons-material/Delete';
import SimpleDatePicker from './SimpleDatePicker';


const AdvancedSearchPopup = () => {


  const [options, setOptions] = React.useState('');
  const handleChange = (event) => {
    setOptions(event.target.value);
  }

  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };


  return (
    <>


      <Box className='fx_fe' mb={1}>
        <Button fullWidth variant="contained" size='small' className='main_btn' onClick={handleClickOpen} startIcon={<AddIcon />}>Advanced Search</Button>
      </Box>

      <Dialog id='dialog' maxWidth='lg'
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" className='col1'>
          <Typography variant='h4' className='fw5'>
            {"Filter"}
          </Typography>
        </DialogTitle>
        <Divider />
        <IconButton
          size='medium'
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,

          }}
        >
          <CloseIcon fontSize='small' />
        </IconButton>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            <Box>
              <Grid container spacing={0} justifyContent='flex-end' alignItems='center'>
                <Grid item lg={3} md={3} sm={4} xs={7}>
                  <Box className='fx_fe'>
                    <Box>
                      <Button fullWidth variant="contained" size='small' className='main_btn' startIcon={<AddIcon />}>Add Filter</Button>
                    </Box>
                    <Box mx={1}>
                      <Tooltip title='Clear All' arrow placement='bottom'>
                        <IconButton size='medium' className='reset_ico'>
                          <SyncIcon fontSize='small' className='col2' />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Box>
                </Grid>
                <Grid item lg={3} md={3} sm={4} xs={5}>
                  <Box className="ol_txtfield" pt={0}>
                    <Autocomplete
                      disablePortal
                      size='small'
                      id="combo-box-demo"
                      options={demo_options}
                      fullWidth
                      renderInput={(params) => <TextField variant='outlined' {...params} label="Save Filter" size='small' />}
                    />
                  </Box>
                </Grid>
              </Grid>
            </Box>

            <Box className='dia_box' my={1}>
              <Box className='dia_input_box'>
                <Grid container spacing={1}>
                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Where" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={3} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Branch" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="is" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={5} md={5} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Branch" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={1} md={1} sm={2} xs={2}>
                    <Box className='al_center'>
                      <Tooltip title='remove' arrow placement='bottom'>
                        <IconButton>
                          <DeleteIcon fontSize='small' className='rd' />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Grid>
                </Grid>
              </Box>

              <Box className='dia_input_box'>
                <Grid container spacing={1}>
                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="And" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={3} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Devices" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="is" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={5} md={5} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Devices" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={1} md={1} sm={2} xs={2}>
                    <Box className='al_center'>
                      <Tooltip title='remove' arrow placement='bottom'>
                        <IconButton>
                          <DeleteIcon fontSize='small' className='rd' />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Grid>
                </Grid>
              </Box>


              <Box className='dia_input_box'>
                <Grid container spacing={1} >
                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="And" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={3} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="From Date" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="is" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Date Range" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={3} sm={4} xs={12}>
                    <SimpleDatePicker />
                  </Grid>

                  <Grid item lg={1} md={1} sm={2} xs={2}>
                    <Box className='al_center'>
                      <Tooltip title='remove' arrow placement='bottom'>
                        <IconButton>
                          <DeleteIcon fontSize='small' className='rd' />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Grid>
                </Grid>
              </Box>

              <Box className='dia_input_box'>
                <Grid container spacing={1} >
                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="And" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={3} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Due Date" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="is" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Date Range" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={3} sm={4} xs={12}>
                    <SimpleDatePicker />
                  </Grid>

                  <Grid item lg={1} md={1} sm={2} xs={2}>
                    <Box className='al_center'>
                      <Tooltip title='remove' arrow placement='bottom'>
                        <IconButton>
                          <DeleteIcon fontSize='small' className='rd' />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Grid>
                </Grid>
              </Box>

              <Box className='dia_input_box'>
                <Grid container spacing={1} >
                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="And" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={3} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Created By" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={2} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="is" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={5} md={5} sm={4} xs={12}>
                    <Box className="ol_txtfield">
                      <Autocomplete
                        disablePortal
                        size='small'
                        id="free-solo-demo"
                        freeSolo
                        options={demo_options}
                        fullWidth
                        renderInput={(params) => <TextField variant='outlined' {...params} label="Select Creator" size='small' />}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={1} md={1} sm={2} xs={2}>
                    <Box className='al_center'>
                      <Tooltip title='remove' arrow placement='bottom'>
                        <IconButton>
                          <DeleteIcon fontSize='small' className='rd' />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            </Box>
            <Box className='fx_fe'>
              <Button variant="contained" size='small' className='sec_btn bg1 wh' startIcon={<AddIcon />} onClick={handleClose}>Add Nested Filter</Button>
            </Box>
          </DialogContentText>
        </DialogContent>

      </Dialog>


    </>
  )
}

export default AdvancedSearchPopup

const demo_options = [
  { label: 'Option 1' },
  { label: 'Option 2' },
  { label: 'Option 3' },
]