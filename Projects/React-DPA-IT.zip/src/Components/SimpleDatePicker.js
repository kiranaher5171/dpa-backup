import React from 'react';
import { Box } from '@mui/material'
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';


const SimpleDatePicker = ({ pickerLabel }) => {


  const [value, setValue] = React.useState(dayjs('2022-04-17'));


  return (
    <>

      <Box className="datepicker">
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label={pickerLabel}
            size="small"
            value={value}
            onChange={(newValue) => setValue(newValue)}
          />
        </LocalizationProvider>
      </Box>

    </>
  )
}

export default SimpleDatePicker

