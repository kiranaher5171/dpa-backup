import * as React from 'react';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Autocomplete from '@mui/material/Autocomplete';
import { Typography, Box } from '@mui/material';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import AccountCircle from '@mui/icons-material/AccountCircle';
import SearchIcon from '@mui/icons-material/Search';


export default function FreeSoloAutoComplete() {
    return (
        <>
            <Box className="ol_txtfield">
                <Autocomplete
                    id="free-solo-demo"
                    freeSolo
                    fullWidth
                    size='small'
                    options={top100Films.map((option) => option.title)}
                    renderInput={(params) => <TextField {...params} label="Search" variant='outlined' size='small' fullWidth  
                    InputProps={{
                        ...params.InputProps,
                        startAdornment: (
                            <SearchIcon fontSize='small' className="content"/> 
                        ),
                      }}
                    />}
                />
            </Box>
        </>
    );
}


const top100Films = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: "Option 6" },
   ];
