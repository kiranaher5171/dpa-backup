import * as React from 'react';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { Box, TextField,  } from '@mui/material';



export default function Date_Time_Picker() {
    return (


        <>
            <Box>
                <LocalizationProvider dateAdapter={AdapterDayjs} >
                    <DatePicker/>
                </LocalizationProvider>
            </Box>
        </>
    );
}