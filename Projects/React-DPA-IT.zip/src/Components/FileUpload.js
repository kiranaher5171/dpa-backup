import React, { useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Box, Typography } from '@mui/material';
import Files from "../Asset/Images/files.png";



export default function FileUpload({ onDrop, accept, open }) {
    const { getRootProps, getInputProps, isDragActive, acceptedFiles } =
        useDropzone({
            accept,
            onDrop,
        });

    const files = acceptedFiles.map((file) => (
        <Typography variant="h6" className="content" key={file.path}>
            {file.path} - {file.size} bytes
        </Typography>
    ));

    return (
        <Box>
            <Box {...getRootProps({ className: "dropzone" })}>
                <input className="input-zone" {...getInputProps()} />
                <Box className="text-center">
                    {isDragActive ? (
                        <Box className="dropzone-content">
                            <Typography variant='h5' className='col1 fw5 al_center' gutterBottom>  Release to drop the files here </Typography>
                        </Box>
                    ) : (
                        <Box className="dropzone-content">
                            <Box className="al_center">
                                <img src={Files} alt="pdf logo here" className='file-logo' />
                            </Box>

                            <Box className="al_center">
                                <Typography variant='h5' className='content fw5' gutterBottom>    Drag & drop your files here or choose file </Typography>
                                <Typography variant='h6' className='content fw4' gutterBottom> 50MB max file size </Typography>
                            </Box>
                        </Box>
                    )}
                </Box>
            </Box>

            <Box>
                <>{files}</>
            </Box>
        </Box>
    );
}