import { Autocomplete, Box, Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Divider, Grid, IconButton, InputAdornment, Stack, Tab, Tabs, TextField, Tooltip, Typography } from '@mui/material'
import React from 'react';
import AddIcon from '@mui/icons-material/Add';
import PropTypes from 'prop-types';
import SearchIcon from '@mui/icons-material/Search';
import StockTable from './Stock/StockTable';
import { styled } from '@mui/material/styles';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CloseIcon from '@mui/icons-material/Close';
import CheckIcon from '@mui/icons-material/Check';
import FreeSoloAutoComplete from '../Components/FreeSoloAutoComplete';

function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 0 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const Stock = () => {

    const [age, setAge] = React.useState('');

    const handleChange = (event) => {
        setAge(event.target.value);
    }

    // tabs
    const [value, setValue] = React.useState(0);

    const handleChangeT = (event, newValue) => {
        setValue(newValue);
    };

    // dialog
    const BootstrapDialog = styled(Dialog)(({ theme }) => ({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2),
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1),
        },
    }));

    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };



    return (
        <>

            <Box className="page-header-bar">
                <Box id='heading' className='fx_sb'>
                    <Box>
                        <Typography variant='h3' className='col1 fw5'>Stock Overview</Typography>
                    </Box>
                    <Box className='fx_fs py1'>
                        <Box>
                            <Button variant="contained" startIcon={<AddIcon />} size='small' className='main_btn' onClick={handleClickOpen}>New Stock</Button>
                        </Box>
                    </Box>
                </Box>
            </Box>

            <Box className="scrolled-content">
                <Box sx={{ width: '100%' }}>
                    <Grid container spacing={2} justifyContent='flex-end'>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Tabs value={value} onChange={handleChangeT} aria-label="basic tabs example">
                                <Tab label="All" {...a11yProps(0)} disableRipple />
                                <Tab label="In Stock" {...a11yProps(1)} disableRipple />
                                <Tab label="Assigned" {...a11yProps(2)} disableRipple />
                            </Tabs>
                        </Grid>
                    </Grid>
                </Box>
                <CustomTabPanel value={value} index={0}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={9} md={8} sm={12} xs={12}>
                                <Grid container spacing={1} alignItems='center' justifyContent='flex-end'>
                                    <Grid item lg={3} md={4} sm={6} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={demo_options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Name" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={4} sm={6} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={demo_options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Brand" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <StockTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
                <CustomTabPanel value={value} index={1}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={9} md={8} sm={12} xs={12}>
                                <Grid container spacing={1} alignItems='center' justifyContent='flex-end'>
                                    <Grid item lg={3} md={4} sm={6} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={demo_options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Name" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={4} sm={6} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={demo_options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Brand" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <StockTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
                <CustomTabPanel value={value} index={2}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={9} md={8} sm={12} xs={12}>
                                <Grid container spacing={1} alignItems='center' justifyContent='flex-end'>
                                    <Grid item lg={3} md={4} sm={6} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={demo_options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Name" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={4} sm={6} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={demo_options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Brand" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <StockTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
            </Box>



            <Dialog id='dialog' maxWidth='md'
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >

                <DialogTitle id="alert-dialog-title" className='col1'>
                    <Typography variant='h4' className='fw5'>
                        {"Stock Addition Form"}
                    </Typography>
                </DialogTitle>
                <Divider />
                <IconButton
                    size='medium'
                    aria-label="close"
                    onClick={handleClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,

                    }}
                >
                    <CloseIcon fontSize='small' />
                </IconButton>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box className='fx_fs'>
                            {/* <Button variant='text' endIcon={<InfoOutlinedIcon fontSize='small' />} className='head_btn content fw5'>Inventory Details</Button> */}
                            <Box mr={1}>
                                <Typography variant='h5' className='content fw5'>Inventory Details</Typography>
                            </Box>
                            <Tooltip title='Lorem Ipsum is simply dummy text of the printing and typesetting industry.' arrow placement='right'>
                                <IconButton><InfoOutlinedIcon fontSize='small' /></IconButton>
                            </Tooltip>
                        </Box>
                        <Grid container spacing={2} pt={1}>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <Autocomplete
                                        disablePortal
                                        size='small'
                                        id="combo-box-demo"
                                        options={demo_options}
                                        fullWidth
                                        renderInput={(params) => <TextField variant='outlined' {...params} label="Select Item" size='small' />}
                                    />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Brand' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Model' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Size' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Core and Clock speed' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Serial Number' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Note/Remark' size="small" variant="outlined" fullWidth multiline rows={3} />
                                </Box>
                            </Grid>
                        </Grid>

                        <Box pt={2} className='fx_fe'>
                            <Stack direction={'row'} spacing={1}>
                                <Button variant="contained" size='small' className='sec_btn bg3 wh' endIcon={<CloseIcon />} onClick={handleClose}>Cancel</Button>

                                <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} onClick={handleClose}>Save</Button>
                            </Stack>
                        </Box>
                    </DialogContentText>
                </DialogContent>

            </Dialog>


        </>
    )
}

export default Stock

const city = [
    { label: 'Mumbai' },
    { label: 'Nashik' },
    { label: 'GiftCity' },
]

const name = [
    { label: 'Laptop' },
    { label: 'Computer' },
    { label: 'Keyboard' },
]

const demo_options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
]
