import { Box } from '@mui/material'
import React, { useState, useEffect, useMemo } from 'react'
import { AgGridReact } from 'ag-grid-react'; // AG Grid Component
import "ag-grid-community/styles/ag-grid.css"; // Mandatory CSS required by the grid
import "ag-grid-community/styles/ag-theme-quartz.css"; // Optional Theme applied to the grid
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import TableSkeleton from '../../Components/TableSkeleton';

export default function BranchTable() {

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const fetchData = async () => {
            setTimeout(() => {
                setLoading(false);
            }, 200);
        };
        fetchData();
    }, []);

    // Row Data: The data to be displayed.
    const [rowData, setRowData] = useState([
        { No: "01", BranchCode: "95111", City: "San Jose", State: 'San Jose', Telephone: '(719) 686-3920', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "02", BranchCode: "95111", City: "San Jose", State: 'San Jose', Telephone: '(719) 686-3920', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "03", BranchCode: "95111", City: "San Jose", State: 'San Jose', Telephone: '(719) 686-3920', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "04", BranchCode: "43215", City: "Columbus", State: 'Columbus', Telephone: '(973) 863-0348', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "05", BranchCode: "43215", City: "Columbus", State: 'Columbus', Telephone: '(973) 863-0348', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "06", BranchCode: "43215", City: "Columbus", State: 'Columbus', Telephone: '(973) 863-0348', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "07", BranchCode: "43215", City: "Columbus", State: 'Columbus', Telephone: '(973) 863-0348', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "08", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "09", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "10", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "11", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "12", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "07", BranchCode: "43215", City: "Columbus", State: 'Columbus', Telephone: '(973) 863-0348', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "08", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "09", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "10", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "11", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
        { No: "12", BranchCode: "90012", City: "Charlotte", State: 'Charlotte', Telephone: '(570) 522-9163', Email: 'salee@yahoo.com', AddedBy: 'Maria Gomez', LastUpdated: '02/03/2020', },
    ]);

    // Column Definitions: Defines the columns to be displayed.
    const [colDefs, setColDefs] = useState([
        { field: "No", minWidth: 70, maxWidth: 70, cellClass: 'al_right' },
        { field: "BranchCode", minWidth: 120, cellClass: 'al_right' },
        { field: "City", minWidth: 100, },
        { field: "State", minWidth: 100, },
        { field: "Telephone", minWidth: 150, },
        { field: "Email", minWidth: 150, },
        { field: "AddedBy", minWidth: 150, },
        { field: "LastUpdated", minWidth: 150, },
    ]);


    // Apply settings across all columns
    const defaultColDef = useMemo(() => ({
        filter: false,
        editable: false,
        flex: 1,
        sortable: true,
    }), []);

    const rowHeight = 30;
    const headerHeight = 30;

    // Container: Defines the grid's theme & dimensions.

    const rowStyle = { background: '#fafafa' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#fff' };
        }
    };

    return (
        <>
            <Box id='table'>

                <Box id="custom-pagination"
                    className={
                        "ag-theme-quartz"
                    }
                    style={{ width: '100%', height: '65vh' }}
                >
                    {loading ? (
                        <Box>
                            <TableSkeleton />
                        </Box>
                    ) : (
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={colDefs}
                            defaultColDef={defaultColDef}
                            rowHeight={rowHeight}
                            headerHeight={headerHeight}
                            getRowStyle={getRowStyle}
                            rowStyle={rowStyle}
                        />
                    )}
                    <Box id='table-info' className='fx_sb' pt={1}>
                        <AgGridInfo />
                        <AgGridPagination />
                    </Box>
                </Box>
            </Box>

        </>
    )
}
