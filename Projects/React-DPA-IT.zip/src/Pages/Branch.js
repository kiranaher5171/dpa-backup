import { Autocomplete, Box, Button, Dialog, DialogContent, DialogContentText, DialogTitle, Divider, Grid, IconButton,  Stack, TextField, Typography } from '@mui/material'
import { styled } from '@mui/material/styles';
import React, { useState } from 'react';
import AddIcon from '@mui/icons-material/Add';
import PropTypes from 'prop-types';
import BranchTable from './Branch/BranchTable';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';

import 'react-phone-number-input/style.css'
import PhoneInput from 'react-phone-number-input'
import FreeSoloAutoComplete from '../Components/FreeSoloAutoComplete';

function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 0 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const Branch = () => {

    const [age, setAge] = React.useState('');

    const handleChange = (event) => {
        setAge(event.target.value);
    }

    // tabs
    const [value, setValue] = React.useState(0);

    const handleChangeT = (event, newValue) => {
        setValue(newValue);
    };

    // dialog
    const BootstrapDialog = styled(Dialog)(({ theme }) => ({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2),
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1),
        },
    }));

    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    // phone number
    const [valuePH, setValuePH] = useState()

    return (
        <>
            <Box className="page-header-bar">
                <Box id='heading' className='fx_sb'>
                    <Box>
                        <Typography variant='h3' className='col1 fw5'>Branches</Typography>
                    </Box>
                    <Box className='fx_fs py1'>
                        <Box>
                            <Button variant="contained" startIcon={<AddIcon />} size='small' className='main_btn' onClick={handleClickOpen}>New Branch</Button>
                        </Box>
                    </Box>
                </Box>
            </Box>


            <Box className="scrolled-content" mt={2}>
                <Box className='whitebx bxsh3'>
                    <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                        <Grid item lg={3} md={4} sm={4} xs={12}>
                            <FreeSoloAutoComplete />
                        </Grid>
                        <Grid item lg={9} md={8} sm={4} xs={12}>
                            <Grid container spacing={1} alignItems='center' justifyContent='flex-end'>
                                <Grid item lg={3} md={4} sm={12} xs={12}>
                                    <Box className="ol_txtfield">
                                        <Autocomplete
                                            disablePortal
                                            size='small'
                                            id="combo-box-demo"
                                            options={demo_options}
                                            fullWidth
                                            renderInput={(params) => <TextField variant='outlined' {...params} label="Status" size='small' />}
                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>

                    <Box pt={1}>
                        <BranchTable />
                    </Box>
                </Box>
            </Box>



            <Dialog id='dialog' maxWidth='md'
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >

                <DialogTitle id="alert-dialog-title" className='col1'>
                    <Typography variant='h4' className='fw5'>
                        {"Add Branch"}
                    </Typography>
                </DialogTitle>
                <Divider />
                <IconButton
                    size='medium'
                    aria-label="close"
                    onClick={handleClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,

                    }}
                >
                    <CloseIcon fontSize='small' />
                </IconButton>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box className='fx_fs'>
                            {/* <Button variant='text' endIcon={<InfoOutlinedIcon fontSize='small' />} className='head_btn content fw5'>Inventory Details</Button> */}
                            <Box>
                                <Typography variant='h5' className='content fw5'>Branch Information</Typography>
                            </Box>
                        </Box>
                        <Grid container spacing={2}>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Organization' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Branch Code' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    {/* <TextField id="outlined-basic" className='textfield' label='Phone Number' size="small" variant="outlined" fullWidth /> */}
                                    <PhoneInput
                                        className='phonefield' fullWidth variant="outlined"
                                        placeholder="Enter phone number"
                                        value={valuePH}
                                        onChange={setValuePH} />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Email' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Address' size="small" variant="outlined" fullWidth multiline rows={3} />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <Autocomplete
                                        disablePortal
                                        size='small'
                                        id="combo-box-demo"
                                        options={demo_options}
                                        fullWidth
                                        renderInput={(params) => <TextField variant='outlined' {...params} label="Country" size='small' />}
                                    />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className="ol_txtfield" pt={1}>
                                    <Autocomplete
                                        disablePortal
                                        size='small'
                                        id="combo-box-demo"
                                        options={demo_options}
                                        fullWidth
                                        renderInput={(params) => <TextField variant='outlined' {...params} label="State" size='small' />}
                                    />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className="ol_txtfield" pt={1}>
                                    <Autocomplete
                                        disablePortal
                                        size='small'
                                        id="combo-box-demo"
                                        options={demo_options}
                                        fullWidth
                                        renderInput={(params) => <TextField variant='outlined' {...params} label="City" size='small' />}
                                    />
                                </Box>
                            </Grid>

                        </Grid>

                        <Box pt={1} className='fx_fe'>
                            <Stack direction={'row'} spacing={1}>
                                <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} onClick={handleClose}>Save</Button>

                                <Button variant="contained" size='small' className='sec_btn bg1 wh' onClick={handleClose}>Set as current branch</Button>
                            </Stack>
                        </Box>
                    </DialogContentText>
                </DialogContent>

            </Dialog>


        </>
    )
}

export default Branch

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
]

const city = [
    { label: 'Mumbai' },
    { label: 'Nashik' },
    { label: 'All' },
]

const country = [
    { label: 'India' },
    { label: 'US' },
]

const state = [
    { label: 'Maharashtra' },
    { label: 'Gujarat' },
]

const demo_options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
]
