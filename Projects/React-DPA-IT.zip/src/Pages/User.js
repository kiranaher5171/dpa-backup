import { Autocomplete, Box, Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Divider, FormControl, Grid, IconButton, InputAdornment, InputLabel, ListItemIcon, ListItemText, MenuItem, OutlinedInput, Stack, Tab, Tabs, TextField, Typography } from '@mui/material'
import React, {useState} from 'react';
import AddIcon from '@mui/icons-material/Add';
import PropTypes from 'prop-types';
import SearchIcon from '@mui/icons-material/Search';
import UserTable from './User/UserTable';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import CheckIcon from '@mui/icons-material/Check';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import FreeSoloAutoComplete from '../Components/FreeSoloAutoComplete';

function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 0 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const User = () => {

    const [age, setAge] = React.useState('');


    // tabs
    const [value, setValue] = React.useState(0);

    const handleChangeT = (event, newValue) => {
        setValue(newValue);
    };

    // dialog
    const BootstrapDialog = styled(Dialog)(({ theme }) => ({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2),
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1),
        },
    }));

    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    // password
    const [values, setValues] = useState({
        password: '',
        showPassword: false,
    });

    const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
    };

    const handleClickShowPassword = () => {
        setValues({ ...values, showPassword: !values.showPassword });
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };



    return (
        <>

            <Box className="page-header-bar">
                <Box id='heading' className='fx_sb'>
                    <Box>
                        <Typography variant='h3' className='col1 fw5'>Users</Typography>
                    </Box>
                    <Box className='fx_fs py1'>
                        <Box>
                            <Button variant="contained" startIcon={<AddIcon />} size='small' className='main_btn' onClick={handleClickOpen}>New User</Button>
                        </Box>
                    </Box>
                </Box>
            </Box>

            <Box className="scrolled-content" mt={2}>
                <Box className='whitebx bxsh3'>
                    <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                        <Grid item lg={3} md={3} sm={4} xs={12}>
                            <FreeSoloAutoComplete />
                        </Grid>

                        <Grid item lg={2} md={3} sm={4} xs={12}>
                            <Box className="ol_txtfield">
                                <Autocomplete
                                    disablePortal
                                    size='small'
                                    id="combo-box-demo"
                                    options={demo_options}
                                    fullWidth
                                    renderInput={(params) => <TextField variant='outlined' {...params} label="Brand" size='small' />}
                                />
                            </Box>
                        </Grid>
                    </Grid>

                    <Box pt={1}>
                        <UserTable />
                    </Box>
                </Box>
            </Box>


            <Dialog id='dialog' maxWidth='md'
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title" className='col1'>
                    <Typography variant='h4' className='fw5'>
                        {"Add User"}
                    </Typography>
                </DialogTitle>
                <Divider />
                <IconButton
                    size='medium'
                    aria-label="close"
                    onClick={handleClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,

                    }}
                >
                    <CloseIcon fontSize='small' />
                </IconButton>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Grid container spacing={2}>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield">
                                    <TextField id="outlined-basic" className='textfield' label='First Name' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield">
                                    <TextField id="outlined-basic" className='textfield' label='Last Name' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield">
                                    <TextField id="outlined-basic" className='textfield' label='Email' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield">
                                    <Autocomplete
                                        disablePortal
                                        size='small'
                                        id="combo-box-demo"
                                        options={demo_options}
                                        fullWidth
                                        renderInput={(params) => <TextField variant='outlined' {...params} label="Branch" size='small' />}
                                    />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={0}>
                                    <Autocomplete
                                        disablePortal
                                        size='small'
                                        id="combo-box-demo"
                                        options={demo_options}
                                        fullWidth
                                        renderInput={(params) => <TextField variant='outlined' {...params} label="Role" size='small' />}
                                    />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='ol_txtfield' mt={0}>
                                    <TextField id="outlined-basic" className='textfield' label='Confirm Password' size="small" variant="outlined" fullWidth
                                        type={values.showPassword ? 'text' : 'password'}
                                        value={values.password}
                                        onChange={handleChange('password')}
                                        InputProps={{
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        size="small"
                                                        aria-label="toggle password visibility"
                                                        onClick={handleClickShowPassword}
                                                        onMouseDown={handleMouseDownPassword}
                                                        edge="end"
                                                    >
                                                        {values.showPassword ? <Visibility fontSize="small" /> : <VisibilityOff fontSize="small" />}
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                    />
                                </Box>
                            </Grid>
                        </Grid>

                        <Box pt={3} className='fx_fe'>
                            <Stack direction={'row'} spacing={1}>
                                <Button variant="contained" size='small' className='sec_btn bg3 wh' endIcon={<CloseIcon />} onClick={handleClose}>Cancel</Button>

                                <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} onClick={handleClose}>Save</Button>
                            </Stack>
                        </Box>
                    </DialogContentText>
                </DialogContent>

            </Dialog>


        </>
    )
}

export default User

const role = [
    { label: 'Admin' },
    { label: 'Super Admin' },
]

const city = [
    { label: 'Mumbai' },
    { label: 'Nashik' },
    { label: 'All' },
]

const demo_options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
]


const options = [
    { label: 'Name 1 (1234)', icon: <AccountCircleIcon sx={{ fontSize: '20px' }} className='content' />, location: 'Mumbai' },
    { label: 'Name 2 (1234)', icon: <AccountCircleIcon sx={{ fontSize: '20px' }} className='content' />, location: 'Nashik' },
    { label: 'Name 3 (1234)', icon: <AccountCircleIcon sx={{ fontSize: '20px' }} className='content' />, location: 'GiftCity' },
]
