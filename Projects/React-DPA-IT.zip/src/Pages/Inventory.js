import { Autocomplete, Box, Button, Divider,  Grid, IconButton,  Tab, Tabs, TextField, Typography, Dialog, DialogContent, DialogContentText, DialogTitle, Stack, } from '@mui/material'
import React from 'react';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import DownloadIcon from '@mui/icons-material/Download';
import AddIcon from '@mui/icons-material/Add';
import PropTypes from 'prop-types';
import { Print } from '@mui/icons-material';
import LogTable from './Inventory/LogTable';
import { Link } from 'react-router-dom';
import CloseIcon from '@mui/icons-material/Close';
import CheckIcon from '@mui/icons-material/Check';
import FileUpload from '../Components/FileUpload';
import confirm from "../Asset/Images/exclamation_sign.gif"
import FreeSoloAutoComplete from '../Components/FreeSoloAutoComplete';

function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 0 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const Inventory = () => {

    const [age, setAge] = React.useState('');

    const handleChange = (event) => {
        setAge(event.target.value);
    }

    // tabs
    const [value, setValue] = React.useState(0);

    const handleChangeT = (event, newValue) => {
        setValue(newValue);
    };


    const [months, setMonths] = React.useState('');

    const handleChangeM = (event) => {
        setMonths(event.target.value);
    }

    // import dialog
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    // export dialog
    const [openE, setOpenE] = React.useState(false);

    const handleClickOpenE = () => {
        setOpenE(true);
    };
    const handleCloseE = () => {
        setOpenE(false);
    };



    return (
        <>

            <Box className="page-header-bar">
                <Box id='heading' className='fx_sb'>
                    <Box>
                        <Typography variant='h3' className='col1 fw5'>Logs</Typography>
                    </Box>
                    <Box className='fx_fs'>
                        <Box className='py1' mr={1}>
                            <Button variant="contained" startIcon={<DownloadIcon />} size='small' className='main_btn' onClick={handleClickOpen}>Import</Button>
                        </Box>
                        <Box className='py1' mr={1}>
                            <Button variant="contained" startIcon={<FileUploadIcon />} size='small' className='main_btn' onClick={handleClickOpenE}>Export</Button>
                        </Box>
                        <Box className='py1'>
                            <Link to='/inventory-management-allocate-asset'>
                                <Button variant="contained" startIcon={<AddIcon />} size='small' className='main_btn'>New Asset</Button>
                            </Link>
                        </Box>
                    </Box>
                </Box>
            </Box>

            <Box className="scrolled-content">
                <Box sx={{ width: '100%' }}>
                    <Grid container spacing={2} justifyContent='flex-end' alignItems='end'>
                        <Grid item lg={11} md={10} sm={11} xs={12}>
                            <Tabs value={value} onChange={handleChangeT} aria-label="basic tabs example">
                                <Tab label="All" {...a11yProps(0)} disableRipple />
                                <Tab label="Laptops" {...a11yProps(1)} disableRipple />
                                <Tab label="Desktops" {...a11yProps(2)} disableRipple />
                            </Tabs>
                        </Grid>
                        <Grid item lg={1} md={2} sm={1} xs={12}>
                            <Box className='fx_fe' pb={'4px'}>
                                {/* <IconButton size='medium' className='ico_btn_bg'>
                                    <Print fontSize='small' />
                                </IconButton> */}
                                <Button variant="contained" startIcon={<Print />} size='small' className='sec_btn bg3 wh'>Print</Button>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>
                <CustomTabPanel value={value} index={0}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={9} md={9} sm={12} xs={12}>
                                <Grid container spacing={1} alignItems='center' justifyContent='flex-end'>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={duration}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Duration" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                id="combo-box-demo"
                                                options={city}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Branch" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                id="combo-box-demo"
                                                options={options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Status" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <LogTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
                <CustomTabPanel value={value} index={1}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={9} md={9} sm={12} xs={12}>
                                <Grid container spacing={1} alignItems='center' justifyContent='flex-end'>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={duration}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Duration" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                id="combo-box-demo"
                                                options={city}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Branch" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                id="combo-box-demo"
                                                options={options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Status" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <LogTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
                <CustomTabPanel value={value} index={2}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={9} md={9} sm={12} xs={12}>
                                <Grid container spacing={1} alignItems='center' justifyContent='flex-end'>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                size='small'
                                                id="combo-box-demo"
                                                options={duration}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Duration" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                id="combo-box-demo"
                                                options={city}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Branch" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className="ol_txtfield">
                                            <Autocomplete
                                                disablePortal
                                                id="combo-box-demo"
                                                options={options}
                                                fullWidth
                                                renderInput={(params) => <TextField variant='outlined' {...params} label="Status" size='small' />}
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <LogTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
            </Box>


            <Dialog id='dialog' maxWidth='sm'
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title" className='col1'>
                    <Typography variant='h4' className='fw5'>
                        {"Import File"}
                    </Typography>
                </DialogTitle>
                <Divider />
                <IconButton
                    size='medium'
                    aria-label="close"
                    onClick={handleClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,

                    }}
                >
                    <CloseIcon fontSize='small' />
                </IconButton>
                <DialogContent>
                    <FileUpload />
                </DialogContent>
            </Dialog>

            <Dialog id='dialog' maxWidth='sm'
                open={openE}
                onClose={handleCloseE}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box className='al_center' pt={1}>
                            <img src={confirm} alt='Forgot Password' className='form_logo' />
                        </Box>
                        <Box className="al_center" mt={2}>
                            <Typography variant='h2' className='col1 fw6'> Confirmation Required </Typography>
                        </Box>
                        <Box className="al_center" mt={1}>
                            <Typography variant='h6' className='content fw5'> Are you sure to export the data? </Typography>
                        </Box>
                        <Box pt={3} className='fx_c'>
                            <Stack direction={'row'} spacing={1}>
                                <Button variant="contained" size='small' className='sec_btn bg3 wh' endIcon={<CloseIcon />} onClick={handleCloseE}>No</Button>

                                <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} onClick={handleCloseE}>Yes</Button>
                            </Stack>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog>

        </>
    )
}

export default Inventory

const city = [
    { label: 'Mumbai' },
    { label: 'Nashik' },
    { label: 'All' },
]

const duration = [
    { label: 'Today' },
    { label: 'Yesterday' },
    { label: 'Last 7 days' },
    { label: 'This week' },
    { label: 'This month' },
    { label: 'Last month' },
    { label: 'Last quarter' },
    { label: 'Exact Date' },
]

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
]


