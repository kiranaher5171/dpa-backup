import { Box } from '@mui/material'
import React, { useState, useEffect, useMemo } from 'react'
import { AgGridReact } from 'ag-grid-react'; // AG Grid Component
import "ag-grid-community/styles/ag-grid.css"; // Mandatory CSS required by the grid
import "ag-grid-community/styles/ag-theme-quartz.css"; // Optional Theme applied to the grid
import TableSkeleton from '../../Components/TableSkeleton';

export default function AssetTable() {

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const fetchData = async () => {
            setTimeout(() => {
                setLoading(false);
            }, 200);
        };
        fetchData();
    }, []);

    // Row Data: The data to be displayed.
    const [rowData, setRowData] = useState([
        { SrNo: "01", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "02", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "03", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "04", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "05", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "06", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "07", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "08", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "09", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "10", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "11", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
        { SrNo: "12", "Branch": "Acer", Model: "Aspire 5 A-15-45", 'Core and Clock speed': 'i3-3220 @ 3.30 GHzr', Qty: '4', },
    ]);

    // Column Definitions: Defines the columns to be displayed.
    const [columnDefs, setColDefs] = useState([
        { field: "SrNo", minWidth: 80, maxWidth: 80, cellClass: 'al_right' },
        { field: "Branch", minWidth: 100, maxWidth: 150, },
        { field: "Model", minWidth: 120, },
        { field: "Core and Clock speed", minWidth: 180, },
        { field: "Qty", minWidth: 70, maxWidth: 70, cellClass: 'al_right' },
    ]);


    // Apply settings across all columns
    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            filter: false,
            editable: false,
            sortable: true,
        };
    }, []);


    // header and row height
    const rowHeight = 30;
    const headerHeight = 30;

    // Container: Defines the grid's theme & dimensions.

    const rowStyle = { background: '#fafafa' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#fff' };
        }
    };

    return (
        <>
            <Box id='table'>

                <Box className="ag-theme-quartz" style={{ width: '100%', height: '265px', }}>
                    {loading ? (
                        <Box>
                            <TableSkeleton />
                        </Box>
                    ) : (
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            rowHeight={rowHeight}
                            headerHeight={headerHeight}
                            getRowStyle={getRowStyle}
                            rowStyle={rowStyle}
                        />
                    )}
                </Box>
            </Box>

        </>
    )
}
