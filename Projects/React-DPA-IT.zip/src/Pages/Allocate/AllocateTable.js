import { Autocomplete, IconButton, Tooltip, Box, TextField, MenuItem } from '@mui/material';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import { AgGridReact } from 'ag-grid-react';
import React, { useMemo, useRef, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import DeleteIcon from '@mui/icons-material/Delete';
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import InfoIcon from '@mui/icons-material/Info';
import TableSkeleton from '../../Components/TableSkeleton';


const PeripheralsTable = () => {

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const fetchData = async () => {
            setTimeout(() => {
                setLoading(false);
            }, 200);
        };
        fetchData();
    }, []);

    const gridRef = useRef();
    const [rowData, setRowData] = useState([
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        }, {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },
        {
            No: '1',
            items: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Items" size='small' />}
                />
            </Box>,
            serialNumber: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Serial Number" size="small" variant="outlined" fullWidth
                />
            </Box>,
            brand: <Box className="auto_field">
                <Autocomplete
                    fullWidth
                    openOnFocus={false}
                    id="combo-box-demo"
                    options={options}
                    size='small'
                    getOptionLabel={(option) => option.label}
                    renderOption={(props, option) => (
                        <MenuItem {...props} className="tb-autocomplete-opt">
                            {option.label}
                        </MenuItem>
                    )}
                    renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Brand" size='small' />}
                />
            </Box>,
            model: <Box className="tb_input">
                <TextField id="outlined-basic" className='textfield' placeholder="Model" size="small" variant="outlined" fullWidth
                />
            </Box>,
            remark: "Text Here",
            status:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Status" size='small' />}
                    />
                </Box>
        },



    ]);
    const [columnDefs] = useState([
        { headerName: 'No', field: 'No', minWidth: 70, maxWidth: 70, cellClass: 'al_right' },
        { headerName: 'Items', field: 'items', minWidth: 150, maxWidth: 150, cellRenderer: (params) => params.data.items, },
        { headerName: 'Serial Number', field: 'serial number', minWidth: 200, maxWidth: 200, cellRenderer: (params) => params.data.serialNumber, },
        { headerName: 'Brand', field: 'brand', minWidth: 200, maxWidth: 200, cellRenderer: (params) => params.data.brand, },
        { headerName: 'Model', field: 'model', minWidth: 200, maxWidth: 200, cellRenderer: (params) => params.data.model, },
        {
            headerName: 'Remark', cellClass: 'al_center', field: 'remark', minWidth: 90, cellRenderer: (params) => <>
                <Tooltip title="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s." arrow placement='bottom'>
                    <IconButton size='small'>
                        <InfoIcon fontSize='small' className='edit_icon gry' />
                    </IconButton>
                </Tooltip>
            </>
        },
        {
            headerName: 'Status', field: 'status', minWidth: 200, maxWidth: 200, cellRenderer: (params) => params.data.status,
        },
        {
            minWidth: 60, maxWidth: 60, cellClass: 'al_center', cellRenderer: (params) => <>
                <Tooltip title="Delete" arrow placement='bottom'>
                    <IconButton size='small'>
                        <DeleteIcon fontSize='small' className='edit_icon rd' />
                    </IconButton>
                </Tooltip>
            </>
        },

    ]);
    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            filter: false,
            editable: false,
            sortable: true,
        };
    }, []);




    // header and row height
    const rowHeight = 30;
    const headerHeight = 30;

    // Container: Defines the grid's theme & dimensions.


    const rowStyle = { background: '#fafafa' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#fff' };
        }
    };


    return (
        <Box className="test-container">
            <Box id="custom-pagination" className="ag-theme-quartz" style={{ width: '100%', height: '50vh' }}>

                {loading ? (
                    <Box>
                        <TableSkeleton />
                    </Box>
                ) : (
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={columnDefs}
                        defaultColDef={defaultColDef}
                        rowHeight={rowHeight}
                        headerHeight={headerHeight}
                        getRowStyle={getRowStyle}
                        rowStyle={rowStyle}
                    />
                )}
                <Box id='table-info' className='fx_sb' pt={1}>
                    <AgGridInfo />
                    <AgGridPagination />
                </Box>
            </Box>
        </Box>
    );
};

export default PeripheralsTable;


const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]


