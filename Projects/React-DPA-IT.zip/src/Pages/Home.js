import { Autocomplete, Box, Button, Grid, TextField, Typography } from '@mui/material'
import React from 'react';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import up from '../Asset/Images/up.svg'
import down from '../Asset/Images/down.svg'
import InventoryOutlinedIcon from '@mui/icons-material/InventoryOutlined';
import RecyclingIcon from '@mui/icons-material/Recycling';
import EngineeringIcon from '@mui/icons-material/Engineering';
import BlockIcon from '@mui/icons-material/Block';
import Detailed from './Dashboard/Detailed';
import Statistics from './Dashboard/Statistics';
import ActivityLog from './Dashboard/ActivityLog';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import { Link } from 'react-router-dom';
import dayjs from 'dayjs';
import SimpleDatePicker from '../Components/SimpleDatePicker';
import AdvancedSearchPopup from '../Components/AdvancedSearchPopup';


const Home = () => {




  return (
    <>
      <Box className="page-header-bar">
        <Box id='heading' className='fx_sb'>
          <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
            <Grid item lg={4} md={12} sm={12} xs={12}>
              <Box>
                <Typography variant='h3' className='col1 fw5'>Dashboard</Typography>
              </Box>
            </Grid>
            <Grid item lg={2} md={3} sm={6} xs={12}>
              <Box className="ol_txtfield py1">
                <Autocomplete
                  disablePortal
                  id="combo-box-demo"
                  options={city}
                  fullWidth
                  renderInput={(params) => <TextField  {...params} variant='outlined' label="Branch" size='small' />}
                />
              </Box>
            </Grid>
            <Grid item lg={2} md={3} sm={6} xs={12}>
              <Box className="ol_txtfield py1">
                <Autocomplete
                  disablePortal
                  id="combo-box-demo"
                  options={duration}
                  fullWidth
                  renderInput={(params) => <TextField  {...params} variant='outlined' label="Duration" size='small' />}
                />
              </Box>
            </Grid>
            <Grid item lg={2} md={3} sm={6} xs={12}>
              <Box className='py1'>
                <SimpleDatePicker pickerLabel='From Date' />
              </Box>
            </Grid>
            <Grid item lg={2} md={3} sm={6} xs={12}>
              <Box  className='py1'>
                <SimpleDatePicker pickerLabel='To Date' />
              </Box>
            </Grid>
          </Grid>

          <Box style={{ marginLeft: '8px' }} className='fx_fe py1'>
            <Button fullWidth variant="contained" startIcon={<FileUploadIcon />} size='small' className='main_btn'>Export</Button>
          </Box>
        </Box>
      </Box>

      <Box className="scrolled-content" mt={2}>
        <Box className='whitebx bxsh3'>
          <Box className="tb_head">
            <Box className='fx_sb'>
              <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                <Grid item lg={9} md={9} sm={9} xs={12}>
                  <Box>
                    <Typography variant='h4' className='fw5 content'>Executive Summary</Typography>
                  </Box>
                </Grid>
                <Grid item lg={3} md={3} sm={3} xs={12}>
                  <Box className="ol_txtfield">
                    <Autocomplete
                      disablePortal
                      id="combo-box-demo"
                      options={demo_options}
                      fullWidth
                      renderInput={(params) => <TextField  {...params} variant='outlined' label="Asset" size='small' />}
                    />
                  </Box>
                </Grid>
              </Grid>


              <Box style={{ minWidth: '120px', marginLeft: '8px' }} className='fx_fe'>
                <Link to='/inventory-management'>
                  <Button fullWidth variant="contained" size='small' className='main_btn' endIcon={<KeyboardDoubleArrowRightIcon />}>View Details</Button>
                </Link>
              </Box>
            </Box>
          </Box>

          <Box mt={2} mb={1}>
            <Grid container spacing={2}>
              <Grid item lg={3} md={6} sm={6} xs={12}>
                <Box className='whitebx bxsh2 fx_sb up_grad'>
                  <Box p={1}>
                    <Typography variant='h6' className='content fw'>
                      Available/In Stock
                    </Typography>
                    <Typography variant='h2' className='col2 fw6' py={1}>
                      23,000
                    </Typography>
                    <Button variant='text' startIcon={<img src={up} className='up' alt='UP' />} disableRipple disabled className='txt_btn grn fw5' >
                      5.39%
                    </Button>
                  </Box>
                  <Box className='ex_icon'>
                    <InventoryOutlinedIcon fontSize='large' />
                  </Box>
                </Box>
              </Grid>
              <Grid item lg={3} md={6} sm={6} xs={12}>
                <Box className='whitebx bxsh2 fx_sb up_grad'>
                  <Box p={1}>
                    <Typography variant='h6' className='content fw'>
                      Allocated/In Use
                    </Typography>
                    <Typography variant='h2' className='col2 fw6' py={1}>
                      35,700
                    </Typography>
                    <Button variant='text' startIcon={<img src={up} className='up' alt='UP' />} disableRipple disabled className='txt_btn grn fw5' >
                      2.39%
                    </Button>
                  </Box>
                  <Box className='ex_icon'>
                    <EngineeringIcon fontSize='large' />
                  </Box>
                </Box>
              </Grid>
              <Grid item lg={3} md={6} sm={6} xs={12}>
                <Box className='whitebx bxsh2 fx_sb down_grad'>
                  <Box p={1}>
                    <Typography variant='h6' className='content fw'>
                      In Repair/Maintainance
                    </Typography>
                    <Typography variant='h2' className='col2 fw6' py={1}>
                      05,689
                    </Typography>
                    <Button variant='text' startIcon={<img src={down} className='up' alt='Down' />} disableRipple disabled className='txt_btn rd fw5' >
                      4.58%
                    </Button>
                  </Box>
                  <Box className='ex_icon'>
                    <RecyclingIcon fontSize='large' />
                  </Box>
                </Box>
              </Grid>
              <Grid item lg={3} md={6} sm={6} xs={12}>
                <Box className='whitebx bxsh2 fx_sb up_grad'>
                  <Box p={1}>
                    <Typography variant='h6' className='content fw'>
                      Retired
                    </Typography>
                    <Typography variant='h2' className='col2 fw6' py={1}>
                      12,562
                    </Typography>
                    <Button variant='text' startIcon={<img src={up} className='up' alt='UP' />} disableRipple disabled className='txt_btn grn fw5' >
                      2.98%
                    </Button>
                  </Box>
                  <Box className='ex_icon'>
                    <BlockIcon fontSize='large' />
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Box>

        <Box mb={2}>
          <Detailed />
        </Box>

        <Box mb={2}>
          <Statistics />
        </Box>

        <Box mb={2}>
          <ActivityLog />
        </Box>

        <Box>
          <AdvancedSearchPopup />
        </Box>

      </Box>



    </>
  )
}

export default Home

const city = [
  { label: 'Mumbai' },
  { label: 'Nashik' },
  { label: 'All' },
]

const duration = [
  { label: 'Today' },
  { label: 'Yesterday' },
  { label: 'Last 7 days' },
  { label: 'This week' },
  { label: 'This month' },
  { label: 'Last month' },
  { label: 'Last quarter' },
  { label: 'Exact Date' },
]

const demo_options = [
  { label: 'Option 1' },
  { label: 'Option 2' },
  { label: 'Option 3' },
]
