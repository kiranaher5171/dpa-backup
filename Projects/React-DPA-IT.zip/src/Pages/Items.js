import { Autocomplete, Box, Button, DialogActions, DialogContent, DialogTitle, Dialog, Grid, IconButton, InputAdornment, Tab, Tabs, TextField, Typography, DialogContentText, InputLabel, FormControl, FormLabel, RadioGroup, FormControlLabel, Radio, Stack, Divider, Switch } from '@mui/material'
import React from 'react';
import AddIcon from '@mui/icons-material/Add';
import PropTypes from 'prop-types';
import SearchIcon from '@mui/icons-material/Search';
import ItemTable from './Items/ItemTable';
import { styled } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import CheckIcon from '@mui/icons-material/Check';
import FreeSoloAutoComplete from '../Components/FreeSoloAutoComplete';

function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 0 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const Items = () => {

    const [age, setAge] = React.useState('');

    const handleChange = (event) => {
        setAge(event.target.value);
    }

    // tabs
    const [value, setValue] = React.useState(0);

    const handleChangeT = (event, newValue) => {
        setValue(newValue);
    };

    // dialog
    const BootstrapDialog = styled(Dialog)(({ theme }) => ({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2),
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1),
        },
    }));

    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };



    return (
        <>

            <Box className="page-header-bar">
                <Box id='heading' className='fx_sb'>
                    <Box>
                        <Typography variant='h3' className='col1 fw5'>Items</Typography>
                    </Box>
                    <Box className='fx_fs py1'>
                        <Box>
                            <Button variant="contained" startIcon={<AddIcon />} size='small' className='main_btn' onClick={handleClickOpen}>Add New Item</Button>
                        </Box>
                    </Box>
                </Box>
            </Box>

            <Box className="scrolled-content">
                <Box sx={{ width: '100%' }}>
                    <Grid container spacing={2} justifyContent='flex-end'>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Tabs value={value} onChange={handleChangeT} aria-label="basic tabs example">
                                <Tab label="All" {...a11yProps(0)} disableRipple />
                                <Tab label="Assets" {...a11yProps(1)} disableRipple />
                                <Tab label="Peripherals" {...a11yProps(2)} disableRipple />
                            </Tabs>
                        </Grid>
                    </Grid>
                </Box>
                <CustomTabPanel value={value} index={0}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <ItemTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
                <CustomTabPanel value={value} index={1}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <ItemTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
                <CustomTabPanel value={value} index={2}>
                    <Box p={'12px'}>
                        <Grid container spacing={1} alignItems='center' justifyContent='space-between'>
                            <Grid item lg={3} md={3} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                        </Grid>

                        <Box pt={1}>
                            <ItemTable />
                        </Box>
                    </Box>
                </CustomTabPanel>
            </Box>



            <Dialog id='dialog' maxWidth='sm'
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title" className='col1'>
                    <Typography variant='h4' className='fw5'>
                        {"Add Item Code"}
                    </Typography>
                </DialogTitle>
                <Divider />
                <IconButton
                    size='medium'
                    aria-label="close"
                    onClick={handleClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,

                    }}
                >
                    <CloseIcon fontSize='small' />
                </IconButton>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box className="ol_txtfield" pt={1}>
                            <TextField id="outlined-basic" className='textfield' label='Item Name' size="small" variant="outlined" fullWidth />
                        </Box>
                        <Box className="ol_txtfield" pt={1}>
                            <TextField id="outlined-basic" className='textfield' label='Code' size="small" variant="outlined" fullWidth />
                        </Box>
                        <Box className="ol_txtfield" pt={1}>
                            <Autocomplete
                                disablePortal
                                size='small'
                                id="combo-box-demo"
                                options={category}
                                fullWidth
                                renderInput={(params) => <TextField variant='outlined' {...params} label="Category" size='small' />}
                            />
                        </Box>
                        <Box pt={1} className='fx_fs radio_grp'>
                            <FormLabel id="demo-row-radio-buttons-group-label">Type:</FormLabel>
                            <RadioGroup
                                row
                                aria-labelledby="demo-row-radio-buttons-group-label"
                                name="row-radio-buttons-group"
                            >
                                <FormControlLabel value="female" control={<Radio />} label="Asset" />
                                <FormControlLabel value="male" control={<Radio />} label="Peripheral" />
                            </RadioGroup>
                        </Box>

                        <Box pt={3} className='fx_fe'>
                            <Stack direction={'row'} spacing={1}>
                                <Button variant="contained" size='small' className='sec_btn bg3 wh' endIcon={<CloseIcon />} onClick={handleClose}>Cancel</Button>

                                <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} onClick={handleClose}>Save</Button>
                            </Stack>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog>


        </>
    )
}

export default Items

const city = [
    { label: 'Mumbai' },
    { label: 'Nashik' },
    { label: 'All' },
]

const months = [
    { label: 'Today' },
    { label: 'Yesterday' },
    { label: 'Last 7 days' },
    { label: 'This week' },
    { label: 'This month' },
    { label: 'Last month' },
    { label: 'Last quarter' },
    { label: 'Exact Date' },
]

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
]

const category = [
    { label: 'Hardware' },
    { label: 'Software' },
    { label: 'Hardware' },
    { label: 'Software' },
    { label: 'Hardware' },
    { label: 'Software' }, 
    { label: 'Hardware' },
    { label: 'Software' },
    { label: 'Hardware' },
    { label: 'Software' },
    { label: 'Hardware' },
    { label: 'Software' },
    { label: 'Hardware' },
    { label: 'Software' },
]

const type = [
    { label: 'Asset' },
    { label: 'Peripheral' },
]



