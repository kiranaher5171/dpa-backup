import { Autocomplete, Avatar, Box, Button, Checkbox, Dialog, DialogContent, DialogContentText, DialogTitle, Divider, FormControlLabel, Grid, IconButton, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Stack, Tab, Tabs, TextField, Typography, } from '@mui/material'
import React from 'react';
import AddIcon from '@mui/icons-material/Add';
import PropTypes from 'prop-types';
import CloseIcon from '@mui/icons-material/Close';
import CheckIcon from '@mui/icons-material/Check';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { Edit } from '@mui/icons-material';
import PeripheralsTable from './Allocate/AllocateTable';
import AssetTable from './Allocate/AssetTable';
import FreeSoloAutoComplete from '../Components/FreeSoloAutoComplete';

function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 0 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

CustomTabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const Allocate = () => {

    const [age, setAge] = React.useState('');

    const handleChange = (event) => {
        setAge(event.target.value);
    }

    // tabs
    const [value, setValue] = React.useState(0);

    const handleChangeT = (event, newValue) => {
        setValue(newValue);
    };

    // dialog
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    // dialog2
    const [open2, setOpen2] = React.useState(false);

    const handleClickOpen2 = () => {
        setOpen2(true);
    };
    const handleClose2 = () => {
        setOpen2(false);
    };


    return (
        <>
            <Box className="page-header-bar">
                <Box id='heading' className='fx_sb'>
                    <Box>
                        <Typography variant='h3' className='col1 fw5'>Allocate Asset</Typography>
                    </Box>
                    <Box className='fx_fe py1'>
                        <Stack direction={'row'} spacing={1}>
                            <Button variant="contained" size='small' className='main_btn' endIcon={<CloseIcon />}>Cancel</Button>

                            <Button variant="contained" size='small' className='main_btn' endIcon={<CheckIcon />}>Save</Button>
                        </Stack>
                    </Box>
                </Box>
            </Box>

            <Box className="scrolled-content">
                <Box id='emp-details' className='whitebx bxsh3' mt={1}>
                    <Box className="tb_head">
                        <Box className='fx_sb'>
                            <Box>
                                <Typography variant='h4' className='fw5 content'>Employee Details</Typography>
                            </Box>

                            <Box style={{ minWidth: '120px', marginLeft: '8px' }} className='fx_fe'>
                                <Button fullWidth variant="contained" size='small' className='main_btn' startIcon={<AddIcon />} onClick={handleClickOpen}>Add</Button>
                            </Box>
                        </Box>
                    </Box>

                    <Box className="user-profile">
                        <List sx={{ padding: '0px' }}>
                            <ListItem disablePadding disableRipple disableTouchRipple>
                                <ListItemButton disableRipple disableTouchRipple className='fx_sb'>
                                    <Box className="fx_fs">
                                        <ListItemIcon>
                                            <Avatar>H</Avatar>
                                        </ListItemIcon>
                                        <ListItemText primary={
                                            <React.Fragment>
                                                <Typography
                                                    variant="body2"
                                                    className='col1'
                                                >
                                                    Employee Name
                                                </Typography>
                                            </React.Fragment>
                                        } secondary={
                                            <React.Fragment>
                                                <Typography
                                                    sx={{ display: 'inline' }}
                                                    component="span"
                                                    variant="body2"
                                                    className='content sec_content'
                                                >
                                                    Department
                                                </Typography>
                                                <Typography
                                                    sx={{ display: 'inline' }}
                                                    component="span"
                                                    variant="body2"
                                                    className='emp-code'
                                                >
                                                    1234
                                                </Typography>
                                            </React.Fragment>
                                        } sx={{ marginLeft: '8px' }} />
                                    </Box>
                                    <Box>
                                        <IconButton
                                            aria-label="more"
                                            id="long-button"
                                            aria-haspopup="true"
                                            size='medium'
                                            className='ico_btn_bg'
                                        >
                                            <Edit fontSize='medium' className='col1 ico_edit' />
                                        </IconButton>
                                    </Box>
                                </ListItemButton>
                            </ListItem>
                        </List>
                    </Box>
                </Box>

                <Box mt={1}>
                    <Box sx={{ width: '100%' }}>
                        <Grid container spacing={2} justifyContent='space-between' alignItems='end'>
                            <Grid item lg={8} md={7} sm={6} xs={12}>
                                <Tabs value={value} onChange={handleChangeT} aria-label="basic tabs example">
                                    <Tab label="Asset Details" {...a11yProps(0)} disableRipple />
                                    <Tab label="Peripherals" {...a11yProps(1)} disableRipple />
                                </Tabs>
                            </Grid>
                            <Grid item lg={4} md={5} sm={6} xs={12}>
                                <Box className='fx_fe' mb={1}>
                                    <Button variant="contained" size='small' className='main_btn' onClick={handleClickOpen2}>Check Stock Availability</Button>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>
                    <CustomTabPanel value={value} index={0}>
                        <Box p={'12px'}>
                            <Grid container spacing={2} pt={1}>
                                <Grid item lg={3} md={3} sm={6} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <Autocomplete
                                            disablePortal
                                            size='small'
                                            id="combo-box-demo"
                                            options={asset}
                                            fullWidth
                                            renderInput={(params) => <TextField variant='outlined' {...params} label="Select Asset" size='small' />}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item lg={3} md={3} sm={6} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <Autocomplete
                                            disablePortal
                                            size='small'
                                            id="combo-box-demo"
                                            options={brand}
                                            fullWidth
                                            renderInput={(params) => <TextField variant='outlined' {...params} label="Brand" size='small' />}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item lg={3} md={3} sm={6} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <Autocomplete
                                            disablePortal
                                            size='small'
                                            id="combo-box-demo"
                                            options={model}
                                            fullWidth
                                            renderInput={(params) => <TextField variant='outlined' {...params} label="Model" size='small' />}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item lg={3} md={3} sm={6} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <Autocomplete
                                            disablePortal
                                            size='small'
                                            id="combo-box-demo"
                                            options={size}
                                            fullWidth
                                            renderInput={(params) => <TextField variant='outlined' {...params} label="Size" size='small' />}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item lg={3} md={3} sm={12} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <TextField id="outlined-basic" className='textfield' label='Core and Clock speed' size="small" variant="outlined" fullWidth />
                                    </Box>
                                </Grid>
                                <Grid item lg={3} md={3} sm={12} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <TextField id="outlined-basic" className='textfield' label='Serial Number' size="small" variant="outlined" fullWidth />
                                    </Box>
                                </Grid>
                                <Grid item lg={3} md={3} sm={12} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <Autocomplete
                                            disablePortal
                                            size='small'
                                            id="combo-box-demo"
                                            options={status}
                                            fullWidth
                                            renderInput={(params) => <TextField variant='outlined' {...params} label="Status" size='small' />}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item lg={3} md={3} sm={12} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <TextField id="outlined-basic" className='textfield' label='Service Tag' size="small" variant="outlined" fullWidth />
                                    </Box>
                                </Grid>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <TextField id="outlined-basic" className='textfield' label='Note/Remark' size="small" variant="outlined" fullWidth multiline rows={3} />
                                    </Box>
                                </Grid>
                            </Grid>

                            <Box className='fx_sb'>
                                <Box mt={2} className='al_left checkbox_with_label'>
                                    <FormControlLabel control={<Checkbox defaultChecked />} label="Laptop Bag" />
                                </Box>
                                <Box pt={2} className='fx_fe'>
                                    <Stack direction={'row'} spacing={1}>
                                        <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} >Save</Button>

                                        <Button variant="contained" size='small' className='sec_btn bg1 wh' startIcon={<AddIcon />} >Add Peripherals</Button>
                                    </Stack>
                                </Box>
                            </Box>
                        </Box>
                    </CustomTabPanel>
                    <CustomTabPanel value={value} index={1}>
                        <Box p={'12px'}>
                            <Box>
                                <PeripheralsTable />
                            </Box>
                        </Box>
                    </CustomTabPanel>
                </Box>
            </Box>


            {/* add user dialog */}
            <Dialog id='dialog' maxWidth='md'
                open={open}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title" className='col1'>
                    <Typography variant='h4' className='fw5'>
                        {"Employee"}
                    </Typography>
                </DialogTitle>
                <Divider />
                <IconButton
                    size='medium'
                    aria-label="close"
                    onClick={handleClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,

                    }}
                >
                    <CloseIcon fontSize='small' />
                </IconButton>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Grid container spacing={2} >
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <FreeSoloAutoComplete />
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='First Name' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Last Name' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Email' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Department' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className="ol_txtfield" pt={1}>
                                    <TextField id="outlined-basic" className='textfield' label='Branch' size="small" variant="outlined" fullWidth />
                                </Box>
                            </Grid>
                        </Grid>

                        <Box pt={2} className='fx_fe'>
                            <Stack direction={'row'} spacing={1}>
                                <Button variant="contained" size='small' className='sec_btn bg3 wh' endIcon={<CloseIcon />} onClick={handleClose}>Cancel</Button>

                                <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} onClick={handleClose}>Save</Button>
                            </Stack>
                        </Box>
                    </DialogContentText>
                </DialogContent>

            </Dialog>

            {/* available stock dialog */}
            <Dialog id='dialog' maxWidth='lg'
                open={open2}
                onClose={handleClose2}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title" className='col1'>
                    <Typography variant='h4' className='fw5'>
                        {"Available Stock for Asset"}
                    </Typography>
                </DialogTitle>
                <Divider />
                <IconButton
                    size='medium'
                    aria-label="close"
                    onClick={handleClose2}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,

                    }}
                >
                    <CloseIcon fontSize='small' />
                </IconButton>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box>
                            <Grid container spacing={2} >
                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box pt={1}>
                                        <FreeSoloAutoComplete />
                                    </Box>
                                </Grid>
                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className="ol_txtfield" pt={1}>
                                        <Autocomplete
                                            disablePortal
                                            size='small'
                                            id="combo-box-demo"
                                            options={size}
                                            fullWidth
                                            renderInput={(params) => <TextField variant='outlined' {...params} label="Display Size" size='small' />}
                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                        <Box pt={2}>
                            <AssetTable />
                        </Box>

                        {/* <Box pt={2} className='fx_fe'>
                                <Stack direction={'row'} spacing={1}>
                                    <Button variant="contained" size='small' className='sec_btn bg3 wh' endIcon={<CloseIcon />} onClick={handleClose2}>Cancel</Button>

                                    <Button variant="contained" size='small' className='sec_btn bg1 wh' endIcon={<CheckIcon />} onClick={handleClose2}>Save</Button>
                                </Stack>
                            </Box> */}
                    </DialogContentText>
                </DialogContent>

            </Dialog>


        </>
    )
}

export default Allocate

const asset = [
    { label: 'Laptop' },
    { label: 'Computer' },
]

const brand = [
    { label: 'Acer' },
    { label: 'HP' },
]

const model = [
    { label: 'Aspire 5 A15-45' },
    { label: 'Aspire 5 A75-90' },
]

const size = [
    { label: 'Dell 18.5"' },
    { label: 'Dell 24.5"' },
]

const status = [
    { label: 'Assigned' },
    { label: 'Replaced' },
]

const options = [
    { label: 'Name 1 (1234)', icon: <AccountCircleIcon sx={{ fontSize: '20px' }} className='content' />, location: 'Mumbai' },
    { label: 'Name 2 (1234)', icon: <AccountCircleIcon sx={{ fontSize: '20px' }} className='content' />, location: 'Nashik' },
    { label: 'Name 3 (1234)', icon: <AccountCircleIcon sx={{ fontSize: '20px' }} className='content' />, location: 'GiftCity' },
]
