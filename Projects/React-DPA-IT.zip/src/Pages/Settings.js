import { Autocomplete, Avatar, Box, Button, Checkbox, Dialog, DialogContent, DialogContentText, DialogTitle, Divider, FormControl, FormControlLabel, Grid, IconButton, InputAdornment, InputLabel, List, ListItem, ListItemButton, ListItemIcon, ListItemText, MenuItem, OutlinedInput, Stack, Tab, Tabs, TextField, Tooltip, Typography } from '@mui/material'
import React, { useState } from 'react';
import AddIcon from '@mui/icons-material/Add';
import CheckIcon from '@mui/icons-material/Check';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import EditIcon from '@mui/icons-material/Edit';



const Settings = () => {

    const [age, setAge] = React.useState('');

   
    const defaultCity = city.find(item => item.label === 'Nashik');

    const [values, setValues] = useState({
        password: '',
        showPassword: false,
    });

    const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
    };

    const handleClickShowPassword = () => {
        setValues({ ...values, showPassword: !values.showPassword });
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };




    return (
        <>

            <Box className="page-header-bar">
                <Box id='heading' className='fx_sb'>
                    <Box>
                        <Typography variant='h3' className='col1 fw5'>Settings</Typography>
                    </Box>
                </Box>
            </Box>

            <Box className='scrolled-content'>
                <Box id='emp-details' mt={1}>
                    <Grid container spacing={3}>
                        <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className='whitebx bxsh3'>
                                <Box className="tb_head">
                                    <Box className='fx_sb'>
                                        <Box mt={1}>
                                            <Typography variant='h4' className='fw5 content'>Change Password</Typography>
                                        </Box>
                                    </Box>
                                </Box>

                                <Box mt={2}>
                                    <Grid container spacing={2}>
                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='ol_txtfield' mt={1}>
                                                <TextField id="outlined-basic" className='textfield' label='Current Password' size="small" variant="outlined" fullWidth
                                                    type={values.showPassword ? 'text' : 'password'}
                                                    value={values.password}
                                                    onChange={handleChange('password')}
                                                    InputProps={{
                                                        endAdornment: (
                                                            <InputAdornment position="end">
                                                                <IconButton
                                                                    size="small"
                                                                    aria-label="toggle password visibility"
                                                                    onClick={handleClickShowPassword}
                                                                    onMouseDown={handleMouseDownPassword}
                                                                    edge="end"
                                                                >
                                                                    {values.showPassword ? <Visibility fontSize="small" /> : <VisibilityOff fontSize="small" />}
                                                                </IconButton>
                                                            </InputAdornment>
                                                        ),
                                                    }}
                                                />
                                            </Box>
                                        </Grid>
                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='ol_txtfield' mt={1}>
                                                <TextField id="outlined-basic" className='textfield' label='New Password' size="small" variant="outlined" fullWidth
                                                    type={values.showPassword ? 'text' : 'password'}
                                                    value={values.password}
                                                    onChange={handleChange('password')}
                                                    InputProps={{
                                                        endAdornment: (
                                                            <InputAdornment position="end">
                                                                <IconButton
                                                                    size="small"
                                                                    aria-label="toggle password visibility"
                                                                    onClick={handleClickShowPassword}
                                                                    onMouseDown={handleMouseDownPassword}
                                                                    edge="end"
                                                                >
                                                                    {values.showPassword ? <Visibility fontSize="small" /> : <VisibilityOff fontSize="small" />}
                                                                </IconButton>
                                                            </InputAdornment>
                                                        ),
                                                    }}
                                                />
                                            </Box>
                                        </Grid>
                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='ol_txtfield' mt={1}>
                                                <TextField id="outlined-basic" className='textfield' label='Confirm Password' size="small" variant="outlined" fullWidth
                                                    type={values.showPassword ? 'text' : 'password'}
                                                    value={values.password}
                                                    onChange={handleChange('password')}
                                                    InputProps={{
                                                        endAdornment: (
                                                            <InputAdornment position="end">
                                                                <IconButton
                                                                    size="small"
                                                                    aria-label="toggle password visibility"
                                                                    onClick={handleClickShowPassword}
                                                                    onMouseDown={handleMouseDownPassword}
                                                                    edge="end"
                                                                >
                                                                    {values.showPassword ? <Visibility fontSize="small" /> : <VisibilityOff fontSize="small" />}
                                                                </IconButton>
                                                            </InputAdornment>
                                                        ),
                                                    }}
                                                />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='fx_fe' mt={1}>
                                                <Button variant="contained" size='small' className='main_btn'>Change Password</Button>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Box>
                        </Grid>

                        <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className='whitebx bxsh3'>
                                <Box className="tb_head">
                                    <Box className='fx_sb relative'>
                                        <Box mt={1}>
                                            <Typography variant='h4' className='fw5 content'>Current Branch</Typography>
                                        </Box>
                                        <Box mx={1}>
                                            <Tooltip title='Update Branch' arrow placement='bottom'>
                                                <IconButton size='medium' className='reset_ico edit_ico_fe'>
                                                    <EditIcon fontSize='small' className='col2 ' />
                                                </IconButton>
                                            </Tooltip>
                                        </Box>
                                    </Box>
                                </Box>

                                <Box mt={2}>
                                    <Grid container spacing={2}>
                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className="ol_txtfield" mt={1}>
                                                <Autocomplete
                                                    disablePortal
                                                    size='small'
                                                    id="combo-box-demo"
                                                    options={city}
                                                    fullWidth
                                                    disabled
                                                    defaultValue={defaultCity}
                                                    renderInput={(params) => <TextField variant='outlined' {...params} label="Current Branch" size='small' />}
                                                />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='fx_fe' mt={1}>
                                                <Button variant="contained" size='small' disabled className='main_btn'>Update Branch</Button>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Box>
                        </Grid>
                    </Grid>

                </Box>
            </Box>
        </>
    )
}

export default Settings

const city = [
    { label: 'Mumbai' },
    { label: 'Nashik' },
    { label: 'All' },
]

const demo_options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
]