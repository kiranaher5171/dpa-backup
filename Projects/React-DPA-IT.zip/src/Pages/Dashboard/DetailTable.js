import { Box } from '@mui/material'
import React, { useState, useEffect, useMemo } from 'react'
import { AgGridReact } from 'ag-grid-react'; // AG Grid Component
import "ag-grid-community/styles/ag-grid.css"; // Mandatory CSS required by the grid
import "ag-grid-community/styles/ag-theme-quartz.css"; // Optional Theme applied to the grid
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import TableSkeleton from '../../Components/TableSkeleton';

export default function DetailTable() {

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const fetchData = async () => {
      setTimeout(() => {
        setLoading(false);
      }, 200);
    };
    fetchData();
  }, []);

  // Row Data: The data to be displayed.
  const [rowData, setRowData] = useState([
    { SrNo: "1", Name: "Keyboards", Available: "152", InUse: 10, InRepair: "155", Retired: "50", Total: '1050' },
    { SrNo: "2", Name: "Monitors", Available: "150", InUse: 10, InRepair: "150", Retired: "50", Total: '1050' },
    { SrNo: "3", Name: "Printers", Available: "200", InUse: 10, InRepair: "100", Retired: "50", Total: '1050' },
    { SrNo: "4", Name: "Headsets", Available: "165", InUse: 10, InRepair: "100", Retired: "50", Total: '1050' },
    { SrNo: "5", Name: "Keyboards", Available: "152", InUse: 10, InRepair: "155", Retired: "50", Total: '1050' },
    { SrNo: "6", Name: "Monitors", Available: "150", InUse: 10, InRepair: "150", Retired: "50", Total: '1050' },
    { SrNo: "7", Name: "Printers", Available: "200", InUse: 10, InRepair: "100", Retired: "50", Total: '1050' },
    { SrNo: "8", Name: "Headsets", Available: "165", InUse: 10, InRepair: "100", Retired: "50", Total: '1050' },
    { SrNo: "6", Name: "Monitors", Available: "150", InUse: 10, InRepair: "150", Retired: "50", Total: '1050' },
    { SrNo: "7", Name: "Printers", Available: "200", InUse: 10, InRepair: "100", Retired: "50", Total: '1050' },
    { SrNo: "8", Name: "Headsets", Available: "165", InUse: 10, InRepair: "100", Retired: "50", Total: '1050' },
  ]);

  // Column Definitions: Defines the columns to be displayed.
  const [colDefs, setColDefs] = useState([
    { field: "SrNo", minWidth: 60, maxWidth: 80, cellClass: 'al_right' },
    { field: "Name", minWidth: 100, },
    { field: "Available", minWidth: 100, cellClass: 'al_right' },
    { field: "InUse", minWidth: 100, cellClass: 'al_right' },
    { field: "InRepair", minWidth: 100, cellClass: 'al_right' },
    { field: "Retired", minWidth: 100, cellClass: 'al_right' },
    { field: "Total", minWidth: 100, cellClass: 'al_right' },
  ]);


  // Apply settings across all columns
  const defaultColDef = useMemo(() => {
    return {
        flex: 1,
        filter: false,
        editable: false,
        sortable: true,
    };
}, []);


  const rowHeight = 30;
  const headerHeight = 30;

  // Container: Defines the grid's theme & dimensions.

  const rowStyle = { background: '#fafafa' };

  const getRowStyle = params => {
    if (params.node.rowIndex % 2 === 0) {
      return { background: '#fff' };
    }
  };

  return (
    <>
      <Box id='table'>

        <Box id="custom-pagination" className={
          "ag-theme-quartz"
        }
          style={{ width: '100%', height: '300px', }}
        >
          {loading ? (
            <Box>
              <TableSkeleton />
            </Box>
          ) : (
            <AgGridReact
              rowData={rowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              rowHeight={rowHeight}
              headerHeight={headerHeight} 
              getRowStyle={getRowStyle}
              rowStyle={rowStyle} 
            />
          )}
          <Box id='table-info' className='fx_sb' pt={1}>
            <AgGridInfo />
            <AgGridPagination />
          </Box>
        </Box>
      </Box>

    </>
  )
}
