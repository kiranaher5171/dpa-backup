import { Autocomplete, IconButton, Tooltip, Box, TextField, MenuItem } from '@mui/material';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import { AgGridReact } from 'ag-grid-react';
import React, { useMemo, useRef, useState, useEffect } from 'react';
import EditIcon from '@mui/icons-material/Edit';
import CancelIcon from '@mui/icons-material/Cancel';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import TableSkeleton from '../../Components/TableSkeleton';

const UserTable = () => {

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const fetchData = async () => {
            setTimeout(() => {
                setLoading(false);
            }, 200);
        };
        fetchData();
    }, []);

    const gridRef = useRef();
    const [rowData, setRowData] = useState([
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        }, {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },
        {
            No: '1', EmpCode: "1664", Name: 'Elizabeth Lopez', Email: 'elopez@yahoo.com', Branch: "Mumbai", permission:
                <Box className="auto_field">
                    <Autocomplete
                        fullWidth
                        openOnFocus={false}
                        id="combo-box-demo"
                        options={options}
                        size='small'
                        getOptionLabel={(option) => option.label}
                        renderOption={(props, option) => (
                            <MenuItem {...props} className="tb-autocomplete-opt">
                                {option.label}
                            </MenuItem>
                        )}
                        renderInput={(params) => <TextField variant="outlined" {...params} placeholder="Permission" size='small' />}
                    />
                </Box>
        },


    ]);
    const [columnDefs] = useState([
        { headerName: 'No', field: 'No', minWidth: 70, maxWidth: 70, cellClass: 'al_right' },
        { headerName: 'Emp  Code', field: 'EmpCode', minWidth: 120, maxWidth: 120, cellClass: 'al_right' },
        { headerName: 'Name', field: 'Name', minWidth: 150, },
        { headerName: 'Email', field: 'Email', minWidth: 150, },
        { headerName: 'Branch', field: 'Branch', minWidth: 150, },
        // { headerName: 'Permission', field: 'Permission', minWidth: 150, },
        {
            headerName: 'Permission',
            field: 'Permission',
            minWidth: 200, maxWidth: 200,
            cellRenderer: (params) => params.data.permission,
        },
        {
            minWidth: 120, maxWidth: 120, cellClass: 'al_center', cellRenderer: (params) => <>

                <Tooltip title="Edit" arrow placement='bottom'>
                    <IconButton size='small'>
                        <EditIcon fontSize='small' className='edit_icon col1' />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Check" arrow placement='bottom'>
                    <IconButton size='small'>
                        <CheckCircleIcon fontSize='small' className='edit_icon grn' />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Close" arrow placement='bottom'>
                    <IconButton size='small'>
                        <CancelIcon fontSize='small' className='edit_icon rd' />
                    </IconButton>
                </Tooltip>


            </>
        },

    ]);
    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            filter: false,
            editable: false,
            sortable: true,
        };
    }, []);


    // const autoGroupColumnDef = useMemo(() => {
    //     return {
    //         minWidth: 200,
    //     };
    // }, []);



    // header and row height
    const rowHeight = 30;
    const headerHeight = 30;

    // Container: Defines the grid's theme & dimensions.

    const rowStyle = { background: '#fafafa' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#fff' };
        }
    };


    return (
        <Box className="test-container">
            <Box id="custom-pagination" className="ag-theme-quartz" style={{ width: '100%', height: '65vh' }}>

                {loading ? (
                    <Box>
                        <TableSkeleton />
                    </Box>
                ) : (
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={columnDefs}
                        defaultColDef={defaultColDef}
                        // autoGroupColumnDef={autoGroupColumnDef}
                        rowHeight={rowHeight}
                        headerHeight={headerHeight}
                        getRowStyle={getRowStyle}
                        rowStyle={rowStyle}
                    />
                )}
                <Box id='table-info' className='fx_sb' pt={1}>
                    <AgGridInfo />
                    <AgGridPagination />
                </Box>
            </Box>
        </Box>
    );
};

export default UserTable;


const options = [
    { label: 'Read' },
    { label: 'Write' },
    { label: 'Both' },
]
