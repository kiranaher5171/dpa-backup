import React, { useState } from 'react';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Box, IconButton, Tooltip, SvgIcon, Button } from '@mui/material';
import { Link } from 'react-router-dom';
import EditIcon from '@mui/icons-material/Edit';
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';

const rows = [
  { id: "1", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "assigned", isActive: true, },
  { id: "2", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", isActive: false, },
  { id: "3", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", isActive: true, },
  { id: "4", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", isActive: false, },
  { id: "5", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", isActive: true, },
  { id: "6", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "assigned", isActive: false, },
  { id: "7", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", isActive: true, },
  { id: "8", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", isActive: false, },
  { id: "9", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", isActive: true, },
  { id: "10", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "assigned", isActive: false, },
  { id: "11", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", isActive: true, },
  { id: "12", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", isActive: false, },
  { id: "13", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", isActive: true, },
  { id: "14", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", isActive: false, },
  { id: "15", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", isActive: true, },
  { id: "16", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", isActive: false, },
  { id: "17", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", isActive: true, },
  { id: "18", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", isActive: false, },
];

function LogTable() {

  const [columnVisibility, setColumnVisibility] = useState({
    No: true,
    EmployeeName: true,
    ServiceTag: true,
    Model: true,
    Monitor: true,
    Processor: true,
    Peripherals: true,
    status: true,
  });

  const toggleColumnVisibility = (columnName) => {
    setColumnVisibility((prevVisibility) => ({
      ...prevVisibility,
      [columnName]: !prevVisibility[columnName],
    }));
  };

  // Status field
  const renderStatusCell = (params) => {
    const { status } = params.row;
    let statusComponent;

    switch (status) {
      case 'assigned':
        statusComponent = <Box className='status_btn assign_btn'>Assigned</Box>;
        break;
      case 'repair':
        statusComponent = <Box className='status_btn repair_btn'>In Repair</Box>;
        break;
      case 'replaced':
        statusComponent = <Box className='status_btn replace_btn'>Replaced</Box>;
        break;
      default:
        statusComponent = <Box className='status_btn retird_btn'>Retired</Box>;
    }

    return statusComponent;
  };


  // Define custom header component
  const CustomHeader = ({ icon, onClick }) => {
    return (
      <Box onClick={onClick}>
        {icon && <SvgIcon component={icon} />}
      </Box>
    );
  };

  const columns = [
    { headerName: 'No', field: 'No', minWidth: 70, maxWidth: 70, align: 'right', flex: 1 },
    { headerName: 'Employee Name', field: 'EmployeeName', flex: 1 },
    { headerName: 'Service Tag', field: 'ServiceTag', cellClassName: 'col1', flex: 1 },
    { headerName: 'Model', field: 'Model', flex: 1 },
    { headerName: 'Monitor', field: 'Monitor', flex: 1 },
    { headerName: 'Processor', field: 'Processor', flex: 1 },
    { headerName: 'Peripherals', field: 'Peripherals', flex: 1 },
    {
      headerName: 'Status', field: 'status', maxWidth: 100, minWidth: 100, flex: 1,
      renderCell: renderStatusCell,
    },
    {
      flex: 1,
      minWidth: 60,
      maxWidth: 60,
      align: 'center',
      renderCell: (params) => (
        <Link to="#">
          <Tooltip title="Edit" arrow placement='right'>
            <IconButton size='small'>
              <EditIcon fontSize='small' className='edit_icon col1' />
            </IconButton>
          </Tooltip>
        </Link>
      ),
    },
    {
      flex: 1,
      align: 'right',
      field: 'add',
      headerName: (
        <CustomHeader
          icon={AddCircleOutlineIcon}
        />
      ),
      minWidth: 70,
      maxWidth: 70,
      sortable: false, // Disable sorting for this column
    },
    { field: 'date', headerName: 'Year', width: 120, align: 'center', renderCell: (params) => <RenderCell {...params} isActive={params.row.isActive} />, },
  ]

  // button
  function RenderCell(props) {
    const { hasFocus, value, isActive } = props;
    const buttonElement = React.useRef(null);
    const rippleRef = React.useRef(null);

    React.useLayoutEffect(() => {
      if (hasFocus) {
        const input = buttonElement.current.querySelector('input');
        input?.focus();
      } else if (rippleRef.current) {
        rippleRef.current.stop({});
      }
    }, [hasFocus]);

    let button;
    if (isActive) {
      button = (
        <Button
          ref={buttonElement}
          touchRippleRef={rippleRef}
          variant="contained"
          size="small"
          className='status_btn'
        >
          Active
        </Button>
      );
    } else {
      button = (
        <Button
          ref={buttonElement}
          touchRippleRef={rippleRef}
          variant="contained"
          size="small"
          className='status_btn'
        >
          Inactive
        </Button>
      );
    }
    return (
      <strong>
        {value?.getFullYear() ?? ''}
        {button}
      </strong>
    );
  }


  return (
    <Box style={{ height: 400, width: '100%', }}>
      <DataGrid
        rowHeight={30}
        headerHeight={30}
        disableColumnFilter
        disableDensitySelector
        disableColumnMenu
        disablePagination
        columns={columns}
        rows={rows}
        slots={{
          toolbar: GridToolbar,
          footer: () => (
            <Box id='table-info' className='fx_sb' pt={1}>
              {/* Add your footer components */}
            </Box>
          ),
        }}
      />
      {/* Add UI elements to toggle column visibility */}
      <Box mt={2}>
        {Object.keys(columnVisibility).map((columnName) => (
          <Tooltip key={columnName} title={`Toggle ${columnName} column`} arrow placement='top'>
            <IconButton
              onClick={() => toggleColumnVisibility(columnName)}
              color={columnVisibility[columnName] ? 'primary' : 'default'}
            >
              {/* Add an icon or label to represent the column */}
            </IconButton>
          </Tooltip>
        ))}
      </Box>
    </Box>
  );
}

export default LogTable;
