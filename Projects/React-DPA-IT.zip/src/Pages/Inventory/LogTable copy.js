import * as React from 'react';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Box, IconButton, Tooltip, SvgIcon } from '@mui/material';
import { Link } from 'react-router-dom';
import EditIcon from '@mui/icons-material/Edit';
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';

const rows = [
  { id: "1", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "assigned", },
  { id: "2", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", },
  { id: "3", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", },
  { id: "4", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", },
  { id: "5", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", },
  { id: "6", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "assigned", },
  { id: "7", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", },
  { id: "8", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", },
  { id: "9", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", },
  { id: "10", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "assigned", },
  { id: "11", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", },
  { id: "12", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", },
  { id: "13", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", },
  { id: "14", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", },
  { id: "15", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", },
  { id: "16", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "replaced", },
  { id: "17", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "", },
  { id: "18", No: '001', EmployeeName: "Anthony Taylor", ServiceTag: 'DPANSK7F7010103', Model: 'Acet Aspire 5 A515-5', Monitor: "hp 18.5", Processor: 'i5-11400', Peripherals: "Keyboard,Mouse", status: "repair", },
];



export default function LogTable() {

  // Status field
  const renderStatusCell = (params) => {
    const { status } = params.row;
    let statusComponent;

    switch (status) {
      case 'assigned':
        statusComponent = <Box className='status_btn assign_btn'>Assigned</Box>;
        break;
      case 'repair':
        statusComponent = <Box className='status_btn repair_btn'>In Repair</Box>;
        break;
      case 'replaced':
        statusComponent = <Box className='status_btn replace_btn'>Replaced</Box>;
        break;
      default:
        statusComponent = <Box className='status_btn retird_btn'>Retired</Box>;
    }

    return statusComponent;
  };


  // Define custom header component
  const CustomHeader = ({ icon, onClick }) => {
    return (
      <Box onClick={onClick}>
        {icon && <SvgIcon component={icon} />}
      </Box>
    );
  };


  return (
    <Box style={{ height: 400, width: '100%', }}>
      <DataGrid
        rowHeight={30}
        headerHeight={30}
        disableColumnFilter
        disableDensitySelector
        disableColumnMenu
        disableExport // Disable export functionality
        disablePagination

        columns={[
          { headerName: 'No', field: 'No', minWidth: 70, maxWidth: 70, align: 'right', flex: 1 },
          { headerName: 'Employee Name', field: 'EmployeeName', flex: 1 },
          { headerName: 'Service Tag', field: 'ServiceTag', cellClassName: 'col1', flex: 1 },
          { headerName: 'Model', field: 'Model', flex: 1 },
          { headerName: 'Monitor', field: 'Monitor', flex: 1 },
          { headerName: 'Processor', field: 'Processor', flex: 1 },
          { headerName: 'Peripherals', field: 'Peripherals', flex: 1 },
          {
            headerName: 'Status', field: 'status', maxWidth: 100, minWidth: 100, flex: 1,
            renderCell: renderStatusCell,
          },
          {
            flex: 1,
            minWidth: 60,
            maxWidth: 60,
            align: 'center',
            renderCell: (params) => (
              <Link to="#">
                <Tooltip title="Edit" arrow placement='right'>
                  <IconButton size='small'>
                    <EditIcon fontSize='small' className='edit_icon col1' />
                  </IconButton>
                </Tooltip>
              </Link>
            ),
          },
          {
            flex: 1,
            align: 'right',
            field: 'add',
            headerName: (
              <CustomHeader
                icon={AddCircleOutlineIcon}
              />
            ),
            minWidth: 70,
            maxWidth: 70,
            sortable: false, // Disable sorting for this column
          },
        ]}
        rows={rows}
        slots={{
          toolbar: GridToolbar,
          exportButton: null,  
          footer: () => (
            <Box id='table-info' className='fx_sb' pt={1}>
              <AgGridInfo />
              <AgGridPagination />
            </Box>
          ),
        }}
      />
    </Box>
  );
}