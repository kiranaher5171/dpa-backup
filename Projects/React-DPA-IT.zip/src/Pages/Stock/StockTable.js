import { Box } from '@mui/material'
import React, { useState, useEffect, useMemo } from 'react'
import { AgGridReact } from 'ag-grid-react'; // AG Grid Component
import "ag-grid-community/styles/ag-grid.css"; // Mandatory CSS required by the grid
import "ag-grid-community/styles/ag-theme-quartz.css"; // Optional Theme applied to the grid
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import TableSkeleton from '../../Components/TableSkeleton';

export default function StockTable() {

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const fetchData = async () => {
            setTimeout(() => {
                setLoading(false);
            }, 200);
        };
        fetchData();
    }, []);

    // Row Data: The data to be displayed.
    const [rowData, setRowData] = useState([
        { No: "01", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "02", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "03", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "04", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "05", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "06", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Michael Taylor' },
        { No: "07", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Emily Enderson' },
        { No: "08", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Emily Enderson', DisplaySize: 'Content', Processor: 'i5-11400' },
        { No: "09", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "10", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Michael Taylor' },
        { No: "11", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Emily Enderson' },
        { No: "12", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Emily Enderson', DisplaySize: 'Content', Processor: 'i5-11400' },
        { No: "05", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "06", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Michael Taylor' },
        { No: "07", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Emily Enderson' },
        { No: "08", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Emily Enderson', DisplaySize: 'Content', Processor: 'i5-11400' },
        { No: "09", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Laptop', DisplaySize: '18.5', Processor: 'i5-11400' },
        { No: "10", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Michael Taylor' },
        { No: "11", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Michael Taylor', DisplaySize: 'Content', Processor: 'Emily Enderson' },
        { No: "12", SerialNumber: "1478855555555111", 'Brand & Model': "Acer - Aspire 5 A515-5", Item: 'Emily Enderson', DisplaySize: 'Content', Processor: 'i5-11400' },
    ]);

    // Column Definitions: Defines the columns to be displayed.
    const [colDefs, setColDefs] = useState([
        { field: "No", maxWidth: 80, minWidth:80, cellClass: 'al_right' },
        { field: "SerialNumber", maxWidth: 150, minWidth: 150, cellClass: 'al_right' },
        { field: "Brand & Model", mmaxWidth: 150, minWidth: 150,},
        { field: "Item", minWidth: 120,},
        { field: "DisplaySize", minWidth: 120, maxWidth: 170, },
        { field: "Processor", maxWidth: 180, minWidth: 180, },
    ]);


    // Apply settings across all columns
    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            filter: false,
            editable: false,
            sortable: true,
        };
    }, []);


    const rowHeight = 30;
    const headerHeight = 30;

    // Container: Defines the grid's theme & dimensions.

    const rowStyle = { background: '#fafafa' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#fff' };
        }
    };

    return (
        <>
            <Box id='table'>

                <Box id="custom-pagination"
                    className={
                        "ag-theme-quartz"
                    }
                    style={{ width: '100%', height: '65vh' }}
                >
                {loading ? (
                    <Box>
                        <TableSkeleton />
                    </Box>
                ) : (
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={colDefs}
                        defaultColDef={defaultColDef}
                        rowHeight={rowHeight}
                        headerHeight={headerHeight} 
                        getRowStyle={getRowStyle}
                        rowStyle={rowStyle} 
                    />
                )}
                    <Box id='table-info' className='fx_sb' pt={1}>
                        <AgGridInfo />
                        <AgGridPagination />
                    </Box>
                </Box>
            </Box>

        </>
    )
}
