import { Box, FormControlLabel } from '@mui/material';
import React, { useState, useEffect, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import Switch from '@mui/material/Switch';
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import AgGridInfo from '../../Components/AgGridInfo';
import AgGridPagination from '../../Components/AgGridPagination';
import TableSkeleton from '../../Components/TableSkeleton';

export default function ItemTable() {

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const fetchData = async () => {
            setTimeout(() => {
                setLoading(false);
            }, 200);
        };
        fetchData();
    }, []);

    const [rowData, setRowData] = useState([
        { No: "1", ItemCode: "00", Name: "Laptop", Category: 'Asset', Status: false },
        { No: "2", ItemCode: "01", Name: "Computer", Category: 'Asset', Status: true },
        { No: "3", ItemCode: "02", Name: "Mouse", Category: 'Asset', Status: false },
        { No: "4", ItemCode: "03", Name: "Keyboard", Category: 'Peripheral', Status: true },
        { No: "5", ItemCode: "04", Name: "NETGEAR Wifi Router", Category: 'Peripheral', Status: true },
        { No: "6", ItemCode: "05", Name: "Unifi Wifi Router", Category: 'Peripheral', Status: true },
        { No: "7", ItemCode: "06", Name: "Firewall 200E", Category: 'Peripheral', Status: false },
        { No: "8", ItemCode: "07", Name: "David Smith", Category: 'Peripheral', Status: false },
        { No: "9", ItemCode: "08", Name: "NETGEAR Wifi Router", Category: 'Peripheral', Status: true },
        { No: "10", ItemCode: "09", Name: "Unifi Wifi Router", Category: 'Peripheral', Status: true },
        { No: "11", ItemCode: "10", Name: "Firewall 200E", Category: 'Peripheral', Status: false },
        { No: "12", ItemCode: "11", Name: "David Smith", Category: 'Peripheral', Status: false },
        { No: "7", ItemCode: "06", Name: "Firewall 200E", Category: 'Peripheral', Status: false },
        { No: "8", ItemCode: "07", Name: "David Smith", Category: 'Peripheral', Status: false },
        { No: "9", ItemCode: "08", Name: "NETGEAR Wifi Router", Category: 'Peripheral', Status: true },
        { No: "10", ItemCode: "09", Name: "Unifi Wifi Router", Category: 'Peripheral', Status: true },
        { No: "11", ItemCode: "10", Name: "Firewall 200E", Category: 'Peripheral', Status: false },
        { No: "12", ItemCode: "11", Name: "David Smith", Category: 'Peripheral', Status: false },
    ]);

    const colDefs = [
        { field: "No", maxWidth: 70, minWidth: 70, cellClass: 'al_right' },
        { field: "ItemCode", maxWidth: 120, minWidth: 120, cellClass: 'al_right' },
        { field: "Name", minWidth: 200, },
        { field: "Category", minWidth: 200, },
        {
            field: "Status", cellClass: 'al_center',
            minWidth: 100, maxWidth: 100,
            // cellRenderer: 'switchRenderer',
            cellRenderer: () => <Box id='switch_only'> <FormControlLabel control={<Switch size='small' />} /></Box>
        },
    ];

    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            filter: false,
            editable: false,
            sortable: true,
        };
    }, []);





    const rowHeight = 30;
    const headerHeight = 30;

    const rowStyle = { background: '#fafafa' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#fff' };
        }
    };

    return (
        <Box id='table'>
            <Box id="custom-pagination" className={"ag-theme-quartz"} style={{ width: '100%', height: '65vh' }}>

                {loading ? (
                    <Box>
                        <TableSkeleton />
                    </Box>
                ) : (
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={colDefs}
                        defaultColDef={defaultColDef}
                        rowHeight={rowHeight}
                        headerHeight={headerHeight} 
                        getRowStyle={getRowStyle}
                        rowStyle={rowStyle} 
                    />
                )}
                <Box id='table-info' className='fx_sb' pt={1}>
                    <AgGridInfo />
                    <AgGridPagination />
                </Box>
            </Box>
        </Box>
    );
}

