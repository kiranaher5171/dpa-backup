import "./App.css";
import Header from "./Component/Header";

import { BrowserRouter as Router, Switch, Route, } from "react-router-dom";
import Footer from "./Component/Footer";




import Sample from "./Pages/Sample";
import SignIn from './Forms/SignIn';
import ForgotPassword from './Forms/Forgot_pass';
import ResetPassword from './Forms/Reset_pass';
import GetOtp from './Forms/Get_otp';
import VerifyOtp from './Forms/Verify_otp';
import SignUp from './Forms/SignUp';


import Createaccount from "./Pages/IFA_Createaccount";
import IFAPartnerProfile from "./Pages/IFA_partner_profile";
import IFAProfile from "./Pages/IFA_profile";
import RMUpdateProfile from "./Pages/RM_update_profile";
import IFAExistingTeam from "./Pages/IFA_existing_team";
import IFAAddNewMember from './Pages/IFA_add_new_member';
import IFAAssignedAgentList from './Pages/IFA_assigned_agent_list';
import IFAAssignedcmList from './Pages/IFA_assigned_cm_list';
import IFAViewClientMapping from './Pages/IFA_view_client_mapping';
import IFAMappedClients from './Pages/IFA_mapped_clients';
import UCC from './Pages/UCC/Ucc';
import AUMReconciliation from './Pages/Admin or Back Office/AUM_Reconciliation';
import AUMUnmatch from './Pages/Admin or Back Office/AUM_Unmatch';
import AUMReconcile from './Pages/Admin or Back Office/AUM_Reconcile';
import OMBranches from './Pages/Operation Management/OM_Branches';
import OMZonal from './Pages/Operation Management/OM_Zonal';
import OMZonalList from './Pages/Operation Management/OM_Zonal_List';
import CMExistingInvlist from './Pages/Client Management/Existing_Investor_List';
import BulkReporting from './Pages/Email_Or_SMS/Bulk_Reporting';
import TMPurchaseHistory from './Pages/Transaction Management/Purchase_history';
import PurchaseCards from './Pages/Transaction Management/Purchase_Cards';
import PurchaseDetails from './Pages/Transaction Management/Purchase_Details';
import InvestorProfile from './Pages/Investor/Investor_Profile';
import InvestorRiskProfile1 from './Pages/Investor/Investor_Risk_Profile_1';
import InvestorRiskProfile2 from './Pages/Investor/Investor_Risk_Profile_2';
import InvestorRiskProfile3 from './Pages/Investor/Investor_Risk_Profile_3';
import InvestorRiskProfile4 from './Pages/Investor/Investor_Risk_Profile_4';
import InvestorRiskProfile5 from './Pages/Investor/Investor_Risk_Profile_5';
import InvestorRiskProfile6 from './Pages/Investor/Investor_Risk_Profile_6';
import InvestorPlanMyGoal from './Pages/Investor/Investor_Plan_My_Goal';
import PMGPurchaseHome from './Pages/Investor/Plan My Goal/PMG_Purchase_Home';
import PMGDashboard from './Pages/Investor/Plan My Goal/PMG_Dashboard';

import InvestorTMRedumption from './Pages/Investor/Investor_TM_Redumption';
import RMCreateAccount from './Pages/RM_Create_Account';
import Success from './Forms/Success';
import Funds from './Pages/Funds';
import PartnerManagement from './Pages/Partner Management/Partner_Management';
import PartnerProfile from './Pages/Partner Management/Partner_Profile';
import AgentClientManagement from './Pages/Agent_Client_Management';
import PMGPurchaseVehicle from './Pages/Investor/Plan My Goal/PMG_Purchase_Vehicle';
import TMRedemption from './Pages/Transaction Management/TM_Redemption';
import TMCancelledSIP from './Pages/Transaction Management/TM_Cancelled_SIP';
import TMCancelledSIPCards from './Pages/Transaction Management/TM_Cancelled_SIP_Cards';
import TMProceedCancellation from './Pages/Transaction Management/TM_Proceed_Cancellation';
import CreateMyGoal from "./Pages/CreateMyGoal";
 






function App() {
  return (
    <>
      
<Router>

<Header/>


{/* <Switch>
          <Route exact path='/' component={Header} />


</Switch> */}


<Switch>

<Route exact path="/aa"><Sample /></Route>
<Route exact path="/"><SignIn /></Route>
<Route exact path="/forgot_password"><ForgotPassword /></Route>
<Route exact path="/reset_password"><ResetPassword /></Route>

<Route exact path="/get_otp"><GetOtp /></Route>
<Route exact path="/verify_otp"><VerifyOtp /></Route>

<Route exact path="/signup"><SignUp /></Route>

<Route exact path="/successfull"><Success /></Route>


<Route exact path="/createaccount"><Createaccount /></Route>
<Route exact path="/ifa_profile"><IFAProfile /></Route>
<Route exact path="/ifa_partner_profile"><IFAPartnerProfile /></Route>

<Route exact path="/rm_update_profile"><RMUpdateProfile /></Route>

<Route exact path="/ifa_existing_team"><IFAExistingTeam /></Route>
<Route exact path="/ifa_add_new_member"><IFAAddNewMember /></Route>

<Route exact path="/ifa_assigned_agent_list"><IFAAssignedAgentList /></Route>
<Route exact path="/ifa_assigned_cm_list"><IFAAssignedcmList /></Route>

<Route exact path="/ifa_view_client_mapping"><IFAViewClientMapping /></Route>
<Route exact path="/ifa_mapped_clients"><IFAMappedClients /></Route>

<Route exact path="/ucc"><UCC /></Route>

<Route exact path="/aum_reconciliation"><AUMReconciliation /></Route>
<Route exact path="/aum_unmatch"><AUMUnmatch /></Route>

<Route exact path="/aum_reconcile"><AUMReconcile /></Route>


<Route exact path="/om_branches"><OMBranches /></Route>
<Route exact path="/om_zonal"><OMZonal /></Route>
<Route exact path="/om_zonal_list"><OMZonalList /></Route>

<Route exact path="/cm_existing_inv_list"><CMExistingInvlist /></Route>

<Route exact path="/bulk_reporting"><BulkReporting /></Route>

<Route exact path="/tm_purchase_history"><TMPurchaseHistory /></Route>
<Route exact path="/purchase_cards"><PurchaseCards /></Route>
<Route exact path="/purchase_details"><PurchaseDetails /></Route>

<Route exact path="/tm_redemption"><TMRedemption /></Route>

<Route exact path="/tm_cancelled_sip"><TMCancelledSIP /></Route>
<Route exact path="/tm_cancelled_sip_cards"><TMCancelledSIPCards /></Route>
<Route exact path="/tm_proceed_cancellation"><TMProceedCancellation /></Route>





<Route exact path="/investor_profile"><InvestorProfile /></Route>


<Route exact path="/investor_risk_profile_1"><InvestorRiskProfile1 /></Route>
<Route exact path="/investor_risk_profile_2"><InvestorRiskProfile2 /></Route>
<Route exact path="/investor_risk_profile_3"><InvestorRiskProfile3 /></Route>
<Route exact path="/investor_risk_profile_4"><InvestorRiskProfile4 /></Route>
<Route exact path="/investor_risk_profile_5"><InvestorRiskProfile5 /></Route>
<Route exact path="/investor_risk_profile_6"><InvestorRiskProfile6 /></Route>

<Route exact path="/investor_plan_my_goal"><InvestorPlanMyGoal /></Route>
<Route exact path="/pmg_purchase_home"><PMGPurchaseHome /></Route>
<Route exact path="/pmg_purchase_vehicle"><PMGPurchaseVehicle /></Route>


<Route exact path="/pmg_dashboard"><PMGDashboard /></Route>

<Route exact path="/investor_tm_redumption"><InvestorTMRedumption /></Route>

<Route exact path="/rm_create_account"><RMCreateAccount /></Route>

<Route exact path="/agent_client_management"><AgentClientManagement /></Route>

<Route exact path="/partner_management"><PartnerManagement /></Route>
<Route exact path="/partner_profile"><PartnerProfile /></Route>


<Route exact path="/funds"><Funds /></Route>


<Route exact path="/create-my-goal"><CreateMyGoal /></Route>

 
</Switch>





<Footer/>


</Router>
       
    </>
  );
}

export default App;
