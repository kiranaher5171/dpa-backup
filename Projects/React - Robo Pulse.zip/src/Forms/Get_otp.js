import React from 'react'
import { Box, Grid, Button, Typography, } from '@material-ui/core';
import { Link } from 'react-router-dom'; 
import { Radio, RadioGroup, FormControlLabel } from '@material-ui/core'
import Logo1 from "../asset/images/Form_gif/mail_sent.gif";

 
import ArrowForwardIcon from '@material-ui/icons/ArrowForward'; 
 
const Get_otp = () => {

 


return (
<>
<Box id='app'>

<Grid container spacing={0} alignItems="top">
<Grid item lg={8} md={6} sm={12} xs={12}>
<Box className='art-wrapper'> </Box>

</Grid>

<Grid item lg={4} md={6} sm={12} xs={12}>
<Box className='content-wrapper'>
<Box className='main-content'>

<Box mt={0} mb={0}>
<img src={Logo1} className='logo_login' alt='logo' /> 
</Box>

<Box mt={2} mb={3}>  
<Typography variant='h4' className='fw500 bl'> Get OTP </Typography></Box>
 
 <Box mb={1}>
<Typography variant='h6' className='al_center gry'> Select OTP Delivery Method </Typography>
</Box>


<Box className='radio' mt={1}>
<RadioGroup row aria-label="position" name="position" defaultValue="top">
<FormControlLabel
value="rdo1"
control={<Radio color="primary" size='small' />}
label="Mobile OTP"
labelPlacement="end"
/>
 
 
<FormControlLabel
value="rdo4"
control={<Radio color="primary" size='small' />}
label="Email OTP"
labelPlacement="end"
/>
</RadioGroup>


<Box mt={3}>
<Link to="/verify_otp">
<Button  variant="contained" color="primary" className='bl_bttn' fullWidth endIcon={<ArrowForwardIcon/>}>
Get OTP
</Button>
</Link>
</Box>


</Box>
 

</Box>
</Box>

</Grid>
</Grid>
</Box>
 


</>
)
}

export default Get_otp


