import React from 'react'
import { Box, Grid, Button, Typography,  TextField, } from '@material-ui/core';
import { Link } from 'react-router-dom';
import Logo1 from "../asset/images/Form_gif/done.gif";
 
const Verify_otp = () => {
 

return (
<>
<Box id='app'>

<Grid container spacing={0} alignItems="top">
<Grid item lg={8} md={6} sm={12} xs={12}>
<Box className='art-wrapper'> </Box>

</Grid>

<Grid item lg={4} md={6} sm={12} xs={12}>
<Box className='content-wrapper'>
<Box className='main-content'>



<Box mt={0} mb={0}>
<img src={Logo1} className='logo_login' alt='logo' /> 
</Box>

<Box mt={2} mb={4}>  
<Typography variant='h4' className='fw500 bl'> Verify OTP  </Typography></Box>
 
 <Box mb={2}>
<Typography variant='h6' className='al_center gry'> The OTP has been sent to xxxxxxx981. <br/>
Please enter the OTP you received to Validate </Typography>
<Typography variant='h6' className='al_center gry fw600'> Attempts Left: 3 </Typography>

</Box>



<Box mt={1}>
<Grid container spacing={1} alignItems="center">
<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='alltxfield'>
<TextField id="filled-basic" label="Enter OTP" variant="filled" fullWidth />
</Box>
</Grid>


<Grid item lg={12} md={12} sm={12} xs={12}>
<Box mt={1} mb={1}>
<Link to="/get_otp"><Typography variant="h6" className='al_center fw600'>Resend OTP</Typography></Link>
</Box>
</Grid>

<Grid item lg={12} md={12} sm={12} xs={12}>
    <Link to="/">
<Button  variant="contained" color="primary" className='bl_bttn' fullWidth>
Validate
</Button>
</Link>
</Grid>
 

<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='al_center' mt={1}>
<Typography variant='h6' className=''> Back to <Link to="/" className='bl bk_yellow fw600'> Login </Link></Typography>
</Box>
</Grid>

</Grid>
</Box>


</Box>
</Box>

</Grid>
</Grid>
</Box>
 


</>
)
}

export default Verify_otp


