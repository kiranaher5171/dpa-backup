import React from 'react'
import { Box, Grid, Button, Typography, TextField, } from '@material-ui/core';
import FPLogo from "../asset/images/Form_gif/forgot_pass.gif";
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
 import { Link } from 'react-router-dom';
 
const Forgot_Password = () => {

 
 


return (
<>
<Box id='app'>

<Grid container spacing={0} alignItems="top">
<Grid item lg={8} md={6} sm={12} xs={12}>
<Box className='art-wrapper'> </Box>

</Grid>

<Grid item lg={4} md={6} sm={12} xs={12}>
<Box className='content-wrapper'>
<Box className='main-content'>


<Box mt={0} mb={0}>
<img src={FPLogo} className='logo_login' alt='logo' /> 
</Box>

<Box mt={2} mb={4}>  
<Typography variant='h4' className='fw500 bl'> Forgot Password </Typography></Box>
 
 <Box mb={2}>
<Typography variant='h6' className='al_center gry'> Enter your email address and we'll send you a link to reset your password. </Typography>
</Box>

<Box mt={1}>
<Grid container spacing={1} alignItems="center">
<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='alltxfield'>
<TextField id="filled-basic" label="Email ID" variant="filled" fullWidth />
</Box>
</Grid>

 

 

<Grid item lg={12} md={12} sm={12} xs={12}>
<Box mt={3}>
<Link to="/reset_password">
<Button  variant="contained" color="primary" className='bl_bttn' fullWidth endIcon={<ArrowForwardIcon/>}>
Reset Password
</Button>
</Link>
</Box>
</Grid>
 

</Grid>
</Box>


</Box>
</Box>

</Grid>
</Grid>
</Box>
 


</>
)
}

export default Forgot_Password


