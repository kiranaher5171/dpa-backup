import React from 'react'
import FPLogo from "../asset/images/Form_gif/reset_pass.gif";
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import { Box, Grid, Button, Typography, FormControl, InputLabel,  } from '@material-ui/core';
import { Link } from 'react-router-dom'; 
import IconButton from '@material-ui/core/IconButton';
import FilledInput from '@material-ui/core/FilledInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
 

 
 
const Reset_Password = () => {

 
const [values, setValues] = React.useState({
amount: '', password: '', weight: '', weightRange: '', showPassword: false,
});

const handleChange = (prop) => (event) => { setValues({ ...values, [prop]: event.target.value }); };
const handleClickShowPassword = () => { setValues({ ...values, showPassword: !values.showPassword }); };
const handleMouseDownPassword = (event) => { event.preventDefault(); };



return (
<>
<Box id='app'>

<Grid container spacing={0} alignItems="top">
<Grid item lg={8} md={6} sm={12} xs={12}>
<Box className='art-wrapper'> </Box>

</Grid>

<Grid item lg={4} md={6} sm={12} xs={12}>
<Box className='content-wrapper'>
<Box className='main-content'>


<Box mt={0} mb={0}>
<img src={FPLogo} className='logo_login' alt='logo' /> 
</Box>

<Box mt={2} mb={4}>  
<Typography variant='h4' className='fw500 bl'> Reset Password </Typography></Box>
 
 <Box mb={2}>
<Typography variant='h6' className='al_center gry'> Please Enter Your New Password  </Typography>
</Box>

<Box mt={1}>
<Grid container spacing={2} alignItems="center">

<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='alltxfield lg_pass'>
<FormControl fullWidth variant="filled">
<InputLabel htmlFor="filled-adornment-password">New Password</InputLabel>
<FilledInput
id="filled-adornment-password"
type={values.showPassword ? 'text' : 'password'}
value={values.password}
onChange={handleChange('password')}
endAdornment={
<InputAdornment position="end">
<IconButton
aria-label="toggle password visibility"
onClick={handleClickShowPassword}
onMouseDown={handleMouseDownPassword}
edge="end"
>
{values.showPassword ? <Visibility /> : <VisibilityOff />}
</IconButton>
</InputAdornment>
}
/>
</FormControl>


</Box>
</Grid>

<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='alltxfield lg_pass'>
<FormControl fullWidth variant="filled">
<InputLabel htmlFor="filled-adornment-password">Confirm Password</InputLabel>
<FilledInput
id="filled-adornment-password"
type={values.showPassword ? 'text' : 'password'}
value={values.password}
onChange={handleChange('password')}
endAdornment={
<InputAdornment position="end">
<IconButton
aria-label="toggle password visibility"
onClick={handleClickShowPassword}
onMouseDown={handleMouseDownPassword}
edge="end"
>
{values.showPassword ? <Visibility /> : <VisibilityOff />}
</IconButton>
</InputAdornment>
}
/>
</FormControl>


</Box>
</Grid>

 

<Grid item lg={12} md={12} sm={12} xs={12}>
<Box mt={2}>
    <Link to="get_otp">
<Button  variant="contained" color="primary" className='bl_bttn' fullWidth endIcon={<ArrowForwardIcon/>}>
Set Password
</Button>
</Link>
</Box>
</Grid>
 

</Grid>
</Box>


</Box>
</Box>

</Grid>
</Grid>
</Box>
 


</>
)
}

export default Reset_Password


