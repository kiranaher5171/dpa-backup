import React from 'react'
import { Box, Grid, Button, Container, Typography, Divider, } from '@material-ui/core';
import Check from "../asset/images/checkmark.gif";
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import { Link } from 'react-router-dom';

const Success = () => {

    return (
        <>


            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>

                    <Grid container spacing={0} alignItems="top" justifyContent='center'>

                        <Grid item lg={4} md={6} sm={12} xs={12}>
                            <Box className='wh_bx' mt={"25%"}>

                                <Box className='al_center' mt={4} mb={4}>
                                    <img src={Check} className='logo_success' alt='logo' />
                                </Box>

                                <Box className='al_center' mt={2} mb={2}>
                                    <Typography variant='h4' className='fw500 bl'> Submission Successful </Typography></Box>

                                <Box className='al_center' mb={3} mt={2}>
                                    <Typography variant='h6' className='al_center gry'> Your profile has been updated successfully. </Typography>
                                </Box>

                                <Divider />

                                <Box className='bt al_center' mt={3} mb={2}>
                                    <Link to="/rm_update_profile" className="link">
                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Go To Dashboard </Button>
                                    </Link>
                                </Box>

                            </Box>
                        </Grid>
                    </Grid>

                </Container>
            </Box>

        </>
    )
}

export default Success
