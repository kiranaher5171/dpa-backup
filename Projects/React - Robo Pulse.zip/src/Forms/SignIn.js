import React from 'react'
import { Box, Grid, Button, Typography, FormControl, InputLabel, TextField, } from '@material-ui/core';
import { Link } from 'react-router-dom';
import IconButton from '@material-ui/core/IconButton';
import FilledInput from '@material-ui/core/FilledInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import { Radio, RadioGroup, FormControlLabel } from '@material-ui/core'
import Logo1 from "../asset/images/RoboPulse.gif";



const SignIn = () => {


    const [values, setValues] = React.useState({
        amount: '', password: '', weight: '', weightRange: '', showPassword: false,
    });

    const handleChange = (prop) => (event) => { setValues({ ...values, [prop]: event.target.value }); };
    const handleClickShowPassword = () => { setValues({ ...values, showPassword: !values.showPassword }); };
    const handleMouseDownPassword = (event) => { event.preventDefault(); };



    return (
        <>
            <Box id='app'>

                <Grid container spacing={0} alignItems="top">
                    <Grid item lg={8} md={6} sm={12} xs={12}>
                        <Box className='art-wrapper'> </Box>

                    </Grid>

                    <Grid item lg={4} md={6} sm={12} xs={12}>
                        <Box className='content-wrapper'>
                            <Box className='main-content'>


                                <Box mt={0} mb={0}>
                                    <Typography variant='h4' className=' bl '> Sign In</Typography>
                                </Box>

                                <Typography variant='h6' className=''> Welcome to RoboPulse </Typography>

                                <Box mt={2}>  <img src={Logo1} className='logo_login' alt='logo' /> </Box>

                                <Box className='radio' mt={2}>
                                    <RadioGroup row aria-label="position" name="position" defaultValue="top">
                                        <FormControlLabel
                                            value="rdo1"
                                            control={<Radio color="primary" size='small' />}
                                            label="IFA"
                                            labelPlacement="end"
                                        />
                                        <FormControlLabel
                                            value="rdo2"
                                            control={<Radio color="primary" size='small' />}
                                            label="RM"
                                            labelPlacement="end"
                                        />
                                        <FormControlLabel
                                            value="rdo3"
                                            control={<Radio color="primary" size='small' />}
                                            label="Investor"
                                            labelPlacement="end"
                                        />
                                        <FormControlLabel
                                            value="rdo4"
                                            control={<Radio color="primary" size='small' />}
                                            label="Admin"
                                            labelPlacement="end"
                                        />
                                    </RadioGroup>
                                </Box>





                                <Box mt={1}>
                                    <Grid container spacing={1} alignItems="center">
                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" label="Email ID" variant="filled" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='alltxfield lg_pass'>
                                                <FormControl fullWidth variant="filled">
                                                    <InputLabel htmlFor="filled-adornment-password">Password</InputLabel>
                                                    <FilledInput
                                                        id="filled-adornment-password"
                                                        type={values.showPassword ? 'text' : 'password'}
                                                        value={values.password}
                                                        onChange={handleChange('password')}
                                                        endAdornment={
                                                            <InputAdornment position="end">
                                                                <IconButton
                                                                    aria-label="toggle password visibility"
                                                                    onClick={handleClickShowPassword}
                                                                    onMouseDown={handleMouseDownPassword}
                                                                    edge="end"
                                                                >
                                                                    {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                </IconButton>
                                                            </InputAdornment>
                                                        }
                                                    />
                                                </FormControl>


                                            </Box>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box mt={1} mb={1}>
                                                <Link to="/forgot_password"><Typography variant="h6" className='al_right'>Forgot Password?</Typography></Link>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Link to="/createaccount">
                                                <Button variant="contained" color="primary" className='bl_bttn' fullWidth>
                                                    Sign In
                                                </Button>
                                            </Link>

                                        </Grid>


                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='al_center' mt={1}>
                                                <Typography variant='h6' className=''>Don't have an account? <Link to="/signup" className='bl bk_yellow'>Sign Up</Link></Typography>
                                            </Box>
                                        </Grid>

                                    </Grid>
                                </Box>


                            </Box>
                        </Box>

                    </Grid>
                </Grid>
            </Box>



        </>
    )
}

export default SignIn


