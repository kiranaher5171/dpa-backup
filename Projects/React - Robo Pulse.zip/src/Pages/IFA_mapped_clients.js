import React from 'react';
import { Box, Container, Grid, Button, Typography, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import GetAppIcon from '@material-ui/icons/GetApp';
import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';

import { Link } from 'react-router-dom';
import CheckCircleOutlineOutlinedIcon from '@material-ui/icons/CheckCircleOutlineOutlined';



export default function IFA_mapped_clients() {

    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;


    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }


    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }


    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex: 1
    }

    const columnDefs = [
        {
            headerName: 'Sr No.', field: 'number', minWidth: 115, cellStyle: { textAlign: 'left' }, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'Client Id', field: 'client_id', minWidth: 115, },
        { headerName: 'Investor Name', field: 'inv_name', minWidth: 150, },
        { headerName: 'Contact', field: 'contact', minWidth: 125, },
        { headerName: 'Email Id', field: 'email', minWidth: 150, },
        { headerName: 'PAN', field: 'pan', minWidth: 150, },
        { headerName: 'Total Fund', field: 'fund', minWidth: 120, },
        { headerName: 'Total Units', field: 'units', minWidth: 120, },
        { headerName: 'Total Invested Amount (RS)', field: 'investment', minWidth: 180, },
        { headerName: 'Total AUM', field: 'aum', minWidth: 110, },
        {
            headerName: 'KYC Status', field: 'status', minWidth: 120, cellStyle: { textAlign: 'center' }, cellRendererFramework: (params) =>
                <Tooltip title="Verified">
                    <span>
                        <CheckCircleOutlineOutlinedIcon size='small' fontSize='smallss' className='c grn tbicon' />
                    </span>
                </Tooltip>
        },
    ]


    const [rowData] = useState([
        { number: "01", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "09", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "john@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "02", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "04", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "03", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "06", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "10", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "05", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "07", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "08", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "01", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "09", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "john@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "02", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "04", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "03", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "06", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "10", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "05", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "07", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "08", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "01", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "09", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "john@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "02", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "04", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "03", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "06", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "10", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "05", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "07", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "08", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "01", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "09", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "john@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "02", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "04", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "03", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "06", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "10", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "05", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
        { number: "07", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Verified" },
        { number: "08", client_id: "001", inv_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPW5289F", fund: "788", units: "650", investment: "50,000", aum: "467", status: "Pending" },
    ])



    return (
        <>

            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' mb={"5px"}>
                                    <Typography variant='h5' className='fw500 bl'> Hello, Investor Name </Typography>
                                </Box>
                            </Grid>

                            <Grid
                                container
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                            >
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <Typography variant='h6' className='fw500 bl' > Assigned Investors List </Typography>
                                </Grid>


                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <ul id='searchportion' style={{marginBottom:'-5px'}}>


                                        <li>
                                            <div class="form-group has-search">
                                                <span class="form-control-feedback"><SearchIcon /></span>
                                                <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                            </div>
                                        </li>

                                        <li>
                                            <IconButton>
                                                <Tooltip title="Download">
                                                <GetAppIcon className='col1' />
                                                </Tooltip>
                                            </IconButton>
                                        </li>

                                    </ul>
                                </Grid>

                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '62vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>
                            </Grid>



                        </Box>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1}>
                                <Link to='/ifa_view_client_mapping' className="link">
                                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                </Link>
                                <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}>  Next </Button>
                            </Box>
                        </Grid>

                    </Box>
                </Container>
            </Box>

        </>
    );
}
