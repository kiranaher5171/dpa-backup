import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Box, Container, Grid, Button, Typography, FormControlLabel, Radio } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';

import RadioGroup from '@material-ui/core/RadioGroup';
import FormControl from '@material-ui/core/FormControl';
import { Link } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
    formControl: {
        margin: theme.spacing(0),
    },
    button: {
        margin: theme.spacing(1, 1, 0, 0),
    },
}));


export default function AUM_Reconciliation() {

    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }


    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex: 1
    }


    const columnDefs = [

        {
            headerName: 'Sr.', field: 'number', minWidth: 50, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'Date', field: 'date', minWidth: 115, align: 'center', },
        { headerName: 'ARN', field: 'arn', minWidth: 125, align: 'center', },
        { headerName: 'Folio no.', field: 'folio', minWidth: 125, align: 'center', },
        { headerName: 'Scheme name', field: 'scheme', minWidth: 150, align: 'center', },
        { headerName: 'Goal name/Fund', field: 'goal', minWidth: 160, align: 'center', },
        { headerName: 'Client Name', field: 'client_name', minWidth: 125, align: 'center', },
        { headerName: 'Client ID', field: 'client_id', minWidth: 125, align: 'center', },
        { headerName: 'Units(Calculated)', field: 'units', minWidth: 150, align: 'center', },
        { headerName: 'Units(RTA)', field: 'unirta', minWidth: 115, align: 'center', },
        { headerName: 'Difference', field: 'difference', minWidth: 115, align: 'center', },
        { headerName: 'Status', field: 'status', minWidth: 115, align: 'center', cellRendererFramework: (params) => <Link to='/aum_unmatch'>Unmatch</Link> },
        { headerName: 'RTA', field: 'rta', minWidth: 120, align: 'center', },
    ]


    const [rowData] = useState([
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "20", unirta: '20', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "20", unirta: '20', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "669", unirta: '700', difference: '31', status: 'Unmatch',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '9856234', scheme: 'Fund name2', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "100", unirta: '100', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Retirement Fund",
            client_name: "LMN", client_id: "IFAINA0002", units: "1000", unirta: '1000', difference: '0', status: 'Match',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "ELSS",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '7896542', scheme: 'Fund name4', goal: "Retirement Fund",
            client_name: "PQR", client_id: "IFAINA0002", units: "10", unirta: '30', difference: '20', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Retirement Fund",
            client_name: "LMN", client_id: "IFAINA0002", units: "1000", unirta: '1000', difference: '0', status: 'Match',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "ELSS",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '7896542', scheme: 'Fund name4', goal: "Retirement Fund",
            client_name: "PQR", client_id: "IFAINA0002", units: "10", unirta: '30', difference: '20', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "20", unirta: '20', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "20", unirta: '20', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "669", unirta: '700', difference: '31', status: 'Unmatch',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '9856234', scheme: 'Fund name2', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "100", unirta: '100', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Retirement Fund",
            client_name: "LMN", client_id: "IFAINA0002", units: "1000", unirta: '1000', difference: '0', status: 'Match',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "ELSS",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '7896542', scheme: 'Fund name4', goal: "Retirement Fund",
            client_name: "PQR", client_id: "IFAINA0002", units: "10", unirta: '30', difference: '20', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Retirement Fund",
            client_name: "LMN", client_id: "IFAINA0002", units: "1000", unirta: '1000', difference: '0', status: 'Match',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "ELSS",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '7896542', scheme: 'Fund name4', goal: "Retirement Fund",
            client_name: "PQR", client_id: "IFAINA0002", units: "10", unirta: '30', difference: '20', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "20", unirta: '20', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "20", unirta: '20', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '1234567', scheme: 'Fund name1', goal: "Purchase home",
            client_name: "ABC", client_id: "IFAINA0001", units: "669", unirta: '700', difference: '31', status: 'Unmatch',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '9856234', scheme: 'Fund name2', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "100", unirta: '100', difference: '0', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Retirement Fund",
            client_name: "LMN", client_id: "IFAINA0002", units: "1000", unirta: '1000', difference: '0', status: 'Match',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "ELSS",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '7896542', scheme: 'Fund name4', goal: "Retirement Fund",
            client_name: "PQR", client_id: "IFAINA0002", units: "10", unirta: '30', difference: '20', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Retirement Fund",
            client_name: "LMN", client_id: "IFAINA0002", units: "1000", unirta: '1000', difference: '0', status: 'Match',
            rta: 'Kfintech',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "Fund(ELSS)",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Unmatch',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '5786212', scheme: 'Fund name3', goal: "ELSS",
            client_name: "XYZ", client_id: "IFAINA0002", units: "825", unirta: '850', difference: '25', status: 'Match',
            rta: 'CAMS',
        },
        {
            date: 'DD/MM/YYYY', arn: 'ARN-194051', folio: '7896542', scheme: 'Fund name4', goal: "Retirement Fund",
            client_name: "PQR", client_id: "IFAINA0002", units: "10", unirta: '30', difference: '20', status: 'Unmatch',
            rta: 'CAMS',
        },
    ])



    const classes = useStyles();
    const [value, setValue] = React.useState('');

    const handleRadioChange = (event) => {
        setValue(event.target.value);

    };

    return (
        <>

            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' >
                                    <Typography variant='h5' className='bl fw500'> AUM Reconciliation </Typography>
                                </Box>
                            </Grid>



                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <ul id='searchportion' style={{ marginTop: '10px' }}>
                                    <li>
                                        <Box className='radio'>
                                            <FormControl component="fieldset" className={classes.formControl}>
                                                <RadioGroup row aria-label="quiz" name="quiz" value={value} onChange={handleRadioChange} >
                                                    <FormControlLabel value="radio1" control={<Radio />} label="Match" onChange={handleRadioChange} />
                                                    <FormControlLabel value="radio2" control={<Radio />} label="Un-Match" onChange={handleRadioChange} />
                                                    <FormControlLabel value="radio3" control={<Radio />} label="See All" onChange={handleRadioChange} />
                                                </RadioGroup>
                                            </FormControl>
                                        </Box>

                                    </li>

                                    <li>
                                        <div class="form-group has-search">
                                            <span class="form-control-feedback"><SearchIcon /></span>
                                            <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                        </div>
                                    </li>



                                </ul>
                            </Grid>



                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '58vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>

                                <Grid container spacing={1} alignItems="top">
                                    <Grid item lg={2} md={2} sm={2} xs={12}>
                                        <Box className='bt al_left'>
                                            <Box>
                                                <Typography variant='h6' className='bl' > Count : <span className='gry'> 12 </span></Typography>
                                            </Box>
                                        </Box>
                                    </Grid>


                                    <Grid item lg={10} md={10} sm={10} xs={12}>
                                        <Grid container spacing={1} alignItems="top" justifyContent='flex-end'>



                                            <Grid item >
                                                <Box className='bt'>
                                                    <Link to='/ifa_existing_team' className="link">
                                                        <Button variant="contained" className='al_center btn bl_bttn' size='small'> Export to Excel </Button>
                                                    </Link>
                                                </Box>
                                            </Grid>

                                            <Grid item >
                                                <Box className='bt'>
                                                    <Button variant="contained" className='al_center btn bl_bttn' size='small'> Unfreeze Marked Folios </Button>
                                                </Box>
                                            </Grid>

                                            <Grid item >
                                                <Box className='bt'>
                                                    <Button variant="contained" className='al_center btn bl_bttn' size='small'> Freeze Marked Folios </Button>
                                                </Box>
                                            </Grid>


                                            <Grid item >
                                                <Box className='bt'>
                                                    <Button variant="contained" className='al_center btn bl_bttn' size='small'> Delete Transaction Folios </Button>
                                                </Box>
                                            </Grid>


                                            <Grid item >
                                                <Box className='bt'>
                                                    <Link to="/aum_reconcile">
                                                        <Button variant="contained" className='al_center btn bl_bttn' size='small'> Reconcile All </Button>
                                                    </Link>
                                                </Box>
                                            </Grid>

                                        </Grid>
                                    </Grid>

                                    {/* <Grid item lg={10} md={10} sm={10} xs={12}>
                                        <Box className='bt al_right'>
                                            <Link to='/ifa_existing_team' className="link">
                                                <Button variant="contained" className='al_center btn bl_bttn' size='small'> Export to Excel </Button>
                                            </Link>

                                            <Button variant="contained" className='al_center btn bl_bttn' size='small'> Unfreeze Marked Folios </Button>

                                            <Button variant="contained" className='al_center btn bl_bttn' size='small'> Freeze Marked Folios </Button>

                                            <Button variant="contained" className='al_center btn bl_bttn' size='small'> Delete Transaction Folios </Button>

                                            <Link to="/aum_reconcile">
                                                <Button variant="contained" className='al_center btn bl_bttn' size='small'> Reconcile All </Button>
                                            </Link>
                                        </Box>
                                    </Grid> */}
                                </Grid>

                            </Grid>



                        </Box>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1}>
                                <Link to='/ifa_existing_team' className="link">
                                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                </Link>
                                <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                            </Box>
                        </Grid>

                    </Box>
                </Container>
            </Box>

        </>
    );
}
