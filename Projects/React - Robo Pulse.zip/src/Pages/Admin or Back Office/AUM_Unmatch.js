import React from 'react';
import { Box, Container, Grid, Button, Typography, TextField } from '@material-ui/core';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import { Link } from 'react-router-dom';


export default function AUM_Unmatch() {

    const [setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true , flex: 1
    }

    const columnDefs = [
        {
            headerName: 'Sr.', field: 'number', minWidth: 50, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'ARN', field: 'arn', minWidth: 180, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Date', field: 'date', minWidth: 200, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Goal name/Fund', field: 'goal', minWidth: 240, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Amount', field: 'amount', minWidth: 160, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'NAV', field: 'nav', minWidth: 140, align: 'center', cellStyle: { textAlign: 'center' } },
        { headerName: 'Purchase Unit', field: 'purchase', minWidth: 160, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Sell Unit', field: 'sell', minWidth: 160, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Bal Units', field: 'balance', minWidth: 160, align: 'center', cellStyle: { textAlign: 'left' } },
    ]


    const [rowData] = useState([
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },

        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },

        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },

        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },
        {
            arn: 'ARN-194052', date: '12-12-2005', goal: 'Purchase home', amount: '50000', nav: "14", purchase: "100", sell: "20",
            balance: "80",
        },

    ])



    return (
        <>

            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' mb={"5px"}>
                                    <Typography variant='h5' className='bl fw500'> Unmatch Clients List </Typography>
                                </Box>
                            </Grid>
 


                            <Grid
                                container
                                direction="row"
                                justifyContent="center"
                                alignItems="center"
                                spacing={1}
                            >


                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Client Name" value="ABC" fullWidth disabled />
                                    </Box>
                                </Grid>

                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Client ID" value="IFAINA0001" fullWidth disabled />
                                    </Box>
                                </Grid>

                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Scheme" value="Fund Name 1" fullWidth disabled />
                                    </Box>
                                </Grid>

                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Folio No" value="1234567" fullWidth disabled />
                                    </Box>
                                </Grid>

                            </Grid>


                            <Grid
                                container
                                direction="row"
                                justifyContent="center"
                                alignItems="center"
                                spacing={1}
                            >


                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Status" value="Unmatch" fullWidth disabled />
                                    </Box>
                                </Grid>


                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Units(Cal)" value="450" fullWidth disabled />
                                    </Box>
                                </Grid>

                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Units(RTA)" value="500" fullWidth disabled />
                                    </Box>
                                </Grid>

                                <Grid item lg={2} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Units Difference" value="50" fullWidth disabled />
                                    </Box>
                                </Grid>

                            </Grid>




                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '52vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>

                                <Grid container spacing={1} alignItems="top">


                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='bt al_right'>
                                            <Link to="/aum_reconcile">
                                                <Button variant="contained" className='al_center btn bl_bttn' size='small'> Reconcile </Button></Link>

                                            <Button variant="contained" className='al_center btn bl_bttn' size='small'> Exit </Button>


                                        </Box>
                                    </Grid>
                                </Grid>

                            </Grid>



                        </Box>


                    </Box>
                </Container>
            </Box>

        </>
    );
}
