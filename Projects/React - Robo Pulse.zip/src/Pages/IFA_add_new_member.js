import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, Button, Typography,  TextField,  } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import PublishOutlinedIcon from '@material-ui/icons/PublishOutlined';
import { Link } from 'react-router-dom';


import Autocomplete from '@material-ui/lab/Autocomplete';

const Role = [
  { title: 'Country manager' },
  { title: 'Regional/zonal manager' },
  { title: 'State manager' },
  { title: 'District manager' },
  { title: 'Branch manager' },
  { title: 'Relationship  manager' },
]

const ISD = [
  { title: '+91' },
  { title: '+94' },
  { title: '+99' },
  { title: '+78' },
  { title: '+67' },
  { title: '+55' },
]

const RandomOpt = [
  { title: 'Option 1' },
  { title: 'Option 2' },
  { title: 'Option 3' },
  { title: 'Option 4' },
  { title: 'Option 5' },
  { title: 'Option 6' },
]


function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};
 


export default function IFA_add_new_member() {


  return (
    <>


      <Box component="section" className='codingpagestart'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

            <Box className='wh_bx' pb={2}>
              <Grid container spacing={1} alignItems="center">


                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className='brd1'>
                    <Typography variant='h5' className=' bl' > Add New Team Member </Typography>
                  </Box>
                </Grid> 

                <Grid
                  container
                  direction="row"
                  justifyContent="flex-start"
                  alignItems="flex-start"
                >
                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='textfield' >
                      <Autocomplete
                        id="combo-box-demo"
                        options={Role}
                        getOptionLabel={(option) => option.title}
                        renderInput={(params) => <TextField {...params} label="Select Role" variant="filled" />}
                      />
                    </Box>
                  </Grid>
                </Grid>




                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter First Name" fullWidth />
                  </Box>
                </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter Middle Name" fullWidth />
                  </Box>
                </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter Last Name" fullWidth />
                  </Box>
                </Grid>


                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Email ID" fullWidth />
                  </Box>
                </Grid>

                <Grid item lg={1} md={2} sm={3} xs={3}>
                  <Box className='textfield' >
                    <Autocomplete
                      id="combo-box-demo"
                      options={ISD}
                      getOptionLabel={(option) => option.title}
                      renderInput={(params) => <TextField {...params} label="ISD" variant="filled" />}
                    /> 
                  </Box>
                </Grid>

                <Grid item lg={2} md={4} sm={9} xs={9}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Mobile no." fullWidth />
                  </Box>
                </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="EUIN" fullWidth />
                  </Box>
                </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='textfield' >
                    <Autocomplete
                      id="combo-box-demo"
                      options={RandomOpt}
                      getOptionLabel={(option) => option.title}
                      renderInput={(params) => <TextField {...params} label="Select Area" variant="filled" />}
                    />
                  </Box>
                </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='textfield' >
                    <Autocomplete
                      id="combo-box-demo"
                      options={RandomOpt}
                      getOptionLabel={(option) => option.title}
                      renderInput={(params) => <TextField {...params} label="Town/City" variant="filled" />}
                    />
                  </Box>
                </Grid>

              </Grid>
            </Box>


            <Grid item lg={12} md={12} sm={12} xs={12}>
              <Box className='bt al_right' mt={1}>
                <Link to='/ifa_existing_team' className="link">
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                </Link>
                <Button variant="contained" className='al_center btn bl_bttn' size='small'> Submit </Button>
              </Box>
            </Grid>


          </Box>
        </Container>
      </Box>




    </>
  );
}
