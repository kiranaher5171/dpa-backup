import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, AppBar, Tabs, Tab, Button, Typography, FormControl, InputLabel, TextField, Divider, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';
import FilledInput from '@material-ui/core/FilledInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import CreateIcon from '@material-ui/icons/Create';
import RotateLeftIcon from '@material-ui/icons/RotateLeft';
import { Link } from 'react-router-dom';
import Autocomplete from '@material-ui/lab/Autocomplete';

const chooseopt = [
    { title: 'Applicable' },
    { title: 'Not Applicable' },
]


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`scrollable-auto-tabpanel-${index}`}
            aria-labelledby={`scrollable-auto-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

const ISD = [
    { title: '+91919191919191' },
    { title: '+94' },
    { title: '+99' },
    { title: '+78' },
    { title: '+67' },
    { title: '+55' },
]




export default function IFA_Profile() {

    const [value, setValue] = React.useState(0);
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState(new Date());
    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker

    const [values, setValues] = React.useState({
        amount: '', password: '', weight: '', weightRange: '', showPassword: false,
    });
    const handleChangePass = (prop) => (event) => { setValues({ ...values, [prop]: event.target.value }); };
    const handleClickShowPassword = () => { setValues({ ...values, showPassword: !values.showPassword }); };
    const handleMouseDownPassword = (event) => { event.preventDefault(); };



    return (
        <>

            <Box className='codingpagestart'>

                <Box className=' sti' component="section" style={{}}>
                    <Container className='containerwidth'>
                        <Box className='st_middle fr_sec'>
                            <Grid container spacing={0} alignItems="center">
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='maintabbedsection'>
                                        <AppBar position="static" className="tabbedbar">
                                            <Tabs
                                                value={value}
                                                onChange={handleChange}
                                                indicatorColor="none"
                                                textColor="primary"
                                                variant="scrollable"
                                                scrollButtons="auto"
                                                aria-label="scrollable auto tabs example"
                                            >
                                                <Tab label="Basic Details" {...a11yProps(0)} />
                                                <Tab label="Mandatory Details"{...a11yProps(1)} />
                                                <Tab label="Upload Document" {...a11yProps(2)} />
                                                <Tab label="RTA Creds" {...a11yProps(3)} />
                                                <Tab label="BSE Star & Mailback Creds" {...a11yProps(4)} />
                                                <Tab label="OTP Verification" {...a11yProps(5)} />
                                            </Tabs>
                                        </AppBar>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                    </Container>
                </Box>


                <Box component="section" mt={1} className='tabbedinfo'>
                    <Container className='containerwidth'>
                        <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                            <TabPanel value={value} index={0} className="ddtab">
                                <Box className='wh_bx' pb={2}>
                                    <Grid container spacing={1} alignItems="top">

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='brd1 flx_sa p0'>
                                                <Typography variant='h5' className='fw500 bl' > Basic Details </Typography>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Type of Account" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Name of Company" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Email ID" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Billing Address" fullWidth />
                                            </Box>
                                        </Grid>
 

                                        <Grid item lg={1} md={2} sm={3} xs={3}>
                                            <Box className='textfield' >
                                                <Autocomplete
                                                    id="combo-box-demo"
                                                    options={ISD}
                                                    getOptionLabel={(option) => option.title}
                                                    renderInput={(params) => <TextField {...params} label="ISD" variant="filled" />}
                                                />
                                            </Box>
                                        </Grid>


                                        <Grid item lg={2} md={4} sm={9} xs={9}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Primary Contact no." fullWidth />
                                            </Box>
                                        </Grid>


                                        <Grid item lg={1} md={2} sm={3} xs={3}>
                                            <Box className='textfield' > 
                                                <Autocomplete
                                                    id="combo-box-demo"
                                                    options={ISD}
                                                    getOptionLabel={(option) => option.title}
                                                    renderInput={(params) => <TextField {...params} label="ISD" variant="filled" />}
                                                />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={2} md={4} sm={9} xs={9}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Secondary Contact no." fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="PAN no." fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='datepic'>
                                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                    <KeyboardDatePicker
                                                        disableToolbar
                                                        variant="inline"
                                                        format="MM/dd/yyyy"
                                                        id="date-picker-inline"
                                                        placeholder="Commencement Date"
                                                        value={selectedDate}
                                                        onChange={handleDateChange}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </MuiPickersUtilsProvider>
                                            </Box>
                                        </Grid>





                                    </Grid>
                                </Box>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' mt={1}>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                                    </Box>
                                </Grid>

                            </TabPanel>

                            <TabPanel value={value} index={1} className="ddtab">
                                <Box className='wh_bx' pb={2}>
                                    <Grid container spacing={1} alignItems="top">

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='brd1 flx_sa p0' >
                                                <Typography variant='h5' className='fw500 bl' > Mandatory Details</Typography>
                                                <IconButton color='primary' component="span">
                                                    <Tooltip title="Edit" aria-label="add">
                                                        <CreateIcon className='smicobtn' />
                                                    </Tooltip>
                                                </IconButton>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="ARN No." fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='datepic'>
                                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                    <KeyboardDatePicker
                                                        disableToolbar
                                                        variant="inline"
                                                        format="MM/dd/yyyy"
                                                        id="date-picker-inline"
                                                        placeholder="Commencement Date"
                                                        value={selectedDate}
                                                        onChange={handleDateChange}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </MuiPickersUtilsProvider>
                                            </Box>
                                        </Grid>


                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='datepic'>
                                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                    <KeyboardDatePicker
                                                        disableToolbar
                                                        variant="inline"
                                                        format="MM/dd/yyyy"
                                                        id="date-picker-inline"
                                                        placeholder="Commencement Date"
                                                        value={selectedDate}
                                                        onChange={handleDateChange}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </MuiPickersUtilsProvider>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="GSTIN" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='textfield' >
                                                <Autocomplete
                                                    id="combo-box-demo"
                                                    options={chooseopt}
                                                    getOptionLabel={(option) => option.title}
                                                    renderInput={(params) => <TextField {...params} label="GST Treatment" variant="filled" />}
                                                />
                                            </Box>
                                        </Grid>


                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="EUIN" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={3} md={6} sm={12} xs={12}>
                                            <Box className='datepic'>
                                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                    <KeyboardDatePicker
                                                        disableToolbar
                                                        variant="inline"
                                                        format="MM/dd/yyyy"
                                                        id="date-picker-inline"
                                                        placeholder="Commencement Date"
                                                        value={selectedDate}
                                                        onChange={handleDateChange}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </MuiPickersUtilsProvider>
                                            </Box>
                                        </Grid>



                                    </Grid>
                                </Box>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' mt={1}>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                                    </Box>
                                </Grid>
                            </TabPanel>

                            <TabPanel value={value} index={2} className="ddtab">
                                <Box className='wh_bx' pb={2}>
                                    <Grid container spacing={2} alignItems="top" justifyContent='center'>

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='brd1 flx_sa p0' >
                                                <Typography variant='h5' className='fw500 bl' > Upload Documents</Typography>
                                                <IconButton color='primary' component="span">
                                                    <Tooltip title="Edit" aria-label="add">
                                                        <CreateIcon className='smicobtn' />
                                                    </Tooltip>
                                                </IconButton>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={6} md={6} sm={12} xs={12}>
                                            <Box className='flx_sa'>
                                                <Typography variant='h6' className='bl fw600'>PAN Card</Typography>
                                                <Typography variant='' className='smcontent'> Updated On: Jan 9, 2025 </Typography>
                                            </Box>
                                            <Box className='uploadfile'>
                                                <input type="file" class="input-file" />
                                            </Box>
                                            <Box mt={1} mb={1}><Divider /></Box>
                                        </Grid>

                                        <Grid item lg={6} md={6} sm={12} xs={12}>
                                            <Box className='flx_sa'>
                                                <Typography variant='h6' className='bl fw600'>GSTIN Doc</Typography>
                                                <Typography variant='' className='smcontent'> Updated On: Jan 9, 2025 </Typography>
                                            </Box>
                                            <Box className='uploadfile'>
                                                <input type="file" class="input-file" />
                                            </Box>
                                            <Box mt={1} mb={1}><Divider /></Box>
                                        </Grid>

                                        <Grid item lg={6} md={6} sm={12} xs={12}>
                                            <Box className='flx_sa'>
                                                <Typography variant='h6' className='bl fw600'>Company Incorporation Certificate</Typography>
                                                <Typography variant='' className='smcontent'> Updated On: Jan 9, 2025 </Typography>
                                            </Box>
                                            <Box className='uploadfile'>
                                                <input type="file" class="input-file" />
                                            </Box>

                                            <Box mt={1} mb={1}><Divider /></Box>

                                        </Grid>

                                        <Grid item lg={6} md={6} sm={12} xs={12}>
                                            <Box className='flx_sa'>
                                                <Typography variant='h6' className='bl fw600'>ARN Certificate</Typography>
                                                <Typography variant='' className='smcontent'> Updated On: Jan 9, 2025 </Typography>
                                            </Box>
                                            <Box className='uploadfile'>
                                                <input type="file" class="input-file" />
                                            </Box>
                                            <Box mt={1} mb={1}><Divider /></Box>
                                        </Grid>

                                    </Grid>
                                </Box>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' mt={1}>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                                    </Box>
                                </Grid>
                            </TabPanel>

                            <TabPanel value={value} index={3} className="ddtab">

                                <Box className='wh_bx' pb={2}>
                                    <Grid container spacing={1} alignItems="top">

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='brd1 flx_sa p0' >
                                                <Typography variant='h5' className='fw500 bl' > RTA Credentials </Typography>
                                                <IconButton color='primary' component="span">
                                                    <Tooltip title="Edit" aria-label="add">
                                                        <CreateIcon className='smicobtn' />
                                                    </Tooltip>
                                                </IconButton>
                                            </Box>
                                            <Box mt={1} mb={1}>
                                                <Typography variant='h6' className='bk'> When you provide your CAMS & Kfintech creds, the system will automatically order and upload all relevant RTA feeds for you in no time </Typography>
                                            </Box>
                                        </Grid>



                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Typography variant='h6' className='bl'> CAMS </Typography>
                                        </Grid>

                                        <Grid item lg={4} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="ARN No." fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={4} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Registered Email ID" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={4} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield lg_pass'>
                                                <FormControl fullWidth variant="filled">
                                                    <InputLabel htmlFor="filled-adornment-password">Password</InputLabel>
                                                    <FilledInput

                                                        id="filled-adornment-password"
                                                        type={values.showPassword ? 'text' : 'password'}
                                                        value={values.password}
                                                        onChange={handleChangePass('password')}
                                                        endAdornment={
                                                            <InputAdornment position="end">
                                                                <IconButton
                                                                    aria-label="toggle password visibility"
                                                                    onClick={handleClickShowPassword}
                                                                    onMouseDown={handleMouseDownPassword}
                                                                    edge="end"
                                                                >
                                                                    {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                </IconButton>
                                                            </InputAdornment>
                                                        }
                                                    />
                                                </FormControl>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Typography variant='h6' className='bl'> Kfintech </Typography>
                                        </Grid>

                                        <Grid item lg={4} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="ARN No." fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={4} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield'>
                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Registered Email ID" fullWidth />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={4} md={6} sm={12} xs={12}>
                                            <Box className='alltxfield lg_pass'>
                                                <FormControl fullWidth variant="filled">
                                                    <InputLabel htmlFor="filled-adornment-password">Password</InputLabel>
                                                    <FilledInput

                                                        id="filled-adornment-password"
                                                        type={values.showPassword ? 'text' : 'password'}
                                                        value={values.password}
                                                        onChange={handleChangePass('password')}
                                                        endAdornment={
                                                            <InputAdornment position="end">
                                                                <IconButton
                                                                    aria-label="toggle password visibility"
                                                                    onClick={handleClickShowPassword}
                                                                    onMouseDown={handleMouseDownPassword}
                                                                    edge="end"
                                                                >
                                                                    {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                </IconButton>
                                                            </InputAdornment>
                                                        }
                                                    />
                                                </FormControl>
                                            </Box>
                                        </Grid>

                                    </Grid>
                                </Box>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' mt={1}>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                                    </Box>
                                </Grid>

                            </TabPanel>

                            <TabPanel value={value} index={4} className="ddtab">
                                <Box className='wh_bx' pb={2}>

                                    <Grid container spacing={1} alignItems="top">

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='brd1 flx_sa p0' >
                                                <Typography variant='h5' className='fw500 bl' > BSE Star & Mailback Credentials </Typography>
                                                <IconButton color='primary' component="span">
                                                    <Tooltip title="Edit" aria-label="add">
                                                        <CreateIcon className='smicobtn' />
                                                    </Tooltip>
                                                </IconButton>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={8} md={7} sm={7} xs={12}>
                                            <Box className='brd_bx' pb={2}>

                                                <Grid container spacing={1} alignItems="center">
                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box>
                                                            <Typography variant='h6' className='bl'> BSE Star Credentials </Typography>
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Registered Email ID" fullWidth />
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Username" fullWidth />
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Member ID" fullWidth />
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield lg_pass'>
                                                            <FormControl fullWidth variant="filled">
                                                                <InputLabel htmlFor="filled-adornment-password">Password</InputLabel>
                                                                <FilledInput

                                                                    id="filled-adornment-password"
                                                                    type={values.showPassword ? 'text' : 'password'}
                                                                    value={values.password}
                                                                    onChange={handleChangePass('password')}
                                                                    endAdornment={
                                                                        <InputAdornment position="end">
                                                                            <IconButton
                                                                                aria-label="toggle password visibility"
                                                                                onClick={handleClickShowPassword}
                                                                                onMouseDown={handleMouseDownPassword}
                                                                                edge="end"
                                                                            >
                                                                                {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                            </IconButton>
                                                                        </InputAdornment>
                                                                    }
                                                                />
                                                            </FormControl>
                                                        </Box>
                                                    </Grid>
                                                </Grid>

                                            </Box>




                                            <Box className='brd_bx' pb={2}>

                                                <Grid container spacing={1} alignItems="center">
                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box>
                                                            <Typography variant='h6' className='bl'> CAMS Security Question </Typography>
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="What is the name of the road you grew up on ?" fullWidth />
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Who is your favorite comic book or cartoon ?" fullWidth />
                                                        </Box>
                                                    </Grid>


                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="In which month did you get married?" fullWidth />
                                                        </Box>
                                                    </Grid>


                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="What is your favorite book?" fullWidth />
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <Box className='alltxfield'>
                                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Who is your landline service provider?" fullWidth />
                                                        </Box>
                                                    </Grid>


                                                </Grid>

                                            </Box>



                                        </Grid>
                                        <Grid item lg={4} md={5} sm={5} xs={12}>
                                            <Box className='brd_bx' pb={2}>
                                                <Grid container spacing={1} alignItems="top">
                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box >
                                                            <Typography variant='h6' className='bl'> CAMS Mailback Files Credentials </Typography>
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='alltxfield lg_pass'>
                                                            <FormControl fullWidth variant="filled">
                                                                <InputLabel htmlFor="filled-adornment-password">Zip File Credentials</InputLabel>
                                                                <FilledInput

                                                                    id="filled-adornment-password"
                                                                    type={values.showPassword ? 'text' : 'password'}
                                                                    value={values.password}
                                                                    onChange={handleChangePass('password')}
                                                                    endAdornment={
                                                                        <InputAdornment position="end">
                                                                            <IconButton
                                                                                aria-label="toggle password visibility"
                                                                                onClick={handleClickShowPassword}
                                                                                onMouseDown={handleMouseDownPassword}
                                                                                edge="end"
                                                                            >
                                                                                {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                            </IconButton>
                                                                        </InputAdornment>
                                                                    }
                                                                />
                                                            </FormControl>
                                                        </Box>
                                                    </Grid>

                                                    <Grid
                                                        container
                                                        direction="column"
                                                        justifyContent="center"
                                                        alignItems="center"
                                                    >
                                                        <Box className='al_center r_icbt'>
                                                            <Typography variant='h6' className='bttxt wh'> OR </Typography>
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='alltxfield lg_pass'>
                                                            <FormControl fullWidth variant="filled">
                                                                <InputLabel htmlFor="filled-adornment-password">Download Link</InputLabel>
                                                                <FilledInput

                                                                    id="filled-adornment-password"
                                                                    type={values.showPassword ? 'text' : 'password'}
                                                                    value={values.password}
                                                                    onChange={handleChangePass('password')}
                                                                    endAdornment={
                                                                        <InputAdornment position="end">
                                                                            <IconButton
                                                                                aria-label="toggle password visibility"
                                                                                onClick={handleClickShowPassword}
                                                                                onMouseDown={handleMouseDownPassword}
                                                                                edge="end"
                                                                            >
                                                                                {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                            </IconButton>
                                                                        </InputAdornment>
                                                                    }
                                                                />
                                                            </FormControl>
                                                        </Box>
                                                    </Grid>
                                                </Grid>
                                            </Box>

                                            <Box className='brd_bx' pb={2}>
                                                <Grid container spacing={1} alignItems="center">
                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box>
                                                            <Typography variant='h6' className='bl'> CAMS Mailback Files Credentials </Typography>
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='alltxfield lg_pass'>
                                                            <FormControl fullWidth variant="filled">
                                                                <InputLabel htmlFor="filled-adornment-password">Zip File Credentials</InputLabel>
                                                                <FilledInput

                                                                    id="filled-adornment-password"
                                                                    type={values.showPassword ? 'text' : 'password'}
                                                                    value={values.password}
                                                                    onChange={handleChangePass('password')}
                                                                    endAdornment={
                                                                        <InputAdornment position="end">
                                                                            <IconButton
                                                                                aria-label="toggle password visibility"
                                                                                onClick={handleClickShowPassword}
                                                                                onMouseDown={handleMouseDownPassword}
                                                                                edge="end"
                                                                            >
                                                                                {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                            </IconButton>
                                                                        </InputAdornment>
                                                                    }
                                                                />
                                                            </FormControl>
                                                        </Box>
                                                    </Grid>

                                                    <Grid
                                                        container
                                                        direction="column"
                                                        justifyContent="center"
                                                        alignItems="center"
                                                    >
                                                        <Box className='al_center r_icbt'>
                                                            <Typography variant='h6' className='bttxt wh'> OR </Typography>
                                                        </Box>
                                                    </Grid>

                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='alltxfield lg_pass'>
                                                            <FormControl fullWidth variant="filled">
                                                                <InputLabel htmlFor="filled-adornment-password">Download Link</InputLabel>
                                                                <FilledInput

                                                                    id="filled-adornment-password"
                                                                    type={values.showPassword ? 'text' : 'password'}
                                                                    value={values.password}
                                                                    onChange={handleChangePass('password')}
                                                                    endAdornment={
                                                                        <InputAdornment position="end">
                                                                            <IconButton
                                                                                aria-label="toggle password visibility"
                                                                                onClick={handleClickShowPassword}
                                                                                onMouseDown={handleMouseDownPassword}
                                                                                edge="end"
                                                                            >
                                                                                {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                            </IconButton>
                                                                        </InputAdornment>
                                                                    }
                                                                />
                                                            </FormControl>
                                                        </Box>
                                                    </Grid>
                                                </Grid>
                                            </Box>

                                        </Grid>

                                    </Grid>



                                </Box>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' mt={1}>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                                    </Box>
                                </Grid>
                            </TabPanel>

                            <TabPanel value={value} index={5} className="ddtab">

                                <Box className='wh_bx' pb={2}>
                                    <Grid container spacing={1} alignItems="top">

                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <Box className='brd1 flx_sa p0' >
                                                <Typography variant='h5' className='fw500 bl' > OTP Verification </Typography>
                                            </Box>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12} >
                                            <Grid container spacing={1} alignItems="center" justifyContent='center'>

                                                <Grid item lg={4} md={12} sm={12} xs={12}>
                                                    <Box className='alltxfield lg_pass'>
                                                        <FormControl fullWidth variant="filled">
                                                            <InputLabel htmlFor="filled-adornment-password"> Password</InputLabel>
                                                            <FilledInput
                                                                id="filled-adornment-password"
                                                                type={values.showPassword ? 'text' : 'password'}
                                                                value={values.password}
                                                                onChange={handleChangePass('password')}
                                                                endAdornment={
                                                                    <InputAdornment position="end">
                                                                        <IconButton
                                                                            aria-label="toggle password visibility"
                                                                            onClick={handleClickShowPassword}
                                                                            onMouseDown={handleMouseDownPassword}
                                                                            edge="end"
                                                                        >
                                                                            {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                        </IconButton>
                                                                    </InputAdornment>
                                                                }
                                                            />
                                                        </FormControl>
                                                    </Box>
                                                </Grid>

                                                <Grid item lg={4} md={12} sm={12} xs={12}>
                                                    <Box className='alltxfield lg_pass'>
                                                        <FormControl fullWidth variant="filled">
                                                            <InputLabel htmlFor="filled-adornment-password">Confirm Password</InputLabel>
                                                            <FilledInput
                                                                id="filled-adornment-password"
                                                                type={values.showPassword ? 'text' : 'password'}
                                                                value={values.password}
                                                                onChange={handleChangePass('password')}
                                                                endAdornment={
                                                                    <InputAdornment position="end">
                                                                        <IconButton
                                                                            aria-label="toggle password visibility"
                                                                            onClick={handleClickShowPassword}
                                                                            onMouseDown={handleMouseDownPassword}
                                                                            edge="end"
                                                                        >
                                                                            {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                                                        </IconButton>
                                                                    </InputAdornment>
                                                                }
                                                            />
                                                        </FormControl>
                                                    </Box>
                                                </Grid>

                                            </Grid>
                                        </Grid>


                                        <Grid item lg={12} md={12} sm={12} xs={12} >
                                            <Grid container spacing={1} alignItems="center" justifyContent='center'>

                                                <Grid item lg={3} md={12} sm={12} xs={12}>
                                                    <Box className='alltxfield'>
                                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Contact Number" fullWidth />
                                                    </Box>
                                                </Grid>

                                                <Grid item lg={3} md={12} sm={12} xs={12}>
                                                    <Box className='bt al_center'>
                                                        <Button variant="contained" className='btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Send OTP </Button>
                                                        <Button variant="contained" className='btn sk_bttn' size='small' endIcon={<RotateLeftIcon />}> Resend </Button>
                                                    </Box>
                                                </Grid>

                                                <Grid item lg={2} md={12} sm={12} xs={12} >
                                                    <Box className='alltxfield'>
                                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter Mobile OTP" fullWidth />
                                                    </Box>
                                                </Grid>

                                            </Grid>
                                        </Grid>

                                        <Grid item lg={12} md={12} sm={12} xs={12} >
                                            <Grid container spacing={1} alignItems="center" justifyContent='center'>

                                                <Grid item lg={3} md={12} sm={12} xs={12}>
                                                    <Box className='alltxfield'>
                                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Email Address" fullWidth />
                                                    </Box>
                                                </Grid>

                                                <Grid item lg={3} md={12} sm={12} xs={12}>
                                                    <Box className='bt al_center'>
                                                        <Button variant="contained" className='btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Send OTP </Button>
                                                        <Button variant="contained" className='btn sk_bttn' size='small' endIcon={<RotateLeftIcon />}> Resend </Button>
                                                    </Box>
                                                </Grid>

                                                <Grid item lg={2} md={12} sm={12} xs={12} >
                                                    <Box className='alltxfield'>
                                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter Email OTP" fullWidth />
                                                    </Box>
                                                </Grid>

                                            </Grid>
                                        </Grid>

                                    </Grid>
                                </Box>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' mt={1}>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>

                                        <Link to="/successfull" className="link">
                                            <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                                        </Link>
                                    </Box>
                                </Grid>

                            </TabPanel>

                        </Box>
                    </Container>
                </Box>

            </Box>

        </>
    );
}
