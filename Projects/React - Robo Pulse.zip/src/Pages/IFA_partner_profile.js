import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, AppBar, Tabs, Tab, Button, Typography, TextField, Divider, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import InputAdornment from '@material-ui/core/InputAdornment';
import CreateIcon from '@material-ui/icons/Create';
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import CancelOutlinedIcon from '@material-ui/icons/CancelOutlined';
import { Link } from 'react-router-dom';
import Autocomplete from '@material-ui/lab/Autocomplete';

const chooseopt = [
  { title: 'Applicable' },
  { title: 'Not Applicable' },
]

const ISD = [
  { title: '+91919191919191' },
  { title: '+94' },
  { title: '+99' },
  { title: '+78' },
  { title: '+67' },
  { title: '+55' },
]

const City = [
  { title: 'Nashik' },
  { title: 'Mumbai' },
  { title: 'GIFT City' },
  { title: 'Nagpur' },
  { title: 'Chennai' },
  { title: 'Banglore' },
]


function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
  };
}





export default function IFA_partner_profile() {

  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };


  // Datepicker
  const [selectedDate, setSelectedDate] = React.useState(new Date());
  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
  // Datepicker



  return (
    <>
<Box className='codingpagestart'>
      <Box className=' sti' component="section" style={{}}>
        <Container className='containerwidth'>
          <Box className='st_middle fr_sec'>
            <Grid container spacing={0} alignItems="center">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='maintabbedsection'>
                  <AppBar position="static" className="tabbedbar">
                    <Tabs
                      value={value}
                      onChange={handleChange}
                      indicatorColor="none"
                      textColor="primary"
                      variant="scrollable"
                      scrollButtons="auto"
                      aria-label="scrollable auto tabs example"
                    >
                      <Tab label="Basic Details" {...a11yProps(0)} />
                      <Tab label="Mandatory Details"{...a11yProps(1)} />
                      <Tab label="Upload Document" {...a11yProps(2)} />
                    </Tabs>
                  </AppBar>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>


      <Box component="section" mt={1} className='tabbedinfo'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

            <TabPanel value={value} index={0} className="ddtab">
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                  <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box className='brd1 flx_sa p0' > 
                        <Typography variant='h5' className='fw500 bl' > Basic Details</Typography> 
                        <IconButton color='primary' component="span">
                          <Tooltip title="Edit" aria-label="add">
                            <CreateIcon className='smicobtn' />
                          </Tooltip>
                        </IconButton> 
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Master ARN" value="ARN-194051" fullWidth disabled
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <PersonOutlineOutlinedIcon />
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Type of Account" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Name of Company" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Email ID" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={1} md={2} sm={3} xs={3}>
                    <Box className='textfield' > 
                      <Autocomplete
                        id="combo-box-demo"
                        options={ISD}
                        getOptionLabel={(option) => option.title}
                        renderInput={(params) => <TextField {...params} label="ISD" variant="filled" />}
                      /> 
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={4} sm={9} xs={9}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Primary Contact no." fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={1} md={2} sm={3} xs={3}>
                    <Box className='textfield' >
                      <Autocomplete
                        id="combo-box-demo"
                        options={ISD}
                        getOptionLabel={(option) => option.title}
                        renderInput={(params) => <TextField {...params} label="ISD" variant="filled" />}
                      /> 
                    </Box>
                  </Grid>

                  <Grid item lg={2} md={4} sm={9} xs={9}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Secondary Contact no." fullWidth />
                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Billing Address" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='textfield' >

                      <Autocomplete
                        id="combo-box-demo"
                        options={City}
                        getOptionLabel={(option) => option.title}
                        renderInput={(params) => <TextField {...params} label="City/Town" variant="filled" />}
                      />

                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="PAN no." fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='datepic'>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <KeyboardDatePicker
                          disableToolbar
                          variant="inline"
                          format="MM/dd/yyyy"
                          id="date-picker-inline"
                          placeholder="Commencement Date"
                          value={selectedDate}
                          onChange={handleDateChange}
                          KeyboardButtonProps={{
                            'aria-label': 'change date',
                          }}
                        />
                      </MuiPickersUtilsProvider>
                    </Box>
                  </Grid>





                </Grid>
              </Box>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<CancelOutlinedIcon />}> Cancel </Button>
                  <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save </Button>
                </Box>
              </Grid>

            </TabPanel>

            <TabPanel value={value} index={1} className="ddtab">
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                  <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box className='brd1 flx_sa p0' > 
                        <Typography variant='h5' className='fw500 bl' > Mandatory Details</Typography> 
                        <IconButton color='primary' component="span">
                          <Tooltip title="Edit" aria-label="add">
                            <CreateIcon className='smicobtn' />
                          </Tooltip>
                        </IconButton> 
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="ARN No." fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='datepic'>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <KeyboardDatePicker title="ARN Date"
                          disableToolbar
                          variant="inline"
                          format="MM/dd/yyyy"
                          id="date-picker-inline"
                          placeholder="Commencement Date"
                          value={selectedDate}
                          onChange={handleDateChange}
                          KeyboardButtonProps={{
                            'aria-label': 'change date',
                          }}
                        />
                      </MuiPickersUtilsProvider>
                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="ARN Renewal Date" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="GSTIN (Optional)" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='textfield' >


                      <Autocomplete
                        id="combo-box-demo"
                        options={chooseopt}
                        getOptionLabel={(option) => option.title}
                        renderInput={(params) => <TextField {...params} label="GST Treatment" variant="filled" />}
                      />

                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="EUIN  (Optional)" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='datepic'>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <KeyboardDatePicker
                          disableToolbar
                          variant="inline"
                          format="MM/dd/yyyy"
                          id="date-picker-inline"
                          placeholder="Commencement Date"
                          value={selectedDate}
                          onChange={handleDateChange}
                          KeyboardButtonProps={{
                            'aria-label': 'change date',
                          }}
                        />
                      </MuiPickersUtilsProvider>
                    </Box>
                  </Grid>



                </Grid>
              </Box>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<CancelOutlinedIcon />}> Cancel </Button>
                  <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save </Button>
                </Box>
              </Grid>
            </TabPanel>
 
            <TabPanel value={value} index={2} className="ddtab">
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={2} alignItems="top">

                  <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box className='brd1 flx_sa p0' > 
                        <Typography variant='h5' className='fw500 bl' > Upload Documents </Typography> 
                        <IconButton color='primary' component="span">
                          <Tooltip title="Edit" aria-label="add">
                            <CreateIcon className='smicobtn' />
                          </Tooltip>
                        </IconButton> 
                    </Box>
                  </Grid>


                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl fw600'>PAN Card</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>

                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl fw600'>GSTIN Doc</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>

                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl fw600'>Company Incorporation Certificate</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>

                    <Box mt={1} mb={1}><Divider /></Box>

                  </Grid>


                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl fw600'>ARN Certificate</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>


                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl fw600'>EUIN Card</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>
 

                </Grid>
              </Box>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<CancelOutlinedIcon />}> Cancel </Button>
                  <Link to="/successfull" className="link">
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save </Button>
                  </Link>
                </Box>
              </Grid>
            </TabPanel>
 
          </Box>
        </Container>
      </Box>



      </Box>

      
    </>
  );
}
