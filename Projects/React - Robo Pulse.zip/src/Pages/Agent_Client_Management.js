import React from 'react';
import { Box, Container, Grid, Button, Typography, IconButton, TextField, Tooltip } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import GetAppIcon from '@material-ui/icons/GetApp';

import { Link } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import CloseIcon from '@material-ui/icons/Close';

import Autocomplete from '@material-ui/lab/Autocomplete';

const chooseopt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]

const styles = (theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(2),
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: theme.palette.grey[500],
    },
});

const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles((theme) => ({
    root: {
        padding: theme.spacing(2),
    },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(1),
    },
}))(MuiDialogActions);


export default function Agent_Client_Management() {


    // Dialog Open 
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    //Dialog State Ended 



    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex: 1
    }

    const columnDefs = [
        {
            headerName: 'Sr No.', field: 'number', minWidth: 40, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'Client ID ', field: 'c_id', minWidth: 100, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Investor Name', field: 'name', minWidth: 140, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Contact', field: 'contact', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Email ID', field: 'email', minWidth: 150, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'PAN', field: 'pan', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Total Funds', field: 'funds', minWidth: 115, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Total Units', field: 'units', minWidth: 115, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Total Invested Amount(Rs)', field: 'amount', minWidth: 150, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'KYC Status', field: 'kyc', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'CM Name', field: 'cm', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'ZM Name', field: 'zm', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'SM Name', field: 'sm', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'DM Name', field: 'dm', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'BM Name', field: 'bm', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'RM Name', field: 'rm', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Agent', field: 'agent', minWidth: 110, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'City', field: 'city', minWidth: 120, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Branch', field: 'branch', minWidth: 125, align: 'center', cellStyle: { textAlign: 'left' } },
    ]


    const [rowData] = useState([
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },
        {
            c_id: 'XXX', name: 'ABC', contact: '9898989898', email: 'abc@gmail.com', pan: "ABCDE258F", funds: "45", units: "7000",
            amount: "900000", kyc: 'Verified', cm: 'ABC', zm: 'DEF', sm: 'GHI', dm: 'JKL', bm: 'MVP', rm: 'XYZ', agent: 'VXD', city: 'Mumbai', branch: 'Andheri branch',
        },

    ])



    return (
        <>

            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' mb={"5px"}>
                                    <Typography variant='h5' className='bl fw500'>Agent Client Management : Investor List </Typography>
                                </Box>
                            </Grid>






                            <Grid item lg={12} md={12} sm={12} xs={12}>

                                <Grid container spacing={1} alignItems="top" justifyContent='flex-end'>


                                    <Grid item lg={2} md={3} sm={4} xs={4}>
                                        <Box className='bt al_right'  >
                                            <Button variant="contained" className='btn bl_bttn' size='small' onClick={handleClickOpen} > Add New Client </Button>
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={3} sm={4} xs={4}>
                                        <Box className='outlined_autocomplete' >
                                            <Autocomplete
                                                id="combo-box-demo"
                                                options={chooseopt}
                                                getOptionLabel={(option) => option.title}
                                                renderInput={(params) => <TextField {...params} placeholder="Assign" variant="outlined" />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item>
                                        <ul id='searchportion' style={{ marginTop: '5px', marginBottom: '-8px' }}>
                                            <li>
                                                <div class="form-group has-search">
                                                    <span class="form-control-feedback"><SearchIcon /></span>
                                                    <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                                </div>
                                            </li>
                                        </ul>
                                    </Grid>


                                    <Grid item >
                                        <Box mt={'5px'}>
                                        <IconButton>
                                            <Tooltip title="Download">
                                                <GetAppIcon className='col1' />
                                            </Tooltip>
                                        </IconButton>
                                        </Box> 
                                    </Grid>




                                </Grid>

 


                            </Grid>



                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '62vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>
                            </Grid>


                            <Grid container spacing={1} alignItems="top">


                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' v>
                                        <Link to='#' className="link">
                                            <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
                                        </Link>
                                    </Box>
                                </Grid>
                            </Grid>


                        </Box>



                    </Box>
                </Container>
            </Box>







            <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={open} className='c_modal'>
                <DialogTitle id="customized-dialog-title" onClose={handleClose}>
                    <Box pt={1}>
                        <Typography variant='h5' className='bl fw500'>
                            Add New Client
                        </Typography>
                    </Box>
                </DialogTitle>
                <DialogContent dividers>
                    <Grid container spacing={2} alignItems="top">


                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='alltxfield'>
                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter Email ID Here" fullWidth />
                            </Box>
                        </Grid>


                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Box className='bt al_right' mt={1}>
                        <Button autoFocus onClick={handleClose} variant="contained" className='btn bl_bttn' size='small' >
                            Send
                        </Button>
                    </Box>
                </DialogActions>

            </Dialog>




        </>
    );
}
