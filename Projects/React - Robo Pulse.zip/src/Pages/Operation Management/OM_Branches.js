import React from 'react';
import { Box, Container, Grid, Button, Typography, Tooltip, IconButton, TextField, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import GetAppIcon from '@material-ui/icons/GetApp';
import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import { Link } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import CloseIcon from '@material-ui/icons/Close';
import Autocomplete from '@material-ui/lab/Autocomplete';

const chooseopt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]

const styles = (theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(2),
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: theme.palette.grey[500],
    },
});

const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles((theme) => ({
    root: {
        padding: theme.spacing(2),
    },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(1),
    },
}))(MuiDialogActions);


export default function OM_Branches() {


    // Dialog Open 
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    //Dialog State Ended 



    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex: 1
    }

    const columnDefs = [
        {
            headerName: '', field: 'number', maxWidth: 55, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'Branch Name', field: 'name', minWidth: 160, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Branch Address', field: 'address', minWidth: 360, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'City Name', field: 'city', minWidth: 115, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'City Code', field: 'citycode', minWidth: 115, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Pincode', field: 'pin', minWidth: 115, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Branch Manager', field: 'bm', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Branch Code', field: 'branchcode', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
    ]


    const [rowData] = useState([
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },

        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
        {
            name: 'Indira nagar branch', address: 'Surkan Arcade, Bhujbal Farm Road Indira Nagar Nashik - 422009', city: "Nashik",
            citycode: 'CCA002', pin: "424007", bm: "Not assigned", branchcode: "INB001",
        },
        {
            name: 'Andheri East branch', address: 'No 12 & 17, Vishal Shopping Centre, Sir MV Road', city: "Mumbai",
            citycode: 'CCA001', pin: "422002", bm: "XYZ", branchcode: "AEB002",
        },
    ])



    return (
        <>

            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' mb={"5px"}>
                                    <Typography variant='h5' className='bl fw500'> Operation Management Branches </Typography>
                                </Box>
                            </Grid>


                            <Grid
                                container
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                            >

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <ul id='searchportion' style={{ marginBottom: '-8px' }}>
                                        <li>
                                            <Box className='bt al_right'  >
                                                <Button variant="contained" className='btn bl_bttn' size='small' onClick={handleClickOpen} > Add Branch </Button>
                                            </Box>
                                        </li>

                                        <li>
                                            <div class="form-group has-search">
                                                <span class="form-control-feedback"><SearchIcon /></span>
                                                <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                            </div>
                                        </li>

                                        <li>
                                            <IconButton>
                                                <Tooltip title="Download">
                                                    <GetAppIcon className='col1' />
                                                </Tooltip>
                                            </IconButton>
                                        </li>

                                    </ul>
                                </Grid>

                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '62vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>
                            </Grid>


                            <Grid container spacing={1} alignItems="top">
                                <Grid item lg={2} md={4} sm={6} xs={6}>
                                    <Box className='bt al_left'>
                                        <Box>
                                            <Typography variant='h6' className='bl' > Total branches : <span className='gry'> 02 </span></Typography>
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={10} md={8} sm={6} xs={6}>
                                    <Box className='bt al_right'>
                                        <Link to='#' className="link">
                                            <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
                                        </Link>
                                    </Box>
                                </Grid>
                            </Grid>


                        </Box>



                    </Box>
                </Container>
            </Box>







            <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={open}>
                <DialogTitle id="customized-dialog-title" onClose={handleClose}>
                    <Box pt={1}>
                        <Typography variant='h5' className='bl fw500'>
                            Enter New Branch Details
                        </Typography>
                    </Box>
                </DialogTitle>
                <DialogContent dividers>
                    <Grid container spacing={1} alignItems="top">


                        <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className='alltxfield'>
                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter Branch Name" fullWidth />
                            </Box>
                        </Grid>


                        <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className='alltxfield'>
                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter Branch Address" fullWidth />
                            </Box>
                        </Grid>

                        <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className='textfield' >
                                <Autocomplete
                                    id="combo-box-demo"
                                    options={chooseopt}
                                    getOptionLabel={(option) => option.title}
                                    renderInput={(params) => <TextField {...params} label="City" variant="filled" />}
                                />
                            </Box>

                        </Grid>

                        <Grid item lg={6} md={6} sm={12} xs={12}>
                            <Box className='alltxfield'>
                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Enter PinCode" fullWidth />
                            </Box>
                        </Grid>


                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Box className='bt al_right' mt={1}>
                        <Button autoFocus onClick={handleClose} variant="contained" className='btn sk_bttn' size='small' >
                            Cancel
                        </Button>

                        <Button autoFocus onClick={handleClose} variant="contained" className='btn bl_bttn' size='small' >
                            Save
                        </Button>
                    </Box>
                </DialogActions>

            </Dialog>




        </>
    );
}
