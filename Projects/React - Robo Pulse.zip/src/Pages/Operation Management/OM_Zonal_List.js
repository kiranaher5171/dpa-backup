import React from 'react';
import { Box, Container, Grid, Button, Typography, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';

import { Link } from 'react-router-dom';


export default function OM_Zonal_List() {

    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex: 1
    }


    const columnDefs = [
        {
            headerName: '', field: 'number', maxWidth: 50, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'Country', field: 'country', minWidth: 100, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Country Code', field: 'countrycode', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Zone/Region', field: 'zone', minWidth: 150, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Zonal code', field: 'zonecode', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'State', field: 'state', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'State Code', field: 'statecode', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'District', field: 'dist', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'District Code', field: 'distcode', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Branch Name', field: 'branch', minWidth: 150, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Branch code', field: 'branchcode', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'City', field: 'city', minWidth: 125, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'City Code', field: 'citycode', minWidth: 130, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Branch Address', field: 'address', minWidth: 280, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Pincode', field: 'pincode', minWidth: 115, align: 'center', cellStyle: { textAlign: 'left' } },
    ]


    const [rowData] = useState([
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
        {
            srno: '1', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA001', state: 'Delhi',
            statecode: 'SCA001', dist: "New Delhi", distcode: 'DCA001', branch: "Janakpuri Branch", branchcode: "NJBC006023",
            city: 'Delhi', citycode: 'CCA001', address: 'B/1/455, Gr Flr Janakpuri New Delhi - 110058', pincode: '110058',
            edit: "422008", delete: "422008",
        },
        {
            srno: '2', country: 'India', countrycode: '(+91)', zone: "North-Eastern region", zonecode: 'ZNA002', state: 'Hariyana',
            statecode: 'SCA002', dist: "Panipat", distcode: 'DCA002', branch: "Panipat Branch", branchcode: "NJBC000293",
            city: 'Delhi', citycode: 'CCA002', address: '515 & 515B, Gaylord Hotel Building, Ward No 8, GT Road, Panipat, Haryana, 132103',
            pincode: '132103', edit: "422008", delete: "422008",
        },
    ])



    return (
        <>

            <Box component="section"   className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box  className='brd1'  mb={"5px"}>
                                    <Typography variant='h5' className='bl fw500'> Operation Management : Zonal / Region wise List </Typography>
                                </Box>
                            </Grid>

                        

                            <Grid
                                container
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                            >

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <ul id='searchportion' style={{marginBottom: '-6px'}}>
                                        <li>
                                            <div class="form-group has-search">
                                                <span class="form-control-feedback"><SearchIcon /></span>
                                                <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                            </div>
                                        </li>
                                    </ul>
                                </Grid>

                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '62vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>
                            </Grid>


                            <Grid container spacing={1} alignItems="top">


                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' v>
                                        <Link to='#' className="link">
                                            <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
                                        </Link>
                                    </Box>
                                </Grid>
                            </Grid>


                        </Box>



                    </Box>
                </Container>
            </Box>






        </>
    );
}
