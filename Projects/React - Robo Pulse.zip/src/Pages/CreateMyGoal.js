import React from 'react';
import { Box, Container, Grid, Button, Typography, TextField, Radio, RadioGroup, FormControlLabel } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import Target from "../asset/images/create_my_goal/target.svg";
import Lumpsum from "../asset/images/create_my_goal/lumpsum.svg";
import SIP from "../asset/images/create_my_goal/sip.svg";
import Tenure from "../asset/images/create_my_goal/tenure.svg";


export default function CreateMyGoal() {



    return (
        <>

            <Box id='CreateMyGoal' component="section" className='codingpagestart footerpadding'>

                <Container className='containerwidth'>

                    <Box className='grybx flx_sa'>
                        <Box pt={'4px'}>
                            <Typography variant='h6' className='mainhead'> Target Amount and SIP </Typography>
                        </Box>
                        <Box className='bt'>
                            <Button variant="contained" className='al_center btn sk_bttn' size='small' endIcon={<ArrowForwardIcon />}> Create My Goal </Button>
                        </Box>
                    </Box>


                    <Box id="radio_grp">
                        <Grid container spacing={0} alignItems="flex-start">

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='radio flx_fs'>

                                    <Box pt={'9px'} mr={1}>
                                        <Typography variant='h6' className='gry'> Risk Appetite : </Typography>
                                    </Box>

                                    <Box>
                                        <RadioGroup row aria-label="position" name="position" defaultValue="top">
                                            <FormControlLabel
                                                value="rdo1"
                                                control={<Radio color="primary" size='small' />}
                                                label="Conservative"
                                                labelPlacement="end"
                                            />
                                            <FormControlLabel
                                                value="rdo2"
                                                control={<Radio color="primary" size='small' />}
                                                label="Moderate Conservative"
                                                labelPlacement="end"
                                            />
                                            <FormControlLabel
                                                value="rdo3"
                                                control={<Radio color="primary" size='small' />}
                                                label="Moderate"
                                                labelPlacement="end"
                                            />
                                            <FormControlLabel
                                                value="rdo4"
                                                control={<Radio color="primary" size='small' />}
                                                label="Moderate Aggressive"
                                                labelPlacement="end"
                                            />
                                            <FormControlLabel
                                                value="rdo5"
                                                control={<Radio color="primary" size='small' />}
                                                label="Aggressive"
                                                labelPlacement="end"
                                            />
                                        </RadioGroup>
                                    </Box>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>




                    <Box id='filters' mt={0}>
                        <Grid container spacing={0} alignItems="flex-start" justifyContent='center'>


                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className='sk_bttn'>
                                    <Grid container spacing={1} alignItems="flex-end">
                                        <Grid item lg={2} md={2} sm={2} xs={2}>
                                            <Box className='mb12 al_center'>
                                                <img src={Target} alt="Target Amount" className='icobtn_lg' />
                                            </Box>
                                        </Grid>
                                        <Grid item lg={10} md={10} sm={10} xs={10}>
                                            <Box className='alltxfield txtfld_ico mb16'>
                                                <TextField id="filled-basic" className='filleddp' variant="outlined" label="Target Amount" fullWidth />
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className='bl_bttn'>
                                    <Grid container spacing={1} alignItems="flex-end">
                                        <Grid item lg={2} md={2} sm={2} xs={2}>
                                            <Box className='mb12'>
                                                <img src={Lumpsum} alt="Lumpsum Amount" className='icobtn_lg' />
                                            </Box>
                                        </Grid>
                                        <Grid item lg={10} md={10} sm={10} xs={10}>
                                            <Box className='alltxfield txtfld_ico mb16'>
                                                <TextField id="filled-basic" className='filleddp' variant="outlined" label="Lumpsum Investment" fullWidth />
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>



                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className='sk_bttn'>
                                    <Grid container spacing={1} alignItems="flex-end">
                                        <Grid item lg={2} md={2} sm={2} xs={2}>
                                            <Box className='mb12'>
                                                <img src={SIP} alt="sip amount" className='icobtn_lg' />
                                            </Box>
                                        </Grid>
                                        <Grid item lg={10} md={10} sm={10} xs={10}>
                                            <Box className='alltxfield txtfld_ico mb16'>
                                                <TextField id="filled-basic" className='filleddp' variant="outlined" label="SIP Amount" fullWidth />
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className='bl_bttn'>
                                    <Grid container spacing={1} alignItems="flex-end">
                                        <Grid item lg={2} md={2} sm={2} xs={2}>
                                            <Box className='mb12'>
                                                <img src={Tenure} alt="Tenure" className='icobtn_lg' />
                                            </Box>
                                        </Grid>
                                        <Grid item lg={10} md={10} sm={10} xs={10}>
                                            <Box className='alltxfield txtfld_ico mb16'>
                                                <TextField id="filled-basic" className='filleddp' variant="outlined" label="Tenure" fullWidth />
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>


                        </Grid>
                    </Box>


                    <Box className='wh_bx' mt={1}>
                        <Grid container spacing={2} alignItems="top">
                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className='ol_bx'>

                                    <Box className='bxhead'>
                                        <Typography variant="h6" className='col1 fw5'> Asset Allocation </Typography>
                                    </Box>

                                    <Box className='graph_hgt'>

                                    </Box>


                                </Box>
                            </Grid>

                            <Grid item lg={6} md={6} sm={12} xs={12}>
                                <Box className='ol_bx'>

                                    <Box className='bxhead'>
                                        <Typography variant="h6" className='col1 fw5'> Risk Profiling </Typography>
                                    </Box>

                                    <Box className='graph_hgt'>

                                    </Box>

                                </Box>
                            </Grid>
                        </Grid>
                    </Box>


                </Container>
            </Box>

        </>
    );
}
