import React from 'react';
import { Box, Container, Grid, List, ListItem, ListItemText, Button, Typography, TextField, Divider, Tooltip } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import { Link } from 'react-router-dom';
import Profile from "../asset/images/profile_pic.jpg"
import Profile2 from "../asset/images/profile_pic.jpg"
import GroupAddOutlinedIcon from '@material-ui/icons/GroupAddOutlined';
import Autocomplete from '@material-ui/lab/Autocomplete';

const Role = [
    { title: 'CM' },
    { title: 'ZM' },
    { title: 'SM' },
    { title: 'DM' },
    { title: 'BM' },
    { title: 'RM' },
    { title: 'Agent' },
]


export default function IFA_existing_team() {

    return (
        <>


            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Box>
                                <Grid container spacing={1} alignItems="center" justifyContent='space-between'>

                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='brd1' >
                                            <Typography variant='h5' className='fw500 bl'> Hello, Team Name Here </Typography>
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={2} sm={6} xs={12}>
                                        <Box className='textfield' >
                                            <Autocomplete
                                                id="combo-box-demo"
                                                options={Role}
                                                getOptionLabel={(option) => option.title}
                                                renderInput={(params) => <TextField {...params} label="Select Role" variant="filled" />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={2} sm={6} xs={12}>
                                        <Box className='bt al_right'>
                                            <Link to="/ifa_add_new_member" className="link">
                                                <Button variant="contained" className='al_center btn bl_bttn' size='small' startIcon={<AddCircleOutlineIcon />}> Add New Team </Button>
                                            </Link>
                                        </Box>
                                    </Grid>


                                </Grid>
                            </Box>

                            <Box>
                                <Grid container spacing={2} alignItems="center">
                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className='grybx'>
                                            <Box className='al_center'>
                                                <img alt="Profile_Image" src={Profile} className="avtar_img_md" />
                                            </Box>

                                            <Box>
                                                <Typography variant='h6' className='bl' > Mr. John Smith </Typography>
                                                <Typography variant='subtitle2' className='gry' > Designation </Typography>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box className='bt'>
                                                <Tooltip title="No. Of Client assign">
                                                    <Link to='ifa_assigned_agent_list' className='link'>
                                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<GroupAddOutlinedIcon />}> 35 </Button>
                                                    </Link>
                                                </Tooltip>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box id='existing_team'>

                                                <Grid container spacing={1} alignItems="center">
                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="CM Name" secondary="Name of CM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="ZM Name" secondary="Name of ZM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="SM Name" secondary="Name of SM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>



                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="DM Name" secondary="Name of DM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>


                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="BM Name" secondary="Name of BM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="RM Name" secondary="Name of RM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                </Grid>

                                            </Box>


                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className='grybx'>
                                            <Box className='al_center'>
                                                <img alt="Profile_Image" src={Profile2} className="avtar_img_md" />
                                            </Box>

                                            <Box>
                                                <Typography variant='h6' className='bl' > Mr. John Smith </Typography>
                                                <Typography variant='subtitle1' className='gry' > Designation </Typography>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box className='bt'>
                                                <Tooltip title="No. Of Client assign">
                                                    <Link to='ifa_assigned_agent_list' className='link'>
                                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<GroupAddOutlinedIcon />}> 35 </Button>
                                                    </Link>
                                                </Tooltip>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box id='existing_team'>

                                                <Grid container spacing={1} alignItems="center">
                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="CM Name" secondary="Name of CM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="ZM Name" secondary="Name of ZM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="SM Name" secondary="Name of SM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>



                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="DM Name" secondary="Name of DM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>


                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="BM Name" secondary="Name of BM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="RM Name" secondary="Name of RM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                </Grid>

                                            </Box>


                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className='grybx' >
                                            <Box className='al_center'>
                                                <img alt="Profile_Image" src={Profile} className="avtar_img_md" />
                                            </Box>

                                            <Box>
                                                <Typography variant='h6' className='bl' > Mr. John Smith </Typography>
                                                <Typography variant='subtitle1' className='gry' > Designation </Typography>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box className='bt'>
                                                <Tooltip title="No. Of Client assign">
                                                    <Link to='ifa_assigned_agent_list' className='link'>
                                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<GroupAddOutlinedIcon />}> 35 </Button>
                                                    </Link>
                                                </Tooltip>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box id='existing_team'>

                                                <Grid container spacing={1} alignItems="center">
                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="CM Name" secondary="Name of CM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="ZM Name" secondary="Name of ZM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="SM Name" secondary="Name of SM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>



                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="DM Name" secondary="Name of DM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>


                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="BM Name" secondary="Name of BM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="RM Name" secondary="Name of RM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                </Grid>

                                            </Box>


                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={3} sm={4} xs={12}>
                                        <Box className='grybx'>
                                            <Box className='al_center'>
                                                <img alt="Profile_Image" src={Profile2} className="avtar_img_md" />
                                            </Box>

                                            <Box>
                                                <Typography variant='h6' className='bl' > Mr. John Smith </Typography>
                                                <Typography variant='subtitle1' className='gry' > Designation </Typography>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box className='bt'>
                                                <Tooltip title="No. Of Client assign">
                                                    <Link to='ifa_assigned_agent_list' className='link'>
                                                        <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<GroupAddOutlinedIcon />}> 35 </Button>
                                                    </Link>
                                                </Tooltip>
                                            </Box>

                                            <Divider className='divider2' />

                                            <Box id='existing_team'>

                                                <Grid container spacing={1} alignItems="center">
                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="CM Name" secondary="Name of CM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="ZM Name" secondary="Name of ZM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="SM Name" secondary="Name of SM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>



                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="DM Name" secondary="Name of DM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>


                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="BM Name" secondary="Name of BM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                                        <List>
                                                            <ListItem>
                                                                <ListItemText primary="RM Name" secondary="Name of RM" />
                                                            </ListItem>
                                                        </List>
                                                        <Divider className='divider2' />
                                                    </Grid>

                                                </Grid>

                                            </Box>


                                        </Box>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={6}>
                                        <Box>
                                            <Typography variant='h6' className='bl' > Total Count : <span className='gry'> 04 </span></Typography>
                                        </Box>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={6}>
                                        <Box className='bt al_right'>
                                            <Link to="/ifa_assigned_cm_list" className='link'>
                                                <Button variant="contained" className='al_center btn gr_bttn' size='small'  > See All </Button>
                                            </Link>
                                        </Box>
                                    </Grid>

                                </Grid>
                            </Box>




                        </Box>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1}>
                                <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                            </Box>
                        </Grid>


                    </Box>
                </Container>
            </Box>




        </>
    );
}
