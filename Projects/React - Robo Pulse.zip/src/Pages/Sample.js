import React from 'react' 
import PropTypes from 'prop-types'; 
import {   Box,   Container, Grid,  AppBar, Tabs, Tab, Button, Typography, RadioGroup, FormControlLabel, Radio, FormControl, InputLabel, TextField, Select, MenuItem, Divider, Checkbox,   } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import AgGrid from './Ag_grid';
 
import f1a from "../asset/images/riskquestion/f01a.svg";
import f1b from "../asset/images/riskquestion/f01b.svg";
import f2a from "../asset/images/riskquestion/f02a.svg";
import f2b from "../asset/images/riskquestion/f02b.svg";
import f3a from "../asset/images/riskquestion/f03a.svg";
import f3b from "../asset/images/riskquestion/f03b.svg";
 


//Tabbed End
function TabPanel(props) {
const { children, value, index, ...other } = props;
return (
<div
role="tabpanel"
hidden={value !== index}
id={`scrollable-auto-tabpanel-${index}`}
aria-labelledby={`scrollable-auto-tab-${index}`}
{...other}
>
{value === index && (
<Box p={3}>
<Typography>{children}</Typography>
</Box>
)}
</div>
);
}
TabPanel.propTypes = {
children: PropTypes.node,
index: PropTypes.any.isRequired,
value: PropTypes.any.isRequired,
};
function a11yProps(index) {
return {
id: `scrollable-auto-tab-${index}`,
'aria-controls': `scrollable-auto-tabpanel-${index}`,
};
}
//Tabbed End

export default function Sample() {
 

//Tabbed start  
const [value, setValue] = React.useState(0);

const handleChange = (event, newValue) => {
setValue(newValue);
};

const [value2, setValue2] = React.useState(0);

const handleChange2 = (event, newValue) => {
setValue2(newValue);
};
 
//Tabbed End


return (

< >
 
<Box pt={'6%'}>
<Container maxWidth='md'>



                <Grid container spacing={0} alignItems="center">

                    <Box className='sti'>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='maintabbedsection'>
                                <AppBar position="static" className="tabbedbar">
                                    <Tabs
                                        value={value}
                                        onChange={handleChange}
                                        indicatorColor="none"
                                        textColor="primary"
                                        variant="scrollable"
                                        scrollButtons="auto"
                                        aria-label="scrollable auto tabs example"
                                    >
                                        <Tab disableRipple label="Source" icon={<ArrowForwardIcon />} {...a11yProps(0)} />
                                        <Tab disableRipple label="Transformation" icon={<ArrowForwardIcon />} {...a11yProps(1)} />
                                        <Tab disableRipple label="Hygiene" icon={<ArrowForwardIcon />} {...a11yProps(2)} />
                                        <Tab disableRipple label="Comparison" icon={<ArrowForwardIcon />} {...a11yProps(3)} />
                                        <Tab disableRipple label="Validation" icon={<ArrowForwardIcon />} {...a11yProps(4)} />
                                        <Tab disableRipple label="Deduplication" icon={<ArrowForwardIcon />} {...a11yProps(5)} />
                                        <Tab disableRipple label="Destination" icon={<ArrowForwardIcon />} {...a11yProps(6)} />
                                    </Tabs>
                                </AppBar>
                            </Box>
                        </Grid>
                    </Box>



                    <TabPanel value={value} index={0}>

                        <Box className='secondtabbedsection'>
                            <AppBar position="static" className="tabbedbar">
                                <Tabs
                                    value={value2}
                                    onChange={handleChange2}
                                    indicatorColor="none"
                                    textColor="primary"
                                    variant="scrollable"
                                    scrollButtons="auto"
                                    aria-label="scrollable auto tabs example"
                                >
                                    <Tab disableRipple label="Subtab 1 &#x27A7;" {...a11yProps(0)} />
                                    <Tab disableRipple label="Subtab 2 " {...a11yProps(1)} />
                                </Tabs>
                            </AppBar>
                        </Box>

                        {/* ============Sub Tab 1 Start ============= */}
                        <TabPanel value={value2} index={0} style={{ backgroundColor: '#f00000', color: "#ffffff" }} >
                            SubTab 1
                        </TabPanel>
                        {/* ============Sub Tab 1 End ============= */}

                        {/* ============Sub Tab 2 Start ============= */}
                        <TabPanel value={value2} index={1} style={{ backgroundColor: '#ff5500', color: "#ffffff" }} >
                            SubTab 2
                        </TabPanel>
                        {/* ============Sub Tab 2 END ============= */}

                    </TabPanel>


                </Grid> 



<Box mt={5}>
<Grid container spacing={0} alignItems="center">
<Grid item lg={12} md={4} sm={4} xs={12}>
    <Box className='bt al_center'>
    <Button variant="contained" className='btn sk_bttn' size='small' >Sky Blue Center</Button>
    </Box>
</Grid>
<Grid item lg={12} md={4} sm={4} xs={12}>
    <Box className='bt al_right'>
    <Button variant="contained" className='al_center btn bl_bttn' size='small' >blue Blue right</Button>
    </Box>
</Grid>
<Grid item lg={12} md={4} sm={4} xs={12}>
    <Box className='bt al_left'>
    <Button variant="contained" className='al_right btn gr_bttn' size='small' >grey Blue left</Button>
    </Box>
</Grid>
</Grid>
</Box>

<Box mt={5}>
    <h1 className='bl fw400'>H1 Heading</h1>
    <h1 className='bl fw500'>H1 Heading</h1>
    <h1 className='bl fw600'>H1 Heading</h1>
    <h2 className='bl fw400'>H2 Heading</h2>
    <h3 className='bl fw500'>H3 Heading</h3>
    <h4 className='bl fw600'>H4 Heading</h4>
    <h5 className='bl fw400'>H5 Heading</h5>
    <h6 className='bl fw500'>H6 Heading</h6>
</Box>


<Grid container spacing={0} alignItems="center">
<Grid item lg={12} md={12} sm={12} xs={12}>
<Box mt={2} mb={2}>
<AgGrid/>
</Box>
</Grid>
</Grid>

<Grid container spacing={2} alignItems="center">
<Grid item lg={6} md={6} sm={12} xs={12}>
<Box className='textfield' >
<FormControl variant='filled'>
<InputLabel id="demo-simple-select-placeholder-label-label">
Select Connection
</InputLabel>
<Select
labelId="demo-simple-select-placeholder-label-label"
id="demo-simple-select-placeholder-label"

>
<MenuItem className='maindd' value={10}><strong>+ New Connection</strong></MenuItem>
<Divider/>
<MenuItem value={20}>Connection 1 </MenuItem>
<MenuItem value={30}>Connection 2 </MenuItem>
<MenuItem value={40}>Connection 3 </MenuItem>
</Select>
</FormControl>
</Box>
</Grid>

<Grid item lg={6} md={6} sm={12} xs={12}>
<Box className='alltxfield'>
<TextField id="filled-basic" className='filleddp' variant="filled" label="Text-Field" fullWidth />
</Box>
</Grid>

<Grid item lg={6} md={6} sm={12} xs={12}>
<Box className='checkbxline'>
<FormControlLabel
control={<Checkbox name="checkedA" />}
label="Send Email on Failed Runs"
/>
</Box>
</Grid>


<Grid item lg={6} md={6} sm={12} xs={12}>
<Box className='radio'>
<RadioGroup row aria-label="position" name="position" defaultValue="top">
<FormControlLabel
value="top"
control={<Radio color="primary" />}
label="Radio1"
labelPlacement="end"
/>
<FormControlLabel
value="database"
control={<Radio color="primary" />}
label="Radio2"
labelPlacement="end"
/>
</RadioGroup>
</Box>
</Grid>

<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className="options_box" pb={5} pt={5}>
<RadioGroup row aria-label="position" name="position" defaultValue="top">           

<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ f1a } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ f1b } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Index Fund"
control={<Radio color="primary" />}
label="Index Fund"
labelPlacement="bottom"
/>
</Box>
</Box>

<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ f2a } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ f2b } width={100} alt="fliper" /></p>
</Box>
</div>
<FormControlLabel
value="ETFs"
control={<Radio color="primary" />}
label="ETFs"
labelPlacement="bottom"
/>
</Box>
</Box>

<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ f3a } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ f3b } width={100}  alt="fliper" /></p>
</Box>
</div>
<FormControlLabel
value="ELSS"
control={<Radio color="primary" />}
label="ELSS"
labelPlacement="bottom"
/>
</Box>
</Box>




</RadioGroup>   
</Box>
</Grid>




</Grid>

</Container>
</Box>
 
</>
);
}
