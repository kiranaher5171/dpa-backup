import React from 'react'
import { Box, Grid, } from '@material-ui/core'; 

import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';      // the AG Grid React Component
import 'ag-grid-community/dist/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/dist/styles/ag-theme-alpine.css'; // Optional theme CSS


const Ag_grid = () => {
 
    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 30;
    const headerHeight = 30;

    //Function foe Quick Search bar
    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    //For Quick Serach Bar
    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }

    // Search box

    // Applying Ag-Grid Properties for table
    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true
    }
    // ===================================AG table start=======================


    const [rowData] = useState([
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "data source", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
        { source: "Nike_Cluster_ID", sourcedata: "Integer", dest: "test", desttype: "Integer", warnings: "Enter Data" },
    ])
    const columnDefs = [

        { headerName: 'Source', field: 'source', width: 180, },
        { headerName: 'Source Data Type', field: 'sourcedata', width: 200, },
        { headerName: 'Destination', field: 'dest', width: 200, },
        { headerName: 'Destination Data Type', width: 220, field: 'desttype', },
        { headerName: 'Warnings (2)', field: 'warnings', width: 160, },
    ]



    return (
        <div>

            <Box className='maintabbedsection' style={{ backgroundColor: '#ffffff', padding: "10px" }} >
                <Box className='middleportion'>

                    <Box mt={0}>
                        <Grid container spacing={0} alignItems="center">

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <ul id='searchportion'>
                                    <li>
                                        <div class="form-group has-search">
                                            <span class="form-control-feedback"><SearchIcon /></span>
                                            <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                        </div>
                                    </li>
                                </ul>
                            </Grid>
                        </Grid>
                    </Box>


                    <Box className='dpacloud_table mb_n sh_n tbheading' mt={0}>
                        <div id='myGrid' style={{ height: 280, width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                            />
                        </div>
                    </Box>


                </Box>
            </Box>






        </div>
    )
}

export default Ag_grid