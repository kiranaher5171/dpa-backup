import React from 'react'; 
import { Box, Container, Grid, Button, Typography, TextField, IconButton, } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack'; 
import { Link } from 'react-router-dom';

import Check from '../../asset/images/checkmark.gif'
 
import CloseOutlinedIcon from '@material-ui/icons/CloseOutlined';
import { withStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent'; 
import CloseIcon from '@material-ui/icons/Close';
import DoneOutlinedIcon from '@material-ui/icons/DoneOutlined'; 
 
 


const styles = (theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(2),
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: theme.palette.grey[500],
    },
});

const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles((theme) => ({
    root: {
        padding: theme.spacing(2),
    },
}))(MuiDialogContent);

 

export default function TM_Proceed_Cancellation() {

    // Dialog Open 
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    //Dialog State Ended 


    return (
        <>


            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>
                            <Grid container spacing={1} alignItems="center" justifyContent='center'>


                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box >
                                        <Typography variant='h5' className=' bl' > Cancelled SIP </Typography>
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='brd1' mb={2} mt={"-20px"}></Box>
                                </Grid>



                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="Scheme Name" fullWidth />
                                    </Box>

                                </Grid>

                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="SIP/XSIP registration number" fullWidth />
                                    </Box>

                                </Grid>

                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='alltxfield'>
                                        <TextField id="filled-basic" className='filleddp' variant="filled" label="No. of EMI for Cancellation" fullWidth />
                                    </Box>
                                </Grid>

                            </Grid>
                        </Box>


                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1}>
                                <Link to='/tm_cancelled_sip_cards' className="link">
                                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                </Link>
                                <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<CloseOutlinedIcon />} onClick={handleClickOpen}> Cancel </Button>
                            </Box>
                        </Grid>


                    </Box>
                </Container>
            </Box>


            <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={open} className='c_modal'>
                <DialogTitle id="customized-dialog-title" onClose={handleClose}>

                </DialogTitle>
                <DialogContent>
                    <Grid container spacing={2} alignItems="top">

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='al_center'>
                                <img src={Check} className='logo_success' alt='logo' />
                            </Box>
                        </Grid>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='al_center'>
                                <Typography variant='h6' className='bl'> Your SIP cancellation request initiated. </Typography>
                            </Box>
                        </Grid>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='al_center'>
                                <Typography variant='h6' className='bl'>  Kindly confirm through email which you have recieved. </Typography>
                            </Box>
                        </Grid>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_center' mt={1}>
                                <Button autoFocus onClick={handleClose} variant="contained" className='btn bl_bttn' size='small' endIcon={<DoneOutlinedIcon />} >
                                    Done
                                </Button>
                            </Box>
                        </Grid>

                    </Grid>
                </DialogContent>


            </Dialog>



        </>
    );
}
