import React from 'react';
import { Box, Container, Grid, List, ListItem, ListItemText, Button, Typography, Divider, IconButton } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import { Link } from 'react-router-dom';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';

import CancelIcon from '@material-ui/icons/Cancel';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import WatchLaterIcon from '@material-ui/icons/WatchLater';
import DoneAllIcon from '@material-ui/icons/DoneAll';

import ABSL from "../../asset/images/Logos/aditya_birla.png"
import ICICI from "../../asset/images/Logos/icici_fund.png"
import HDFC from "../../asset/images/Logos/hdfc_fund2.png"
import INVE from "../../asset/images/Logos/invesco2.png"
import EMI from "../../asset/images/Logos/emi.png"

import Carousel from "react-elastic-carousel";



const breakPoints = [
    { width: 100, itemsToShow: 1 },
    { width: 360, itemsToShow: 1, itemsToScroll: 1 },
    { width: 460, itemsToShow: 2, itemsToScroll: 1 },
    { width: 550, itemsToShow: 2, itemsToScroll: 2 },
    { width: 600, itemsToShow: 3, itemsToScroll: 2 },
    { width: 1050, itemsToShow: 4, itemsToScroll: 2 },
    { width: 1200, itemsToShow: 4, itemsToScroll: 3 }
];

export default function Purchase_Details() {

    return (
        <>


            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='maintabbedsection mb_n'>

                        <Box className='wch_bx' pb={2}>

                            <Grid container spacing={3} alignItems="top" justifyContent='center'>

                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                    <Box className='wh_bx'>
                                        <Box mb={"0px"}>
                                            <Typography variant='h5' className='fw500 bl'> SIP Details </Typography>
                                        </Box>

                                        <Box className='brd1' mb={2}></Box>

                                        <Box id='purchase_card' className='grybx'>
                                            <Box className='al_center'>
                                                <img alt="Logo" src={ABSL} className="logo_img_md" />
                                            </Box>

                                            <Box className='card_title' mt={2} mb={'5px'}>
                                                <Typography variant='h5' className='bl' > Aditya Birla SL India Opportunities Fund(G) </Typography>
                                            </Box>





                                            <Divider className='divider1' />

                                            <Box>
                                                <TableContainer  >
                                                    <Table aria-label="simple table">
                                                        <TableBody>
                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> Scheme Name </TableCell>
                                                                <TableCell align="left" className='col3'> SIP </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> Amount </TableCell>
                                                                <TableCell align="left" className='col3'> 764 </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> Next installment Date </TableCell>
                                                                <TableCell align="left" className='col3'> 10-05-2025 </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> Order ID </TableCell>
                                                                <TableCell align="left" className='col3'> 372355595 </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> Folio Number </TableCell>
                                                                <TableCell align="left" className='col3'> 1042377506 </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> Goal </TableCell>
                                                                <TableCell align="left" className='col3'> Retirement Savings </TableCell>
                                                            </TableRow>

                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                                <Divider className='divider1' />
                                            </Box>


                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                    <Box className='wh_bx'>
                                        <Box mb={"0px"}>
                                            <Typography variant='h5' className='fw500 bl'> Payment & Other Events </Typography>
                                        </Box>

                                        <Box className='brd1' mb={2}></Box>

                                        <Box id='purchase_card' className='grybx'>
                                            <Box className='al_center'>
                                                <img alt="Logo" src={EMI} className="logo_img_md" />
                                            </Box>

                                            {/* <Box className='card_title' mt={1}>
<Typography variant='h5' className='bl' > Aditya Birla SL India Opportunities Fund(G) </Typography>
</Box> */}





                                            <Divider className='divider1' />

                                            <Box>
                                                <TableContainer  >
                                                    <Table aria-label="simple table">
                                                        <TableBody>
                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> 1<sup>st</sup> installment </TableCell>
                                                                <TableCell align="left" className='col3'> Paid </TableCell>
                                                                <TableCell align="left" className='col3'>  <CheckCircleIcon className='green' />  </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> 2<sup>nd</sup> installment </TableCell>
                                                                <TableCell align="left" className='col3'> Paid </TableCell>
                                                                <TableCell align="left" className='col3'>  <CheckCircleIcon className='green' />  </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> 3<sup>rd</sup> installment </TableCell>
                                                                <TableCell align="left" className='col3'> Failed </TableCell>
                                                                <TableCell align="left" className='col3'> <CancelIcon className='red' /> </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> Edit SIP Amount & date </TableCell>
                                                                <TableCell align="left" className='col3'> Completed </TableCell>
                                                                <TableCell align="left" className='col3'>  <DoneAllIcon className='col1' />  </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> 4<sup>th</sup> installment </TableCell>
                                                                <TableCell align="left" className='col3'> Paid </TableCell>
                                                                <TableCell align="left" className='col3'>  <CheckCircleIcon className='green' />  </TableCell>
                                                            </TableRow>

                                                            <TableRow >
                                                                <TableCell component="th" className='col1'> 5<sup>th</sup>  installment </TableCell>
                                                                <TableCell align="left" className='col3'> Upcoming in 5 days </TableCell>
                                                                <TableCell align="left" className='col3'>  <WatchLaterIcon className='yellow' />  </TableCell>
                                                            </TableRow>

                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                                <Divider className='divider1' />
                                            </Box>


                                        </Box>
                                    </Box>
                                </Grid>


                            </Grid>

                        </Box>

                        <Grid container spacing={3} alignItems="top" justifyContent='center'>

                            <Grid item lg={8} md={12} sm={12} xs={12}>
                                <Box className='bt al_right'>
                                    <Link to="/purchase_cards" className='link'>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                    </Link>
                                </Box>
                            </Grid>
                        </Grid>


                    </Box>
                </Container>
            </Box>




        </>
    );
}
