import React from 'react';
import { Box, Container, Grid, List, ListItem, ListItemText, Button, Typography, Divider, IconButton, Tooltip } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import { Link } from 'react-router-dom';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow'; 
 
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import UTI from "../../asset/images/Logos/uti.png"


import Carousel from "react-elastic-carousel";
import GetAppIcon from '@material-ui/icons/GetApp';


const breakPoints = [
    { width: 100, itemsToShow: 1 },
    { width: 360, itemsToShow: 1, itemsToScroll: 1 },
    { width: 460, itemsToShow: 2, itemsToScroll: 1 },
    { width: 550, itemsToShow: 2, itemsToScroll: 2 },
    { width: 600, itemsToShow: 3, itemsToScroll: 2 },
    { width: 1050, itemsToShow: 4, itemsToScroll: 2 },
    { width: 1200, itemsToShow: 4, itemsToScroll: 3 }
];

export default function TM_Cancelled_SIP_Cards() {

    return (
        <>


            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>
                            <Grid container spacing={1} alignItems="center">

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='brd1 flx_sa p0' mb={2}>
                                        <Box>
                                            <Typography variant='h5' className=' bl' > Cancelled SIP Details </Typography>
                                        </Box>
                                        <Box className='al_right'>
                                            <IconButton color='primary' component="span">
                                                <Tooltip title="Download Transaction History" aria-label="add">
                                                    <GetAppIcon className='smicobtn' />
                                                </Tooltip>
                                            </IconButton>
                                        </Box>
                                    </Box>
                                </Grid>



                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Grid container spacing={2} alignItems="center">


                                        <Carousel breakPoints={breakPoints}>

                                            <Grid item>

                                                <Box id='purchase_card' className='grybx'>
                                                    <Box className='al_center'>
                                                        <img alt="Logo" src={UTI} className="logo_img_md" />
                                                    </Box>

                                                    <Box className='card_title' mt={1}>
                                                        <Typography variant='h6' className='bl' > UTI NIFTY Index Fund Regular Plan </Typography>
                                                    </Box>

                                                    <Divider className='divider1' />
                                                    <Grid container
                                                        direction="row"
                                                        justifyContent="center"
                                                        alignItems="center"
                                                        spacing={3}
                                                    >
                                                        <Grid item >
                                                            <List>
                                                                <ListItem>
                                                                    <ListItemText primary="Client Name" secondary="XYZ" />
                                                                </ListItem>
                                                            </List>
                                                        </Grid>

                                                        <Grid item  >
                                                            <List>
                                                                <ListItem>
                                                                    <ListItemText primary="Client ID" secondary="1234" />
                                                                </ListItem>
                                                            </List>
                                                        </Grid>
                                                    </Grid>
                                                    <Divider className='divider1' />

                                                    <Box>
                                                        <TableContainer  >
                                                            <Table aria-label="simple table">
                                                                <TableBody>
                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Units </TableCell>
                                                                        <TableCell align="left" className='col3'> 23.77100187 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Amount </TableCell>
                                                                        <TableCell align="left" className='col3'> 764 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'>  Fund Name</TableCell>
                                                                        <TableCell align="left" className='col3'> NFO </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Type </TableCell>
                                                                        <TableCell align="left" className='col3'> SIP </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> SIP Registration No. </TableCell>
                                                                        <TableCell align="left" className='col3'> 37595641 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> No. of Installment </TableCell>
                                                                        <TableCell align="left" className='col3'> 12 </TableCell>
                                                                    </TableRow>

                                                                </TableBody>
                                                            </Table>
                                                        </TableContainer>
                                                        <Divider className='divider1' />
                                                    </Box>


                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='bt al_center'>
                                                            <Link to='/tm_proceed_cancellation' className='link'>
                                                                <Button variant="contained" className='btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Proceed Cancellation </Button>
                                                            </Link>
                                                        </Box>
                                                    </Grid>


                                                </Box>

                                            </Grid>

                                            <Grid item>
                                                <Box id='purchase_card' className='grybx'>
                                                    <Box className='al_center'>
                                                        <img alt="Logo" src={UTI} className="logo_img_md" />
                                                    </Box>

                                                    <Box className='card_title' mt={1}>
                                                        <Typography variant='h6' className='bl' > UTI NIFTY Index Fund Regular Plan </Typography>
                                                    </Box>

                                                    <Divider className='divider1' />
                                                    <Grid container
                                                        direction="row"
                                                        justifyContent="center"
                                                        alignItems="center"
                                                        spacing={3}
                                                    >
                                                        <Grid item >
                                                            <List>
                                                                <ListItem>
                                                                    <ListItemText primary="Client Name" secondary="XYZ" />
                                                                </ListItem>
                                                            </List>
                                                        </Grid>

                                                        <Grid item  >
                                                            <List>
                                                                <ListItem>
                                                                    <ListItemText primary="Client ID" secondary="1234" />
                                                                </ListItem>
                                                            </List>
                                                        </Grid>
                                                    </Grid>
                                                    <Divider className='divider1' />

                                                    <Box>
                                                        <TableContainer  >
                                                            <Table aria-label="simple table">
                                                                <TableBody>
                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Units </TableCell>
                                                                        <TableCell align="left" className='col3'> 23.77100187 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Amount </TableCell>
                                                                        <TableCell align="left" className='col3'> 764 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'>  Fund Name</TableCell>
                                                                        <TableCell align="left" className='col3'> NFO </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Type </TableCell>
                                                                        <TableCell align="left" className='col3'> SIP </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> SIP Registration No. </TableCell>
                                                                        <TableCell align="left" className='col3'> 37595641 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> No. of Installment </TableCell>
                                                                        <TableCell align="left" className='col3'> 12 </TableCell>
                                                                    </TableRow>

                                                                </TableBody>
                                                            </Table>
                                                        </TableContainer>
                                                        <Divider className='divider1' />
                                                    </Box>


                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='bt al_center'>
                                                            <Link to='/tm_proceed_cancellation' className='link'>
                                                                <Button variant="contained" className='btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Proceed Cancellation </Button>
                                                            </Link>
                                                        </Box>
                                                    </Grid>


                                                </Box>
                                            </Grid>





                                        </Carousel>


                                    </Grid>







                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='bt al_right'>
                                            <Link to="/tm_purchase_history" className='link'>
                                                <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                            </Link>
                                        </Box>
                                    </Grid>

                                </Grid>





                            </Grid>
                        </Box>



                    </Box>
                </Container>
            </Box>




        </>
    );
}
