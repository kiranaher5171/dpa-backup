import React from 'react';
import { Box, Container, Grid, List, ListItem, ListItemText, Button, Typography, Divider, IconButton, Tooltip } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import { Link } from 'react-router-dom';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import CancelIcon from '@material-ui/icons/Cancel';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';

import ABSL from "../../asset/images/Logos/aditya_birla.png"
import ICICI from "../../asset/images/Logos/icici_fund.png"
import HDFC from "../../asset/images/Logos/hdfc_fund2.png"
import INVE from "../../asset/images/Logos/invesco2.png"

import Carousel from "react-elastic-carousel";
import GetAppIcon from '@material-ui/icons/GetApp';


const breakPoints = [
    { width: 100, itemsToShow: 1 },
    { width: 360, itemsToShow: 1, itemsToScroll: 1 },
    { width: 460, itemsToShow: 2, itemsToScroll: 1 },
    { width: 550, itemsToShow: 2, itemsToScroll: 2 },
    { width: 600, itemsToShow: 3, itemsToScroll: 2 },
    { width: 1050, itemsToShow: 4, itemsToScroll: 2 },
    { width: 1200, itemsToShow: 4, itemsToScroll: 3 }
];



export default function Purchase_Cards() {

    return (
        <>


            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={1}>
                            <Grid container spacing={1} alignItems="center">



                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='brd1 flx_sa p0' mb={0}>
                                        <Box>
                                            <Typography variant='h5' className=' bl' > Transaction History </Typography>
                                        </Box>
                                        <Box className='al_right'>
                                            <IconButton color='primary' component="span">
                                                <Tooltip title="Download Transaction History" aria-label="add">
                                                    <GetAppIcon className='smicobtn' />
                                                </Tooltip>
                                            </IconButton>
                                        </Box>
                                    </Box>
                                </Grid>



                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Grid container spacing={2} alignItems="center">

                                        <Carousel breakPoints={breakPoints}>

                                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                                <Link to='/purchase_details' >
                                                    <Box id='purchase_card' className='grybx'>
                                                        <Box className='al_center'>
                                                            <img alt="Logo" src={ABSL} className="logo_img_md" />
                                                        </Box>

                                                        <Box className='card_title'>
                                                            <Typography variant='h6' className='bl' > Aditya Birla SL India Opportunities Fund(G) </Typography>
                                                        </Box>

                                                        <Divider className='divider1' />
                                                        <Grid container
                                                            direction="row"
                                                            justifyContent="center"
                                                            alignItems="center"
                                                            spacing={3}
                                                        >
                                                            <Grid item >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client Name" secondary="XYZ" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>

                                                            <Grid item  >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client ID" secondary="1234" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>
                                                        </Grid>
                                                        <Divider className='divider1' />

                                                        <Box>
                                                            <TableContainer  >
                                                                <Table aria-label="simple table">
                                                                    <TableBody>
                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Units </TableCell>
                                                                            <TableCell align="left" className='col3'> 23.77100187 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Amount </TableCell>
                                                                            <TableCell align="left" className='col3'> 764 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Goal/ Fund </TableCell>
                                                                            <TableCell align="left" className='col3'> Retirement Savings </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Type </TableCell>
                                                                            <TableCell align="left" className='col3'> SIP </TableCell>
                                                                        </TableRow>

                                                                    </TableBody>
                                                                </Table>
                                                            </TableContainer>
                                                            <Divider className='divider1' />
                                                        </Box>


                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Comment" secondary="Comment Here..." />
                                                                    </ListItem>
                                                                </List>

                                                            </Box>
                                                        </Grid>

                                                        <Divider className='divider1' />

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <IconButton size='large'>
                                                                    <CheckCircleIcon className='green' />
                                                                </IconButton>
                                                            </Box>
                                                        </Grid>


                                                    </Box>
                                                </Link>
                                            </Grid>

                                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                                <Link to='/purchase_details' >
                                                    <Box id='purchase_card' className='grybx'>
                                                        <Box className='al_center'>
                                                            <img alt="Logo" src={ICICI} className="logo_img_md" />
                                                        </Box>

                                                        <Box className='card_title'>
                                                            <Typography variant='h6' className='bl' > ICICI Prudential Infrastructure Fund - Growth </Typography>
                                                        </Box>

                                                        <Divider className='divider1' />
                                                        <Grid container
                                                            direction="row"
                                                            justifyContent="center"
                                                            alignItems="center"
                                                            spacing={3}
                                                        >
                                                            <Grid item >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client Name" secondary="XYZ" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>

                                                            <Grid item  >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client ID" secondary="1234" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>
                                                        </Grid>
                                                        <Divider className='divider1' />

                                                        <Box>
                                                            <TableContainer  >
                                                                <Table aria-label="simple table">
                                                                    <TableBody>
                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Units </TableCell>
                                                                            <TableCell align="left" className='col3'> 23.77100187 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Amount </TableCell>
                                                                            <TableCell align="left" className='col3'> 764 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Goal/ Fund </TableCell>
                                                                            <TableCell align="left" className='col3'> Retirement Savings </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Type </TableCell>
                                                                            <TableCell align="left" className='col3'> SIP </TableCell>
                                                                        </TableRow>

                                                                    </TableBody>
                                                                </Table>
                                                            </TableContainer>
                                                            <Divider className='divider1' />
                                                        </Box>


                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Comment" secondary="Comment Here..." />
                                                                    </ListItem>
                                                                </List>

                                                            </Box>
                                                        </Grid>

                                                        <Divider className='divider1' />

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <IconButton size='large'>
                                                                    <CheckCircleIcon className='green' />
                                                                </IconButton>
                                                            </Box>
                                                        </Grid>


                                                    </Box>
                                                </Link>
                                            </Grid>

                                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                                <Link to='/purchase_details' >
                                                    <Box id='purchase_card' className='grybx'>
                                                        <Box className='al_center'>
                                                            <img alt="Logo" src={HDFC} className="logo_img_md" />
                                                        </Box>

                                                        <Box className='card_title'>
                                                            <Typography variant='h6' className='bl' > HDFC Infrastructure Fund - Growth </Typography>
                                                        </Box>

                                                        <Divider className='divider1' />
                                                        <Grid container
                                                            direction="row"
                                                            justifyContent="center"
                                                            alignItems="center"
                                                            spacing={3}
                                                        >
                                                            <Grid item >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client Name" secondary="XYZ" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>

                                                            <Grid item  >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client ID" secondary="1234" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>
                                                        </Grid>
                                                        <Divider className='divider1' />

                                                        <Box>
                                                            <TableContainer  >
                                                                <Table aria-label="simple table">
                                                                    <TableBody>
                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Units </TableCell>
                                                                            <TableCell align="left" className='col3'> 23.77100187 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Amount </TableCell>
                                                                            <TableCell align="left" className='col3'> 764 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Goal/ Fund </TableCell>
                                                                            <TableCell align="left" className='col3'> Retirement Savings </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Type </TableCell>
                                                                            <TableCell align="left" className='col3'> SIP </TableCell>
                                                                        </TableRow>

                                                                    </TableBody>
                                                                </Table>
                                                            </TableContainer>
                                                            <Divider className='divider1' />
                                                        </Box>


                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Comment" secondary="Comment Here..." />
                                                                    </ListItem>
                                                                </List>

                                                            </Box>
                                                        </Grid>

                                                        <Divider className='divider1' />

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <IconButton size='large'>
                                                                    <CheckCircleIcon className='green' />
                                                                </IconButton>
                                                            </Box>
                                                        </Grid>


                                                    </Box>
                                                </Link>
                                            </Grid>

                                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                                <Link to='/purchase_details' >
                                                    <Box id='purchase_card' className='grybx'>
                                                        <Box className='al_center'>
                                                            <img alt="Logo" src={INVE} className="logo_img_md" />
                                                        </Box>

                                                        <Box className='card_title'>
                                                            <Typography variant='h6' className='bl' > Invesco India PSU Equity Fund - Growth </Typography>
                                                        </Box>

                                                        <Divider className='divider1' />
                                                        <Grid container
                                                            direction="row"
                                                            justifyContent="center"
                                                            alignItems="center"
                                                            spacing={3}
                                                        >
                                                            <Grid item >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client Name" secondary="XYZ" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>

                                                            <Grid item  >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Client ID" secondary="1234" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>
                                                        </Grid>
                                                        <Divider className='divider1' />

                                                        <Box>
                                                            <TableContainer  >
                                                                <Table aria-label="simple table">
                                                                    <TableBody>
                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Units </TableCell>
                                                                            <TableCell align="left" className='col3'> 23.77100187 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Amount </TableCell>
                                                                            <TableCell align="left" className='col3'> 764 </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Goal/ Fund </TableCell>
                                                                            <TableCell align="left" className='col3'> Retirement Savings </TableCell>
                                                                        </TableRow>

                                                                        <TableRow >
                                                                            <TableCell component="th" className='col1'> Type </TableCell>
                                                                            <TableCell align="left" className='col3'> SIP </TableCell>
                                                                        </TableRow>

                                                                    </TableBody>
                                                                </Table>
                                                            </TableContainer>
                                                            <Divider className='divider1' />
                                                        </Box>


                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Comment" secondary="Comment Here..." />
                                                                    </ListItem>
                                                                </List>

                                                            </Box>
                                                        </Grid>

                                                        <Divider className='divider1' />

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='al_center'>
                                                                <IconButton size='large'>
                                                                    <CancelIcon className='red' />
                                                                </IconButton>
                                                            </Box>
                                                        </Grid>


                                                    </Box>
                                                </Link>
                                            </Grid>



                                        </Carousel>

                                    </Grid>


  
                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='bt al_right'>
                                            <Link to="/tm_purchase_history" className='link'>
                                                <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                            </Link>
                                        </Box>
                                    </Grid>

                                </Grid>
 


                            </Grid>
                        </Box>



                    </Box>
                </Container>
            </Box>




        </>
    );
}
