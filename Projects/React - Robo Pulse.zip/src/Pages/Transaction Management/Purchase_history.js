import React from 'react';
import {Container,  Box, Grid, Button, Typography, TextField, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { Link } from 'react-router-dom';


const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]

export default function TM_Purchase_History() {

    return (
        <>
        
      <Box component="section"  className='codingpagestart'>
        <Container className='containerwidth'>


            <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='brd1 flx_sa p0' >
                            <Box pb={1}>
                                <Typography variant='h5' className=' bl' > Purchase History </Typography>
                            </Box>

                        </Box>
                    </Grid>



                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Select CM" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Select ZM" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Select SM" variant="filled" />}
                            />
                        </Box>
                    </Grid>




                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Select DM" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Select BM" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Select RM" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Select Agent" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                   

                </Grid>
            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Link to="/purchase_cards">
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small'  >Search Result </Button>
                </Box>
                </Link>
            </Grid>


            </Container>
        </Box>
        </>
    );
}
