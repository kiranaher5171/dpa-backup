import React from 'react';
import { Box, Grid, Button, Typography, TextField, Divider, IconButton, Tooltip} from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';


import Autocomplete from '@material-ui/lab/Autocomplete';
 
import CreateIcon from '@material-ui/icons/Create';

const chooseopt = [
    { title: 'Applicable' },
    { title: 'Not Applicable' },
]

const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]





export default function Investor_Profile_FATCA() {



    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState(new Date());

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    return (
        <>

<Box className='wh_bx' pb={2}>
                                <Grid container spacing={1} alignItems="top">

                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='brd1 flx_sa p0' >
                                            <Box>
                                                <Typography variant='h5' className=' bl' > FATCA </Typography>
                                            </Box>
                                           
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="PAN / PEKRN" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='datepic'>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="MM/dd/yyyy"
                                                    id="date-picker-inline"
                                                    placeholder="Commencement Date"
                                                    value={selectedDate}
                                                    onChange={handleDateChange}
                                                    KeyboardButtonProps={{
                                                        'aria-label': 'change date',
                                                    }}
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Address Type" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Data Source" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Individual / Non-Individual" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Tax Status" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Country of Birth" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Residential Country" fullWidth />
                                        </Box>
                                    </Grid>
                                    
                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Occupation Type" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                       <Box className='textfield' >
                                            <Autocomplete
                                                id="combo-box-demo"
                                                options={Random_Opt}
                                                getOptionLabel={(option) => option.title}
                                                renderInput={(params) => <TextField {...params} label="Wealth Source" variant="filled" />}
                                            />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Income Slab" fullWidth />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='alltxfield'>
                                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Identification Doc Type" fullWidth />
                                        </Box>
                                    </Grid>


                                </Grid>
                            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
            </Grid>



        </>
    );
}
