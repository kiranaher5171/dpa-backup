import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Typography, FormLabel, RadioGroup, AppBar, FormControlLabel, Radio, Tabs, Tab, Button, Grid, TextField, Tooltip, FormControl, InputLabel, IconButton, Select, MenuItem, Divider, List, ListItem, ListItemText, ListItemAvatar, Avatar, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward'; 

import { Link } from 'react-router-dom';

import ArrowBackIcon from '@material-ui/icons/ArrowBack';
 
  
import A1 from "../../asset/images/riskquestion/q5_1a.svg";
import A2 from "../../asset/images/riskquestion/q5_2a.svg";
import A3 from "../../asset/images/riskquestion/q5_3a.svg";
import A4 from "../../asset/images/riskquestion/q5_4a.svg";
import A5 from "../../asset/images/riskquestion/q5_5a.svg";
 
import B1 from "../../asset/images/riskquestion/q5_1b.svg";
import B2 from "../../asset/images/riskquestion/q5_2b.svg";
import B3 from "../../asset/images/riskquestion/q5_3b.svg";
import B4 from "../../asset/images/riskquestion/q5_4b.svg";
import B5 from "../../asset/images/riskquestion/q5_5b.svg";

export default function Investor_Risk_Profile_5() {
 

  return (
    <>

  


      <Box component="section"  className='tabbedinfo codingpagestart'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

         
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">


                  <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className= "al_center brd1" >
                                          <Box mb={1}>
                                                <Typography variant='h5' className=' bl' >My current and future income source (example: salary, business income, investment income etc)are: </Typography>
                                          </Box>
                                        </Box>
                                    </Grid>


                <Box className="options_box" pb={5} pt={5}>
<RadioGroup row aria-label="position" name="position" defaultValue="top">           

<Grid container spacing={1} alignItems="center" justifyContent='center'>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ A1 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ B1 } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Stongly Agree"
control={<Radio color="primary" />}
label="Stongly Agree"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ A2 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ B2 } width={100} alt="fliper" /></p>
</Box>
</div>
<FormControlLabel
value="Agree"
control={<Radio color="primary" />}
label="Agree"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ A3 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ B3 } width={100}  alt="fliper" /></p>
</Box>
</div>
<FormControlLabel
value="Neither Agree nor Disagree"
control={<Radio color="primary" />}
label="Neither Agree nor Disagree"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ A4 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ B4 } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Disagree"
control={<Radio color="primary" />}
label="Disagree"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ A5 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ B5 } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Strongly Disagree"
control={<Radio color="primary" />}
label="Strongly Disagree"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

</Grid>
 

</RadioGroup>   
</Box>

<Grid item lg={12} md={12} sm={12} xs={12}>
  <Box className='brd1'></Box>
</Grid>



<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='bt al_right' mt={1}>
<Link to="/investor_risk_profile_4">
<Button variant="contained" className='al_center btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
</Link>
<Link to="/investor_risk_profile_6">
<Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
</Link>
</Box>
</Grid>

                </Grid>
              </Box>

 





          </Box>
        </Container>
      </Box>




    </>
  );
}
