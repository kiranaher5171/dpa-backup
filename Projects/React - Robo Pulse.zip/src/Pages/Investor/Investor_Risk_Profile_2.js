import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Typography, FormLabel, RadioGroup, AppBar, FormControlLabel, Radio, Tabs, Tab, Button, Grid, TextField, Tooltip, FormControl, InputLabel, IconButton, Select, MenuItem, Divider, List, ListItem, ListItemText, ListItemAvatar, Avatar, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward'; 

import { Link } from 'react-router-dom';

import ArrowBackIcon from '@material-ui/icons/ArrowBack';
 
  
import r2a from "../../asset/images/riskquestion/rq_2a.svg";
import nom1 from "../../asset/images/riskquestion/nominee.svg";
import q2_1 from "../../asset/images/riskquestion/q2_1a.svg";
import q2_2 from "../../asset/images/riskquestion/q2_2a.svg";
import q2_4a from "../../asset/images/riskquestion/q2_4a.svg";
 
import r2b from "../../asset/images/riskquestion/rq_2b.svg";
import nom2 from "../../asset/images/riskquestion/nominee2.svg";
import q2_1b from "../../asset/images/riskquestion/q2_1b.svg";
import q2_2b from "../../asset/images/riskquestion/q2_2b.svg";
import q2_4b from "../../asset/images/riskquestion/q2_4b.svg";

export default function Investor_Risk_Profile_2() {
 

  return (
    <>

  


      <Box component="section"  className='tabbedinfo codingpagestart'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

         
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">


                  <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className= "al_center brd1" >
                                          <Box mb={1}>
                                                <Typography variant='h5' className=' bl' > Would you prefer to run your own business or be a salaried employee ? </Typography>
                                          </Box>
                                        </Box>
                                    </Grid>


                <Box className="options_box" pb={5} pt={5}>
<RadioGroup row aria-label="position" name="position" defaultValue="top">           

<Grid container spacing={1} alignItems="center" justifyContent='center'>


<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ q2_1 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ q2_1b } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Being a salaried employee"
control={<Radio color="primary" />}
label="Being a salaried employee"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ r2a } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ r2b } width={100} alt="fliper" /></p>
</Box>
</div>
<FormControlLabel
value="Salaried employee"
control={<Radio color="primary" />}
label="Salaried employee while running a part-time business"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ q2_2 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ q2_2b } width={100}  alt="fliper" /></p>
</Box>
</div>
<FormControlLabel
value="Salaried employee with huge investments in stock"
control={<Radio color="primary" />}
label="Salaried employee with huge investments in stock"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ q2_4a } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ q2_4b } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Running a partnership business"
control={<Radio color="primary" />}
label="Running a partnership business"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ nom1 } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ nom2 } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Running my own business"
control={<Radio color="primary" />}
label="Running my own business"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>


</Grid>

 


</RadioGroup>   
</Box>

<Grid item lg={12} md={12} sm={12} xs={12}>
  <Box className='brd1'></Box>
</Grid>



<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='bt al_right' mt={1}>
<Link to="/investor_risk_profile_1">
<Button variant="contained" className='al_center btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
</Link>
<Link to="/investor_risk_profile_3">
<Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
</Link>
</Box>

</Grid>

                </Grid>
              </Box>

 





          </Box>
        </Container>
      </Box>




    </>
  );
}
