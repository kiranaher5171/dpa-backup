import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Typography, FormLabel, RadioGroup, AppBar, FormControlLabel, Radio, Tabs, Tab, Button, Grid, TextField, Tooltip, FormControl, InputLabel, IconButton, Select, MenuItem, Divider, List, ListItem, ListItemText, ListItemAvatar, Avatar, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import InputAdornment from '@material-ui/core/InputAdornment';
import CreateIcon from '@material-ui/icons/Create';
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import CancelOutlinedIcon from '@material-ui/icons/CancelOutlined';
import { Link } from 'react-router-dom';
import Autocomplete from '@material-ui/lab/Autocomplete';


import r1a from "../../asset/images/riskquestion/rq_1a.svg";
import r2a from "../../asset/images/riskquestion/rq_2a.svg";
import r3a from "../../asset/images/riskquestion/rq_3a.svg";
import r4a from "../../asset/images/riskquestion/rq_4a.svg";
import r5a from "../../asset/images/riskquestion/rq_5a.svg";

import r1b from "../../asset/images/riskquestion/rq_1b.svg";
import r2b from "../../asset/images/riskquestion/rq_2b.svg";
import r3b from "../../asset/images/riskquestion/rq_3b.svg";
import r4b from "../../asset/images/riskquestion/rq_4b.svg";
import r5b from "../../asset/images/riskquestion/rq_5b.svg";



const chooseopt = [
  { title: 'Applicable' },
  { title: 'Not Applicable' },
]

const ISD = [
  { title: '+91' },
  { title: '+94' },
  { title: '+99' },
  { title: '+78' },
  { title: '+67' },
  { title: '+55' },
]

const City = [
  { title: 'Nashik' },
  { title: 'Mumbai' },
  { title: 'GIFT City' },
  { title: 'Nagpur' },
  { title: 'Chennai' },
  { title: 'Banglore' },
]


function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
  };
}





export default function Investor_Risk_Profile_1() {

  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };


  // Datepicker
  const [selectedDate, setSelectedDate] = React.useState(new Date());
  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
  // Datepicker



  return (
    <>




      <Box component="section" className='tabbedinfo codingpagestart'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>


            <Box className='wh_bx' pb={2}>
              <Grid container spacing={1} alignItems="top">


                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className="al_center brd1" >
                    <Box mb={1}>
                      <Typography variant='h5' className=' bl' > Whats Your Age ? </Typography>
                    </Box>
                  </Box>
                </Grid>



                <Box className="options_box" pb={5} pt={5}>
                  <RadioGroup row aria-label="position" name="position" defaultValue="top">


                    <Grid container spacing={1} alignItems="center" justifyContent='center'>


                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className="option_box1 al_center">
                          <Box class="flip-container" for="radio1">
                            <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
                              <Box class="flipper">
                                <p align="center"><img src={r1a} className='front' width={100} alt="fliper" /></p>
                                <p align="center" className='back'><img src={r1b} width={100} alt="fliper" /></p>
                              </Box>
                            </div>
                            <FormControlLabel
                              value="30 and below"
                              control={<Radio color="primary" />}
                              label="30 and below"
                              labelPlacement="bottom"
                            />
                          </Box>
                        </Box>
                      </Grid>


                      <Grid item lg={2} md={4} sm={6} xs={12}> 
                        <Box className="option_box1 al_center">
                          <Box class="flip-container" for="radio1">
                            <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
                              <Box class="flipper">
                                <p align="center"><img src={r2a} className='front' width={100} alt="fliper" /></p>
                                <p align="center" className='back'><img src={r2b} width={100} alt="fliper" /></p>
                              </Box>
                            </div>
                            <FormControlLabel
                              value="31-40"
                              control={<Radio color="primary" />}
                              label="31-40"
                              labelPlacement="bottom"
                            />
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className="option_box1 al_center">
                          <Box class="flip-container" for="radio1">
                            <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
                              <Box class="flipper">
                                <p align="center"><img src={r3a} className='front' width={100} alt="fliper" /></p>
                                <p align="center" className='back'><img src={r3b} width={100} alt="fliper" /></p>
                              </Box>
                            </div>
                            <FormControlLabel
                              value="41-50"
                              control={<Radio color="primary" />}
                              label="41-50"
                              labelPlacement="bottom"
                            />
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className="option_box1 al_center">
                          <Box class="flip-container" for="radio1">
                            <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
                              <Box class="flipper">
                                <p align="center"><img src={r4a} className='front' width={100} alt="fliper" /></p>
                                <p align="center" className='back'><img src={r4b} width={100} alt="fliper" /></p>
                              </Box>
                            </div>
                            <FormControlLabel
                              value="51-60"
                              control={<Radio color="primary" />}
                              label="51-60"
                              labelPlacement="bottom"
                            />
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>

                        <Box className="option_box1 al_center">
                          <Box class="flip-container" for="radio1">
                            <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
                              <Box class="flipper">
                                <p align="center"><img src={r5a} className='front' width={100} alt="fliper" /></p>
                                <p align="center" className='back'><img src={r5b} width={100} alt="fliper" /></p>
                              </Box>
                            </div>
                            <FormControlLabel
                              value="above 60"
                              control={<Radio color="primary" />}
                              label="Above 60"
                              labelPlacement="bottom"
                            />
                          </Box>
                        </Box>

                      </Grid>


                    </Grid>




                  </RadioGroup>
                </Box>

                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className='brd1'></Box>
                </Grid>



                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className='bt al_right' mt={1}>
                    <Link to="/investor_risk_profile_2">
                      <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
                    </Link>
                  </Box>
                </Grid>

              </Grid>
            </Box>







          </Box>
        </Container>
      </Box>




    </>
  );
}
