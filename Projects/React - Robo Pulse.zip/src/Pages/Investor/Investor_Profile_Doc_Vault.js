import React from 'react';
import { Box, Grid, Button, Typography, TextField, Divider, IconButton, Tooltip} from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';


import Autocomplete from '@material-ui/lab/Autocomplete';
 
import CreateIcon from '@material-ui/icons/Create';

const chooseopt = [
    { title: 'Applicable' },
    { title: 'Not Applicable' },
]

const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]





export default function Investor_Profile_Doc_Vault() {



    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState(new Date());

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    return (
        <>

<Box className='wh_bx' pb={2}>
                                <Grid container spacing={1} alignItems="top">

                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='brd1 flx_sa p0' >
                                            <Box>
                                                <Typography variant='h5' className=' bl' > Document Vault </Typography>
                                            </Box>
                                           
                                        </Box>
                                    </Grid>
 
 

                                    <Grid item lg={3} md={4} sm={6} xs={12}>
                                        <Box className='flx_sa'>
                                            <Typography variant='h6' className='bl '>AOF</Typography>
                                            <Typography variant='' className='smcontent'> Updated On: Jan 9, 2025 </Typography>
                                        </Box>
                                        <Box className='uploadfile'>
                                            <input type="file" class="input-file" />
                                        </Box>

                                    </Grid>

 
                                    

                                </Grid>
                            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
            </Grid>



        </>
    );
}
