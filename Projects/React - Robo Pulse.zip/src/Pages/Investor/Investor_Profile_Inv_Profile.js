import React from 'react';
import { Box, Grid, Button, Typography, TextField, Divider, IconButton, Tooltip} from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';


import Autocomplete from '@material-ui/lab/Autocomplete';
import SaveOutlinedIcon from '@material-ui/icons/SaveOutlined';
import CreateIcon from '@material-ui/icons/Create';
import CIBIL from "../../asset/images/Logos/cibil.gif"



const chooseopt = [
    { title: 'Applicable' },
    { title: 'Not Applicable' },
]

const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]




export default function Investor_Profile_Inv_Profile() {



    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState(new Date());

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    return (
        <>

<Box className='wh_bx' pb={2}>
                                <Grid container spacing={1} alignItems="top" justifyContent='center'>

                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='brd1 flx_sa p0' >
                                            <Box>
                                                <Typography variant='h5' className=' bl' > Investor Details </Typography>
                                            </Box>
                                           
                                        </Box>
                                    </Grid>

                                    <Grid item lg={8} md={12} sm={12} xs={12}>

                                    <Box className='al_center'>
                                    <Typography variant='h5' className=' bl' gutterBottom > Your Investment Profile is </Typography> 
                                    {/* <Typography variant='h5' className='green' gutterBottom > GOOD </Typography>  */}
                                    </Box>


<Box className='al_center'>
<img alt="Logo" src={CIBIL} className="gif_md" />
</Box>


<Box className='al_center'> 
<Typography variant='h4' className='red' gutterBottom > AGGRESSIVE </Typography> 
</Box>


                                    </Grid>



                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_center' mt={1}>
                                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Change Your Investment Profile </Button>
                                    </Box>
                                    </Grid>
                                    
 
                                    

                                </Grid>
                            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<SaveOutlinedIcon />}> Save  </Button>
                </Box>
            </Grid>



        </>
    );
}
