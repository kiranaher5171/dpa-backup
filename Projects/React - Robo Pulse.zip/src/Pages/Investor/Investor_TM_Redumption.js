import React from 'react';
import { Box, Container, Grid, List, ListItem, ListItemText, Button, Typography, Divider, RadioGroup, Radio, FormControlLabel, } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import { Link } from 'react-router-dom';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';

import ABSL from "../../asset/images/Logos/aditya_birla.png"
import ICICI from "../../asset/images/Logos/icici_fund.png"
import HDFC from "../../asset/images/Logos/hdfc_fund2.png"
import INVE from "../../asset/images/Logos/invesco2.png"
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import Carousel from "react-elastic-carousel";


const breakPoints = [
    { width: 100, itemsToShow: 1 },
    { width: 360, itemsToShow: 1, itemsToScroll: 1 },
    { width: 460, itemsToShow: 2, itemsToScroll: 1 },
    { width: 550, itemsToShow: 2, itemsToScroll: 2 },
    { width: 600, itemsToShow: 3, itemsToScroll: 2 },
    { width: 1050, itemsToShow: 3, itemsToScroll: 2 },
    { width: 1200, itemsToShow: 4, itemsToScroll: 3 }
];

export default function Investor_TM_Redumption() {

    return (
        <>


            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx mainta bbedsection mb_n'  style={{paddingBottom:'55px'}}>

                        <Box className='wh_bx' pb={0}>
                            <Grid container spacing={1} alignItems="center">

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box mb={"0px"}>
                                        <Typography variant='h5' className='fw500 bl'> Investor Redumption </Typography>
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='brd1' mb={1}>
                                    </Box>
                                </Grid>



                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Grid container spacing={1} alignItems="center">


                                        <Carousel breakPoints={breakPoints}>

                                            <Grid item>
                                                <Box id='purchase_card' className='grybx'>
                                                    <Box className='al_center'>
                                                        <img alt="Logo" src={ABSL} className="logo_img_md" />
                                                    </Box>

                                                    <Box className='card_title' pt={2}>
                                                        <Typography variant='h6' className='bl' > Aditya Birla SL India Opportunities Fund(G) </Typography>
                                                    </Box>

                                                    <Divider className='divider1' />

                                                    <Box>
                                                        <TableContainer  >
                                                            <Table aria-label="simple table">
                                                                <TableBody>
                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Current NAV </TableCell>
                                                                        <TableCell align="left" className='col3'> 106.4 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Average NAV </TableCell>
                                                                        <TableCell align="left" className='col3'> 96.4 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Folio No. </TableCell>
                                                                        <TableCell align="left" className='col3'> 96123456978 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Balance Units </TableCell>
                                                                        <TableCell align="left" className='col3'> 104 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Money Invested </TableCell>
                                                                        <TableCell align="left" className='col3'> 100000 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Current Value of Investment </TableCell>
                                                                        <TableCell align="left" className='col3'> 121000 </TableCell>
                                                                    </TableRow>


                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Day change % </TableCell>
                                                                        <TableCell align="left" className='col3'> 5% </TableCell>
                                                                    </TableRow>


                                                                </TableBody>
                                                            </Table>
                                                        </TableContainer>
                                                        <Divider className='divider1' />
                                                    </Box>




                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='al_left' mt={"5px"} mb={'5px'}>
                                                            <Typography variant='h6' className='bl' >Redemption Option </Typography>
                                                        </Box>


                                                        <RadioGroup row aria-label="position" name="position" defaultValue="top">


                                                            <Grid
                                                                container
                                                                direction="row"
                                                                justifyContent="space-around"
                                                                alignItems="center">

                                                                <Grid item lg={5} md={6} sm={6} xs={6} className="pady4">
                                                                    <Box className="option_box1 al_left ">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="All Units"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="All Units"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>
                                                                <Grid item lg={5} md={6} sm={6} xs={6} className="pady4">
                                                                    <Box className="option_box1 al_left">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="Partial Units"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="Partial Units"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>
                                                                <Grid item lg={5} md={6} sm={6} xs={6} className=" ">
                                                                    <Box className="option_box1 al_left">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="All Amount"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="All Amount"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>
                                                                <Grid item lg={5} md={6} sm={6} xs={6} className=" ">
                                                                    <Box className="option_box1 al_left">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="Partial Amount"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="Partial Amount"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>

                                                            </Grid>

                                                        </RadioGroup>

                                                    </Grid>

                                                    <Divider className='divider1' />



                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Grid container
                                                            direction="row"
                                                            justifyContent="space-evenly"
                                                            alignItems="center"
                                                            spacing={3}
                                                        >
                                                            <Grid item >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Amount*" secondary="-" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>

                                                            <Grid item  >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Units*" secondary="6200.57" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>
                                                        </Grid>

                                                        <Divider className='divider1' />

                                                    </Grid>

                                                </Box>
                                            </Grid>

                                            <Grid item>
                                                <Box id='purchase_card' className='grybx'>
                                                    <Box className='al_center'>
                                                        <img alt="Logo" src={ICICI} className="logo_img_md" />
                                                    </Box>

                                                    <Box className='card_title' pt={2}>
                                                        <Typography variant='h6' className='bl' > ICICI Prudential Housing Opportunities Fund </Typography>
                                                    </Box>

                                                    <Divider className='divider1' />

                                                    <Box>
                                                        <TableContainer  >
                                                            <Table aria-label="simple table">
                                                                <TableBody>
                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Current NAV </TableCell>
                                                                        <TableCell align="left" className='col3'> 106.4 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Average NAV </TableCell>
                                                                        <TableCell align="left" className='col3'> 96.4 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Folio No. </TableCell>
                                                                        <TableCell align="left" className='col3'> 96123456978 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Balance Units </TableCell>
                                                                        <TableCell align="left" className='col3'> 104 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Money Invested </TableCell>
                                                                        <TableCell align="left" className='col3'> 100000 </TableCell>
                                                                    </TableRow>

                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Current Value of Investment </TableCell>
                                                                        <TableCell align="left" className='col3'> 121000 </TableCell>
                                                                    </TableRow>


                                                                    <TableRow >
                                                                        <TableCell component="th" className='col1'> Day change % </TableCell>
                                                                        <TableCell align="left" className='col3'> 5% </TableCell>
                                                                    </TableRow>


                                                                </TableBody>
                                                            </Table>
                                                        </TableContainer>
                                                        <Divider className='divider1' />
                                                    </Box>




                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Box className='al_left' mt={"5px"} mb={'5px'}>
                                                            <Typography variant='h6' className='bl' >Redemption Option </Typography>
                                                        </Box>


                                                        <RadioGroup row aria-label="position" name="position" defaultValue="top">


                                                            <Grid
                                                                container
                                                                direction="row"
                                                                justifyContent="space-around"
                                                                alignItems="center">

                                                                <Grid item lg={5} md={6} sm={6} xs={6} className="pady4">
                                                                    <Box className="option_box1 al_left ">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="All Units"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="All Units"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>
                                                                <Grid item lg={5} md={6} sm={6} xs={6} className="pady4">
                                                                    <Box className="option_box1 al_left">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="Partial Units"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="Partial Units"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>
                                                                <Grid item lg={5} md={6} sm={6} xs={6} className=" ">
                                                                    <Box className="option_box1 al_left">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="All Amount"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="All Amount"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>
                                                                <Grid item lg={5} md={6} sm={6} xs={6} className=" ">
                                                                    <Box className="option_box1 al_left">
                                                                        <Box class="flip-container" for="radio1">
                                                                            <FormControlLabel
                                                                                value="Partial Amount"
                                                                                control={<Radio color='primary' size='small' />}
                                                                                label="Partial Amount"
                                                                                labelPlacement="left"
                                                                            />
                                                                        </Box>
                                                                    </Box>
                                                                </Grid>

                                                            </Grid>

                                                        </RadioGroup>

                                                    </Grid>

                                                    <Divider className='divider1' />



                                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                                        <Grid container
                                                            direction="row"
                                                            justifyContent="space-evenly"
                                                            alignItems="center"
                                                            spacing={3}
                                                        >
                                                            <Grid item >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Amount*" secondary="-" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>

                                                            <Grid item  >
                                                                <List>
                                                                    <ListItem>
                                                                        <ListItemText primary="Units*" secondary="6200.57" />
                                                                    </ListItem>
                                                                </List>
                                                            </Grid>
                                                        </Grid>

                                                        <Divider className='divider1' />

                                                    </Grid>

                                                </Box>
                                            </Grid>





                                        </Carousel>


                                    </Grid>







                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='bt al_right'>

                                            <Button variant="contained" className='btn sk_bttn' size='small' endIcon={<ArrowForwardIcon />}> Execute Redemption </Button>

                                            <Button variant="contained" className='btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Send Redemption Request </Button>


                                        </Box>
                                    </Grid>

                                </Grid>





                            </Grid>
                        </Box>



                    </Box>
                </Container>
            </Box>




        </>
    );
}
