import React from 'react';
import PropTypes from 'prop-types';
import { Box,  Grid, AppBar, Tabs, Tab, Button, Typography,   TextField, Divider, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import Autocomplete from '@material-ui/lab/Autocomplete';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';


function TabPanel(props) {
    const { children, value, index, ...other } = props;
    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`scrollable-auto-tabpanel-${index}`}
            aria-labelledby={`scrollable-auto-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={0} pt={2} pb={0}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}



const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]





export default function Investor_Bank_Details() {


    const [value2, setValue2] = React.useState(0);
    const handleChange2 = (event, newValue) => {
        setValue2(newValue);
    };

        // Datepicker
        const [selectedDate, setSelectedDate] = React.useState(new Date());

        const handleDateChange = (date) => {
            setSelectedDate(date);
        };
        // Datepicker


    return (
        <>


<Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='brd1 flx_sa p0' >
                            <Box>
                                <Typography variant='h5' className=' bl' > Bank Details </Typography>
                            </Box>
                            
                        </Box>
                    </Grid>
                    </Grid>
                  
 

            <Box className='secondtabbedsection'>
                <Grid container spacing={1} alignItems="top">
                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <AppBar position="static" className="tabbedbar">
                            <Tabs
                                value={value2}
                                onChange={handleChange2}
                                indicatorColor="none"
                                textColor="primary"
                                variant="scrollable"
                                scrollButtons="auto"
                                aria-label="scrollable auto tabs example"
                            > 
                                <Tab disableRipple label="Primary Details" {...a11yProps(0)} />
                                <Tab disableRipple label="Secondary Details (Optional)" {...a11yProps(1)} />
                            </Tabs>
                        </AppBar>
                    </Grid>
                </Grid>
            </Box>



            <TabPanel value={value2} index={0} className="ddtab">
            <Box pb={2}>
                <Grid container spacing={1} alignItems="top">

                <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Name Of Account Holder" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Bank A/c Number" fullWidth />
                        </Box>
                    </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Account Type" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Branch Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="IFSC Code " fullWidth />
                        </Box>
                    </Grid>
                    

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="MICR Code " fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='datepic'>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="MM/dd/yyyy"
                                                    id="date-picker-inline"
                                                    placeholder="Commencement Date"
                                                    value={selectedDate}
                                                    onChange={handleDateChange}
                                                    KeyboardButtonProps={{
                                                        'aria-label': 'change date',
                                                    }}
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Box>
                                    </Grid>


                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='datepic'>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="MM/dd/yyyy"
                                                    id="date-picker-inline"
                                                    placeholder="Commencement Date"
                                                    value={selectedDate}
                                                    onChange={handleDateChange}
                                                    KeyboardButtonProps={{
                                                        'aria-label': 'change date',
                                                    }}
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Box>
                                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Mandate Amount Rs. Limit / Transaction " fullWidth />
                        </Box>
                    </Grid>
 
                </Grid>
            </Box>
            </TabPanel>


            <TabPanel value={value2} index={1} className="ddtab">
            <Box pb={2}>
                <Grid container spacing={1} alignItems="top">

                <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Name Of Account Holder" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Bank A/c Number" fullWidth />
                        </Box>
                    </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Account Type" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Branch Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="IFSC Code " fullWidth />
                        </Box>
                    </Grid>
                    

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="MICR Code " fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='datepic'>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="MM/dd/yyyy"
                                                    id="date-picker-inline"
                                                    placeholder="Commencement Date"
                                                    value={selectedDate}
                                                    onChange={handleDateChange}
                                                    KeyboardButtonProps={{
                                                        'aria-label': 'change date',
                                                    }}
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Box>
                                    </Grid>


                                    <Grid item lg={3} md={6} sm={12} xs={12}>
                                        <Box className='datepic'>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="MM/dd/yyyy"
                                                    id="date-picker-inline"
                                                    placeholder="Commencement Date"
                                                    value={selectedDate}
                                                    onChange={handleDateChange}
                                                    KeyboardButtonProps={{
                                                        'aria-label': 'change date',
                                                    }}
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Box>
                                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Mandate Amount Rs. Limit / Transaction " fullWidth />
                        </Box>
                    </Grid>
 
                </Grid>
            </Box>
            </TabPanel>


      
 
         
            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
            </Grid>


        </>
    );
}
