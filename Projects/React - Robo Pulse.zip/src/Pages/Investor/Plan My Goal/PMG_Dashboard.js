import React from 'react';
import { Box, Container, Grid, List, ListItem, ListItemText, Button, Typography, Divider, IconButton, TextField, InputAdornment } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import { Link } from 'react-router-dom';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';

import CancelIcon from '@material-ui/icons/Cancel';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import WatchLaterIcon from '@material-ui/icons/WatchLater';
import DoneAllIcon from '@material-ui/icons/DoneAll';

// import ABSL from "../../asset/images/Logos/aditya_birla.png"
// import ICICI from "../../asset/images/Logos/icici_fund.png"
// import HDFC from "../../asset/images/Logos/hdfc_fund2.png"
// import INVE from "../../asset/images/Logos/invesco2.png"
// import EMI from "../../asset/images/Logos/emi.png"
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';
import Carousel from "react-elastic-carousel";
import LocationOnOutlinedIcon from '@material-ui/icons/LocationOnOutlined';
import EditOutlinedIcon from '@material-ui/icons/EditOutlined';
import RefreshOutlinedIcon from '@material-ui/icons/RefreshOutlined';
import CHART from "../../../asset/images/pmg_chart.png"


import TrendingDownOutlinedIcon from '@material-ui/icons/TrendingDownOutlined';


const breakPoints = [
    { width: 100, itemsToShow: 1 },
    { width: 360, itemsToShow: 1, itemsToScroll: 1 },
    { width: 460, itemsToShow: 2, itemsToScroll: 1 },
    { width: 550, itemsToShow: 2, itemsToScroll: 2 },
    { width: 600, itemsToShow: 3, itemsToScroll: 2 },
    { width: 1050, itemsToShow: 4, itemsToScroll: 2 },
    { width: 1200, itemsToShow: 4, itemsToScroll: 3 }
];

export default function PMG_Dashboard() {

    return (
        <>


            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='maintabbedsection mb_n'>

                        <Box className='wch_bx' pb={2}>

                            <Grid container spacing={0} alignItems="top" justifyContent='center'>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='wh_bx'>


                                        <Box className='card_head al_center sk_bg2'>
                                            <Typography variant='h3' className='bl' gutterBottom> Based on your inputs, the target amount should be <strong>Rs. 81700</strong>  </Typography>

                                            <Typography variant='h3' className='bl'> And the suggested SIP amount should be <strong>Rs. 5000</strong>  to achive the goal. </Typography>

                                        </Box>

                                        <Box className='brd1' mb={2}></Box>
                                        <Grid container spacing={2} alignItems="top" justifyContent='center'>

                                            <Grid item lg={8} md={12} sm={12} xs={12}>
                                                <Box id='purchase_card' className='grybx2'>


                                                    <Box className='al_center'>
                                                        <img alt="Logo" src={CHART} className="gif_lg" />
                                                    </Box>

                                                </Box>

                                            </Grid>


                                            <Grid item lg={4} md={4} sm={12} xs={12}>

                                                <Box id='purchase_card' className='grybx2'>
                                                    <Grid container spacing={2} alignItems="top" justifyContent='center'>


                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='alltxfield'>
                                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Target Amount" fullWidth />
                                                            </Box>
                                                        </Grid>

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='bt al_right'>
                                                                <Button variant="contained" className='btn bl_bttn' size='small' endIcon={<EditOutlinedIcon />}> Edit Targeted Amount </Button>
                                                            </Box>
                                                        </Grid>

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='alltxfield'>
                                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="SIP Amount" fullWidth />
                                                            </Box>
                                                        </Grid>

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='bt al_right'>
                                                                <Button variant="contained" className='btn bl_bttn' size='small' endIcon={<RefreshOutlinedIcon />}> Recompute </Button>
                                                            </Box>
                                                        </Grid>

                                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                                            <Box className='alltxfield'>
                                                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Tenure (in Years)" fullWidth />
                                                            </Box>
                                                        </Grid>


                                                    </Grid>
                                                </Box>

                                            </Grid>



                                        </Grid>

                                        <Box className='brd1' mb={2}></Box>

                                        <Box className='card_head al_center sk_bg2'>
                                            <Box mt={1}>
                                                <Typography variant='h6' className='bl' gutterBottom> Your Goal is  </Typography>
                                            </Box>

                                            <Box className='bt al_center' mb={0}>
                                                <Link to="/off_track" className='link'>
                                                    <Button variant="contained" className='btn red_bttn btn_lg' size='small' endIcon={<TrendingDownOutlinedIcon />}> Off Track  </Button>
                                                </Link>
                                            </Box>


                                            <Box className='card_ head al_center s k_bg2'>
                                                <Typography variant='h6' className='bl' gutterBottom> Even if you are off-track currently and still want to plan this goal. We will guide you to get on-track over the course of time.
                                                </Typography>


                                            </Box>


                                        </Box>



                                    </Box>






                                </Grid>




                            </Grid>

                        </Box>






                    </Box>
                </Container>
            </Box>




        </>
    );
}
