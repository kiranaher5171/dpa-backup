import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, AppBar, Tabs, Tab, Button, Typography, TextField, Divider, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import InputAdornment from '@material-ui/core/InputAdornment';
import CreateIcon from '@material-ui/icons/Create';
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import CancelOutlinedIcon from '@material-ui/icons/CancelOutlined';
import { Link } from 'react-router-dom';
import Autocomplete from '@material-ui/lab/Autocomplete';


const chooseopt = [
  { title: 'Applicable' },
  { title: 'Not Applicable' },
]

const ISD = [
  { title: '+91' },
  { title: '+94' },
  { title: '+99' },
  { title: '+78' },
  { title: '+67' },
  { title: '+55' },
]

const City = [
  { title: 'Nashik' },
  { title: 'Mumbai' },
  { title: 'GIFT City' },
  { title: 'Nagpur' },
  { title: 'Chennai' },
  { title: 'Banglore' },
]






export default function PMG_Purchase_Home() {

  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };


  // Datepicker
  const [selectedDate, setSelectedDate] = React.useState(new Date());
  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
  // Datepicker



  return (
    <>




      <Box component="section" className='tabbedinfo codingpagestart'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>


            <Box className='wh_bx' pb={2}>
              <Grid container spacing={1} alignItems="top"  >

                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className='brd1 flx_sa p0' >
                    <Box>
                      <Typography variant='h5' className='fw500 bl' > Purchase Home </Typography>
                    </Box>

                  </Box>
                </Grid>





                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Name of the Goal" fullWidth />
                  </Box>
                </Grid>

                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Present Cost of Your Goal" fullWidth />
                  </Box>
                </Grid>


                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Loan Component (%)" fullWidth InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <Tooltip title='Additional Information Here'>
                            <InfoOutlinedIcon className='col2' />
                          </Tooltip>
                        </InputAdornment>
                      ),
                    }} />
                  </Box>
                </Grid>



                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Your Contribution (%)" fullWidth
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <Tooltip title='Additional Information Here'>
                              <InfoOutlinedIcon className='col2' />
                            </Tooltip>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>


                <Grid item lg={3} md={6} sm={12} xs={12}>
                  <Box className='alltxfield'>
                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Investment Period (in Years)" fullWidth
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <Tooltip title='Additional Information Here'>
                              <InfoOutlinedIcon className='col2' />
                            </Tooltip>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Box>
                </Grid>


              </Grid>
            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
              <Box className='bt al_right' mt={1}>
                <Link to='investor_plan_my_goal'>
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                </Link>

                <Link to='pmg_dashboard'>
                  <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
                </Link>
              </Box>
            </Grid>





          </Box>
        </Container>
      </Box>




    </>
  );
}
