import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Typography, FormLabel, RadioGroup, AppBar, FormControlLabel, Radio, Tabs, Tab, Button, Grid, TextField, Tooltip, FormControl, InputLabel, IconButton, Select, MenuItem, Divider, List, ListItem, ListItemText, ListItemAvatar, Avatar, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward'; 

import { Link } from 'react-router-dom';

import ArrowBackIcon from '@material-ui/icons/ArrowBack';
 
  
import P1A from "../../asset/images/riskquestion/pmg_1.svg";
import P1B from "../../asset/images/riskquestion/pmg_1h.svg";

import P2A from "../../asset/images/riskquestion/pmg_2.svg";
import P2B from "../../asset/images/riskquestion/pmg_2h.svg";

import P3A from "../../asset/images/riskquestion/pmg_3.svg";
import P3B from "../../asset/images/riskquestion/pmg_3h.svg";

import P4A from "../../asset/images/riskquestion/pmg_4.svg";
import P4B from "../../asset/images/riskquestion/pmg_4h.svg";

import P5A from "../../asset/images/riskquestion/pmg_5.svg";
import P5B from "../../asset/images/riskquestion/pmg_5h.svg";

import P6A from "../../asset/images/riskquestion/pmg_6.svg";
import P6B from "../../asset/images/riskquestion/pmg_6h.svg";

import P7A from "../../asset/images/riskquestion/pmg_7.svg";
import P7B from "../../asset/images/riskquestion/pmg_7h.svg";

import P8A from "../../asset/images/riskquestion/pmg_8.svg";
import P8B from "../../asset/images/riskquestion/pmg_8h.svg";

import P9A from "../../asset/images/riskquestion/pmg_9.svg";
import P9B from "../../asset/images/riskquestion/pmg_9h.svg";

import P10A from "../../asset/images/riskquestion/pmg_10.svg";
import P10B from "../../asset/images/riskquestion/pmg_10h.svg";

 

export default function Investor_Plan_My_Goal() {
 

  return (
    <>

  


      <Box component="section"  className='tabbedinfo codingpagestart'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

         
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">


                  <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className= "al_left brd1" >
                                          <Box mb={1}>
                                                <Typography variant='h5' className=' bl' > Select Goal </Typography>
                                          </Box>
                                        </Box>
                                    </Grid>


                <Box className="options_box" pb={5} pt={5}>
<RadioGroup   aria-label="position" name="position" defaultValue="top">           

<Grid container spacing={1} alignItems="center" justifyContent='center'>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Link to="pmg_purchase_home" >
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P1A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P1B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Purchase Home</Typography>
</Box>
</Box>
</Link>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Link to="pmg_purchase_vehicle" >
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P2A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P2B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Purchase Vehicle</Typography>
</Box>
</Box>
</Link>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P3A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P3B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'> Child Education </Typography>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P4A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P4B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Retirement Fund</Typography>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P5A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P5B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Emergency Fund</Typography>
</Box>
</Box>
</Grid>
 
</Grid>

 
</RadioGroup>   
</Box>
 

<Box className="options_box" pb={5} pt={5}>
<RadioGroup   aria-label="position" name="position" defaultValue="top">           

<Grid container spacing={1} alignItems="center" justifyContent='center'>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P6A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P6B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Vacation</Typography>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P7A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P7B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Start Business</Typography>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P8A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P8B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'> Marriage </Typography>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P9A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P9B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Build Wealth</Typography>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P10A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P10B } width={100} alt="fliper"/></p>
</Box>
</div>
<Typography variant='subtitle1' className='col1'>Other</Typography>
</Box>
</Box>
</Grid>
 

</Grid>

</RadioGroup>   
</Box>
 



<Grid item lg={12} md={12} sm={12} xs={12}>
  <Box className='brd1'></Box>
</Grid>



<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='bt al_right' mt={1}>
<Link to="/investor_risk_profile_5">
<Button variant="contained" className='al_center btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
</Link>
{/* <Link to="/investor_risk_profile_6"> */}
<Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Next </Button>
{/* </Link> */}
</Box>
</Grid>

                </Grid>
              </Box>

 





          </Box>
        </Container>
      </Box>




    </>
  );
}
