import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, AppBar, Tabs, Tab, Button, Typography, FormControl, InputLabel, TextField, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';
import FilledInput from '@material-ui/core/FilledInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import CreateIcon from '@material-ui/icons/Create';
import { Link } from 'react-router-dom';
import RotateLeftIcon from '@material-ui/icons/RotateLeft';

import Autocomplete from '@material-ui/lab/Autocomplete';
import Investor_Profile_Reg_Details from './Investor_Profile_Reg_Details';
import Investor_Profile_Inv_Details from './Investor_Profile_Inv_Details';
import Investor_Bank_Details from './Investor_Bank_Details';
import Investor_Nominee_Details from './Investor_Nominee_Details';
import Investor_Profile_Doc_Vault from './Investor_Profile_Doc_Vault';
import Investor_Profile_FATCA from './Investor_Profile_FATCA';
import Investor_Profile_Inv_Profile from './Investor_Profile_Inv_Profile';
import Investor_Profile_Reports from './Investor_Profile_Reports';

const chooseopt = [
    { title: 'Applicable' },
    { title: 'Not Applicable' },
]


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`scrollable-auto-tabpanel-${index}`}
            aria-labelledby={`scrollable-auto-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}






export default function Investor_Profile() {


    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const [value2, setValue2] = React.useState(0);
    const handleChange2 = (event, newValue) => {
        setValue2(newValue);
    };



    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState("12/12/2025");

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    const [values, setValues] = React.useState({
        amount: '', password: '', weight: '', weightRange: '', showPassword: false,
    });

    const handleChangePass = (prop) => (event) => { setValues({ ...values, [prop]: event.target.value }); };
    const handleClickShowPassword = () => { setValues({ ...values, showPassword: !values.showPassword }); };
    const handleMouseDownPassword = (event) => { event.preventDefault(); };



    return (
        <>

<Box className='codingpagestart'>



            <Box className=' sti' component="section" style={{}}>
                <Container className='containerwidth'>
                    <Box className='st_middle fr_sec'>
                        <Grid container spacing={0} alignItems="center">
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='maintabbedsection'>
                                    <AppBar position="static" className="tabbedbar">
                                        <Tabs
                                            value={value}
                                            onChange={handleChange}
                                            indicatorColor="none"
                                            textColor="primary"
                                            variant="scrollable"
                                            scrollButtons="auto"
                                            aria-label="scrollable auto tabs example"
                                        >
                                            <Tab label="Registration Details" {...a11yProps(0)} />
                                            <Tab label="Investor Details"{...a11yProps(1)} />
                                            <Tab label="Bank Details" {...a11yProps(2)} />
                                            <Tab label="Nominee" {...a11yProps(3)} />
                                            <Tab label="Document Vault" {...a11yProps(4)} />
                                            <Tab label="FATCA" {...a11yProps(5)} />
                                            <Tab label="Investment Profile" {...a11yProps(5)} />
                                            <Tab label="Reports" {...a11yProps(5)} />
                                        </Tabs>
                                    </AppBar>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>
                </Container>
            </Box>


            <Box component="section" mt={1} className='tabbedinfo'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <TabPanel value={value} index={0} className="ddtab">
                            <Investor_Profile_Reg_Details />
                        </TabPanel>


                        <TabPanel value={value} index={1} className="ddtab">
                            <Investor_Profile_Inv_Details />
                        </TabPanel>


                        <TabPanel value={value} index={2} className="ddtab">
                            <Investor_Bank_Details />
                        </TabPanel>

                        <TabPanel value={value} index={3} className="ddtab">
                            <Investor_Nominee_Details />
                        </TabPanel>

                        <TabPanel value={value} index={4} className="ddtab">
                            <Investor_Profile_Doc_Vault />
                        </TabPanel>

                        <TabPanel value={value} index={5} className="ddtab">
                            <Investor_Profile_FATCA />
                        </TabPanel>

                        <TabPanel value={value} index={6} className="ddtab">
                            <Investor_Profile_Inv_Profile />
                        </TabPanel>

                        <TabPanel value={value} index={7} className="ddtab">
                            <Investor_Profile_Reports />
                        </TabPanel>


                    </Box>
                </Container>
            </Box>


</Box>

        </>
    );
}
