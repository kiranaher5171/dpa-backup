import React from 'react';
import { Box, Container, Grid, Button, Typography, TextField } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import { Link } from 'react-router-dom';
import Autocomplete from '@material-ui/lab/Autocomplete';

const chooseopt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
]



export default function IFA_view_client_mapping() {


    return (
        <>


            <Box component="section" className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>
                            <Grid container spacing={1} alignItems="center">


                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='flx_sa brd1'>
                                        <Typography variant='h5' className='fw500 bl' > Hello, IFA name </Typography>
                                        <Typography variant='h6' className='fw500 bl' > View Client Mapping </Typography>
                                    </Box>
                                </Grid>
 
                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='textfield' >

                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={chooseopt}
                                            getOptionLabel={(option) => option.title}
                                            renderInput={(params) => <TextField {...params} label="Select CM" variant="filled" />}
                                        />

                                    </Box>
                                </Grid>

                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='textfield' >

                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={chooseopt}
                                            getOptionLabel={(option) => option.title}
                                            renderInput={(params) => <TextField {...params} label="Select ZM" variant="filled" />}
                                        />


                                    </Box>
                                </Grid>

                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='textfield' >
                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={chooseopt}
                                            getOptionLabel={(option) => option.title}
                                            renderInput={(params) => <TextField {...params} label="Select SM" variant="filled" />}
                                        />

                                    </Box>
                                </Grid>


                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='textfield' >

                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={chooseopt}
                                            getOptionLabel={(option) => option.title}
                                            renderInput={(params) => <TextField {...params} label="Select DM" variant="filled" />}
                                        />

                                    </Box>
                                </Grid>

                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='textfield' >
                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={chooseopt}
                                            getOptionLabel={(option) => option.title}
                                            renderInput={(params) => <TextField {...params} label="Select BM" variant="filled" />}
                                        />

                                    </Box>
                                </Grid>

                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='textfield' >
                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={chooseopt}
                                            getOptionLabel={(option) => option.title}
                                            renderInput={(params) => <TextField {...params} label="Select RM" variant="filled" />}
                                        />
                                    </Box>
                                </Grid>



                                <Grid item lg={3} md={6} sm={12} xs={12}>
                                    <Box className='textfield' >
                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={chooseopt}
                                            getOptionLabel={(option) => option.title}
                                            renderInput={(params) => <TextField {...params} label="Select Agent" variant="filled" />}
                                        />
                                    </Box>
                                </Grid>





                            </Grid>
                        </Box>


                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1}>
                                <Link to='/ifa_mapped_clients' className="link">
                                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Get Clients </Button>
                                </Link>
                            </Box>
                        </Grid>

                    </Box>
                </Container>
            </Box>




        </>
    );
}
