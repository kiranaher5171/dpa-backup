import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, AppBar, Tabs, Tab, Button, Typography, FormControl, InputLabel, TextField, Avatar,  Divider, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import FilledInput from '@material-ui/core/FilledInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import CreateIcon from '@material-ui/icons/Create';
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import { useState } from "react";
import { Link } from 'react-router-dom';



import Autocomplete from '@material-ui/lab/Autocomplete';

const ISD = [
  { title: '+91' },
  { title: '+94' },
  { title: '+99' },
  { title: '+78' },
  { title: '+67' },
  { title: '+55' },
]




function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
  };
}



export default function RM_update_profile() {


  const [file, setFile] = useState(null);

  const handleChange2 = function loadFile(event) {
    if (event.target.files.length > 0) {
      const file = URL.createObjectURL(event.target.files[0]);
      setFile(file);
    }
  };

  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };



  // Datepicker
  const [selectedDate, setSelectedDate] = React.useState(new Date());

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
  // Datepicker


  const [values, setValues] = React.useState({
    amount: '', password: '', weight: '', weightRange: '', showPassword: false,
  });

  const handleChangePass = (prop) => (event) => { setValues({ ...values, [prop]: event.target.value }); };
  const handleClickShowPassword = () => { setValues({ ...values, showPassword: !values.showPassword }); };
  const handleMouseDownPassword = (event) => { event.preventDefault(); };



  return (
    <>

<Box className='codingpagestart'>

      <Box className=' sti' component="section" style={{}}>
        <Container className='containerwidth'>
          <Box className='st_middle fr_sec '>
            <Grid container spacing={0} alignItems="center">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='maintabbedsection'>
                  <AppBar position="static" className="tabbedbar">
                    <Tabs
                      value={value}
                      onChange={handleChange}
                      indicatorColor="none"
                      textColor="primary"
                      variant="scrollable"
                      scrollButtons="auto"
                      aria-label="scrollable auto tabs example"
                    >
                      <Tab label="Basic Details" {...a11yProps(0)} />
                      <Tab label="Upload Document"{...a11yProps(1)} />
                      <Tab label="AMFI Creds" {...a11yProps(2)} />
                    </Tabs>
                  </AppBar>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>


      <Box component="section" mt={1} className='tabbedinfo'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

            <TabPanel value={value} index={0} className="ddtab">
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                  <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box className='brd1 flx_sa p0' > 
                        <Typography variant='h5' className=' bl' > Basic Details </Typography> 
                        <IconButton color='primary' component="span">
                          <Tooltip title="Edit" aria-label="add">
                            <CreateIcon className='smicobtn' />
                          </Tooltip>
                        </IconButton> 
                    </Box>
                  </Grid>



                    <Grid container spacing={1} alignItems="center">

                      <Grid item lg={2} md={4} sm={6} xs={12}>

                        <Box className="Drop al_center">
                          <input type="file"
                            onChange={handleChange2}
                            id="upload"
                            accept="image/*"
                            style={{ display: "none" }} />
                          <label htmlFor="upload">
                            <IconButton color="primary"
                              aria-label="upload picture"
                              component="span">
                              <Tooltip title="Change Your Profile" aria-label="add">
                                <Avatar id="avatar" src={file}
                                  style={{
                                    width: "42px",
                                    height: "42px",
                                  }}
                                />
                              </Tooltip>
                            </IconButton>
                          </label>
                          <label htmlFor="avatar" />
                        </Box>


                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className='alltxfield'>
                          <TextField id="filled-basic" className='filleddp' variant="filled" label="CM ID" value="#CM012345" fullWidth disabled
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <PersonOutlineOutlinedIcon />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Box>
                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className='alltxfield'>
                          <TextField id="filled-basic" className='filleddp' variant="filled" label="ZM ID" value="#ZM012345" fullWidth disabled
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <PersonOutlineOutlinedIcon />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Box>
                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className='alltxfield'>
                          <TextField id="filled-basic" className='filleddp' variant="filled" label="SM ID" value="#SM012345" fullWidth disabled
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <PersonOutlineOutlinedIcon />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Box>
                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className='alltxfield'>
                          <TextField id="filled-basic" className='filleddp' variant="filled" label="DM ID" value="#DM012345" fullWidth disabled
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <PersonOutlineOutlinedIcon />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Box>
                      </Grid>

                      <Grid item lg={2} md={4} sm={6} xs={12}>
                        <Box className='alltxfield'>
                          <TextField id="filled-basic" className='filleddp' variant="filled" label="BM ID" value="#BM012345" fullWidth disabled
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <PersonOutlineOutlinedIcon />
                                </InputAdornment>
                              ),
                            }}
                          />
                        </Box>
                      </Grid>

                    </Grid>
  


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Type of Account" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="First Name" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Middle Name" fullWidth />
                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Last Name" fullWidth />
                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="ARN" fullWidth />
                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Email ID" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={1} md={2} sm={3} xs={3}>
                    <Box className='textfield' > 
                      <Autocomplete
                        id="combo-box-demo"
                        options={ISD}
                        getOptionLabel={(option) => option.title}
                        renderInput={(params) => <TextField {...params} label="ISD" variant="filled" />}
                      /> 
                    </Box>
                  </Grid>


                  <Grid item lg={2} md={4} sm={9} xs={9}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Contact Number" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Address" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="Aadhar Number" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="PAN" fullWidth />
                    </Box>
                  </Grid>

                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='alltxfield'>
                      <TextField id="filled-basic" className='filleddp' variant="filled" label="EUIN (Optional)" fullWidth />
                    </Box>
                  </Grid>


                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Box className='datepic'>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <KeyboardDatePicker
                          disableToolbar
                          variant="inline"
                          format="MM/dd/yyyy"
                          id="date-picker-inline"
                          placeholder="Commencement Date"
                          value={selectedDate}
                          onChange={handleDateChange}
                          KeyboardButtonProps={{
                            'aria-label': 'change date',
                          }}
                        />
                      </MuiPickersUtilsProvider>
                    </Box>
                  </Grid>





                </Grid>
              </Box>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                  <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
              </Grid>

            </TabPanel>

            <TabPanel value={value} index={1} className="ddtab">
              <Box className='wh_bx' pb={2}>

                <Grid container spacing={2} alignItems="top">

                  <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box className='brd1 flx_sa p0' >
                        <Typography variant='h5' className=' bl' > Upload Documents </Typography>
                        <IconButton color='primary' component="span">
                          <Tooltip title="Edit" aria-label="add">
                            <CreateIcon className='smicobtn' />
                          </Tooltip>
                        </IconButton>
                    </Box>
                  </Grid>

                  <Grid item lg={4} md={4} sm={6} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl'>ARN Certificate</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>

                  <Grid item lg={4} md={4} sm={6} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl '>Aadhar Card</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>


                  <Grid item lg={4} md={4} sm={6} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl '>Graduation Certificate</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>

                    <Box mt={1} mb={1}><Divider /></Box>

                  </Grid>


                  <Grid item lg={4} md={4} sm={6} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl '>EUIN Card</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>


                  <Grid item lg={4} md={4} sm={6} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl '>PAN Card</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>

                  <Grid item lg={4} md={4} sm={6} xs={12}>
                    <Box className='flx_sa'>
                      <Typography variant='h6' className='bl '>NISM Certificate</Typography>
                      <Tooltip title="Additional Information" aria-label="add">
                        <span className='infoico infoico_align'>  <InfoOutlinedIcon className='gry' /> </span>
                      </Tooltip>
                    </Box>
                    <Box className='uploadfile uploadfile_tt'>
                      <input type="file" class="input-file" />
                    </Box>
                    <Box mt={1} mb={1}><Divider /></Box>
                  </Grid>


                </Grid>
              </Box>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                  <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
              </Grid>
            </TabPanel>

            <TabPanel value={value} index={2} className="ddtab">
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                  <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box className='brd1 flx_sa p0' >
                        <Typography variant='h5' className=' bl' > AMFI Login Credentials </Typography>
                        <IconButton color='primary' component="span">
                          <Tooltip title="Edit" aria-label="add">
                            <CreateIcon className='smicobtn' />
                          </Tooltip>
                        </IconButton>
                    </Box>
                  </Grid>


                  <Grid
                    container
                    direction="row"
                    justifyContent="center"
                    alignItems="center"
                    spacing={3}
                  >

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                      <Box className='alltxfield'>
                        <TextField id="filled-basic" className='filleddp' variant="filled" label="EUIN" fullWidth />
                      </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                      <Box className='alltxfield lg_pass'>
                        <FormControl fullWidth variant="filled">
                          <InputLabel htmlFor="filled-adornment-password">Password</InputLabel>
                          <FilledInput

                            id="filled-adornment-password"
                            type={values.showPassword ? 'text' : 'password'}
                            value={values.password}
                            onChange={handleChangePass('password')}
                            endAdornment={
                              <InputAdornment position="end">
                                <IconButton
                                  aria-label="toggle password visibility"
                                  onClick={handleClickShowPassword}
                                  onMouseDown={handleMouseDownPassword}
                                  edge="end"
                                >
                                  {values.showPassword ? <Visibility /> : <VisibilityOff />}
                                </IconButton>
                              </InputAdornment>
                            }
                          />
                        </FormControl>
                      </Box>
                    </Grid>

                  </Grid>


                </Grid>
              </Box>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                  <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                  <Link to="/successfull" className="link">
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                  </Link>
                </Box>
              </Grid>
            </TabPanel>
 
          </Box>
        </Container>
      </Box>


</Box>

    </>
  );
}
