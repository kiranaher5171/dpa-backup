import React from 'react';
import { Box, Container, Grid, Button, Typography, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import GetAppIcon from '@material-ui/icons/GetApp';

import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import { Link } from 'react-router-dom';


export default function Partner_Management() {

    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }


    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true ,  flex: 1
    }

    const columnDefs = [
        {
            headerName: ' ', field: 'number', minWidth: 55, maxWidth: 55,  headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'Partner Id', field: 'agent_id', minWidth: 125,  },
        { headerName: 'Partner Name', field: 'agent_name', minWidth: 150, cellRendererFramework: (params) => <Link to='/partner_profile'>ABC</Link> },
        { headerName: 'Contact', field: 'contact', minWidth: 125, },
        { headerName: 'Email Id', field: 'email', minWidth: 150, },
        { headerName: 'PAN', field: 'pan', minWidth: 125, },
        { headerName: 'Sub-Broker ARN', field: 'arn', minWidth: 150, },
        { headerName: 'EUIN', field: 'euin', minWidth: 125, },
        { headerName: 'Catagory', field: 'catagory', minWidth: 125, }, 
    ]


    const [rowData] = useState([
        { number: "01", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", pan: "AGDPR5192E",   arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "09", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "john@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "02", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E",  arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "04", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E",  arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "03", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E",  arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "06", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "10", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "05", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "07", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "08", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "01", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", pan: "AGDPR5192E",   arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "09", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "john@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "02", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E",  arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "04", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E",  arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "03", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E",  arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "06", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "10", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "05", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        { number: "07", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Normal", },
        { number: "08", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", pan: "AGDPR5192E", arn: "ARN-409211", euin: "E12346", catagory: "Gold", },
        
 ])



    return (
        <>

            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>
        


                            <Grid
                                container
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                            >
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <Typography variant='h6' className='fw500 bl' >Existing Investors List </Typography>
                                </Grid>


                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <ul id='searchportion'>
                                        <li>
                                            <Box className='bt al_right' mr={1} >
                                                <Typography variant='h6' className='bl' > Total Partners : <span className='gry'> 20 </span></Typography>
                                            </Box>
                                        </li>

                                        <li>
                                            <div class="form-group has-search">
                                                <span class="form-control-feedback"><SearchIcon /></span>
                                                <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                            </div>
                                        </li>

                                        <li>
                                            <IconButton>
                                                <Tooltip title="Download">
                                                <GetAppIcon className='col1' />
                                                </Tooltip>
                                            </IconButton>
                                        </li>

                                    </ul>
                                </Grid>

                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '68vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>
                            </Grid>



                        </Box>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1}>
                                <Link to='#' className="link">
                                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                </Link>
                                <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                            </Box>
                        </Grid>

                    </Box>
                </Container>
            </Box>

        </>
    );
}
