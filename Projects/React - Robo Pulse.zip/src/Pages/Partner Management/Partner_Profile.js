import React from 'react';
import { Box, Container, Grid,  Button, Typography, Divider,  TextField, InputAdornment } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import { Link } from 'react-router-dom';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
 
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined'; 
import LocationOnOutlinedIcon from '@material-ui/icons/LocationOnOutlined';

 
export default function Partner_Profile() {

    return (
        <>


            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='maintabbedsection mb_n'>

                        <Box className='wch_bx' pb={2}>

                            <Grid container spacing={0} alignItems="top" justifyContent='center'>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='wh_bx'>

                                        <Box mb={"0px"}>
                                            <Typography variant='h5' className='fw500 bl'> Partner Profile </Typography>
                                        </Box>

<Box className='brd1' mb={2}></Box>
<Grid container spacing={2} alignItems="top" justifyContent='center'>

<Grid item lg={12} md={12} sm={12} xs={12}> 

<Grid container spacing={2} alignItems="top" justifyContent='center'>


<Grid item lg={3} md={4} sm={4} xs={12}>
<Box className='alltxfield'>
<TextField id="filled-basic" className='filleddp' variant="filled" label="Partner Name" value="ABC" fullWidth disabled
InputProps={{
startAdornment: (
<InputAdornment position="start">
<PersonOutlineOutlinedIcon />
</InputAdornment>
),
}}
/>
</Box>
</Grid>

<Grid item lg={3} md={4} sm={4} xs={12}>
<Box className='alltxfield'>
<TextField id="filled-basic" className='filleddp' variant="filled" label="Location" value="Mumbai" fullWidth disabled
InputProps={{
startAdornment: (
<InputAdornment position="start">
<LocationOnOutlinedIcon />
</InputAdornment>
),
}}
/>
</Box>
</Grid>

<Grid item lg={3} md={4} sm={4} xs={12}>
<Box className='alltxfield'>
<TextField id="filled-basic" className='filleddp' variant="filled" label="Sub-Broker ARN" value="ARN-194051" fullWidth disabled
InputProps={{
startAdornment: (
<InputAdornment position="start">
<PersonOutlineOutlinedIcon />
</InputAdornment>
),
}}
/>
</Box>
</Grid>


</Grid>
</Grid>


<Grid item lg={4} md={4} sm={12} xs={12}>
<Box id='purchase_card' className='grybx2'>
<Box className='al_left card_head bl_bttn'> 
    <Typography variant='h5' className='fw500 wh'> AUM Summary </Typography>
</Box>
 
<Divider className='divider1' />

<Box>
<TableContainer  style={{minHeight: '105px'}}  >
<Table aria-label="simple table">
<TableBody>
<TableRow >
<TableCell component="th" className='col1'> AUM </TableCell>
<TableCell align="left" className='col3'> 25 Cr </TableCell> 
</TableRow>

<TableRow >
<TableCell component="th" className='col1'> Total no. of Clients </TableCell>
<TableCell align="left" className='col3'> 50000 </TableCell> 
</TableRow>

<TableRow >
<TableCell component="th" className='col1'> Total funds invested </TableCell>
<TableCell align="left" className='col3'> 500 </TableCell> 
</TableRow>

<TableRow >
<TableCell component="th" className='col1'> Category </TableCell>
<TableCell align="left" className='col3'> Gold </TableCell>
</TableRow>

</TableBody>
</Table>
</TableContainer>
</Box>
<Divider className='divider1' />

</Box>
</Grid>

<Grid item lg={4} md={4} sm={12} xs={12}>
<Box id='purchase_card' className='grybx2'> 
<Box className='al_left card_head sk_bttn'> 
    <Typography variant='h5' className='fw500 wh'> SIP Summary </Typography>
</Box> 
 
<Divider className='divider1' />

<Box>
<TableContainer style={{minHeight: '105px'}} >
<Table aria-label="simple table">
<TableBody>
<TableRow >
<TableCell component="th" className='col1'> No. of SIPs </TableCell>
<TableCell align="left" className='col3'> 50 </TableCell> 
</TableRow>

<TableRow >
<TableCell component="th" className='col1'> Live SIP </TableCell>
<TableCell align="left" className='col3'> 45 </TableCell> 
</TableRow>

<TableRow >
<TableCell component="th" className='col1'> Invested Amount </TableCell>
<TableCell align="left" className='col3'> 500000 </TableCell> 
</TableRow>
 

</TableBody>
</Table>
</TableContainer>
</Box>
<Divider className='divider1' />
</Box>
</Grid>

<Grid item lg={4} md={4} sm={12} xs={12}>
<Box id='purchase_card' className='grybx2'>
<Box className='al_left card_head green_bttn'> 
    <Typography variant='h5' className='fw500 wh'> Lumpsum  Summary </Typography>
</Box> 
 
<Divider className='divider1' />

<Box>
<TableContainer  style={{minHeight: '105px'}}  >
<Table aria-label="simple table">
<TableBody>
<TableRow >
<TableCell component="th" className='col1'> No. of Lumpsum </TableCell>
<TableCell align="left" className='col3'> 30 </TableCell> 
</TableRow>

<TableRow >
<TableCell component="th" className='col1'> Invested Amount </TableCell>
<TableCell align="left" className='col3'> 1000000 </TableCell>  
</TableRow>
 

</TableBody>
</Table>
</TableContainer>
</Box>

<Divider className='divider1' />
</Box>
</Grid>


</Grid>
</Box>

<Grid item lg={12} md={12} sm={12} xs={12}>
<Box className='bt al_right' mt={1}>
                                    <Link to="/partner_management" className='link'>
                                        <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                    </Link>
                                </Box>
                                </Grid>


                                </Grid>

                                


                            </Grid>

                        </Box>

                        
                               
                         


                    </Box>
                </Container>
            </Box>




        </>
    );
}
