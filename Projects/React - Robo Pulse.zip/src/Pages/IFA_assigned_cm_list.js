import React from 'react';
import { Box, Container, Grid, Button, Typography, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import GetAppIcon from '@material-ui/icons/GetApp';

import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import { Link } from 'react-router-dom';



export default function IFA_assigned_cm_list() {


    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 30;
    const headerHeight = 30;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex:1
    }

    const columnDefs = [
        {
            headerName: 'Sr No.', field: 'number', minWidth: 115, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'CM Id', field: 'cm_id', minWidth: 115, },
        { headerName: 'CM Name', field: 'cm_name', minWidth: 160, },
        { headerName: 'Contact', field: 'contact', minWidth: 160, },
        { headerName: 'Email Id', field: 'email', minWidth: 200, },
        { headerName: 'Total AUM', field: 'aum', minWidth: 125, },
        { headerName: 'No. of ZM', field: 'zm', minWidth: 140, },
        { headerName: 'Total Fund', field: 'fund', minWidth: 125, },
        { headerName: 'Total Invested Amount (RS)', field: 'investment', minWidth: 180, },
        { headerName: 'Country', field: 'country', minWidth: 125, },
    ]


    const [rowData] = useState([
        { number: "01", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "India" },
        { number: "09", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Australia" },
        { number: "02", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch610@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Pakistan" },
        { number: "04", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "United States" },
        { number: "03", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bangladesh" },
        { number: "06", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bhutan" },
        { number: "10", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "China" },
        { number: "05", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Indonesia" },
        { number: "07", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Argentina" },
        { number: "08", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "France" },
        { number: "01", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "India" },
        { number: "09", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Australia" },
        { number: "02", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch610@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Pakistan" },
        { number: "04", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "United States" },
        { number: "03", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bangladesh" },
        { number: "06", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bhutan" },
        { number: "10", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "China" },
        { number: "05", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Indonesia" },
        { number: "01", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "India" },
        { number: "09", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Australia" },
        { number: "02", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch610@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Pakistan" },
        { number: "04", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "United States" },
        { number: "03", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bangladesh" },
        { number: "06", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bhutan" },
        { number: "10", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "China" },
        { number: "05", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Indonesia" },
        { number: "01", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "India" },
        { number: "09", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Australia" },
        { number: "02", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch610@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Pakistan" },
        { number: "04", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "United States" },
        { number: "03", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bangladesh" },
        { number: "06", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bhutan" },
        { number: "10", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "China" },
        { number: "05", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Indonesia" },
        { number: "01", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "India" },
        { number: "09", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Australia" },
        { number: "02", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch610@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Pakistan" },
        { number: "04", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "United States" },
        { number: "03", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bangladesh" },
        { number: "06", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Bhutan" },
        { number: "10", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "China" },
        { number: "05", cm_id: "001", cm_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", zm: "650", fund: "220", investment: "688", country: "Indonesia" },
        
    ])



    return (
        <>

            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' mb={"5px"}>
                                    <Typography variant='h5' className='fw500 bl'> Hello, Country Manager </Typography>
                                </Box>
                            </Grid>

                            <Grid
                                container
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                            >
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <Typography variant='h6' className='fw500 bl' > Assigned CM List </Typography>
                                </Grid>


                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <ul id='searchportion' style={{marginBottom:'-8px'}}>
                                        <li>
                                            <Box className='bt al_right'  >
                                                <Button variant="contained" className='btn bl_bttn' size='small' > Deactivate </Button>
                                            </Box>
                                        </li>

                                        <li>
                                            <div class="form-group has-search">
                                                <span class="form-control-feedback"><SearchIcon /></span>
                                                <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                            </div>
                                        </li>

                                        <li>
                                            <IconButton>
                                                <Tooltip title="Download">
                                                <GetAppIcon className='col1' />
                                                </Tooltip>
                                            </IconButton>
                                        </li>

                                    </ul>
                                </Grid>

                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '62vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination={true}
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>
                            </Grid>



                        </Box>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1}>
                                <Link to='/ifa_existing_team' className="link">
                                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                </Link>
                                <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                            </Box>
                        </Grid>

                    </Box>
                </Container>
            </Box>

        </>
    );
}
