import React from 'react';
import { Box, Container, Grid, Button, Typography, IconButton, TextField, Tooltip, InputAdornment } from '@material-ui/core'; 
import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import GetAppIcon from '@material-ui/icons/GetApp';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { Link } from 'react-router-dom'; 
import Autocomplete from '@material-ui/lab/Autocomplete';


import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';


const chooseopt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]

export default function SMS() {

 
    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState("12/12/2025");

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex: 1
    }

    const columnDefs = [
        {
            headerName: 'Sr No.', field: 'number', minWidth: 60, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true,
        },
        { headerName: 'Investor Name', field: 'name', minWidth: 150, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Mobile Number', field: 'email', minWidth: 150, align: 'center', cellStyle: { textAlign: 'left' } },
        { headerName: 'Status', field: 'status', minWidth: 125, align: 'center', cellStyle: { textAlign: 'center' }, cellRendererFramework: (params) => <CheckCircleIcon size="large" style={{ color: 'green' }} />, },

    ]


    const [rowData] = useState([
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
          {
            name: 'XYZ', email: '8888002200', status: '', 
        },  {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },
        {
            name: 'XYZ', email: '8888002200', status: '', 
        },


    ])



    return (
        <>

            <Box component="section">
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' mb={"5px"}>
                                    <Typography variant='h5' className='bl fw500'> Existing Investors Names </Typography>
                                </Box>
                            </Grid>
 

                            <Grid
                                container
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                            >



                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <ul id='searchportion' style={{marginBottom: '-8px'}}>

                                    <li>
                                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='datepic textfield'>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="MM/dd/yyyy"
                                                    id="date-picker-inline"
                                                    placeholder="Commencement Date"
                                                    value={selectedDate}
                                                    onChange={handleDateChange}
                                                    KeyboardButtonProps={{
                                                        'aria-label': 'change date',
                                                    }}
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Box>
                                    </Grid>
                                    </li>

                                    <li>
                                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='datepic textfield'>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="MM/dd/yyyy"
                                                    id="date-picker-inline"
                                                    placeholder="Commencement Date"
                                                    value={selectedDate}
                                                    onChange={handleDateChange}
                                                    KeyboardButtonProps={{
                                                        'aria-label': 'change date',
                                                    }}
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Box>
                                    </Grid>
                                    </li>

                                        <li>
                                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                                <Box className='textfield' >
                                                    <Autocomplete
                                                        id="combo-box-demo"
                                                        options={chooseopt}
                                                        getOptionLabel={(option) => option.title}
                                                        renderInput={(params) => <TextField {...params} label="Select Report" variant="filled" />}
                                                    />
                                                </Box>
                                            </Grid>
                                        </li>


                                        <li>
                                            <div class="form-group has-search">
                                                <span class="form-control-feedback"><SearchIcon /></span>
                                                <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                            </div>
                                        </li>
 

{/* <li>
<Box className='textfield'>
<TextField id="filled-basic" className='filleddp' variant="filled" placeholder="Registered Email ID" fullWidth 
onChange={onFilterTextChange}
InputProps={{
    startAdornment: (
    <InputAdornment position="start">
    <SearchIcon />
    </InputAdornment>
    ),
    }}
    />
</Box>
</li> */}


                                        <li>
                                            <IconButton>
                                                <Tooltip title="Download">
                                                <GetAppIcon className='col1' />
                                                </Tooltip>
                                            </IconButton>
                                        </li>


                                    </ul>
                                </Grid>

                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '55vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight}
                                            rowSelection={'multiple'}
                                            pagination='true'
                                            suppressRowClickSelection={true}
                                        />
                                    </div>
                                </Box>
                            </Grid>


                            <Grid container spacing={1} alignItems="top">


                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='bt al_right' >

                                        <Link to='#' className="link">
                                            <Button variant="contained" className='al_center btn bl_bttn' size='small' > Send Updates </Button>
                                        </Link>

                                        <Link to='#' className="link">
                                            <Button variant="contained" className='al_center btn bl_bttn' size='small' > Next </Button>
                                        </Link>
                                    </Box>
                                </Grid>
                            </Grid>


                        </Box>



                    </Box>
                </Container>
            </Box>
 

        </>
    );
}
