import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, AppBar, Tabs, Tab, Typography, } from '@material-ui/core';
import Emails from './Emails';
import SMS from './SMS';

function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`scrollable-auto-tabpanel-${index}`}
            aria-labelledby={`scrollable-auto-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}






export default function Bulk_Reporting() {


    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };



    return (
        <>
            <Box className='codingpagestart'>

                <Box className='  sti' component="section" style={{}}>
                    <Container className='containerwidth'>
                        <Box className='st_middle fr_sec'>
                            <Grid container spacing={0} alignItems="center">
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='maintabbedsection'>
                                        <AppBar position="static" className="tabbedbar">
                                            <Tabs
                                                value={value}
                                                onChange={handleChange}
                                                indicatorColor="none"
                                                textColor="primary"
                                                variant="scrollable"
                                                scrollButtons="auto"
                                                aria-label="scrollable auto tabs example"
                                            >
                                                <Tab label="Emails" {...a11yProps(0)} />
                                                <Tab label="SMS"{...a11yProps(1)} />
                                            </Tabs>
                                        </AppBar>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                    </Container>
                </Box>


                <Box component="section" mt={1} className='tabbedinfo'>

                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <TabPanel value={value} index={0} className="ddtab">
                            <Emails />
                        </TabPanel>

                        <TabPanel value={value} index={1} className="ddtab">
                            <SMS />
                        </TabPanel>

                    </Box>

                </Box>


            </Box>



        </>
    );
}
