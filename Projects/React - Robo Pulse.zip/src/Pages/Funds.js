import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Typography, FormLabel, RadioGroup, AppBar, FormControlLabel, Radio, Tabs, Tab, Button, Grid, TextField, Tooltip, FormControl, InputLabel, IconButton, Select, MenuItem, Divider, List, ListItem, ListItemText, ListItemAvatar, Avatar, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward'; 

import { Link } from 'react-router-dom';

import ArrowBackIcon from '@material-ui/icons/ArrowBack';
 
  
import P1A from "../asset/images/riskquestion/pmg_1.svg";
import P1B from "../asset/images/riskquestion/pmg_1h.svg"; 

import P2A from "../asset/images/riskquestion/pmg_2.svg";
import P2B from "../asset/images/riskquestion/pmg_2h.svg";

import P3A from "../asset/images/riskquestion/pmg_3.svg";
import P3B from "../asset/images/riskquestion/pmg_3h.svg";

import P4A from "../asset/images/riskquestion/pmg_4.svg";
import P4B from "../asset/images/riskquestion/pmg_4h.svg";

import P5A from "../asset/images/riskquestion/pmg_5.svg";
import P5B from "../asset/images/riskquestion/pmg_5h.svg";

import P6A from "../asset/images/riskquestion/pmg_6.svg";
import P6B from "../asset/images/riskquestion/pmg_6h.svg";

import P7A from "../asset/images/riskquestion/pmg_7.svg";
import P7B from "../asset/images/riskquestion/pmg_7h.svg";

import P8A from "../asset/images/riskquestion/pmg_8.svg";
import P8B from "../asset/images/riskquestion/pmg_8h.svg";

import P9A from "../asset/images/riskquestion/pmg_9.svg";
import P9B from "../asset/images/riskquestion/pmg_9h.svg";

import P10A from "../asset/images/riskquestion/pmg_10.svg";
import P10B from "../asset/images/riskquestion/pmg_10h.svg";

 

export default function Funds() {
 

  return (
    <>

  


      <Box component="section"  className='tabbedinfo codingpagestart'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

         
              <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">


                  <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className= "al_left brd1" >
                                          <Box mb={1}>
                                                <Typography variant='h5' className=' bl' > Funds </Typography>
                                          </Box>
                                        </Box>
                                    </Grid>

<Grid item lg={12} md={12} sm={12} xs={12}>
<RadioGroup row aria-label="position" name="position" defaultValue="top">           

<Box className="options_box" pb={5} pt={5}>
      <Grid container spacing={1} alignItems="center" justifyContent='center'>

      <Grid item lg={2} md={4} sm={6} xs={12}>
      <Box className="option_box1 al_center">
      <Box class="flip-container" for="radio1">
      <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
      <Box class="flipper">
      <p align="center"><img src={ P1A } className='front' width={100} alt="fliper" /></p>
      <p align="center" className='back'><img src={ P1B } width={100} alt="fliper"/></p>
      </Box>
      </div>
      <FormControlLabel
      value="Index Fund"
      control={<Radio color="primary" />}
      label="Index Fund"
      labelPlacement="bottom"
      />
      </Box>
      </Box> 
      </Grid>

      <Grid item lg={2} md={4} sm={6} xs={12}>
      <Box className="option_box1 al_center">
      <Box class="flip-container" for="radio1">
      <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
      <Box class="flipper">
      <p align="center"><img src={ P1A } className='front' width={100} alt="fliper" /></p>
      <p align="center" className='back'><img src={ P1B } width={100} alt="fliper"/></p>
      </Box>
      </div>
      <FormControlLabel
      value="Hybrid funds"
      control={<Radio color="primary" />}
      label="Hybrid funds"
      labelPlacement="bottom"
      />
      </Box>
      </Box> 
      </Grid>

      <Grid item lg={2} md={4} sm={6} xs={12}>
      <Box className="option_box1 al_center">
      <Box class="flip-container" for="radio1">
      <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
      <Box class="flipper">
      <p align="center"><img src={ P1A } className='front' width={100} alt="fliper" /></p>
      <p align="center" className='back'><img src={ P1B } width={100} alt="fliper"/></p>
      </Box>
      </div>
      <FormControlLabel
      value="Tax Saving Funds"
      control={<Radio color="primary" />}
      label="Tax Saving Funds"
      labelPlacement="bottom"
      />
      </Box>
      </Box> 
      </Grid>

      <Grid item lg={2} md={4} sm={6} xs={12}>
      <Box className="option_box1 al_center">
      <Box class="flip-container" for="radio1">
      <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
      <Box class="flipper">
      <p align="center"><img src={ P1A } className='front' width={100} alt="fliper" /></p>
      <p align="center" className='back'><img src={ P1B } width={100} alt="fliper"/></p>
      </Box>
      </div>
      <FormControlLabel
      value="Bond Funds"
      control={<Radio color="primary" />}
      label="Bond Funds"
      labelPlacement="bottom"
      />
      </Box>
      </Box> 
      </Grid>

      <Grid item lg={2} md={4} sm={6} xs={12}>
      <Box className="option_box1 al_center">
      <Box class="flip-container" for="radio1">
      <div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
      <Box class="flipper">
      <p align="center"><img src={ P1A } className='front' width={100} alt="fliper" /></p>
      <p align="center" className='back'><img src={ P1B } width={100} alt="fliper"/></p>
      </Box>
      </div>
      <FormControlLabel
      value="NFO"
      control={<Radio color="primary" />}
      label="NFO"
      labelPlacement="bottom"
      />
      </Box>
      </Box> 
      </Grid>

      </Grid>
</Box>

<Box className="options_box" pb={5} pt={5}>
<Grid container spacing={1} alignItems="center" justifyContent='center'>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P6A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P6B } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="SIP with 500"
control={<Radio color="primary" />}
label="SIP with 500"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P7A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P7B } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Gold"
control={<Radio color="primary" />}
label="Gold"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P8A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P8B } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Equity"
control={<Radio color="primary" />}
label="Equity"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>

<Grid item lg={2} md={4} sm={6} xs={12}>
<Box className="option_box1 al_center">
<Box class="flip-container" for="radio1">
<div id="customoptions_image_0_0" data-id="radio1" title="" onClick="return false;" >
<Box class="flipper">
<p align="center"><img src={ P9A } className='front' width={100} alt="fliper" /></p>
<p align="center" className='back'><img src={ P9B } width={100} alt="fliper"/></p>
</Box>
</div>
<FormControlLabel
value="Money Market"
control={<Radio color="primary" />}
label="Money Market"
labelPlacement="bottom"
/>
</Box>
</Box>
</Grid>




</Grid>
</Box>

</RadioGroup>  
</Grid> 


<Grid item lg={12} md={12} sm={12} xs={12}>
  <Box className='brd1'></Box>
</Grid>

 
                </Grid>
              </Box>

 
          </Box>
        </Container>
      </Box>




    </>
  );
}
