import React from 'react';
import { Box, Container, Grid, Button, Typography, Tooltip, IconButton, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack'; 
import GetAppIcon from '@material-ui/icons/GetApp';
import SearchIcon from '@material-ui/icons/Search';
import { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import { Link } from 'react-router-dom';


export default function IFA_assigned_agent_list() {

    const [gridApi, setGridApi] = useState(null);
    const [setGridColumnApi] = useState(null);
    const rowHeight = 22;
    const headerHeight = 25;

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }

    const onFilterTextChange = (e) => {
        gridApi.setQuickFilter(e.target.value)
    }


    const defaultColDef = {
        sortable: true, checkboxSelection: false, resizable: true, autoHeight: true
        , filter: true, flex: 1
    }

    const columnDefs = [
        {
            headerName: 'Sr No.', field: 'number', minWidth: 115, headerCheckboxSelection: true,
            checkboxSelection: true,
            showDisabledCheckboxes: true, 
        },
        { headerName: 'Agent Id', field: 'agent_id', minWidth: 110, },
        { headerName: 'Agent Name', field: 'agent_name', minWidth: 160, },
        { headerName: 'Contact', field: 'contact', minWidth: 125, },
        { headerName: 'Email Id', field: 'email', minWidth: 160, },
        { headerName: 'Total AUM', field: 'aum', minWidth: 125, },
        { headerName: 'No. of Clients', field: 'clients', minWidth: 150, },
        { headerName: 'Total Fund', field: 'fund', minWidth: 150, },
        { headerName: 'Total Invested Amount (RS)', field: 'investment', minWidth: 180, },
        { headerName: 'Branch', field: 'branch', minWidth: 160, },
        { headerName: 'City', field: 'city', minWidth: 160, },
    ]


    const [rowData] = useState([
        { number: "01", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980",   clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "09", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "02", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "04", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "03", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "06", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "10", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "05", agent_id: "001", agent_name: "John Witch", contact: "+91 9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "07", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "08", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },

        { number: "01", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "09", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "02", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "04", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "03", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "06", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "10", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "05", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "07", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "08", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },

        { number: "01", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "abc@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "09", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "john@gmail.com", aum: "980", clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "02", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "04", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "03", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "06", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "10", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "05", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
        { number: "07", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Mumbai Branch", city: "Mumbai", investment: "688", },
        { number: "08", agent_id: "001", agent_name: "John Witch", contact: "9889002257", email: "johnwitch@gmail.com", aum: "980",  clients: "650", fund: "220", branch: "Nashik Branch", city: "Nashik", investment: "688", },
    ])



    return (
        <>

            <Box component="section"  className='codingpagestart'>
                <Container className='containerwidth'>
                    <Box id='gridico' className='whitebx maintabbedsection mb_n'>

                        <Box className='wh_bx' pb={2}>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='brd1' mb={"5px"}>
                                    <Typography variant='h5' className='bl fw500'> Hello, Agent Name </Typography>
                                </Box>
                            </Grid>
  
                            <Grid
                                container
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                            >
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <Typography variant='h6' className='fw500 bl' > Assigned Agents List </Typography>
                                </Grid>

                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <ul id='searchportion' style={{marginBottom: '-8px'}}>
                                        <li>
                                            <Box className='bt al_right'  >
                                                <Button variant="contained" className='btn bl_bttn' size='small' > Assign CM </Button>
                                            </Box>
                                        </li>

                                        <li>
                                            <div class="form-group has-search">
                                                <span class="form-control-feedback"><SearchIcon /></span>
                                                <input type="Search" onChange={onFilterTextChange} class="form-control" placeholder="Search" />
                                            </div>
                                        </li>

                                        <li>
                                            <IconButton>
                                                <Tooltip title="Download">
                                                    <GetAppIcon className='col1' />
                                                </Tooltip>
                                            </IconButton>
                                        </li>

                                    </ul>
                                </Grid>

                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Box className='dpacloud_table  tbheading' >
                                    <div id='myGrid' style={{ height: '62vh', width: '100%', padding: "5px 0px" }} className="ag-theme-alpine" >
                                        <AgGridReact
                                            onGridReady={onGridReady}
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowHeight={rowHeight}
                                            headerHeight={headerHeight} 
                                            pagination='true' 
                                        />
                                    </div>
                                </Box>
                            </Grid>



                        </Box>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className='bt al_right' mt={1} >
                                <Link to='/ifa_existing_team' className="link">
                                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                                </Link>
                                <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                            </Box>
                        </Grid>

                    </Box>
                </Container>
            </Box>

        </>
    );
}
