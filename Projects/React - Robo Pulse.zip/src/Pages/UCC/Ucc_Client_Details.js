import React from 'react';
import { Box, Grid, Button, Typography, TextField, Divider, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';


import Autocomplete from '@material-ui/lab/Autocomplete';
 

const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]





export default function Ucc_Client_Details() {



    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState(new Date());

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    return (
        <>


            <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='brd1 flx_sa p0' > 
                                <Typography variant='h5' className=' bl' > Client Details </Typography> 
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Client Code" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Member Code" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Corp Branch" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Tax Status" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Holding Nature" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Primary Holder First Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Primary Holder Second Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Primary Holder Last Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='datepic'>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    disableToolbar
                                    variant="inline"
                                    format="MM/dd/yyyy"
                                    id="date-picker-inline"
                                    placeholder="Primary Holder DOB"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </MuiPickersUtilsProvider>
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Active" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Gender" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Divider />
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Gaurdian First Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Gaurdian Middle Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Gaurdian Last Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='datepic'>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    disableToolbar
                                    variant="inline"
                                    format="MM/dd/yyyy"
                                    id="date-picker-inline"
                                    placeholder="Gaurdian DOB"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </MuiPickersUtilsProvider>
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Secondary Holder First Name*" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Secondary Holder Middle Name*" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Secondary Holder Last Name*" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='datepic'>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    disableToolbar
                                    variant="inline"
                                    format="MM/dd/yyyy"
                                    id="date-picker-inline"
                                    placeholder="Secondary Holder DOB"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </MuiPickersUtilsProvider>
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Holder First Name*" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Holder Middle Name*" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Holder Last Name*" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='datepic'>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    disableToolbar
                                    variant="inline"
                                    format="MM/dd/yyyy"
                                    id="date-picker-inline"
                                    placeholder="Third Holder DOB"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </MuiPickersUtilsProvider>
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Occupation Code" fullWidth />
                        </Box>
                    </Grid>
                </Grid>
            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
            </Grid>

        </>
    );
}
