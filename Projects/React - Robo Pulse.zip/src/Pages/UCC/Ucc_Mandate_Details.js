import React from 'react';
import { Box, Grid, Button, Typography, TextField, } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';
import RotateLeftOutlinedIcon from '@material-ui/icons/RotateLeftOutlined';
import SaveOutlinedIcon from '@material-ui/icons/SaveOutlined';
import Autocomplete from '@material-ui/lab/Autocomplete';

const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]


export default function Ucc_Mandate_Details() {

    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState(new Date());
    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    return (
        <>


            <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='brd1 flx_sa p0' > 
                                <Typography variant='h5' className=' bl' > Mandate Registration </Typography> 
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Client Code" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Client Name" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Amount" fullWidth />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Bank Name" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="IFSC" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Account Number" variant="filled" />}
                            />
                        </Box>
                    </Grid>






                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Account Type" fullWidth />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="MICR Number" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='datepic'>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    disableToolbar
                                    variant="inline"
                                    format="MM/dd/yyyy"
                                    id="date-picker-inline"
                                    placeholder="Third Holder DOB"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </MuiPickersUtilsProvider>
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='datepic'>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    disableToolbar
                                    variant="inline"
                                    format="MM/dd/yyyy"
                                    id="date-picker-inline"
                                    placeholder="Third Holder DOB"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </MuiPickersUtilsProvider>
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Mandate Type" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                </Grid>
            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn gr_bttn' size='small' endIcon={<RotateLeftOutlinedIcon />}> Reset </Button>

                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<SaveOutlinedIcon />}> Save </Button>
                </Box>
            </Grid>



        </>
    );
}
