import React from 'react'; 
import { Box, Grid, Button, Typography, TextField, Tooltip} from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import RotateLeftOutlinedIcon from '@material-ui/icons/RotateLeftOutlined';
import BackupOutlinedIcon from '@material-ui/icons/BackupOutlined';
import Autocomplete from '@material-ui/lab/Autocomplete';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';


const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]


export default function Ucc_Scan_Mandate() {
 

    return (
        <>


            <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='brd1 flx_sa p0' > 
                                <Typography variant='h5' className=' bl' > Upload Scan Mandate </Typography> 
                        </Box>
                    </Grid>
                </Grid>



                <Box pb={2}>
                    <Grid container spacing={1} alignItems="top">


                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            <Box className='alltxfield'>
                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Member Code" fullWidth />
                            </Box>
                        </Grid>


                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            <Box className='alltxfield'>
                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Client Code" fullWidth />
                            </Box>
                        </Grid>


                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            <Box className='alltxfield'>
                                <TextField id="filled-basic" className='filleddp' variant="filled" label="Client Name" fullWidth />
                            </Box>
                        </Grid>

                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            <Box className='textfield' >
                                <Autocomplete
                                    id="combo-box-demo"
                                    options={Random_Opt}
                                    getOptionLabel={(option) => option.title}
                                    renderInput={(params) => <TextField {...params} label="Mandate Type" variant="filled" />}
                                />
                            </Box>
                        </Grid>


                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            <Box className='textfield' >
                                <Autocomplete
                                    id="combo-box-demo"
                                    options={Random_Opt}
                                    getOptionLabel={(option) => option.title}
                                    renderInput={(params) => <TextField {...params} label="Mandate ID" variant="filled" />}
                                />
                            </Box>
                        </Grid>


                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            <Box className='textfield' >
                                <Autocomplete
                                    id="combo-box-demo"
                                    options={Random_Opt}
                                    getOptionLabel={(option) => option.title}
                                    renderInput={(params) => <TextField {...params} label="Utility Code" variant="filled" />}
                                />
                            </Box>
                        </Grid>

                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            <Box className='textfield' >
                                <Autocomplete
                                    id="combo-box-demo"
                                    options={Random_Opt}
                                    getOptionLabel={(option) => option.title}
                                    renderInput={(params) => <TextField {...params} label="Agency Name" variant="filled" />}
                                />
                            </Box>
                        </Grid>


                        <Grid item lg={3} md={6} sm={12} xs={12}>
                            
                            <Box className='uploadfile' mt={1}>
                                <input type="file" class="input-file" />
                            </Box>
                            
                        </Grid>

                    </Grid>
                </Box>

            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn gr_bttn' size='small' endIcon={<RotateLeftOutlinedIcon />}> Reset </Button>

                    <Button variant="contained" className='al_center btn bl_bttn' size='small'  > Upload </Button>
                </Box>
            </Grid>


        </>
    );
}
