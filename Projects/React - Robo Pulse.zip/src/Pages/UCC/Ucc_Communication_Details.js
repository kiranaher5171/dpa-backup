import React from 'react';
import PropTypes from 'prop-types';
import { Box, Grid, AppBar, Tabs, Tab, Button, Typography, TextField, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';
import Autocomplete from '@material-ui/lab/Autocomplete';


function TabPanel(props) {
    const { children, value, index, ...other } = props;
    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`scrollable-auto-tabpanel-${index}`}
            aria-labelledby={`scrollable-auto-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={0} pt={2} pb={0}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]





export default function Ucc_Communication_Details() {



    // Datepicker
    const [selectedDate, setSelectedDate] = React.useState(new Date());
    const handleDateChange = (date) => {
        setSelectedDate(date);
    };
    // Datepicker


    const [value2, setValue2] = React.useState(0);
    const handleChange2 = (event, newValue) => {
        setValue2(newValue);
    };


    return (
        <>


            <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='brd1 flx_sa p0' > 
                                <Typography variant='h5' className=' bl' > Communication Details </Typography> 
                        </Box>
                    </Grid>
                </Grid>



                <Box className='secondtabbedsection'>
                    <Grid container spacing={1} alignItems="top">
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <AppBar position="static" className="tabbedbar">
                                <Tabs
                                    value={value2}
                                    onChange={handleChange2}
                                    indicatorColor="none"
                                    textColor="primary"
                                    variant="scrollable"
                                    scrollButtons="auto"
                                    aria-label="scrollable auto tabs example"
                                >
                                    <Tab disableRipple label=" India " {...a11yProps(0)} />
                                    <Tab disableRipple label=" Foreign " {...a11yProps(1)} />
                                    <Tab disableRipple label="Nominee Details" {...a11yProps(2)} />
                                </Tabs>
                            </AppBar>
                        </Grid>
                    </Grid>
                </Box>



                <TabPanel value={value2} index={0} className="ddtab">
                    <Box pb={2}>
                        <Grid container spacing={1} alignItems="top">


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Address Line 1" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Address Line 2" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Address Line 3" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="City" fullWidth />
                                </Box>
                            </Grid>





                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Pincode" fullWidth />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="State" variant="filled" />}
                                    />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="Country" variant="filled" />}
                                    />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Residence Phone" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Residence Fax" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Office Phone" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Office Fax" fullWidth />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Communication Mode" fullWidth />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Email" fullWidth />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Mobile" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="Email Declaration Flag" variant="filled" />}
                                    />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="Mobile Declaration Flag" variant="filled" />}
                                    />
                                </Box>
                            </Grid>


                        </Grid>
                    </Box>
                </TabPanel>


                <TabPanel value={value2} index={1} className="ddtab">
                    <Box pb={2}>
                        <Grid container spacing={1} alignItems="top">


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Address Line 1" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Address Line 2" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Address Line 3" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="City" fullWidth />
                                </Box>
                            </Grid>





                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Pincode" fullWidth />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="State" variant="filled" />}
                                    />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="Country" variant="filled" />}
                                    />
                                </Box>
                            </Grid>

                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Residence Phone" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Residence Fax" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Office Phone" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Office Fax" fullWidth />
                                </Box>
                            </Grid>


                        </Grid>
                    </Box>
                </TabPanel>

                <TabPanel value={value2} index={2} className="ddtab">
                    <Box pb={2}>
                        <Grid container spacing={1} alignItems="top">


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="First Nominee Name" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="First Nominee Relationship" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="First Nominee Applicable" fullWidth />
                                </Box>
                            </Grid>



                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="First Nominee Minor Flag" variant="filled" />}
                                    />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Second Nominee Name" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Second Nominee Relationship" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Second Nominee Applicable" fullWidth />
                                </Box>
                            </Grid>



                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="Second Nominee Minor Flag" variant="filled" />}
                                    />
                                </Box>
                            </Grid>



                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Nominee Name" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Nominee Relationship" fullWidth />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Nominee Applicable" fullWidth />
                                </Box>
                            </Grid>



                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='textfield' >
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={Random_Opt}
                                        getOptionLabel={(option) => option.title}
                                        renderInput={(params) => <TextField {...params} label="Third Nominee Minor Flag" variant="filled" />}
                                    />
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='datepic'>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <KeyboardDatePicker
                                            disableToolbar
                                            variant="inline"
                                            format="MM/dd/yyyy"
                                            id="date-picker-inline"
                                            placeholder="Third Holder DOB"
                                            value={selectedDate}
                                            onChange={handleDateChange}
                                            KeyboardButtonProps={{
                                                'aria-label': 'change date',
                                            }}
                                        />
                                    </MuiPickersUtilsProvider>
                                </Box>
                            </Grid>



                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                <Box className='alltxfield'>
                                    <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Nominee Gaurdian Name" fullWidth />
                                </Box>
                            </Grid>


                        </Grid>
                    </Box>
                </TabPanel>


            </Box>


            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
            </Grid>


        </>
    );
}
