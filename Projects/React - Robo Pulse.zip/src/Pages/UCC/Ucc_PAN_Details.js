import React from 'react';
import { Box, Grid, Button, Typography, TextField, Divider, } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import Autocomplete from '@material-ui/lab/Autocomplete';


const Random_Opt = [
    { title: 'Option 1' },
    { title: 'Option 2' },
    { title: 'Option 3' },
    { title: 'Option 4' },
    { title: 'Option 5' },
    { title: 'Option 6' },
]


export default function Ucc_PAN_Details() {
 
    return (
        <>


            <Box className='wh_bx' pb={2}>
                <Grid container spacing={1} alignItems="top">

                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='brd1 flx_sa p0' > 
                                <Typography variant='h5' className=' bl' > PAN Details </Typography> 
                        </Box>
                        <Box mt={1}>
                            <Typography variant='h6' className='bk'> If hoding type is "Joint" or "Anyone or Superior" & three holders are there  </Typography>
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Primary Holder PAN Extend" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Primary Holder PAN" fullWidth />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Secondary Holder PAN Extend" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Secondary Holder PAN" fullWidth />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Third Holder PAN Extend" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Third Holder PAN" fullWidth />
                        </Box>
                    </Grid>




                    <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Divider />
                    </Grid>


                    <Grid item lg={12} md={12} sm={12} xs={12}> 
                            <Typography variant='h6' className='bk'> In case of minor </Typography> 
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Primary Holder PAN Extend" variant="filled" />}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Primary Holder PAN" fullWidth />
                        </Box>
                    </Grid>


                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='textfield' >
                            <Autocomplete
                                id="combo-box-demo"
                                options={Random_Opt}
                                getOptionLabel={(option) => option.title}
                                renderInput={(params) => <TextField {...params} label="Gaurdian PAN Extend" variant="filled" />}
                            />
                        </Box>
                    </Grid>

                    <Grid item lg={3} md={6} sm={12} xs={12}>
                        <Box className='alltxfield'>
                            <TextField id="filled-basic" className='filleddp' variant="filled" label="Gaurdian PAN" fullWidth />
                        </Box>
                    </Grid>


                </Grid>
            </Box>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='bt al_right' mt={1}>
                    <Button variant="contained" className='btn sk_bttn' size='small' startIcon={<ArrowBackIcon />}> Back </Button>
                    <Button variant="contained" className='al_center btn bl_bttn' size='small' endIcon={<ArrowForwardIcon />}> Save & Next </Button>
                </Box>
            </Grid>



        </>
    );
}
