import React from 'react';
import PropTypes from 'prop-types';
import { Box, Container, Grid, AppBar, Tabs, Tab, Typography, } from '@material-ui/core';  
import UccClientDetails from './Ucc_Client_Details';
import UccPANDetails from './Ucc_PAN_Details';
import UccDepositoryDetails from './Ucc_Depository_Details';
import UccBankDetails from './Ucc_Bank_Details';
import UccCommunicationDetails from './Ucc_Communication_Details';
import UccKYCDetails from './Ucc_KYC_Details';
import UccELOG from './Ucc_ELOG';
import UccMandateDetails from './Ucc_Mandate_Details';
import UccScanMandate from './Ucc_Scan_Mandate';


 
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    'aria-controls': `scrollable-auto-tabpanel-${index}`,
  };
}



export default function UCC() {
 
  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

 

  return (
    <>

<Box className='codingpagestart'>

      <Box className='sti' component="section" style={{}}>
        <Container className='containerwidth'>
          <Box className='st_middle fr_sec '>
            <Grid container spacing={0} alignItems="center">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className='maintabbedsection'>
                  <AppBar position="static" className="tabbedbar">
                    <Tabs
                      value={value}
                      onChange={handleChange}
                      indicatorColor="none"
                      textColor="primary"
                      variant="scrollable"
                      scrollButtons="auto"
                      aria-label="scrollable auto tabs example"
                    >
                      <Tab label="Client Details" {...a11yProps(0)} />
                      <Tab label="PAN Details"{...a11yProps(1)} />
                      <Tab label="Depository Details" {...a11yProps(2)} />
                      <Tab label="Bank Details" {...a11yProps(3)} />
                      <Tab label="Communication Details"{...a11yProps(4)} />
                      <Tab label="KYC Details" {...a11yProps(5)} />
                      <Tab label="Elog/Image Upload" {...a11yProps(6)} />
                      <Tab label="FATCA"{...a11yProps(7)} />
                      <Tab label="Mandate Registration" {...a11yProps(8)} />
                      <Tab label="Upload Scan Mandate" {...a11yProps(9)} />
                    </Tabs>
                  </AppBar>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>


      <Box component="section" mt={1} className='tabbedinfo'>
        <Container className='containerwidth'>
          <Box id='gridico' className='whitebx maintabbedsection mb_n'>

            <TabPanel value={value} index={0} className="ddtab">
              <UccClientDetails />
            </TabPanel>

            <TabPanel value={value} index={1} className="ddtab">
              <UccPANDetails />
            </TabPanel>



            <TabPanel value={value} index={2} className="ddtab">
              <UccDepositoryDetails />
            </TabPanel>


            <TabPanel value={value} index={3} className="ddtab">
              <UccBankDetails />
            </TabPanel>

            <TabPanel value={value} index={4} className="ddtab">
              <UccCommunicationDetails />
            </TabPanel>

            <TabPanel value={value} index={5} className="ddtab">
              <UccKYCDetails />
            </TabPanel>

            
            <TabPanel value={value} index={6} className="ddtab">
              <UccELOG />
            </TabPanel>

            <TabPanel value={value} index={7} className="ddtab">
              Comming Soon
            </TabPanel>

            <TabPanel value={value} index={8} className="ddtab">
              <UccMandateDetails />
            </TabPanel>

            <TabPanel value={value} index={9} className="ddtab">
              <UccScanMandate />
            </TabPanel>
 
          </Box>
        </Container>
      </Box>



      </Box>

    </>
  );
}
