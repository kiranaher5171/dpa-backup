import { Container, Grid, Typography, Box, } from '@material-ui/core';
import { Link } from 'react-router-dom';

export default function Footer() {

const currentYear = new Date().getFullYear();

    return (
        <div>
            <Box className='footer' component="section" style={{ backgroundColor: '#fff' }}>
                <Container className='containerwidth'>
                    <Grid container>
                        <Grid item lg={6} sm={7} xs={12}>
                            <Typography className='footer_one_text'>
                                Copyright © {currentYear} Decimal Point Analytics Pvt. Ltd
                            </Typography>
                        </Grid>
                        <Grid item lg={6} sm={5} xs={12}>
                            <Typography className='al_right gry'>
                                <Link to="#" className='footer_two_text'>  Terms and Conditions  </Link> | <Link to="#" className='footer_two_text'>  Privacy Policy  </Link>
                            </Typography>

                        </Grid>
                    </Grid>
                </Container>
            </Box>

        </div>
    );
}
