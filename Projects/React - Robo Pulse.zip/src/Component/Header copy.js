import { AppBar, Toolbar, IconButton, Divider, MenuItem, List, ListItem, ListItemAvatar, ListItemText, Menu, Box, Container, Drawer, withStyles, Typography, } from '@material-ui/core';
import React from 'react';
import { useState } from 'react';
import Scroll from './Scroll'
import MenuIcon from '@material-ui/icons/Menu';
import dpalogo from "../asset/images/robopulse.svg";
import CloseIcon from '@mui/icons-material/Close';
import MuiAccordion from '@material-ui/core/Accordion';
import MuiAccordionSummary from '@material-ui/core/AccordionSummary';
import MuiAccordionDetails from '@material-ui/core/AccordionDetails';
import { Route, Switch, Link } from 'react-router-dom';
import FiberManualRecordIcon from '@material-ui/icons/FiberManualRecord';
import profile from "../asset/images/profile_pic.jpg";
import P2 from "../asset/images/riskquestion/notification.svg";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

import IM1 from "../asset/images/createaccount/m1.svg";
import IM2 from "../asset/images/createaccount/m4.svg";
import IM3 from "../asset/images/createaccount/m5.svg";
import IM4 from "../asset/images/createaccount/m6.svg";
import IM5 from "../asset/images/createaccount/m7.svg";
import IM6 from "../asset/images/createaccount/m8.svg";
import P1 from "../asset/images/riskquestion/profile_1.svg";
import P3 from "../asset/images/riskquestion/logout.svg";
import P4 from "../asset/images/createaccount/settings.svg";




import Sample from "../Pages/Sample";
import SignIn from '../Forms/SignIn';
import ForgotPassword from '../Forms/Forgot_pass';
import ResetPassword from '../Forms/Reset_pass';
import GetOtp from '../Forms/Get_otp';
import VerifyOtp from '../Forms/Verify_otp';
import SignUp from '../Forms/SignUp';


import Createaccount from "../Pages/IFA_Createaccount";
import IFAPartnerProfile from "../Pages/IFA_partner_profile";
import IFAProfile from "../Pages/IFA_profile";
import RMUpdateProfile from "../Pages/RM_update_profile";
import IFAExistingTeam from "../Pages/IFA_existing_team";
import IFAAddNewMember from '../Pages/IFA_add_new_member';
import IFAAssignedAgentList from '../Pages/IFA_assigned_agent_list';
import IFAAssignedcmList from '../Pages/IFA_assigned_cm_list';
import IFAViewClientMapping from '../Pages/IFA_view_client_mapping';
import IFAMappedClients from '../Pages/IFA_mapped_clients';
import UCC from '../Pages/UCC/Ucc';
import AUMReconciliation from '../Pages/Admin or Back Office/AUM_Reconciliation';
import AUMUnmatch from '../Pages/Admin or Back Office/AUM_Unmatch';
import AUMReconcile from '../Pages/Admin or Back Office/AUM_Reconcile';
import OMBranches from '../Pages/Operation Management/OM_Branches';
import OMZonal from '../Pages/Operation Management/OM_Zonal';
import OMZonalList from '../Pages/Operation Management/OM_Zonal_List';
import CMExistingInvlist from '../Pages/Client Management/Existing_Investor_List';
import BulkReporting from '../Pages/Email_Or_SMS/Bulk_Reporting';
import TMPurchaseHistory from '../Pages/Transaction Management/Purchase_history';
import PurchaseCards from '../Pages/Transaction Management/Purchase_Cards';
import PurchaseDetails from '../Pages/Transaction Management/Purchase_Details';
import InvestorProfile from '../Pages/Investor/Investor_Profile';
import InvestorRiskProfile1 from '../Pages/Investor/Investor_Risk_Profile_1';
import InvestorRiskProfile2 from '../Pages/Investor/Investor_Risk_Profile_2';
import InvestorRiskProfile3 from '../Pages/Investor/Investor_Risk_Profile_3';
import InvestorRiskProfile4 from '../Pages/Investor/Investor_Risk_Profile_4';
import InvestorRiskProfile5 from '../Pages/Investor/Investor_Risk_Profile_5';
import InvestorRiskProfile6 from '../Pages/Investor/Investor_Risk_Profile_6';
import InvestorPlanMyGoal from '../Pages/Investor/Investor_Plan_My_Goal';
import PMGPurchaseHome from '../Pages/Investor/Plan My Goal/PMG_Purchase_Home';
import PMGDashboard from '../Pages/Investor/Plan My Goal/PMG_Dashboard';

import InvestorTMRedumption from '../Pages/Investor/Investor_TM_Redumption';
import RMCreateAccount from '../Pages/RM_Create_Account';
import Success from '../Forms/Success';
import Funds from '../Pages/Funds';
import PartnerManagement from '../Pages/Partner Management/Partner_Management';
import PartnerProfile from '../Pages/Partner Management/Partner_Profile';
import AgentClientManagement from '../Pages/Agent_Client_Management';
import PMGPurchaseVehicle from '../Pages/Investor/Plan My Goal/PMG_Purchase_Vehicle';
import TMRedemption from '../Pages/Transaction Management/TM_Redemption';
import TMCancelledSIP from '../Pages/Transaction Management/TM_Cancelled_SIP';
import TMCancelledSIPCards from '../Pages/Transaction Management/TM_Cancelled_SIP_Cards';
import TMProceedCancellation from '../Pages/Transaction Management/TM_Proceed_Cancellation';



const Accordion = withStyles({
root: {
border: '0px solid rgba(0, 0, 0, .125)',
boxShadow: 'none',
'&:not(:last-child)': {
borderBottom: 0,
},
'&:before': {
display: 'none',
},
'&$expanded': {
margin: 'auto',
},
},
expanded: {},
})(MuiAccordion);


const AccordionSummary = withStyles({
root: {
borderBottom: '0px solid rgba(0, 0, 0, .125)',
marginBottom: -1,
minHeight: 46,
'&$expanded': {
minHeight: 46,
},
},
content: {
'&$expanded': {
margin: '0px 0',
},
},
expanded: {},
})(MuiAccordionSummary);


const AccordionDetails = withStyles((theme) => ({
root: {
padding: theme.spacing(0),
},
}))(MuiAccordionDetails);



export default function PrimarySearchAppBar() {



const [activePage, setActivePage] = useState('home');



const [anchorE1, setAnchorE1] = React.useState(null);

const handleClick1 = (event) => {
setAnchorE1(event.currentTarget);
};

const handleClose1 = () => {
setAnchorE1(null);
};



const [anchorE2, setAnchorE2] = React.useState(null);

const handleClick2 = (event) => {
setAnchorE2(event.currentTarget);
};

const handleClose2 = () => {
setAnchorE2(null);
};



const [state, setState] = React.useState({
});

const toggleDrawer = (anchor, open) => (event) => {
if (event.type === 'right' && (event.key === 'right')) {
return;
}

setState({ ...state, [anchor]: open });
};






const [expanded, setExpanded] = React.useState('false');

const handleChange = (panel) => (event, newExpanded) => {
setExpanded(newExpanded ? panel : false);
};

const list = (anchor) => (

<Box id='drawer' className='mobilemenuview' sx={{ width: 300 }} role="presentation">


<Box mb={'5px'} mt={1} mr={2} className='al_right'>
<IconButton className='Close_btn' variant="contained" onClick={toggleDrawer(anchor, false)}>
<CloseIcon fontSize='small' color='primary' />
</IconButton>
</Box>

<Box >
 
{/* <a
href="#home"
className={activePage === 'home' ? 'active' : ''}
onClick={() => setActivePage('home')}
>
Home
</a> */}

{/* Main Drawer Content Start from Here */}
<List id="drawerlist">
<Divider />
 
<ListItem className='drawerlist' pl={2} button component={Link} to="/createaccount" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM1} width={30} className='menuicons' />
</ListItemAvatar>
{/* <ListItemText primary="IFA Create A/C" /> */}
<Typography className={activePage === 'IFA_Create' ? 'active' : ''}
onClick={() => setActivePage('IFA_Create')} > IFA Create A/C </Typography>
</ListItem>
 
<Divider />
 
<ListItem className='drawerlist' pl={2} button component={Link} to="/ifa_profile" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
{/* <ListItemText primary="IFA Profile" /> */}
<Typography className={activePage === 'IFA_Profile' ? 'active' : ''}
onClick={() => setActivePage('IFA_Profile')} > IFA Profile </Typography>
</ListItem> 

<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/ifa_partner_profile" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
{/* <ListItemText primary="IFA Partner Update Profile" /> */}
<Typography className={activePage === 'IFA_Partner_pro' ? 'active' : ''}
onClick={() => setActivePage('IFA_Partner_pro')} > IFA Partner Update Profile </Typography>
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/rm_update_profile" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
{/* <ListItemText primary="RM Update Profile" /> */}
<Typography className={activePage === 'RM_Update_Profile' ? 'active' : ''}
onClick={() => setActivePage('RM_Update_Profile')} > RM Update Profile </Typography>
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/ucc" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM4} width={30} className='menuicons' />
</ListItemAvatar>
{/* <ListItemText primary="UCC" /> */}
<Typography variant='subtitle1' className={activePage === 'UCC' ? 'active' : ''}
onClick={() => setActivePage('UCC')} > UCC </Typography>
</ListItem>
<Divider />

<Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel1bh-content"
id="panel1bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM5} width={30} className='menuicons' />
</ListItemAvatar>
{/* <ListItemText primary="Admin/Back Office" /> */}
<Typography variant='subtitle1' className={activePage === 'Admin/Back Office' ? 'active' : ''}
onClick={() => setActivePage('Admin/Back Office')} > Admin/Back Office </Typography>
</AccordionSummary>
<AccordionDetails className='dropdnpadding'>
<List disablePadding>
<ListItem button className='down_option' component={Link} to="/coming_soon" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" /> Category wise AUM</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/aum_reconciliation" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" /> AUM Reconciliation</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/ifa_SIPbook" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" /> SIP Book</ListItemText>
</ListItem>
</List>

</AccordionDetails>
</Accordion>
<Divider />

<Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel2bh-content"
id="panel2bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Team Management" />
</AccordionSummary>
<AccordionDetails>

<List disablePadding>
<ListItem button className='down_option' component={Link} to="/ifa_existing_team" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Existing Team Members</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/ifa_view_client_mapping" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />View client mapping</ListItemText>
</ListItem>
</List>
</AccordionDetails>
</Accordion>
<Divider />

<Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel3bh-content"
id="panel3bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM3} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Operation management" />
</AccordionSummary>
<AccordionDetails>

<List disablePadding>
<ListItem button className='down_option' component={Link} to="/om_branches" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Branches</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/om_zonal" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Zonal/Region</ListItemText>
</ListItem>
</List>

</AccordionDetails>
</Accordion>
<Divider />

<Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel4bh-content"
id="panel4bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM4} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Client Management" />
</AccordionSummary>
<AccordionDetails className='dropdnpadding'>
<List disablePadding>
<ListItem button className='down_option' component={Link} to="/cm_existing_inv_list" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Existing Investors List</ListItemText>
</ListItem>
</List>

</AccordionDetails>
</Accordion>
<Divider />

<Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel5bh-content"
id="panel5bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM4} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Email/SMS" />
</AccordionSummary>
<AccordionDetails className='dropdnpadding'>
<List disablePadding>
<ListItem button className='down_option' component={Link} to="/bulk_reporting" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Bulk Reporting</ListItemText>
</ListItem>
</List>

</AccordionDetails>
</Accordion>
<Divider />

<Accordion expanded={expanded === 'panel6'} onChange={handleChange('panel6')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel6bh-content"
id="panel6bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM4} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Transaction Management" />
</AccordionSummary>
<AccordionDetails className='dropdnpadding'>
<List disablePadding>
<ListItem button className='down_option' component={Link} to="/tm_purchase_history" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Purchase History</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/tm_redemption" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Redemption</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/tm_cancelled_sip" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Cancelled SIP</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/tran_financialgoal" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Financial Goals</ListItemText>
</ListItem>
</List>

</AccordionDetails>
</Accordion>
<Divider />

<Accordion expanded={expanded === 'panel7'} onChange={handleChange('panel7')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel7bh-content"
id="panel7bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM4} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Investor" />
</AccordionSummary>
<AccordionDetails className='dropdnpadding'>
<List disablePadding>
<ListItem button className='down_option' component={Link} to="/investor_dashboard" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Dashboard</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/investor_profile" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Profile</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/investor_risk_profile_1" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Risk Profile</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/investor_plan_my_goal" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Plan My Goals</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/funds" onClick={toggleDrawer(anchor, false)} >
<ListItemText ><FiberManualRecordIcon className="listicon" fontSize="small" />Funds</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/investor_goaltracker" onClick={toggleDrawer(anchor, false)} >
<ListItemText ><FiberManualRecordIcon className="listicon" fontSize="small" />Goal Tracker</ListItemText>
</ListItem>
</List>

</AccordionDetails>
</Accordion>
<Divider />

<Accordion expanded={expanded === 'panel8'} onChange={handleChange('panel8')}>
<AccordionSummary
expandIcon={<ExpandMoreIcon />}
aria-controls="panel8bh-content"
id="panel8bh-header"
className='drawerlist'
>
<ListItemAvatar>
<img alt="header_img" src={IM4} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Investor Transaction Management" />
</AccordionSummary>
<AccordionDetails className='dropdnpadding'>
<List disablePadding>
<ListItem button className='down_option' component={Link} to="/purchase_cards" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Transaction History</ListItemText>
</ListItem>
<ListItem button className='down_option' component={Link} to="/investor_tm_redumption" onClick={toggleDrawer(anchor, false)} >
<ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Redemption</ListItemText>
</ListItem>
</List>
</AccordionDetails>
</Accordion>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/rm_create_account" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM1} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="RM Create A/C" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/dashboard_rm" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Dashboard_RM" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/dashboard_ifa" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Dashboard_IFA" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/dashboard_agent" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Dashboard_Agent" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/agent_client_management" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Agent Client_Management" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/performancemanagement_agent" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Agent Performance_Management" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/performance_management" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM2} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Performance management" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/partner_management" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM6} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Partner Management" />
</ListItem>
<Divider />

<ListItem className='drawerlist' pl={2} button component={Link} to="/funds" onClick={toggleDrawer(anchor, false)} >
<ListItemAvatar>
<img alt="header_img" src={IM4} width={30} className='menuicons' />
</ListItemAvatar>
<ListItemText primary="Fund" />
</ListItem>
<Divider />


</List>
{/* Main Drawer Content Ends Here */}



</Box>
</Box>
);






return (
<div className="grow">
<Scroll showBelow={250} />
<AppBar position="fixed" className="appnavbar" alignItems="center" data-aos="fade-down">
<Container >
<Toolbar>

<Box className='loggo'>
<a href='/' onClick={() => { window.location.href = "/" }}><img src={dpalogo} className='dpalogo' alt='logo' /></a>
</Box>

<div className="grow" />
<div className="sectionDesktop desktopviewmenu">

<Box variant="h6" className="logintitle" aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick1}>
<IconButton disableRipple className="menutt"> <img alt="header_img" src={P2} width={30} className='menuicons' /></IconButton>
</Box>

<Menu
id="menuId"
anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
anchorEl={anchorE1}
keepMounted
open={Boolean(anchorE1)}
onClose={handleClose1} className="menuitem"
>
<MenuItem onClick={handleClose1} component={Link} to="#">
Option 1
</MenuItem>
<Divider />
<MenuItem onClick={handleClose1} component={Link} to="#">
Option 2
</MenuItem>
<Divider />
<MenuItem onClick={handleClose1} component={Link} to="#">
Option 3
</MenuItem>
</Menu>


<Box variant="h6" className="logintitle" aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick2}>
<IconButton disableRipple className="menutt"> <img alt="header_img" src={profile} width={30} className='menuicons' /></IconButton>
</Box>




<Menu
id="menuId"
anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
anchorEl={anchorE2}
keepMounted
open={Boolean(anchorE2)}
onClose={handleClose2} className="menuitem"
>
<MenuItem onClick={handleClose2} component={Link} to="#">
<img alt="header_img" src={P1} width={30} className='menuicons' />Profile
</MenuItem>
<Divider />
<MenuItem onClick={handleClose2} component={Link} to="#">
<img alt="header_img" src={P4} width={30} className='menuicons' /> Setting
</MenuItem>
<Divider />
<MenuItem onClick={handleClose2} component={Link} to="#">
<img alt="header_img" src={P3} width={30} className='menuicons' /> Logout
</MenuItem>
</Menu>



</div>

<Box className='mobileviewmenu'>
{['right'].map((anchor) => (
<React.Fragment  >

<IconButton aria-label="delete" onClick={toggleDrawer(anchor, true)}>
<MenuIcon fontSize="small" color='primary' />
</IconButton>
<Drawer
className='drawer'
anchor={anchor}
open={state[anchor]}
onClose={toggleDrawer(anchor, false)}
>
{list(anchor)}
</Drawer>
</React.Fragment>
))}
</Box>

</Toolbar>
</Container>
</AppBar>
 
<main style={{ width: '100%' }}>
<Switch>

<Route exact path="/aa"><Sample /></Route>
<Route exact path="/"><SignIn /></Route>
<Route exact path="/forgot_password"><ForgotPassword /></Route>
<Route exact path="/reset_password"><ResetPassword /></Route>

<Route exact path="/get_otp"><GetOtp /></Route>
<Route exact path="/verify_otp"><VerifyOtp /></Route>

<Route exact path="/signup"><SignUp /></Route>

<Route exact path="/successfull"><Success /></Route>


<Route exact path="/createaccount"><Createaccount /></Route>
<Route exact path="/ifa_profile"><IFAProfile /></Route>
<Route exact path="/ifa_partner_profile"><IFAPartnerProfile /></Route>

<Route exact path="/rm_update_profile"><RMUpdateProfile /></Route>

<Route exact path="/ifa_existing_team"><IFAExistingTeam /></Route>
<Route exact path="/ifa_add_new_member"><IFAAddNewMember /></Route>

<Route exact path="/ifa_assigned_agent_list"><IFAAssignedAgentList /></Route>
<Route exact path="/ifa_assigned_cm_list"><IFAAssignedcmList /></Route>

<Route exact path="/ifa_view_client_mapping"><IFAViewClientMapping /></Route>
<Route exact path="/ifa_mapped_clients"><IFAMappedClients /></Route>

<Route exact path="/ucc"><UCC /></Route>

<Route exact path="/aum_reconciliation"><AUMReconciliation /></Route>
<Route exact path="/aum_unmatch"><AUMUnmatch /></Route>

<Route exact path="/aum_reconcile"><AUMReconcile /></Route>


<Route exact path="/om_branches"><OMBranches /></Route>
<Route exact path="/om_zonal"><OMZonal /></Route>
<Route exact path="/om_zonal_list"><OMZonalList /></Route>

<Route exact path="/cm_existing_inv_list"><CMExistingInvlist /></Route>

<Route exact path="/bulk_reporting"><BulkReporting /></Route>

<Route exact path="/tm_purchase_history"><TMPurchaseHistory /></Route>
<Route exact path="/purchase_cards"><PurchaseCards /></Route>
<Route exact path="/purchase_details"><PurchaseDetails /></Route>

<Route exact path="/tm_redemption"><TMRedemption /></Route>

<Route exact path="/tm_cancelled_sip"><TMCancelledSIP /></Route>
<Route exact path="/tm_cancelled_sip_cards"><TMCancelledSIPCards /></Route>
<Route exact path="/tm_proceed_cancellation"><TMProceedCancellation /></Route>





<Route exact path="/investor_profile"><InvestorProfile /></Route>


<Route exact path="/investor_risk_profile_1"><InvestorRiskProfile1 /></Route>
<Route exact path="/investor_risk_profile_2"><InvestorRiskProfile2 /></Route>
<Route exact path="/investor_risk_profile_3"><InvestorRiskProfile3 /></Route>
<Route exact path="/investor_risk_profile_4"><InvestorRiskProfile4 /></Route>
<Route exact path="/investor_risk_profile_5"><InvestorRiskProfile5 /></Route>
<Route exact path="/investor_risk_profile_6"><InvestorRiskProfile6 /></Route>

<Route exact path="/investor_plan_my_goal"><InvestorPlanMyGoal /></Route>
<Route exact path="/pmg_purchase_home"><PMGPurchaseHome /></Route>
<Route exact path="/pmg_purchase_vehicle"><PMGPurchaseVehicle /></Route>


<Route exact path="/pmg_dashboard"><PMGDashboard /></Route>

<Route exact path="/investor_tm_redumption"><InvestorTMRedumption /></Route>

<Route exact path="/rm_create_account"><RMCreateAccount /></Route>

<Route exact path="/agent_client_management"><AgentClientManagement /></Route>

<Route exact path="/partner_management"><PartnerManagement /></Route>
<Route exact path="/partner_profile"><PartnerProfile /></Route>


<Route exact path="/funds"><Funds /></Route>



</Switch>
</main>

</div>



);
}
