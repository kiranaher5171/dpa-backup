import { AppBar, Toolbar, IconButton, Divider, MenuItem, List, ListItem, ListItemAvatar, ListItemText, Menu, Box, Container, Drawer, withStyles, Typography, } from '@material-ui/core';
import React from 'react';
import { useState } from 'react';
import Scroll from './Scroll'
import MenuIcon from '@material-ui/icons/Menu';
import dpalogo from "../asset/images/robopulse.svg";
import CloseIcon from '@mui/icons-material/Close';
import MuiAccordion from '@material-ui/core/Accordion';
import MuiAccordionSummary from '@material-ui/core/AccordionSummary';
import MuiAccordionDetails from '@material-ui/core/AccordionDetails';
import { Route, Switch, Link } from 'react-router-dom';
import FiberManualRecordIcon from '@material-ui/icons/FiberManualRecord';
import profile from "../asset/images/profile_pic.jpg";
import P2 from "../asset/images/riskquestion/notification.svg";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

import IM1 from "../asset/images/createaccount/m1.svg";
import IM2 from "../asset/images/createaccount/m4.svg";
import IM3 from "../asset/images/createaccount/m5.svg";
import IM4 from "../asset/images/createaccount/m6.svg";
import IM5 from "../asset/images/createaccount/m7.svg";
import IM6 from "../asset/images/createaccount/m8.svg";
import P1 from "../asset/images/riskquestion/profile_1.svg";
import P3 from "../asset/images/riskquestion/logout.svg";
import P4 from "../asset/images/createaccount/settings.svg";





const Accordion = withStyles({
  root: {
    border: '0px solid rgba(0, 0, 0, .125)',
    boxShadow: 'none',
    '&:not(:last-child)': {
      borderBottom: 0,
    },
    '&:before': {
      display: 'none',
    },
    '&$expanded': {
      margin: 'auto',
    },
  },
  expanded: {},
})(MuiAccordion);


const AccordionSummary = withStyles({
  root: {
    borderBottom: '0px solid rgba(0, 0, 0, .125)',
    marginBottom: -1,
    minHeight: 46,
    '&$expanded': {
      minHeight: 46,
    },
  },
  content: {
    '&$expanded': {
      margin: '0px 0',
    },
  },
  expanded: {},
})(MuiAccordionSummary);


const AccordionDetails = withStyles((theme) => ({
  root: {
    padding: theme.spacing(0),
  },
}))(MuiAccordionDetails);



export default function PrimarySearchAppBar() {



  const [activePage, setActivePage] = useState('');



  const [anchorE1, setAnchorE1] = React.useState(null);

  const handleClick1 = (event) => {
    setAnchorE1(event.currentTarget);
  };

  const handleClose1 = () => {
    setAnchorE1(null);
  };



  const [anchorE2, setAnchorE2] = React.useState(null);

  const handleClick2 = (event) => {
    setAnchorE2(event.currentTarget);
  };

  const handleClose2 = () => {
    setAnchorE2(null);
  };



  const [state, setState] = React.useState({
  });

  const toggleDrawer = (anchor, open) => (event) => {
    if (event.type === 'right' && (event.key === 'right')) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };



  // const headerClick = (anchor) => {
  //     setActivePage('');
  //      toggleDrawer(anchor, false);
  //     };



  const [expanded, setExpanded] = React.useState('false');

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };



  const list = (anchor) => (





    <Box id='drawer' className='mobilemenuview' sx={{ width: 300 }} role="presentation">


      <Box mb={'5px'} mt={1} mr={2} className='al_right'>
        <IconButton className='Close_btn' variant="contained" onClick={toggleDrawer(anchor, false)}>
          <CloseIcon fontSize='small' color='primary' />
        </IconButton>
      </Box>

      <Box >


        {/* Main Drawer Content Start from Here */}
        <List id="drawerlist">
          <Divider />



          <ListItem className='drawerlist' pl={2} button component={Link} to="/createaccount" onClick={toggleDrawer(anchor, false)}
          // 
          // onClick={()=>{ toggleDrawer(anchor, false); setActivePage('IFA_Create')}} 
          // onClick={() => {
          //     setActivePage('IFA_Create');
          //     toggleDrawer(anchor, false);
          //   }}
          >
            <ListItemAvatar>
              <img alt="header_img" src={IM1} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="IFA Create A/C" /> */}
            <Typography variant='subtitle2' onClick={() => setActivePage('IFA_Create')} className={activePage === 'IFA_Create' ? 'active' : ''}> IFA Create A/C </Typography>
          </ListItem>

          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/ifa_profile" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="IFA Profile" /> */}
            <Typography variant='subtitle2' className={activePage === 'IFA_Profile' ? 'active' : ''} onClick={() => setActivePage('IFA_Profile')}
            > IFA Profile </Typography>
          </ListItem>

          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/ifa_partner_profile" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="IFA Partner Update Profile" /> */}
            <Typography variant='subtitle2' className={activePage === 'IFA_Partner_pro' ? 'active' : ''}
              onClick={() => setActivePage('IFA_Partner_pro')} > IFA Partner Update Profile </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/rm_update_profile" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="RM Update Profile" /> */}
            <Typography variant='subtitle2' className={activePage === 'RM_Update_Profile' ? 'active' : ''}
              onClick={() => setActivePage('RM_Update_Profile')} > RM Update Profile </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/ucc" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM4} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="UCC" /> */}
            <Typography variant='subtitle2' className={activePage === 'UCC' ? 'active' : ''}
              onClick={() => setActivePage('UCC')} > UCC </Typography>
          </ListItem>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel1'} onChange={handleChange('panel1')} onClick={() => setActivePage('Admin/Back Office')} >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1bh-content"
              id="panel1bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM5} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Admin/Back Office" /> */}
              <Typography variant='subtitle1' className={activePage === 'Admin/Back Office' ? 'active' : ''}> Admin/Back Office </Typography>
            </AccordionSummary>
            <AccordionDetails className='dropdnpadding'>
              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/coming_soon" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" /> Category wise AUM</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/aum_reconciliation" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" /> AUM Reconciliation</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/ifa_SIPbook" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" /> SIP Book</ListItemText>
                </ListItem>
              </List>

            </AccordionDetails>
          </Accordion>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel2'} onChange={handleChange('panel2')} onClick={() => setActivePage('Team Management')} >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel2bh-content"
              id="panel2bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM2} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Team Management" /> */}

              <Typography variant='subtitle1' className={activePage === 'Team Management' ? 'active' : ''}> Team Management </Typography>

            </AccordionSummary>
            <AccordionDetails>

              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/ifa_existing_team" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Existing Team Members</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/ifa_view_client_mapping" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />View client mapping</ListItemText>
                </ListItem>
              </List>
            </AccordionDetails>
          </Accordion>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel3'} onChange={handleChange('panel3')} onClick={() => setActivePage('Operation management')} >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel3bh-content"
              id="panel3bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM3} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Operation management" /> */}
              <Typography variant='subtitle1' className={activePage === 'Operation management' ? 'active' : ''}> Operation management </Typography>
            </AccordionSummary>
            <AccordionDetails>

              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/om_branches" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Branches</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/om_zonal" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Zonal/Region</ListItemText>
                </ListItem>
              </List>

            </AccordionDetails>
          </Accordion>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel4'} onChange={handleChange('panel4')} onClick={() => setActivePage('Client Management')}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel4bh-content"
              id="panel4bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM4} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Client Management" /> */}
              <Typography variant='subtitle1' className={activePage === 'Client Management' ? 'active' : ''}> Client Management </Typography>
            </AccordionSummary>
            <AccordionDetails className='dropdnpadding'>
              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/cm_existing_inv_list" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Existing Investors List</ListItemText>
                </ListItem>
              </List>

            </AccordionDetails>
          </Accordion>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel5'} onChange={handleChange('panel5')} onClick={() => setActivePage('Email/SMS')} >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel5bh-content"
              id="panel5bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM4} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Email/SMS" /> */}
              <Typography variant='subtitle1' className={activePage === 'Email/SMS' ? 'active' : ''}> Email/SMS </Typography>
            </AccordionSummary>
            <AccordionDetails className='dropdnpadding'>
              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/bulk_reporting" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Bulk Reporting</ListItemText>
                </ListItem>
              </List>

            </AccordionDetails>
          </Accordion>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel6'} onChange={handleChange('panel6')} onClick={() => setActivePage('Transaction Management')}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel6bh-content"
              id="panel6bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM4} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Transaction Management" /> */}
              <Typography variant='subtitle1' className={activePage === 'Transaction Management' ? 'active' : ''}> Transaction Management </Typography>
            </AccordionSummary>
            <AccordionDetails className='dropdnpadding'>
              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/tm_purchase_history" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Purchase History</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/tm_redemption" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Redemption</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/tm_cancelled_sip" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Cancelled SIP</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/tran_financialgoal" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Financial Goals</ListItemText>
                </ListItem>
              </List>

            </AccordionDetails>
          </Accordion>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel7'} onChange={handleChange('panel7')} onClick={() => setActivePage('Investor')}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel7bh-content"
              id="panel7bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM4} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Investor" /> */}
              <Typography variant='subtitle1' className={activePage === 'Investor' ? 'active' : ''}
              > Investor </Typography>
            </AccordionSummary>
            <AccordionDetails className='dropdnpadding'>
              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/investor_dashboard" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Dashboard</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/investor_profile" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Profile</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/investor_risk_profile_1" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Risk Profile</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/investor_plan_my_goal" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Plan My Goals</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/funds" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText ><FiberManualRecordIcon className="listicon" fontSize="small" />Funds</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/investor_goaltracker" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText ><FiberManualRecordIcon className="listicon" fontSize="small" />Goal Tracker</ListItemText>
                </ListItem>
              </List>

            </AccordionDetails>
          </Accordion>
          <Divider />

          <Accordion id='Accordian' expanded={expanded === 'panel8'} onChange={handleChange('panel8')} onClick={() => setActivePage('Investor Transaction Management')}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel8bh-content"
              id="panel8bh-header"
              className='drawerlist'
            >
              <ListItemAvatar>
                <img alt="header_img" src={IM4} width={30} className='menuicons' />
              </ListItemAvatar>
              {/* <ListItemText primary="Investor Transaction Management" /> */}
              <Typography variant='subtitle1' className={activePage === 'Investor Transaction Management' ? 'active' : ''}
              > Investor Transaction Management </Typography>
            </AccordionSummary>
            <AccordionDetails className='dropdnpadding'>
              <List disablePadding>
                <ListItem button className='down_option' component={Link} to="/purchase_cards" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Transaction History</ListItemText>
                </ListItem>
                <ListItem button className='down_option' component={Link} to="/investor_tm_redumption" onClick={toggleDrawer(anchor, false)} >
                  <ListItemText > <FiberManualRecordIcon className="listicon" fontSize="small" />Redemption</ListItemText>
                </ListItem>
              </List>
            </AccordionDetails>
          </Accordion>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/rm_create_account" onClick={toggleDrawer(anchor, false)}  >
            <ListItemAvatar>
              <img alt="header_img" src={IM1} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="RM Create A/C" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('RM Create A/C')} className={activePage === 'RM Create A/C' ? 'active' : ''}
            > RM Create A/C </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/dashboard_rm" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Dashboard_RM" /> */}

            <Typography variant='subtitle1' onClick={() => setActivePage('Dashboard_RM')} className={activePage === 'Dashboard_RM' ? 'active' : ''}
            > Dashboard_RM </Typography>

          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/dashboard_ifa" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Dashboard_IFA" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('Dashboard_IFA')} className={activePage === 'Dashboard_IFA' ? 'active' : ''}
            > Dashboard_IFA </Typography>

          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/dashboard_agent" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Dashboard_Agent" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('Dashboard_Agent')} className={activePage === 'Dashboard_Agent' ? 'active' : ''}
            > Dashboard_Agent </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/agent_client_management" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Agent Client_Management" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('Agent Client_Management')} className={activePage === 'Agent Client_Management' ? 'active' : ''}
            > Agent Client_Management </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/performancemanagement_agent" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Agent Performance_Management" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('Agent Performance_Management')} className={activePage === 'Agent Performance_Management' ? 'active' : ''}
            > Agent Performance_Management </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/performance_management" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM2} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Performance management" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('Performance management')} className={activePage === 'Performance management' ? 'active' : ''}
            > Performance management </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/partner_management" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM6} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Partner Management" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('Partner Management')} className={activePage === 'Partner Management' ? 'active' : ''}
            > Partner Management </Typography>
          </ListItem>
          <Divider />

          <ListItem className='drawerlist' pl={2} button component={Link} to="/funds" onClick={toggleDrawer(anchor, false)} >
            <ListItemAvatar>
              <img alt="header_img" src={IM4} width={30} className='menuicons' />
            </ListItemAvatar>
            {/* <ListItemText primary="Fund" /> */}
            <Typography variant='subtitle1' onClick={() => setActivePage('Fund')} className={activePage === 'Fund' ? 'active' : ''}
            > Fund </Typography>
          </ListItem>
          <Divider />


        </List>
        {/* Main Drawer Content Ends Here */}



      </Box>
    </Box>


  );



  return (
    <div className="grow">
      <Scroll showBelow={250} />

      <AppBar position="fixed" className="appnavbar" alignItems="center" data-aos="fade-down">
        <Container className='containerwidth'>
          <Toolbar>

            <Box className='loggo'>
              <a href='/' onClick={() => { window.location.href = "/" }}><img src={dpalogo} className='dpalogo' alt='logo' /></a>
            </Box>

            <div className="grow" />
            <div className="sectionDesktop desktopviewmenu">

              <Box variant="h6" className="logintitle" aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick1}>
                <IconButton disableRipple className="menutt"> <img alt="header_img" src={P2} width={30} className='menuicons' /></IconButton>
              </Box>

              <Menu
                id="menuId"
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                anchorEl={anchorE1}
                keepMounted
                open={Boolean(anchorE1)}
                onClose={handleClose1} className="menuitem"
              >
                <MenuItem onClick={handleClose1} component={Link} to="#">
                  Option 1
                </MenuItem>
                <Divider />
                <MenuItem onClick={handleClose1} component={Link} to="#">
                  Option 2
                </MenuItem>
                <Divider />
                <MenuItem onClick={handleClose1} component={Link} to="#">
                  Option 3
                </MenuItem>
              </Menu>


              <Box variant="h6" className="logintitle" aria-controls="simple-menu" aria-haspopup="true" onClick={handleClick2}>
                <IconButton disableRipple className="menutt"> <img alt="header_img" src={profile} width={30} className='menuicons' /></IconButton>
              </Box>




              <Menu
                id="menuId"
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                anchorEl={anchorE2}
                keepMounted
                open={Boolean(anchorE2)}
                onClose={handleClose2} className="menuitem"
              >
                <MenuItem onClick={handleClose2} component={Link} to="#">
                  <img alt="header_img" src={P1} width={30} className='menuicons' />Profile
                </MenuItem>
                <Divider />
                <MenuItem onClick={handleClose2} component={Link} to="#">
                  <img alt="header_img" src={P4} width={30} className='menuicons' /> Setting
                </MenuItem>
                <Divider />
                <MenuItem onClick={handleClose2} component={Link} to="/">
                  <img alt="header_img" src={P3} width={30} className='menuicons' /> Log Out
                </MenuItem>
              </Menu>



            </div>

            <Box className='mobileviewmenu'>
              {['right'].map((anchor) => (
                <React.Fragment  >

                  <IconButton aria-label="delete" onClick={toggleDrawer(anchor, true)}>
                    <MenuIcon fontSize="small" color='primary' />
                  </IconButton>
                  <Drawer
                    className='drawer'
                    anchor={anchor}
                    open={state[anchor]}
                    onClose={toggleDrawer(anchor, false)}
                  >
                    {list(anchor)}
                  </Drawer>
                </React.Fragment>
              ))}
            </Box>

          </Toolbar>
        </Container>
      </AppBar>


    </div>



  );
}
