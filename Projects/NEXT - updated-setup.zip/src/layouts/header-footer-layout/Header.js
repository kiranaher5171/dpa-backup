"use client";

import * as React from "react";

import {
  AppBar,
  Avatar,
  Badge,
  Box,
  Button,
  Drawer,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemAvatar,
  ListItemButton,
  ListItemText,
  ListSubheader,
  Menu,
  Stack,
  Toolbar,
  Tooltip,
  Typography,
} from "@mui/material";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import LogoutIcon from "@mui/icons-material/Logout";
import MenuIcon from "@mui/icons-material/Menu";
import MenuOpenIcon from "@mui/icons-material/MenuOpen";
import HelpCenterOutlinedIcon from "@mui/icons-material/HelpCenterOutlined";
import PersonOutlineOutlinedIcon from "@mui/icons-material/PersonOutlineOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import { MdOutlineNotificationsNone } from "react-icons/md";
import logo from "../../../public/assets/logo.svg";
import Image from "next/image";
import Link from "next/link";
import { getMenuItems } from "../sidebar-layout/menuItems";

export default function Header() {
  const pathname = usePathname();
  const router = useRouter();

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [userName, setUserName] = useState("");
  const [anchorElP, setAnchorElP] = useState(null);
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [navMenuItem, setNavMenuItem] = useState(null);

  const openP = Boolean(anchorElP);
  const openNav = Boolean(anchorElNav);
  const handleClickP = (event) => setAnchorElP(event.currentTarget);
  const handleCloseP = () => setAnchorElP(null);
  const handleOpenNavMenu = (event, item) => {
    setAnchorElNav(event.currentTarget);
    setNavMenuItem(item);
  };
  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
    setNavMenuItem(null);
  };

  const [helpAnchorEl, setHelpAnchorEl] = useState(null);
  const helpMenuOpen = Boolean(helpAnchorEl);
  const handleHelpClick = (event) => setHelpAnchorEl(event.currentTarget);
  const handleHelpClose = () => setHelpAnchorEl(null);
  const handleHelpAction = (action) => {
    handleHelpClose();
    // Handle navigation or action for resources, faqs, user_guides
    if (action === "resources") router.push("/help/resources");
    else if (action === "faqs") router.push("/help/faqs");
    else if (action === "user_guides") router.push("/help/user-guides");
  };

  const handleLogout = () => {
    localStorage.clear();
    handleCloseP();
    router.push("/auth/login");
  };

  const initials = userName
    ?.split(" ")
    .map((word) => word.charAt(0))
    .join("")
    .toUpperCase() || "?";

  // Use shared menu items (same as MainLayout sidebar)
  const menuItems = getMenuItems();

  useEffect(() => {
    if (typeof window !== "undefined") {
      setUserName(localStorage.getItem("user_name") || "");
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (typeof window === "undefined") return;

      const triggerHeight =
        pathname === "/"
          ? window.innerHeight * 0.8 // 80vh for home page
          : window.innerHeight * 0.3; // 30vh for other pages

      if (window.scrollY > triggerHeight) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    // Initial check

    handleScroll();

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, [pathname]);

  const toggleDrawer = () => {
    setDrawerOpen((prev) => !prev);
  };

  const handleDrawerClose = () => setDrawerOpen(false);

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar
        id="Appbar"
        position="fixed"
        className={`Appbar_height ${scrolled ? "scrolled" : ""}`}
        elevation={0} // no shadow initially
      >
        <Toolbar className="fx_sb">
          {/* Logo - Left */}

          <Box>
            <Link href="/home">
              <Image
                src={logo}
                alt="logo"
                className="appbar_logo"
                priority

              /> 

              {/* <Typography variant="h4" className="white fw6">
                Job Portal
              </Typography> */}
            </Link>
          </Box>

          {/* Desktop Menu - Center */}

          <Box
            sx={{
              display: { xs: "none", md: "flex" },
              gap: 1,
              alignItems: "center",
              flexGrow: 1,
              justifyContent: "center",
              mx: 2,
            }}
          >
            {menuItems.map((item) =>
              item.children ? (
                <Button
                  key={item.href}
                  disableRipple
                  className={`menus ${
                    pathname.startsWith(item.href) ? "active" : ""
                  }`}
                  onClick={(e) => handleOpenNavMenu(e, item)}
                  endIcon={<ArrowDropDownIcon />}
                >
                  {item.title}
                </Button>
              ) : (
                <Link key={item.href} href={item.href} passHref>
                  <Button
                    disableRipple
                    className={`menus ${
                      pathname.startsWith(item.href) ? "active" : ""
                    }`}
                  >
                    {item.title}
                  </Button>
                </Link>
              )
            )}
          </Box>

          {/* Login Button - Right */}

          <Box
            sx={{
              display: { xs: "none", md: "flex" },
              alignItems: "center",
              gap: 1,
            }}
          > 

<Tooltip arrow title="Notifications">
              <IconButton size="medium" className="tertiary">
                <Badge className="notification-badge" badgeContent={4} color="error">
                  <MdOutlineNotificationsNone className="black" style={{ fontSize: "22px" }} />
                </Badge>
              </IconButton>
            </Tooltip>

            <Tooltip arrow title="Help & Support">
              <IconButton
                size="medium"
                className="tertiary"
                onClick={handleHelpClick}
                aria-controls={helpMenuOpen ? "help-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={helpMenuOpen ? "true" : undefined}
              >
                <HelpCenterOutlinedIcon className="black" style={{ fontSize: "22px" }} />
              </IconButton>
            </Tooltip>

            <Menu
              id="help-menu"
              anchorEl={helpAnchorEl}
              open={helpMenuOpen}
              onClose={handleHelpClose}
              MenuListProps={{
                "aria-labelledby": "help-button",
              }}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "right",
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "right",
              }}
            >
              <List disablePadding sx={{ minWidth: 160 }}>
                <ListItemButton
                  className="menus"
                  onClick={() => handleHelpAction("resources")}
                >
                  <ListItemText primary="Resources" />
                </ListItemButton>
                <Divider />
                <ListItemButton
                  className="menus"
                  onClick={() => handleHelpAction("faqs")}
                >
                  <ListItemText primary="FAQs" />
                </ListItemButton>
                <Divider />
                <ListItemButton
                  className="menus"
                  onClick={() => handleHelpAction("user_guides")}
                >
                  <ListItemText primary="User Guides" />
                </ListItemButton>
                <Divider />
              </List>
            </Menu>

          

            <Box id="profile">
              <List>
                <ListItem disablePadding secondaryAction={<ArrowDropDownIcon />}>
                  <ListItemButton onClick={handleClickP}>
                    <ListItemAvatar>
                      <Avatar size="small"> KA</Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      id="desktop-only"
                      primary={
                        <Typography variant="h6" className="fw6">
                          <span className="col1 fw5">Welcome,</span> {userName || "User"}
                        </Typography>
                      }
                    />
                  </ListItemButton>
                </ListItem>
              </List>
            </Box>
          </Box>

          {/* Mobile Drawer Icon - Toggle Button */}

          <Tooltip title={drawerOpen ? "Collapse" : "Expand"} arrow placement="bottom">
            <IconButton onClick={toggleDrawer} size="medium" className='mobile-menu-icon' id="mobile-only">
              {drawerOpen ? <MenuOpenIcon fontSize='medium' /> : <MenuIcon fontSize='medium' />}
            </IconButton>
          </Tooltip>
        </Toolbar>
      </AppBar>

      {/* Nav dropdown for items with sub-menus (e.g. Home) */}
      <Menu
        anchorEl={anchorElNav}
        open={openNav}
        onClose={handleCloseNavMenu}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
        transformOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <List disablePadding sx={{ minWidth: 160 }}>
          {navMenuItem?.children?.map((child) => (
            <ListItem key={child.href} disablePadding sx={{ flexDirection: "column", alignItems: "stretch" }}>
              <ListItemButton
                component={Link}
                href={child.href}
                onClick={() => {
                  handleDrawerClose();
                  handleCloseNavMenu();
                }}
              >
                <ListItemText primary={child.title} />
              </ListItemButton>
              <Divider />
            </ListItem>
          ))}
        </List>
      </Menu>

      {/* Mobile Drawer */}

      <Drawer anchor="right" open={drawerOpen} onClose={handleDrawerClose}>
        <Box sx={{ width: 280 }} role="presentation" pt={2}>
          <List
            component="nav"
            subheader={<ListSubheader component="div">Menu</ListSubheader>}
          >
            {menuItems.map((item) => (
              <React.Fragment key={item.href}>
                {item.children ? (
                  item.children.map((child) => (
                    <React.Fragment key={child.href}>
                      <Link href={child.href} passHref>
                        <ListItemButton
                          disableRipple
                          onClick={handleDrawerClose}
                          sx={{ pl: 2 }}
                        >
                          <ListItemText primary={child.title} />
                        </ListItemButton>
                      </Link>
                      <Divider />
                    </React.Fragment>
                  ))
                ) : (
                  <>
                    <Link href={item.href} passHref>
                      <ListItemButton disableRipple onClick={handleDrawerClose}>
                        <ListItemText primary={item.title} />
                      </ListItemButton>
                    </Link>
                    <Divider />
                  </>
                )}
              </React.Fragment>
            ))}

 

            <Divider />
          </List>
        </Box>
      </Drawer>

      <Menu
        anchorEl={anchorElP}
        id="profile-menu"
        open={openP}
        onClose={handleCloseP}
        onClick={handleCloseP}
        slotProps={{
          paper: {
            elevation: 0,
            sx: {
              overflow: "visible",
              filter: "drop-shadow(0px 2px 4px rgba(0,0,0,0.25))",
              mt: 1.5,
              "&::before": {
                content: '""',
                display: "block",
                position: "absolute",
                top: 0,
                right: 12,
                width: 10,
                height: 10,
                bgcolor: "background.paper",
                transform: "translateY(-50%) rotate(45deg)",
                zIndex: 0,
              },
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <Stack direction="column" alignItems="center" justifyContent="center" spacing={1}>
          <Button
            variant="text"
            className="profile-options"
            startIcon={<PersonOutlineOutlinedIcon fontSize="small" />}
            disableRipple
            onClick={handleCloseP}
          >
            Profile
          </Button>
          <Button
            variant="text"
            className="profile-options"
            startIcon={<SettingsOutlinedIcon fontSize="small" />}
            disableRipple
            onClick={handleCloseP}
          >
            Settings
          </Button>
          <Button
            variant="text"
            className="profile-options"
            startIcon={<LogoutIcon fontSize="small" />}
            disableRipple
            onClick={handleLogout}
          >
            Logout
          </Button>
        </Stack>
      </Menu>
    </Box>
  );
}
