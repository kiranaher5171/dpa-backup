"use client";
import { Box } from "@mui/material";

/**
 * FormLayout - Simple layout without header and footer
 * Used for authentication pages, forms, etc.
 */
export default function FormLayout({ children }) {
    return (
        <Box>
            {children}
        </Box>
    );
}

