import { Box, TextField } from '@mui/material'
import React from 'react'
import Autocomplete from '@mui/material/Autocomplete';

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]

const SimpleAutoComplete = ({ label, placeholder }) => {
    return (
        <>
            <Box className='textfield auto-complete'>
                <Autocomplete
                    disablePortal
                    fullWidth
                    id="combo-box-demo"
                    options={options}
                    getOptionLabel={(option) => option.label || ''}
                    renderInput={(params) => (
                        <TextField 
                            {...params} 
                            label={label} 
                            placeholder={placeholder}
                            variant='outlined' 
                            size='small'
                        />
                    )}
                />
            </Box>
        </>
    )
}

export default SimpleAutoComplete