import React, { useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Box, Typography } from '@mui/material';
import Image from 'next/image';
import dragdrop from "/assets/icons/dragdrop.svg";



export default function PdfDropzone({ onDrop, accept, open }) {
    const { getRootProps, getInputProps, isDragActive, acceptedFiles } =
        useDropzone({
            accept,
            onDrop,
        });

    const files = acceptedFiles.map((file) => (
        <Typography variant="h6" className="content" key={file.path}>
            {file.path} - {file.size} bytes
        </Typography>
    ));

    return (
        <Box>
            <Box {...getRootProps({ className: "dropzone" })}>
                <input className="input-zone" {...getInputProps()} />
                <Box className="center">
                    {isDragActive ? (
                        <Box className="dropzone-content">
                            <Typography variant='h5' className='col1 fw5' gutterBottom>     Release to drop the files here </Typography>
                        </Box>
                    ) : (
                        <Box className="dropzone-content">
                            <Box>
                                <Image src={dragdrop} alt="pdf logo here" className='pdfimg' />
                            </Box>

                            <Box pt={2}>
                                <Typography variant='h4' className='gray fw5' gutterBottom> Drag & drop your files here  </Typography>
                                <Typography variant='h5' className='black fw6' gutterBottom> Or </Typography>
                                <Typography variant='h4' className='l-secondary fw5' gutterBottom> Browse file </Typography>
                            </Box>
                        </Box>
                    )}
                </Box>
            </Box>

            <Box>
                <>{files}</>
            </Box>
        </Box>
    );
}