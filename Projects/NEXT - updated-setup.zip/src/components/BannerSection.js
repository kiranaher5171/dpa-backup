import React from 'react'
import { Box, Container, Stack, Typography } from '@mui/material'
import Grid from '@mui/material/Grid'
import NavigateNextIcon from "@mui/icons-material/NavigateNext";

export default function BannerSection({
    imageSrc = '/assets/hero-banner/hero-banner1.jpg',
    title = 'Page Title',
    subtitle = '',
    breadcrumbs = ['Home', 'Page']
}) {
    return (
        <Box className="HeroSection section">
            <Box className="hero-fixed-bg" style={{ backgroundImage: `url(${imageSrc})` }} />
            <Box className="gradient-overlay" />
            <Box className="content">
                <Container maxWidth>
                    <Grid container spacing={0} alignItems="center" justifyContent="flex-start">
                        <Grid size={{ lg: 7, md: 7, sm: 10, xs: 12 }}>
                            {/* <Stack direction="row" alignItems="center" justifyContent="flex-start" spacing={1}>
                                {breadcrumbs.map((crumb, idx) => (
                                    <React.Fragment key={idx}>
                                        <Typography variant="h5" className={`white ${idx === breadcrumbs.length - 1 ? 'fw5' : 'fw4'}`}>
                                            {crumb}
                                        </Typography>
                                        {idx !== breadcrumbs.length - 1 && <NavigateNextIcon style={{ color: 'white' }} />}
                                    </React.Fragment>
                                ))}
                            </Stack> */}
                            <Box pt={5} pb={5}>
                                <Typography variant="h4" className='white fw6 lora' gutterBottom>
                                    {title}
                                </Typography>
                                {subtitle ? (
                                    <Typography mt={1} variant="h5" className='white fw4'>
                                        {subtitle}
                                    </Typography>
                                ) : null}
                            </Box>
                        </Grid>
                    </Grid>
                </Container>
            </Box>
        </Box>
    )
}