import "./root.css";
import { Poppins, Lora } from 'next/font/google';
import ThemeProviderComponent from "@/components/ThemeProviderComponent";
import crypto from 'crypto';

// Poppins - Default font for the entire project
const poppins = Poppins({
  subsets: ['latin'],
  weight: ['100', '300', '400', '500', '600', '700', '800'],
  variable: "--font-poppins",
  display: 'swap',
});

// Lora - Secondary font (apply with className="lora")
// Lora only supports weights: 400, 500, 600, 700
const lora = Lora({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: "--font-lora",
  display: 'swap',
});

export const metadata = {
  title: "Global Investment Administration",
};

export default function RootLayout({ children }) {
  const nonce = crypto.randomBytes(16).toString('base64');

  return (
    <html lang="en" className={`${poppins.variable} ${lora.variable}`}>
      <body className={poppins.className}>
        <ThemeProviderComponent nonce={nonce}>
          <main>
            {children}
          </main>
        </ThemeProviderComponent>
      </body>
    </html>
  );
}
