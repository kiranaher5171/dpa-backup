"use client";

import React, { useState } from "react";
import {
  Box,
  Button,
  Checkbox,
  Chip,
  Container,
  IconButton,
  Stack,
  Typography,
} from "@mui/material";
import SimpleAutoComplete from "@/components/customized_input_fields/SimpleAutoComplete";
import SimpleDatePicker from "@/components/customized_input_fields/SimpleDatePicker";
import SimpleTextField from "@/components/customized_input_fields/SimpleTextField";
import { MdKeyboardArrowLeft } from "react-icons/md";
import DummyTabs from "./DummyTabs";
import DummyDialog from "./DummyDialog";
import DummyStepper from "./DummyStepper";
import DummyVideoDialog from "./DummyVideoDialog";
import DummyImages from "./DummyImages";
import SimpleMultiSelectAutoComplete from "@/components/customized_input_fields/SimpleMulticheckAutoComplete";
import SimpleMulticheckAutoComplete from "@/components/customized_input_fields/SimpleMulticheckAutoComplete";
import DummyAGridTable from "./DummyAGridTable";
import DummyAGridTableExpand from "./DummyAGridTableExpand";
import MainLayout from "../../layouts/sidebar-layout/MainLayout";
import ConformationDialog from "@/components/dialogs/ConformationDialog";
import ContainDialog from "@/components/dialogs/ContainDialog";
import DeleteDialog from "@/components/dialogs/DeleteDialog";
import SuccessDialog from "@/components/dialogs/SuccessDialog";
import VideoDialog from "@/components/dialogs/VideoDialog";

const page = () => {
  // Initialize with 50 chip labels
  const [chipLabels, setChipLabels] = useState(
    Array.from({ length: 10 }, (_, i) => `Chip ${i + 1}`)
  );

  // Delete handler
  const handleDelete = (chipToDelete) => {
    setChipLabels((chips) => chips.filter((chip) => chip !== chipToDelete));
  };

  // Dialog states
  const [openConformation, setOpenConformation] = useState(false);
  const [openConformationDialog, setOpenConformationDialog] = useState(false);
  const [openContain, setOpenContain] = useState(false);
  const [openDelete, setOpenDelete] = useState(false);
  const [openSuccess, setOpenSuccess] = useState(false);
  const [openVideo, setOpenVideo] = useState(false);

  // Dialog handlers
  const handleOpenConformation = () => setOpenConformation(true);
  const handleCloseConformation = () => setOpenConformation(false);

  const handleOpenConformationDialog = () => setOpenConformationDialog(true);
  const handleCloseConformationDialog = () => setOpenConformationDialog(false);

  const handleOpenContain = () => setOpenContain(true);
  const handleCloseContain = () => setOpenContain(false);

  const handleOpenDelete = () => setOpenDelete(true);
  const handleCloseDelete = () => setOpenDelete(false);

  const handleOpenSuccess = () => setOpenSuccess(true);
  const handleCloseSuccess = () => setOpenSuccess(false);

  const handleOpenVideo = () => setOpenVideo(true);
  const handleCloseVideo = () => setOpenVideo(false);

  const options = [
    { label: "India", value: "india" },
    { label: "USA", value: "usa" },
    { label: "UK", value: "uk" },
  ];

  const options2 = [
    { label: "Passport" },
    { label: "PAN Card" },
    { label: "Aadhaar Card" },
    { label: "Driving License" },
    { label: "Voter ID" },
  ];

  // State for multiselect documents
  const [selectedDocuments, setSelectedDocuments] = useState([]);

  return (
    <div>
      <MainLayout>
        <Container maxWidth>
          {/* Image Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Image Components
            </Typography>
            <Box mt={2}>
              <DummyImages />
            </Box>
          </Box>

          {/* Tabs Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Tabs Components
            </Typography>
            <Box mt={2}>
              <DummyTabs />
            </Box>
          </Box>

          {/* Dialog Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Dialog Components
            </Typography>
            <Stack direction="row" justifyContent="flex-start" gap={2} flexWrap="wrap" mt={2}>
              <Button
                disableRipple
                onClick={handleOpenConformationDialog}
                variant="contained"
                className="primary-action-btn"
              >
                Open Conformation Dialog
              </Button>
              <Button
                disableRipple
                onClick={handleOpenContain}
                variant="contained"
                className="primary-action-btn"
              >
                Open Contain Dialog
              </Button>
              <Button
                disableRipple
                onClick={handleOpenDelete}
                variant="contained"
                className="primary-action-btn"
              >
                Open Delete Dialog
              </Button>
              <Button
                disableRipple
                onClick={handleOpenSuccess}
                variant="contained"
                className="primary-action-btn"
              >
                Open Success Dialog
              </Button>
              <Button
                disableRipple
                onClick={handleOpenVideo}
                variant="contained"
                className="primary-action-btn"
              >
                Open Video Dialog
              </Button>
            </Stack>
          </Box>

          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Button Components
            </Typography>
            <Stack direction="row" justifyContent="flex-start" gap={2} flexWrap="wrap" mt={2}>
              <Button
                disableRipple
                variant="contained"
                className="primary-action-btn"
              >
                primary-action-btn
              </Button>
              <Button
                disableRipple
                variant="outlined"
                className="primary-outline-btn"
              >
                primary-outline-btn
              </Button>
              <Button
                disableRipple
                variant="contained"
                className="secondary-action-btn"
              >
                secondary-action-btn
              </Button>
              <Button
                disableRipple
                variant="outlined"
                className="secondary-outline-btn"
              >
                secondary-outline-btn
              </Button>
              <Button
                disableRipple
                variant="contained"
                className="gray-action-btn"
              >
                gray-action-btn
              </Button>
              <Button
                disableRipple
                variant="outlined"
                className="gray-outline-btn"
              >
                gray-outline-btn
              </Button>
              <Button
                disableRipple
                variant="text"
                className="link-text-btn"
              >
                link-text-btn
              </Button>
              <IconButton disableRipple size="small" className="ico-btn">
                <MdKeyboardArrowLeft className="col1" />
              </IconButton>
              <Typography variant="body2" sx={{ alignSelf: 'center' }}>
                ico-btn
              </Typography>
              <Button
                disableRipple
                variant="text"
                className="back-btn"
                startIcon={<MdKeyboardArrowLeft />}
              >
                back-btn
              </Button>
            </Stack>
          </Box>

          {/* Chip Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Chip Components
            </Typography>
            <Stack
              direction="row"
              flexWrap="wrap"
              justifyContent="flex-start"
              gap={1}
              mt={2}
            >
              {chipLabels.map((label, index) => (
                <Chip
                  key={index}
                  label={label}
                  onDelete={() => handleDelete(label)}
                />
              ))}
            </Stack>
          </Box>

          {/* Stepper Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Stepper Components
            </Typography>
            <Box mt={2}>
              <DummyStepper />
            </Box>
          </Box>

          {/* Typography Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Typography Components
            </Typography>
            <Box mt={2}>
              <Typography variant="h5" className="fw2" gutterBottom>
                fw2 - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw3" gutterBottom>
                fw3 - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw4" gutterBottom>
                fw4 - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw5" gutterBottom>
                fw5 - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw6" gutterBottom>
                fw6 - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw7" gutterBottom>
                fw7 - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>
            </Box>
          </Box>

          {/* Typography with Lora Font Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Typography Components (Lora Font)
            </Typography>
            <Box mt={2}>
              <Typography variant="h5" className="fw3 lora" gutterBottom>
                fw3 lora - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw4 lora" gutterBottom>
                fw4 lora - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw5 lora" gutterBottom>
                fw5 lora - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw6 lora" gutterBottom>
                fw6 lora - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>

              <Typography variant="h5" className="fw7 lora" gutterBottom>
                fw7 lora - Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy text
                ever since the 1500s, when an unknown prlora took a galley of type
                and scrambled it to make a type specimen book.
              </Typography>
            </Box>
          </Box>

          {/* Input Field Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Input Field Components
            </Typography>
            <Stack direction="column" spacing={2} mt={2}>
              <SimpleAutoComplete label="Movie" options={options} />
              <SimpleMultiSelectAutoComplete
                label="Select Document(s)"
                options={options2}
              />
              <SimpleMulticheckAutoComplete
                label="multi Document(s)"
                options={options2}
                value={selectedDocuments}
                onChange={(event, newValue) => {
                  setSelectedDocuments(newValue);
                  console.log("Selected documents:", newValue);
                }}
              />
              <SimpleDatePicker label="Transaction Date*" />
              <SimpleTextField label="Transaction Date*" />
            </Stack>
          </Box>

          {/* Table Components Section */}
          <Box my={2}>
            <Typography variant="h5" className="fw6" gutterBottom>
              Table Components
            </Typography>
            <Box mt={2}>
              <DummyAGridTable />
            </Box>
          </Box>
        </Container>

        <DummyDialog
          open={openConformation}
          onClose={handleCloseConformation}
        />

        {/* Dialog Components */}
        <ConformationDialog
          open={openConformationDialog}
          onClose={handleCloseConformationDialog}
        />
        <ContainDialog
          open={openContain}
          onClose={handleCloseContain}
        />
        <DeleteDialog
          open={openDelete}
          onClose={handleCloseDelete}
        />
        <SuccessDialog
          open={openSuccess}
          onClose={handleCloseSuccess}
        />
        <VideoDialog
          open={openVideo}
          onClose={handleCloseVideo}
          videoId="dQw4w9WgXcQ"
          channel="youtube"
        />
      </MainLayout>
    </div>
  );
};

export default page;
