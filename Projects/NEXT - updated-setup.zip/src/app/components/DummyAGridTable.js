"use client";
import React, { useEffect, useState } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { VscCircleFilled } from "react-icons/vsc";
import { BsQuestionCircleFill } from "react-icons/bs";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import { Box, IconButton } from "@mui/material";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import { FaEye } from "react-icons/fa";
import { RiEdit2Fill } from "react-icons/ri";
import { MdDeleteOutline } from "react-icons/md";
import DummyDialog from "./DummyDialog";

ModuleRegistry.registerModules([AllCommunityModule]);

const DummyAGridTable = () => {
  // Conformation dialog
  const [openConformation, setOpenConformation] = useState(false);

  const handleOpenConformation = () => setOpenConformation(true);
  const handleCloseConformation = () => setOpenConformation(false);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const [rowData] = useState([
    {
      make: "Tesla",
      model: "Model Y",
      price: 64950,
      electric: true,
      result: "success",
    },
    {
      make: "Ford",
      model: "F-Series",
      price: 33850,
      electric: false,
      result: "processing",
    },
    {
      make: "Toyota",
      model: "Corolla",
      price: 29600,
      electric: false,
      result: "pending",
    },
    {
      make: "Mercedes",
      model: "EQA",
      price: 48890,
      electric: true,
      result: "success",
    },
    {
      make: "Fiat",
      model: "500",
      price: 15774,
      electric: false,
      result: "Suspended",
    },
    {
      make: "Nissan",
      model: "Juke",
      price: 20675,
      electric: false,
      result: "pending",
    },
  ]);

  const [colDefs] = useState([
    { field: "make", headerName: "Make", minWidth: 250 },
    { field: "model", headerName: "Model", minWidth: 250 },
    { field: "price", headerName: "Price", minWidth: 250 },
    {
      field: "electric",
      minWidth: 250,
      headerName: "Electric",
      cellRenderer: (params) =>
        params.value ? (
          <span style={{ color: "green", fontWeight: "bold" }}>Yes ⚡</span>
        ) : (
          <span style={{ color: "gray" }}>No</span>
        ),
    },
    {
      headerName: "Status",
      field: "Status",
      minWidth: 250,
      cellRenderer: (params) => {
        const result = params.data?.result;
        if (!result) return "";

        const statusMap = {
          success: { class: "green-btn", label: "Completed" },
          Suspended: { class: "red-btn", label: "Suspended" },
          processing: { class: "orange-btn", label: "In Process" },
          pending: { class: "yellow-btn", label: "On Hold", icon: true },
        };

        const status = statusMap[result];

        return (
          <span className={status.class}>
            <VscCircleFilled style={{ position: "relative", top: 2 }} />{" "}
            {status.label}
            {status.icon && (
              <>
                &nbsp;&nbsp;
                <BsQuestionCircleFill
                  className="pending"
                  style={{
                    position: "relative",
                    top: 2,
                    color: "#D0B404",
                    fontSize: "15px",
                  }}
                />
              </>
            )}
          </span>
        );
      },
    },
    {
      headerName: "% Doc Completion",
      field: "completion",
      minWidth: 250,
      cellRenderer: (params) => {
        const result = params.data?.result;
        const percentMap = {
          success: { class: "green", value: "100%" },
          Suspended: { class: "red", value: "0%" },
          processing: { class: "orange", value: "75%" },
          pending: { class: "yellow", value: "50%" },
        };

        const percent = percentMap[result];
        return percent ? (
          <span className={`${percent.class} fw5`}>{percent.value}</span>
        ) : (
          ""
        );
      },
    },
    {
      headerName: "Action",
      field: "action",
      minWidth: 160,
      cellRenderer: () => {
        return (
          <span style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <IconButton size="small" className="ico-btn">
              {" "}
              <FaEye className="col1" sx={{ fontSize: "20px" }} />
            </IconButton>
            <IconButton size="small" className="ico-btn">
              {" "}
              <RiEdit2Fill className="col1" />
            </IconButton>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={handleOpenConformation}
            >
              {" "}
              <MdDeleteOutline className="col1" />
            </IconButton>
          </span>
        );
      },
    },
  ]);

  const defaultColDef = {
    sortable: false,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "30vh", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box style={{ width: "100%", height: "30vh" }}>
            <AgGridReact
              rowData={rowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
            />
          </Box>

          <Box className="fx_sb" mt={1}>
            <AgGridInfo />
            <AgGridPagination />
          </Box>
        </>
      )}

      <DummyDialog open={openConformation} onClose={handleCloseConformation} />
    </>
  );
};

export default DummyAGridTable;
