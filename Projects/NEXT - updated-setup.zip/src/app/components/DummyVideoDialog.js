'use client';

import React, { useState } from 'react';
import ModalVideo from 'react-modal-video';
import 'react-modal-video/css/modal-video.css';
import { Box, Button } from '@mui/material';

const DummyVideoDialog = ({ videoId = 'L61p2uyiMSo', channel = 'youtube' }) => {
  const [isOpen, setOpen] = useState(false);

  return (
    <Box>
      <Button variant='outlined' className='gray-action-btn' onClick={() => setOpen(true)}>
        Watch Video in Dialog
      </Button>

      <ModalVideo
        channel={channel}
        isOpen={isOpen}
        videoId={videoId}
        onClose={() => setOpen(false)}
      />
    </Box>
  );
};

export default DummyVideoDialog;
