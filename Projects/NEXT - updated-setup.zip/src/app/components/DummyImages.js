import React from 'react'
import { Box, Container, Stack, Typography } from '@mui/material' 
import Image from 'next/image';
import Grid from "@mui/material/Grid";
import { MdNavigateNext } from "react-icons/md";
import HeroBanner from '../../../public/assets/herobanner.jpg'

const DummyImages = () => {
    return (
        <>
            <Box className="smHeroSection">
                <Image
                    src={HeroBanner}
                    alt="Background"
                    fill
                    style={{ objectFit: 'cover', objectPosition: 'center' }}
                    quality={100}
                    priority
                />
                <Box className="gradient-overlay"></Box>
                <Box className="content">
                    <Container maxWidth="lg">
                        <Grid container spacing={0} alignItems="center" justifyContent="flex-start">
                            <Grid size={{ lg: 10, md: 10, sm: 10, xs: 12 }}>
                                {/* Static Breadcrumbs */}
                                <Stack direction="row" alignItems="center" justifyContent="flex-start" spacing={1}>
                                    <Typography variant="h5" className='fw4 white'>
                                        Who We Are
                                    </Typography>
                                    <MdNavigateNext style={{ color: 'white' }} />
                                    <Typography variant="h5" className='fw5 white'>
                                        Decimal Sutras
                                    </Typography>
                                </Stack>
                                {/* Static Breadcrumbs */}
                                <Box pt={3} pb={3}>
                                    <Typography variant="h1" className='white fw4 lora'>
                                        Our Core
                                        <br />
                                        <span className='fw6'>Organizational Values</span>
                                    </Typography>
                                </Box>
                            </Grid>
                        </Grid>
                    </Container>
                </Box>
            </Box>
        </>
    )
}

export default DummyImages