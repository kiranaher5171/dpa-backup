'use client';
import React, { useEffect, useState } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { VscCircleFilled } from "react-icons/vsc";
import { BsQuestionCircleFill } from "react-icons/bs";
import { Box, IconButton } from "@mui/material";
import { FaEye } from "react-icons/fa";
import { RiEdit2Fill } from "react-icons/ri";
import { MdDeleteOutline } from "react-icons/md";
import DummyDialog from "./DummyDialog";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination"; 

ModuleRegistry.registerModules([AllCommunityModule]);

const DummyAGridTableExpand = () => {
  const [openConformation, setOpenConformation] = useState(false);
  const handleOpenConformation = () => setOpenConformation(true);
  const handleCloseConformation = () => setOpenConformation(false);

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  const [rowData] = useState([
    { id: 1, make: "Tesla", model: "Model Y", price: 64950, electric: true, result: 'success' },
    { id: 2, make: "Ford", model: "F-Series", price: 33850, electric: false, result: 'processing' },
    { id: 3, make: "Toyota", model: "Corolla", price: 29600, electric: false, result: 'pending' },
    { id: 4, make: "Mercedes", model: "EQA", price: 48890, electric: true, result: 'success' },
  ]);

  const [colDefs] = useState([
    {
      headerName: '',
      cellRenderer: 'agGroupCellRenderer',
      minWidth: 60,
      maxWidth: 60,
      cellRendererParams: {
        suppressCount: true,
        innerRenderer: (params) => params.data?.make || '',
      },
    },
    { field: "model", headerName: "Model" },
    { field: "price", headerName: "Price" },
    {
      field: "electric",
      headerName: "Electric",
      cellRenderer: (params) =>
        params.value ? (
          <span style={{ color: "green", fontWeight: "bold" }}>Yes ⚡</span>
        ) : (
          <span style={{ color: "gray" }}>No</span>
        ),
    },
    {
      headerName: 'Status',
      field: 'Status',
      cellRenderer: (params) => {
        const result = params.data?.result;
        const statusMap = {
          success: { class: "green-btn", label: "Completed" },
          Suspended: { class: "red-btn", label: "Suspended" },
          processing: { class: "orange-btn", label: "In Process" },
          pending: { class: "yellow-btn", label: "On Hold", icon: true },
        };
        const status = statusMap[result];
        return (
          <span className={status?.class}>
            <VscCircleFilled style={{ position: "relative", top: 2 }} /> {status?.label}
            {status?.icon && (
              <>
                &nbsp;&nbsp;
                <BsQuestionCircleFill style={{ color: "#D0B404", fontSize: "15px" }} />
              </>
            )}
          </span>
        );
      },
    },
    {
      headerName: 'Action',
      field: 'action',
      cellRenderer: () => {
        return (
          <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <IconButton size="small"> <FaEye className="col1" /></IconButton>
            <IconButton size="small"> <RiEdit2Fill className="col1" /></IconButton>
            <IconButton size="small" onClick={handleOpenConformation}> <MdDeleteOutline className="col1" /></IconButton>
          </span>
        );
      }
    },
  ]);

  const defaultColDef = {
    sortable: false,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  return (
    <>
      {loading ? (
        <Box style={{ width: '100%', height: '30vh' }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box className="ag-theme-alpine" style={{ width: "100%", height: "60vh" }}>
            <AgGridReact
              rowData={rowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              masterDetail={true}
              detailCellRendererParams={{
                detailGridOptions: {
                  columnDefs: [
                    { field: 'docName', headerName: 'Document Name' },
                    { field: 'docType', headerName: 'Document Type' },
                    { field: 'aiRemark', headerName: 'AI Remark' },
                    { field: 'confidence', headerName: 'Confidence' },
                    { field: 'status', headerName: 'Status' },
                    { field: 'action', headerName: 'Action' },
                  ],
                  defaultColDef: {
                    flex: 1,
                    resizable: true,
                  },
                  rowHeight: 35,
                },
                getDetailRowData: function (params) {
                  params.successCallback([
                    { docName: "PAN", docType: "ID", aiRemark: "Valid", confidence: "High", status: "Verified", action: "View" },
                    { docName: "Aadhar", docType: "ID", aiRemark: "Mismatch", confidence: "Low", status: "Error", action: "Edit" },
                    { docName: "Bank Statement", docType: "Financial", aiRemark: "Incomplete", confidence: "Medium", status: "Pending", action: "Upload" },
                    { docName: "Salary Slip", docType: "Income", aiRemark: "Valid", confidence: "High", status: "Verified", action: "View" },
                  ]);
                },
              }}
            />
          </Box>

          <Box className="fx_sb" mt={1}>
            <AgGridInfo />
            <AgGridPagination />
          </Box>
        </>
      )}

      <DummyDialog open={openConformation} onClose={handleCloseConformation} />
    </>
  );
};

export default DummyAGridTableExpand;
