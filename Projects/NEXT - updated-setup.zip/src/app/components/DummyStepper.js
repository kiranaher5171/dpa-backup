'use client';

import React, { useState } from 'react';
import {
  Stepper, Step, StepLabel, StepConnector,
  Box, Stack, Typography, Button
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { FaCheck } from 'react-icons/fa';
import { SiSquare } from 'react-icons/si';

// --- Custom Connector ---
const CustomConnector = styled(StepConnector)({
  '& .MuiStepConnector-line': {
    borderColor: '#d0d0d0',
    borderTopWidth: 2,
  },
  '&.Mui-active .MuiStepConnector-line, &.Mui-completed .MuiStepConnector-line': {
    borderColor: '#1d3acc',
  },
});

// --- Custom Step Icon ---
const StepIconRoot = styled('div')(({ active, completed }) => ({
  backgroundColor: completed ? '#1d3acc' : active ? '#e6e9fb' : '#ccc',
  color: completed ? '#fff' : active ? '#1d3acc' : '#999',
  width: 20,
  height: 20,
  borderRadius: 4,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  fontSize: 12,
}));

function CustomStepIcon({ active, completed }) {
  return (
    <StepIconRoot active={active} completed={completed}>
      {completed ? <FaCheck size={12} /> : active ? <SiSquare size={12} /> : ''}
    </StepIconRoot>
  );
}

const steps = [
  'Curate collection',
  'Folder selection',
  'Collection setup',
  'Feed selection',
  'Go to dashboard',
  'Finalize and Submit',
];

export default function DummyStepper() {
  const [activeStep, setActiveStep] = useState(0);

  const handleNext = () => {
    setActiveStep((prev) => prev + 1);
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  const renderStepContent = (step) => (
    <Typography variant="body1">Step {step + 1}: content here.</Typography>
  );

  return (
    <Box sx={{ width: '100%' }}>
      <Stack spacing={3}>
        {/* Step Content */}
        <Box p={2} minHeight="100px">
          {activeStep === steps.length ? (
            <Typography variant="h6">All steps completed - you're finished</Typography>
          ) : renderStepContent(activeStep)}
        </Box>

        {/* Stepper */}
        <Stepper alternativeLabel activeStep={activeStep} connector={<CustomConnector />}>
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel StepIconComponent={CustomStepIcon}>
                <Typography
                  variant="h6"
                  className="fs12"
                  sx={{
                    color: index <= activeStep ? '#1d3acc' : '#555',
                    fontWeight: 500,
                  }}
                >
                  {label}
                </Typography>
              </StepLabel>
            </Step>
          ))}
        </Stepper>

        {/* Buttons */}
        <Stack direction="row" spacing={2} justifyContent="center" alignItems="center" pb={3}>
          {activeStep > 0 && (
            <Button variant="outlined" className="primary-outline-btn" onClick={handleBack}>
              Back
            </Button>
          )}
          {activeStep < steps.length ? (
            <Button variant="contained" className="primary-action-btn" onClick={handleNext}>
              {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
            </Button>
          ) : (
            <Button onClick={handleReset}>Reset</Button>
          )}
        </Stack>
      </Stack>
    </Box>
  );
}
