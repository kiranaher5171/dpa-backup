"use client"
import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';

export default function DummyTabs() {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box className="page-section">
      <Box id="simpleTabs" sx={{ width: '100%' }}>
        <Tabs
          value={value}
          onChange={handleChange}
          variant="scrollable"
          scrollButtons="auto"
          allowScrollButtonsMobile
          aria-label="Radar Health History tabs"
          sx={{
            '& .MuiTabs-scrollButtons': {
              '&.Mui-disabled': {
                opacity: 0.3,
              },
            },
          }}
        >
          <Tab label="All(20)" />
          <Tab label="Completed (6)" />
          <Tab label="In process(6)" />
          <Tab label="On hold(552)" />
          <Tab label="Suspended(52)" />
        </Tabs>
        {value === 0 && (
          <Box sx={{ p: 3 }}>
            Tabs All
          </Box>
        )}
        {value === 1 && (
          <Box sx={{ p: 3 }}>
            Tabs Completed
          </Box>
        )}
        {value === 2 && (
          <Box sx={{ p: 3 }}>
            Tabs process
          </Box>
        )}
        {value === 3 && (
          <Box sx={{ p: 3 }}>
            Tabs hold
          </Box>
        )}
        {value === 4 && (
          <Box sx={{ p: 3 }}>
            Tabs Suspended
          </Box>
        )}
      </Box>
    </Box>
  );
}
