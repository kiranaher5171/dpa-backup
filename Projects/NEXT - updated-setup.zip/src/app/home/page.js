import HeaderFooterLayout from '@/layouts/header-footer-layout/HeaderFooterLayout';
import MainLayout from '../../layouts/sidebar-layout/MainLayout';
import { Container } from '@mui/material'
import React from 'react'

const page = () => {
    return (
        <>
            <HeaderFooterLayout>
                <Container maxWidth>
                    home
                </Container>
            </HeaderFooterLayout>
        </>
    )
}

export default page