import HeaderFooterLayout from '@/layouts/header-footer-layout/HeaderFooterLayout';
import { Container } from '@mui/material';
import React from 'react';

export default function OverviewPage() {
  return (
    <HeaderFooterLayout>
      <Container maxWidth>
        <h1>Overview</h1>
        <p>Home overview content.</p>
      </Container>
    </HeaderFooterLayout>
  );
}
