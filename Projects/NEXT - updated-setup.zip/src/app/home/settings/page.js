import HeaderFooterLayout from '@/layouts/header-footer-layout/HeaderFooterLayout';
import { Container } from '@mui/material';
import React from 'react';

export default function SettingsPage() {
  return (
    <HeaderFooterLayout>
      <Container maxWidth>
        <h1>Settings</h1>
        <p>Home settings content.</p>
      </Container>
    </HeaderFooterLayout>
  );
}
