import HeaderFooterLayout from '@/layouts/header-footer-layout/HeaderFooterLayout';
import { Container } from '@mui/material';
import React from 'react';

export default function DetailsPage() {
  return (
    <HeaderFooterLayout>
      <Container maxWidth>
        <h1>Details</h1>
        <p>Home details content.</p>
      </Container>
    </HeaderFooterLayout>
  );
}
