"use client";
import VisibilityOffOutlinedIcon from "@mui/icons-material/VisibilityOffOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import {
  Box,
  Button,
  Checkbox,
  Grid,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
  Snackbar,
  Alert,
} from "@mui/material";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";
import LOGO from "../../../../public/assets/logo.svg";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";

const Form = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const router = useRouter();

  const handleShowPasswordToggle = () => setShowPassword((prev) => !prev);

  const handleSnackbarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setSnackbarOpen(false);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    setSnackbarOpen(true);
    setTimeout(() => {
      router.push("/dashboard");
    }, 1500);
  };

  return (
    <>
      <Box className="form-card">
        <Box pb={4} className="center">
          <Image src={LOGO} className="auth-logo" alt="iFieldSmart Technologies" priority />
        </Box>

        <Box mb={5} mt={1}>
          <Typography variant="h4" className="form-heading">
            LOGIN
          </Typography>
        </Box>

        <Box>
          <form onSubmit={handleLogin}>
            <Grid container alignItems="top" justifyContent="center" spacing={3}>
              <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                <Box className="form-textfield">
                  <TextField
                    placeholder="Email Address"
                    variant="outlined"
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="end">
                          <EmailOutlinedIcon className="secondary" />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
              </Grid>

              {/* Password Field */}
              <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                <Box className="form-textfield">
                  <TextField
                    placeholder="Password"
                    variant="outlined"
                    type={showPassword ? "text" : "password"}
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="end">
                          <LockOutlinedIcon className="secondary" />
                        </InputAdornment>
                      ),
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            size="small"
                            onClick={handleShowPasswordToggle}
                            edge="end"
                          >
                            {showPassword ? (
                              <VisibilityOutlinedIcon
                                fontSize="small"
                                className="primary"
                              />
                            ) : (
                              <VisibilityOffOutlinedIcon
                                fontSize="small"
                                className="primary"
                              />
                            )}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
              </Grid>

              <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                <Box display="flex" alignItems="center">
                  <Checkbox
                    id="rememberMe"
                    color="primary"
                    className="checkbox col1"
                    size="small"
                  />
                  <Typography
                    htmlFor="rememberMe"
                    variant="body2"
                    className="col1 fw4 h6"
                    component="label"
                    sx={{ cursor: "pointer", userSelect: "none" }}
                  >
                    Remember Me
                  </Typography>
                </Box>
              </Grid>

              {/* Forgot Password */}
              <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                <Box className="right" mt={0}>
                  <Typography variant="h6" className="primary fw6">
                    <a href="/forgot-password">Forgot Password?</a>
                  </Typography>
                </Box>
              </Grid>

              {/* Submit Button */}
              <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                <Box>
                  <Button
                    type="submit"
                    variant="contained"
                    className="auth-btn"
                    fullWidth
                    disableRipple
                  >
                    Login
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </form>
        </Box>
      </Box>
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={1500}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity="success"
          variant="filled"
          sx={{ width: "100%" }}
        >
          Login successful! Redirecting...
        </Alert>
      </Snackbar>
    </>
  );
};

export default Form;
