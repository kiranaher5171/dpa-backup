import MainLayout from '../../layouts/sidebar-layout/MainLayout';
import { Container } from '@mui/material'
import React from 'react'

const page = () => {
    return (
        <>
            <MainLayout> 
                    Dashboard   home 
            </MainLayout>
        </>
    )
}

export default page