"use client";
import * as React from 'react';
import { useState } from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import IconButton from '@mui/material/IconButton';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import logo from '../../public/assets/hr-connect.png';
import smlogo from '../../public/assets/hr-connect.png';
import { AppBar, Autocomplete, Avatar, Badge, Button, ListItemAvatar, Menu, TextField, Stack, Toolbar, Tooltip, Typography } from '@mui/material';
import Image from 'next/image';
import Link from 'next/link';
import LogoutIcon from '@mui/icons-material/Logout';
import { usePathname } from 'next/navigation';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import MobileDrawer from './MobileDrawer';
import { IoNotificationsOutline } from "react-icons/io5";
import MenuIcon from '@mui/icons-material/Menu';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import { RiRefund2Line } from "react-icons/ri";
import { LuUserCog } from "react-icons/lu";


import Footer from './Footer';

const drawerWidth = 260;

const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
});

const closedMixin = (theme) => ({
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: `calc(${theme.spacing(10)} + 1px)`,
    [theme.breakpoints.up('sm')]: {
        width: `calc(${theme.spacing(10)} + 1px)`,
    },
});

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        width: drawerWidth,
        flexShrink: 0,
        whiteSpace: 'nowrap',
        boxSizing: 'border-box',
        ...(open && {
            ...openedMixin(theme),
            '& .MuiDrawer-paper': openedMixin(theme),
        }),
        ...(!open && {
            ...closedMixin(theme),
            '& .MuiDrawer-paper': closedMixin(theme),
        }),
    }),
);


const rolesToSwitch = [
    { label: 'User' },
    { label: 'Admin' },
    { label: 'Super Admin' },
]


export default function MainLayout({ children }) {
    const [open, setOpen] = useState(true);
    const pathname = usePathname();

    const menuItems = [
        { href: '/', title: 'Reimbursements', icon: <RiRefund2Line />, activePaths: ['/', '/reimbursements-details'] },
        { href: '/user-and-roles', title: 'User & Roles', icon: <LuUserCog />, activePaths: ['/user-and-roles'] },
    ];

    const isActive = (paths) => {
        return paths.some(path => {
            if (path === '/') {
                return pathname === '/'; // exact match only for home
            }
            return pathname.startsWith(path);
        });
    };

    // Profile Menu
    const [anchorElP, setAnchorElP] = React.useState(null);
    const openP = Boolean(anchorElP);
    const handleClickP = (event) => {
        setAnchorElP(event.currentTarget);
    };
    const handleCloseP = () => {
        setAnchorElP(null);
    };

    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <CssBaseline />


                <Drawer variant="permanent" open={open} className="drawer" id="desktop-only">
                    <Box className="sidebar-bg">

                        <Box className="w100 center">
                            {open ?
                                <Image src={logo} className="logo no-select" draggable="false" alt="Logo" />
                                :
                                <Image src={smlogo} className="smlogo no-select" draggable="false" alt="Logo" />
                            }
                        </Box>

                        <Box id="menus">
                            <List>
                                {menuItems.map((item) => (
                                    <Link href={item.href} passHref key={item.href}>
                                        <ListItem disablePadding>
                                            <ListItemButton disableRipple selected={isActive(item.activePaths)}>
                                                <Tooltip title={item.title} arrow placement="right">
                                                    <ListItemIcon>{item.icon}</ListItemIcon>
                                                </Tooltip>
                                                <ListItemText primary={item.title} sx={{ opacity: open ? 1 : 0 }} />
                                            </ListItemButton>
                                        </ListItem>
                                    </Link>
                                ))}
                            </List>
                        </Box>

                    </Box>
                </Drawer>

                <Box component="main">


                    <AppBar position="sticky" open={open} id="header">
                        <Toolbar className='fx_sb'>

                            <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
                                <Box id="desktop-only">
                                    <Tooltip title="Collapse" arrow placement="bottom">
                                        <IconButton onClick={() => setOpen(!open)} size="small" sx={{ display: open ? '' : 'none' }}>
                                            <MenuOpenIcon fontSize="medium" className="primary" />
                                        </IconButton>
                                    </Tooltip>
                                    <Tooltip title="Expand" arrow placement="bottom">
                                        <IconButton onClick={() => setOpen(!open)} size="small" sx={{ display: open ? 'none' : '' }}>
                                            <MenuIcon fontSize="medium" className="primary" />
                                        </IconButton>
                                    </Tooltip>
                                </Box>

                                <Box id="mobile-only" className="w100 center">
                                    <Image src={logo} className="m-logo no-select" alt="Logo" draggable="false" />
                                </Box>
                            </Stack>

                            <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={2}>

                                <Box className="notifications">
                                    <Badge color="primary" badgeContent={4}>
                                        <IconButton>
                                            <IoNotificationsOutline />
                                        </IconButton>
                                    </Badge>
                                </Box>

                                <Box id="desktop-only" className='textfield auto-complete noClear'>
                                    <Autocomplete
                                        disablePortal
                                        options={rolesToSwitch}
                                        sx={{ width: 160 }}
                                        renderInput={(params) => <TextField {...params} label="Role" variant='outlined' />}
                                    />
                                </Box>

                                <Box id="profile">
                                    <List id="desktop-only">
                                        <ListItem disablePadding secondaryAction={<ArrowDropDownIcon />}>
                                            <ListItemButton disableRipple onClick={handleClickP}>
                                                <ListItemAvatar>
                                                    <Avatar>
                                                        AK
                                                    </Avatar>
                                                </ListItemAvatar>
                                                <ListItemText primary={<Typography variant='h6'>Amit Kumar</Typography>} />
                                            </ListItemButton>
                                        </ListItem>
                                    </List>
                                    <List id="mobile-only">
                                        <ListItem disablePadding>
                                            <ListItemButton disableRipple onClick={handleClickP}>
                                                <ListItemAvatar>
                                                    <Avatar>
                                                        AK
                                                    </Avatar>
                                                </ListItemAvatar>
                                            </ListItemButton>
                                        </ListItem>
                                    </List>
                                </Box>

                                <Box id="mobile-only">
                                    <MobileDrawer />
                                </Box>

                            </Stack>




                        </Toolbar>
                    </AppBar>

                    <Box className="child-content">
                        {children}
                    </Box>


                    <Footer />
                </Box>
            </Box>



            <Menu
                anchorEl={anchorElP}
                id="profile-menu"
                open={openP}
                onClose={handleCloseP}
                onClick={handleCloseP}
                slotProps={{
                    paper: {
                        elevation: 0,
                        sx: {
                            overflow: 'visible',
                            filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.25))',
                            '&::before': {
                                content: '""',
                                display: 'block',
                                position: 'absolute',
                                top: 0,
                                right: 12,
                                width: 10,
                                height: 10,
                                bgcolor: 'background.paper',
                                transform: 'translateY(-50%) rotate(45deg)',
                                zIndex: 0,
                            },
                        },
                    },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
                <Stack direction="column" alignItems="center" justifyContent="center" spacing={1}>
                    <Button variant="text" className="profile-options" startIcon={<PersonOutlineOutlinedIcon />} disableRipple onClick={handleCloseP}>Profile</Button>
                    <Button variant="text" className="profile-options" startIcon={<LogoutIcon />} disableRipple onClick={handleCloseP}>Logout</Button>
                </Stack>
            </Menu>


        </>
    );
}
