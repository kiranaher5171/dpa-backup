"use client"
import * as React from 'react';
import { useState } from 'react';
import { Box, Drawer, IconButton } from '@mui/material';
import MobileDrawerContent from './MobileDrawerContent';
import { RiMenu3Fill } from "react-icons/ri";
import { RiMenuFold2Line } from "react-icons/ri";

export default function MobileDrawer() {
    const [state, setState] = useState({ right: false });

    const toggleDrawer = (anchor, open) => () => {
        setState({ ...state, [anchor]: open });
    };

    const isDrawerOpen = state['right'];

    const handleCloseDrawer = () => {
        setState({ ...state, right: false });
    };

    return (
        <>
            <IconButton
                className='drawer_btn'
                size='medium'
                onClick={toggleDrawer('right', !isDrawerOpen)}
            >
                {isDrawerOpen ? <RiMenuFold2Line /> : <RiMenu3Fill />}
            </IconButton>

            <Drawer id='mobile-drawer' anchor="right" open={isDrawerOpen} onClose={toggleDrawer('right', false)}>

                <Box className="sidebar-bg">
                    <Box height={'60px'}>
                        <IconButton
                            className='drawer_btn'
                            size='medium'
                            onClick={toggleDrawer('right', !isDrawerOpen)}
                        >
                            {isDrawerOpen ? <RiMenuFold2Line /> : <RiMenu3Fill />}
                        </IconButton>
                    </Box>


                    <MobileDrawerContent onClose={handleCloseDrawer} />

                </Box>
            </Drawer >
        </>
    );
}
