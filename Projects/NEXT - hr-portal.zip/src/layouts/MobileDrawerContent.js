"use client";
import * as React from 'react';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import { Tooltip } from '@mui/material';
import Link from 'next/link';
import { usePathname } from 'next/navigation'; // Import usePathname
import HealthAndSafetyOutlinedIcon from '@mui/icons-material/HealthAndSafetyOutlined';
import { RiRefund2Line } from "react-icons/ri";
import { LuUserCog } from "react-icons/lu";
import { Autocomplete, TextField } from '@mui/material';


const rolesToSwitch = [
    { label: 'User' },
    { label: 'Admin' },
    { label: 'Super Admin' },
]

export default function MobileDrawerContent({ onClose }) {

    const pathname = usePathname(); // Use usePathname hook



    const menuItems = [
         { href: '/', title: 'Reimbursements', icon: <RiRefund2Line />, activePaths: ['/', '/reimbursements-details'] },
         { href: '/user-and-roles', title: 'User & Roles', icon: <LuUserCog />, activePaths: ['/user-and-roles'] },
     ];
 




      const isActive = (paths) => {
        return paths.some(path => {
            if (path === '/') {
                return pathname === '/'; // exact match only for home
            }
            return pathname.startsWith(path);
        });
    };

    return (
        <>
            <Box> 
                <Box id="mobile-only" className='textfield auto-complete noClear'>
                    <Autocomplete
                        disablePortal
                        options={rolesToSwitch}
                        fullWidth
                        renderInput={(params) => <TextField {...params} label="Role" variant='outlined' />}
                    />
                </Box>


                <Box id="menus">
                    <List>
                        {menuItems.map((item) => (
                            <Link href={item.href} passHref key={item.href}>
                                <ListItem disablePadding>
                                    <ListItemButton onClick={onClose} selected={isActive(item.activePaths)}>
                                        <Tooltip title={item.title} arrow placement="right">
                                            <ListItemIcon>
                                                {item.icon}
                                            </ListItemIcon>
                                        </Tooltip>
                                        <ListItemText primary={item.title} />
                                    </ListItemButton>
                                </ListItem>
                            </Link>
                        ))}
                    </List>

                </Box>
            </Box>
        </>
    );
}
