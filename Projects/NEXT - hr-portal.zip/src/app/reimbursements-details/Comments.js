"use client";
import React from 'react'
import MainLayout from '@/layouts/MainLayout'
import { Typography, Box, Container, Stack, Button, TextField, InputAdornment, IconButton, Chip } from '@mui/material'
import { IoIosArrowForward } from "react-icons/io";
import Grid from '@mui/material/Grid2';
import ProgressTracker from './ProgressTracker';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import SimpleDatePicker from '@/components/SimpleDatePicker';
import PdfDropzone from '@/components/UploadDropzone';
import Link from 'next/link';
import { LuSendHorizontal } from "react-icons/lu";


const dummyOptions = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]

const Comments = () => {

    const [open, setOpen] = React.useState(false);

    const handleOpen = (user) => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };


    return (
        <>

            <Grid container spacing={1} alignItems="center" justifyContent="center">
                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box className="fx_sb" mt={2}>
                        <Typography variant='h5' className='fw5 black'>Comments:</Typography>
                        <Typography variant='h6' className='fw5 primary link ptr' onClick={handleOpen}>View all</Typography>
                    </Box>
                </Grid>
                <Grid size={{ lg: 8, md: 7, sm: 12, xs: 12 }}>
                    <Box className="profile-submit">
                        <List disablePadding>
                            <ListItem disableGutters disablePadding>
                                <ListItemAvatar>
                                    <Avatar>
                                        JD
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText
                                    primary={<><span className='black fw5'>John Doe</span> <span className='black'> &nbsp;|&nbsp;</span> <span className='gry-txt fw4'> Sr. Accountant</span></>}
                                    secondary={<><span className='gry-txt fw4'>All docs are ok. Reimbursement approved.</span></>}
                                />
                            </ListItem>
                        </List>
                    </Box>
                </Grid>
                <Grid size={{ lg: 4, md: 5, sm: 12, xs: 12 }}>
                    <Box className="right">
                        <Typography variant='h6' className='fw4 gry-txt' gutterBottom>15 feb 2025</Typography>
                    </Box>
                </Grid>
            </Grid>



            <Dialog
                open={open}
                onClose={handleClose}
                fullWidth
                maxWidth="sm"
            >
                <DialogTitle id="scroll-dialog-title">
                    <Typography variant='h5' className='fw6 black'>Comments:</Typography>
                </DialogTitle>

                <DialogContent>

                    {/* Comment 1 */}
                    <Grid container spacing={1} alignItems="center" justifyContent="center">
                        <Grid size={{ lg: 8, md: 7, sm: 12, xs: 12 }}>
                            <Box className="profile-submit" mb={2}>
                                <List disablePadding>
                                    <ListItem disableGutters disablePadding>
                                        <ListItemAvatar>
                                            <Avatar>
                                                JD
                                            </Avatar>
                                        </ListItemAvatar>
                                        <ListItemText
                                            primary={<><span className='black fw5'>John Doe</span> <span className='black'> &nbsp;|&nbsp;</span> <span className='gry-txt fw4'> Sr. Accountant</span></>}
                                            secondary={<><span className='gry-txt fw4'>All docs are ok. Reimbursement approved.</span></>}
                                        />
                                    </ListItem>
                                </List>
                            </Box>
                        </Grid>
                        <Grid size={{ lg: 4, md: 5, sm: 12, xs: 12 }}>
                            <Box className="right">
                                <Typography variant='h6' className='fw4 gry-txt' gutterBottom>15 feb 2025</Typography>
                            </Box>
                        </Grid>
                    </Grid>
                    {/* Comment 1 */}


                    {/* Comment 2 */}
                    <Grid container spacing={1} alignItems="center" justifyContent="center">
                        <Grid size={{ lg: 8, md: 7, sm: 12, xs: 12 }}>
                            <Box className="profile-submit" mb={2}>
                                <List disablePadding>
                                    <ListItem disableGutters disablePadding>
                                        <ListItemAvatar>
                                            <Avatar>
                                                JD
                                            </Avatar>
                                        </ListItemAvatar>
                                        <ListItemText
                                            primary={<><span className='black fw5'>John Doe</span> <span className='black'> &nbsp;|&nbsp;</span> <span className='gry-txt fw4'> Sr. Accountant</span></>}
                                            secondary={<><span className='gry-txt fw4'>All docs are ok. Reimbursement approved.</span></>}
                                        />
                                    </ListItem>
                                </List>
                            </Box>
                        </Grid>
                        <Grid size={{ lg: 4, md: 5, sm: 12, xs: 12 }}>
                            <Box className="right">
                                <Typography variant='h6' className='fw4 gry-txt' gutterBottom>15 feb 2025</Typography>
                            </Box>
                        </Grid>
                    </Grid>
                    {/* Comment 2 */}

                </DialogContent>

                <DialogActions>
                    <Grid container spacing={1} alignItems="center" justifyContent="center" className="w100">
                        <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                            <Box className="textfield standard auto-complete" mt={1}>
                                <TextField variant='standard' placeholder='Add Comment' size='small' fullWidth
                                    slotProps={{
                                        input: {
                                            endAdornment: <InputAdornment position="start">
                                                <IconButton className='add-comment-btn'>
                                                    <LuSendHorizontal />
                                                </IconButton>
                                            </InputAdornment>
                                        },
                                    }}
                                />
                            </Box>
                        </Grid>
                    </Grid>
                </DialogActions>
            </Dialog>



        </>
    )
}

export default Comments