import React from 'react'
import MainLayout from '@/layouts/MainLayout'
import { Typography, Box, Container, Stack, Button, TextField, InputAdornment, IconButton, Chip } from '@mui/material'
import { IoIosArrowForward } from "react-icons/io";
import Grid from '@mui/material/Grid2';
import ProgressTracker from './ProgressTracker';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import { LuSendHorizontal } from "react-icons/lu";
import Link from 'next/link';
import Comments from './Comments';

const page = () => {
    return (
        <>
            <MainLayout>

                <Container maxWidth>
                    <Grid container spacing={2} alignItems="flex-start" justifyContent="flex-start">
                        <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                            <Box py={1}>
                                <Stack direction="row" spacing={1} justifyContent={"flex-start"} alignItems="center">
                                    <Link href="/">
                                        <Typography variant='h5' className="fw5"> Reimbursements </Typography>
                                    </Link>
                                    <IoIosArrowForward />
                                    <Typography variant='h5' className="fw5"> Voucher R123 Amit Kumar </Typography>
                                </Stack>
                            </Box>
                            <Box mt={2}>
                                <ProgressTracker />
                            </Box>

                            <Box className="lunch-expense-scroll">
                                <Box className="whitebox" mt={2}>
                                    <Box>
                                        <Box mb={2}>
                                            <Typography variant='h4' className='fw6 text' gutterBottom>Lunch Expense</Typography>
                                        </Box>
                                        <Grid container spacing={3} alignItems="center" justifyContent="center">
                                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                                <Box>
                                                    <Typography variant='h6' className='fw4 gry-txt' gutterBottom>Time: 1 jan at 9:00 pm</Typography>
                                                    <Typography variant='h6' className='fw4 gry-txt' gutterBottom>Ocean view near  jehan circle nashik</Typography>
                                                </Box>
                                            </Grid>
                                            <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                                                <Box className="fx_fe gap2">
                                                    <Typography variant='h5' className='fw5 black right' gutterBottom>Amount to be Reimbursed</Typography>
                                                    <Box className="amount-box">
                                                        &#x20B9; 23,500
                                                    </Box>
                                                </Box>
                                            </Grid>
                                        </Grid>
                                    </Box>

                                    <Box mt={3}>
                                        {/* Submitted By - Profile */}
                                        <Grid container spacing={1} alignItems="center" justifyContent="center">
                                            <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                                <Box>
                                                    <Typography variant='h5' className='fw5 black'>Submitted By:</Typography>
                                                </Box>
                                            </Grid>

                                            <Grid size={{ lg: 8, md: 7, sm: 12, xs: 12 }}>
                                                <Box className="profile-submit">
                                                    <List disablePadding>
                                                        <ListItem disableGutters disablePadding>
                                                            <ListItemAvatar>
                                                                <Avatar>
                                                                    SS
                                                                </Avatar>
                                                            </ListItemAvatar>
                                                            <ListItemText
                                                                primary={<><span className='black fw5'>Sandesh Subedi</span> <span className='black'> &nbsp;|&nbsp;</span> <span className='gry-txt fw4'> UI Designer</span></>}
                                                                secondary={<><span className='gry-txt fw4'>Creative Department</span></>}
                                                            />
                                                        </ListItem>
                                                    </List>
                                                </Box>
                                            </Grid>
                                            <Grid size={{ lg: 4, md: 5, sm: 12, xs: 12 }}>
                                                <Box className="right">
                                                    <Typography variant='h6' className='fw4 gry-txt' gutterBottom>15 feb 2025</Typography>
                                                </Box>
                                            </Grid>
                                            <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                                <Box className="view-only-remark">
                                                    <Typography variant='h6' className='fw4 text'>
                                                        Remarks by employee Sandesh Sabudi
                                                    </Typography>
                                                </Box>
                                            </Grid>
                                        </Grid>
                                        {/* Submitted By - Profile */}

                                        {/* User Comment */}
                                        <Comments />
                                        {/* User Comment */}

                                        {/* Add Comment */}
                                        <Grid container spacing={1} alignItems="center" justifyContent="center">
                                            <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                                <Box className="textfield standard auto-complete" mt={1}>
                                                    <TextField variant='standard' placeholder='Add Comment' size='small' fullWidth
                                                        slotProps={{
                                                            input: {
                                                                endAdornment: <InputAdornment position="start">
                                                                    <IconButton className='add-comment-btn'>
                                                                        <LuSendHorizontal />
                                                                    </IconButton>
                                                                </InputAdornment>
                                                            },
                                                        }}
                                                    />
                                                </Box>
                                            </Grid>
                                        </Grid>
                                        {/* Add Comment */}

                                    </Box>
                                </Box>

                                <Box className="whitebox" mt={2}>
                                    <Box>
                                        <Grid container spacing={1} alignItems="center" justifyContent="center">
                                            <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                                <Box>
                                                    <Typography variant='h5' className='fw5 black'>Participants:</Typography>
                                                </Box>
                                            </Grid>
                                            <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                                                <Box className="chip-container" mt={1} mb={1}>
                                                    <Box className="chip-items fit-content">
                                                        <Chip label={<>2124 &nbsp;|&nbsp; Sarah wilson</>} variant="filled" className='active' />
                                                    </Box>
                                                    <Box className="chip-items fit-content">
                                                        <Chip label={<>2124 &nbsp;|&nbsp; Sarah wilson</>} variant="filled" className='active' />
                                                    </Box>
                                                    <Box className="chip-items fit-content">
                                                        <Chip label={<>2124 &nbsp;|&nbsp; Sarah wilson</>} variant="filled" className='active' />
                                                    </Box>
                                                    <Box className="chip-items fit-content">
                                                        <Chip label={<>2124 &nbsp;|&nbsp; Sarah wilson</>} variant="filled" className='active' />
                                                    </Box>
                                                    <Box className="chip-items fit-content">
                                                        <Chip label={<>2124 &nbsp;|&nbsp; Sarah wilson</>} variant="filled" className='active' />
                                                    </Box>
                                                    <Box className="chip-items fit-content">
                                                        <Chip label={<>2124 &nbsp;|&nbsp; Sarah wilson</>} variant="filled" className='active' />
                                                    </Box>
                                                </Box>
                                            </Grid>
                                        </Grid>
                                    </Box>
                                </Box>
                            </Box>

                            <Box pt={1}>
                                <Stack direction="row" alignItems="center" justifyContent="flex-end" spacing={2}>
                                    <Button variant='outlined' className='btn-tertiary-outlined'>Revise</Button>
                                    <Button variant='outlined' className='btn-error-outlined'>Reject</Button>
                                    <Button variant='contained' className='btn-primary-contained'>Approve & Process</Button>
                                </Stack>
                            </Box>



                        </Grid>
                        <Grid size={{ lg: 6, md: 6, sm: 12, xs: 12 }}>
                            <Box py={1} sx={{ background: '#ffffff', height: 'calc( 100vh - 125px )', borderRadius: '2px' }}>

                            </Box>
                        </Grid>
                    </Grid>


                </Container>

            </MainLayout>


        </>
    )
}

export default page