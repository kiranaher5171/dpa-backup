import "./root.css";
import localFont from 'next/font/local';
import ThemeProviderComponent from "@/components/ThemeProviderComponent";
import crypto from 'crypto';


const poppins = localFont({
  src: [
    {
      path: "../../public/fonts/Poppins/Poppins-Thin.ttf",
      weight: "100",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins/Poppins-Light.ttf",
      weight: "300",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins/Poppins-Regular.ttf",
      weight: "400",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins/Poppins-medium.ttf",
      weight: "500",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins/Poppins-SemiBold.ttf",
      weight: "600",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins/Poppins-Bold.ttf",
      weight: "700",
      style: "normal",
    },
    {
      path: "../../public/fonts/Poppins/Poppins-ExtraBold.ttf",
      weight: "800",
      style: "normal",
    },
  ],
  display: 'swap', // This tells the browser to use fallback fonts until the custom font is loaded
  variable: "--font-poppins",
});


export const viewport = 'width=device-width, initial-scale=1';

export const metadata = {
  title: "DPA HR Connect",
};

export default function RootLayout({ children }) {
  const nonce = crypto.randomBytes(16).toString('base64');

  return (
    <html lang="en" className={poppins.variable}>
      <body className={poppins.className}>
        <ThemeProviderComponent nonce={nonce}>
          <main>
            {children}
          </main>
        </ThemeProviderComponent>
      </body>
    </html>
  );
}
