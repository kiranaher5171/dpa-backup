"use client";
import React, { useState } from 'react';
import { IconButton, Menu, MenuItem, Tooltip, Divider, Dialog, DialogTitle, Typography, DialogContent, TextField, Autocomplete, DialogActions, Button, Box } from '@mui/material';
import { BsThreeDots } from 'react-icons/bs';
import Grid from '@mui/material/Grid2';
import CloseIcon from '@mui/icons-material/Close';
import { MdOutlineFileDownloadDone } from "react-icons/md";
import { IoBanSharp } from "react-icons/io5";


const dummyOptions = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
]

const ActionMenu = ({ data }) => {
    const [anchorEl, setAnchorEl] = useState(null);
    const menuOpen = Boolean(anchorEl);

    const menuHandleClick = (event) => {
        event.stopPropagation();
        setAnchorEl(event.currentTarget);
    };

    const menuHandleClose = () => {
        setAnchorEl(null);
    };

    // For Dialog
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => { setOpen(true); };
    const handleClose = () => { setOpen(false); };

    // For Success Dialog
    const [open1, setOpen1] = React.useState(false);
    const handleOpen1 = () => { setOpen(false); setOpen1(true); };
    const handleClose1 = () => { setOpen1(false); };


    // For Failed Dialog
    const [open2, setOpen2] = React.useState(false);
    const handleOpen2 = () => { setOpen2(true); };
    const handleClose2 = () => { setOpen2(false); };

    return (
        <>
            <Tooltip arrow title="More actions">
                <IconButton className='sq_ico_btn black' onClick={menuHandleClick}>
                    <BsThreeDots />
                </IconButton>
            </Tooltip>

            <Menu
                anchorEl={anchorEl}
                open={menuOpen}
                onClose={menuHandleClose}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                slotProps={{
                    paper: {
                        elevation: 0,
                        sx: {
                            overflow: 'visible',
                            filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.25))',
                            '&::before': {
                                content: '""',
                                display: 'block',
                                position: 'absolute',
                                top: 0,
                                right: 12,
                                width: 10,
                                height: 10,
                                bgcolor: 'background.paper',
                                transform: 'translateY(-50%) rotate(45deg)',
                                zIndex: 0,
                            },
                        },
                    },
                }}
            >
                <MenuItem
                    disableRipple
                    onClick={() => {
                        menuHandleClose(); // Close the menu first
                        handleOpen2();     // Then open the dialog
                    }}
                >
                    Disable User
                </MenuItem>
                <Divider />
                <MenuItem
                    disableRipple
                    onClick={() => {
                        menuHandleClose();
                        handleOpen1();
                    }}
                >
                    Grant a Role
                </MenuItem>
                <Divider />
                <MenuItem
                    disableRipple
                    onClick={() => {
                        menuHandleClose();
                        handleOpen();
                    }}
                >
                    Revoke a Role
                </MenuItem>

            </Menu>





            <Dialog
                open={open}
                onClose={handleClose}
                fullWidth
                maxWidth="xs"
            >
                <DialogTitle id="scroll-dialog-title">
                    <Typography variant='h5' className='fw6 black'>Grant User a Role</Typography>
                </DialogTitle>

                <DialogContent>


                    <Grid container spacing={3} alignItems="flex-start" justifyContent="flex-start">
                        <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                            <Box className='textfield auto-complete' mt={2}>
                                <Typography variant='body1' className='label'>Grant User a Role</Typography>
                                <TextField placeholder="Username" variant='outlined' fullWidth />
                            </Box>
                        </Grid>

                        <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                            <Box className='textfield auto-complete' pb={'40px'}>
                                <Typography variant='body1' className='label'>Role to grant</Typography>
                                <Autocomplete
                                    disablePortal
                                    options={dummyOptions}
                                    fullWidth
                                    renderInput={(params) => <TextField {...params} placeholder="Select" variant='outlined' />}
                                />
                            </Box>
                        </Grid>

                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Button variant='outlined' className='btn-tertiary-outlined' onClick={handleClose}>Cancel</Button>
                    <Button variant='contained' className='btn-primary-contained' onClick={handleOpen1}>Grant</Button>
                </DialogActions>
            </Dialog>



            {/* Role Granted */}
            <Dialog
                open={open1}
                onClose={handleClose1}
                fullWidth
                maxWidth="xs"
            >
                <IconButton
                    aria-label="close"
                    onClick={handleClose1}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent>

                    <Box className="center w100">
                        <Box pt={3} className="center">
                            <Box className="dialog-img primary">
                                <MdOutlineFileDownloadDone />
                            </Box>
                        </Box>
                        <Box py={3}>
                            <Typography variant='h5' className='primary fw6'>
                                Role Granted Successfully
                            </Typography>
                        </Box>
                    </Box>

                </DialogContent>

            </Dialog>



            {/* Role Granted */}
            <Dialog
                open={open2}
                onClose={handleClose2}
                fullWidth
                maxWidth="xs"
            >
                <IconButton
                    aria-label="close"
                    onClick={handleClose2}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent>

                    <Box className="center w100">
                        <Box pt={3} className="center">
                            <Box className="dialog-img red">
                                <IoBanSharp />
                            </Box>
                        </Box>
                        <Box py={3}>
                            <Typography variant='h5' className='primary fw6'>
                                User Disabled Successfully
                            </Typography>
                        </Box>
                    </Box>

                </DialogContent>

            </Dialog>
        </>
    );
};

export default ActionMenu;