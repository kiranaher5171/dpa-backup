"use client";
import React from 'react'
import { Box, IconButton, Typography, TextField, InputAdornment } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/table_components/TableSkeleton';
import { FaCircle } from "react-icons/fa";
import { IoSearchOutline } from "react-icons/io5";
import ActionMenu from './ActionMenu';

const UsersRoleTable = () => {

    const [gridApi, setGridApi] = useState(null);

    const headerHeight = 45;
    const rowHeight = 60;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: false, flex: 1, suppressMovable: true, resizable: false,
    }


    const [rowData] = useState([
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' }
    ]);


    const columnDefs = [
        {
            headerName: 'EMP ID', field: 'emp_code', minWidth: 120, maxWidth: 120, cellRenderer: () => "# 4820",
        },
        {
            headerName: 'Username', field: 'name', minWidth: 160, cellRenderer: () => "John Doe",
        },
        {
            headerName: 'Status', field: 'status', minWidth: 140, maxWidth: 150, cellRenderer: (params) => {
                const status = params.data.status;
                if (status === 'enabled') {
                    return <Typography variant='h6' className='approved txt-tag'> <FaCircle /> Enabled</Typography>;
                } else {
                    return <Typography variant='h6' className='canceled txt-tag'> <FaCircle /> Disabled</Typography>;
                }
            }
        },
        {
            headerName: 'Last login', field: 'login', minWidth: 220, cellRenderer: () => "12th Feb 2025 | 12:00:00",
        },
        {
            headerName: 'Owner', field: 'owner', minWidth: 220, cellRenderer: () => "Accountant/HR",
        },
        {
            headerName: 'Actions',
            field: 'action',
            minWidth: 160,
            maxWidth: 160,
            cellRenderer: (params) => <ActionMenu data={params.data} />,
        },
    ];


    return (
        <>
            <Box>
                <Box className="fx_sb" pb={2}>
                    <Typography variant='h5' className='fw6 black'>Recent Claims</Typography>
                    <Box className="textfield standard auto-complete" mt={1}>
                        <TextField variant='outlined' placeholder='Search' size='small' fullWidth
                            slotProps={{
                                input: {
                                    startAdornment: <InputAdornment position="start">
                                        <IconButton disabled>
                                            <IoSearchOutline style={{ fontSize: '20px' }} />
                                        </IconButton>
                                    </InputAdornment>
                                },
                            }}
                        />
                    </Box>
                </Box>
                {loading ? (
                    <Box style={{ width: '100%', height: '66vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz" style={{ width: '100%', height: '66vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                            />
                        </Box>
                    </>
                )}
            </Box>
        </>
    )
}

export default UsersRoleTable