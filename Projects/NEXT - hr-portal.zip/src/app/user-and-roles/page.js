import MainLayout from '@/layouts/MainLayout'
import React from 'react'
import UsersRoleTable from './UsersRoleTable'
import { Box, Container } from '@mui/material'

const page = () => {
    return (
        <MainLayout>

            <Container maxWidth>

                <Box className="whitebox" mt={2}>
                    <UsersRoleTable />
                </Box>

            </Container>


        </MainLayout>
    )
}

export default page