import Link from 'next/link'
import { Box, Button, Container, Grid, Typography } from '@mui/material'
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import UnderDev from "../../public/under-dev.png";
import Image from 'next/image';

export default function NotFound() {
    return (
        <>



            <Container maxWidth>
                <Box id="page-content">

                    <Box className="whitebx">
                        <Box className="center" mb={1}>
                            <Grid container alignItems="center" justifyContent='center' spacing={0}>
                                <Grid item lg={4} md={6} sm={7} xs={8}>
                                    <Box>
                                        <Image src={UnderDev} alt="Page Under Developement" className='not-found-img' priority />
                                    </Box>

                                    <Box>
                                        <Typography variant="h4" gutterBottom className='blue fw7'>
                                            Under Construction
                                        </Typography>
                                        <Typography variant="h6" gutterBottom className='fw5'>
                                            We are working hard to bring you this page. Please check back later.
                                        </Typography>
                                    </Box>



                                    <Box mt={2} mb={2}>
                                        <Link href={"/"} passHref>
                                            <Button variant='outlined' className='secondary-btn' size='small' startIcon={<HomeOutlinedIcon fontSize='small' />}> Go Back to Home </Button>
                                        </Link>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>

                    </Box>
                </Box>
            </Container>
        </>
    )
}