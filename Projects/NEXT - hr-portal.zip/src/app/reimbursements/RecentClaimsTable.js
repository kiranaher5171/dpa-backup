"use client";
import React from 'react'
import { Box, Tooltip, IconButton, Typography, Button } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/table_components/TableSkeleton';
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';
import Link from 'next/link';
import { FaCircle } from "react-icons/fa";



const RecentClaimsTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const headerHeight = 45;
    const rowHeight = 60;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: false, checkboxSelection: false, autoHeight: true, filter: false, flex: 1, suppressMovable: true, resizable: false,
    }


    const [rowData] = useState([
        { status: 'approved', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'reject', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'approved', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'reject', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'approved', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'reject', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'approved', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'reject', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'approved', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'reject', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'approved', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] },
        { status: 'reject', members: ['Amit B.', 'Ravi Sharma', 'Neha W.', 'Ajay M.', 'Bharat M.'] }
    ]);


    const columnDefs = [
        {
            headerName: 'Date', field: 'date', minWidth: 140, cellRenderer: () => "Jan 15, 2025",
        },
        {
            headerName: 'Amount', field: 'amt', minWidth: 160, maxWidth: 180, cellRenderer: () => <>&#x20B9; 34,295</>,
        },
        {
            headerName: 'Restaurant', field: 'res', minWidth: 220, cellRenderer: () => "The Garden restaurant",
        },
        {
            headerName: 'Team Members',
            field: 'members',
            minWidth: 180,
            maxWidth: 180,
            cellRenderer: (params) => {
                const members = params.data.members || [];

                const getInitials = (name) => {
                    if (!name) return "";

                    // Remove periods and extra spaces, then split
                    const cleaned = name.replace(/\./g, "").trim().split(/\s+/);

                    if (cleaned.length === 1) {
                        return cleaned[0][0].toUpperCase();
                    }

                    // Take first letter of first and last words
                    const firstInitial = cleaned[0][0].toUpperCase();
                    const lastInitial = cleaned[cleaned.length - 1][0].toUpperCase();

                    return firstInitial + lastInitial;
                };


                const getColorFromName = (name) => {
                    let hash = 0;
                    for (let i = 0; i < name.length; i++) {
                        hash = name.charCodeAt(i) + ((hash << 5) - hash);
                    }
                    return `hsl(${hash % 360}, 80%, 40%)`;
                };

                return (
                    <Box className="member-group">
                        <AvatarGroup max={3} spacing="medium">
                            {members.map((name, index) => {
                                const initials = getInitials(name);
                                const bgColor = getColorFromName(name);
                                return (
                                    <Tooltip title={name} key={index} arrow placement="top">
                                        <Avatar sx={{ backgroundColor: bgColor, color: "#FFF" }}>
                                            {initials}
                                        </Avatar>
                                    </Tooltip>
                                );
                            })}
                        </AvatarGroup>
                    </Box>
                );
            }
        },
        {
            headerName: 'Status', field: 'status', minWidth: 150, maxWidth: 160, cellRenderer: (params) => {
                const status = params.data.status;
                if (status === 'approved') {
                    return <Typography variant='h6' className='approved txt-tag'> <FaCircle /> Approved</Typography>;
                } else if (status === 'reject') {
                    return <Typography variant='h6' className='canceled txt-tag'> <FaCircle /> Canceled</Typography>;
                } else {
                    return <Typography variant='h6' className='pending txt-tag'> <FaCircle /> Pending</Typography>;
                }
            }
        },
        {
            headerName: 'Actions', field: 'action', minWidth: 160, maxWidth: 160,
            cellRenderer: () => {
                return (
                    <>
                        <Box className="left">
                            <Link href="/reimbursements-details" className='link'>
                                <Typography variant='h6'>View Details</Typography>
                            </Link>
                        </Box>
                    </>
                );
            },
        },
    ];


    return (
        <>
            <Box>
                <Box className="fx_sb" pb={2}>
                    <Typography variant='h5' className='fw6 black'>Recent Claims</Typography>
                    <Typography variant='h6' className='fw6 primary link'>View All</Typography>
                </Box>
                {loading ? (
                    <Box style={{ width: '100%', height: '220px', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz" style={{ width: '100%', height: '220px' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                            />
                        </Box>
                    </>
                )}
            </Box>
        </>
    )
}

export default RecentClaimsTable