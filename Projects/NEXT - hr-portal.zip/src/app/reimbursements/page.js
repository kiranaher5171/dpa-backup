import React from 'react'
import MainLayout from '@/layouts/MainLayout'
import { Typography, Box, Container, Stack, Button } from '@mui/material'
import { IoIosArrowForward } from "react-icons/io";
import Grid from '@mui/material/Grid2';
import { LuClock3 } from "react-icons/lu";
import { BiBadgeCheck } from "react-icons/bi";
import { IoMdCheckmarkCircleOutline } from "react-icons/io";
import { IoClose } from "react-icons/io5";
import RecentClaimsTable from './RecentClaimsTable';
import { IoMdAdd } from "react-icons/io";
import AddNewClaim from './AddNewClaim';

const page = () => {
    return (
        <>
            <MainLayout>

                <Container maxWidth>
                    <Box py={1}>
                        <Stack direction="row" spacing={1} justifyContent={"flex-start"} alignItems="center">
                            <Typography variant='h5' className="fw5"> Reimbursements </Typography>
                            <IoIosArrowForward />
                            <Typography variant='h5' className="fw5"> List </Typography>
                        </Stack>
                    </Box>


                    <Box className="whitebox" mt={1}>
                        <Box>
                            <Grid container spacing={3} alignItems="flex-start" justifyContent="flex-start">
                                <Grid size={{ lg: 8, md: 8, sm: 8, xs: 12 }}>
                                    <Box>
                                        <Typography variant='h4' className='fw6 text' gutterBottom>Expense Reimbursement Portal</Typography>
                                        <Typography variant='h6' className='fw4 text'>Manage your team lunch expense claims</Typography>
                                    </Box>
                                </Grid>
                                <Grid size={{ lg: 4, md: 4, sm: 4, xs: 12 }}>
                                    <Box className="right">
                                        <AddNewClaim />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>

                        <Box mt={2}>
                            <Grid container spacing={3} alignItems="center" justifyContent="flex-start">
                                <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }}>
                                    <Box className="whitebox">
                                        <Box className="fx_sb" mb={2}>
                                            <Box className="card-icon pending">
                                                <LuClock3 />
                                            </Box>
                                            <Typography variant='h4' className='fw5 black'>3</Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw3 gry-txt'>Pending Claims</Typography>
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }}>
                                    <Box className="whitebox">
                                        <Box className="fx_sb" mb={2}>
                                            <Box className="card-icon approve">
                                                <BiBadgeCheck />
                                            </Box>
                                            <Typography variant='h4' className='fw5 black'>5</Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw3 gry-txt'>Claims to approve</Typography>
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }}>
                                    <Box className="whitebox">
                                        <Box className="fx_sb" mb={2}>
                                            <Box className="card-icon approved">
                                                <IoMdCheckmarkCircleOutline />
                                            </Box>
                                            <Typography variant='h4' className='fw5 black'>12</Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw3 gry-txt'>Approved claims</Typography>
                                    </Box>
                                </Grid>

                                <Grid size={{ lg: 3, md: 4, sm: 6, xs: 12 }}>
                                    <Box className="whitebox">
                                        <Box className="fx_sb" mb={2}>
                                            <Box className="card-icon reject">
                                                <IoClose />
                                            </Box>
                                            <Typography variant='h4' className='fw5 black'>3</Typography>
                                        </Box>
                                        <Typography variant='h5' className='fw3 gry-txt'>Rejected claims</Typography>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                    </Box>


                    <Box className="whitebox" mt={2}>
                        <RecentClaimsTable />
                    </Box>


                </Container>

            </MainLayout>

        </>
    )
}

export default page