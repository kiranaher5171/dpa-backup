/** @type {import('next').NextConfig} */
const nextConfig = {
    eslint: {
        // Disable ESLint during build
        ignoreDuringBuilds: true,
    },
    async rewrites() {
        return [
            {
                source: '/',
                destination: '/reimbursements/',
            }
        ];
    },
};

export default nextConfig;
