/** @type {import('next').NextConfig} */
const nextConfig = {
  reactCompiler: true,
  images: {
    remotePatterns: [
      { protocol: 'http', hostname: '127.0.0.1', port: '1337', pathname: '/uploads/**' },
      { protocol: 'http', hostname: 'localhost', port: '1337', pathname: '/uploads/**' },
    ],
  },
  async rewrites() {
    return [
        {
            source: '/',
            destination: '/auth/login',
        },
        {
            source: '/forgot-password',
            destination: '/auth/forgot-password',
        },
        {
            source: '/reset-password',
            destination: '/auth/reset-password',
        }, 
    ];
},
};

export default nextConfig;
