'use client'
import React, { useState } from 'react'
import HeaderFooter from '@/components/layout/HeaderFooter'
import Box from '@mui/material/Box'
import Container from '@mui/material/Container'
import Grid from '@mui/material/Grid'
import Image from 'next/image'
import Typography from '@mui/material/Typography'
import ContactUSTable from './ContactUSTable'
import TableSearch from '@/components/table_components/TableSearch'
import ContactUsForm from './ContactUsForm'

const page = () => {
  const [contactTableSearch, setContactTableSearch] = useState('')

  return (
    <HeaderFooter>
      <Box className="section">
        <Container>
          <Grid container spacing={5}>
            <Grid size={{ xs: 12, sm: 6, md: 6, lg: 6 }}>
              <Box sx={{ position: 'relative', height: '500px' }}>
                <Image
                  src="/images/dummyImage.jpg"
                  alt="Contact Us"
                  loading="lazy"
                  fill
                  style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '6px' }}
                />
              </Box>
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 6, lg: 6 }}>
              <ContactUsForm />
            </Grid>
          </Grid>
        </Container>
        <Box className="whitebx" sx={{ mt: 5 }}>
          <Box className="fx_sb" sx={{ pb: 1 }}>
            <Typography variant="h6" className="table-heading" sx={{ flexShrink: 0 }}>
              Contact Us
            </Typography>
            <TableSearch value={contactTableSearch} onChange={setContactTableSearch} />
          </Box>
          <ContactUSTable searchQuery={contactTableSearch} />
        </Box>
      </Box>
    </HeaderFooter>
  )
}

export default page
