'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AllCommunityModule, ModuleRegistry } from 'ag-grid-community'
import { AgGridReact } from 'ag-grid-react'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import AgGridInfo from '@/components/table_components/AgGridInfo'
import AgGridPagination from '@/components/table_components/AgGridPagination'
import TableSkeleton from '@/components/table_components/TableSkeleton'

ModuleRegistry.registerModules([AllCommunityModule])

function normalizeContactRow(entry) {
  if (!entry || typeof entry !== 'object') return null
  if (entry.attributes && typeof entry.attributes === 'object') {
    return { id: entry.id, documentId: entry.documentId, ...entry.attributes }
  }
  return entry
}

function formatHearAbout(value) {
  const v = String(value || '').trim()
  if (!v) return '—'
  return v.charAt(0).toUpperCase() + v.slice(1)
}

function formatDate(value) {
  if (!value) return '—'
  const d = new Date(value)
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString()
}

function truncateMessage(value, max = 72) {
  const s = String(value ?? '')
  if (s.length <= max) return s
  return `${s.slice(0, max)}…`
}

const ContactUSTable = ({ searchQuery = '' }) => {
  const headerHeight = 35
  const rowHeight = 40
  const [pageSize] = useState(25)
  const [currentPage, setCurrentPage] = useState(1)
  const [refreshNonce, setRefreshNonce] = useState(0)
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [rowData, setRowData] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [pagination, setPagination] = useState({
    page: 1,
    pageSize: 25,
    pageCount: 1,
    total: 0,
  })

  useEffect(() => {
    const trimmed = String(searchQuery ?? '').trim()
    if (trimmed === '') {
      setDebouncedSearch('')
      return undefined
    }
    const t = setTimeout(() => setDebouncedSearch(trimmed), 300)
    return () => clearTimeout(t)
  }, [searchQuery])

  const prevDebounced = useRef(debouncedSearch)
  useEffect(() => {
    if (prevDebounced.current !== debouncedSearch) {
      prevDebounced.current = debouncedSearch
      setCurrentPage(1)
    }
  }, [debouncedSearch])

  useEffect(() => {
    const ac = new AbortController()
    let cancelled = false

    const run = async () => {
      setLoading(true)
      setError('')
      try {
        const q = debouncedSearch ? `&q=${encodeURIComponent(debouncedSearch)}` : ''
        const res = await fetch(`/api/contact-us?page=${currentPage}&pageSize=${pageSize}${q}`, {
          method: 'GET',
          headers: { Accept: 'application/json' },
          cache: 'no-store',
          signal: ac.signal,
        })
        const text = await res.text()
        let json
        try {
          json = JSON.parse(text)
        } catch {
          if (!cancelled) {
            setError(`Invalid response (${res.status})`)
            setRowData([])
          }
          return
        }
        if (!res.ok) {
          const msg = json?.error?.message || text.slice(0, 200)
          if (!cancelled) {
            setError(typeof msg === 'string' ? msg : 'Failed to load contacts')
            setRowData([])
          }
          return
        }
        const raw = Array.isArray(json?.data) ? json.data : []
        const rows = raw.map(normalizeContactRow).filter(Boolean)
        const p = json?.meta?.pagination
        if (!cancelled) {
          setRowData(rows)
          if (p && typeof p === 'object') {
            setPagination({
              page: p.page ?? currentPage,
              pageSize: p.pageSize ?? pageSize,
              pageCount: Math.max(1, p.pageCount ?? 1),
              total: p.total ?? rows.length,
            })
          } else {
            setPagination({
              page: currentPage,
              pageSize,
              pageCount: 1,
              total: rows.length,
            })
          }
        }
      } catch (e) {
        if (e?.name === 'AbortError') return
        if (!cancelled) {
          setError(e?.message ? String(e.message) : 'Network error')
          setRowData([])
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    run()
    return () => {
      cancelled = true
      ac.abort()
    }
  }, [currentPage, pageSize, refreshNonce, debouncedSearch])

  useEffect(() => {
    const onRefresh = () => {
      setCurrentPage(1)
      setRefreshNonce((n) => n + 1)
    }
    window.addEventListener('contact-us-list-refresh', onRefresh)
    return () => window.removeEventListener('contact-us-list-refresh', onRefresh)
  }, [])

  const columnDefs = useMemo(
    () => [
      { headerName: 'Full name', field: 'full_name', minWidth: 130, flex: 1 },
      { headerName: 'Email', field: 'email', minWidth: 180, flex: 1.2 },
      { headerName: 'Phone', field: 'phone_number', minWidth: 130, flex: 1 },
      {
        headerName: 'Source',
        field: 'hear_about_us',
        minWidth: 110,
        maxWidth: 140,
        valueFormatter: (p) => formatHearAbout(p.value),
      },
      {
        headerName: 'Message',
        field: 'message',
        minWidth: 160,
        flex: 1.5,
        valueFormatter: (p) => truncateMessage(p.value),
        tooltipValueGetter: (p) => String(p.value ?? ''),
      },
      {
        headerName: 'Submitted',
        field: 'createdAt',
        minWidth: 160,
        maxWidth: 200,
        valueFormatter: (p) => formatDate(p.value),
      },
    ],
    []
  )

  const defaultColDef = useMemo(
    () => ({
      sortable: false,
      autoHeight: false,
      filter: false,
      flex: 1,
      suppressMovable: true,
      resizable: true,
    }),
    []
  )

  const totalPages = pagination.pageCount || 1
  const totalRows = pagination.total ?? rowData.length

  const handlePageChange = (_event, page) => {
    setCurrentPage(page)
  }

  return (
    <Box>
      {error ? (
        <Typography color="error" variant="body2" sx={{ mb: 1 }}>
          {error}
        </Typography>
      ) : null}
      {loading ? (
        <Box style={{ width: '100%', height: '65vh', overflow: 'hidden' }} aria-label="Loading...">
          <TableSkeleton />
        </Box>
      ) : (
        <Box className="ag-theme-quartz" style={{ width: '100%', height: '65vh' }}>
          <AgGridReact
            theme="legacy"
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressMovableColumns
            rowHeight={rowHeight}
            headerHeight={headerHeight}
            getRowId={(params) => String(params.data?.id ?? params.data?.documentId ?? params.node?.id)}
            tooltipShowDelay={0}
            rowClassRules={{
              'even-row': (params) => params.node.rowIndex % 2 !== 0,
              'odd-row': (params) => params.node.rowIndex % 2 === 0,
            }}
          />
        </Box>
      )}
      <Box id="tb_footer" className="fx_sb" sx={{ mt: 1 }}>
        <AgGridInfo currentPage={pagination.page || currentPage} rowsPerPage={pagination.pageSize || pageSize} totalRows={totalRows} />
        <AgGridPagination currentPage={pagination.page || currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
      </Box>
    </Box>
  )
}

export default ContactUSTable
