'use client'

import 'react-phone-input-2/lib/style.css'

import React, { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import CircularProgress from '@mui/material/CircularProgress'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import Grid from '@mui/material/Grid'
import { Alert, Autocomplete, Checkbox, FormControlLabel } from '@mui/material'
import PhoneInput from 'react-phone-input-2'

const HEAR_OPTIONS = [
  { label: 'Google', value: 'google' },
  { label: 'Facebook', value: 'facebook' },
  { label: 'Twitter', value: 'twitter' },
  { label: 'Instagram', value: 'instagram' },
  { label: 'LinkedIn', value: 'linkedin' },
]

const CHARACTER_LIMITS = {
  full_name: 80,
  email: 120,
  phone_number: 32,
  message: 1000,
}

const nameRegex = /^[a-zA-Z\s]+$/

const validateField = (name, value, data) => {
  const emailRegex =
    /^[a-zA-Z0-9_]+(?:[-._][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+(?:[-.][a-zA-Z0-9_]+)*\.[a-zA-Z]{2,}$/
  const label = name.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())

  if (name === 'message') {
    if (!value || !String(value).trim()) return 'Message is required'
    if (String(value).trim().length > CHARACTER_LIMITS.message) {
      return `${label} cannot exceed ${CHARACTER_LIMITS.message} characters`
    }
    return null
  }

  if (name === 'hear_about_us') {
    if (!data?.hear_about_us) return 'Please select how you heard about us'
    return null
  }

  if (!value || !String(value).trim()) {
    return `${label} is required`
  }
  const v = String(value).trim()
  const max = CHARACTER_LIMITS[name]
  if (max && v.length > max) {
    return `${label} cannot exceed ${max} characters`
  }
  if (name === 'email' && !emailRegex.test(v)) return 'Email is not valid'
  if (name === 'full_name' && !nameRegex.test(v)) return 'Full name can only contain letters and spaces'
  if (name === 'phone_number') {
    const digits = v.replace(/\D/g, '')
    if (digits.length < 10 || digits.length > 18) return 'Please enter a valid phone number'
  }
  return null
}

/** Next.js proxy → Strapi `POST /api/contactus` (not `/api/ContactUs`, which is not a Strapi route). */
const DEFAULT_SUBMIT_PATH = '/api/contact-us'

export default function ContactUsForm() {
  const submitPath =
    (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_CONTACT_US_FORM_PATH) || DEFAULT_SUBMIT_PATH

  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone_number: '',
    hear_about_us: null,
    message: '',
  })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [submitError, setSubmitError] = useState('')
  const [isChecked, setIsChecked] = useState(false)

  const nameInputRef = useRef(null)

  useEffect(() => {
    nameInputRef.current?.focus()
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    const max = CHARACTER_LIMITS[name] ?? 5000
    if (value.length <= max) {
      const next = { ...formData, [name]: value }
      setFormData(next)
      const err = validateField(name, value, next)
      setErrors((prev) => ({ ...prev, [name]: err }))
      if (submitError) setSubmitError('')
    }
  }

  const handlePhoneChange = (value) => {
    const v = String(value || '')
    const next = { ...formData, phone_number: v }
    setFormData(next)
    const withPlus = v ? `+${v.replace(/^\+/, '')}` : ''
    const err = validateField('phone_number', withPlus, next)
    setErrors((prev) => ({ ...prev, phone_number: err }))
    if (submitError) setSubmitError('')
  }

  const handlePhoneBlur = () => {
    const v = formData.phone_number ? `+${String(formData.phone_number).replace(/^\+/, '')}` : ''
    const err = validateField('phone_number', v, formData)
    setErrors((prev) => ({ ...prev, phone_number: err }))
  }

  const handleCheckboxChange = (e) => {
    const checked = e.target.checked
    setIsChecked(checked)
    setErrors((prev) => ({
      ...prev,
      checkbox: checked ? null : 'To continue, please accept the terms and privacy policy.',
    }))
    if (submitError) setSubmitError('')
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    const err = validateField(name, value, formData)
    setErrors((prev) => ({ ...prev, [name]: err }))
  }

  const validateForm = () => {
    const newErrors = {}
    const phoneVal = formData.phone_number ? `+${String(formData.phone_number).replace(/^\+/, '')}` : ''
    ;['full_name', 'email', 'message'].forEach((key) => {
      const err = validateField(key, formData[key], formData)
      if (err) newErrors[key] = err
    })
    const phoneErr = validateField('phone_number', phoneVal, formData)
    if (phoneErr) newErrors.phone_number = phoneErr
    const hearErr = validateField('hear_about_us', '', formData)
    if (hearErr) newErrors.hear_about_us = hearErr
    if (!isChecked) {
      newErrors.checkbox = 'To continue, please accept the terms and privacy policy.'
    }
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async () => {
    if (!validateForm()) {
      setSuccess(false)
      setSubmitError('Please fix the errors above and try again.')
      return
    }

    setLoading(true)
    setSuccess(false)
    setSubmitError('')

    const rawPath = String(submitPath).trim()
    const isDirectStrapi = /^https?:\/\//i.test(rawPath)
    const url = isDirectStrapi
      ? rawPath
      : rawPath.startsWith('/')
        ? rawPath
        : `/${rawPath}`
    const hearValue = String(formData.hear_about_us?.value ?? '').trim().toLowerCase()
    const phoneE164 = formData.phone_number
      ? `+${String(formData.phone_number).replace(/^\+/, '').trim()}`
      : ''

    const payload = {
      data: {
        full_name: formData.full_name.trim(),
        email: formData.email.trim(),
        phone_number: phoneE164.slice(0, CHARACTER_LIMITS.phone_number),
        hear_about_us: hearValue,
        message: formData.message.trim(),
      },
    }

    const token = isDirectStrapi
      ? String(
          (typeof process !== 'undefined' &&
            (process.env.NEXT_PUBLIC_STRAPI_API_TOKEN || process.env.NEXT_PUBLIC_STRAPI_TOKEN)) ||
            ''
        ).trim()
      : ''

    try {
      const doPost = async (withAuth) => {
        const headers = {
          'Content-Type': 'application/json',
          ...(withAuth && token ? { Authorization: `Bearer ${token}` } : {}),
        }
        return fetch(url, {
          method: 'POST',
          headers,
          body: JSON.stringify(payload),
        })
      }

      let response = await doPost(!!token)
      if (isDirectStrapi && (response.status === 401 || response.status === 403) && token) {
        response = await doPost(false)
      }

      if (response.ok) {
        setSuccess(true)
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('contact-us-list-refresh'))
        }
        setFormData({
          full_name: '',
          email: '',
          phone_number: '',
          hear_about_us: null,
          message: '',
        })
        setIsChecked(false)
        setErrors({})
        setTimeout(() => setSuccess(false), 8000)
      } else {
        const text = await response.text()
        setSubmitError(`Submit failed (${response.status}). ${text.slice(0, 240)}`.trim())
      }
    } catch (err) {
      setSubmitError(err?.message ? String(err.message) : 'Network error while submitting.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Grid container spacing={2}>
      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield">
          <Typography variant="h5" className="SectionTitle lora">
            Get in Touch
          </Typography>
          <Typography variant="h5" className="paragraph" gutterBottom>
            Define your goals and identify areas where we can add value to your business
          </Typography>
        </Box>
      </Grid>

      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield">
          <Typography variant="h5" className="textfield-label" gutterBottom>
            Full Name *
          </Typography>
          <TextField
            name="full_name"
            variant="outlined"
            fullWidth
            placeholder="Enter your full name"
            value={formData.full_name}
            onChange={handleChange}
            onBlur={handleBlur}
            error={!!errors.full_name}
            helperText={errors.full_name}
            inputRef={nameInputRef}
            slotProps={{ htmlInput: { maxLength: CHARACTER_LIMITS.full_name } }}
          />
        </Box>
      </Grid> 

      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield">
          <Typography variant="h5" className="textfield-label" gutterBottom>
            Email *
          </Typography>
          <TextField
            name="email"
            type="email"
            variant="outlined"
            fullWidth
            placeholder="Enter your email"
            value={formData.email}
            onChange={handleChange}
            onBlur={handleBlur}
            error={!!errors.email}
            helperText={errors.email}
            slotProps={{ htmlInput: { maxLength: CHARACTER_LIMITS.email } }}
          />
        </Box>
      </Grid>

      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield mobile-input" sx={{ width: '100%' }}>
          <Typography variant="h5" className="textfield-label" gutterBottom>
            Phone *
          </Typography>
          <PhoneInput
            country="in"
            value={formData.phone_number}
            onChange={handlePhoneChange}
            onBlur={handlePhoneBlur}
          />
          {errors.phone_number ? (
            <Typography color="error" variant="caption" sx={{ mt: 0.5, display: 'block' }}>
              {errors.phone_number}
            </Typography>
          ) : null}
        </Box>
      </Grid>

      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield autocomplete">
          <Typography variant="h5" className="textfield-label" gutterBottom>
            How did you hear about us? *
          </Typography>
          <Autocomplete
            disablePortal
            options={HEAR_OPTIONS}
            getOptionLabel={(o) => o.label}
            value={formData.hear_about_us}
            onChange={(_, v) => {
              const next = { ...formData, hear_about_us: v }
              setFormData(next)
              const err = validateField('hear_about_us', '', next)
              setErrors((prev) => ({ ...prev, hear_about_us: err }))
              if (submitError) setSubmitError('')
            }}
            fullWidth
            renderInput={(params) => (
              <TextField
                {...params}
                placeholder="Select an option"
                error={!!errors.hear_about_us}
                helperText={errors.hear_about_us}
              />
            )}
          />
        </Box>
      </Grid>

      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield textarea">
          <Typography variant="h5" className="textfield-label" gutterBottom>
            Message *
          </Typography>
          <TextField
            name="message"
            variant="outlined"
            fullWidth
            multiline
            minRows={3}
            placeholder="Enter your message"
            value={formData.message}
            onChange={handleChange}
            onBlur={handleBlur}
            error={!!errors.message}
            helperText={errors.message}
            slotProps={{ htmlInput: { maxLength: CHARACTER_LIMITS.message } }}
          />
        </Box>
      </Grid>

      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield">
          <FormControlLabel
            control={<Checkbox size='small' sx={{ color: '#000' }} checked={isChecked} onChange={handleCheckboxChange} />}
            className="textfield-label"
            label={
              <span className="textfield-label"> 
                I agree to the{' '}
                <Link href="/terms-of-use" target="_blank" className="link">
                  Terms of Use
                </Link>{' '}
                and{' '}
                <Link href="/privacy-policy" target="_blank" className="link">
                  Privacy Policy
                </Link>
                . 
              </span>
            }
          />
          {errors.checkbox ? (
            <Typography color="error" variant="body2" sx={{ mt: 1 }}>
              {errors.checkbox}
            </Typography>
          ) : null}
        </Box>
      </Grid>

      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
        <Box className="textfield fx_fe">
          <Button
            variant="contained"
            className="primary-btn"
            onClick={handleSubmit}
            disabled={loading}
            sx={{ minWidth: 160 }}
          >
            {loading ? <CircularProgress size={24} color="inherit" /> : 'Send Message'}
          </Button>
        </Box>
        {success ? (
          <Alert severity="success" sx={{ mt: 2 }}>
            Thank you! Your message was sent. We will get back to you shortly.
          </Alert>
        ) : null}
        {submitError ? (
          <Alert severity="error" sx={{ mt: 2 }}>
            {submitError}
          </Alert>
        ) : null}
      </Grid>
    </Grid>
  )
}
