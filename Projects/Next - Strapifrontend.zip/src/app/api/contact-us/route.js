import { NextResponse } from 'next/server'

function strapiBase() {
  return (process.env.NEXT_PUBLIC_STRAPI_URL || 'http://127.0.0.1:1337').replace(/\/$/, '')
}

/** Strapi `contact-us` type: pluralName in schema is `contactus` → GET/POST `/api/contactus` */
const STRAPI_CONTACT_PATH = '/api/contactus'

const HEAR_ENUM = new Set(['google', 'facebook', 'twitter', 'instagram', 'linkedin'])

/**
 * Proxies contact form POST to Strapi.
 * Use a Strapi **API Token** (Settings → API Tokens), not a Users-Permissions JWT — JWTs cause 401 here.
 * If a token is set but invalid, we retry without Authorization so Public → create can still work.
 */
function resolveStrapiToken() {
  return (
    process.env.STRAPI_API_TOKEN?.trim() ||
    process.env.STRAPI_TOKEN?.trim() ||
    process.env.NEXT_PUBLIC_STRAPI_API_TOKEN?.trim() ||
    process.env.NEXT_PUBLIC_STRAPI_TOKEN?.trim() ||
    ''
  )
}

async function strapiJsonResponse(strapiRes) {
  const text = await strapiRes.text()
  let json
  try {
    json = JSON.parse(text)
  } catch {
    return new NextResponse(text, { status: strapiRes.status })
  }
  return NextResponse.json(json, { status: strapiRes.status })
}

/** Proxies list GET to Strapi (same auth behavior as POST). Optional `q` = case-insensitive contains on name, email, phone, message. */
export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10) || 1)
  const pageSize = Math.min(100, Math.max(1, parseInt(searchParams.get('pageSize') || '25', 10) || 25))
  const q = (searchParams.get('q') || '').trim()

  const token = resolveStrapiToken()
  const qs = new URLSearchParams({
    'pagination[page]': String(page),
    'pagination[pageSize]': String(pageSize),
    sort: 'createdAt:desc',
  })
  if (q) {
    qs.set('filters[$or][0][full_name][$containsi]', q)
    qs.set('filters[$or][1][email][$containsi]', q)
    qs.set('filters[$or][2][phone_number][$containsi]', q)
    qs.set('filters[$or][3][message][$containsi]', q)
  }
  const url = `${strapiBase()}${STRAPI_CONTACT_PATH}?${qs.toString()}`

  const getFromStrapi = (withAuth) => {
    const headers = { Accept: 'application/json' }
    if (withAuth && token) {
      headers.Authorization = `Bearer ${token}`
    }
    return fetch(url, { headers, cache: 'no-store' })
  }

  let strapiRes = await getFromStrapi(!!token)
  if ((strapiRes.status === 401 || strapiRes.status === 403) && token) {
    strapiRes = await getFromStrapi(false)
  }

  return strapiJsonResponse(strapiRes)
}

export async function POST(request) {
  let body
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: { message: 'Invalid JSON' } }, { status: 400 })
  }

  const data = body?.data
  if (!data || typeof data !== 'object') {
    return NextResponse.json({ error: { message: 'Expected { data: { ... } }' } }, { status: 400 })
  }

  const required = ['full_name', 'email', 'phone_number', 'message']
  for (const k of required) {
    if (data[k] == null || String(data[k]).trim() === '') {
      return NextResponse.json({ error: { message: `Missing field: ${k}` } }, { status: 400 })
    }
  }

  const hear = data.hear_about_us != null ? String(data.hear_about_us).trim().toLowerCase() : ''
  if (!hear || !HEAR_ENUM.has(hear)) {
    return NextResponse.json({ error: { message: 'Invalid or missing hear_about_us' } }, { status: 400 })
  }
  data.hear_about_us = hear

  const token = resolveStrapiToken()
  const url = `${strapiBase()}${STRAPI_CONTACT_PATH}`
  const bodyStr = JSON.stringify({ data })

  const postToStrapi = (withAuth) => {
    const headers = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }
    if (withAuth && token) {
      headers.Authorization = `Bearer ${token}`
    }
    return fetch(url, { method: 'POST', headers, body: bodyStr })
  }

  let strapiRes = await postToStrapi(!!token)
  if ((strapiRes.status === 401 || strapiRes.status === 403) && token) {
    strapiRes = await postToStrapi(false)
  }

  return strapiJsonResponse(strapiRes)
}
