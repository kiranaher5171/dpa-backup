"use client";
import React from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import NextLink from "next/link"; 
import Container from "@mui/material/Container";
import {
  Box,
  Grid,
  TextField,
  Typography,
  Button,
  Link,
} from "@mui/material";

const page = () => {
  const [showOtp, setShowOtp] = React.useState(false);
  const router = useRouter();

  const handlePrimaryAction = () => {
    if (!showOtp) {
      setShowOtp(true);
      return;
    }
    router.push("/auth/reset-password");
  };

  return ( 
      <div style={{ position: "relative", minHeight: "100vh" }}>
        <Image
          src="/login-bg.jpg"
          alt="Login background"
          fill
          priority
          sizes="100vw"
          style={{ objectFit: "cover", zIndex: 0 }}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            zIndex: 1,
          }}
        />
        <div style={{ position: "relative", zIndex: 2, alignItems: "center", justifyContent: "flex-end", display: "flex", height: "100vh" }}>
          <Container maxWidth="lg">
            <Grid container spacing={2} sx={{ justifyContent: "end", alignItems: "center" }}>
              <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>

                <Grid container spacing={2}>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box sx={{ mb: 2 }} className="fx_c">
                      <Image
                        src="/images/logo.png"
                        alt="Logo"
                        width={120}
                        height={100}
                        priority
                        sizes="(max-width: 600px) 70vw, 280px"
                        style={{ width: "100%", maxWidth: 200, height: "auto", objectFit: "contain" }}
                      />
                    </Box>

                    <Box sx={{ my: 2 }}>
                      <Typography variant="h4" className="center form-heading" gutterBottom>
                        FORGOT PASSWORD
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="h5" className="center white">
                        Provide your account's email for which you want to reset your
                        password!
                      </Typography>
                    </Box>

                  </Grid>

                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box className="login-textfield" sx={{ mt: 2 }}>
                      <Box sx={{ mb: 1 }}>
                        <Typography variant="h6" className="login-label " gutterBottom>Email</Typography>
                      </Box>
                      <TextField variant="outlined" fullWidth placeholder="Enter your email" />
                    </Box>
                  </Grid>
                  {showOtp ? (
                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                      <Box className="login-textfield" sx={{ mt: 1 }}>
                        <Box sx={{ mb: 1 }}>
                          <Typography variant="h6" className="login-label " gutterBottom>
                            Enter OTP
                          </Typography>
                        </Box>
                        <TextField variant="outlined" fullWidth placeholder="Enter OTP" />
                      </Box>
                    </Grid>
                  ) : null}

                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box sx={{ mt: 5 }}>
                      <Button
                        variant="contained"
                        className="login-btn"
                        fullWidth
                        onClick={handlePrimaryAction}
                      >
                        {showOtp ? "Submit" : "Send OTP"}
                      </Button>
                    </Box>

                    <Box className="center" sx={{ mt: 2 }}>
                      <Link
                        component={NextLink}
                        href="/auth/login"
                        underline="always"
                        className="white"
                        sx={{
                          fontSize: 13,
                          fontWeight: 500,
                          color: "#fff",
                          opacity: 0.9,
                          "&:hover": { opacity: 1 },
                        }}
                      >
                        Back to Login
                      </Link>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Container>
        </div>
      </div> 
  );
}

export default page