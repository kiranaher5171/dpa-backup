"use client";
import React from "react";
import Image from "next/image";
import NextLink from "next/link"; 
import Container from "@mui/material/Container";
import {
  Box,
  Grid,
  TextField,
  Typography,
  IconButton,
  FormControl,
  InputLabel,
  OutlinedInput,
  InputAdornment,
  Button,
  Checkbox,
  FormControlLabel,
  Link,
} from "@mui/material";
import { VisibilityOff, Visibility } from "@mui/icons-material";

const page = () => {
  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((v) => !v);
  const handleMouseDownPassword = (event) => event.preventDefault();
  const handleMouseUpPassword = (event) => event.preventDefault();

  return ( 
      <div style={{ position: "relative", minHeight: "100vh" }}>
        <Image
          src="/login-bg.jpg"
          alt="Login background"
          fill
          priority
          sizes="100vw"
          style={{ objectFit: "cover", zIndex: 0 }}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            zIndex: 1,
          }}
        />
        <div style={{ position: "relative", zIndex: 2, alignItems: "center", justifyContent: "flex-end", display: "flex", height: "100vh" }}>
          <Container maxWidth="lg">
            <Grid container spacing={2} sx={{ justifyContent: "end", alignItems: "center" }}>
              <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }} className="formbx">

                <Grid container spacing={2}  >
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box sx={{ mb: 2 }} className="fx_c">
                      <Image
                        src="/images/logo.png"
                        alt="Logo"
                        width={120}
                        height={100}
                        priority
                        sizes="(max-width: 600px) 70vw, 280px"
                        style={{ width: "100%", maxWidth: 200, height: "auto", objectFit: "contain" }}
                      />
                    </Box>

                    <Box sx={{ my: 2 }}>
                      <Typography variant="h4" className="center form-heading" gutterBottom>
                        LOGIN
                      </Typography>
                    </Box>
                    
                    <Box>
                      <Typography variant="h5" className="center white">
                        Welcome back! Please enter your details.
                      </Typography>
                    </Box>
                  </Grid>

                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }} >
                    <Box className="login-textfield" sx={{ mt: 2 }}>
                      <Box sx={{ mb: 1 }}>
                        <Typography variant="h6" className="login-label " gutterBottom>Email</Typography>
                      </Box>
                      <TextField variant="outlined" fullWidth placeholder="Enter your email" />
                    </Box>
                  </Grid>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box className="login-textfield" sx={{ mt: 2 }}>
                      <Box sx={{ mb: 1 }}>
                        <Typography variant="h6" className="login-label " gutterBottom>Password</Typography>
                      </Box>
                      <FormControl fullWidth variant="outlined">
                        <OutlinedInput
                          id="outlined-adornment-password"
                          type={showPassword ? "text" : "password"}
                          endAdornment={
                            <InputAdornment position="end">
                              <IconButton
                                aria-label={showPassword ? "hide the password" : "display the password"}
                                onClick={handleClickShowPassword}
                                onMouseDown={handleMouseDownPassword}
                                onMouseUp={handleMouseUpPassword}
                                edge="end"
                                size="small"
                              >
                                {showPassword ? (
                                  <VisibilityOff style={{ fontSize: 18 }} />
                                ) : (
                                  <Visibility style={{ fontSize: 18 }} />
                                )}
                              </IconButton>
                            </InputAdornment>
                          }
                          placeholder="Enter your password"
                        />
                      </FormControl>
                    </Box>
                  </Grid>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box
                      sx={{
                        mt: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        // gap: 2,
                      }}
                    >
                      <FormControlLabel
                        control={<Checkbox size="small" sx={{ color: "#fff" }} />}
                        label="Remember me"
                        sx={{
                          m: 0,
                          "& .MuiFormControlLabel-label": {
                            fontSize: 13,
                            fontWeight: 500,
                            color: "#fff",

                          },
                        }}
                      />

                      <Link
                        component={NextLink}
                        href="/auth/forgot-password"
                        underline="always"
                        sx={{
                          fontSize: 13,
                          fontWeight: 500,
                          color: "#fff",
                          opacity: 0.9,
                          "&:hover": { opacity: 1 },
                        }}
                      >
                        Forgot password?
                      </Link>
                    </Box>
                  </Grid>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box sx={{ mt: 1 }}>
                      <Link component={NextLink} href="/insights/blogs" className="forgot-password-link">
                        <Button variant="contained" className="login-btn" fullWidth>
                          Login
                        </Button>
                      </Link>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Container>
        </div>
      </div> 
  );
}

export default page