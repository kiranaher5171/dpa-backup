"use client";
import React from "react";
import Image from "next/image";
import { useRouter } from "next/navigation"; 
import Container from "@mui/material/Container";
import {
  Box,
  Grid,
  Typography,
  IconButton,
  FormControl,
  OutlinedInput,
  InputAdornment,
  Button,
  Link,
} from "@mui/material";
import { VisibilityOff, Visibility } from "@mui/icons-material";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";

const page = () => {
  const [showNewPassword, setShowNewPassword] = React.useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = React.useState(false);
  const [snackOpen, setSnackOpen] = React.useState(false);
  const router = useRouter();

  const handleMouseDownPassword = (event) => event.preventDefault();
  const handleMouseUpPassword = (event) => event.preventDefault();

  const handleResetPassword = () => {
    setSnackOpen(true);
    window.setTimeout(() => {
      router.push("/auth/login");
    }, 900);
  };

  const handleSnackClose = (_event, reason) => {
    if (reason === "clickaway") return;
    setSnackOpen(false);
  };

  return ( 
    <>
      <div style={{ position: "relative", minHeight: "100vh" }}>
        <Image
          src="/login-bg.jpg"
          alt="Login background"
          fill
          priority
          sizes="100vw"
          style={{ objectFit: "cover", zIndex: 0 }}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            zIndex: 1,
          }}
        />
        <div style={{ position: "relative", zIndex: 2, alignItems: "center", justifyContent: "flex-end", display: "flex", height: "100vh" }}>
          <Container maxWidth="lg">
            <Grid container spacing={2} sx={{ justifyContent: "end", alignItems: "center" }}>
              <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>

                <Grid container spacing={2}>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box sx={{ mb: 2 }} className="fx_c">
                      <Image
                        src="/images/logo.png"
                        alt="Logo"
                        width={120}
                        height={100}
                        priority
                        sizes="(max-width: 600px) 70vw, 280px"
                        style={{ width: "100%", maxWidth: 200, height: "auto", objectFit: "contain" }}
                      />
                    </Box>

                    <Box sx={{ my: 2 }}>
                      <Typography variant="h4" className="center form-heading" gutterBottom>
                        RESET PASSWORD
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="h5" className="center white">
                        Enter your new password and confirm it to reset your password!
                      </Typography>
                    </Box>

                  </Grid>
                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box className="login-textfield" sx={{ mt: 2 }}>
                      <Box sx={{ mb: 1 }}>
                        <Typography variant="h6" className="login-label " gutterBottom>Enter New Password</Typography>
                      </Box>
                      <FormControl fullWidth variant="outlined">
                        <OutlinedInput
                          id="outlined-adornment-password"
                          type={showNewPassword ? "text" : "password"}
                          endAdornment={
                            <InputAdornment position="end">
                              <IconButton
                                aria-label={showNewPassword ? "hide the password" : "display the password"}
                                onClick={() => setShowNewPassword((v) => !v)}
                                onMouseDown={handleMouseDownPassword}
                                onMouseUp={handleMouseUpPassword}
                                edge="end"
                                size="small"
                              >
                                {showNewPassword ? (
                                  <VisibilityOff style={{ fontSize: 18 }} />
                                ) : (
                                  <Visibility style={{ fontSize: 18 }} />
                                )}
                              </IconButton>
                            </InputAdornment>
                          }
                          placeholder="Enter new password"
                        />
                      </FormControl>
                    </Box>
                  </Grid>

                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box className="login-textfield" sx={{ mt: 2 }}>
                      <Box sx={{ mb: 1 }}>
                        <Typography variant="h6" className="login-label " gutterBottom>Confirm New Password</Typography>
                      </Box>
                      <FormControl fullWidth variant="outlined">
                        <OutlinedInput
                          id="outlined-adornment-password"
                          type={showConfirmPassword ? "text" : "password"}
                          endAdornment={
                            <InputAdornment position="end">
                              <IconButton
                                aria-label={showConfirmPassword ? "hide the password" : "display the password"}
                                onClick={() => setShowConfirmPassword((v) => !v)}
                                onMouseDown={handleMouseDownPassword}
                                onMouseUp={handleMouseUpPassword}
                                edge="end"
                                size="small"
                              >
                                {showConfirmPassword ? (
                                  <VisibilityOff style={{ fontSize: 18 }} />
                                ) : (
                                  <Visibility style={{ fontSize: 18 }} />
                                )}
                              </IconButton>
                            </InputAdornment>
                          }
                          placeholder="Enter confirm new password"
                        />
                      </FormControl>
                    </Box>
                  </Grid>

                  <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                    <Box sx={{ mt: 5 }}>
                      <Button
                        variant="contained"
                        className="login-btn"
                        fullWidth
                        onClick={handleResetPassword}
                      >
                        Reset password
                      </Button>
                    </Box>

                    <Box className="center" sx={{ mt: 2 }}>
                      <Link
                        href="/"
                        underline="always"
                        sx={{
                          fontSize: 13,
                          fontWeight: 500,
                          color: "#fff",
                          opacity: 0.9,
                          "&:hover": { opacity: 1 },
                        }}
                      >
                        Back to Login
                      </Link>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Container>
        </div>
      </div>

      <Snackbar
        open={snackOpen}
        autoHideDuration={2000}
        onClose={handleSnackClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
      >
        <Alert onClose={handleSnackClose} severity="success" variant="filled" sx={{ width: "100%" }}>
          Password reset successfully.
        </Alert>
      </Snackbar> 
     </>
  );
}

export default page