import React from 'react'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Link from 'next/link'

/** Renders Strapi Blocks (v5) nodes: paragraph, heading, list, list-item, text, link. */
function InlineNodes({ nodes }) {
  if (!Array.isArray(nodes)) return null
  return nodes.map((node, i) => {
    if (!node || typeof node !== 'object') return null
    if (node.type === 'text' && typeof node.text === 'string') {
      return (
        <Box
          component="span"
          key={i}
          sx={{
            fontWeight: node.bold ? 700 : undefined,
            fontStyle: node.italic ? 'italic' : undefined,
            textDecoration: node.underline ? 'underline' : undefined,
          }}
        >
          {node.text}
        </Box>
      )
    }
    if (node.type === 'link' && node.url) {
      const href = node.url
      const inner = <InlineNodes nodes={node.children} />
      if (href.startsWith('http://') || href.startsWith('https://')) {
        return (
          <a key={i} href={href} target="_blank" rel="noopener noreferrer">
            {inner}
          </a>
        )
      }
      return (
        <Link key={i} href={href}>
          {inner}
        </Link>
      )
    }
    return null
  })
}

function BlockNode({ block, index }) {
  if (!block || typeof block !== 'object') return null
  const { type, children, level } = block

  if (type === 'paragraph') {
    const hasText =
      Array.isArray(children) &&
      children.some((c) => (c?.type === 'text' && c.text && c.text.trim()) || c?.type === 'link')
    if (!hasText) {
      return <Box key={index} sx={{ minHeight: '0.75em' }} />
    }
    return (
      <Typography
        key={index}
        component="p"
        variant="body2"
        className="insight-card-description"
        sx={{ mb: 1.75, whiteSpace: 'pre-wrap' }}
      >
        <InlineNodes nodes={children} />
      </Typography>
    )
  }

  if (type === 'heading') {
    const variant = level === 1 ? 'h4' : level === 2 ? 'h5' : 'h6'
    return (
      <Typography key={index} variant={variant} className="insight-card-title" sx={{ mt: 2, mb: 1 }}>
        <InlineNodes nodes={children} />
      </Typography>
    )
  }

  if (type === 'list') {
    const ListTag = block.format === 'ordered' ? 'ol' : 'ul'
    return (
      <Box
        key={index}
        component={ListTag}
        sx={{
          pl: 2.5,
          my: 1.5,
          color: 'var(--secondary)',
          '& .MuiTypography-root': { color: 'inherit' },
        }}
      >
        {Array.isArray(children)
          ? children.map((child, j) => <BlockNode key={j} block={child} index={j} />)
          : null}
      </Box>
    )
  }

  if (type === 'list-item') {
    const hasNestedBlocks =
      Array.isArray(children) && children.some((c) => c && typeof c === 'object' && c.type && c.type !== 'text')
    if (hasNestedBlocks) {
      return (
        <Box component="li" key={index} sx={{ mb: 0.5 }}>
          {children.map((c, j) => (
            <BlockNode key={j} block={c} index={j} />
          ))}
        </Box>
      )
    }
    return (
      <Box component="li" key={index} sx={{ mb: 0.5 }}>
        <Typography variant="body2" className="insight-card-description" component="span">
          <InlineNodes nodes={children} />
        </Typography>
      </Box>
    )
  }

  return null
}

export function StrapiRichText({ blocks }) {
  if (!Array.isArray(blocks) || blocks.length === 0) return null
  return (
    <Box sx={{ mt: 1 }}>
      {blocks.map((block, i) => (
        <BlockNode key={i} block={block} index={i} />
      ))}
    </Box>
  )
}
