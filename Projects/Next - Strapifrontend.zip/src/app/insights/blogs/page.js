import React from 'react'
import HeaderFooter from '@/components/layout/HeaderFooter'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Container from '@mui/material/Container'
import Grid from '@mui/material/Grid'
import { InsightCard } from './InsightCard'
import { fetchStrapiBlogs, getBlogSlug, resolveStrapiBlogCoverUrl } from '@/lib/strapiBlogs'

export const dynamic = 'force-dynamic'

export default async function BlogsPage() {
  let blogs = []
  let loadError = null
  try {
    blogs = await fetchStrapiBlogs()
  } catch (e) {
    loadError = e instanceof Error ? e.message : 'Failed to load blogs.'
  }

  return (
    <HeaderFooter>
      <Box className="section">
        <Container maxWidth="lg">
          <Box sx={{ mb: 2 }}>
            <Typography variant="h5" className="SectionTitle" gutterBottom>
              Our Latest Trending Blogs
            </Typography>
            <Typography variant="h5" className="paragraph" gutterBottom>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos. Lorem ipsum dolor sit amet
              consectetur adipisicing elit. Quisquam, quos. Lorem ipsum dolor sit amet consectetur adipisicing elit.
              Quisquam, quos. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.
            </Typography>
          </Box>

          {loadError ? (
            <Typography color="error" sx={{ py: 2 }}>
              {loadError}
            </Typography>
          ) : blogs.length === 0 ? (
            <Typography color="text.secondary" sx={{ py: 2 }}>
              No blog posts yet. Publish entries in Strapi and ensure Public role can access Blog (find).
            </Typography>
          ) : (
            <Grid container spacing={2}>
              {blogs.map((blog, index) => (
                <Grid key={blog.documentId || blog.id} size={{ xs: 12, sm: 6, md: 4, lg: 4 }}>
                  <InsightCard
                    slug={getBlogSlug(blog)}
                    documentId={blog.documentId}
                    title={blog.blog_title}
                    description={blog.blog_description}
                    category={blog.blog_category}
                    coverSrc={resolveStrapiBlogCoverUrl(blog)}
                    priority={index === 0}
                  />
                </Grid>
              ))}
            </Grid>
          )}
        </Container>
      </Box>
    </HeaderFooter>
  )
}
