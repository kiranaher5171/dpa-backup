import React from 'react'
import { notFound } from 'next/navigation'
import HeaderFooter from '@/components/layout/HeaderFooter'
import Box from '@mui/material/Box'
import Container from '@mui/material/Container'
import Typography from '@mui/material/Typography'
import Image from 'next/image'
import { Button, Grid } from '@mui/material'
import ArrowLeftIcon from '@mui/icons-material/ArrowLeft'
import { InsightCard } from '../InsightCard'
import Link from 'next/link'
import {
  fetchStrapiBlogByDocumentId,
  fetchStrapiBlogBySlug,
  fetchStrapiRelatedBlogs,
  getBlogSlug,
  normalizeBlogSections,
  resolveStrapiBlogCoverUrl,
} from '@/lib/strapiBlogs'
import { StrapiRichText } from '../StrapiRichText'

export const dynamic = 'force-dynamic'

function excerpt(text, maxLen = 280) {
  if (!text || typeof text !== 'string') return ''
  const t = text.trim()
  if (t.length <= maxLen) return t
  return `${t.slice(0, maxLen).trim()}…`
}

export async function generateMetadata({ params }) {
  const { slug } = await params
  let blog = await fetchStrapiBlogBySlug(slug)
  if (!blog) blog = await fetchStrapiBlogByDocumentId(slug)
  const title = blog?.blog_title
  return title ? { title } : { title: 'Blog' }
}

export default async function BlogDetailPage({ params }) {
  const { slug } = await params
  let blog = await fetchStrapiBlogBySlug(slug)
  if (!blog) {
    blog = await fetchStrapiBlogByDocumentId(slug)
  }
  if (!blog) {
    notFound()
  }

  const coverSrc = resolveStrapiBlogCoverUrl(blog)
  const imageSrc = coverSrc || '/images/dummyImage.jpg'
  const useUnoptimized =
    imageSrc.startsWith('http://127.0.0.1') ||
    imageSrc.startsWith('http://localhost') ||
    imageSrc.startsWith('https://127.0.0.1') ||
    imageSrc.startsWith('https://localhost')

  const sections = normalizeBlogSections(blog)
  const currentSlug = getBlogSlug(blog)
  const exclude = currentSlug ? { blog_slug: currentSlug } : { documentId: blog.documentId }

  let related = []
  try {
    related = await fetchStrapiRelatedBlogs(exclude, 3)
  } catch {
    related = []
  }

  return (
    <HeaderFooter>
      <Box className="sectionsm">
        <Container maxWidth="lg">
          <Typography variant="h5" className="SectionTitle" gutterBottom>
          {blog.blog_title}
          </Typography>
          <Typography variant="h5" className="paragraph" gutterBottom>
            {excerpt(blog.blog_description)}
          </Typography>

          <Box sx={{ position: 'relative', height: '200px' }}>
            <Image
              src={imageSrc}
              alt={blog.blog_title || 'Blog'}
              loading="eager"
              priority
              fill
              sizes="100vw"
              unoptimized={useUnoptimized}
              style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '6px' }}
            />
          </Box>
          <Box className="insight-details-page-separator" aria-hidden />

          <Box className="sectionsm">
            {sections.length > 0 ? (
              sections.map((sec, i) => {
                const headerText =
                  (typeof sec.header === 'string' && sec.header.trim()) ||
                  (typeof sec.title === 'string' && sec.title.trim()) ||
                  ''
                const hasRich = Array.isArray(sec.rich_text) && sec.rich_text.length > 0
                const legacyBody = typeof sec.sub_title === 'string' && sec.sub_title.trim()

                return (
                  <Box key={sec.id ?? `sec-${i}`} sx={{ marginTop: i === 0 ? 0 : '30px' }}>
                    {headerText ? (
                      <Typography variant="h5" className="insight-card-title">
                        {headerText}
                      </Typography>
                    ) : null}
                    {hasRich ? (
                      <StrapiRichText blocks={sec.rich_text} />
                    ) : legacyBody ? (
                      <Typography
                        variant="body2"
                        className="insight-card-description"
                        sx={{ whiteSpace: 'pre-line', mt: headerText ? 1 : 0 }}
                      >
                        {sec.sub_title}
                      </Typography>
                    ) : null}
                  </Box>
                )
              })
            ) : (
              <Box sx={{ marginTop: 0 }}>
                {blog.blog_title ? (
                  <Typography variant="h5" className="insight-card-title">
                    {blog.blog_title}
                  </Typography>
                ) : null}
                {blog.blog_description ? (
                  <Typography variant="body2" className="insight-card-description" sx={{ whiteSpace: 'pre-line' }}>
                    {blog.blog_description}
                  </Typography>
                ) : null}
              </Box>
            )}
          </Box>

          <Box sx={{ backgroundColor: '#f5f5f5', padding: '10px' }}>
            <Link href="/insights/blogs">
              <Button variant="text" color="primary" className="insight-card-read-more" startIcon={<ArrowLeftIcon />}>
                Back to Blogs
              </Button>
            </Link>
          </Box>

          <Box>
            <Box className="sectionsm">
              <Typography variant="h5" className="SectionTitle" gutterBottom>
                Related Blogs
              </Typography>
              <Typography variant="h5" className="paragraph" gutterBottom>
                More from our insights collection.
              </Typography>
            </Box>

            {related.length === 0 ? (
              <Typography color="text.secondary" sx={{ py: 2 }}>
                No other posts to show yet.
              </Typography>
            ) : (
              <Grid container spacing={2}>
                {related.map((b) => (
                  <Grid key={b.documentId || b.id} size={{ xs: 12, sm: 6, md: 3, lg: 4 }}>
                    <InsightCard
                      slug={getBlogSlug(b)}
                      documentId={b.documentId}
                      title={b.blog_title}
                      description={b.blog_description}
                      category={b.blog_category}
                      coverSrc={resolveStrapiBlogCoverUrl(b)}
                      priority={false}
                    />
                  </Grid>
                ))}
              </Grid>
            )}
          </Box>
        </Container>
      </Box>
    </HeaderFooter>
  )
}
