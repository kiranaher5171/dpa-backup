import React from 'react'
import Box from '@mui/material/Box'
import Image from 'next/image'
import Typography from '@mui/material/Typography'
import { Button } from '@mui/material'
import ArrowRightIcon from '@mui/icons-material/ArrowRight'
import Link from 'next/link'

const FALLBACK_COVER = '/images/dummyImage.jpg'

function excerpt(text, maxLen = 180) {
  if (!text || typeof text !== 'string') return ''
  const t = text.trim()
  if (t.length <= maxLen) return t
  return `${t.slice(0, maxLen).trim()}…`
}

export function InsightCard({
  slug,
  documentId,
  title,
  description,
  category,
  coverSrc,
  priority = false,
}) {
  const segment = (slug && String(slug).trim()) || documentId
  const href = segment ? `/insights/blogs/${encodeURIComponent(segment)}` : '/insights/blogs'
  const imageSrc = coverSrc || FALLBACK_COVER
  const useUnoptimized =
    imageSrc.startsWith('http://127.0.0.1') ||
    imageSrc.startsWith('http://localhost') ||
    imageSrc.startsWith('https://127.0.0.1') ||
    imageSrc.startsWith('https://localhost')

  return (
    <Box className="insight-card">
      <Link href={href} style={{ textDecoration: 'none', color: 'inherit' }}>
        <Box sx={{ position: 'relative', height: '200px', overflow: 'hidden' }}>
          <Image
            src={imageSrc}
            alt={title || 'Insight'}
            loading={priority ? 'eager' : 'lazy'}
            priority={priority}
            className="insight-card-image"
            quality={100}
            fill
            sizes="(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw"
            unoptimized={useUnoptimized}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
          <Box sx={{ position: 'absolute', top: 4, right: 4, zIndex: 1 }}>
            <Typography variant="h6" component="span" className="insight-card-category-tag">
              {category || 'Insight'}
            </Typography>
          </Box>
        </Box>
        <Box className="insight-card-read-more-separator" aria-hidden />
        <Box className="content-box">
          <Typography variant="h5" className="insight-card-title two">
            {title || 'Untitled'}
          </Typography>
          <Typography variant="body2" className="insight-card-description four">
            {excerpt(description)}
          </Typography>
          <Box
            className="insight-card-read-more-wrap"
            sx={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start', mt: 1 }}
          >
            <Button
              variant="text"
              color="primary"
              component="span"
              className="insight-card-read-more"
              endIcon={<ArrowRightIcon />}
            >
              Read More
            </Button> 
          </Box>
        </Box>
      </Link>
    </Box>
  )
}
