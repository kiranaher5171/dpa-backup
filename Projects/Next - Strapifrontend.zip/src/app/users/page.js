'use client'
import React, { useState } from 'react'
import HeaderFooter from '@/components/layout/HeaderFooter'
import Box from '@mui/material/Box'
import Container from '@mui/material/Container' 
import Typography from '@mui/material/Typography'
import UserManagementTable from './UserManagementTable'
import TableSearch from '@/components/table_components/TableSearch'
import { MdPersonAddAlt1 } from "react-icons/md";
import { IconButton } from '@mui/material'
import AddUserDialog from './AddUserDialog'

const page = () => {
    const [open, setOpen] = useState(false);
    return (
        <HeaderFooter>
            <Container maxWidth>

                <Box className="whitebx" sx={{ mt: 2 }}>
                    <Box className="fx_sb" sx={{ pb: 1 }}>
                        <Typography variant="h6" className="table-heading" sx={{ flexShrink: 0 }}>
                            Users
                        </Typography>
                        <Box className="fx_fe gap1">
                            <TableSearch />
                            <IconButton size="small" className="icon-btn" onClick={() => setOpen(true)}>  <MdPersonAddAlt1 /> </IconButton>
                        </Box>
                    </Box>
                    <UserManagementTable />
                </Box>

                <AddUserDialog open={open} onClose={() => setOpen(false)} />

            </Container>
        </HeaderFooter>
    )
}

export default page