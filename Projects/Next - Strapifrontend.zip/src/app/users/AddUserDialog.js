import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Typography from "@mui/material/Typography";
import { Box, Divider, Grid, TextField, Autocomplete} from "@mui/material";

const options = [
    { label: "Option 1", value: "option1" },
    { label: "Option 2", value: "option2" },
    { label: "Option 3", value: "option3" },
];

export default function AddUserDialog({ open, onClose }) {

    return (
        <Dialog
            open={open}
            onClose={onClose}
            aria-labelledby="customized-dialog-title"
            maxWidth="xs"
            fullWidth
        >
            <DialogTitle component="div" sx={{ m: 0, p: 2 }} id="customized-dialog-title">
                <Typography variant="h6" component="span" className="table-heading">
                    Add User
                </Typography>
            </DialogTitle>
            <IconButton
                aria-label="close"
                onClick={onClose}
                sx={(theme) => ({
                    position: "absolute",
                    right: 10,
                    top: 12,
                    color: "rgba(0, 0, 0, 0.54)",
                })}
            >
                <CloseIcon sx={{ fontSize: 18 }} />
            </IconButton>
            <Box>
                <Divider
                    sx={{
                        borderColor: "#E0E0E0",
                    }}
                />
            </Box>
            <DialogContent sx={{ minHeight: "30vh" }}>
                <Grid container spacing={2}>
                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                        <Box className="textfield">     
                            <Typography variant="body2" className="form-label" gutterBottom>   User Name</Typography>
                            <TextField variant="outlined" fullWidth placeholder="Enter User Name" />
                        </Box>
                    </Grid>
                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                        <Box className="textfield">     
                            <Typography variant="body2" className="form-label" gutterBottom>   Email</Typography>
                            <TextField variant="outlined" fullWidth placeholder="Enter Email" />
                        </Box>
                    </Grid>
                    <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                        <Box className="textfield auto-complete">     
                            <Typography variant="body2" className="form-label" gutterBottom> Select Role</Typography>
                            <Autocomplete
                                options={options}
                                renderInput={(params) => <TextField className="textfield" {...params} placeholder="Select Role" />}
                            />
                        </Box>
                    </Grid>
                </Grid>
            </DialogContent>

            <DialogActions>
                <Button autoFocus className="primary-outlined-btn" onClick={onClose}>
                    Cancel
                </Button>
                <Button autoFocus className="primary-btn" onClick={onClose}>
                    Add User
                </Button>
            </DialogActions>
        </Dialog>
    );
}
