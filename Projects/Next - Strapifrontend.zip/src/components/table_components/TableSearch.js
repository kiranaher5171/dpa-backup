'use client'

import React, { useState } from 'react'
import { IoSearch } from 'react-icons/io5'
import Box from '@mui/material/Box'
import InputAdornment from '@mui/material/InputAdornment'
import TextField from '@mui/material/TextField'

/** Uncontrolled when `value` / `onChange` omitted; controlled when both passed. */
const TableSearch = ({ value, onChange, placeholder = 'SEARCH' }) => {
  const [internal, setInternal] = useState('')
  const controlled = typeof value === 'string' && typeof onChange === 'function'
  const displayValue = controlled ? value : internal

  const handleChange = (e) => {
    const next = e.target.value
    if (controlled) onChange(next)
    else setInternal(next)
  }

  return (
    <Box className="table-search">
      <TextField
        variant="outlined"
        size="small"
        placeholder={placeholder}
        value={displayValue}
        onChange={handleChange}
        sx={{ width: 220 }}
        slotProps={{
          input: {
            startAdornment: (
              <InputAdornment position="start">
                <IoSearch size={20} color="#bfbfbf" aria-hidden />
              </InputAdornment>
            ),
          },
        }}
      />
    </Box>
  )
}

export default TableSearch
