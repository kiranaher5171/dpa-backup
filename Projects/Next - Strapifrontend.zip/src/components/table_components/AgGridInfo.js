import { Box, Typography } from '@mui/material';
import style from "./pagination.module.css";


const AgGridInfo = ({currentPage,rowsPerPage,totalRows}) => {
    const total = Math.max(0, Number(totalRows) || 0);
    const startRow = total === 0 ? 0 : (currentPage - 1) * rowsPerPage + 1;
    const endRow = total === 0 ? 0 : Math.min(currentPage * rowsPerPage, total);
    return (
        <>
            <Box id={style.tableInfo}>
                <Typography variant='h6' className='txt fw5'>Showing {startRow} to {endRow} of <span className={style.totalEntries}>{total} entries</span></Typography>
            </Box>
        </>
    )
}

export default AgGridInfo