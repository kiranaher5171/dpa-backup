import React from 'react'
import Header from './Header'
import { Box } from '@mui/material'

const HeaderFooter = ({ children }) => {
  return (
    <div>
        <Header />
        <Box className="page-content" >
          {children}
        </Box> 
    </div>
    )
}

export default HeaderFooter