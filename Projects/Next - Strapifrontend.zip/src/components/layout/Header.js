'use client';
import React, { useState } from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Link from 'next/link';
import Container from '@mui/material/Container';
import { usePathname } from 'next/navigation';
import Image from 'next/image';

const NAV_ITEMS = [
    { label: 'Blogs', href: '/insights/blogs' },
    { label: 'Features', href: '#' },
    { label: 'About', href: '#' },
    { label: 'Contact', href: '/contact-us' },
];

/** True when this nav href is the current app route (ignores # placeholder links). */
function isNavActive(pathname, href) {
    if (!href || href === '#' || href.startsWith('#')) return false;
    if (href === '/') return pathname === '/';
    return pathname === href || pathname.startsWith(`${href}/`);
}

export default function Header() {
    const pathname = usePathname();
    const [drawerOpen, setDrawerOpen] = useState(false);

    const toggleDrawer = (open) => (event) => {
        // Prevent toggling if the event comes from tab or shift+tab
        if (
            event &&
            event.type === 'keydown' &&
            (event.key === 'Tab' || event.key === 'Shift')
        ) {
            return;
        }
        setDrawerOpen(open);
    };

    const drawerList = (
        <Box
            sx={{ width: 250 }}
            role="presentation"
            onClick={toggleDrawer(false)}
            onKeyDown={toggleDrawer(false)}
        >
            <List>
                {NAV_ITEMS.map(({ label, href }) => {
                    const active = isNavActive(pathname, href);
                    const itemClass = active ? 'headermenus drawer-nav active' : 'headermenus drawer-nav';
                    if (href === '#') {
                        return (
                            <ListItem key={label} disablePadding>
                                <ListItemButton component="a" href="#" className={itemClass}>
                                    <ListItemText primary={label} />
                                </ListItemButton>
                            </ListItem>
                        );
                    }
                    return (
                        <ListItem key={label} disablePadding>
                            <ListItemButton
                                component={Link}
                                href={href}
                                className={itemClass}
                                selected={active}
                            >
                                <ListItemText primary={label} />
                            </ListItemButton>
                        </ListItem>
                    );
                })}
            </List>
        </Box>
    );

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar position="fixed">
                <Container maxWidth>
                    <Toolbar>
                        <Box sx={{ flexGrow: 1 }}>
                            <Image src="/images/logo.png" alt="Logo" width={100} height={30} loading="lazy" />
                        </Box>

                        <Box id="desktop-only" sx={{ display: { xs: 'none', md: 'flex' }, alignItems: 'center', gap: 0.5 }}>
                            {NAV_ITEMS.map(({ label, href }) => {
                                const active = isNavActive(pathname, href);
                                const className = active ? 'headermenus active' : 'headermenus';
                                if (href === '#') {
                                    return (
                                        <Button key={label} component="a" href="#" className={className}>
                                            {label}
                                        </Button>
                                    );
                                }
                                return (
                                    <Button key={label} component={Link} href={href} className={className}>
                                        {label}
                                    </Button>
                                );
                            })}
                        </Box>
                        <IconButton
                            id="mobile-only"
                            size="large"
                            edge="end"
                            color="inherit"
                            aria-label="menu"
                            sx={{ mr: 2, display: { xs: 'flex', md: 'none' } }}
                            onClick={toggleDrawer(true)}
                        >
                            <MenuIcon />
                        </IconButton>
                    </Toolbar>
                </Container>
            </AppBar>
            <Drawer
                anchor="right"
                open={drawerOpen}
                onClose={toggleDrawer(false)}
            >
                <Toolbar />
                {drawerList}
            </Drawer>
        </Box>
    );
}
