import * as React from 'react';
import { useState } from 'react';
import "./Header.css";
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import { Link } from 'react-router-dom';
import { Menu, Button, Stack } from '@mui/material';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

import MobileDrawer from './MobileDrawer';
import LOGO from '../../Assets/Images/dpa_main_logo.svg';

export default function Header() {
  const [activePage, setActivePage] = useState('');
  const handleSetActivePage = (pageName) => { setActivePage(pageName); };

  const [anchorE2, setAnchorE2] = React.useState(null);
  const handleClick = (event) => { setAnchorE2(event.currentTarget); };
  const handleClose = () => { setAnchorE2(null); };

  const handleLogoClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setActivePage('home');
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar id='Appbar' position="fixed">
        <Toolbar className='Appbar_height'>

          <Box component="div" sx={{ flexGrow: 1 }}>
            <Link to="/" className={activePage === 'home' ? 'active' : ''} onClick={handleLogoClick}>
              <img src={LOGO} alt="PDF Query" className='appbar_logo' />
            </Link>
          </Box>

          <Box component="span" className='fx_fe'>

            <Box className="desktop_menus">
              <Link to="/about-us" className={activePage === 'about-us' ? 'active' : ''} onClick={() => handleSetActivePage('about-us')}>
                <Button className="menus" color="inherit" disableRipple> AboutUs </Button>
              </Link>

              <Link to="#" className={activePage === 'Information' ? 'active' : ''} onClick={() => handleSetActivePage('Information')}>
                <Button variant="text" className='menus' disableRipple endIcon={<ArrowDropDownIcon />} onClick={handleClick}> Information </Button>
              </Link>

              <Menu
                id="menuId"
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                anchorEl={anchorE2}
                keepMounted
                open={Boolean(anchorE2)}
                onClose={handleClose}
                className="menuitem"
              >
                <Stack direction="column" spacing={0}>
                  <Link to="/#why-pdfquery" onClick={() => { handleSetActivePage('Information'); handleClose(); }}>
                    <Button variant="text" className='menus dropmenus' disableRipple>Opction 1 </Button>
                  </Link>
                  <Link to="/#how-it-works" onClick={() => { handleSetActivePage('Information'); handleClose(); }}>
                    <Button variant="text" className='menus dropmenus' disableRipple> Opction 2 </Button>
                  </Link>
                  <Link to="/#who-can-use-it" onClick={() => { handleSetActivePage('Information'); handleClose(); }}>
                    <Button variant="text" className='menus dropmenus' disableRipple> Opction 3 </Button>
                  </Link>
                  <Link to="/#compare-with-chatgpt" onClick={() => { handleSetActivePage('Information'); handleClose(); }}>
                    <Button variant="text" className='menus dropmenus' disableRipple> last opction 4 </Button>
                  </Link>
                </Stack>
              </Menu>

              <Link to="/contact-us" className={activePage === 'contact-us' ? 'active' : ''} onClick={() => handleSetActivePage('contact-us')}>
                <Button className="menus" color="inherit" disableRipple> Contact Us </Button>
              </Link>

              <Link to="/#" className={activePage === 'Sign' ? 'active' : ''} onClick={() => handleSetActivePage('Sign')}>
                <Button variant="text" className='menus' disableRipple> Sign In </Button>
              </Link>
            </Box>

            <Box className="mobile_menus">
              <MobileDrawer />
            </Box>

          </Box>

        </Toolbar>
      </AppBar>
    </Box>
  );
}
