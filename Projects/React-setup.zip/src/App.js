import Header from './Component/Header/Header';
import './Root.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import BackToTop from './Component/Scroll/BackToTop';
import { SignIn } from './Pages/SignIn'; 
import { ContactUs } from './Pages/ContactUs';
import { AboutUs } from './Pages/AboutUs';


function App() {
  return (
    <>

      <Router>
        <Header />
        <BackToTop /> 
        
        <Routes>
          <Route path="/" element={<SignIn />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/contact-us" element={<ContactUs />} />
        </Routes>

      </Router>

    </>
  );
}

export default App;
