import { Box, Typography } from '@mui/material'
import React from 'react'

export const ContactUs = () => {


    return (
        <>
            <Box className="section">
                <Typography variant='h5'> ContactUs page</Typography>
            </Box>
        </>
    )
}
