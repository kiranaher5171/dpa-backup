import { Box, Typography } from '@mui/material'
import React from 'react'

export const AboutUs = () => {


    return (
        <>
            <Box className="section">
                <Typography variant='h5'> AboutUs page</Typography>
            </Box>
        </>
    )
}
