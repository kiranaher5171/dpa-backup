import { Box, Typography } from '@mui/material'
import React from 'react'

export const SignIn = () => {


    return (
        <>
            <Box className="section">
                <Typography variant='h5'> SignIn page</Typography>
            </Box>
        </>
    )
}
