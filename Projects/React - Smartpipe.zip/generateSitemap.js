const fs = require("fs");

const siteUrl = "https://app.smartpipe.cloud"; // Set your site URL

const encodeUrl = (url) => {
  return url.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
};

const generateSitemap = () => {
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${encodeUrl(siteUrl)}</loc>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${encodeUrl(`${siteUrl}/pricing`)}</loc>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${encodeUrl(`${siteUrl}/about`)}</loc>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${encodeUrl(`${siteUrl}/contact-us`)}</loc>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>`;

  fs.writeFileSync("public/sitemap.xml", sitemap);
};

generateSitemap();
