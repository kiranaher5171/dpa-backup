import * as React from "react";
import "./Drawer.css";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import MenuIcon from "@mui/icons-material/Menu";
import { Drawer, Divider, Button } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import { Link, useLocation } from "react-router-dom";

export default function MobileDrawer() {
	const location = useLocation();

	const isActive = (paths) => {
		return paths.some((path) => location.pathname === path);
	};

	const [state, setState] = React.useState({});
	const toggleDrawer = (anchor, open) => (event) => {
		if (event.type === "right" && event.key === "right") {
			return;
		}
		setState({ ...state, [anchor]: open });
	};

	const toggleDrawerFromIcon = (anchor, open) => (event) => {
		setState((prevState) => ({ [anchor]: !prevState[anchor] }));
	};

	const scrollToElement = (id) => {
		const element = document.getElementById(id);
		if (element) {
			const stickyItemsHeight = 0;
			const offset = element.getBoundingClientRect().top - stickyItemsHeight;

			setTimeout(() => {
				window.scrollBy({ top: offset, behavior: "smooth" });
			}, 50);
		}
	};

	return (
		<>
			{["right"].map((anchor) => (
				<>
					<IconButton onClick={toggleDrawerFromIcon(anchor, true)}>
						<MenuIcon fontSize="small" className="" />
					</IconButton>
					<Drawer
						className="drawer"
						anchor={anchor}
						open={state[anchor]}
						onClose={toggleDrawer(anchor, false)}
					>
						<Box
							className="mobilemenuview"
							sx={{ width: 220 }}
							role="presentation"
						>
							<Box mb={1} mt={1} mr={2} className="al_right">
								<IconButton onClick={toggleDrawer(anchor, false)}>
									<CloseIcon fontSize="small" className="wh" />
								</IconButton>
							</Box>

							<Divider />

							<Box>
								<Link
									to="/"
									className={`${isActive(["/"]) ? "active_menu" : ""}`}
								>
									<AccordionSummary>
										<Typography
											className="menus_mobile"
											onClick={toggleDrawer(anchor, false)}
										>
											Home
										</Typography>
									</AccordionSummary>
								</Link>

								{/* <Accordion>
                  <Link to="/about-us" className={`${isActive(['/about-us']) ? 'active_menu' : ''}`}>
                    <AccordionSummary>
                      <Typography className='menus_mobile' onClick={toggleDrawer(anchor, false)}>
                        About us
                      </Typography>
                    </AccordionSummary>
                  </Link>
                </Accordion> */}

								<Link
									to="/connectors"
									className={`${
										isActive(["/connectors"]) ? "active_menu" : ""
									}`}
								>
									<AccordionSummary>
										<Typography
											className="menus_mobile"
											onClick={toggleDrawer(anchor, false)}
										>
											Connectors
										</Typography>
									</AccordionSummary>
								</Link>

								<Link
									to="/about-us"
									className={`${isActive(["/about-us"]) ? "active_menu" : ""}`}
								>
									<AccordionSummary>
										<Typography
											className="menus_mobile"
											onClick={toggleDrawer(anchor, false)}
										>
											About Us
										</Typography>
									</AccordionSummary>
								</Link>

								<Link
									to="/resources"
									className={`${isActive(["/resources"]) ? "active_menu" : ""}`}
								>
									<AccordionSummary>
										<Typography
											className="menus_mobile"
											onClick={toggleDrawer(anchor, false)}
										>
											Resources
										</Typography>
									</AccordionSummary>
								</Link>

								<Link
									to="/pricing"
									className={`${isActive(["/pricing"]) ? "active_menu" : ""}`}
								>
									<AccordionSummary>
										<Typography
											className="menus_mobile"
											onClick={toggleDrawer(anchor, false)}
										>
											Pricing
										</Typography>
									</AccordionSummary>
								</Link>

								<Link
									to="/#get-in-touch"
									className={`${isActive(["/#"]) ? "active_menu" : ""}`}
									onClick={() => scrollToElement("get-in-touch")}
								>
									<AccordionSummary>
										<Typography
											className="menus_mobile"
											onClick={toggleDrawer(anchor, false)}
										>
											Contact Us
										</Typography>
									</AccordionSummary>
								</Link>

								<a
									href="https://app.smartpipe.cloud/"
									rel="noopener noreferrer"
								>
									<Button
										fullWidth
										variant="outlined "
										className="main-btn-2"
										style={{
											maxWidth: "80%",
											marginLeft: 20,
											marginTop: "40vh",
										}}
									>
										{" "}
										Sign in / Sign up{" "}
									</Button>
								</a>
							</Box>

							<Box></Box>
						</Box>
					</Drawer>
				</>
			))}
		</>
	);
}
