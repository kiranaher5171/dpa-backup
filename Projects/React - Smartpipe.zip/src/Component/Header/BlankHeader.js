import * as React from 'react';
import { useState, useEffect } from 'react';
import "./Header.css";
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import LOGO from "../../Assets/Images/logo.svg"
import { Link, useLocation } from 'react-router-dom';
import VpnKeyIcon from '@mui/icons-material/VpnKey';


import MobileDrawer from './MobileDrawer';

export default function BlankHeader() {



  const [scrollClass, setScrollClass] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setScrollClass('scrolled');
      } else {
        setScrollClass('');
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);




  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar id='Appbar' position="fixed" className={scrollClass}>
        <Toolbar className='Appbar_height'>

          <Box component="div" sx={{ flexGrow: 1 }}>
            <Link to="/">
              <img src={LOGO} className='main-logo' alt='SMARTPiPE' />
            </Link>
          </Box>

          <Box className='desktopviewmenu'>

            <a href='https://app.smartpipe.cloud/' target='_blank' rel='noopener noreferrer'>
              <Button variant="outlined" className="main-btn-2" > Sign in / Sign up </Button>
            </a>
          </Box>



          <Box mr={1} className='mobileviewmenu'>
            <a href='https://app.smartpipe.cloud/' target='_blank' rel='noopener noreferrer'>
              <IconButton className='wbg' size='small'>
                <VpnKeyIcon className='col2' fontSize='small' />
              </IconButton>
            </a>
          </Box>

        </Toolbar>
      </AppBar>
    </Box>

  );
}
