import * as React from "react";
import { useState, useEffect } from "react";
import "./Header.css";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import LOGO from "../../Assets/Images/smartpipe_logo.png";
import { Link, useLocation } from "react-router-dom";
import VpnKeyIcon from "@mui/icons-material/VpnKey";

import MobileDrawer from "./MobileDrawer";

export default function Header() {
  const location = useLocation();

  // const isActive = (paths) => {
  //   return paths.some(path => location.pathname.startsWith(path));
  // };

  const isActive = (paths) => {
    return paths.some((path) => location.pathname === path);
  };

  const [scrollClass, setScrollClass] = useState("");

  useEffect(() => {
    const handleScroll = () => {
      if (true) {
        setScrollClass("scrolled");
      } else {
        setScrollClass("");
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const scrollToElement = (id) => {
    const element = document.getElementById(id);
    if (element) {
      const stickyItemsHeight = 0;
      const offset = element.getBoundingClientRect().top - stickyItemsHeight;

      setTimeout(() => {
        window.scrollBy({ top: offset, behavior: "smooth" });
      }, 50);
    }
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar id="Appbar" position="fixed" className={scrollClass}>
        <Toolbar className="Appbar_height">
          <Box component="div" sx={{ flexGrow: 1 }}>
            <Link to="/">
              <img src={LOGO} className="main-logo" alt="SMARTPiPE" />
            </Link>
          </Box>

          <Box className="desktopviewmenu">
            <Link to="/" className={`${isActive(["/"]) ? "active_menu" : ""}`}>
              <Button
                className="menus"
                color="inherit"
                disableRipple
                style={{ color: "black" }} // Set the color to black
              >
                Home
              </Button>
            </Link>
            ;
            {/* <Link to="/about-us" className={`${isActive(['/about-us']) ? 'active_menu' : ''}`}>
              <Button className="menus" color="inherit" disableRipple> About us </Button>
            </Link> */}
            <Link
              to="/connectors"
              className={`${isActive(["/connectors"]) ? "active_menu" : ""}`}
            >
              <Button className="menus" color="inherit" disableRipple>
                {" "}
                Connectors{" "}
              </Button>
            </Link>
            <Link
              to="/about-us"
              className={`${isActive(["/about-us"]) ? "active_menu" : ""}`}
            >
              <Button className="menus" color="inherit" disableRipple>
                {" "}
                About us{" "}
              </Button>
            </Link>
            <Link
              to="/resources"
              className={`${isActive(["/resources"]) ? "active_menu" : ""}`}
            >
              <Button className="menus" color="inherit" disableRipple>
                {" "}
                Resources{" "}
              </Button>
            </Link>
            <Link
              to="/pricing"
              className={`${isActive(["/pricing"]) ? "active_menu" : ""}`}
            >
              <Button className="menus" color="inherit" disableRipple>
                {" "}
                Pricing{" "}
              </Button>
            </Link>
            {/* <Link to="/contact-us" className={`${isActive(['/contact-us']) ? 'active_menu' : ''}`}>
              <Button className="menus" color="inherit" disableRipple> Contact Us </Button>
            </Link> */}
            <Link
              to="/#get-in-touch"
              className={`${isActive(["/#get-in-touch"]) ? "active_menu" : ""}`}
              onClick={() => scrollToElement("get-in-touch")}
            >
              <Button className="menus" color="inherit" disableRipple>
                {" "}
                Contact Us{" "}
              </Button>
            </Link>
            {/* <Link to="/sign-in" className={`${isActive(['/sign-in']) ? 'active_menu' : ''}`}> */}
            <a href="https://app.smartpipe.cloud/" rel="noopener noreferrer">
              <Button variant="outlined" className="main-btn-2">
                {" "}
                Sign in / Sign up{" "}
              </Button>
            </a>
            {/* </Link> */}
          </Box>

          <Box mr={1} className="mobileviewmenu">
            <a
              href="https://app.smartpipe.cloud/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <IconButton className="wbg" size="small">
                <VpnKeyIcon className="col2" fontSize="small" />
              </IconButton>
            </a>
          </Box>

          <Box className="mobileviewmenu">
            <MobileDrawer />
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
