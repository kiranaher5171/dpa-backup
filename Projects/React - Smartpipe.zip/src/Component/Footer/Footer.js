import {
  Box,
  Button,
  Container,
  Grid,
  IconButton,
  Stack,
  Typography,
} from "@mui/material";
import React from "react";
import { Link, useLocation } from "react-router-dom";
import Logo2 from "../../Assets/Images/logo2.svg";
import YouTubeIcon from "@mui/icons-material/YouTube";
import LinkedInIcon from "@mui/icons-material/LinkedIn";

export const Footer = () => {
  const location = useLocation();
  const isActive = (paths) => {
    return paths.some((path) => location.pathname === path);
  };

  const scrollToElement = (id) => {
    const element = document.getElementById(id);
    if (element) {
      const stickyItemsHeight = 0;
      const offset = element.getBoundingClientRect().top - stickyItemsHeight;

      setTimeout(() => {
        window.scrollBy({ top: offset, behavior: "smooth" });
      }, 50);
    }
  };

  return (
    <>
      <Box id="footer" className="section">
        <Container maxWidth="lg">
          <Box>
            <Grid
              container
              rowSpacing={4}
              columnSpacing={5}
              alignItems="top"
              justifyContent="center"
            >
              <Grid item lg={4} md={4} sm={12} xs={12}>
                <Box>
                  <img src={Logo2} alt="20x faster data pipeline creation" />
                </Box>
                <Box pt={2} sx={{ width: "250px" }}>
                  <Typography variant="h6" className="gry fw4" gutterBottom>
                    SMARTPiPE® is a Data Management as a Service & No-code data
                    integration platform
                  </Typography>
                </Box>
              </Grid>

              <Grid item lg={2} md={2} sm={3} xs={6}>
                <Box mt={"12px"}>
                  <Stack direction={"column"} spacing={1}>
                    <Link
                      to="/"
                      className={`linkitem ${
                        isActive(["/"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Home{" "}
                      </Button>
                    </Link>

                    <Link
                      to="/connectors"
                      className={`linkitem ${
                        isActive(["/connectors"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Data connectors{" "}
                      </Button>
                    </Link>

                    {/* <Box>
                      <Button variant='text' className='footer-btn' disableRipple>About us </Button>
                    </Box> */}
                  </Stack>
                </Box>
              </Grid>

              <Grid item lg={2} md={2} sm={3} xs={6}>
                <Box mt={"12px"}>
                  <Stack direction={"column"} spacing={1}>
                    <Link
                      to="/resources"
                      className={`linkitem ${
                        isActive(["/resources"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Resources{" "}
                      </Button>
                    </Link>

                    {/* <Link
                      to="#"
                      className={`linkitem ${
                        isActive(["/knowledge-hub"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Knowledge hub{" "}
                      </Button>
                    </Link> */}

                    <Link
                      to="/schedule-a-demo"
                      className={`linkitem ${
                        isActive(["/schedule-a-demo"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Schedule a demo{" "}
                      </Button>
                    </Link>
                  </Stack>
                </Box>
              </Grid>

              <Grid item lg={2} md={2} sm={3} xs={6}>
                <Box mt={"12px"}>
                  <Stack direction={"column"} spacing={1}>
                    {/* <Link
                      to="#"
                      className={`linkitem ${
                        isActive(["/company"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Company{" "}
                      </Button>
                    </Link> */}

                    {/* <Link to="/contact-us" className={`linkitem ${isActive(['/contact-us']) ? 'active_menu' : ''}`}> */}
                    <Link
                      to="/#get-in-touch"
                      className={`${
                        isActive(["/#get-in-touch"]) ? "active_menu" : ""
                      }`}
                      onClick={() => scrollToElement("get-in-touch")}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Contact us{" "}
                      </Button>
                    </Link>

                    <Link
                      to="/privacy"
                      className={`linkitem ${
                        isActive(["/privacy"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Privacy policy{" "}
                      </Button>
                    </Link>

                    <Link
                      to="/cookies"
                      className={`linkitem ${
                        isActive(["/cookies"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Cookie policy{" "}
                      </Button>
                    </Link>

                    <Link
                      to="/terms"
                      className={`linkitem ${
                        isActive(["/terms"]) ? "active_menu" : ""
                      }`}
                    >
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Terms of service{" "}
                      </Button>
                    </Link>
                  </Stack>
                </Box>
              </Grid>

              <Grid item lg={2} md={2} sm={3} xs={6}>
                <Box mt={"12px"}>
                  <Stack direction={"column"} spacing={1}>
                    <Box>
                      <Button
                        variant="text"
                        className="footer-btn"
                        disableRipple
                      >
                        Follow us on{" "}
                      </Button>
                    </Box>

                    <Stack direction={"row"} spacing={1}>
                      <a
                        href="https://www.linkedin.com/company/dpa-smartpipe/"
                        target="_blank"
                        rel="noreferrer"
                      >
                        <IconButton className="social-ico-btn linkedin">
                          <LinkedInIcon fontSize="small" />
                        </IconButton>
                      </a>

                      <a
                        href="https://www.youtube.com/@SMARTPiPE-DMaaS"
                        target="_blank"
                        rel="noreferrer"
                      >
                        <IconButton className="social-ico-btn yt">
                          <YouTubeIcon fontSize="small" />
                        </IconButton>
                      </a>
                    </Stack>
                  </Stack>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>
    </>
  );
};
