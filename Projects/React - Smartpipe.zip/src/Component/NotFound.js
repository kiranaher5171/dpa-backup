import React, { useEffect, useState } from "react";
import { Box, Typography, Link } from "@mui/material";
import { Link as RouterLink, useNavigate } from "react-router-dom";

const NotFoundPage = () => {
  const navigate = useNavigate();
  const [redirectCountdown, setRedirectCountdown] = useState(8);

  useEffect(() => {
    const redirectTimer = setTimeout(() => {
      navigate("/");
    }, redirectCountdown * 1000);

    const interval = setInterval(() => {
      setRedirectCountdown((prevCountdown) => prevCountdown - 1);
    }, 1000);

    return () => {
      clearTimeout(redirectTimer);
      clearInterval(interval);
    };
  }, [navigate, redirectCountdown]);

  return (
    <>
      <Box className="under-construction">
        <Typography variant="h2" className="col1 fw7">
          Page Not Found
        </Typography>
        <Typography variant="h5" className="gry fw7">
          Redirecting to{" "}
          <Link component={RouterLink} to="/">
            Homepage
          </Link>{" "}
          in <span className="col1">{redirectCountdown} seconds</span>...
        </Typography>
      </Box>
    </>
  );
};

export default NotFoundPage;
