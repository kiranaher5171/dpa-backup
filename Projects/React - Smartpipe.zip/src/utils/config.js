import Joi from "joi";
const config = {
  APP_URL: process.env.REACT_APP_URL,
  CLARITY_PROJECT: process.env.REACT_APP_CLARITY_PROJECT,
  SMARTPIPE_REDIRECT_URL: process.env.REACT_APP_SMARTPIPE_REDIRECT_URL,
  SMARTPIPE_SUPPORT_URL: process.env.REACT_APP_SMARTPIPE_SUPPORT_URL,
  GOOGLE_ANALYTICS_ID: process.env.REACT_APP_GA_TRACKING_ID,
};
const configSchema = Joi.object({
  APP_URL: Joi.string().required(),
  CLARITY_PROJECT: Joi.string().required(),
  SMARTPIPE_SUPPORT_URL: Joi.string().required(),
  SMARTPIPE_REDIRECT_URL: Joi.string().required(),
  GOOGLE_ANALYTICS_ID: Joi.string().required(),
});
const { error } = configSchema.validate(config);
if (error) {
  console.error("Configuration validation error:", error.details);
} else {
  console.log("Configuration is valid");
}
export default config;
