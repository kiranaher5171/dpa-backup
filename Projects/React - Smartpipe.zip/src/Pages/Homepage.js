import React, { useEffect } from "react";
import { HeroSection } from "./HomepageSections/HeroSection";
import { DmaasPros } from "./HomepageSections/DmaasPros";
import { HowItWorks } from "./HomepageSections/HowItWorks";
import { Features } from "./HomepageSections/Features";
import { Testimonials } from "./HomepageSections/Testimonials";
import { Benefits } from "./HomepageSections/Benefits";
import { GetInTouch } from "./HomepageSections/GetInTouch";
import { SecurityAssurancePatch } from "./HomepageSections/SecurityAssurancePatch";
import AOS from "aos";
import "aos/dist/aos.css";

export const Homepage = () => {
  useEffect(() => {
    AOS.init({ duration: 800 });
  }, []);

  return (
    <>
      <HeroSection />

      <DmaasPros />

      <Features />

      <SecurityAssurancePatch />

      <HowItWorks />

      <Testimonials />

      <Benefits />

      <GetInTouch />
    </>
  );
};
