import { Box, Button, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import Benefit1 from "../../Assets/Images/landing-page/benefits/benefit1.svg";
import Benefit2 from "../../Assets/Images/landing-page/benefits/benefit2.svg";
import Benefit3 from "../../Assets/Images/landing-page/benefits/benefit3.svg";
import Benefit4 from "../../Assets/Images/landing-page/benefits/benefit4.svg";
import { Link } from 'react-router-dom';


export const Benefits = () => {
    return (
        <>

            <Box id="benefits" className="section">

                <Container maxWidth="lg">

                    <Box className="al_left" data-aos="fade-up" data-duration="800">
                        <Typography variant='h2' className='col1v2 fw7 mb0' gutterBottom>
                            Our unmatched benefits
                        </Typography>

                        <Box id="txt-w-btn" className="fx_fs">
                            <Box>
                                <Typography variant='h4' className='bl fw6 mb0'>
                                    Unlock exclusive features that set our data management platform apart from the rest
                                </Typography>
                            </Box>

                            <Link to="/schedule-a-demo">
                                <Box className="btn-with-txt">
                                    <Button variant='text' className='txt-btn' disableRipple endIcon={<ArrowForwardIosIcon />}> Schedule a demo </Button>
                                </Box>
                            </Link>
                        </Box>
                    </Box>

                    <Box data-aos="fade-up" data-duration="1200">
                        <Grid container columnSpacing={4} alignItems="top" justifyContent="center">
                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className="benefit-bx-main">
                                    <Box className="benefit-ico">
                                        <img src={Benefit1} alt='20x faster data pipeline creation' />
                                    </Box>
                                    <Box className="benefits-bx">
                                        <Typography variant='h5' className='bl fw4' gutterBottom>
                                            20X  faster data pipeline creation
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className="benefit-bx-main">
                                    <Box className="benefit-ico">
                                        <img src={Benefit2} alt='World’s first fully managed service' />
                                    </Box>
                                    <Box className="benefits-bx">
                                        <Typography variant='h5' className='bl fw4' gutterBottom>
                                            World’s first fully managed service
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className="benefit-bx-main">
                                    <Box className="benefit-ico">
                                        <img src={Benefit3} alt='Reduce your cost by upto 50%' />
                                    </Box>
                                    <Box className="benefits-bx">
                                        <Typography variant='h5' className='bl fw4' gutterBottom>
                                            Reduce your cost by upto 50%
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>


                            <Grid item lg={3} md={3} sm={6} xs={12}>
                                <Box className="benefit-bx-main">
                                    <Box className="benefit-ico">
                                        <img src={Benefit4} alt='Save up to ~20 person-hours/week' />
                                    </Box>
                                    <Box className="benefits-bx">
                                        <Typography variant='h5' className='bl fw4' gutterBottom>
                                            Save up to ~20 person-hours/week
                                        </Typography>
                                    </Box>
                                </Box>
                            </Grid>



                        </Grid>
                    </Box>




                </Container>

            </Box>
        </>
    )
}
