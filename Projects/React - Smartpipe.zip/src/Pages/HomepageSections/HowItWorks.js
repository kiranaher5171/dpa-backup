import { Box, Button, Container, Typography } from '@mui/material'
import React from 'react' 
import Flow from "../../Assets/Images/landing-page/flow-video.m4v";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { Link } from 'react-router-dom';




export const HowItWorks = () => {
    return (
        <>

            <Box id="how-it-works" className="section">

                <Container maxWidth="lg">
                    <Box className="flow-brd-bx">


                        <Box className="al_left" mb={2} data-aos="fade-up" data-duration="1000">
                            <Typography variant='h2' className='col1v2 fw7 mb0' gutterBottom>
                                How does SMARTPiPE work?
                            </Typography>
                        </Box>

                        <Box mt={4} mb={2}>
                            <video autoPlay loop muted >
                                <source src={Flow} type="video/webm" />
                            </video>
                        </Box>


                        <Box className="al_right">
                        <Link to="/connectors">
                            <Button variant='text' className='txt-btn' disableRipple endIcon={<ArrowForwardIosIcon />}> Explore connectors </Button>
                            </Link>
                        </Box>



                    </Box>
                </Container>

            </Box>
        </>
    )
}
