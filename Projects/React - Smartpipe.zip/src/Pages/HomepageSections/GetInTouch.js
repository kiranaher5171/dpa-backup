import { Box, Container, Grid, Typography } from "@mui/material";
import React, { useEffect } from "react";
import SideImg from "../../Assets/Images/landing-page/get-in-touch.png";
// import FormTabs from './GetInTouch/FormTabs';
import ContactForm from "./GetInTouch/ContactForm";

export const GetInTouch = () => {
  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      const element = document.querySelector(hash);
      if (element) {
        const offset = 160;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition - offset;
        window.scrollBy({
          top: offsetPosition,
          behavior: "smooth",
        });
      }
    }
  }, []);

  return (
    <>
      <Box id="get-in-touch" className="section">
        <Container maxWidth="lg">
          <Box
            className="contact-bg-bx"
            data-aos="zoom-in"
            data-duration="2000"
          >
            <Grid container alignItems="top" justifyContent="center">
              <Grid
                item
                lg={5}
                md={3}
                sm={12}
                xs={12}
                data-aos="zoom-in"
                data-duration="1000"
                className="contact-side-img"
                style={{ backgroundImage: "url(" + SideImg + ")" }}
              ></Grid>
              <Grid item lg={7} md={9} sm={12} xs={12}>
                <Box className="contact-formbx">
                  <Box className="al_left">
                    <Typography variant="h2" className="wh fw7" gutterBottom>
                      Get in touch
                    </Typography>

                    <Typography variant="h4" className="wh fw4" gutterBottom>
                      Have an enquiry? Fill out the form to contact our team
                    </Typography>
                  </Box>

                  <Box>
                    {/* <FormTabs /> */}
                    <ContactForm />
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>
    </>
  );
};
