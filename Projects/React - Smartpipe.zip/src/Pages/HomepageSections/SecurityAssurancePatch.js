import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'

import Security from "../../Assets/Images/landing-page/icons/security.svg";
import Decorator from "../../Assets/Images/landing-page/icons/secure-deco.svg";



export const SecurityAssurancePatch = () => {
    return (
        <>

            <Box id="security-assurance-patch" pt={"50px"} data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-duration="2000">

                <Container maxWidth="lg">

                    <Grid container spacing={2} alignItems="top" justifyContent="center">
                        <Grid item lg={11} md={11} sm={12} xs={12}>
                            <Box className="dark-bg-bx">

                                <Grid container rowSpacing={2} columnSpacing={2} alignItems="center" justifyContent="center">
                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                        <Box className="fx_fs">
                                            <Box>
                                                <img src={Security} className='' alt='' />
                                            </Box>
                                            <Box ml={2}>
                                                <Typography variant='h3' className='wh fw5' gutterBottom>
                                                    Your Data is Completely Secure
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={6} xs={12}>
                                        <Box className="fx_fs">
                                            <Box>
                                                <img src={Decorator} className='' alt='' />
                                            </Box>
                                            <Box ml={2}>
                                                <Typography variant='h6' className='wh fw4' gutterBottom>
                                                    GDPR & HIPAA Compliant
                                                </Typography>
                                            </Box>
                                        </Box>

                                        <Box className="fx_fs" pt={'12px'}>
                                            <Box>
                                                <img src={Decorator} className='' alt='' />
                                            </Box>
                                            <Box ml={2}>
                                                <Typography variant='h6' className='wh fw4' gutterBottom>
                                                    Role based access
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Grid>
                                    <Grid item lg={3} md={3} sm={6} xs={12}>
                                        <Box className="fx_fs">
                                            <Box>
                                                <img src={Decorator} className='' alt='' />
                                            </Box>
                                            <Box ml={2}>
                                                <Typography variant='h6' className='wh fw4' gutterBottom>
                                                    We do not save your data
                                                </Typography>
                                            </Box>
                                        </Box>

                                        <Box className="fx_fs" pt={'12px'}>
                                            <Box>
                                                <img src={Decorator} className='' alt='' />
                                            </Box>
                                            <Box ml={2}>
                                                <Typography variant='h6' className='wh fw4' gutterBottom>
                                                    Region restricted processing
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Grid>
                                </Grid>


                            </Box>
                        </Grid>
                    </Grid>


                </Container>

            </Box>
        </>
    )
}
