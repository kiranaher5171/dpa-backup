import { Box, Button, Grid, TextField, Typography } from "@mui/material";
import axios from "axios";
import React, { useState } from "react";
import config from "../../../utils/config";
import withSnackbar from "../../../Component/HOC/Snackbar";

function ContactForm({ setSnackState }) {
  const [email, setEmail] = useState("");
  const [description, setDescription] = useState("");
  const [fullName, setFullName] = useState("");

  const isValidEmail = (email) => {
    // Regular expression for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const isValidFullName = (name) => {
    const fullNameRegex = /^[a-zA-Z0-9\s]+$/;
    return fullNameRegex.test(name);
  };

  const isValidNote = (note) => {
    return note.length >= 3;
  };

  const handleSubmit = async () => {
    if (
      !isValidEmail(email) ||
      !isValidFullName(fullName) ||
      !isValidNote(description)
    ) {
      setSnackState({
        message: "Please fill in all fields correctly.",
        severity: "error",
      });
      return;
    }

    var formData = new FormData();
    formData.append("attachment", undefined);
    formData.append("email", email);
    formData.append("subject", "Enquiry");
    formData.append("description", description);
    formData.append("type", "Contact sales");
    formData.append("priority", 1);
    formData.append("name", fullName);

    try {
      const response = await axios.post(
        `${config.SMARTPIPE_SUPPORT_URL}/api/v1/support/freshdesk/`,
        formData
      );

      setSnackState({
        message: "Your Ticket has been created",
        severity: "success",
      });
      onReset();
    } catch (error) {
      setSnackState({
        message: "Failed to create ticket",
        severity: "error",
      });
    }
  };

  const onReset = () => {
    setEmail("");
    setDescription("");
    setFullName("");
  };

  return (
    <Box id="contact-form">
      <Box pt={2}>
        <Grid
          container
          rowSpacing={2}
          columnSpacing={2}
          alignItems="top"
          justifyContent="flex-start"
        >
          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="ol_txtfield" pt={2}>
              <Typography variant="h6" className="wh fw5" gutterBottom>
                Full Name
              </Typography>
              <TextField
                id="filled-basic"
                className="filleddp"
                variant="outlined"
                placeholder="Enter full name"
                fullWidth
                value={fullName}
                type="name"
                autoComplete="off"
                error={
                  (!isValidFullName(fullName) && fullName.length > 0) ||
                  (fullName.length > 0 && fullName.length < 3)
                }
                helperText={
                  !isValidFullName(fullName) && fullName.length > 0
                    ? "Only Alphanumeric characters allowed"
                    : fullName.length > 0 && fullName.length < 3
                    ? "Name must be at least 3 characters long"
                    : ""
                }
                onChange={(e) => setFullName(e.target.value)}
              />
            </Box>
          </Grid>

          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="ol_txtfield" pt={2}>
              <Typography variant="h6" className="wh fw5" gutterBottom>
                Email
              </Typography>
              <TextField
                id="filled-basic"
                className="filleddp"
                variant="outlined"
                placeholder="Enter email"
                fullWidth
                value={email}
                error={!isValidEmail(email) && email.length > 0}
                helperText={
                  !isValidEmail(email) && email.length > 0
                    ? "Enter a valid email address"
                    : ""
                }
                onChange={(e) => setEmail(e.target.value)}
              />
            </Box>
          </Grid>

          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="ol_txtfield" pt={2}>
              <Typography variant="h6" className="wh fw5" gutterBottom>
                Note
              </Typography>
              <TextField
                id="filled-basic"
                className="filleddp"
                variant="outlined"
                multiline
                rows={2}
                placeholder="Enter note here"
                fullWidth
                value={description}
                error={!isValidNote(description) && description.length > 0}
                helperText={
                  !isValidNote(description) && description.length > 0
                    ? "Note must be at least 3 characters long"
                    : ""
                }
                onChange={(e) => setDescription(e.target.value)}
              />
            </Box>
          </Grid>

          <Grid item lg={4} md={4} sm={6} xs={12}>
            <Box pt={2}>
              <Button
                variant="outlined"
                className="main-btn-2"
                fullWidth
                onClick={handleSubmit}
                disabled={
                  !isValidEmail(email) ||
                  !isValidFullName(fullName) ||
                  !isValidNote(description)
                }
              >
                {" "}
                Submit{" "}
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
}
export default withSnackbar(ContactForm);
