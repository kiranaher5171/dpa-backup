import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { ContactForm } from './ContactForm'; 
import { ScheduleDemoCustom } from './ScheduleDemoCustom';

export default function FormTabs() {
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <Box className="secondary-tabs" pt={4}>
            <TabContext value={value}>
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <TabList onChange={handleChange} aria-label="lab API tabs example">
                        <Tab label="Contact us" value="1" />
                        <Tab label="Schedule demo" value="2" />
                    </TabList>
                </Box>
                <TabPanel value="1">
                    <ContactForm />
                </TabPanel>
                <TabPanel value="2">
                    <ScheduleDemoCustom />
                </TabPanel>
            </TabContext>
        </Box>
    );
}
