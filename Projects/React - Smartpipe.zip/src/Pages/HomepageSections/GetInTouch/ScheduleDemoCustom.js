import { Box, Button, Grid, Stack, Typography } from '@mui/material'
import React, { useState } from 'react'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';

import TimezonePicker from 'react-timezone';



export const ScheduleDemoCustom = () => {


    const [selectedSlot, setSelectedSlot] = useState("04:00 PM");

    const handleSlotSelect = (slot) => {
        setSelectedSlot(slot);
    };


    const [selectedTimeZone, setSelectedTimeZone] = useState("Asia/Yerevan");
    const handleTimeZoneChange = (timezone) => {
        setSelectedTimeZone(timezone);
    };

    return (
        <Box id="schedule-demo">

            <Box pt={2}>
                <Grid container rowSpacing={2} columnSpacing={4} alignItems="flex-end" justifyContent="flex-start">
                    <Grid item lg={8} md={8} sm={8} xs={12}>
                        <Box className='calender' pt={1}>
                            <Typography variant="h6" className="wh fw5" gutterBottom>Select Date</Typography>
                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DateCalendar />
                            </LocalizationProvider>
                        </Box>
                    </Grid>

                    <Grid item lg={4} md={4} sm={4} xs={12}>
                        <Box pt={1}>
                            <Typography variant="h6" className="wh fw5" gutterBottom>Select Time</Typography>
                            <Box className='time-selection'>
                                <Stack direction="column" spacing={1}>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '04:00 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('04:00 PM')}>
                                        04:00 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '04:30 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('04:30 PM')}>
                                        04:30 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '05:00 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('05:00 PM')}>
                                        05:00 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '05:30 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('05:30 PM')}>
                                        05:30 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '06:00 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('06:00 PM')}>
                                        06:00 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '06:30 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('06:30 PM')}>
                                        06:30 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '07:00 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('07:00 PM')}>
                                        07:00 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '07:00 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('07:00 PM')}>
                                        07:00 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '07:30 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('07:30 PM')}>
                                        07:30 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '08:00 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('08:00 PM')}>
                                        08:00 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '08:30 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('08:30 PM')}>
                                        08:30 PM
                                    </Button>
                                    <Button variant="outlined"
                                        className={`time-slot ${selectedSlot === '09:00 PM' ? 'selected-slot' : ''}`}
                                        fullWidth onClick={() => handleSlotSelect('09:00 PM')}>
                                        09:00 PM
                                    </Button>
                                </Stack>
                            </Box>
                        </Box>
                    </Grid>


                    <Grid item lg={8} md={8} sm={12} xs={12}>
                        <Box className='timezone-picker' pt={0}>
                            <Typography variant="h6" className="wh fw5" gutterBottom>Time Zone:</Typography>
                            <TimezonePicker
                                value={selectedTimeZone}
                                onChange={handleTimeZoneChange}
                                inputProps={{
                                    placeholder: 'Select Timezone...',
                                    name: 'timezone',
                                }}
                            />
                        </Box>
                    </Grid>


                    <Grid item lg={4} md={4} sm={12} xs={12}>
                        <Box pt={2}>
                            <Button variant="outlined" className="main-btn-2" fullWidth> Next </Button>
                        </Box>
                    </Grid>
                </Grid>

            </Box>


        </Box>
    )
}
