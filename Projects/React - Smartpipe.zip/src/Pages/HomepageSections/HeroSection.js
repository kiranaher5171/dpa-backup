import { Box, Button, Container, Grid, Stack, Typography } from "@mui/material";
import React, { useState } from "react";
import SideImg from "../../Assets/Images/landing-page/hero-side.png";
import { Link } from "react-router-dom";
import { TypeAnimation } from "react-type-animation";
import "aos/dist/aos.css";

export const HeroSection = () => {
  const scrollToElement = (id) => {
    const element = document.getElementById(id);
    if (element) {
      const stickyItemsHeight = 50;
      const offset = element.getBoundingClientRect().top - stickyItemsHeight;

      setTimeout(() => {
        window.scrollBy({ top: offset, behavior: "smooth" });
      }, 50);
    }
  };

  return (
    <>
      <Box id="hero">
        <Container maxWidth="lg">
          <Box
            className="animated-bx"
            data-aos="fade-down"
            data-duration="2000"
          >
            <Typography variant="h1" className="wh fw7 type-animation-text">
              <TypeAnimation
                className="type-animation-text"
                sequence={[
                  "Is inefficient data handling limiting your growth?",
                  1500,
                ]}
                wrapper="span"
                speed={60}
                repeat={0}
                cursor={false}
              />
            </Typography>
          </Box>

          <Box pt={2} id="hero-content">
            <Grid
              container
              rowSpacing={2}
              columnSpacing={10}
              alignItems="top"
              justifyContent="center"
            >
              <Grid item lg={7} md={7} sm={12} xs={12}>
                <Box className="relative">
                  <Box>
                    <Typography variant="h4" className="wh fw6">
                      <ul>
                        <li data-aos="fade-down" data-duration="2200">
                          Automating data processing and cleansing is
                          challenging and time-consuming
                        </li>

                        <li data-aos="fade-down" data-duration="2300">
                          Dealing with errors and data quality issues is a
                          challenge
                        </li>

                        <li data-aos="fade-down" data-duration="2400">
                          It is a struggle to integrate data from various
                          sources
                        </li>

                        <li data-aos="fade-down" data-duration="2500">
                          Costs more than it should
                        </li>
                      </ul>
                    </Typography>
                  </Box>

                  <Box className="absolute w100">
                    <Box
                      className="get-started-bx"
                      data-aos="fade-up"
                      data-duration="2500"
                    >
                      <Box className="al_center" pb={2}>
                        <Typography
                          variant="h3"
                          className="col1v2 fw7"
                          gutterBottom
                        >
                          Introducing Data Management as a Service (DMaaS)​
                        </Typography>

                        <Typography
                          variant="h4"
                          className="bl fw6"
                          gutterBottom
                        >
                          We can manage data for you, from start to finish
                        </Typography>
                      </Box>

                      <Box className="al_center" mt={2}>
                        <Stack
                          direction="row"
                          spacing={2}
                          justifyContent="center"
                        >
                          <Link to="/schedule-a-demo">
                            <Button variant="outlined" className="main-btn-3">
                              {" "}
                              Schedule a demo{" "}
                            </Button>
                          </Link>
                          <Button
                            variant="outlined"
                            className="main-btn-2"
                            onClick={() => scrollToElement("get-in-touch")}
                          >
                            {" "}
                            Contact us{" "}
                          </Button>
                        </Stack>
                      </Box>

                      <Box className="al_center" pt={3}>
                        <Link to="#">
                          <Typography
                            variant="h5"
                            className="col1 fw6"
                            gutterBottom
                            onClick={() => scrollToElement("features")}
                          >
                            <u>Prefer to do it yourself with zero-code?</u>
                          </Typography>
                        </Link>
                      </Box>
                    </Box>
                  </Box>
                </Box>
              </Grid>
              <Grid
                item
                lg={5}
                md={5}
                sm={12}
                xs={12}
                data-aos="zoom-in-up"
                data-aos-offset="300"
                data-aos-easing="ease-in-sine"
              >
                <Box
                  mt={"38px"}
                  className="hero-side-img"
                  style={{ backgroundImage: "url(" + SideImg + ")" }}
                ></Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>
    </>
  );
};
