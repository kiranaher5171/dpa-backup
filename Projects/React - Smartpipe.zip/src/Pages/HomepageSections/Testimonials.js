import { Box, Grid, IconButton, Container, Typography, Rating } from '@mui/material';
import React, { useState, useEffect } from 'react';  
import { ArrowBackIos, ArrowForwardIos } from '@mui/icons-material'; 

import RatingFilled from "../../Assets/Images/landing-page/icons/rating_filled.svg";
import RatingOutlined from "../../Assets/Images/landing-page/icons/rating_outlined.svg";




const Testimonial1 = () => {
    return (
        <Box>
            <Box className="testimonial-rating" mb={2}>
                <Rating name="read-only" value={4} readOnly icon={<img src={RatingFilled} alt='Rating Filled'/>} emptyIcon={<img src={RatingOutlined}  alt='Rating Outlined'/>} />
            </Box>

            <Box className="testimonial-content">
                <Typography variant="h6" className="content fw5">
                    <em>
                        SMARTPiPE revolutionized the data management at our financial index firm, automating processes and replacing inefficient manual methods. This led to significant time and cost savings, and improved data accuracy across multiple processes. The quick setup of data pipelines enhanced operational efficiency, ensuring up-to-date databases and reliable financial indices. This transformation reinforced our leadership in the Indian market.
                    </em>
                </Typography>
            </Box>

            <Box className="testimonial-footer">
                <Typography variant="h6" className="bl fw5">
                    <em>
                        -Senior developer for leading index publisher in Asia.
                    </em>
                </Typography>
            </Box>
        </Box>
    );
};


const Testimonial2 = () => {
    return (
        <Box>

            <Box className="testimonial-rating" mb={2}>
                <Rating name="read-only" value={5} readOnly icon={<img src={RatingFilled}  alt='Rating Filled'/>} emptyIcon={<img src={RatingOutlined}  alt='Rating Outlined'/>} />
            </Box>


            <Box className="testimonial-content">
                <Typography variant="h6" className="content fw5">
                    <em>
                        Partnering with SMARTPiPE has been a game-changer for our financial data operations. Their innovative SaaS platform transformed the way we handle data, turning complex challenges into streamlined processes and delivering results beyond our expectations. Their commitment to efficiency, data integrity, and cost-saving solutions has empowered us to focus on growth and deliver superior value to our clients.
                    </em>
                </Typography>
            </Box>

            <Box className="testimonial-footer">
                <Typography variant="h6" className="bl fw5">
                    <em>
                        -Client Process Owner for global data feed provider.
                    </em>
                </Typography>
            </Box>

        </Box>
    );
};


const items = [
    { id: 1, content: <><Testimonial1 /></> },
    { id: 2, content: <><Testimonial2 /></> }
];




export const Testimonials = () => {
    const [index, setIndex] = useState(0);


    useEffect(() => {
        const timer = setTimeout(() => {
            handleNext();
        }, 8000);
        return () => clearTimeout(timer);
    }, [index]);


    const handleNext = () => {
        setIndex((prevIndex) => (prevIndex + 1) % items.length);
    };

    const handleBack = () => {
        setIndex((prevIndex) => (prevIndex - 1 + items.length) % items.length);
    };

    return (
        <Box id="testimonials" className="section">
            <Container maxWidth="lg">
                <Box className="al_left" data-aos="fade-up" data-duration="1000">
                    <Typography variant='h2' className='col1v2 fw7 mb0' gutterBottom>
                        Words from Our Valued Customers
                    </Typography>
                    <Typography variant='h4' className='bl fw6' gutterBottom>
                        Read what our customers have to say about their experience with us
                    </Typography>
                </Box>

                <Box id="testimonials-cards" data-aos="zoom-in" data-duration="2000">
 
                    <Box className="aboveTabTestimonial">
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <Grid container columnSpacing={5} justifyContent="flex-end" alignItems="flex-end">
                                    {[index, (index + 1) % items.length].map((itemIndex, i) => (
                                        <Grid key={items[itemIndex].id} item xs={5}>
                                            <div className={`testimonial-bx ${i === 1 ? 'bx-2' : ''}`}>
                                                {items[itemIndex].content}
                                            </div>
                                        </Grid>
                                    ))}


                                    <Grid item xs={5}>
                                        <Box className="al_right arrows">
                                            <IconButton onClick={handleBack}>
                                                <ArrowBackIos className="col2" />
                                            </IconButton>
                                            <IconButton onClick={handleNext}>
                                                <ArrowForwardIos className="col2" />
                                            </IconButton>
                                        </Box>
                                    </Grid>
                                </Grid>

                            </Grid>
                        </Grid>
                    </Box>




                    <Box className="belowTabTestimonial">
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <Grid container columnSpacing={5} justifyContent="flex-end" alignItems="flex-end">
                                    {/* {[index, (index + 1) % items.length].map((itemIndex, i) => ( */}
                                    <Grid item xs={12}>
                                        <div className={`testimonial-bx`}>
                                            {items[index].content}
                                        </div>
                                    </Grid>
                                    {/* ))} */}


                                    <Grid item xs={5}>
                                        <Box className="al_right arrows">
                                            <IconButton onClick={handleBack}>
                                                <ArrowBackIos className="col2" />
                                            </IconButton>
                                            <IconButton onClick={handleNext}>
                                                <ArrowForwardIos className="col2" />
                                            </IconButton>
                                        </Box>
                                    </Grid>
                                </Grid>

                            </Grid>
                        </Grid>
                    </Box>
                </Box>



            </Container>
        </Box>
    )
};
