import {
  Box,
  Button,
  Container,
  Grid,
  InputAdornment,
  TextField,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import VideoBg from "../../Assets/Images/landing-page/video-bg.png";
import PlayCircleFilledWhiteOutlinedIcon from "@mui/icons-material/PlayCircleFilledWhiteOutlined";
import Done from "../../Assets/Images/landing-page/done.svg";
import Trial from "../../Assets/Images/landing-page/icons/trial.svg";
import Loyal from "../../Assets/Images/landing-page/icons/loyal.svg";
import Service from "../../Assets/Images/landing-page/icons/service.svg";
import ModalVideo from "react-modal-video";
import "react-modal-video/scss/modal-video.scss";
import config from "../../utils/config";

export const Features = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState("");

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };
  const openModal = () => {
    setIsOpen(true);
  };
  const isValidEmail = (email) => {
    // Regular expression for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  return (
    <>
      <Box id="features">
        <Container maxWidth="lg">
          <Box data-aos="fade-up" data-duration="1000">
            <Typography variant="h2" className="wh fw7" gutterBottom>
              Effortlessly manage it yourself, no coding required
            </Typography>
            <Typography variant="h4" className="wh fw6" gutterBottom>
              Empower your data management journey hassle-free
            </Typography>
          </Box>

          <Box mt={5}>
            <Grid
              container
              rowSpacing={2}
              columnSpacing={6}
              alignItems="top"
              justifyContent="center"
            >
              <Grid item lg={6} md={6} sm={6} xs={12}>
                <Box data-aos="zoom-in-up" date-duration="1000">
                  <Box
                    class="video-container-bg"
                    style={{ backgroundImage: "url(" + VideoBg + ")" }}
                  >
                    <Box className="al_center ptr" onClick={openModal}>
                      <PlayCircleFilledWhiteOutlinedIcon
                        fontSize="large"
                        className="pulse-button"
                      />
                      <Typography variant="h4" className="wh fw6 mb0" mt={2}>
                        Get started-It’s free
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={6} md={6} sm={6} xs={12}>
                <Box
                  className="checkpoints"
                  data-aos="zoom-in-up"
                  data-duration="800"
                >
                  <Box className="fx_fs" mb={2}>
                    <Box mr={1} className="fx_c">
                      <img src={Done} width={"14px"} alt="Check Icon" />
                    </Box>
                    <Box>
                      <Typography variant="h4" className="wh">
                        AI powered auto suggestions
                      </Typography>
                    </Box>
                  </Box>

                  <Box className="fx_fs" mb={2}>
                    <Box mr={1} className="fx_c">
                      <img src={Done} width={"14px"} alt="Check Icon" />
                    </Box>
                    <Box>
                      <Typography variant="h4" className="wh">
                        Set up within minutes and reconfigure
                      </Typography>
                    </Box>
                  </Box>

                  <Box className="fx_fs" mb={2}>
                    <Box mr={1} className="fx_c">
                      <img src={Done} width={"14px"} alt="Check Icon" />
                    </Box>
                    <Box>
                      <Typography variant="h4" className="wh">
                        Intuitive and user-friendly design
                      </Typography>
                    </Box>
                  </Box>

                  <Box className="fx_fs" mb={2}>
                    <Box mr={1} className="fx_c">
                      <img src={Done} width={"14px"} alt="Check Icon" />
                    </Box>
                    <Box>
                      <Typography variant="h4" className="wh">
                        Schedule auto runs with alerts and logs
                      </Typography>
                    </Box>
                  </Box>

                  <Box className="fx_fs" mb={2}>
                    <Box mr={1} className="fx_c">
                      <img src={Done} width={"14px"} alt="Check Icon" />
                    </Box>
                    <Box>
                      <Typography variant="h4" className="wh">
                        Auto detects semantic data types & changes
                      </Typography>
                    </Box>
                  </Box>

                  <Box className="fx_fs" mb={2}>
                    <Box mr={1} className="fx_c">
                      <img src={Done} width={"14px"} alt="Check Icon" />
                    </Box>
                    <Box>
                      <Typography variant="h4" className="wh">
                        Pre-built data connectors
                      </Typography>
                    </Box>
                  </Box>

                  <Box className="fx_fs" mb={2}>
                    <Box mr={1} className="fx_c">
                      <img src={Done} width={"14px"} alt="Check Icon" />
                    </Box>
                    <Box>
                      <Typography variant="h4" className="wh">
                        Manage multiple pipelines in a single platform
                      </Typography>
                    </Box>
                  </Box>
                </Box>

                <Box pt={3} data-aos="fade-up" data-duration="800">
                  <Grid
                    container
                    spacing={2}
                    alignItems="top"
                    justifyContent="flex-start"
                  >
                    <Grid item lg={9} md={9} sm={9} xs={12}>
                      <Box>
                        <Typography variant="h6" className="gry">
                          Please enter your email to access our data management
                          service
                        </Typography>
                      </Box>

                      <Box className="email_txtfield" pt={1}>
                        <TextField
                          size="small"
                          placeholder="Enter email id"
                          variant="outlined"
                          fullWidth
                          value={email}
                          onChange={handleEmailChange}
                          error={!isValidEmail(email) && email.length > 0}
                          helperText={
                            !isValidEmail(email) && email.length > 0
                              ? "Enter a valid email address"
                              : ""
                          }
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                {" "}
                                <Button
                                  variant="outlined"
                                  className="main-btn-2"
                                  disabled={
                                    !isValidEmail(email) || email.length == 0
                                  }
                                  onClick={() =>
                                    (window.location.href =
                                      process.env
                                        .REACT_APP_SMARTPIPE_REDIRECT_URL +
                                      `/signup?redirect=null&email=${email}`)
                                  }
                                >
                                  {" "}
                                  Continue{" "}
                                </Button>
                              </InputAdornment>
                            ),
                          }}
                        />
                      </Box>
                    </Grid>
                  </Grid>
                </Box>

                <Box
                  className="checkpoints"
                  mt={4}
                  data-aos="zoom-in"
                  data-duration="1200"
                >
                  <Grid
                    container
                    rowSpacing={3}
                    columnSpacing={4}
                    alignItems="center"
                    justifyContent="flex-start"
                  >
                    <Grid item lg={3} md={3} sm={4} xs={4}>
                      <Box className="al_center">
                        <Box mr={1} className="fx_c">
                          <img
                            src={Trial}
                            width={"32px"}
                            alt="14-day free trial"
                          />
                        </Box>
                        <Box pt={2}>
                          <Typography variant="h6" className="gry">
                            14-day free
                          </Typography>
                          <Typography variant="h6" className="gry">
                            trial
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>

                    <Grid item lg={3} md={3} sm={4} xs={4}>
                      <Box className="al_center">
                        <Box mr={1} className="fx_c">
                          <img
                            src={Loyal}
                            width={"32px"}
                            alt="Optimize data management"
                          />
                        </Box>
                        <Box pt={2}>
                          <Typography variant="h6" className="gry">
                            Optimize data management
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>

                    <Grid item lg={3} md={3} sm={4} xs={4}>
                      <Box className="al_center">
                        <Box mr={1} className="fx_c">
                          <img
                            src={Service}
                            width={"32px"}
                            alt="Expert guidance available"
                          />
                        </Box>
                        <Box pt={2}>
                          <Typography variant="h6" className="gry">
                            Expert guidance available
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>
                  </Grid>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>

      <ModalVideo
        channel="custom"
        isOpen={isOpen}
        url="https://smartpipe.cloud/static/media/smartpipe-demo.mp4"
        onClose={() => setIsOpen(false)}
      />
    </>
  );
};
