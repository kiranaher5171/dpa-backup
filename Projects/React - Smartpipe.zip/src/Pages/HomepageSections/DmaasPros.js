import { Box, Button, Container, Grid, Typography } from "@mui/material";
import React from "react";
import { Link } from "react-router-dom";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";

export const DmaasPros = () => {
  const scrollToElement = (id) => {
    const element = document.getElementById(id);
    if (element) {
      const stickyItemsHeight = 50;
      const offset = element.getBoundingClientRect().top - stickyItemsHeight;

      setTimeout(() => {
        window.scrollBy({ top: offset, behavior: "smooth" });
      }, 50);
    }
  };

  return (
    <>
      <Box id="dmaas-pros" className="section">
        <Container maxWidth="lg">
          <Box className="al_center" data-aos="fade-up" data-duration="1000">
            <Typography variant="h2" className="col1v2 fw7 mb0" gutterBottom>
              World’s First Data Management as a Service (DMaaS)
            </Typography>
            <Typography variant="h4" className="bl fw6" gutterBottom>
              Discover our managed services for seamless support
            </Typography>
          </Box>

          <Box pt={4}>
            <Grid
              container
              spacing={4}
              alignItems="top"
              justifyContent="center"
            >
              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box
                  className="pros-brd-bx pros-hgt"
                  data-aos="fade-up"
                  data-duration="800"
                >
                  <Typography variant="h4" className="bl fw5" gutterBottom>
                    Proactive process monitoring, issue resolution and
                    follow ups with data senders for corrections
                  </Typography>
                  <Box className="decorator">
                    <span /> <span /> <span />
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box
                  className="pros-brd-bx pros-hgt"
                  data-aos="fade-up"
                  data-duration="800"
                >
                  <Typography variant="h4" className="bl fw5" gutterBottom>
                    Complete management of data pipelines from set up
                    to maintenance
                  </Typography>
                  <Box className="decorator">
                    <span /> <span /> <span />
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box
                  className="pros-brd-bx pros-hgt"
                  data-aos="fade-up"
                  data-duration="800"
                >
                  <Typography variant="h4" className="bl fw5" gutterBottom>
                    Comprehensive data pipeline management and issue resolution
                  </Typography>
                  <Box className="decorator">
                    <span /> <span /> <span />
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box
                  className="pros-brd-bx pros-hgt"
                  data-aos="fade-up"
                  data-duration="800"
                >
                  <Typography variant="h4" className="bl fw5" gutterBottom>
                    Delegate new data needs hassle-free
                  </Typography>
                  <Box className="decorator">
                    <span /> <span /> <span />
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box
                  className="pros-brd-bx pros-hgt"
                  data-aos="fade-up"
                  data-duration="800"
                >
                  <Typography variant="h4" className="bl fw5" gutterBottom>
                    Analyst oversight prevents data loss and delays
                  </Typography>
                  <Box className="decorator">
                    <span /> <span /> <span />
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box
                  className="pros-hgt"
                  data-aos="fade-up"
                  data-duration="800"
                >
                  <Box>
                    <Button
                      variant="text"
                      className="txt-btn"
                      disableRipple
                      endIcon={<ArrowForwardIosIcon />}
                      onClick={() => scrollToElement("get-in-touch")}
                    >
                      {" "}
                      Contact us
                    </Button>
                  </Box>
                  <Box className="">
                    <Typography variant="h5" className="gry fw6" gutterBottom>
                      Want to learn more about data management & pipeline{" "}
                      <Link to="/resources" className="col1">
                        {" "}
                        click here{" "}
                      </Link>
                    </Typography>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>
    </>
  );
};
