import {
  Box,
  Container,
  Grid,
  TextField,
  Typography,
  InputAdornment,
  Stack,
  Button,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import SearchIcon from "@mui/icons-material/Search";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import FAQ from "../Assets/Images/faq.png";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
// import ConnectorsFaq from './ConnectorsPages/ConnectorsFaq';

import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";

import AWS from "../Assets/Images/connectors/aws.png";
import SnowFlake from "../Assets/Images/connectors/snowflake.png";
import Salesforce from "../Assets/Images/connectors/salesforce.png";
import FTP from "../Assets/Images/connectors/ftp.png";
import SFTP from "../Assets/Images/connectors/sftp.png";
import Oracle from "../Assets/Images/connectors/oracledb.png";
import Mongo from "../Assets/Images/connectors/mongo.png";
import Postgre from "../Assets/Images/connectors/postgre-sql.png";
import OOS from "../Assets/Images/connectors/oracleobjectstorage.png";
import MsSQL from "../Assets/Images/connectors/mssql.png";
import MYSQL from "../Assets/Images/connectors/mysql.png";
import Dropbox from "../Assets/Images/connectors/dropbox.png";
import API from "../Assets/Images/connectors/api.png";
import GCS from "../Assets/Images/connectors/googlecloudstorage.png";
import GD from "../Assets/Images/connectors/google-drive.png";
import GS from "../Assets/Images/connectors/google-sheet.png";
import GBQ from "../Assets/Images/connectors/googlebigquery.png";
import Azure from "../Assets/Images/connectors/azure-blob.png";
import Citrix from "../Assets/Images/connectors/citrix-sharefile.png";
import Cockroach from "../Assets/Images/connectors/cockroachdb.png";
import Maria from "../Assets/Images/connectors/mariadb.png";
import Sharepoint from "../Assets/Images/connectors/sharepoint.png";
import OneDrive from "../Assets/Images/connectors/onedrive.png";
import UploadFile from "../Assets/Images/connectors/upload-file.png";
import Email from "../Assets/Images/connectors/email.png";
import BoxC from "../Assets/Images/connectors/box.png";
import OracleATP from "../Assets/Images/connectors/oracle-atp.png";

const connectorData = [
  { plan: "Free", name: "AWS S3", type: "storage", image: AWS },
  { plan: "Free", name: "Google Drive", type: "storage", image: GD },
  { plan: "Premium", name: "Salesforce", type: "custom", image: Salesforce },
  { plan: "Premium", name: "Azure Blob", type: "storage", image: Azure },
  { plan: "Free", name: "MsSQL", type: "database", image: MsSQL },

  { plan: "Free", name: "MYSQL", type: "database", image: MYSQL },
  { plan: "Free", name: "Oracle DB", type: "database", image: Oracle },
  { plan: "Free", name: "Mongo-DB", type: "database", image: Mongo },
  { plan: "Free", name: "Postgre-SQL", type: "database", image: Postgre },
  { plan: "Free", name: "Snowflake", type: "database", image: SnowFlake },
  { plan: "Free", name: "Google Big Query", type: "database", image: GBQ },
  { plan: "Free", name: "Oracle Object Storage", type: "storage", image: OOS },
  { plan: "Free", name: "Google Cloud Storage", type: "storage", image: GCS },
  { plan: "Free", name: "FTP", type: "storage", image: FTP },
  { plan: "Free", name: "SFTP", type: "storage", image: SFTP },
  { plan: "Free", name: "Share Point", type: "storage", image: Sharepoint },
  { plan: "Free", name: "One Drive", type: "storage", image: OneDrive },
  { plan: "Free", name: "Uploadfile", type: "storage", image: UploadFile },
  { plan: "Premium", name: "Email", type: "custom", image: Email },
  { plan: "Free", name: "Dropbox", type: "storage", image: Dropbox },
  { plan: "Free", name: "Google Sheet", type: "storage", image: GS },
  { plan: "Free", name: "API", type: "custom", image: API },
  { plan: "Free", name: "Citrix Sharefile", type: "storage", image: Citrix },
  { plan: "Free", name: "Mariadb", type: "database", image: Maria },
  { plan: "Free", name: "Cockroach", type: "database", image: Cockroach },
  { plan: "Free", name: "Box", type: "storage", image: BoxC },
  { plan: "Free", name: "Oracle ATP", type: "database", image: OracleATP },
  // { plan: "Premium", name: "HtmlTable", type: "custom", image: Common },
];

export const Connectors = () => {
  const [open, setOpen] = React.useState(false);

  const [searchText, setSearchText] = React.useState("");

  const handleSearchChange = (event) => {
    setSearchText(event.target.value);
  };
  const [filter, setFilter] = useState({
    all: true,
    database: false,
    storage: false,
    custom: false,
  });

  const filteredConnectors = connectorData.filter((connector) => {
    const isNameMatch = connector.name
      .toLowerCase()
      .includes(searchText.toLowerCase());
    const isTypeMatch = filter[connector.type];
    const isAllChecked = filter.all;

    if (isAllChecked) {
      return isNameMatch;
    } else {
      return isNameMatch && isTypeMatch;
    }
  });
  useEffect(() => {
    if (!filter.custom && !filter.storage && !filter.database)
      setFilter((prevFilter) => ({
        ...prevFilter,
        ["all"]: true,
      }));
  }, [filter]);

  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    console.log(name, checked, "hii");
    if (name !== "all") {
      if (checked)
        setFilter((prevFilter) => ({
          ...prevFilter,
          ["all"]: false,
          [name]: checked,
        }));
      else {
        setFilter((prevFilter) => ({
          ...prevFilter,
          [name]: checked,
        }));
      }
    } else
      setFilter((prevFilter) => ({
        ...prevFilter,
        [name]: true,
        database: false,
        storage: false,
        custom: false,
      }));
  };

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const [open2, setOpen2] = React.useState(false);
  const handleClickOpen2 = () => {
    setOpen(false);
    setOpen2(true);
    setTimeout(() => {
      setOpen2(false);
    }, 3000);
  };
  const handleClose2 = () => {
    setOpen2(false);
  };

  const scrollToElement = (id) => {
    const element = document.getElementById(id);
    if (element) {
      const stickyItemsHeight = 0;
      const offset = element.getBoundingClientRect().top - stickyItemsHeight;

      setTimeout(() => {
        window.scrollBy({ top: offset, behavior: "smooth" });
      }, 5000);
    }
  };

  return (
    <>
      {/* sticky container section */}
      <Box id="connectors" className="sticky-nav">
        <Container maxWidth="lg">
          <Box className="al_center">
            <Typography variant="h5" className="dgry fw4" gutterBottom>
              Unlock exclusive features that set our data management platform
              apart from the rest
              <a
                href="https://app.smartpipe.cloud/"
                className="col1 fw5"
                rel="noopener noreferrer"
              >
                <u> Get started - It’s free </u>
              </a>
            </Typography>
          </Box>
        </Container>
      </Box>
      {/* sticky container section */}

      {/* Connectors Page Heading section */}
      <Box id="connectors" className="section">
        <Container maxWidth="lg">
          <Box className="al_center">
            <Typography variant="h2" className="col1v2 fw7 mb0" gutterBottom>
              Seamlessly incorporate data from all your various sources
            </Typography>
            <Typography variant="h4" className="dgry fw6" gutterBottom>
              SMARTPiPE offers a comprehensive library of connectors spanning
              applications, databases, file systems, and more...
            </Typography>
          </Box>
        </Container>
      </Box>
      {/* Connectors Page Heading section */}

      {/* Connectors section */}
      <Box id="connectors" className="section">
        <Container maxWidth="lg">
          <Box>
            <Grid
              container
              rowSpacing={1}
              alignItems="center"
              justifyContent="space-between"
            >
              <Grid item lg={4} md={6} sm={12} xs={12}>
                <Box className="email_txtfield" pt={1} pb={1}>
                  <TextField
                    size="small"
                    placeholder="Search by connector name or type"
                    variant="outlined"
                    fullWidth
                    value={searchText}
                    onChange={handleSearchChange}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          {" "}
                          <SearchIcon className="col1" />{" "}
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
              </Grid>
              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box className="al_center checkboxes" pt={1} pb={1}>
                  <Stack direction="row" justifyContent="flex-end" spacing={2}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="all"
                          checked={filter.all}
                          onChange={handleCheckboxChange}
                        />
                      }
                      label="All"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="database"
                          checked={filter.database}
                          onChange={handleCheckboxChange}
                        />
                      }
                      label="Database"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="storage"
                          checked={filter.storage}
                          onChange={handleCheckboxChange}
                        />
                      }
                      label="File Storage"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="custom"
                          checked={filter.custom}
                          onChange={handleCheckboxChange}
                        />
                      }
                      label="Apps/Services"
                    />
                  </Stack>
                </Box>
              </Grid>
              <Grid item lg={6} md={6} sm={12} xs={12}>
                <Box className="al_left">
                  <Typography variant="h5" className="bl fw6" gutterBottom>
                    Unable to locate your desired connector integration?{" "}
                    <Link to="#" className="col1" onClick={handleClickOpen}>
                      {" "}
                      click here{" "}
                    </Link>
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </Box>
          <Box pt={6}>
            <Grid
              container
              rowSpacing={{ xs: 2, sm: 2, md: 4 }}
              columnSpacing={{ xs: 2, sm: 2, md: 6 }}
              alignItems="top"
              justifyContent="flex-start"
            >
              {filteredConnectors.map((connector, index) => (
                <Grid item lg={3} md={3} sm={4} xs={6} key={index}>
                  <Box className="connector_bx">
                    <Box className={`plan ${connector.plan.toLowerCase()}`}>
                      <Typography variant="h6" className="fw6">
                        {connector.plan}
                      </Typography>
                    </Box>
                    <img
                      src={connector.image}
                      alt={`${connector.name} Connector`}
                    />
                    <Box pt={2}>
                      <Typography variant="h5" className="fw6 bl">
                        {connector.name}
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Box>
        </Container>
      </Box>
      {/* Connectors section */}

      {/* FAQ section */}
      <Box id="connectors" className="section">
        <Box id="faq">
          <Container maxWidth="lg">
            <Box className="faq-bg-bx">
              <Grid container alignItems="top" justifyContent="center">
                <Grid
                  item
                  lg={4}
                  md={4}
                  sm={12}
                  xs={12}
                  className="contact-side-img"
                  style={{ backgroundImage: "url(" + FAQ + ")" }}
                />
                <Grid item lg={8} md={8} sm={12} xs={12}>
                  <Box className="contact-formbx">
                    <Box className="al_left">
                      <Typography
                        variant="h2"
                        className="col1v2 fw7 mb0"
                        gutterBottom
                      >
                        Find the answers you need
                      </Typography>
                    </Box>

                    <Box className="al_left">
                      <Typography
                        variant="h5"
                        className="dgry fw4"
                        gutterBottom
                      >
                        Want to learn more about data management & data
                        pipelines{" "}
                        <Link to="/resources" className="col1">
                          {" "}
                          click here{" "}
                        </Link>
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Container>
        </Box>
      </Box>
      {/* FAQ section */}

      {/* Reach us out section */}
      <Box id="connectors" className="section">
        <Container maxWidth="lg">
          <Box>
            <Grid
              container
              rowSpacing={4}
              columnSpacing={4}
              alignItems="top"
              justifyContent="center"
            >
              <Grid item lg={10} md={10} sm={11} xs={12}>
                <Box>
                  <Box className="al_center" pb={2}>
                    {/* <Typography variant='h3' className="col1v2 fw7" gutterBottom> */}
                    <Typography
                      variant="h2"
                      className="col1v2 fw7"
                      gutterBottom
                    >
                      Feel free to reach out to us at your convenience, and
                      we'll be happy to assist you with scheduling a demo
                    </Typography>

                    <Typography variant="h4" className="bl fw6" gutterBottom>
                      Discover our managed services for seamless support
                    </Typography>
                  </Box>
                  <Box className="al_center" mt={1}>
                    <Stack direction="row" spacing={2} justifyContent="center">
                      <Link to="/schedule-a-demo">
                        <Button variant="outlined" className="main-btn-3">
                          {" "}
                          Schedule a demo{" "}
                        </Button>
                      </Link>

                      {/* <Link to="/#get-in-touch" onClick={() => scrollToElement('get-in-touch')}> */}
                      <Link
                        to="/#get-in-touch"
                        onClick={() => scrollToElement("get-in-touch")}
                      >
                        <Button variant="outlined" className="main-btn-2">
                          {" "}
                          Contact us{" "}
                        </Button>
                      </Link>
                    </Stack>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Container>
      </Box>
      {/* Reach us out section */}

      {/* Unable to locate connector dialog */}
      <Dialog
        fullWidth={true}
        maxWidth={"xs"}
        open={open}
        onClose={handleClose}
      >
        <DialogTitle>
          <Typography variant="h3" className="bl fw6">
            Unable to locate your desired connector integration?
          </Typography>
        </DialogTitle>

        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: "#000",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          <DialogContentText>
            <Box>
              <Grid
                container
                rowSpacing={2}
                columnSpacing={2}
                alignItems="top"
                justifyContent="flex-start"
              >
                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className="ol_txtfield">
                    <Typography variant="h6" className="bl fw5" gutterBottom>
                      Name of connector
                    </Typography>
                    <TextField
                      id="filled-basic"
                      className="filleddp"
                      variant="outlined"
                      placeholder="Enter name of connector"
                      fullWidth
                    />
                  </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className="ol_txtfield" pt={1}>
                    <Typography variant="h6" className="bl fw5" gutterBottom>
                      Email id
                    </Typography>
                    <TextField
                      id="filled-basic"
                      className="filleddp"
                      variant="outlined"
                      placeholder="Enter your email id"
                      fullWidth
                    />
                  </Box>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={6}>
                  <Box pt={2} mr={1}>
                    <Button
                      variant="outlined"
                      className="main-btn-3"
                      fullWidth
                      onClick={handleClose}
                    >
                      {" "}
                      Cancel{" "}
                    </Button>
                  </Box>
                </Grid>

                <Grid item lg={6} md={6} sm={6} xs={6}>
                  <Box pt={2} ml={1}>
                    <Button
                      variant="outlined"
                      className="main-btn-2"
                      fullWidth
                      onClick={handleClickOpen2}
                    >
                      {" "}
                      Submit{" "}
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      {/* Unable to locate connector dialog */}

      {/* Request recieved dialog */}
      <Dialog
        fullWidth={true}
        maxWidth={"xs"}
        open={open2}
        onClose={handleClose2}
      >
        <DialogContent>
          <DialogContentText>
            <Box>
              <Grid
                container
                rowSpacing={2}
                columnSpacing={2}
                alignItems="top"
                justifyContent="flex-start"
              >
                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className="al_center" pt={1}>
                    <CheckCircleIcon
                      sx={{ color: "#1dd882", fontSize: "45px" }}
                    />
                  </Box>

                  <Box className="al_center" pt={1}>
                    <Typography variant="h4" className="dgry fw5" gutterBottom>
                      Your request has been received, and we will promptly
                      notify you of any updates.
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      {/* Request recieved dialog */}
    </>
  );
};
