import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { Link } from 'react-router-dom';
import EastIcon from '@mui/icons-material/East';
import { Button } from '@mui/material';

export default function ConnectorsFaq() {
  const [expanded, setExpanded] = React.useState('panel1');

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  return (
    <>
      <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography variant='h5' className='col2 fw6'>
            What is connectors?
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography variant='h6' className='dgry fw4 three'>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500ss  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500ss
          </Typography>

          <Link to="#">
            <Button variant='text' className='learn-more' disableRipple>
              Learn More
            </Button>
          </Link>

        </AccordionDetails>
      </Accordion>

      <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >
          <Typography variant='h5' className='col2 fw6'>
            What SMARTPiPE do?
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography variant='h6' className='dgry fw4 three'>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500ss
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500ss
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500ss
          </Typography>

          <Link to="#">
            <Button variant='text' className='learn-more' disableRipple>
              Learn More
            </Button>
          </Link>

        </AccordionDetails>
      </Accordion>

      <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3bh-content"
          id="panel3bh-header"
        >
          <Typography variant='h5' className='col2 fw6'>
            How SMARTPiPE works?
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography variant='h6' className='dgry fw4 three'>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500ss Lorem Ipsum has been the industry's standard dummy text ever since the 1500ss
          </Typography>

          <Link to="#">
            <Button variant='text' className='learn-more' disableRipple>
              Learn More
            </Button>
          </Link>
        </AccordionDetails>
      </Accordion>
    </>
  );
}