import React, { useState } from "react";
import {
  Typography,
  Paper,
  Box,
  Container,
  Grid,
  Button,
  IconButton,
} from "@mui/material";

import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Switch,
} from "@mui/material";

import ic1 from "../Assets/Images/pricing/free.svg";
import ic2 from "../Assets/Images/pricing/personal.svg";
import ic3 from "../Assets/Images/pricing/business.svg";
import CheckIcon from "@mui/icons-material/Check";
import HorizontalRuleIcon from "@mui/icons-material/HorizontalRule";
import { Tooltip } from "@mui/material";
import { LoadingButton } from "@mui/lab";
import { Info } from "@mui/icons-material";

// const paddleEnvironment = process.env.NEXT_PUBLIC_PADDLE_ENV;
const redirectUrl = process.env.REACT_APP_SMARTPIPE_REDIRECT_URL;
const Pricing = ({ setSnackState }) => {
  const plans = {
    Free: {
      plan_code: "PLN000",
      plan_description: "Free plan",
      usage_price: 0,
      flat_record: 0.2,
      usage_record: 0.0,
      pipelines: "10",
      pipeline_runs: "10/pipe/month",
      member: "",
      monthly_limited_price: 0,
      monthly_regular_price: 0,
      annual_limited_price: 0,
      annual_regular_price: 0,
      unlimited_validations: true,
      global_email_support: true,
      live_chat_support: false,
      managed_service_support: false,
      premium_connectors: false,
    },
    Managed: {
      plan_code: "PLN002",
      plan_description: "Let us manage it for you!",
      usage_price: 50,
      flat_record: 3.0,
      usage_record: 1e-5,
      pipelines: "Unlimited",
      pipeline_runs: "Unlimited",
      member: "Unlimited",
      monthly_limited_price: 599,
      monthly_regular_price: 749,
      annual_limited_price: 539,
      annual_regular_price: 674,
      unlimited_validations: true,
      global_email_support: true,
      live_chat_support: true,
      managed_service_support: true,
      premium_connectors: true,
    },
    Standard: {
      plan_code: "PLN001",
      plan_description: "Larger Workloads",
      usage_price: 10,
      flat_record: 3.0,
      usage_record: 1e-5,
      pipelines: "Unlimited",
      pipeline_runs: "Unlimited",
      member: "Unlimited",
      monthly_limited_price: 249,
      monthly_regular_price: 279,
      annual_limited_price: 224,
      annual_regular_price: 251,
      unlimited_validations: true,
      global_email_support: true,
      live_chat_support: true,
      managed_service_support: false,
      premium_connectors: true,
    },
  };
  const [isLoading, setLoading] = useState(false);

  const [openPaymentSwitchCasesModal, setOpenPaymentSwitchCasesModal] =
    useState(false);
  const [currentCase, setCurrentCase] = useState("");
  const [caseModule, setCaseModule] = useState("");

  const [yearly, setYearly] = useState(true);

  const handle = async (e) => {
    window.location.href = process.env.REACT_APP_SMARTPIPE_REDIRECT_URL;
  };

  const handleSwitchPlan = (e) => {
    setYearly(e.target.checked);
    setCaseModule("commitment");
    if (e.target.checked) {
      setCurrentCase("monthlyToAnnual");
    } else {
      setCurrentCase("annualToMonthly");
    }
    setOpenPaymentSwitchCasesModal(true);
  };

  const planIcon = (isIncluded) => {
    return isIncluded ? (
      <CheckIcon className="check-ico" />
    ) : (
      <HorizontalRuleIcon className="dash-ico" />
    );
  };

  function formatNumberWithCommas(value) {
    return value.toLocaleString("en-US");
  }

  return (
    <>
      <Box id="pricing" className="topsection" component="section">
        <Container maxWidth="lg" fixed={true}>
          {" "}
          <Box className="codingpagestart  pb" component="section" mb={1}>
            <Grid
              container
              spacing={2}
              alignItems="center"
              justifyContent="center"
            >
              <Grid item lg={8} md={7} sm={12} xs={12}>
                <Box className="alltxfield al_left" mt={2}>
                  <Typography variant="h3" className="col2 fw7">
                    Choose the plan that's right for your business
                  </Typography>
                </Box>
              </Grid>

              <Grid item lg={4} md={5} sm={12} xs={12}>
                <Box className="al_right" mt={2}>
                  <div style={{ fontSize: "12px", fontWeight: 500 }}>
                    Monthly Commitment
                    <Switch
                      checked={yearly}
                      onChange={handleSwitchPlan}
                      className="switch"
                    />
                    Annual Commitment* (Save 10%)
                  </div>
                </Box>
              </Grid>
            </Grid>
          </Box>
          <TableContainer className="premium_head" component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell className="firstrow"></TableCell>
                  <TableCell className="threerow tbh">Free</TableCell>
                  <TableCell className="threerow tbh">Standard</TableCell>
                  <TableCell className="threerow tbh">
                    Managed Service
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell align="center"></TableCell>
                  <TableCell align="center">
                    <img src={ic1} className="mid_ic" alt="Free Plan" />
                  </TableCell>
                  <TableCell align="center">
                    <img src={ic2} className="mid_ic" alt="Premium Plan" />
                  </TableCell>
                  <TableCell align="center">
                    <img src={ic3} className="mid_ic" alt="Free Plan" />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell></TableCell>
                  <TableCell align="center" className="grt">
                    <Typography className="tpgi">Free Forever</Typography>
                  </TableCell>

                  <TableCell align="center" className="">
                    <Typography className="tpgi">
                      Start Your Free Trial <br />$
                      {yearly
                        ? plans?.Standard?.annual_limited_price
                        : plans?.Standard?.monthly_limited_price}
                      /month
                    </Typography>
                  </TableCell>

                  <TableCell align="center" className="grt">
                    <Typography className="tpgi">
                      $
                      {yearly
                        ? plans?.Managed?.annual_limited_price
                        : plans?.Managed?.monthly_limited_price}
                      /month
                    </Typography>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell align="center" className=""></TableCell>
                  <TableCell align="center" className="">
                    <Button
                      variant="contained"
                      color="primary"
                      className="main-btn-2"
                      size="small"
                      onClick={(e) => handle(e)}
                      name="Free"
                    >
                      {"Get Started"}
                    </Button>
                  </TableCell>
                  <TableCell align="center" className="">
                    {yearly && (
                      <LoadingButton
                        loading={isLoading}
                        variant="contained"
                        data-plan={"standard"}
                        data-plancode={plans?.Standard?.plan_code}
                        onClick={handle}
                        color="primary"
                        className="main-btn-2"
                        size="small"
                        name="Standard"
                      >
                        {"Start your 14-day Free Trial"}
                      </LoadingButton>
                    )}
                    {!yearly && (
                      <LoadingButton
                        loading={isLoading}
                        variant="contained"
                        data-plan={"standard"}
                        data-plancode={plans?.Standard?.plan_code}
                        onClick={handle}
                        color="primary"
                        className="main-btn-2"
                        size="small"
                        name="Standard"
                      >
                        {"Start your 14-day Free Trial"}
                      </LoadingButton>
                    )}
                  </TableCell>
                  <TableCell align="center" className="">
                    {yearly && (
                      <LoadingButton
                        variant="contained"
                        onClick={handle}
                        data-plan={"managed"}
                        data-plancode={plans?.Managed?.plan_code}
                        color="primary"
                        className="main-btn-2"
                        size="small"
                        name="Managed"
                      >
                        {"Get Started"}
                      </LoadingButton>
                    )}
                    {!yearly && (
                      <LoadingButton
                        variant="contained"
                        onClick={handle}
                        data-plan={"managed"}
                        data-plancode={plans?.Managed?.plan_code}
                        color="primary"
                        className="main-btn-2"
                        size="small"
                        name="Managed"
                      >
                        {"Get Started"}
                      </LoadingButton>
                    )}
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell></TableCell>
                  <TableCell align="center" className="grt">
                    <Typography
                      className="bannerhead4"
                      style={{ margin: "10px" }}
                    >
                      No credit card required
                    </Typography>
                  </TableCell>
                  <TableCell align="center" className="grt">
                    <Typography
                      className="bannerhead4"
                      style={{ margin: "10px" }}
                    >
                      {`Limited time offer; thereafter $${
                        yearly
                          ? plans?.Standard?.annual_regular_price
                          : plans?.Standard?.monthly_regular_price
                      }`}
                    </Typography>
                  </TableCell>
                  <TableCell align="center" className="grt">
                    <Typography
                      className="bannerhead4"
                      style={{ margin: "10px" }}
                    >
                      {`Limited time offer; thereafter $${
                        yearly
                          ? plans?.Managed?.annual_regular_price
                          : plans?.Managed?.monthly_regular_price
                      }`}
                    </Typography>
                  </TableCell>
                </TableRow>

                <TableRow className="sm_pd">
                  <TableCell>Features</TableCell>
                  <TableCell align="center">
                    {plans?.Free?.plan_description}
                  </TableCell>
                  <TableCell align="center">
                    {plans?.Standard?.plan_description}
                  </TableCell>
                  <TableCell align="center">
                    {plans?.Managed?.plan_description}
                  </TableCell>
                </TableRow>

                <TableRow className="mk_pd">
                  <TableCell className="wht">
                    Rows processed/month
                    <Tooltip title="Total number of rows successfully loaded to destination.">
                      <IconButton>
                        <Info fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                  <TableCell align="center" className="wht">
                    {formatNumberWithCommas(plans?.Free?.flat_record * 1000000)}
                  </TableCell>
                  <TableCell align="center" className=" wht">
                    {formatNumberWithCommas(
                      plans?.Standard?.flat_record * 1000000
                    )}
                  </TableCell>
                  <TableCell align="center" className=" wht">
                    {formatNumberWithCommas(
                      plans?.Managed?.flat_record * 1000000
                    )}
                  </TableCell>
                </TableRow>

                <TableRow className="mk_pd">
                  <TableCell className="">
                    Per additional one million rows
                  </TableCell>
                  <TableCell align="center">
                    {planIcon(plans?.Free?.usage_price)}
                  </TableCell>
                  <TableCell align="center" className="">
                    ${plans?.Standard?.usage_price}
                  </TableCell>
                  <TableCell align="center" className="">
                    ${plans?.Managed?.usage_price}
                  </TableCell>
                </TableRow>

                <TableRow className="mk_pd">
                  <TableCell className=" wht">Pipelines</TableCell>
                  <TableCell align="center" className=" wht">
                    {plans?.Free?.pipelines}
                  </TableCell>
                  <TableCell align="center" className=" wht">
                    {plans?.Standard?.pipelines}
                  </TableCell>
                  <TableCell align="center" className=" wht">
                    {plans?.Managed?.pipelines}
                  </TableCell>
                </TableRow>

                <TableRow className="mk_pd">
                  <TableCell className="">Pipeline Runs</TableCell>
                  <TableCell align="center" className="">
                    {plans?.Free?.pipeline_runs}
                  </TableCell>
                  <TableCell align="center">
                    {plans?.Standard?.pipeline_runs}
                  </TableCell>
                  <TableCell align="center">
                    {plans?.Managed?.pipeline_runs}
                  </TableCell>
                </TableRow>
                <TableRow className="mk_pd wht">
                  <TableCell className="wht">Manage Team (Users)</TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Free?.member)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {plans?.Standard?.member}
                  </TableCell>
                  <TableCell align="center" className="">
                    {plans?.Managed?.member}
                  </TableCell>
                </TableRow>

                <TableRow className="mk_pd">
                  <TableCell className="">Unlimited Validations</TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Free?.unlimited_validations)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Standard?.unlimited_validations)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Managed?.unlimited_validations)}
                  </TableCell>
                </TableRow>

                <TableRow className="mk_pd wht">
                  <TableCell className="wht">Contact Form Support</TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Free?.global_email_support)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Standard?.global_email_support)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Managed?.global_email_support)}
                  </TableCell>
                </TableRow>

                <TableRow className="mk_pd">
                  <TableCell>Live Chat Support</TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Free?.live_chat_support)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Standard?.live_chat_support)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Managed?.live_chat_support)}
                  </TableCell>
                </TableRow>
                <TableRow className="mk_pd wht">
                  <TableCell className="">Managed Service Support</TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Free?.managed_service_support)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Standard?.managed_service_support)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Managed?.managed_service_support)}
                  </TableCell>
                </TableRow>
                <TableRow className="mk_pd ">
                  <TableCell>Standard Connectors</TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Free?.premium_connectors)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Standard?.premium_connectors)}
                  </TableCell>
                  <TableCell align="center" className="">
                    {planIcon(plans?.Managed?.premium_connectors)}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
          <Box className="bt_button al_left" mt={2} component="section">
            <Typography style={{ fontSize: 11 }}>
              <b>*Billed Monthly</b>
            </Typography>
            <Typography style={{ fontSize: 11 }}>
              <b>All plans and pricing are subject to change</b>
            </Typography>
          </Box>
        </Container>
      </Box>
    </>
  );
};

export default Pricing;
