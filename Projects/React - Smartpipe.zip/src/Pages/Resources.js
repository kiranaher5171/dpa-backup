import React from "react";
import { Box, Container, Typography } from "@mui/material";

export const Resources = () => {
  return (
    <>
      {/* Schedule a Demo Page */}
      <Box className="topsection">
        <Container style={{ maxWidth: "92%" }}>
          <Box className="al_center relative">
            <Typography variant="h2" className="col1v2 fw7 mb0" gutterBottom>
              Comprehensive Documentation Hub
            </Typography>
            <Typography variant="h4" className="dgry fw6" gutterBottom>
              Your One-Stop Resource for Product Information and FAQs
            </Typography>
          </Box>

          <Box className="doc-iframe" mt={4}>
            <iframe
              title="Smartpipe Documentation"
              src="https://doc.clickup.com/43202154/d/h/196dka-20964/6695698889ca6be"
              width={"2000px"}
              height={"120%"}
              frameborder="0"
            />
          </Box>
        </Container>
      </Box>
      {/* Schedule a Demo Page */}
    </>
  );
};
