import { Box, Container, Grid, Typography, Divider } from "@mui/material";
import React from "react";

import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";

import LanguageIcon from "@mui/icons-material/Language";
import DataUsageIcon from "@mui/icons-material/DataUsage";
import VerifiedUserIcon from "@mui/icons-material/VerifiedUser";
import LinkedInIcon from "@mui/icons-material/LinkedIn";

import splogo from "../Assets/Images/about/smartpipe_logo.png";
import dpalogo from "../Assets/Images/about/dpalogo.svg";
import sd from "../Assets/Images/about/shailesh_dhuri.jpg";
import ps from "../Assets/Images/about/paresh_sharma.jpg";
import rr from "../Assets/Images/about/ronen_rub.png";
import r2logo from "../Assets/Images/about/r2.svg";
import r2logosm from "../Assets/Images/about/r2logosm.png";
import dpalogosm from "../Assets/Images/about/dpalogosm.png";

export const AboutUs = () => {
  const [open1, setOpen1] = React.useState(false);
  const handleClickOpen1 = () => {
    setOpen1(true);
  };
  const handleClose1 = () => {
    setOpen1(false);
  };

  const [open2, setOpen2] = React.useState(false);
  const handleClickOpen2 = () => {
    setOpen2(true);
  };
  const handleClose2 = () => {
    setOpen2(false);
  };

  const [open3, setOpen3] = React.useState(false);
  const handleClickOpen3 = () => {
    setOpen3(true);
  };
  const handleClose3 = () => {
    setOpen3(false);
  };

  return (
    <>
      <Box id="about-us">
        {/* sticky container section */}
        <Box className="section bg1" component="section" mt={"50px"}>
          <Container maxWidth="lg" className="bdr">
            <Grid container spacing={1} alignItems="center">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="al_center ">
                  <Typography variant="h2" className="wh fw7" gutterBottom>
                    About Us
                  </Typography>

                  <Typography variant="h4" className="wh">
                    Introducing Data Management as a Service (DMaaS)
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>
        {/* sticky container section */}

        <Box
          className="mainsection d-bg"
          id="manage"
          component="section"
          py={"4%"}
        >
          <Container maxWidth="lg">
            <Grid container spacing={1} alignItems="center">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="mob_mt30 al_center mobcenter" mb={3}>
                  <Typography className="bannerhead_a1 ">
                    Revolutionizing Data Management with{" "}
                    <span className="smart">SMART</span>
                    <span className="pipe">PiPE</span>
                  </Typography>
                </Box>
              </Grid>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Typography className="pagecontent jst">
                  Welcome to <span className="smart">SMART</span>
                  <span className="pipe">PiPE</span>, the world's first and only
                  managed service for data pipelines. Our team combines
                  expertise in data management and machine learning with a
                  commitment to excellent customer service to simplify how
                  companies manage their data.
                </Typography>
              </Grid>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Divider />
              </Grid>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box mb={1} mt={1}>
                  <Typography variant="h6" className="bannersubhead1 jst col1">
                    Data Management as a Service (DMaaS)
                  </Typography>
                </Box>
              </Grid>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Typography className="pagecontent jst">
                  {" "}
                  At <span className="smart">SMART</span>
                  <span className="pipe">PiPE</span> , we understand the
                  difficulties businesses encounter when managing their data.
                  That's why we offer a comprehensive, end-to-end solution that
                  boasts enterprise-grade quality, eliminating the downsides of
                  existing tools such as long setup times, difficult set up and
                  maintenance, and technical skill requirements. Additionally,
                  we cut the costs and complexity associated with building it
                  in-house. Our managed service option is a unique and valuable
                  proposition, where we take on the responsibility of managing
                  your data pipelines from start to finish, including follow-ups
                  with data vendors and sending counterparties. We can handle
                  the minutia of changes and validations in your pipelines. This
                  enables you to focus on more critical areas of your business.{" "}
                </Typography>
              </Grid>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Typography className="pagecontent jst">
                  For those who prefer a self-service option, our data pipeline
                  solution includes advanced features such as cleaning,
                  validation, and scheduling. Our pipes are engineered to be
                  highly automated, minimizing set-up time and effort and with
                  no coding required. We use intelligent algorithms and machine
                  learning to resolve complex data issues, giving you peace of
                  mind and confidence in your data.
                </Typography>
              </Grid>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Divider />
              </Grid>

              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="jst">
                  <Typography variant="h6" className="bannersubhead1 col1">
                    Choose <span className="smart">SMART</span>
                    <span className="pipe">PiPE</span> for a hassle-free data
                    management experience with the added convenience of a
                    managed service
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>

        <Box className="section sec_bg" component="section" mt={"1%"}>
          <Container maxWidth="lg" className="bdr">
            <Grid container spacing={1} alignItems="top">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="al_center" mb={1}>
                  <Typography variant="h2" className="blue bannerhead_a1">
                    Our Vision
                  </Typography>
                </Box>
              </Grid>
            </Grid>

            <Box mt={3}>
              <Grid container spacing={3} alignItems="top">
                <Grid item lg={4} md={4} sm={6} xs={12}>
                  <Box className="str_bg">
                    <Box>
                      <Box mb={1}>
                        <IconButton disabled>
                          <LanguageIcon className="col1 vision_ico" />
                        </IconButton>
                      </Box>
                      <Typography
                        variant="h4"
                        className="blue al_center pagecontent"
                      >
                        At <span className="smart">SMART</span>
                        <span className="pipe">PiPE</span> , our vision is to
                        become the go-to service for any data management need
                      </Typography>
                    </Box>
                  </Box>
                </Grid>

                <Grid item lg={4} md={4} sm={6} xs={12}>
                  <Box className="str_bg">
                    <Box>
                      <Box mb={1}>
                        <IconButton disabled>
                          <DataUsageIcon className="col1 vision_ico" />
                        </IconButton>
                      </Box>

                      <Typography
                        variant="h4"
                        className="blue al_center pagecontent"
                      >
                        We are committed to building "SMART" pipes that can
                        learn from data and adapt to new challenges
                      </Typography>
                    </Box>
                  </Box>
                </Grid>

                <Grid item lg={4} md={4} sm={6} xs={12}>
                  <Box className="str_bg mnhg1">
                    <Box>
                      <Box mb={1}>
                        <IconButton disabled>
                          <VerifiedUserIcon className="col1 vision_ico" />
                        </IconButton>
                      </Box>

                      <Typography
                        variant="h4"
                        className="blue al_center pagecontent"
                      >
                        We prioritize a world-class product design and user
                        experience for both business and technical users
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Container>
        </Box>

        <Box className="section d-bg" component="section">
          <Container maxWidth="lg" className="bdr">
            <Grid item lg={12} md={12} sm={12} xs={12}>
              <Box className="al_center" mb={3}>
                <Typography variant="h2" className="blue bannerhead_a1">
                  Partnership for Excellence: <br />{" "}
                  <span className="smart">SMART</span>
                  <span className="pipe">PiPE</span> Brings Together Two Leaders
                  in the FinTech Industry
                </Typography>
              </Box>
            </Grid>

            <Grid container spacing={1} alignItems="top">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="al_center" mt={3}>
                  <img
                    src={splogo}
                    className="dpalogo  com_logo "
                    alt="SmartPipe Logo"
                  />
                </Box>
              </Grid>
            </Grid>

            <Box id="fintech-leaders" mt={3}>
              <Grid container spacing={3} alignItems="top">
                <Grid item lg={6} md={6} sm={12} xs={12}>
                  <Box className="whbx">
                    <Box className="al_center">
                      <img
                        src={dpalogo}
                        className="dpalogo  com_logo col1bg"
                        alt="DPA Logo"
                      />
                    </Box>

                    <Box mt={2}>
                      <Typography variant="h4" className="blue jst pagecontent">
                        {" "}
                        DPA is a unique company that brings together deep
                        computational skills with core financial services domain
                        expertise. Our team has extensive experience in data,
                        advanced statistics, and large-scale programming, as
                        well as expertise in artificial intelligence and machine
                        learning. This allows us to create tailor-made products
                        and real-time services and solutions for our clients.
                      </Typography>

                      <Typography variant="h4" className="blue jst pagecontent">
                        In addition, we have experience developing solutions for
                        the extraction of research intelligence from big data.
                        With our diverse skill set and background in both
                        technology and finance, we are well-equipped to address
                        the data challenges that plague the industry. Trust us
                        to deliver the expert insights and innovative solutions
                        your business needs.
                      </Typography>
                    </Box>
                  </Box>
                </Grid>

                <Grid item lg={6} md={6} sm={12} xs={12}>
                  <Box className="whbx">
                    <Box className="al_center">
                      <img
                        src={r2logo}
                        className="dpalogo  com_logo col1bg "
                        alt="R2 Logic Logo"
                      />
                    </Box>

                    <Box mt={2}>
                      <Typography variant="h4" className="blue jst pagecontent">
                        {" "}
                        R<sup>2</sup> Logic acts as a technology advisor for
                        hedge funds, alternative asset managers, and family
                        offices. Our team has deep hands-on experience in
                        multiple asset classes, specializing in credit and fixed
                        income, and is able to dissect, analyze, and recommend
                        unique solutions that increase efficiency and improve
                        productivity.
                      </Typography>

                      <Typography variant="h4" className="blue jst pagecontent">
                        In addition to our expertise in the financial industry,
                        we also have a track record of leading transformations
                        across industries focused on automation, data
                        governance, and analytics. Our approach is centered on
                        helping firms navigate the complex technology landscape
                        and make informed decisions that drive success. Trust us
                        to provide the expert guidance you need to thrive in
                        today's digital world.
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Container>
        </Box>

        <Box className="section sec_bg" component="section">
          <Container maxWidth="lg" className="bdr">
            <Grid container spacing={1} alignItems="top">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="al_center" mb={3}>
                  <Typography className="bannerhead_a1">
                    {" "}
                    And is Led by Veterans in the Field{" "}
                  </Typography>
                </Box>
              </Grid>
            </Grid>

            <Grid
              container
              direction="row"
              justifyContent="center"
              alignItems="center"
            >
              <Grid item lg={4} md={4} sm={6} xs={12} className="dpateam">
                <Box onClick={handleClickOpen1} className="tmlink">
                  <Box mt={4}>
                    <Box
                      className="team"
                      style={{ backgroundImage: "url(" + rr + ")" }}
                    ></Box>
                  </Box>

                  <Box mt={3}>
                    <Typography className="teaminfo blue al_center">
                      Ronen Rub
                    </Typography>
                  </Box>
                  <Box className="line" style={{ margin: "0 auto" }}></Box>
                  <Box mt={1}>
                    <Typography
                      variant="h6"
                      className="black al_center pagecontent"
                    >
                      Founder
                      <br />R<sup>2</sup> Logic, LLC
                    </Typography>
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={4} md={4} sm={6} xs={12} className="dpateam">
                <Box onClick={handleClickOpen2} className="tmlink">
                  <Box mt={4}>
                    <Box
                      className="team"
                      style={{ backgroundImage: "url(" + sd + ")" }}
                    ></Box>
                  </Box>

                  <Box mt={3}>
                    <Typography className="teaminfo blue al_center">
                      Shailesh Dhuri
                    </Typography>
                  </Box>
                  <Box className="line" style={{ margin: "0 auto" }}></Box>
                  <Box mt={1}>
                    <Typography
                      variant="h6"
                      className="black al_center pagecontent"
                    >
                      Chief Executive Officer, <br /> Decimal Point Analytics
                    </Typography>
                  </Box>
                </Box>
              </Grid>

              <Grid item lg={4} md={4} sm={6} xs={12} className="dpateam">
                <Box onClick={handleClickOpen3} className="tmlink">
                  <Box mt={4}>
                    <Box
                      className="team"
                      style={{ backgroundImage: "url(" + ps + ")" }}
                    ></Box>
                  </Box>

                  <Box mt={3}>
                    <Typography className="teaminfo blue al_center">
                      Paresh Sharma
                    </Typography>
                  </Box>
                  <Box className="line" style={{ margin: "0 auto" }}></Box>
                  <Box mt={1}>
                    <Typography
                      variant="h6"
                      className="black pagecontent   al_center"
                    >
                      Managing Partner,
                      <br />
                      Decimal Point Analytics
                    </Typography>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>

        <Box className="section d-bg" component="section">
          <Container maxWidth="lg" className="bdr">
            <Grid container spacing={1} alignItems="top">
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="al_center" mb={6}>
                  <Typography className="bannerhead_a1 ">
                    Data Management Visionary: Ronen Rub Shares Insight
                  </Typography>
                </Box>
              </Grid>
            </Grid>

            <Grid
              container
              direction="row"
              justifyContent="top"
              alignItems="top"
            >
              <Grid item lg={3} md={5} sm={6} xs={12}>
                <Box className="tmlink">
                  <Box>
                    <Box
                      className="team2"
                      style={{ backgroundImage: "url(" + rr + ")" }}
                    ></Box>
                  </Box>
                </Box>
              </Grid>

              <Grid
                item
                lg={9}
                md={7}
                sm={6}
                xs={12}
                className="blockquote-wrapper"
              >
                <Box className="blockquote">
                  <Typography
                    variant="h6"
                    className="subtitle2 gry pagecontent jst"
                  >
                    As CTOs, we are constantly faced with the challenge of
                    ensuring that millions of data points are validated and
                    transferred from source to destination successfully. With
                    the volume of files we receive from brokers and custodians,
                    it can be overwhelming to try to manage this process
                    in-house. That's why we offer a managed service for data
                    pipelines at <span className="smart">SMART</span>
                    <span className="pipe">PiPE</span>- we take care of
                    everything from start to finish, so your internal team can
                    focus on higher level tasks. Trust us to build and manage
                    your pipes with the highest level of quality and efficiency.
                  </Typography>

                  <Box className="h4">
                    <Typography className="pagecontent blue">
                      <span className="col2 fw6"> Ronen Rub </span> <br />
                      Founder - R<sup>2</sup> Logic, LLC
                    </Typography>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Box>

      {/* Ronen Rub dialog */}
      <Dialog
        fullWidth={true}
        maxWidth={"sm"}
        open={open1}
        onClose={handleClose1}
      >
        <IconButton
          aria-label="close"
          onClick={handleClose1}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: "#000",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          <DialogContentText>
            <Box>
              <Grid container spacing={2} alignItems="center">
                <Grid item lg={4} md={4} sm={5} xs={12}>
                  <Box>
                    <Box
                      className="teama"
                      style={{ backgroundImage: "url(" + rr + ")" }}
                    ></Box>
                  </Box>
                </Grid>
                <Grid item lg={8} md={8} sm={7} xs={12}>
                  <Box mt={3}>
                    <Typography className="  al_left bannerhead_a2  blue">
                      Ronen Rub
                    </Typography>
                  </Box>
                  <Box className="line"></Box>
                  <Box mt={1}>
                    <Typography
                      variant="h6"
                      className="black al_left pagecontent"
                    >
                      Founder
                      <br />R<sup>2</sup> Logic, LLC
                    </Typography>
                  </Box>
                  <Box className="linkedin-ic">
                    <a
                      href="https://www.linkedin.com/in/ronen-rub-193a041/"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <IconButton aria-label="delete" size="small">
                        <LinkedInIcon fontSize="small" color="primary" />
                      </IconButton>
                    </a>
                  </Box>
                </Grid>
              </Grid>
              <Grid container spacing={2} alignItems="center">
                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box mt={3}>
                    <Typography variant="h6" className="black jst pagecontent">
                      Prior to{" "}
                      <strong>
                        {" "}
                        Founding R<sup>2</sup> Logic{" "}
                      </strong>
                      , Ronen was the MD and CTO at Waterfall Asset Management
                      and brings in 30+ Years of experience in leading
                      technology enabled transformations across industries
                    </Typography>
                  </Box>
                </Grid>

                <Grid item lg={3} md={3} sm={3} xs={12}>
                  <Box className="al_left">
                    <img
                      src={r2logosm}
                      className="dpalogo "
                      alt="SmartPipe Logo"
                    />
                  </Box>
                </Grid>

                <Grid item lg={9} md={9} sm={9} xs={12}>
                  <Box>
                    <Typography className="black bannerhead_a3   col1">
                      R-Squared Logic
                    </Typography>
                    <Typography className="black bannerhead_a3 col2 ">
                      A US-based Technology Advisor
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      {/* Ronen Rub dialog */}

      {/*  Shailesh Dhuri dialog */}
      <Dialog
        fullWidth={true}
        maxWidth={"sm"}
        open={open2}
        onClose={handleClose2}
      >
        <IconButton
          aria-label="close"
          onClick={handleClose2}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: "#000",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          <DialogContentText>
            <Box>
              <Grid container spacing={2} alignItems="center">
                <Grid item lg={4} md={4} sm={5} xs={12}>
                  <Box>
                    <Box
                      className="teama"
                      style={{ backgroundImage: "url(" + sd + ")" }}
                    ></Box>
                  </Box>
                </Grid>
                <Grid item lg={8} md={8} sm={7} xs={12}>
                  <Box mt={3}>
                    <Typography className="bannerhead_a2 blue al_left">
                      Shailesh Dhuri
                    </Typography>
                  </Box>
                  <Box className="line"></Box>
                  <Box mt={1}>
                    <Typography
                      variant="h6"
                      className="black al_left pagecontent"
                    >
                      Chief Executive Officer,
                      <br /> Decimal Point Analytics
                    </Typography>
                  </Box>
                  <Box className="linkedin-ic">
                    <a
                      href="https://www.linkedin.com/in/shailesh-dhuri-68baa/"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <IconButton aria-label="delete" size="small">
                        <LinkedInIcon fontSize="small" color="primary" />
                      </IconButton>
                    </a>
                  </Box>
                </Grid>
              </Grid>
              <Grid container spacing={2} alignItems="center">
                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box mt={3}>
                    <Typography variant="h6" className="black jst pagecontent">
                      Shailesh is the Founder and CEO of Decimal Point Analytics
                      and is leading DPA’s initiatives to build new industry
                      verticals, where none exist.
                    </Typography>
                  </Box>
                </Grid>

                <Grid item lg={2} md={2} sm={2} xs={2}>
                  <Box className="al_center">
                    <img
                      src={dpalogosm}
                      className="dpalogo "
                      alt="SmartPipe Logo"
                    />
                  </Box>
                </Grid>

                <Grid item lg={10} md={10} sm={10} xs={10}>
                  <Box>
                    <Typography className="black bannerhead_a3   col1">
                      Decimal Point Analytics
                    </Typography>
                    <Typography className="black bannerhead_a3 col2 ">
                      Tech-Enabled Research & Analytics Company
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      {/* Shailesh Dhuri dialog */}

      {/*  Paresh Sharma dialog */}
      <Dialog
        fullWidth={true}
        maxWidth={"sm"}
        open={open3}
        onClose={handleClose3}
      >
        <IconButton
          aria-label="close"
          onClick={handleClose3}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: "#000",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          <DialogContentText>
            <Box>
              <Grid container spacing={2} alignItems="center">
                <Grid item lg={4} md={4} sm={5} xs={12}>
                  <Box>
                    <Box
                      className="teama"
                      style={{ backgroundImage: "url(" + ps + ")" }}
                    ></Box>
                  </Box>
                </Grid>
                <Grid item lg={8} md={8} sm={7} xs={12}>
                  <Box mt={3}>
                    <Typography className="bannerhead_a2 blue al_left">
                      Paresh Sharma
                    </Typography>
                  </Box>
                  <Box className="line"></Box>
                  <Box mt={1}>
                    <Typography
                      variant="h6"
                      className="black al_left pagecontent"
                    >
                      Managing Partner,
                      <br />
                      Decimal Point Analytics
                    </Typography>
                  </Box>
                  <Box className="linkedin-ic">
                    <a
                      href="https://www.linkedin.com/in/paresh-sharma-b615ba5/"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <IconButton aria-label="delete" size="small">
                        <LinkedInIcon fontSize="small" />
                      </IconButton>
                    </a>
                  </Box>
                </Grid>
              </Grid>
              <Grid container spacing={2} alignItems="center">
                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box>
                    <Typography variant="h6" className="black jst pagecontent">
                      Paresh is the Managing Partner at Decimal Point Analytics
                      and is leading DPA’s Cloud based Data Analytics
                      initiatives.
                    </Typography>
                  </Box>
                </Grid>

                <Grid item lg={2} md={2} sm={2} xs={2}>
                  <Box className="al_center">
                    <img
                      src={dpalogosm}
                      className="dpalogo "
                      alt="SmartPipe Logo"
                    />
                  </Box>
                </Grid>

                <Grid item lg={10} md={10} sm={10} xs={10}>
                  <Box>
                    <Typography className="black bannerhead_a3   col1">
                      Decimal Point Analytics
                    </Typography>
                    <Typography className="black bannerhead_a3 col2 ">
                      Tech-Enabled Research & Analytics Company
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      {/* Paresh Sharma dialog */}
    </>
  );
};
