import React from "react";
import { Box, Container, Typography, Button } from "@mui/material";
import CalendlyInlineWidget from "../Component/CalendlyInlineWidget";
import { useNavigate } from "react-router-dom";

export const ScheduleDemo = () => {
  const navigate = useNavigate();

  return (
    <>
      {/* Schedule a Demo Page */}
      <Box className="topsection">
        <Container maxWidth="lg">
          <Box className="al_center">
            <Typography variant="h2" className="col1v2 fw7 mb0" gutterBottom>
              Schedule a demo
            </Typography>
            <Typography variant="h4" className="dgry fw6" gutterBottom>
              Experience Our Products Firsthand: Explore a Live Demonstration
            </Typography>
          </Box>

          <Box mt={"-40px"}>
            <CalendlyInlineWidget />
          </Box>
        </Container>
      </Box>
      {/* Schedule a Demo Page */}
    </>
  );
};
