import { Container, Grid, Typography, Box, Divider } from "@mui/material";
import React, { useEffect, useRef } from "react";

// import Cookies_Collected from "../Assets/Images/cookies_table.png";
// import CookiesTable from "./CookiesTable";

export default function Terms() {
  // useEffect(() => {
  //   window.scrollTo(0, 0);
  // }, []);

  const scriptRef = useRef();

  useEffect(() => {
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.charset = "UTF-8";
    script.setAttribute("data-cookiescriptreport", "report");
    script.src =
      "//report.cookie-script.com/r/1c94e50fa161412d25053738f7f74d87.js";

    document.body.appendChild(script);
    scriptRef.current.appendChild(script);

    // return () => {
    //   scriptRef.current.removeChild(script);
    // };
  }, []);

  return (
    <>
      <Box className="section col1bg" component="section" mt={"50px"}>
        <Container maxWidth="lg" className="bdr">
          <Grid container spacing={1} alignItems="center">
            <Grid item lg={12} md={12} sm={12} xs={12}>
              <Box className="al_center ">
                <Typography variant="h2" className="wh bannerhead_a1">
                  Cookies Policy
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      <Box className="mainsection" id="manage" component="section" mt={"3%"}>
        <Container maxWidth="lg">
          <Box className="jst">
            <Typography variant="h6" className="pagesubhead col1">
              1. What are cookies?
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            Cookies are small data files that are placed on your computer or
            mobile device when you (<strong>“You”</strong>) visit our website (
            <strong>“Website”</strong>). Website owners can use cookies for a
            variety of reasons that can include enabling their websites to work
            (or work more efficiently), providing personalized content and
            advertising, and creating website analytics.
          </Typography>

          <Typography className="pagecontent jst">
            Cookies set by the website owner (in this case,{" "}
            <span className="col1">SMART</span>
            <span className="col2">PiPE</span>, as referred to as{" "}
            <strong>“we”</strong>, <strong>“us”</strong> or{" "}
            <strong>“our”</strong>) are called{" "}
            <strong>"First-Party Cookies"</strong>. Only the website owner can
            access the First-Party Cookies it sets. Cookies set by parties other
            than the website owner are called "
            <strong>Third-Party Cookies</strong>”. Third-Party Cookies enable
            features and/or functionalities of such third party as provided
            through the Website (for suppose, advertising, interactive content
            and social sharing). The parties that set these Third-Party Cookies
            can recognize Your device while it visits the Website in question as
            well as when it visits other websites that have partnered with them.
          </Typography>

          <Typography className="pagecontent jst">
            <span className="col1">SMART</span>
            <span className="col2">PiPE</span> may use web beacons, tags, flash
            cookies, HTML5, and scripts (<strong>“Data Tools”</strong>) in the
            Website or in emails to help deliver cookies, count visits,
            understand usage and campaign effectiveness and determine whether an
            email has been opened and acted upon.{" "}
            <span className="col1">SMART</span>
            <span className="col2">PiPE</span> may receive reports based on the
            use of these technologies by our service/analytics providers on an
            individual and aggregated basis.
          </Typography>

          <Divider />

          <Box className="jst" pt={1}>
            <Typography variant="h6" className="pagesubhead col1">
              2. Information Collected:
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            Some cookies collect information pertaining to Your browsing and
            purchasing behaviour when You access our Website through same
            computer or other devices. This includes information pertaining to
            pages viewed, products purchased and ancillary activities conducted
            on the Website. All data passed by these cookies are anonymous and
            will never contain individual details such as Your name, address,
            telephone number or payment information but may contain the customer
            reference number as assigned by us and which is unique to You.
          </Typography>

          <Divider />

          <Box className="jst" pt={1}>
            <Typography variant="h6" className="pagesubhead col1">
              3. Why do we use cookies?
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            We use First-Party Cookies and Third-Party Cookies for various
            reasons. Some cookies are essential for technical reasons that are
            strictly necessary for our Website to operate.
          </Typography>

          <Typography className="pagecontent jst">
            Cookies collect certain standard information that Your browser sends
            to the Website such as browser type and language, access times, and
            the address of the website from which You arrived at our Website.
            They may also collect information about Your internet protocol (IP)
            address, clickstream behavior (i.e. the pages You view, the links
            You click, and other actions that You may take when You use the
            Website) and product information. These are some of the First-Party
            Cookies which are essential to the Website’s operation.
          </Typography>

          <Divider />

          <Box className="jst" pt={1}>
            <Typography variant="h6" className="pagesubhead col1">
              4. What Types of Cookies do we use?
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            The following are the types of cookie that may be used during Your
            visit to our site:
            <ol>
              <li>
                {" "}
                <Typography className="pagecontent jst">
                  {" "}
                  <em> Session cookies: </em> <br />
                  Session cookies are those cookies which are deleted after each
                  visit to our site. For example, when You are browsing our
                  Website, it will remember You for the duration of Your visit,
                  but the cookie will be removed from Your computer as soon as
                  You close down Your internet browser.
                </Typography>
              </li>

              <li>
                {" "}
                <Typography className="pagecontent jst">
                  {" "}
                  <em> Analytics Cookies: </em> <br />
                  Analytics Cookies are those cookies that gather and store
                  information about the website visitor. For example, when You
                  visit Our Platform, the cookies store information on how You
                  use Our Platform, calculate the duration of Your session,
                  while creating an analytics report of Our Platform’s
                  performance. It may be noted that we are engaged in the use of
                  Microsoft Clarity and Google Analytics pursuant to which
                  cookie policy of Microsoft Clarity (as available in the given
                  link) and Google Analytics (as available in the given link)
                  shall be applicable.
                </Typography>
              </li>

              <li>
                {" "}
                <Typography className="pagecontent jst">
                  {" "}
                  <em> Persistent cookies: </em> <br />
                  Persistent cookies are those cookies that remembers You for a
                  set period of time. These cookies allow the website to display
                  the content browsed by You based on what You viewed the
                  previous time when You visited our website.
                </Typography>
              </li>

              <li>
                {" "}
                <Typography className="pagecontent jst">
                  {" "}
                  <em> Essential Cookies: </em> <br />
                  Essential Cookies are those which are required for technical
                  reasons that are strictly necessary for our Website to
                  operate.
                </Typography>
              </li>
            </ol>
          </Typography>

          <Typography className="pagecontent jst">
            List Of Cookies We Collect:
          </Typography>

          <Box id="cookies-table" className="al_left" pb={2}>
            {/* <img src={Cookies_Collected} alt="total cookies collected" className="collection_banner" /> */}
            {/* <script type="text/javascript" charset="UTF-8"  data-cookiescriptreport="report" src="//report.cookie-script.com/r/1c94e50fa161412d25053738f7f74d87.js"></script> */}
            {/* <CookiesTable /> */}
            <div ref={scriptRef} />
          </Box>

          {/* <Divider /> */}

          <Box className="jst" pt={1}>
            <Typography variant="h6" className="pagesubhead col1">
              5. Turning off and Deleting Cookies:
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            It may be understood that You shall have the option to adjust the
            settings of Your internet browser to either automatically reject all
            cookies or receive prior consent notification when any cookie is
            being proposed to be used. However, if you chose to disable cookies
            in Your internet browser, this may prevent a great bulk of features
            on our Platform from working efficiently, and Your browser shall
            provide repeated "alert" or “warning” notifications during Your use
            of our Website which shall reduce your interest and/or the
            attractiveness of our Website. For this reason, we recommend You
            allow only those cookies in their entirety which are essential for
            the functioning of our Website.
          </Typography>

          <Divider />

          <Box className="jst" pt={1}>
            <Typography variant="h6" className="pagesubhead col1">
              6. Consent:
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            <span className="col1">SMART</span>
            <span className="col2">PiPE</span> has obtained consent for the
            collection and use of cookies except Essential Cookies through
            consent mechanism such as pop-up or banner By using our website, You
            consent towards our use of the cookies as described in this cookie
            policy. Prior to obtaining such consent, you hereby agreed that you
            have been provided accurate and specific information about the data
            each cookie tracks and its purpose in plain language to the user.
            Therefore, <span className="col1">SMART</span>
            <span className="col2">PiPE</span> has documented and stored such
            consent received from users.
          </Typography>

          <Divider />

          <Box className="jst" pt={1}>
            <Typography variant="h6" className="pagesubhead col1">
              7. Right to Opt-Out and Withdraw Consent:
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            <span className="col1">SMART</span>
            <span className="col2">PiPE</span> allows You to access its services
            irrespective of Your refusal to allow the use of cookies, however by
            restricting to certain functionality efficiency for which Your
            consent towards use of cookies is not obtained. You can withdraw
            your consent for cookies pursuant to the terms provided in{" "}
            <a href="https://tools.google.com/dlpage/gaoptout" target="_blank">
              {" "}
              https://tools.google.com/dlpage/gaoptout.{" "}
            </a>
          </Typography>

          <Divider />

          <Box className="jst" pt={1}>
            <Typography variant="h6" className="pagesubhead col1">
              8. Disclaimer
            </Typography>
          </Box>

          <Typography className="pagecontent jst">
            We may update this policy from time to time in order to reflect the
            changes to the cookies that we use for operational, legal or
            regulatory reasons. Therefore, we suggest that You re-visit this
            policy on a frequent basis to stay informed about our use of cookies
            and related technologies. The last modification date of this
            document is shown at the bottom of this page.
          </Typography>

          <Divider />

          <Box className="jst" pt={1} pb={"3%"}>
            <Typography className="pagecontent jst">
              Last update: 18-04-2023.
            </Typography>
          </Box>
        </Container>
      </Box>
    </>
  );
}
