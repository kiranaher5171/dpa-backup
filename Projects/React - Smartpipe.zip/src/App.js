import "./Root.css";
import "aos/dist/aos.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Homepage } from "./Pages/Homepage";
import { ThemeProvider, createTheme } from "@mui/material";
import MainLayout from "./Layouts/MainLayout";
import BackToTop from "./Component/Scroll/BackToTop";
import OpenAtTop from "./Component/Scroll/OpenAtTop";
import NotFoundPage from "./Component/NotFound";
import { Connectors } from "./Pages/Connectors";
import BlankHeaderLayout from "./Layouts/BlankHeaderLayout";
import { ScheduleDemo } from "./Pages/ScheduleDemo";
import { Resources } from "./Pages/Resources";
import Pricing from "./Pages/Pricing";
import { AboutUs } from "./Pages/About";
import Policy from "./Pages/Policy";
import Terms from "./Pages/Cookie";
import TermsCondtion from "./Pages/Terms";

function App() {
  const theme = createTheme({
    typography: {
      fontFamily: "Open Sans, sans-serif",
    },
  });

  return (
    <>
      <ThemeProvider theme={theme}>
        <Router>
          <BackToTop />
          <OpenAtTop />
          <Routes>
            <Route
              path="/"
              element={
                <MainLayout>
                  <Homepage />
                </MainLayout>
              }
            />

            <Route
              path="/connectors"
              element={
                <MainLayout>
                  <Connectors />
                </MainLayout>
              }
            />
            <Route
              path="/resources"
              element={
                <MainLayout>
                  <Resources />
                </MainLayout>
              }
            />
            <Route
              path="/pricing"
              element={
                <MainLayout>
                  <Pricing />
                </MainLayout>
              }
            />
            <Route
              path="/privacy"
              element={
                <MainLayout>
                  <Policy />
                </MainLayout>
              }
            />
            <Route
              path="/cookies"
              element={
                <MainLayout>
                  <Terms />
                </MainLayout>
              }
            />
            <Route
              path="/terms"
              element={
                <MainLayout>
                  <TermsCondtion />
                </MainLayout>
              }
            />
            <Route
              path="/about-us"
              element={
                <MainLayout>
                  <AboutUs />
                </MainLayout>
              }
            />
            <Route
              path="/pricing"
              element={
                <MainLayout>
                  <Pricing />
                </MainLayout>
              }
            />

            <Route
              path="/schedule-a-demo"
              element={
                <MainLayout>
                  <ScheduleDemo />
                </MainLayout>
              }
            />

            <Route
              path="*"
              element={
                <MainLayout>
                  <NotFoundPage />
                </MainLayout>
              }
            />
          </Routes>
        </Router>
      </ThemeProvider>
    </>
  );
}

export default App;
