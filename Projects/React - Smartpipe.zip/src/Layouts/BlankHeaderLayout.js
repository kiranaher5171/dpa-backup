import React from 'react';
import BlankHeader from '../Component/Header/BlankHeader';
import { Footer } from '../Component/Footer/Footer';

const BlankHeaderLayout = ({ children }) => {
  return (
    <div>
      <BlankHeader/>
      <main className='main-layout'>{children}</main>
      <Footer/>
    </div>
  );
};

export default BlankHeaderLayout;