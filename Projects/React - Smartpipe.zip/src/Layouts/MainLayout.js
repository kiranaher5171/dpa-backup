import React from 'react';
import Header from '../Component/Header/Header'; 
import { Footer } from '../Component/Footer/Footer';

const MainLayout = ({ children }) => {
    return (
        <div>
            <Header />
            <main className='main-layout'>{children}</main>
            <Footer />
        </div>
    );
};

export default MainLayout;