"use client";

import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Divider from "@mui/material/Divider";
import ListItemIcon from "@mui/material/ListItemIcon";
import MenuItem from "@mui/material/MenuItem";
import Drawer from "@mui/material/Drawer";
import Tooltip from "@mui/material/Tooltip";
import {
  MdAndroid,
  MdLogout,
  MdMenu,
  MdPersonAdd,
  MdSettings,
} from "react-icons/md";
import "../../../css/header.css";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import ListItemText from "@mui/material/ListItemText";
import Image from "next/image";
import Link from "next/link";

const pages = ["Products", "Pricing", "Blog"];

function Header() {
  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const [anchorElProfile, setAnchorElProfile] = React.useState(null);
  const [rightDrawerOpen, setRightDrawerOpen] = React.useState(false);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleOpenProfileMenu = (event) => {
    setAnchorElProfile(event.currentTarget);
  };

  const handleCloseProfileMenu = () => {
    setAnchorElProfile(null);
  };

  const profileMenuOpen = Boolean(anchorElProfile);

  return (
    <AppBar position="sticky">
      <Container maxWidth>
        <Toolbar disableGutters sx={{ gap: 1 }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flexGrow: 1,
              minWidth: 0,
            }}
          >
            <Image
              src="/ambit-logo.jpg"
              alt="Ambit Capital"
              width={140}
              height={40}
              className="object-contain"
              priority
              sizes="140px"
            />

            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
              <IconButton
                size="large"
                aria-label="open navigation menu"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleOpenNavMenu}
                color="inherit"
              >
                <MdMenu size={28} aria-hidden />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorElNav}
                anchorOrigin={{
                  vertical: "bottom",
                  horizontal: "left",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "left",
                }}
                open={Boolean(anchorElNav)}
                onClose={handleCloseNavMenu}
                sx={{ display: { xs: "block", md: "none" } }}
              >
                {pages.map((page) => (
                  <MenuItem key={page} onClick={handleCloseNavMenu}>
                    <Typography sx={{ textAlign: "center" }}>{page}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
            <Box sx={{ display: { xs: "flex", md: "none" }, mr: 1, lineHeight: 0 }}>
              <MdAndroid size={28} aria-hidden />
            </Box>
            <Typography
              variant="h5"
              noWrap
              component="a"
              href="#app-bar-with-responsive-menu"
              sx={{
                mr: 2,
                display: { xs: "flex", md: "none" },
                flexGrow: 1,
                fontWeight: 700,
                letterSpacing: ".3rem",
                color: "inherit",
                textDecoration: "none",
              }}
            >
              LOGO
            </Typography>
            {/* <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
            {pages.map((page) => (
              <Button
                key={page}
                onClick={handleCloseNavMenu}
                sx={{ my: 2, color: "white", display: "block" }}
              >
                {page}
              </Button>
            ))}
          </Box> */}
          </Box>

          <Box sx={{ display: "flex", alignItems: "center", flexShrink: 0 }}>

            {/* <Tooltip arrow title="Notifications">
              <IconButton size="medium" className='tertiary'>
                <Badge className='notification-badge' badgeContent={4} color="error">
                  <MdOutlineNotificationsNone style={{ fontSize: '22px' }} />
                </Badge>
              </IconButton>
            </Tooltip> */}



            <List id="profile" disablePadding sx={{ pl: 1 }}>
              <ListItem disablePadding>
                <ListItemButton
                  disableRipple
                  disableTouchRipple
                  onClick={handleOpenProfileMenu}
                  aria-controls={profileMenuOpen ? "account-menu" : undefined}
                  aria-haspopup="true"
                  aria-expanded={profileMenuOpen ? "true" : undefined}
                  sx={{ position: "relative", width: "100%" }}
                  className="profile-menu-item"
                >
                  <ListItemAvatar>
                    <Avatar> 
                      AD
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText primary={<Typography variant='h6' className='primary' sx={{position: 'relative', top: 1, textTransform: 'capitalize'}}>  <span>Aida Belac</span></Typography>} secondary={<Typography variant='h6' className='secondary' sx={{position: 'relative', top: -2, textTransform: 'capitalize'}}>admin</Typography>} />
                </ListItemButton>
              </ListItem>
            </List>

            <Box sx={{ ml: 2 }}>
              <Tooltip arrow title="Logout">
                <Link href="/"> <IconButton size="medium" className='tertiary'>
                  <MdLogout size={18} aria-hidden className="primary" />
                </IconButton> </Link>
              </Tooltip>
            </Box>

            <Menu
              id="account-menu"
              anchorEl={anchorElProfile}
              open={profileMenuOpen}
              onClose={handleCloseProfileMenu}
              onClick={handleCloseProfileMenu}
              anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
              transformOrigin={{ horizontal: "right", vertical: "top" }}
              slotProps={{
                paper: {
                  elevation: 0,
                  sx: {
                    position: "relative",
                    overflow: "visible",
                    filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
                    mt: 1.5,
                    minWidth: "min-content !important",
                    width: "max-content !important",
                    maxWidth: "min(100vw - 24px, 320px)",
                    "& .MuiAvatar-root": {
                      width: 32,
                      height: 32,
                      ml: -0.5,
                      mr: 1,
                    },
                    "&::before": {
                      content: '""',
                      display: "block",
                      position: "absolute",
                      top: 0,
                      right: 14,
                      width: 10,
                      height: 10,
                      bgcolor: "background.paper",
                      transform: "translateY(-50%) rotate(45deg)",
                      zIndex: 0,
                    },
                    "& .MuiMenu-list": {
                      position: "relative",
                      zIndex: 1,
                      width: "max-content",
                      minWidth: 0,
                    },
                  },
                },
              }}
            >

              <MenuItem onClick={handleCloseProfileMenu}>
                <ListItemIcon sx={{ minWidth: 36 }}>
                  <MdSettings size={20} aria-hidden />
                </ListItemIcon>
                Settings
              </MenuItem>
              <Divider />
              <MenuItem onClick={handleCloseProfileMenu}>
                <ListItemIcon sx={{ minWidth: 36 }}>
                  <MdLogout size={20} aria-hidden />
                </ListItemIcon>
                Logout
              </MenuItem>
            </Menu>

          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
}
export default Header;
