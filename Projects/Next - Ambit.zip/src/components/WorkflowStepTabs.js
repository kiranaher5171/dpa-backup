import * as React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";

export default function WorkflowStepTabs({ steps }) {
  return (
    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 1 }}>
      {steps.map((s, idx) => {
        const isDone = s.state === "done";
        const isActive = s.state === "active";
        return (
          <Box key={s.label} sx={{ flex: 1, minWidth: 0 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Box
                sx={{
                  width: 22,
                  height: 22,
                  borderRadius: 999,
                  display: "grid",
                  placeItems: "center",
                  fontSize: 12,
                  fontWeight: 800,
                  backgroundColor: isDone ? "rgb(46,125,50)" : isActive ? "rgb(211,47,47)" : "rgba(15,23,42,0.10)",
                  color: isDone || isActive ? "#fff" : "rgba(15,23,42,0.75)",
                }}
              >
                {s.badge ?? (isDone ? "✓" : idx + 1)}
              </Box>
              <Typography variant="caption" sx={{ fontWeight: 700, color: "text.primary", whiteSpace: "nowrap" }}>
                {s.label}
              </Typography>
            </Box>
            <Box
              sx={{
                height: 2,
                mt: 1,
                bgcolor: isDone ? "rgb(46,125,50)" : isActive ? "rgb(211,47,47)" : "rgba(15,23,42,0.10)",
                borderRadius: 999,
                width: "100%",
              }}
            />
          </Box>
        );
      })}
    </Box>
  );
}

