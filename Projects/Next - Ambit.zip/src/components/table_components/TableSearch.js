"use client";

import React from "react";
import { IoSearch } from "react-icons/io5";
import Box from "@mui/material/Box";
import InputAdornment from "@mui/material/InputAdornment";
import TextField from "@mui/material/TextField";

const TableSearch = () => {
  return (
    <Box className="table-search">
      <TextField
        variant="outlined"
        size="small"
        placeholder="SEARCH"
        sx={{ width: 220 }}
        slotProps={{
          input: {
            startAdornment: (
              <InputAdornment position="start">
                <IoSearch size={20} color="#bfbfbf" aria-hidden />
              </InputAdornment>
            ),
          },
        }}
      />
    </Box>
  );
};

export default TableSearch; 