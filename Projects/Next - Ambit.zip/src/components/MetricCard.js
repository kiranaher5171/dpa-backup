"use client";

import * as React from "react";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";

export default function MetricCard({
  label,
  value,
  accent = "var(--primary)",
  icon: Icon,
  tileText,
  subLabel1,
  subLabel2,
  minHeight = 100,
  hideValue = false,
}) {
  return (
    <Box
      sx={{
        height: "100%",
        minHeight,
        bgcolor: "#fff",
        borderRadius: 3,
        border: "1px solid rgba(15, 23, 42, 0.08)",
        borderTop: "4px solid",
        borderTopColor: accent,
        boxShadow: "0 1px 6px rgba(15, 23, 42, 0.06)",
        py: 2,
        px: 2,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}
    >
      <Stack direction="row" spacing={2} sx={{ width: "100%", minHeight: 52, alignItems: "stretch" }}>
        <Box
          sx={{
            width: 52,
            height: 52,
            flexShrink: 0,
            alignSelf: "center",
            borderRadius: 2.5,
            bgcolor: accent,
            border: "2px solid rgba(255, 255, 255, 0.95)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
          }}
          aria-hidden
        >
          {Icon ? (
            <Icon size={26} />
          ) : tileText != null ? (
            <Typography
              component="span"
              sx={{
                fontWeight: 900,
                fontSize: 22,
                lineHeight: 1,
                letterSpacing: "-0.02em",
                color: "#fff",
              }}
            >
              {tileText}
            </Typography>
          ) : null}
        </Box>

        <Stack
          spacing={0.35}
          sx={{
            flex: 1,
            minWidth: 0,
            textAlign: "right",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
        >
          {label ? (
            <Typography
              variant="caption"
              component="p"
              sx={{
                m: 0,
                fontWeight: 800,
                letterSpacing: "0.09em",
                textTransform: "uppercase",
                color: "text.secondary",
                fontSize: 13,
                lineHeight: 1.3,
              }}
            >
              {label}
            </Typography>
          ) : null}

          {!hideValue ? (
            <Typography
              component="p"
              sx={{
                m: 0,
                fontWeight: 900,
                fontSize: 22,
                lineHeight: 1.1,
                color: "rgba(15, 23, 42, 0.9)",
                letterSpacing: "-0.02em",
              }}
            >
              {value}
            </Typography>
          ) : null}

          {subLabel1 ? (
            <Typography
              variant="caption"
              component="p"
              sx={{
                m: 0,
                color: "rgba(15, 23, 42, 0.9)",
                fontWeight: 600,
                fontSize: "13px",
                letterSpacing: "0.05em",
                lineHeight: 1.25,
              }}
            >
              {subLabel1}
            </Typography>
          ) : null}
          {subLabel2 ? (
            <Typography
              variant="caption"
              component="p"
              sx={{
                m: 0,
                color: "text.secondary",
                fontWeight: 600,
                fontSize: 11,
                letterSpacing: "0.02em",
                lineHeight: 1.25,
              }}
            >
              {subLabel2}
            </Typography>
          ) : null}
        </Stack>
      </Stack>
    </Box>
  );
}

