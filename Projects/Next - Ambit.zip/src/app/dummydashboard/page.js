"use client";

import * as React from "react";
import HeaderFooterLayout from "@/components/layout/HeaderFooterLayout/HeaderFooterLayout";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import Tabs from "@mui/material/Tabs";
import Typography from "@mui/material/Typography";
import DummyTable from "./DummyTable";
import TableSearch from "@/components/table_components/TableSearch";
import { MdGroups, MdStorefront, MdTune } from "react-icons/md";
import { RiUserAddLine } from "react-icons/ri";
import IconButton from "@mui/material/IconButton";

const SECTIONS = [
  { label: "User management", title: "User management", Icon: MdGroups },
  { label: "Dealer management", title: "Dealer management", Icon: MdStorefront },
  { label: "Rule config", title: "Rule config", Icon: MdTune },
];

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`dashboard-tabpanel-${index}`}
      aria-labelledby={`dashboard-tab-${index}`}
      {...other}
    >
      {value === index ? <Box sx={{ pt: 2 }}>{children}</Box> : null}
    </div>
  );
}

function a11yProps(index) {
  return {
    id: `dashboard-tab-${index}`,
    "aria-controls": `dashboard-tabpanel-${index}`,
  };
}

export default function Page() {
  const [value, setValue] = React.useState(0);

  return (
    <HeaderFooterLayout>
      <Container maxWidth>
        <Box sx={{ width: "100%", mt: 2 }}>
          <Box>
            <Tabs
              value={value}
              onChange={(_, next) => setValue(next)}
              aria-label="Dashboard sections"
              variant="scrollable"
              scrollButtons
              allowScrollButtonsMobile
            >
              {SECTIONS.map((section, index) => {
                const Icon = section.Icon;
                return (
                  <Tab
                    key={section.label}
                    icon={<Icon size={20} aria-hidden />}
                    iconPosition="start"
                    label={section.label}
                    {...a11yProps(index)}
                    sx={{ textTransform: "none", minHeight: 48 }}
                  />
                );
              })}
            </Tabs>
          </Box>

          {SECTIONS.map((section, index) => (
            <TabPanel key={section.label} value={value} index={index}>
              <Box className="whitebx">
                <Box className="fx_sb" sx={{ pb: 1 }}>
                  <Typography variant="h6" className="table-heading" sx={{ flexShrink: 0 }}>
                    {section.title}
                  </Typography>

                 <Box className="fx_fs gap2">
                 <IconButton><RiUserAddLine size={20} aria-hidden /></IconButton>
                 <TableSearch />
                 </Box>
                </Box>
                <DummyTable />
              </Box>
            </TabPanel>
          ))}
        </Box>
      </Container>
    </HeaderFooterLayout>
  );
}
