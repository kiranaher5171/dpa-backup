"use client";

import { useEffect, useState } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import Box from "@mui/material/Box";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import TableSkeleton from "@/components/table_components/TableSkeleton";

ModuleRegistry.registerModules([AllCommunityModule]);

const GRID_STYLE = { width: "100%", height: "500px" };

export default function DummyTable() {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 400);
    return () => clearTimeout(t);
  }, []);

  const [rowData] = useState(Array.from({ length: 30 }, () => ({})));

  const columnDefs = [
    { headerName: "Customer Group", field: "customerGroup", minWidth: 180, cellRenderer: () => "Blue" },
    { headerName: "Category", field: "category", minWidth: 150, cellRenderer: () => "BRO" },
    { headerName: "Remarks", field: "remarks", minWidth: 150, cellRenderer: () => "181.5" },
    { headerName: "Jan-25", field: "jan25", minWidth: 150, cellRenderer: () => "181.5" },
    { headerName: "Feb-25", field: "feb25", minWidth: 150, cellRenderer: () => "181.5" },
    { headerName: "Mar-25", field: "mar25", minWidth: 150, cellRenderer: () => "181.5" },
    { headerName: "Apr-25", field: "apr25", minWidth: 150, cellRenderer: () => "181.5" },
    { headerName: "May-25", field: "may25", minWidth: 150, cellRenderer: () => "181.5" },
  ];

  const defaultColDef = {
    sortable: false,
    filter: false,
    flex: 1,
    suppressMovable: true,
    resizable: true,
  };

  return (
    <Box>
      {loading ? (
        <Box style={{ ...GRID_STYLE, overflow: "hidden" }} aria-label="Loading...">
          <TableSkeleton />
        </Box>
      ) : (
        <Box className="ag-theme-quartz" style={GRID_STYLE}>
          <AgGridReact
            theme="legacy"
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressMovableColumns
            rowHeight={30}
            headerHeight={35}
          />
        </Box>
      )}
      <Box id="tb_footer" className="fx_sb" sx={{ mt: 1 }}>
        <AgGridInfo currentPage={1} rowsPerPage={rowData.length} totalRows={rowData.length} />
        <AgGridPagination currentPage={1} totalPages={1} onPageChange={() => {}} />
      </Box>
    </Box>
  );
}
