"use client";

import { useEffect, useState } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import Avatar from "@mui/material/Avatar";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import ListItemText from "@mui/material/ListItemText";
import Stack from "@mui/material/Stack";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import { MdPerson } from "react-icons/md";
import { Typography } from "@mui/material";

ModuleRegistry.registerModules([AllCommunityModule]);

function isRowActive(data) {
  const raw = data?.status ?? "active";
  const normalized = String(raw).toLowerCase().trim();
  return (
    normalized === "active" ||
    normalized === "true" ||
    normalized === "1" ||
    normalized === "yes"
  );
}

const DealerManagementTable = ({ onEdit }) => {
  const headerHeight = 35;
  const rowHeight = 40;

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  const [rowData] = useState([
    { customerGroup: "Blue", primary: "Enterprise",   status: "active" },
    { customerGroup: "Blue", primary: "SMB",   status: "inactive" },
    { customerGroup: "Retail", primary: "Retail group",    status: "active" },
    ...Array.from({ length: 34 }, (_, i) => ({
      customerGroup: "Blue",
      status: i % 5 === 0 ? "inactive" : "active",
    })),
  ]);

  const columnDefs = [
   
    { headerName: "Dealer ID", field: "dealerId", minWidth: 150,   cellRenderer: () => "DLR-000345"  },
      { headerName: "Dealer Name", field: "dealerName", minWidth: 150, cellRenderer: () => "James Porter" }, 
      { headerName: "Email", field: "email", minWidth: 150, cellRenderer: () => "james@ambit.com" }, 
    { headerName: "Branch", field: "branch", minWidth: 150, cellRenderer: () => "Mumbai" }, 
    { headerName: "Business", field: "business", minWidth: 150, cellRenderer: () => "Ambit Brokerage" }, 
    {
      headerName: "Status",
      field: "status",
      minWidth: 200,
      maxWidth: 200,
      headerClass: "header_center",
      cellClass: "fx_c",
      cellRenderer: (p) => {
        const isActive = isRowActive(p.data);
        const label = isActive ? "Active" : "Inactive";
        const toneClass = isActive ? "status-pill--active" : "status-pill--inactive";

        return (
          <Box component="span" className={`status-pill ${toneClass}`}>
            {label}
          </Box>
        );
      },
    },
    {
      headerName: "Action",
      colId: "action",
      headerClass: "header_center",
      cellClass: "fx_c",
      sortable: false,
      minWidth: 100,
      maxWidth: 100,
      flex: 0,
      cellRenderer: (p) => {
        const isActive = isRowActive(p.data);
        return (
          <Box sx={{display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"center", height: "100%", gap: 1}}>
            <Button variant="outlined" size="small" className="action-btn action-btn--blue" onClick={() => onEdit?.(p.data)}>
              Edit
            </Button>
          </Box>
        );
      },
    },
  ];

  const defaultColDef = {
    sortable: false,
    autoHeight: false,
    filter: false,
    flex: 1,
    suppressMovable: true,
    resizable: true,
  };

  return (
    <Box>
      {loading ? (
        <Box style={{ width: "100%", height: "65vh", overflow: "hidden" }} aria-label="Loading...">
          <TableSkeleton />
        </Box>
      ) : (
        <Box className="ag-theme-quartz" style={{ width: "100%", height: "65vh" }}>
          <AgGridReact
            theme="legacy"
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressMovableColumns
            rowHeight={rowHeight}
            headerHeight={headerHeight}
            rowClassRules={{
              "even-row": (params) => params.node.rowIndex % 2 !== 0,
              "odd-row": (params) => params.node.rowIndex % 2 === 0,
            }}
          />
        </Box>
      )}
      <Box id="tb_footer" className="fx_sb" sx={{ mt: 1 }}>
        <AgGridInfo
          currentPage={1}
          rowsPerPage={rowData.length}
          totalRows={rowData.length}
        />
        <AgGridPagination currentPage={1} totalPages={1} onPageChange={() => {}} />
      </Box>
    </Box>
  );
};

export default DealerManagementTable;
