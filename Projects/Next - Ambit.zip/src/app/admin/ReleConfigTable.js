"use client";

import { useEffect, useState } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Tooltip from "@mui/material/Tooltip";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import Switch from "@mui/material/Switch";
import { Divider } from "@mui/material"; 

ModuleRegistry.registerModules([AllCommunityModule]);

function isRowActive(data) {
  const raw = data?.status ?? "active";
  const normalized = String(raw).toLowerCase().trim();
  return (
    normalized === "active" ||
    normalized === "true" ||
    normalized === "1" ||
    normalized === "yes"
  );
}

const RULE_CONFIG_ROWS = [
  { customerGroup: "Blue", primary: "Enterprise", status: "active" },
  { customerGroup: "Blue", primary: "SMB", status: "inactive" },
  { customerGroup: "Retail", primary: "Retail group", status: "active" },
  ...Array.from({ length: 34 }, (_, i) => ({
    customerGroup: "Blue",
    status: i % 5 === 0 ? "inactive" : "active",
  })),
];

// Switch style: green if checked/active, red if unchecked/inactive
const getSwitchSx = (checked) => ({
  "& .MuiSwitch-thumb": {
    backgroundColor: checked ? "#2e7d32" : "#d32f2f", // Green for active, Red for inactive
  },
  "& .MuiSwitch-track": {
    backgroundColor: checked ? "#c8e6c9!important" : "#ffcdd2!important", // Green BG for active, Red BG for inactive
    opacity: 1,
  },
  "&.Mui-checked+.MuiSwitch-track": {
    backgroundColor: "#2e7d32!important", // Bright green when checked
  },
  "&+.MuiSwitch-track": {
    backgroundColor: "#d32f2f!important", // Red when not checked
  },
});

const actionBtnRed = {
  textTransform: "none",
  fontSize: 11,
  fontWeight: 600,
  py: 0.35,
  px: 1.25,
  minWidth: 76,
  borderColor: "#d32f2f",
  color: "#d32f2f",
  "&:hover": {
    borderColor: "#b71c1c",
    color: "#b71c1c",
    bgcolor: "rgba(211, 47, 47, 0.04)",
  },
};

const actionBtnGreen = {
  textTransform: "none",
  fontSize: 11,
  fontWeight: 600,
  py: 0.35,
  px: 1.25,
  minWidth: 76,
  borderColor: "#2e7d32",
  color: "#2e7d32",
  "&:hover": {
    borderColor: "#1b5e20",
    color: "#1b5e20",
    bgcolor: "rgba(46, 125, 50, 0.04)",
  },
};

const UserManagementTable = ({ onEdit }) => {
  const headerHeight = 40;
  const rowHeight = 40;

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  const [rowData] = useState(RULE_CONFIG_ROWS);
  const [activeFlags, setActiveFlags] = useState(() =>
    RULE_CONFIG_ROWS.map((r) => isRowActive(r))
  );

  const columnDefs = [
    {
      field: "customerGroup",
      minWidth: 150,
      cellRenderer: () => "RT-0987",
      hide: false,
      headerName: "Rule ID",
    },
    {
      field: "role",
      minWidth: 150,
      cellRenderer: () => "	Market Recommendation",
      headerName: "Rule name",
    },
    {
      field: "ruleDescription",
      minWidth: 350,
      cellRenderer: () => {
        const text =
          "This rule is used to recommend market based on the customer's risk profile and the market's risk profile";
        return (
          <Tooltip title={text} arrow placement="top">
            <Box
              component="span"
              sx={{
                display: "inline-block",
                maxWidth: "100%",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
            >
              {text}
            </Box>
          </Tooltip>
        );
      },
      headerName: "Rule description",
    },
    {
      field: "status",
      minWidth: 200,
      maxWidth: 200,
      headerClass: "header_center",
      cellClass: "fx_c",
      headerName: "Status",
      cellRenderer: (p) => {
        const isActive = isRowActive(p.data);
        const label = isActive ? "Active" : "Inactive";
        const toneClass = isActive ? "status-pill--active" : "status-pill--inactive";

        return (
          <Box component="span" className={`status-pill ${toneClass}`}>
            {label}
          </Box>
        );
      },
    },
    {
      colId: "action",
      headerClass: "header_center",
      cellClass: "fx_c",
      sortable: false,
      minWidth: 300,
      maxWidth: 300,
      flex: 0,
      headerName: "Action",
      cellRenderer: (p) => {
        const rowIndex = p?.node?.rowIndex ?? 0;
        const isActive = Boolean(activeFlags[rowIndex]);
        const label = isActive ? "Active" : "Inactive";
        const fg = isActive ? "#2e7d32" : "#d32f2f";
        return (
          <Box className="fx_fs gap2" sx={{ display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "center", height: "100%" }}>
            <Button
              variant="outlined"
              size="small"
              className="action-btn action-btn--blue"
              onClick={() => onEdit?.(p.data)} 
            >
              Edit
            </Button>
            {/* Switch color handled via sx */}
            <Switch
              size="small"
              checked={isActive}
              sx={getSwitchSx(isActive)}
              onChange={(_, next) => {
                setActiveFlags((prev) => {
                  const copy = [...prev];
                  copy[rowIndex] = next;
                  return copy;
                });
              }}
            />
            <Typography variant="caption" sx={{ color: fg, fontWeight: 500, minWidth: 56 }}>
              {label}
            </Typography>
          </Box>
        );
      },
    },
  ];

  const defaultColDef = {
    sortable: false,
    autoHeight: false,
    filter: false,
    flex: 1,
    suppressMovable: true,
    resizable: true,
  };

  return (
    <Box>
      {loading ? (
        <Box style={{ width: "100%", height: "65vh", overflow: "hidden" }} aria-label="Loading...">
          <TableSkeleton />
        </Box>
      ) : (
        <> 
        <Box className="ag-theme-quartz" style={{ width: "100%", height: "65vh" }}>
          <AgGridReact
            theme="legacy"
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressMovableColumns
            rowHeight={rowHeight}
            headerHeight={headerHeight}
            rowClassRules={{
              "even-row": (params) => params.node.rowIndex % 2 !== 0,
              "odd-row": (params) => params.node.rowIndex % 2 === 0,
            }}
          />
        </Box>
        </>
      )}
      <Box id="tb_footer" className="fx_sb" sx={{ mt: 1 }}>
        <AgGridInfo
          currentPage={1}
          rowsPerPage={rowData.length}
          totalRows={rowData.length}
        />
        <AgGridPagination currentPage={1} totalPages={1} onPageChange={() => {}} />
      </Box>
    </Box>
  );
};

export default UserManagementTable;
