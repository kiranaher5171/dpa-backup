import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import CloseIcon from "@mui/icons-material/Close";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";

export default function AddRuleDialog({ open, onClose }) {
  return (
    <Dialog open={open} onClose={onClose} aria-labelledby="add-rule-dialog-title" maxWidth="xs" fullWidth>
      <DialogTitle component="div" sx={{ m: 0, p: 2 }} id="add-rule-dialog-title">
        <Typography variant="h6" component="span" className="table-heading">
          Add Rule
        </Typography>
      </DialogTitle>
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 10,
          top: 12,
          color: "rgba(0, 0, 0, 0.54)",
        }}
      >
        <CloseIcon sx={{ fontSize: 18 }} />
      </IconButton>
      <Box>
        <Divider sx={{ borderColor: "#E0E0E0" }} />
      </Box>

      <DialogContent sx={{ minHeight: "22vh" }}>
        <Grid container spacing={2}>
          <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
            <Box className="textfield">
              <Typography variant="body2" className="form-label" gutterBottom>
                Rule ID
              </Typography>
              <TextField variant="outlined" fullWidth placeholder="Enter Rule ID" />
            </Box>
          </Grid>
          <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
            <Box className="textfield">
              <Typography variant="body2" className="form-label" gutterBottom>
                Rule Name
              </Typography>
              <TextField variant="outlined" fullWidth placeholder="Enter Rule Name" />
            </Box>
          </Grid>
          <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
            <Box className="textfield">
              <Typography variant="body2" className="form-label" gutterBottom>
                Rule Description
              </Typography>
              <TextField variant="outlined" multiline rows={2} fullWidth placeholder="Enter Rule Description" />
            </Box>
          </Grid>
        </Grid>
      </DialogContent>

      <DialogActions>
        <Button autoFocus className="primary-outlined-btn" onClick={onClose}>
          Cancel
        </Button>
        <Button autoFocus className="primary-btn" onClick={onClose}>
          Add Rule
        </Button>
      </DialogActions>
    </Dialog>
  );
}

