"use client";

import * as React from "react";
import HeaderFooterLayout from "@/components/layout/HeaderFooterLayout/HeaderFooterLayout";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import Tabs from "@mui/material/Tabs";
import Typography from "@mui/material/Typography";
import TableSearch from "@/components/table_components/TableSearch";
import { MdAdd, MdGroups, MdStorefront, MdTune } from "react-icons/md";
import { RiUserAddLine } from "react-icons/ri";
import IconButton from "@mui/material/IconButton";
import UserManagementTable from "./UserManagementTable";
import DealerManagementTable from "./DealerManagementTable";
import ReleConfigTable from "./ReleConfigTable";
import AddUserDialog from "./AddUserDialog";
import AddDealerDialog from "./AddDealerDialog";
import AddRuleDialog from "./AddRuleDialog";
import { Divider, Tooltip } from "@mui/material";

const SECTIONS = [
  { label: "User management", title: "User management", Icon: MdGroups },
  { label: "Dealer management", title: "Dealer management", Icon: MdStorefront },
  { label: "Rule config", title: "Rule config", Icon: MdTune },
];

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`dashboard-tabpanel-${index}`}
      aria-labelledby={`dashboard-tab-${index}`}
      {...other}
    >
      {value === index ? <Box sx={{ pt: 2 }}>{children}</Box> : null}
    </div>
  );
}

function a11yProps(index) {
  return {
    id: `dashboard-tab-${index}`,
    "aria-controls": `dashboard-tabpanel-${index}`,
  };
}

export default function Page() {
  const [value, setValue] = React.useState(0);
  const [addUserOpen, setAddUserOpen] = React.useState(false);
  const [addDealerOpen, setAddDealerOpen] = React.useState(false);
  const [addRuleOpen, setAddRuleOpen] = React.useState(false);

  return (
    <HeaderFooterLayout>
      <Container maxWidth>
        <Box sx={{ width: "100%", mt: 2 }}>
          <Box>
            <Tabs
              value={value}
              onChange={(_, next) => setValue(next)}
              aria-label="Dashboard sections"
              variant="scrollable"
              scrollButtons
              allowScrollButtonsMobile
              sx={{
                minHeight: 36,
                flexShrink: 0,
                "& .MuiTabs-indicator": {
                  height: 3,
                  borderRadius: 999,
                },
                "& .MuiTab-root": {
                  minHeight: 36,
                  px: 1.5,
                  textTransform: "none",
                  fontSize: 12,
                  fontWeight: 600,
                  color: "text.secondary",
                  minWidth: "auto",
                },
                "& .MuiTab-root.Mui-selected": { color: "text.primary" },
              }}
            >
              {SECTIONS.map((section, index) => {
                const Icon = section.Icon;
                return (
                  <Tab
                    key={section.label}
                    icon={<Icon size={18} aria-hidden />}
                    iconPosition="start"
                    label={section.label}
                    {...a11yProps(index)}
                  />
                );
              })}
            </Tabs>
          </Box>

          {SECTIONS.map((section, index) => (
            <TabPanel key={section.label} value={value} index={index}>
              <Box className="whitebx">
                <Box className="fx_sb" sx={{ pb: 1 }}>
                  <Typography variant="h6" className="table-heading" sx={{ flexShrink: 0 }}>
                    {section.title}
                  </Typography>

                  <Box className="fx_fs gap2" sx={{ alignItems: "center", flexWrap: "wrap" }}>
                    {index === 0 ? (
                      <Tooltip arrow placement="top" title="Add User">
                        <IconButton aria-label="Add user" onClick={() => setAddUserOpen(true)}>
                          <RiUserAddLine size={20} aria-hidden />
                        </IconButton>
                      </Tooltip>
                    ) : null}
                    {index === 1 ? (
                      <Tooltip arrow placement="top" title="Add Dealer">
                        <IconButton aria-label="Add dealer" onClick={() => setAddDealerOpen(true)}>
                          <RiUserAddLine size={20} aria-hidden />
                        </IconButton>
                      </Tooltip>
                    ) : null}
                    {index === 2 ? (
                      <Tooltip arrow placement="top" title="Add Rule">
                        <IconButton aria-label="Add rule" onClick={() => setAddRuleOpen(true)}>
                          <RiUserAddLine size={20} aria-hidden />
                        </IconButton>
                      </Tooltip>
                    ) : null}
                    <TableSearch /> 
                  </Box>
                </Box>
                {index === 0 ? <UserManagementTable onEdit={() => setAddUserOpen(true)} /> : null}
                {index === 1 ? <DealerManagementTable onEdit={() => setAddDealerOpen(true)} /> : null}
                {index === 2 ? <ReleConfigTable /> : null}
              </Box>
            </TabPanel>
          ))}
        </Box>
      </Container>

      <AddUserDialog open={addUserOpen} onClose={() => setAddUserOpen(false)} />
      <AddDealerDialog open={addDealerOpen} onClose={() => setAddDealerOpen(false)} />
      <AddRuleDialog open={addRuleOpen} onClose={() => setAddRuleOpen(false)} />
    </HeaderFooterLayout>
  );
}
