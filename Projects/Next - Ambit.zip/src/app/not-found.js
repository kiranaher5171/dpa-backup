"use client"; 
import HeaderFooterLayout from "@/components/layout/HeaderFooterLayout/HeaderFooterLayout";
import { Box, Button, Typography } from "@mui/material";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

const Page = () => {
  const [countdown, setCountdown] = useState(5);
  const router = useRouter();

  useEffect(() => {
    // Set up the countdown timer
    const timer = setInterval(() => {
      setCountdown((prevCount) => {
        if (prevCount === 1) {
          // Redirect when countdown reaches 1
          clearInterval(timer);
          // Use a setTimeout to delay the push, avoiding the render issue
          setTimeout(() => router.push("/"), 0);
        }
        return prevCount - 1;
      });
    }, 1000);

    return () => clearInterval(timer); // Cleanup timer on component unmount
  }, [router]);

  return (
    <HeaderFooterLayout> 
        <Box
          sx={{
            minHeight: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "100%",
          }}
        >
          <Box className="center">
            <Image
              src="/under-development.webp"
              loading="lazy"
              draggable="false"
              alt="under construction"
              height={300}
              width={400}
            />
           <Box sx={{mt: 5}}>
           <Typography variant="h5">
              The page you are asking for is Not Found. It may be under
              construction.
            </Typography>
            <Typography variant="h5">
              Redirecting to homepage in {countdown} seconds.
            </Typography>
           </Box>
         <Box className="fx_c" sx={{ mt: 3 }}>
         <Button variant="contained" color="primary" className="primary-btn" onClick={() => router.push("/")}>
          Click here to go back to login page
          </Button>
         </Box>
          </Box>
        </Box> 
      </HeaderFooterLayout>
  );
};

export default Page;
