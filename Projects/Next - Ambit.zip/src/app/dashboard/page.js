import HeaderFooterLayout from "@/components/layout/HeaderFooterLayout/HeaderFooterLayout";
import LeadershipDashboard from "./LeadershipDashboard";

export default function Page() {
  return (
    <HeaderFooterLayout>
      <LeadershipDashboard />
    </HeaderFooterLayout>
  );
}
