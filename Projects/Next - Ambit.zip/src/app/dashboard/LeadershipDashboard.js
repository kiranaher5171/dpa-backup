"use client";

import * as React from "react";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Grid from "@mui/material/Grid";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import dynamic from "next/dynamic";
import Skeleton from "@mui/material/Skeleton";
import { legendClasses } from "@mui/x-charts/ChartsLegend";
import MetricCard from "@/components/MetricCard";
import {
  MdCheckCircle,
  MdDownload,
  MdFlag,
  MdPendingActions,
  MdSchedule,
  MdShowChart,
  MdTimerOff,
} from "react-icons/md";
import {
  Menubar,
  MenuRoot,
  MenuTrigger,
  MenuPortal,
  MenuPositioner,
  MenuPopup,
  MenuItem,
} from "../call-summary/components/Menubar";
import "../call-summary/menubar.css";

const PieChart = dynamic(() => import("@mui/x-charts/PieChart").then((m) => m.PieChart), {
  ssr: false,
  loading: () => <Skeleton variant="rounded" width="100%" height={280} />,
});
const BarChart = dynamic(() => import("@mui/x-charts/BarChart").then((m) => m.BarChart), {
  ssr: false,
  loading: () => <Skeleton variant="rounded" width="100%" height={280} />,
});
const LineChart = dynamic(() => import("@mui/x-charts/LineChart").then((m) => m.LineChart), {
  ssr: false,
  loading: () => <Skeleton variant="rounded" width="100%" height={280} />,
});

const BUSINESS_OPTIONS = ["All", "Ambit Broking", "Ambit Capital"];
const TIME_PRESET_OPTIONS = ["day", "week", "MTD", "QTD", "YTD"];

const LEADERSHIP_KPIS = [
  {
    key: "processed",
    label: "Processed",
    value: 154,
    accent: "#d32f2f",
    icon: MdShowChart,
  },
  {
    key: "cleared",
    label: "Cleared",
    value: 110,
    accent: "#00897b",
    icon: MdCheckCircle,
  },
  {
    key: "flagged",
    label: "Flagged",
    value: 44,
    accent: "#7b241c",
    icon: MdFlag,
  },
  {
    key: "unresolved",
    label: "Unresolved",
    value: 18,
    accent: "#f9a825",
    icon: MdPendingActions,
  },
  {
    key: "aging",
    label: "Avg aging",
    value: "4.2d",
    accent: "#455a64",
    icon: MdSchedule,
  },
  {
    key: "tat",
    label: "TAT breach",
    value: 3,
    accent: "#d32f2f",
    icon: MdTimerOff,
  },
];

const STATUS_PIE = [
  { id: "unseen", value: 28, label: "Unseen", color: "#fb8c00" },
  { id: "review", value: 19, label: "Under Review", color: "#d32f2f" },
  { id: "esc", value: 11, label: "Escalated", color: "#00897b" },
  { id: "closed", value: 31, label: "Closed", color: "#546e7a" },
  { id: "fp", value: 5, label: "False Positive", color: "#9e9e9e" },
];

const AGING_PIE = [
  { id: "gt10", value: 12, label: "> 10 days", color: "#c62828" },
  { id: "5_10", value: 18, label: "5–10 days", color: "#ef6c00" },
  { id: "3_5", value: 25, label: "3–5 days", color: "#ffb74d" },
  { id: "lt3", value: 39, label: "< 3 days", color: "#00897b" },
];

const BRANCH_BARS = { categories: ["Mumbai", "Bangalore", "Delhi"], values: [20, 16, 12] };

const MONTHS = ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr"];
const VIOLATION_TREND = [9, 14, 12, 18, 11, 15, 21];

const DEALERS = ["Sarah Collins", "Emma Wright", "James Porter", "Michael Hughes", "Rachel Morgan"];
const DEALER_FLAGS = [42, 38, 32, 28, 24];

const DEALER_BAR_COLORS = ["#4fc3f7", "#78909c", "#e57373", "#26a69a", "#ffb74d"];

function dealerBenchmarkBarLabel(item, context) {
  const name = DEALERS[item.dataIndex];
  const v = item.value;
  if (name == null || v == null) return null;
  const full = `${name}: ${v}`;
  const w = context.bar.width;
  if (w < 52) return String(v);
  if (w < 140) {
    const short = name.length > 12 ? `${name.slice(0, 11)}…` : name;
    return `${short}: ${v}`;
  }
  return full;
}

function SummaryFilterMenu({ value, onChange, options }) {
  return (
    <MenuRoot>
      <MenuTrigger className="summary-logs-menu-trigger summary-logs-filter-trigger" type="button">
        {value}
      </MenuTrigger>
      <MenuPortal>
        <MenuPositioner sideOffset={4} alignOffset={0}>
          <MenuPopup className="summary-logs-menu-popup">
            {options.map((opt) => (
              <MenuItem
                key={opt}
                type="button"
                className="summary-logs-menu-item"
                onClick={() => onChange(opt)}
              >
                {opt}
              </MenuItem>
            ))}
          </MenuPopup>
        </MenuPositioner>
      </MenuPortal>
    </MenuRoot>
  );
}

function LeadershipMetricCard({ label, value, accent, icon }) {
  return <MetricCard label={label} value={value} accent={accent} icon={icon} />;
}

function ChartCard({ title, subtitle, children }) {
  return (
    <Box className="whitebx" sx={{ p: 2, height: "100%", minHeight: 320 }}>
      <Stack
        direction="row"
        sx={{ mb: 1, alignItems: "flex-start", justifyContent: "space-between" }}
      >
        <Typography variant="subtitle1" className="table-heading" sx={{ fontWeight: 700 }}>
          {title}
        </Typography>
        {subtitle ? (
          <Typography variant="caption" color="text.secondary">
            {subtitle}
          </Typography>
        ) : null}
      </Stack>
      <Box sx={{ width: "100%", overflow: "hidden" }}>{children}</Box>
    </Box>
  );
}

export default function LeadershipDashboard() {
  const [business, setBusiness] = React.useState("All");
  const [timePreset, setTimePreset] = React.useState("day");
  const [fromDate, setFromDate] = React.useState("");
  const [toDate, setToDate] = React.useState("");

  return (
    <Container maxWidth>

      <Box
        className="whitebx"
        sx={{
          p: 2,
          my: 2,
          display: "flex",
          flexWrap: "wrap",
          alignItems: "flex-end",
          gap: 2,
          justifyContent: "space-between",
        }}
      >
        <Stack direction="row" spacing={1} gap={2} sx={{ flexWrap: "wrap", alignItems: "flex-end" }}>
          <Box sx={{ minWidth: 200, maxWidth: 240 }}>
            <Box className="textfield auto-complete">
              <Typography variant="body2" className="form-label" gutterBottom>
                Business
              </Typography>
              <Autocomplete
                options={BUSINESS_OPTIONS}
                value={business}
                onChange={(_e, next) => setBusiness(next ?? "All")}
                renderInput={(params) => <TextField {...params} placeholder="Select..." />}
              />
            </Box>
          </Box>
          <Box sx={{ minWidth: 160, maxWidth: 200 }}>
            <Box className="textfield">
              <Typography variant="body2" className="form-label" gutterBottom>
                From
              </Typography>
              <TextField
                type="date"
                variant="outlined"
                fullWidth
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
              />
            </Box>
          </Box>
          <Box sx={{ minWidth: 160, maxWidth: 200 }}>
            <Box className="textfield">
              <Typography variant="body2" className="form-label" gutterBottom>
                To
              </Typography>
              <TextField
                type="date"
                variant="outlined"
                fullWidth
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
              />
            </Box>
          </Box>
        </Stack>
        <Button
          variant="contained"
          startIcon={<MdDownload size={18} />}
          className="primary-btn"
        >
          Download
        </Button>
      </Box>

      <Grid container spacing={2} sx={{ mb: 2 }}>
        {LEADERSHIP_KPIS.map((k) => (
          <Grid key={k.key} size={{ xs: 12, sm: 6, md: 4, lg: 2 }}>
            <LeadershipMetricCard label={k.label} value={k.value} accent={k.accent} icon={k.icon} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid size={{ xs: 12, md: 4 }}>
          <ChartCard title="Flagged by status">
            <PieChart
              series={[
                {
                  innerRadius: 48,
                  outerRadius: 88,
                  paddingAngle: 2,
                  cornerRadius: 4,
                  data: STATUS_PIE,
                },
              ]}
              width={320}
              height={260}
              slotProps={{ legend: { direction: "vertical", position: { vertical: "middle", horizontal: "right" } } }}
            />
          </ChartCard>
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <ChartCard title="Flagged by aging">
            <PieChart
              series={[
                {
                  innerRadius: 48,
                  outerRadius: 88,
                  paddingAngle: 2,
                  cornerRadius: 4,
                  data: AGING_PIE,
                },
              ]}
              width={320}
              height={260}
              slotProps={{ legend: { direction: "vertical", position: { vertical: "middle", horizontal: "right" } } }}
            />
          </ChartCard>
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <ChartCard title="Flags by branch">
            <BarChart
              sx={{ width: "100%", maxWidth: "100%" }}
              xAxis={[
                {
                  scaleType: "band",
                  data: BRANCH_BARS.categories,
                  tickLabelStyle: { fontSize: 11 },
                  height: 28,
                },
              ]}
              yAxis={[
                {
                  min: 0,
                  max: 22,
                  width: 32,
                  tickSize: 4,
                  tickLabelStyle: { fontSize: 11 },
                },
              ]}
              series={[{ type: "bar", data: BRANCH_BARS.values, color: "#d32f2f", label: "Flags" }]}
              height={260}
              margin={{ left: 2, right: 8, top: 4, bottom: 28 }}
              grid={{ horizontal: true }}
              slotProps={{
                legend: {
                  direction: "horizontal",
                  position: { vertical: "bottom", horizontal: "left" },
                  padding: 0,
                  sx: {
                    [`& .${legendClasses.mark}`]: { width: 10, height: 10 },
                    [`& .${legendClasses.label}`]: { fontSize: 11 },
                  },
                },
              }}
            />
          </ChartCard>
        </Grid>
      </Grid>

      <Box sx={{ mb: 2 }}>
        <ChartCard title="Historical violation frequency">
          <LineChart
            sx={{ width: "100%", maxWidth: "100%" }}
            xAxis={[
              {
                scaleType: "point",
                data: MONTHS,
                tickLabelStyle: { fontSize: 11 },
                height: 28,
              },
            ]}
            yAxis={[
              {
                width: 32,
                tickSize: 4,
                tickLabelStyle: { fontSize: 11 },
              },
            ]}
            series={[
              {
                data: VIOLATION_TREND,
                color: "#d32f2f",
                curve: "natural",
                area: false,
              },
            ]}
            height={280}
            margin={{ left: 2, right: 12, top: 8, bottom: 20 }}
            grid={{ horizontal: true }}
          />
        </ChartCard>
      </Box>

      <Box sx={{ mb: 3 }}>
        <ChartCard title="Dealer benchmarking">
          <BarChart
            sx={{ width: "100%", maxWidth: "100%" }}
            layout="horizontal"
            borderRadius={4}
            hideLegend
            xAxis={[
              {
                min: 0,
                max: 50,
                tickLabelStyle: { fontSize: 11 },
              },
            ]}
            yAxis={[
              {
                scaleType: "band",
                data: DEALERS,
                width: 0,
                position: "none",
                disableLine: true,
                disableTicks: true,
                categoryGapRatio: 0.12,
              },
            ]}
            series={[
              {
                type: "bar",
                id: "dealer-benchmark-flagged",
                data: DEALER_FLAGS,
                label: "Flagged",
                color: "#e53935",
                colorGetter: ({ dataIndex }) =>
                  DEALER_BAR_COLORS[dataIndex % DEALER_BAR_COLORS.length],
                barLabel: dealerBenchmarkBarLabel,
                barLabelPlacement: "center",
              },
            ]}
            height={280}
            margin={{ left: 6, right: 12, top: 4, bottom: 8 }}
            grid={{ horizontal: true }}
            slotProps={{
              barLabel: {
                style: {
                  fill: "#fff",
                  fontSize: 11,
                  fontWeight: 600,
                  stroke: "rgba(0,0,0,0.32)",
                  strokeWidth: 0.55,
                  paintOrder: "stroke fill",
                },
              },
            }}
          />
        </ChartCard>
      </Box>
    </Container>
  );
}
