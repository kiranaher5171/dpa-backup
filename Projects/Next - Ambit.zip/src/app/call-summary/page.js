"use client";

import * as React from "react";
import HeaderFooterLayout from "@/components/layout/HeaderFooterLayout/HeaderFooterLayout";
import SummaryLogsTable from "./SummaryLogsTable";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import LinearProgress from "@mui/material/LinearProgress";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { HiArrowSmLeft } from "react-icons/hi";
import {
    Menubar,
    MenuRoot,
    MenuTrigger,
    MenuPortal,
    MenuPositioner,
    MenuPopup,
    MenuItem,
} from "./components/Menubar";
import "./menubar.css";
import { Grid } from "@mui/material";
import dynamic from "next/dynamic";
import Skeleton from "@mui/material/Skeleton";
import { legendClasses } from "@mui/x-charts/ChartsLegend";
import UploadRecordingPanel from "./components/UploadRecordingPanel";
import ProcessingStatusPanel from "./components/ProcessingStatusPanel";
import MetricCard from "@/components/MetricCard";
import { MdUploadFile, MdOutlineHourglassTop } from "react-icons/md";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";

const BarChart = dynamic(() => import("@mui/x-charts/BarChart").then((m) => m.BarChart), {
    ssr: false,
    loading: () => <Skeleton variant="rounded" width="100%" height={260} />,
});
const PieChart = dynamic(() => import("@mui/x-charts/PieChart").then((m) => m.PieChart), {
    ssr: false,
    loading: () => <Skeleton variant="rounded" width="100%" height={260} />,
});

const BUSINESS_OPTIONS = ["All", "Ambit Broking", "Ambit Capital"];

const TIME_PRESET_OPTIONS = ["day", "week", "MTD", "QTD", "YTD"];

const BRANCH_OPTIONS = ["All", "Mumbai", "Bangalore", "Delhi"];

const DEALER_OPTIONS = [
    "All",
    "James Porter",
    "Sarah Collins",
    "Michael Hughes",
    "Emma Wright",
    "David Foster",
    "Rachel Morgan",
    "Tom Bennett",
    "Lucy Hayes",
];

const FLAG_OPTIONS = ["All", "Cleared", "Flagged", "Skipped"];

const SEVERITY_OPTIONS = ["All", "Critical", "High", "Medium", "-"];

const STATUS_OPTIONS = [
    "All",
    "Unseen",
    "Under Review",
    "Escalated",
    "Closed",
    "False Positive",
];

function formatTimePresetLabel(preset) {
    if (!preset) return "";
    const upper = preset.toUpperCase();
    if (["MTD", "QTD", "YTD"].includes(upper)) return upper;
    return preset.charAt(0).toUpperCase() + preset.slice(1).toLowerCase();
}

function processedSubLabel(timePreset, business) {
    const period = formatTimePresetLabel(timePreset) || "Period";
    const biz = business || "Business";
    return `${period} · ${biz}`;
}

const CALLS_BY_BRANCH_LABELS = ["Mumbai", "Bangalore", "Delhi"];
const CALLS_BY_BRANCH_CLEARED = [45, 50, 42];
const CALLS_BY_BRANCH_FLAGGED = [15, 25, 10];

const VIOLATION_RULE_LABELS = [
    "Market Recommendation",
    "Trade Confirmation",
    "Price",
    "TM Code",
    "Securities Code",
    "Client Confidentiality",
    "Quantity",
    "Price Guarantee",
];
const VIOLATION_RULE_COUNTS = [12, 10, 9, 8, 7, 6, 5, 4];

const VIOLATION_BAR_COLORS = [
    "#4fc3f7",
    "#78909c",
    "#e57373",
    "#26a69a",
    "#bcaaa4",
    "#00897b",
    "#ffb74d",
    "#81d4fa",
];

function violationRuleBarLabel(item, context) {
    const name = VIOLATION_RULE_LABELS[item.dataIndex];
    const v = item.value;
    if (name == null || v == null) return null;
    const full = `${name}: ${v}`;
    const w = context.bar.width;
    if (w < 52) return String(v);
    if (w < 130) {
        const short = name.length > 10 ? `${name.slice(0, 9)}…` : name;
        return `${short}: ${v}`;
    }
    return full;
}

const FLAGGED_BY_STATUS_PIE = [
    { id: "unseen", value: 28, label: "Unseen", color: "#fb8c00" },
    { id: "review", value: 19, label: "Under Review", color: "#6d4c41" },
    { id: "esc", value: 11, label: "Escalated", color: "#e53935" },
    { id: "closed", value: 31, label: "Closed", color: "#00897b" },
    { id: "fp", value: 5, label: "False Positive", color: "#bdbdbd" },
];

function SummaryChartCard({ title, children, chartMinHeight = 240, chartAlign = "center" }) {
    return (
        <Box
            className="whitebx"
            sx={{
                height: "100%",
                minHeight: 300,
                p: 2,
                display: "flex",
                flexDirection: "column",
            }}
        >
            <Typography variant="subtitle1" className="table-heading" sx={{ fontWeight: 700, mb: 1, flexShrink: 0 }}>
                {title}
            </Typography>
            <Box
                sx={{
                    flex: 1,
                    width: "100%",
                    minHeight: chartMinHeight,
                    display: "flex",
                    alignItems: chartAlign === "start" ? "flex-start" : "center",
                    justifyContent: chartAlign === "start" ? "flex-start" : "center",
                }}
            >
                {children}
            </Box>
        </Box>
    );
}

const SUMMARY_KPI_STATS = [
    {
        key: "processed",
        value: 15,
        label: "Calls processed",
        subLabel1: "Day · All", 
        accent: "#e53935",
    },
    {
        key: "cleared",
        value: 6,
        label: "Cleared",
        subLabel1: "No violations found", 
        accent: "#00897b",
    },
    {
        key: "flagged",
        value: 8,
        label: "Flagged",
        subLabel1: "Require attention", 
        accent: "#b71c1c",
    },
    {
        key: "unresolved",
        value: 8,
        label: "Unresolved",
        subLabel1: "Open flagged calls", 
        accent: "#fb8c00",
    },
];

function SummaryMetricCard({ value, label, subLabel1, subLabel2, accent, icon }) {
    return (
        <MetricCard
            label={label}
            value={value}
            accent={accent}
            tileText={value}
            hideValue
            subLabel1={subLabel1}
            subLabel2={subLabel2}
        />
    );
}

function SummaryFilterMenu({ value, onChange, options, formatLabel = (v) => v, placeholder }) {
    return (
        <MenuRoot>
            <MenuTrigger className="summary-logs-menu-trigger summary-logs-filter-trigger" type="button">
                {value ? formatLabel(value) : placeholder}
            </MenuTrigger>
            <MenuPortal>
                <MenuPositioner sideOffset={4} alignOffset={0}>
                    <MenuPopup className="summary-logs-menu-popup">
                        {options.map((opt) => (
                            <MenuItem
                                key={opt}
                                type="button"
                                className="summary-logs-menu-item"
                                onClick={() => onChange(opt)}
                            >
                                {formatLabel(opt)}
                            </MenuItem>
                        ))}
                    </MenuPopup>
                </MenuPositioner>
            </MenuPortal>
        </MenuRoot>
    );
}

export default function Page() {
    const [business, setBusiness] = React.useState("All");
    const [timePreset, setTimePreset] = React.useState("day");
    const [fromDate, setFromDate] = React.useState("");
    const [toDate, setToDate] = React.useState("");
    const [rightTab, setRightTab] = React.useState(null); // null = no selection
    const [branch, setBranch] = React.useState("All");
    const [dealer, setDealer] = React.useState("All");
    const [flag, setFlag] = React.useState("All");
    const [severity, setSeverity] = React.useState("All");
    const [status, setStatus] = React.useState("All");

    return (
        <HeaderFooterLayout>
            <Container maxWidth>
                <Box
                    sx={{
                        width: "100%",
                        mt: 2,
                        display: "flex",
                        alignItems: "center",
                        flexWrap: "wrap",
                        justifyContent: "space-between",
                        gap: 1,
                    }}
                >
                    <Box
                        sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "flex-start",
                            gap: 1,
                            minWidth: 0,
                        }}
                    >
                        {rightTab ? (
                            <Button
                                variant="text"
                                size="small"
                                startIcon={<HiArrowSmLeft fontSize="small" />}
                                onClick={() => setRightTab(null)}
                                className="back-btn"
                                disableRipple
                            >
                                Back to summary
                            </Button>
                        ) : (
                            <Box sx={{ display: "flex", alignItems: "flex-end", gap: 2, flexWrap: "wrap" }}>
                                <Box sx={{ minWidth: 160, maxWidth: 220 }}>
                                    <Box className="textfield auto-complete">
                                        <Typography variant="body2" className="form-label" gutterBottom>
                                            Business
                                        </Typography>
                                        <Autocomplete
                                            options={BUSINESS_OPTIONS}
                                            value={business}
                                            onChange={(_e, next) => setBusiness(next ?? "All")}
                                            renderInput={(params) => <TextField {...params} placeholder="All" />}
                                        />
                                    </Box>
                                </Box>

                       

                                <Box sx={{ minWidth: 160, maxWidth: 200 }}>
                                    <Box className="textfield">
                                        <Typography variant="body2" className="form-label" gutterBottom>
                                            From
                                        </Typography>
                                        <TextField
                                            type="date"
                                            variant="outlined"
                                            fullWidth
                                            value={fromDate}
                                            onChange={(e) => setFromDate(e.target.value)}
                                        />
                                    </Box>
                                </Box>

                                <Box sx={{ minWidth: 160, maxWidth: 200 }}>
                                    <Box className="textfield">
                                        <Typography variant="body2" className="form-label" gutterBottom>
                                            To
                                        </Typography>
                                        <TextField
                                            type="date"
                                            variant="outlined"
                                            fullWidth
                                            value={toDate}
                                            onChange={(e) => setToDate(e.target.value)}
                                        />
                                    </Box>
                                </Box>
                            </Box>
                        )}
                    </Box>

                    <Box
                        sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "flex-end",
                            gap: 1,
                            flexWrap: "nowrap",
                            maxWidth: "100%",
                            overflowX: "auto",
                            minWidth: 0,
                            "&::-webkit-scrollbar": { display: "none" },
                            scrollbarWidth: "none",
                        }}
                    >
                        <Tabs
                            value={rightTab ?? false}
                            onChange={(_, next) => setRightTab((prev) => (prev === next ? null : next))}
                            variant="standard"
                            sx={{
                                minHeight: 36,
                                flexShrink: 0,
                                "& .MuiTabs-indicator": {
                                    height: 3,
                                    borderRadius: 999,
                                },
                                "& .MuiTab-root": {
                                    minHeight: 36,
                                    px: 1.5,
                                    textTransform: "none",
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "text.secondary",
                                    minWidth: "auto",
                                },
                                "& .MuiTab-root.Mui-selected": { color: "text.primary" },
                            }}
                        >
                            <Tab
                                value="upload"
                                label="Upload a recording"
                                icon={<MdUploadFile size={18} aria-hidden />}
                                iconPosition="start"
                            />
                            <Tab
                                value="status"
                                label="Processing status"
                                icon={<MdOutlineHourglassTop size={18} aria-hidden />}
                                iconPosition="start"
                            />
                        </Tabs>
                    </Box>
                </Box>

                {rightTab === "upload" ? <UploadRecordingPanel /> : null}
                {rightTab === "status" ? <ProcessingStatusPanel /> : null}

                {rightTab == null ? (
                <>
                <Box sx={{ width: "100%", mt: 2 }}>
                    <Grid container spacing={2} sx={{ alignItems: "center" }}>
                        {SUMMARY_KPI_STATS.map((stat) => (
                            <Grid key={stat.key} size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
                                <SummaryMetricCard
                                    value={stat.value}
                                    label={stat.label}
                                    subLabel1={
                                        stat.key === "processed"
                                            ? processedSubLabel(timePreset, business)
                                            : stat.subLabel1
                                    }
                                    subLabel2={stat.subLabel2}
                                    accent={stat.accent}
                                />
                            </Grid>
                        ))}
                    </Grid>
                </Box>

                <Box sx={{ width: "100%", mt: 2 }}>
                    <Grid container spacing={2}>
                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <SummaryChartCard title="Calls by branch" chartAlign="start">
                                <BarChart
                                    sx={{ width: "100%", maxWidth: "100%" }}
                                    xAxis={[
                                        {
                                            scaleType: "band",
                                            data: CALLS_BY_BRANCH_LABELS,
                                            height: 28,
                                            tickLabelStyle: { fontSize: 11 },
                                        },
                                    ]}
                                    yAxis={[
                                        {
                                            min: 0,
                                            max: 60,
                                            width: 34,
                                            tickSize: 4,
                                            tickLabelStyle: { fontSize: 11 },
                                        },
                                    ]}
                                    series={[
                                        {
                                            type: "bar",
                                            data: CALLS_BY_BRANCH_CLEARED,
                                            label: "Cleared",
                                            color: "#00897b",
                                        },
                                        {
                                            type: "bar",
                                            data: CALLS_BY_BRANCH_FLAGGED,
                                            label: "Flagged",
                                            color: "#c62828",
                                        },
                                    ]}
                                    height={250}
                                    margin={{ left: 2, right: 4, top: 2, bottom: 14 }}
                                    grid={{ horizontal: true }}
                                    slotProps={{
                                        legend: {
                                            direction: "horizontal",
                                            position: { vertical: "bottom", horizontal: "left" },
                                            padding: 0,
                                            sx: {
                                                [`& .${legendClasses.mark}`]: { width: 10, height: 10 },
                                                [`& .${legendClasses.label}`]: { fontSize: 11 },
                                            },
                                        },
                                    }}
                                />
                            </SummaryChartCard>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <SummaryChartCard title="Violations by rule" chartMinHeight={260} chartAlign="start">
                                <BarChart
                                    sx={{ width: "100%", maxWidth: "100%" }}
                                    layout="horizontal"
                                    borderRadius={4}
                                    hideLegend
                                    xAxis={[
                                        {
                                            min: 0,
                                            max: 14,
                                            tickLabelStyle: { fontSize: 11 },
                                        },
                                    ]}
                                    yAxis={[
                                        {
                                            scaleType: "band",
                                            data: VIOLATION_RULE_LABELS,
                                            width: 0,
                                            position: "none",
                                            disableLine: true,
                                            disableTicks: true,
                                            categoryGapRatio: 0.12,
                                        },
                                    ]}
                                    series={[
                                        {
                                            type: "bar",
                                            id: "violations-by-rule",
                                            data: VIOLATION_RULE_COUNTS,
                                            label: "Violations",
                                            color: "#00897b",
                                            colorGetter: ({ dataIndex }) =>
                                                VIOLATION_BAR_COLORS[dataIndex % VIOLATION_BAR_COLORS.length],
                                            barLabel: violationRuleBarLabel,
                                            barLabelPlacement: "center",
                                        },
                                    ]}
                                    height={270}
                                    margin={{ left: 6, right: 10, top: 4, bottom: 8 }}
                                    grid={{ horizontal: true }}
                                    slotProps={{
                                        barLabel: {
                                            style: {
                                                fill: "#fff",
                                                fontSize: 11,
                                                fontWeight: 600,
                                                stroke: "rgba(0,0,0,0.32)",
                                                strokeWidth: 0.55,
                                                paintOrder: "stroke fill",
                                            },
                                        },
                                    }}
                                />
                            </SummaryChartCard>
                        </Grid>

                        <Grid size={{ lg: 4, md: 4, sm: 6, xs: 12 }}>
                            <SummaryChartCard title="Flagged by status">
                                <PieChart
                                    series={[
                                        {
                                            innerRadius: 44,
                                            outerRadius: 78,
                                            paddingAngle: 2,
                                            cornerRadius: 3,
                                            data: FLAGGED_BY_STATUS_PIE,
                                        },
                                    ]}
                                    width={320}
                                    height={248}
                                    margin={{ left: 8, right: 8, top: 4, bottom: 4 }}
                                    slotProps={{
                                        legend: {
                                            direction: "vertical",
                                            position: { vertical: "middle", horizontal: "left" },
                                        },
                                    }}
                                />
                            </SummaryChartCard>
                        </Grid>
                    </Grid>
                </Box>

                <Box className="whitebx" sx={{ width: "100%", my: 2 }}>
                    <Box className="fx_sb" sx={{ pb: 1, alignItems: "center", gap: 2, flexWrap: "wrap" }}>
                        <Typography variant="h6" className="table-heading" sx={{ flexShrink: 0 }}>
                            Summary Logs
                        </Typography>
                        <Box sx={{ flexShrink: 0 }}>
                            <Menubar className="summary-logs-menubar">
                                <SummaryFilterMenu value={branch} onChange={setBranch} options={BRANCH_OPTIONS} />
                                <SummaryFilterMenu value={dealer} onChange={setDealer} options={DEALER_OPTIONS} />
                                <SummaryFilterMenu value={flag} onChange={setFlag} options={FLAG_OPTIONS} />
                                <SummaryFilterMenu value={severity} onChange={setSeverity} options={SEVERITY_OPTIONS} />
                                <SummaryFilterMenu value={status} onChange={setStatus} options={STATUS_OPTIONS} />
                            </Menubar>
                        </Box>
                    </Box>
                    <SummaryLogsTable />
                </Box>
                </>
                ) : null}
            </Container>
        </HeaderFooterLayout>
    );
}
