"use client";

import * as React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";

function StatusPill({ status }) {
  const palette = (() => {
    switch (status) {
      case "Complete":
        return { bg: "rgb(232, 245, 233)", fg: "rgb(46, 125, 50)" };
      case "Processing":
        return { bg: "rgb(255, 235, 238)", fg: "rgb(198, 40, 40)" };
      case "Queued":
        return { bg: "rgb(227, 242, 253)", fg: "rgb(21, 101, 192)" };
      case "Skipped":
        return { bg: "rgb(255, 248, 225)", fg: "rgb(245, 127, 23)" };
      case "Failed":
      default:
        return { bg: "rgb(253, 236, 236)", fg: "rgb(211, 47, 47)" };
    }
  })();

  return (
    <Box
      component="span"
      sx={{
        bgcolor: palette.bg,
        color: palette.fg,
        borderRadius: "6px",
        fontSize: 11,
        fontWeight: 700,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        height: 22,
        px: 1,
        minWidth: 82,
        textTransform: "capitalize",
        gap: 0.75,
      }}
    >
      <Box
        component="span"
        sx={{
          width: 6,
          height: 6,
          borderRadius: 99,
          bgcolor: palette.fg,
          display: "inline-block",
        }}
        aria-hidden
      />
      {status}
    </Box>
  );
}

function StageBar({ value = 0, color = "#e53935" }) {
  return (
    <Box
      sx={{
        height: 6,
        width: 96,
        borderRadius: 99,
        bgcolor: "rgba(15, 23, 42, 0.08)",
        overflow: "hidden",
      }}
    >
      <Box sx={{ height: "100%", width: `${Math.max(0, Math.min(100, value))}%`, bgcolor: color }} />
    </Box>
  );
}

export default function ProcessingStatusTable({ rows }) {
  return (
    <Box
      sx={{
        border: "1px solid rgba(15, 23, 42, 0.08)",
        borderRadius: 2,
        overflow: "hidden",
        bgcolor: "#fff",
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "2fr 1.2fr 1fr 1fr 1fr 1.2fr",
          gap: 0,
          px: 1.5,
          py: 1,
          bgcolor: "rgba(15, 23, 42, 0.03)",
          borderBottom: "1px solid rgba(15, 23, 42, 0.08)",
        }}
      >
        {["File", "Dealer", "Branch", "Duration", "Stage", "Status"].map((h) => (
          <Typography key={h} variant="caption" sx={{ fontWeight: 800, letterSpacing: "0.08em", color: "text.secondary" }}>
            {h.toUpperCase()}
          </Typography>
        ))}
      </Box>

      {rows.map((r) => (
        <Box
          key={r.id}
          sx={{
            display: "grid",
            gridTemplateColumns: "2fr 1.2fr 1fr 1fr 1fr 1.2fr",
            px: 1.5,
            py: 1.05,
            borderBottom: "1px solid rgba(15, 23, 42, 0.06)",
            alignItems: "center",
          }}
        >
          <Typography sx={{ fontSize: 12, fontWeight: 700, color: "#b71c1c" }} noWrap title={r.file}>
            {r.file}
          </Typography>
          <Typography sx={{ fontSize: 12 }} noWrap title={r.dealer}>
            {r.dealer}
          </Typography>
          <Typography sx={{ fontSize: 12 }} noWrap title={r.branch}>
            {r.branch}
          </Typography>
          <Typography sx={{ fontSize: 12 }} noWrap title={r.duration}>
            {r.duration}
          </Typography>
          <StageBar value={r.stagePct} />
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 1 }}>
            <StatusPill status={r.status} />
            {r.status === "Failed" ? (
              <Button size="small" variant="outlined" sx={{ textTransform: "none", fontSize: 11, py: 0.25, px: 1 }}>
                Retry
              </Button>
            ) : null}
          </Box>
        </Box>
      ))}
    </Box>
  );
}

