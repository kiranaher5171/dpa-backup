"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import HeaderFooterLayout from "@/components/layout/HeaderFooterLayout/HeaderFooterLayout";
import WorkflowStepTabs from "@/components/WorkflowStepTabs";
import { HiArrowSmLeft } from "react-icons/hi";
import { Grid } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import { MdPlayArrow, MdDownload } from "react-icons/md";
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa";

export default function DeepDiveReportPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const callId = searchParams.get("callId") ?? "";
  const [askAiQuery, setAskAiQuery] = useState("");
  const [actionTaken, setActionTaken] = useState(null);
  const [aiFeedback, setAiFeedback] = useState("");

  // Dummy data for now (wire API later)
  const details = {
    callId: callId || "CS-10041",
    branch: "Mumbai",
    dealer: "James Porter",
    dateTime: "15 Apr 2026 · 09:02",
    duration: "7m 14s",
    language: "English",
    clientCode: "CLT-10041",
  };

  const transcript = [
    { id: "t1", time: "02:44", speaker: "Client", text: "Okay okay. Let's do it. How many lots?" },
    { id: "t2", time: "03:01", speaker: "Dealer", text: "To say 300 lots on futures, we can hedge with some puts." },
    {
      id: "t3",
      time: "03:22",
      speaker: "Dealer",
      text: "And by the way, keep this between us — don’t mention it to your RM at the bank.",
      violation: { code: "R-09", label: "Discussion of confidential client / supervisory relationship context", severity: "Critical" },
      highlight: "keep this between us — don’t mention it to your RM at the bank",
    },
    { id: "t4", time: "04:18", speaker: "Client", text: "Sure, understood. Let's proceed." },
    {
      id: "t5",
      time: "04:35",
      speaker: "Dealer",
      text: "Perfect. I’ll place the order now and send you the confirmation on WhatsApp.",
      violation: { code: "R-05", label: "Trade confirmation channel / wording not clearly compliant", severity: "Medium" },
      highlight: "send you the confirmation on WhatsApp",
    },
    { id: "t6", time: "05:01", speaker: "Client", text: "Fine. Thanks." },
  ];

  const rules = [
    { code: "R-01", name: "TM Code", status: "Clear" },
    { code: "R-02", name: "Securities Code", status: "Clear" },
    { code: "R-03", name: "Price", status: "Violated", severity: "Medium" },
    { code: "R-04", name: "Quantity", status: "Clear" },
    { code: "R-05", name: "Trade Confirmation", status: "Violated", severity: "Medium" },
    { code: "R-07", name: "Market Recommendation", status: "Violated", severity: "Critical" },
    { code: "R-08", name: "Price Guarantee", status: "Clear" },
  ];

  const workflowSteps = [
    { label: "Unseen", state: "done" },
    { label: "Under Review", state: "active", badge: "2" },
    { label: "Escalated", state: "todo", badge: "3" },
    { label: "Closed", state: "todo", badge: "4" },
  ];

  const workflowMeta = {
    severity: "Critical",
    tat: "2d",
  };

  const actionOptions = ["Review completed", "Escalated to compliance", "Call flagged incorrectly", "Closed - No action"];

  const getSeverityBg = (severity) => {
    if (severity === "Critical") return "rgba(211, 47, 47, 0.08)";
    if (severity === "Medium") return "rgba(245, 124, 0, 0.10)";
    return "transparent";
  };

  const getSeverityChip = (severity) => {
    if (severity === "Critical") return { bg: "rgba(211,47,47,0.14)", fg: "rgb(183, 28, 28)", label: "Critical" };
    if (severity === "Medium") return { bg: "rgba(245,124,0,0.14)", fg: "rgb(156, 82, 0)", label: "Medium" };
    return { bg: "rgba(46,125,50,0.10)", fg: "rgb(46,125,50)", label: "Clear" };
  };

  const handleDownloadReport = () => {
    const report = {
      details,
      transcript,
      rules,
      workflow: {
        steps: workflowSteps,
        meta: workflowMeta,
        actionTaken,
        aiFeedback,
      },
      generatedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `deep-dive-report-${details.callId || "report"}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <HeaderFooterLayout>
      <Box sx={{ width: "100%", p: 2 }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2, flexWrap: "wrap" }}>
          <Button
            variant="text"
            size="small"
            className="back-btn"
            disableRipple
            startIcon={<HiArrowSmLeft fontSize="small" />}
            onClick={() => router.push("/call-summary")}
          >
            Back to summary
          </Button>

          <Button
            variant="outlined"
            size="small"
            className="action-btn action-btn--red"
            startIcon={<MdDownload />}
            sx={{ minWidth: 158, justifyContent: "center" }}
            onClick={handleDownloadReport}
          >
            Download
          </Button>
        </Box>

        <Box className="whitebx" sx={{ mt: 2, p: 2 }}>
          <Grid container spacing={2} sx={{ alignItems: "center" }}>
            <Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>   Call ID</Typography>
                <TextField variant="outlined" fullWidth placeholder="Enter Call ID" />
              </Box>
            </Grid>
            <Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>   Branch</Typography>
                <TextField variant="outlined" fullWidth placeholder="Enter Branch" />
              </Box>
            </Grid>
            <Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>   Dealer</Typography>
                <TextField variant="outlined" fullWidth placeholder="Enter Dealer" />
              </Box>
            </Grid>
            <Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>   Date &amp; Time</Typography>
                <TextField variant="outlined" fullWidth placeholder="Enter Date &amp; Time" />
              </Box>
            </Grid>

            <Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>   Duration</Typography>
                <TextField variant="outlined" fullWidth placeholder="Enter Duration" />
              </Box>
            </Grid>
            <Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>   Language</Typography>
                <TextField variant="outlined" fullWidth placeholder="Enter Language" />
              </Box>
            </Grid>
            <Grid size={{ lg: 3, md: 6, sm: 6, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>   Client Code</Typography>
                <TextField variant="outlined" fullWidth placeholder="Enter Client Code" />
              </Box>
            </Grid>
          </Grid>
        </Box>

        <Box className="whitebx" sx={{ mt: 2, p: 2 }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              gap: 2,
              flexWrap: "wrap",
            }}
          >
            <IconButton
              aria-label="Play"
              sx={{
                width: 44,
                height: 44,
                borderRadius: 999,
                bgcolor: "rgb(211, 47, 47)",
                color: "#fff",
                boxShadow: "0 6px 14px rgba(211, 47, 47, 0.18)",
                "&:hover": { bgcolor: "rgb(183, 28, 28)" },
              }}
              onClick={() => {}}
            >
              <MdPlayArrow style={{ fontSize: 22, marginLeft: 2 }} />
            </IconButton>

            <Box sx={{ flex: "1 1 520px", minWidth: 260 }}>
              <Box
                sx={{
                  height: 42,
                  borderRadius: 2,
                  bgcolor: "#fff",
                  border: "1px solid rgba(15, 23, 42, 0.08)",
                  display: "flex",
                  alignItems: "center",
                  overflow: "hidden",
                  px: 1.5,
                  position: "relative",
                }}
                aria-label="Waveform"
              >
                <Box
                  sx={{
                    width: "100%",
                    height: 20,
                    background:
                      "repeating-linear-gradient(90deg, rgba(15,23,42,0.18) 0 2px, transparent 2px 8px)",
                    opacity: 0.45,
                  }}
                />
                <Box
                  aria-hidden
                  sx={{
                    position: "absolute",
                    left: "52%",
                    top: 6,
                    bottom: 6,
                    width: 3,
                    borderRadius: 999,
                    bgcolor: "rgba(211, 47, 47, 0.8)",
                    boxShadow: "0 0 0 6px rgba(211, 47, 47, 0.06)",
                  }}
                />
              </Box>
              <Box sx={{ display: "flex", justifyContent: "space-between", mt: 0.5 }}>
                <Typography variant="caption" sx={{ color: "text.secondary" }}>
                  00:00
                </Typography>
                <Typography variant="caption" sx={{ color: "text.secondary" }}>
                  {details.duration}
                </Typography>
              </Box>
            </Box>

            <Box sx={{ display: "flex", flexDirection: "column", gap: 1, flexShrink: 0, alignItems: "flex-end" }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <Button variant="outlined" size="small" className="action-btn action-btn--gray" sx={{ minWidth: 56 }}>
                  0.75×
                </Button>
                <Button variant="outlined" size="small" className="action-btn action-btn--gray" sx={{ minWidth: 52 }}>
                  WAV
                </Button>
              </Box>
              <Button
                variant="outlined"
                size="small"
                className="action-btn action-btn--red"
                startIcon={<MdDownload />}
                sx={{ width: 158, justifyContent: "center" }}
                onClick={handleDownloadReport}
              >
                Download
              </Button>
            </Box>
          </Box>
        </Box>

        <Grid container spacing={2} sx={{ mt: 2, alignItems: "stretch" }}>
          <Grid size={{ lg: 8, md: 12, sm: 12, xs: 12 }}>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2, height: "100%" }}>
              <Box className="whitebx" sx={{ p: 2 }}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2, mb: 2 }}>
                  <Typography variant="h6" className="table-heading">
                    English transcript
                  </Typography>
                  <Typography variant="body2" sx={{ color: "text.secondary", fontWeight: 600 }}>
                    4 violations
                  </Typography>
                </Box>

                <Box sx={{ display: "flex", flexDirection: "column", gap: 1, height: "450px", overflow: "auto" }}>
                  {transcript.map((row) => {
                    const sev = row.violation?.severity;
                    const isDealer = row.speaker === "Dealer";
                    return (
                      <Box
                        key={row.id}
                        sx={{
                          border: "1px solid rgba(15, 23, 42, 0.10)",
                          borderRadius: 2,
                          p: 1.25,
                          backgroundColor: row.violation ? getSeverityBg(sev) : "#fff",
                        }}
                      >
                        <Box sx={{ display: "flex", alignItems: "baseline", gap: 1, flexWrap: "wrap" }}>
                          <Typography variant="caption" sx={{ color: "text.secondary", minWidth: 44 }}>
                            {row.time}
                          </Typography>
                          <Typography
                            variant="caption"
                            sx={{
                              fontWeight: 700,
                              color: isDealer ? "rgb(183, 28, 28)" : "rgb(2, 136, 209)",
                              minWidth: 52,
                            }}
                          >
                            {row.speaker}
                          </Typography>

                          <Typography variant="body2" sx={{ color: "text.primary", flex: "1 1 auto" }}>
                            {row.highlight ? (
                              <>
                                {row.text.split(row.highlight)[0]}
                                <Box component="span" sx={{ bgcolor: "rgba(254, 219, 0, 0.55)", px: 0.5, borderRadius: 0.75 }}>
                                  {row.highlight}
                                </Box>
                                {row.text.split(row.highlight)[1]}
                              </>
                            ) : (
                              row.text
                            )}
                          </Typography>
                        </Box>

                        {row.violation ? (
                          <Box
                            sx={{
                              mt: 1,
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "space-between",
                              gap: 1,
                              flexWrap: "wrap",
                            }}
                          >
                            <Typography variant="caption" sx={{ color: "text.secondary" }}>
                              <Box component="span" sx={{ fontWeight: 800, color: "text.primary" }}>
                                {row.violation.code}
                              </Box>{" "}
                              {row.violation.label}
                            </Typography>
                            <Box
                              sx={{
                                px: 1,
                                py: 0.25,
                                borderRadius: 999,
                                fontSize: 12,
                                fontWeight: 700,
                                backgroundColor: getSeverityChip(sev).bg,
                                color: getSeverityChip(sev).fg,
                              }}
                            >
                              {getSeverityChip(sev).label}
                            </Box>
                          </Box>
                        ) : null}
                      </Box>
                    );
                  })}
                </Box>
              </Box>

              <Box className="whitebx textfield " sx={{ p: 2 }}>
              <Box sx={{mb: 2}}>
              <Typography variant="body2" className="table-heading">
                  Ask AI
                </Typography>
              </Box>
                <TextField
                  multiline
                  minRows={3}
                  fullWidth
                  placeholder='e.g. "Summarise all compliance concerns" or "What did the dealer say about the block trade?"'
                  value={askAiQuery}
                  onChange={(e) => setAskAiQuery(e.target.value)}
                />
                <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1 }}>
                  <Button
                    variant="contained"
                    className="primary-btn"
                    sx={{ minWidth: 120, borderRadius: 2 }}
                    onClick={() => {}}
                  >
                    Ask AI
                  </Button>
                </Box>
              </Box>
            </Box>
          </Grid>

          <Grid size={{ lg: 4, md: 12, sm: 12, xs: 12 }}>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2, height: "100%" }}>
              <Box className="whitebx" sx={{ p: 2 }}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2 }}>
                  <Typography variant="h6" className="table-heading">
                    Compliance rule results
                  </Typography>
                  <Typography variant="caption" sx={{ color: "text.secondary" }}>
                    Click row to expand
                  </Typography>
                </Box>

                <Box sx={{ display: "flex", flexDirection: "column", gap: 0.75 }}>
                  {rules.map((r) => {
                    const chip =
                      r.status === "Clear"
                        ? { bg: "rgba(46,125,50,0.10)", fg: "rgb(46,125,50)", label: "Clear" }
                        : r.severity === "Critical"
                          ? { bg: "rgba(211,47,47,0.14)", fg: "rgb(183, 28, 28)", label: "Violated" }
                          : { bg: "rgba(245,124,0,0.14)", fg: "rgb(156, 82, 0)", label: "Violated" };

                    return (
                      <Box
                        key={r.code}
                        sx={{
                          display: "grid",
                          gridTemplateColumns: "60px 1fr auto",
                          alignItems: "center",
                          gap: 1,
                          border: "1px solid rgba(15, 23, 42, 0.10)",
                          borderRadius: 1.5,
                          px: 1,
                          py: 0.75,
                          backgroundColor: "#fff",
                        }}
                      >
                        <Typography variant="caption" sx={{ color: "text.secondary", fontWeight: 700 }}>
                          {r.code}
                        </Typography>
                        <Typography variant="body2" sx={{ color: "text.primary", fontWeight: 600 }}>
                          {r.name}
                        </Typography>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
                          {r.status !== "Clear" ? (
                            <Box
                              sx={{
                                px: 1,
                                py: 0.25,
                                borderRadius: 999,
                                fontSize: 12,
                                fontWeight: 700,
                                backgroundColor:
                                  r.severity === "Critical" ? "rgba(211,47,47,0.10)" : "rgba(245,124,0,0.10)",
                                color: r.severity === "Critical" ? "rgb(183, 28, 28)" : "rgb(156, 82, 0)",
                              }}
                            >
                              {r.severity}
                            </Box>
                          ) : null}
                          <Box
                            sx={{
                              px: 1,
                              py: 0.25,
                              borderRadius: 999,
                              fontSize: 12,
                              fontWeight: 800,
                              backgroundColor: chip.bg,
                              color: chip.fg,
                            }}
                          >
                            {chip.label}
                          </Box>
                        </Box>
                      </Box>
                    );
                  })}
                </Box>
              </Box>

              <Box className="whitebx" sx={{ p: 2, flex: "1 1 auto" }}>
                <Typography variant="h6" className="table-heading" sx={{ mb: 2 }}>
                  Workflow closure
                </Typography>

                <Box sx={{ mt: 2 }}>
                  <WorkflowStepTabs steps={workflowSteps} />
                </Box>

                <Box sx={{ display: "flex", alignItems: "center", gap: 2, mt: 2, flexWrap: "wrap" }}>
                  <Typography variant="body2" sx={{ color: "text.secondary" }}>
                    Severity:{" "}
                    <Box
                      component="span"
                      sx={{
                        ml: 0.75,
                        px: 1,
                        py: 0.25,
                        borderRadius: 999,
                        fontSize: 12,
                        fontWeight: 800,
                        backgroundColor: getSeverityChip(workflowMeta.severity).bg,
                        color: getSeverityChip(workflowMeta.severity).fg,
                      }}
                    >
                      {workflowMeta.severity}
                    </Box>
                  </Typography>
                  <Typography variant="body2" sx={{ color: "text.secondary" }}>
                    TAT:{" "}
                    <Box component="span" sx={{ ml: 0.75, fontWeight: 800, color: "text.primary" }}>
                      {workflowMeta.tat}
                    </Box>
                  </Typography>
                </Box>

                <Box sx={{ mt: 2 }}>
                  <Typography variant="caption" sx={{ color: "text.secondary", fontWeight: 800, letterSpacing: 0.8 }}>
                    ACTION TAKEN
                  </Typography>
                  <Box className="textfield auto-complete" sx={{ mt: 0.75 }}>
                    <Autocomplete
                      options={actionOptions}
                      value={actionTaken}
                      onChange={(_e, next) => setActionTaken(next)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder="Select action..."
                        />
                      )}
                    />
                  </Box>

                  <Button
                    variant="contained"
                    fullWidth
                    className="primary-btn"
                    sx={{ mt: 2 }}
                    onClick={() => {}}
                  >
                    Send escalation email
                  </Button>
                </Box>
              </Box>

              <Box className="whitebx" sx={{ p: 2 }}>
                <Typography variant="h6" className="table-heading">
                  AI feedback loop
                </Typography>
                <Typography variant="body2" sx={{ color: "text.secondary", mt: 2, mb: 1 }} >
                  Was this call <span style={{ fontWeight: 600, color: "var(--primary)" }}>correctly flagged?</span>
                </Typography>

                <Box sx={{ display: "flex", gap: 1, mt: 1.25 }}>
                  <Button
                    variant={aiFeedback === "correct" ? "contained" : "outlined"}
                    fullWidth
                    startIcon={<FaThumbsUp />}
                    className={aiFeedback === "correct" ? "primary-btn" : "primary-outlined-btn"}
                    sx={{ borderRadius: 2 }}
                    onClick={() => setAiFeedback("correct")}
                  >
                    Correct
                  </Button>
                  <Button
                    variant={aiFeedback === "incorrect" ? "contained" : "outlined"}
                    fullWidth
                    startIcon={<FaThumbsDown />}
                    className={aiFeedback === "incorrect" ? "primary-btn" : "primary-outlined-btn"}
                    sx={{ borderRadius: 2 }}
                    onClick={() => setAiFeedback("incorrect")}
                  >
                    Incorrect
                  </Button>
                </Box>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </HeaderFooterLayout>
  );
}

