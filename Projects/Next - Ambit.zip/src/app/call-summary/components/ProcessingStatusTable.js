"use client";

import * as React from "react";
import { useEffect, useMemo, useState } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import TableSkeleton from "@/components/table_components/TableSkeleton";

ModuleRegistry.registerModules([AllCommunityModule]);

const SAMPLE_ROWS = [
  {
    id: "REC_MUMBAI_0901",
    file: "REC_MUMBAI_0901.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "7m 14s",
    stagePct: 100,
    status: "Complete",
  },
  {
    id: "REC_BLR_0934",
    file: "REC_BANGALORE_0934.wav",
    dealer: "Michael Hughes",
    branch: "Bangalore",
    duration: "11m 45s",
    stagePct: 62,
    status: "Processing",
  },
  {
    id: "REC_BLR_0951",
    file: "REC_BANGALORE_0951.wav",
    dealer: "Emma Wright",
    branch: "Bangalore",
    duration: "3m 28s",
    stagePct: 18,
    status: "Queued",
  },
  {
    id: "REC_MUMBAI_1022",
    file: "REC_MUMBAI_1022.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "2m 10s",
    stagePct: 100,
    status: "Skipped",
  },
  {
    id: "REC_DELHI_1039",
    file: "REC_DELHI_1039.wav",
    dealer: "Rachel Morgan",
    branch: "Delhi",
    duration: "8m 33s",
    stagePct: 78,
    status: "Failed",
  },
  {
    id: "REC_MUMBAI_0901",
    file: "REC_MUMBAI_0901.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "7m 14s",
    stagePct: 100,
    status: "Complete",
  },
  {
    id: "REC_BLR_0934",
    file: "REC_BANGALORE_0934.wav",
    dealer: "Michael Hughes",
    branch: "Bangalore",
    duration: "11m 45s",
    stagePct: 62,
    status: "Processing",
  },
  {
    id: "REC_BLR_0951",
    file: "REC_BANGALORE_0951.wav",
    dealer: "Emma Wright",
    branch: "Bangalore",
    duration: "3m 28s",
    stagePct: 18,
    status: "Queued",
  },
  {
    id: "REC_MUMBAI_1022",
    file: "REC_MUMBAI_1022.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "2m 10s",
    stagePct: 100,
    status: "Skipped",
  },
  {
    id: "REC_DELHI_1039",
    file: "REC_DELHI_1039.wav",
    dealer: "Rachel Morgan",
    branch: "Delhi",
    duration: "8m 33s",
    stagePct: 78,
    status: "Failed",
  },
  {
    id: "REC_MUMBAI_0901",
    file: "REC_MUMBAI_0901.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "7m 14s",
    stagePct: 100,
    status: "Complete",
  },
  {
    id: "REC_BLR_0934",
    file: "REC_BANGALORE_0934.wav",
    dealer: "Michael Hughes",
    branch: "Bangalore",
    duration: "11m 45s",
    stagePct: 62,
    status: "Processing",
  },
  {
    id: "REC_BLR_0951",
    file: "REC_BANGALORE_0951.wav",
    dealer: "Emma Wright",
    branch: "Bangalore",
    duration: "3m 28s",
    stagePct: 18,
    status: "Queued",
  },
  {
    id: "REC_MUMBAI_1022",
    file: "REC_MUMBAI_1022.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "2m 10s",
    stagePct: 100,
    status: "Skipped",
  },
  {
    id: "REC_DELHI_1039",
    file: "REC_DELHI_1039.wav",
    dealer: "Rachel Morgan",
    branch: "Delhi",
    duration: "8m 33s",
    stagePct: 78,
    status: "Failed",
  },
  {
    id: "REC_MUMBAI_0901",
    file: "REC_MUMBAI_0901.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "7m 14s",
    stagePct: 100,
    status: "Complete",
  },
  {
    id: "REC_BLR_0934",
    file: "REC_BANGALORE_0934.wav",
    dealer: "Michael Hughes",
    branch: "Bangalore",
    duration: "11m 45s",
    stagePct: 62,
    status: "Processing",
  },
  {
    id: "REC_BLR_0951",
    file: "REC_BANGALORE_0951.wav",
    dealer: "Emma Wright",
    branch: "Bangalore",
    duration: "3m 28s",
    stagePct: 18,
    status: "Queued",
  },
  {
    id: "REC_MUMBAI_1022",
    file: "REC_MUMBAI_1022.wav",
    dealer: "James Porter",
    branch: "Mumbai",
    duration: "2m 10s",
    stagePct: 100,
    status: "Skipped",
  },
  {
    id: "REC_DELHI_1039",
    file: "REC_DELHI_1039.wav",
    dealer: "Rachel Morgan",
    branch: "Delhi",
    duration: "8m 33s",
    stagePct: 78,
    status: "Failed",
  },
];

function statusTone(status) {
  const key = String(status ?? "").toLowerCase().trim();
  switch (key) {
    case "complete":
      return "status-pill--green";
    case "queued":
      return "status-pill--blue";
    case "skipped":
      return "status-pill--yellow";
    case "processing":
    case "failed":
    default:
      return "status-pill--red";
  }
}

function StatusPill({ status }) {
  const label = String(status ?? "").trim() || "-";
  const toneClass = statusTone(label);
  return (
    <Box sx={{ display: "flex", alignItems: "center", height: "100%" }}>
      <Box component="span" className={`status-pill ${toneClass}`}>
        {label}
      </Box>
    </Box>
  );
}

function StageBar({ value = 0, color = "var(--primary)" }) {
  const pct = Math.max(0, Math.min(100, Number(value) || 0));
  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 1, height: "100%" }}>
      <Box
        sx={{
          height: 6,
          width: 96,
          borderRadius: 99,
          bgcolor: "rgba(15, 23, 42, 0.08)",
          overflow: "hidden",
        }}
      >
        <Box sx={{ height: "100%", width: `${pct}%`, bgcolor: color }} />
      </Box>
      <Typography variant="caption" sx={{ fontWeight: 700, color: "text.secondary" }}>
        {pct}%
      </Typography>
    </Box>
  );
}

export default function ProcessingStatusTable({ rows }) {
  const rowData = Array.isArray(rows) && rows.length ? rows : SAMPLE_ROWS;
  const headerHeight = 35;
  const rowHeight = 40;

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 150);
    return () => clearTimeout(timer);
  }, []);

  const columnDefs = useMemo(
    () => [
      {
        headerName: "File",
        field: "file",
        minWidth: 220,
        cellRenderer: (p) => ( 
              p.value
        ),
      },
      { headerName: "Dealer", field: "dealer", minWidth: 140 },
      { headerName: "Branch", field: "branch", minWidth: 120 },
      { headerName: "Duration", field: "duration", minWidth: 110, maxWidth: 140, flex: 0 },
      {
        headerName: "Stage",
        field: "stagePct",
        minWidth: 170,
        maxWidth: 190,
        flex: 0,
        cellRenderer: (p) => <StageBar value={p.value} />,
      },
      {
        headerName: "Status",
        field: "status",
        minWidth: 160,
        maxWidth: 180,
        flex: 0,
        headerClass: "header_center",
        cellClass: "fx_c",
        cellRenderer: (p) => <StatusPill status={p.value} />,
      },
      {
        headerName: "Action",
        colId: "action",
        minWidth: 140,
        maxWidth: 160,
        flex: 0,
        headerClass: "header_center",
        cellClass: "fx_c",
        sortable: false,
        cellRenderer: (p) =>
          String(p.data?.status) === "Failed" ? (
            <Button
              variant="outlined"
              size="small"
              className="action-btn action-btn--blue"
              sx={{ minWidth: 92 }}
              onClick={() => {}}
            >
              Retry
            </Button>
          ) : (
            <Box />
          ),
      },
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: false,
      autoHeight: false,
      filter: false,
      flex: 1,
      suppressMovable: true,
      resizable: true,
    }),
    []
  );

  return (
    <Box>
      {loading ? (
        <Box style={{ width: "100%", height: "50vh", overflow: "hidden" }} aria-label="Loading...">
          <TableSkeleton />
        </Box>
      ) : (
        <Box className="ag-theme-quartz" style={{ width: "100%", height: "50vh" }}>
          <AgGridReact
            theme="legacy"
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressMovableColumns
            rowHeight={rowHeight}
            headerHeight={headerHeight}
            rowClassRules={{
              "even-row": (params) => params.node.rowIndex % 2 !== 0,
              "odd-row": (params) => params.node.rowIndex % 2 === 0,
            }}
          />
        </Box>
      )}

      <Box id="tb_footer" className="fx_sb" sx={{ mt: 1 }}>
        <AgGridInfo currentPage={1} rowsPerPage={rowData?.length ?? 0} totalRows={rowData?.length ?? 0} />
        <AgGridPagination currentPage={1} totalPages={1} onPageChange={() => {}} />
      </Box>
    </Box>
  );
}

