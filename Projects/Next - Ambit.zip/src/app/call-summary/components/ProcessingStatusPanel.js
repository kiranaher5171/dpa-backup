"use client";

import * as React from "react";
import Box from "@mui/material/Box";
import LinearProgress from "@mui/material/LinearProgress";
import MenuItem from "@mui/material/MenuItem";
import Typography from "@mui/material/Typography";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";

import { MdCheckCircle, MdError, MdOutlineHourglassTop, MdOutlinePlaylistAddCheck, MdSkipNext } from "react-icons/md";
import ProcessingStatusTable from "./ProcessingStatusTable";
import MetricCard from "@/components/MetricCard";

export default function ProcessingStatusPanel() {
  const [filter, setFilter] = React.useState("");
  const filterOptions = React.useMemo(
    () => ["All", "Complete", "Processing", "Queued", "Failed", "Skipped"],
    []
  );

  const rows = React.useMemo(
    () => [
      {
        id: "REC_MUMBAI_0901",
        file: "REC_MUMBAI_0901.wav",
        dealer: "James Porter",
        branch: "Mumbai",
        duration: "7m 14s",
        stagePct: 100,
        status: "Complete",
      },
      {
        id: "REC_DELHI_0918",
        file: "REC_DELHI_0918.wav",
        dealer: "Sarah Collins",
        branch: "Delhi",
        duration: "4m 02s",
        stagePct: 100,
        status: "Complete",
      },
      {
        id: "REC_BLR_0934",
        file: "REC_BANGALORE_0934.wav",
        dealer: "Michael Hughes",
        branch: "Bangalore",
        duration: "11m 45s",
        stagePct: 62,
        status: "Processing",
      },
      {
        id: "REC_BLR_0951",
        file: "REC_BANGALORE_0951.wav",
        dealer: "Emma Wright",
        branch: "Bangalore",
        duration: "3m 28s",
        stagePct: 18,
        status: "Queued",
      },
      {
        id: "REC_BLR_1005",
        file: "REC_BANGALORE_1005.wav",
        dealer: "David Foster",
        branch: "Bangalore",
        duration: "6m 55s",
        stagePct: 12,
        status: "Queued",
      },
      {
        id: "REC_MUMBAI_1022",
        file: "REC_MUMBAI_1022.wav",
        dealer: "James Porter",
        branch: "Mumbai",
        duration: "2m 10s",
        stagePct: 100,
        status: "Skipped",
      },
      {
        id: "REC_DELHI_1039",
        file: "REC_DELHI_1039.wav",
        dealer: "Rachel Morgan",
        branch: "Delhi",
        duration: "8m 33s",
        stagePct: 78,
        status: "Failed",
      },
      {
        id: "REC_BLR_1055",
        file: "REC_BANGALORE_1055.wav",
        dealer: "Sarah Collins",
        branch: "Bangalore",
        duration: "5m 01s",
        stagePct: 100,
        status: "Complete",
      },
    ],
    []
  );

  const counts = React.useMemo(() => {
    const total = rows.length;
    const complete = rows.filter((r) => r.status === "Complete").length;
    const processing = rows.filter((r) => r.status === "Processing").length;
    const queued = rows.filter((r) => r.status === "Queued").length;
    const failed = rows.filter((r) => r.status === "Failed").length;
    const skipped = rows.filter((r) => r.status === "Skipped").length;
    return { total, complete, processing, queued, failed, skipped };
  }, [rows]);

  const pipelinePct = Math.round((counts.complete / Math.max(1, counts.total)) * 100);

  const filteredRows = React.useMemo(() => {
    if (!filter || filter === "All") return rows;
    return rows.filter((r) => r.status === filter);
  }, [rows, filter]);

  const kpiCard = (value, label, accent, Icon) => (
    <MetricCard label={label} value={value} accent={accent} icon={Icon} minHeight={92} />
  );

  return (
    <>
    <Box>
   

      <Box
        sx={{
          mt: 2,
          display: "grid",
          gap: 1.5,
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2, minmax(0, 1fr))",
            md: "repeat(5, minmax(0, 1fr))",
          },
        }}
      >
        {kpiCard(counts.total, "Total", "#1565c0", MdOutlinePlaylistAddCheck)}
        {kpiCard(counts.complete, "Complete", "#00897b", MdCheckCircle)}
        {kpiCard(counts.processing, "Processing", "var(--primary)", MdOutlineHourglassTop)}
        {kpiCard(counts.failed, "Failed", "#6d4c41", MdError)}
        {kpiCard(counts.skipped, "Skipped", "#fb8c00", MdSkipNext)}
      </Box>

      {/* <Box sx={{ mt: 2 }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 0.75 }}>
          <Typography
            variant="caption"
            sx={{ fontWeight: 800, letterSpacing: "0.08em", color: "text.secondary" }}
          >
            PIPELINE PROGRESS
          </Typography>
          <Typography variant="caption" sx={{ fontWeight: 800, color: "rgba(15, 23, 42, 0.7)" }}>
            {pipelinePct}%
          </Typography>
        </Box>
        <LinearProgress
          variant="determinate"
          value={pipelinePct}
          sx={{
            height: 6,
            borderRadius: 99,
            bgcolor: "rgba(15, 23, 42, 0.08)",
            "& .MuiLinearProgress-bar": {
              borderRadius: 99,
              bgcolor: "#00897b",
            },
          }}
        />
      </Box> */}

      </Box>
      <Box className="whitebx" sx={{ mt: 2, p: 2 }}>
      <Box className="fx_sb" sx={{ mb: 1, alignItems: "center", gap: 2, flexWrap: "wrap" }}>
        <Typography variant="h6" className="table-heading" sx={{ flexShrink: 0 }}>
          Processing status
        </Typography>
        <Box className="textfield auto-complete" sx={{ minWidth: 220, flexShrink: 0 }}>
          <Autocomplete
            options={filterOptions}
            value={filter || "All"}
            onChange={(_, v) => setFilter(v ?? "All")}
            renderInput={(params) => (
              <TextField className="textfield" {...params} placeholder="Filter by status" />
            )}
          />
        </Box>
      </Box>

      <ProcessingStatusTable rows={filteredRows} />
    </Box>

   </>
  );
}

