"use client";

import { Menu } from "@base-ui/react/menu";
import { Menubar } from "@base-ui/react/menubar";

export { Menubar };

export const MenuRoot = Menu.Root;
export const MenuTrigger = Menu.Trigger;
export const MenuPortal = Menu.Portal;
export const MenuPositioner = Menu.Positioner;
export const MenuPopup = Menu.Popup;
export const MenuItem = Menu.Item;
export const MenuSeparator = Menu.Separator;
export const MenuSubmenuRoot = Menu.SubmenuRoot;
export const MenuSubmenuTrigger = Menu.SubmenuTrigger;
