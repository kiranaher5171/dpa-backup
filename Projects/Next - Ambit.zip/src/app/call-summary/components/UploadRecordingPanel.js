"use client";

import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import { MdUploadFile } from "react-icons/md";
import fileIcon from "../../../../public/files.png";
import Image from "next/image";

export default function UploadRecordingPanel() {
  const [fileName, setFileName] = React.useState("");
  const fileInputRef = React.useRef(null);

  const dealerOptions = React.useMemo(
    () => ["Select...", "Dealer A", "Dealer B", "Dealer C"],
    []
  );
  const branchOptions = React.useMemo(
    () => ["Select...", "Mumbai", "Delhi", "Pune"],
    []
  );

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    setFileName(file?.name ?? "");
  };

  const openFilePicker = () => fileInputRef.current?.click();

  return (
    <Box className="whitebx" sx={{ mt: 2, p: 2 }}>
      <Box sx={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", mb: 1 }}>
        <Typography variant="h6" className="table-heading">
        Upload a recording
        </Typography> 
      </Box>

      <Grid container spacing={4} sx={{ mt: 2, alignItems: "flex-start" }}>
        <Grid size={{ lg: 6, md: 12, sm: 12, xs: 12 }}> 
          <Box
            role="button"
            tabIndex={0}
            onClick={openFilePicker}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                openFilePicker();
              }
            }}
            sx={{
              border: "1px dashed rgba(15, 23, 42, 0.22)",
              borderRadius: 2,
              py: 9,
              // minHeight: 185,
              height: "100%",
              bgcolor: "rgba(15, 23, 42, 0.02)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              textAlign: "center",
              cursor: "pointer",
              "&:focus-visible": {
                outline: "2px solid color-mix(in srgb, var(--primary) 55%, transparent)",
                outlineOffset: 2,
              },
            }}
          >
            <Box>
                <Box sx={{display: "inline-flex", mb: 4 }}>
                  <Image src={fileIcon} alt="upload-file" width={"100%"} height={70} />
                </Box>
              <Typography sx={{ fontWeight: 600, color: "text.primary" }}>
                Drop a file here or click to browse
              </Typography>
              <Typography variant="body2" sx={{ color: "text.secondary", mt: 0.5 }}>
                WAV, MP3, OGG or M4A
              </Typography>

             
                <input ref={fileInputRef} type="file" hidden onChange={handleFileChange} />

            </Box>
          </Box>
        </Grid>

        <Grid size={{ lg: 6, md: 12, sm: 12, xs: 12 }}> 
          <Grid container spacing={2}>
          <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>
                 File Name
                </Typography>
                <TextField
                  type="text"
                  variant="outlined"
                  fullWidth
                  value={fileName}
                  placeholder="Select a file..."
                  slotProps={{ htmlInput: { readOnly: true } }}
                />
              </Box>
            </Grid>
            <Grid size={{ lg: 6, md: 12, sm: 12, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>
                  Call date
                </Typography>
                <TextField type="date" variant="outlined" fullWidth />
              </Box>
            </Grid>
            <Grid size={{ lg: 6, md: 12, sm: 12, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>
                  Call time
                </Typography>
                <TextField type="time" variant="outlined" fullWidth />
              </Box>
            </Grid>

            <Grid size={{ lg: 6, md: 12, sm: 12, xs: 12 }}>
              <Box className="textfield auto-complete">
                <Typography variant="body2" className="form-label" gutterBottom>
                  Dealer
                </Typography>
                <Autocomplete
                  options={dealerOptions}
                  defaultValue={dealerOptions[0]}
                  renderInput={(params) => <TextField {...params} placeholder="Select..." />}
                />
              </Box>
            </Grid>
            <Grid size={{ lg: 6, md: 12, sm: 12, xs: 12 }}>
              <Box className="textfield auto-complete">
                <Typography variant="body2" className="form-label" gutterBottom>
                  Branch
                </Typography>
                <Autocomplete
                  options={branchOptions}
                  defaultValue={branchOptions[0]}
                  renderInput={(params) => <TextField {...params} placeholder="Select..." />}
                />
              </Box>
            </Grid>

            <Grid size={{ lg: 6, md: 12, sm: 12, xs: 12 }}>
              <Box className="textfield">
                <Typography variant="body2" className="form-label" gutterBottom>
                  Business line
                </Typography>
                <RadioGroup row defaultValue="Ambit Broking">
                  <FormControlLabel value="Ambit Broking" control={<Radio size="small" />} label="Ambit Broking" />
                  <FormControlLabel value="Ambit Capital" control={<Radio size="small" />} label="Ambit Capital" />
                </RadioGroup>
              </Box>
            </Grid>

                <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
              <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1 }}>
                <Button variant="contained" className="primary-btn">
                  Upload
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Box>
  );
}

