"use client";

import { useEffect, useState } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { useRouter } from "next/navigation";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import TableSkeleton from "@/components/table_components/TableSkeleton";

ModuleRegistry.registerModules([AllCommunityModule]);

function badgePill(label, toneClass) {
  const text = String(label ?? "").trim() || "—";
  return (
    <Box sx={{ display: "flex", alignItems: "center", height: "100%" }}>
      <Box component="span" className={`status-pill ${toneClass}`}>
        {text}
      </Box>
    </Box>
  );
}

function flagTone(flag) {
  const key = String(flag ?? "").toLowerCase().trim();
  switch (key) {
    case "cleared":
      return "status-pill--green";
    case "skipped":
      return "status-pill--yellow";
    case "flagged":
    default:
      return "status-pill--red";
  }
}

function severityTone(severity) {
  const key = String(severity ?? "").toLowerCase().trim();
  switch (key) {
    case "critical":
      return "status-pill--red";
    case "high":
      return "status-pill--yellow";
    case "medium":
    default:
      return "status-pill--orange";
  }
}

function statusTone(status) {
  const key = String(status ?? "").toLowerCase().trim();
  switch (key) {
    case "closed":
      return "status-pill--green";
    case "unseen":
      return "status-pill--blue";
    case "under_review":
    case "escalated":
    default:
      return "status-pill--red";
  }
}

const SAMPLE_ROWS = [
  {
    callId: "CS-10041",
    callTime: "09:02",
    duration: "7m 14s",
    business: "Ambit Broking",
    branch: "Mumbai",
    dealer: "James Porter",
    flag: "flagged",
    severity: "critical",
    status: "unseen",
    action: "review",
  },
  {
    callId: "CS-10042",
    callTime: "09:18",
    duration: "4m 02s",
    business: "Ambit Broking",
    branch: "Delhi",
    dealer: "Sarah Chen",
    flag: "cleared",
    severity: "high",
    status: "closed",
    action: "view",
  },
  {
    callId: "CS-10043",
    callTime: "10:41",
    duration: "12m 55s",
    business: "Ambit Broking",
    branch: "Bangalore",
    dealer: "Ravi Nair",
    flag: "skipped",
    severity: "medium",
    status: "under_review",
    action: "review",
  },
  {
    callId: "CS-10044",
    callTime: "11:05",
    duration: "3m 20s",
    business: "Ambit Broking",
    branch: "Mumbai",
    dealer: "James Porter",
    flag: "cleared",
    severity: null,
    status: "closed",
    action: "view",
  },
  {
    callId: "CS-10045",
    callTime: "11:22",
    duration: "8m 11s",
    business: "Ambit Broking",
    branch: "Delhi",
    dealer: "Anita Desai",
    flag: "flagged",
    severity: "critical",
    status: "escalated",
    action: "review",
  },
  {
    callId: "CS-10046",
    callTime: "12:03",
    duration: "5m 48s",
    business: "Ambit Broking",
    branch: "Mumbai",
    dealer: "Leo Park",
    flag: "flagged",
    severity: "high",
    status: "unseen",
    action: "review",
  },
  {
    callId: "CS-10047",
    callTime: "12:44",
    duration: "6m 30s",
    business: "Ambit Broking",
    branch: "Bangalore",
    dealer: "Ravi Nair",
    flag: "cleared",
    severity: "medium",
    status: "closed",
    action: "view",
  },
  {
    callId: "CS-10048",
    callTime: "13:10",
    duration: "9m 01s",
    business: "Ambit Broking",
    branch: "Delhi",
    dealer: "Sarah Chen",
    flag: "skipped",
    severity: "high",
    status: "unseen",
    action: "review",
  },
  {
    callId: "CS-10049",
    callTime: "13:55",
    duration: "2m 14s",
    business: "Ambit Broking",
    branch: "Mumbai",
    dealer: "James Porter",
    flag: "cleared",
    severity: null,
    status: "closed",
    action: "view",
  },
  {
    callId: "CS-10050",
    callTime: "14:12",
    duration: "11m 40s",
    business: "Ambit Broking",
    branch: "Bangalore",
    dealer: "Priya Rao",
    flag: "flagged",
    severity: "critical",
    status: "under_review",
    action: "review",
  },
  {
    callId: "CS-10051",
    callTime: "14:33",
    duration: "5m 05s",
    business: "Ambit Broking",
    branch: "Delhi",
    dealer: "Anita Desai",
    flag: "cleared",
    severity: "medium",
    status: "closed",
    action: "view",
  },
  {
    callId: "CS-10052",
    callTime: "15:01",
    duration: "7m 50s",
    business: "Ambit Broking",
    branch: "Mumbai",
    dealer: "Leo Park",
    flag: "skipped",
    severity: "high",
    status: "escalated",
    action: "review",
  },
  {
    callId: "CS-10053",
    callTime: "15:28",
    duration: "4m 18s",
    business: "Ambit Broking",
    branch: "Bangalore",
    dealer: "Priya Rao",
    flag: "flagged",
    severity: "medium",
    status: "unseen",
    action: "review",
  },
  {
    callId: "CS-10054",
    callTime: "16:02",
    duration: "10m 22s",
    business: "Ambit Broking",
    branch: "Delhi",
    dealer: "Sarah Chen",
    flag: "cleared",
    severity: "critical",
    status: "closed",
    action: "view",
  },
  {
    callId: "CS-10055",
    callTime: "16:40",
    duration: "6m 07s",
    business: "Ambit Broking",
    branch: "Mumbai",
    dealer: "James Porter",
    flag: "cleared",
    severity: null,
    status: "closed",
    action: "view",
  },
];

const SummaryLogsTable = () => {
  const headerHeight = 40;
  const rowHeight = 44;
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 150);
    return () => clearTimeout(timer);
  }, []);

  const [rowData] = useState(SAMPLE_ROWS);

  const columnDefs = [
    {
      headerName: "CALL ID",
      field: "callId",
      minWidth: 110,
      width: 120,
      flex: 0,
      cellRenderer: (p) => (
        <Box sx={{ display: "flex", alignItems: "center", height: "100%" }}>
          <Typography variant="h6" fontWeight={700} sx={{ color: "rgb(211, 47, 47)" }} noWrap>
            {p.data?.callId ?? ""}
          </Typography>
        </Box>
      ),
    },
    {
      headerName: "CALL TIME",
      field: "callTime",
      minWidth: 90,
      width: 100,
      flex: 0,
    },
    {
      headerName: "DURATION",
      field: "duration",
      minWidth: 90,
      width: 100,
      flex: 0,
    },
    {
      headerName: "BUSINESS",
      field: "business",
      minWidth: 130,
      flex: 1,
    },
    {
      headerName: "BRANCH",
      field: "branch",
      minWidth: 100,
      width: 120,
      flex: 0,
    },
    {
      headerName: "DEALER",
      field: "dealer",
      minWidth: 120,
      flex: 1,
    },
    {
      headerName: "FLAG",
      field: "flag",
      headerClass: "header_center",
      cellClass: "fx_c",
      minWidth: 100,
      width: 110,
      flex: 0,
      cellRenderer: (p) => {
        const key = String(p.data?.flag ?? "").toLowerCase();
        const label = key || "—";
        return badgePill(label, flagTone(key));
      },
    },
    {
      headerName: "SEVERITY",
      field: "severity",
      headerClass: "header_center",
      cellClass: "fx_c",
      minWidth: 100,
      width: 115,
      flex: 0,
      cellRenderer: (p) => {
        const key = p.data?.severity ? String(p.data.severity).toLowerCase() : "";
        if (!key) {
          return (
            <Box sx={{ display: "flex", alignItems: "center", height: "100%" }}>
              <Typography variant="body2" color="text.secondary">
                —
              </Typography>
            </Box>
          );
        }
        return badgePill(key, severityTone(key));
      },
    },
    {
      headerName: "STATUS",
      field: "status",
      headerClass: "header_center",
      cellClass: "fx_c",
      minWidth: 120,
      width: 140,
      flex: 0,
      cellRenderer: (p) => {
        const key = String(p.data?.status ?? "").toLowerCase();
        const label = key.replace(/_/g, " ");
        return badgePill(label, statusTone(key));
      },
    },
    {
      headerName: "ACTION",
      colId: "action",
      headerClass: "header_center",
      cellClass: "fx_c",
      sortable: false,
      minWidth: 120,
      width: 130,
      maxWidth: 150,
      flex: 0,
      headerClass: "header_center",
      cellClass: "fx_c",
      cellRenderer: (p) => {
        const isView = String(p.data?.action ?? "review").toLowerCase() === "view";
        const label = isView ? "View" : "Review";
        const callId = p.data?.callId;
        return (
          <Button
            display="block"
            variant="outlined"
            size="small"
            className="action-btn action-btn--blue"
            sx={{ minWidth: 92, gap: 0.5 }}
            onClick={() => {
              if (!callId) return;
              router.push(`/call-summary/deep-dive?callId=${encodeURIComponent(callId)}`);
            }}
          >
              {label}
              <Box component="span" sx={{ fontSize: 12, lineHeight: 1, ml: 0.25 }}>
                →
              </Box>
          </Button> 
        );
      },
    },
  ];

  const defaultColDef = {
    sortable: false,
    autoHeight: false,
    filter: false,
    suppressMovable: true,
    resizable: true,
  };

  return (
    <Box>
      {loading ? (
        <Box style={{ width: "100%", height: "50vh", overflow: "hidden" }} aria-label="Loading...">
          <TableSkeleton />
        </Box>
      ) : (
        <Box className="ag-theme-quartz" style={{ width: "100%", height: "50vh" }}>
          <AgGridReact
            theme="legacy"
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressMovableColumns
            rowHeight={rowHeight}
            headerHeight={headerHeight}
            rowClassRules={{
              "even-row": (params) => params.node.rowIndex % 2 !== 0,
              "odd-row": (params) => params.node.rowIndex % 2 === 0,
            }}
          />
        </Box>
      )}
      <Box id="tb_footer" className="fx_sb" sx={{ mt: 1 }}>
        <AgGridInfo
          currentPage={1}
          rowsPerPage={rowData.length}
          totalRows={rowData.length}
        />
        <AgGridPagination currentPage={1} totalPages={1} onPageChange={() => {}} />
      </Box>
    </Box>
  );
};

export default SummaryLogsTable;
