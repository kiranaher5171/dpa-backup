/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
      // Disable ESLint during build
      ignoreDuringBuilds: true,
  },
  async rewrites() {
      return [
          {
              source: '/',
              destination: '/auth/login',
          },
          {
              source: '/forgot-password',
              destination: '/auth/forgot-password',
          },
          {
              source: '/reset-password',
              destination: '/auth/reset-password',
          }, 
      ];
  },
};

export default nextConfig;
