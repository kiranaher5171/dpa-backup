"use client";

import { ThemeProvider, createTheme } from "@mui/material";
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';
import PropTypes from 'prop-types';

const theme = createTheme({
  typography: {
    fontFamily: 'Roboto, sans-serif',
  },
});

const ThemeProviderComponent = ({ children }) => { 
  const cache = createCache({
    key: 'dpa',
    nonce: "123", 
    prepend: true,
  });

  return (
    <CacheProvider value={cache}>
      <ThemeProvider theme={theme}>
        {children}
      </ThemeProvider>
    </CacheProvider>
  );
};

ThemeProviderComponent.propTypes = {
  children: PropTypes.node.isRequired,
  nonce: PropTypes.string, // Add prop type for nonce
};

export default ThemeProviderComponent;
