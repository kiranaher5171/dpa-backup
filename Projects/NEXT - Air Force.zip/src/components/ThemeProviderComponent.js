"use client";

import { ThemeProvider, createTheme } from "@mui/material";
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';
import PropTypes from 'prop-types';
import { usePathname } from 'next/navigation';
import MainLayout from "@/app/layouts/MainLayout";

const theme = createTheme({
  typography: {
    fontFamily: 'Roboto, sans-serif',
  },
});

const ThemeProviderComponent = ({ children }) => {
  const cache = createCache({
    key: 'dpa',
    nonce: "123",
    prepend: true,
  });

  const pathname = usePathname();
  const noLayoutRoutes = ['/', '/reset-password']; // Pages without layout
  const isNoLayoutPage = noLayoutRoutes.includes(pathname);

  return (
    <CacheProvider value={cache}>
      <ThemeProvider theme={theme}>
        {isNoLayoutPage ? (
          <>{children}</> // Render children directly for auth pages
        ) : (
          <MainLayout>{children}</MainLayout> // Wrap other pages in MainLayout
        )}
      </ThemeProvider>
    </CacheProvider>
  );
};

ThemeProviderComponent.propTypes = {
  children: PropTypes.node.isRequired,
};

export default ThemeProviderComponent;
