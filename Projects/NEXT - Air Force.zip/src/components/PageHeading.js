import { Box, Container, Typography } from '@mui/material'
import React from 'react'
import style from "../css/page-heading.module.css";


const PageHeading = ({ title, note }) => {
    return (
        <Box id={style.pageHead} className={style.pageHead}>
            <Container maxWidth>
                <Box className={style.pageHeadContent}>
                    <Typography variant='h3' className='fw3 white'>
                        {title}
                    </Typography>
                    <Typography variant='h6' className='fw5 white'>
                        {note}
                    </Typography>
                </Box>
            </Container>
        </Box>
    )
}

export default PageHeading