import { Container, Typography, Box, Stack } from '@mui/material';

const Footer = ({clsName}) => {

    const currentYear = new Date().getFullYear();

    return (
        <>
            <Box className={clsName}>
                <Container maxWidth>
                    <Stack direction={"row"} alignItems={"center"} justifyContent={"space-between"}>
                        <Typography variant='h6' className='copyright'>
                            Copyright © {currentYear} Indian Air Force, Government of India. All Rights Reserved.
                        </Typography>
                    </Stack>
                </Container>
            </Box>
        </>
    )
}

export default Footer