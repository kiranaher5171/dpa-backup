import { Box, Container, Typography } from '@mui/material'
import React from 'react'


const CardHeading = ({ heading, note }) => {
    return (
        <Box className="fx_sb" mb={1}>
            <Typography variant='h5' className='card-heading fw5'>{heading}</Typography>
            <Typography variant='h5' className='card-heading fw5'>{note}</Typography>
        </Box>
    )
}

export default CardHeading