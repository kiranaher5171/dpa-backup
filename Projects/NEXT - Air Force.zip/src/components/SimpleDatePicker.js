"use client"
import React from 'react';
import { Box } from '@mui/material'
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';


const SimpleDatePicker = () => {


  const [value, setValue] = React.useState(dayjs('yyyy-mm-dd'));


  return (
    <>

      <Box className="datepicker">
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            placeholder="Select Date"
            size="small"
            value={value}
            onChange={(newValue) => setValue(newValue)}
          />
        </LocalizationProvider>
      </Box>

    </>
  )
}

export default SimpleDatePicker

