"use client"
import React from 'react'
import MainLayout from '../layouts/MainLayout'
import PageHeading from '@/components/PageHeading'
import { Box, Grid, Divider, Typography, TextField, Button, Stack, IconButton, Container, Chip } from '@mui/material'
import Autocomplete from '@mui/material/Autocomplete';
import SimpleDatePicker from '@/components/SimpleDatePicker'
import CachedOutlinedIcon from '@mui/icons-material/CachedOutlined';
import RadarListTable from './RadarListTable'

import RadarIcon from '@mui/icons-material/Radar';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import CardHeading from '@/components/CardHeading'

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]



const page = () => {

    return (

        <>
            {/* <MainLayout> */}
            <Box>
                <PageHeading title={"Radar Health Summary"} note={"As on 8th February 2024"} />
            </Box>

            <Container maxWidth>
                <Box id="page-content">
                    <Box className="alicebx" mb={2}>
                        <Box>
                            <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                <Grid item lg={2} md={3} sm={4} xs={6}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>Select Date</Typography>
                                        <SimpleDatePicker />
                                    </Box>
                                </Grid>

                                <Grid item lg={2} md={3} sm={4} xs={6}>
                                    <Box className='textfield auto-complete'>
                                        <Typography variant='body' className='label'>Select Radar Unit</Typography>
                                        <Autocomplete
                                            disablePortal
                                            fullWidth
                                            id="combo-box-demo"
                                            options={options}
                                            renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                        />
                                    </Box>
                                </Grid>


                                <Grid item lg={2} md={3} sm={4} xs={6}>
                                    <Box className='textfield auto-complete'>
                                        <Typography variant='body' className='label'>Prediction Result</Typography>
                                        <Autocomplete
                                            disablePortal
                                            fullWidth
                                            id="combo-box-demo"
                                            options={options}
                                            renderInput={(params) => <TextField {...params} placeholder="Select..." variant='outlined' size='small' />}
                                        />
                                    </Box>
                                </Grid>


                                <Grid item lg={2} md={3} sm={4} xs={6}>
                                    <Stack direction={"row"} spacing={1} justifyContent={"flex-start"} alignItems={"center"}>
                                        <Box>
                                            <Typography variant='body' className='label'>&nbsp;</Typography>
                                            <Box>
                                                <IconButton size='medium'>
                                                    <CachedOutlinedIcon fontSize='small' className='skyblue' />
                                                </IconButton>
                                            </Box>
                                        </Box>

                                        <Box>
                                            <Typography variant='body' className='label'>&nbsp;</Typography>
                                            <Box className="left">
                                                <Button variant='outlined' className='primary-btn' size='small'>Search</Button>
                                            </Box>
                                        </Box>
                                    </Stack>
                                </Grid>
                            </Grid>
                        </Box>
                    </Box>
                </Box>
            </Container>

            <Box className="inner-page-scroll">

                <Container maxWidth>
                    <Box>
                        {/* <Box className="alicebx" mb={2}>
                            <Box>
                                <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield'>
                                            <Typography variant='body' className='label'>Select Date</Typography>
                                            <SimpleDatePicker />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Select Radar Unit</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Prediction Result</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select..." variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Stack direction={"row"} spacing={1} justifyContent={"flex-start"} alignItems={"center"}>
                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box>
                                                    <IconButton size='medium'>
                                                        <CachedOutlinedIcon fontSize='small' className='skyblue' />
                                                    </IconButton>
                                                </Box>
                                            </Box>

                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box className="left">
                                                    <Button variant='outlined' className='primary-btn' size='small'>Search</Button>
                                                </Box>
                                            </Box>
                                        </Stack>
                                    </Grid>
                                </Grid>
                            </Box>
                        </Box> */}

                        <Box className="whitebx">
                            <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className="fx_fs gap1">
                                        <RadarIcon className='green' />

                                        <Typography variant='h4' className='h4v2'>
                                            Total Radar Units :
                                        </Typography>


                                        <Chip label="30" className="chip1" />

                                        <Typography variant='h4' className='fw5 green'>
                                            39
                                        </Typography>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>

                        <Box className="whitebx" mt={'6px'}>
                            <Box className="">

                                <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                    <Grid item lg={4} md={12} sm={12} xs={12}>
                                        <Box className="fx_fs gap1">
                                            <RadarIcon className='red' />

                                            <Typography variant='h4' className='h4v2'>
                                                Future Fault Predictions :
                                            </Typography>

                                            <Chip label="30" className="chip2" />

                                            <Typography variant='h4' className='fw5 red'>
                                                04
                                            </Typography>
                                        </Box>
                                    </Grid>
                                    <Grid item lg={8} md={12} sm={12} xs={12}>
                                        <Box className="severity-level fx_fe">
                                            <Typography variant='h6' className='fw5 text'>
                                                Severity Level :
                                            </Typography>

                                            <Box className="fx_fs gap2">
                                                <Typography variant='h6' className='fw5 red fx_fs'>
                                                    <FiberManualRecordIcon className='esm-ico' />   High: 02
                                                </Typography>

                                                <Typography variant='h6' className='fw5 yellow fx_fs'>
                                                    <FiberManualRecordIcon className='esm-ico' /> Moderate: 04
                                                </Typography>

                                                <Typography variant='h6' className='fw5 green fx_fs'>
                                                    <FiberManualRecordIcon className='esm-ico' /> Low: 03
                                                </Typography>
                                            </Box>

                                        </Box>
                                    </Grid>
                                </Grid>
                            </Box>
                        </Box>


                        <Box className="whitebx" mt={2}>
                            <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box>
                                        {/* <Box className="fx_sb" mb={1}>
                                            <Typography variant='h5' className='blue fw5 card-heading'>Radar List</Typography>
                                        </Box> */}
                                        <CardHeading heading={"Radar List"} />
                                        <Divider />
                                        <Box mt={1}>
                                            <RadarListTable />
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box>
                                        {/* <Box className="fx_sb" mb={1}>
                                            <Typography variant='h5' className='blue fw5'>Fault Prediction - Next 30 Days</Typography>
                                        </Box> */}
                                        <CardHeading heading={"Fault Prediction - Next 30 Days"} />
                                        <Divider />
                                        <Box mt={1}>
                                            <RadarListTable />
                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>


                        <Box mt={2}>
                            <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className="whitebx">
                                        {/* <Box className="fx_sb" mb={1}>
                                            <Typography variant='h5' className='blue fw5'>Failure count of Component</Typography>
                                        </Box> */}
                                        <CardHeading heading={"Failure count of Component"} />
                                        <Box style={{ width: '100%', height: '25vh', overflow: 'hidden' }} area-label="Chart">

                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className="whitebx">
                                        {/* <Box className="fx_sb" mb={1}>
                                            <Typography variant='h5' className='blue fw5'>Radar Failure count by Location</Typography>
                                        </Box> */}
                                        <CardHeading heading={"Radar Failure count by Location"} />
                                        <Box style={{ width: '100%', height: '25vh', overflow: 'hidden' }} area-label="Chart">

                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                    </Box>
                </Container>

            </Box>
            {/* </MainLayout > */}

        </>
    )
}

export default page