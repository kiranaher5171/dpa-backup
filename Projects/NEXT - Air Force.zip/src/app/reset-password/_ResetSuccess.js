import { Box, Button, Typography } from '@mui/material'
import Image from 'next/image'
import Link from 'next/link'
import React from 'react'
import LOGO from "../../../public/assets/logo.png";
import style from "../../css/forms.module.css"


const ResetSuccess = () => {
    return (
        <>
            <Box className={style.formbx2}>

                <Box pb={2} className="center">
                    <Image src={LOGO} className={style.formLogo} alt='Indian Air Force' priority />
                </Box>

                <Box className="center">
                    <Typography variant='h4' className="fw5 blue" gutterBottom>
                        Password Changed
                    </Typography>
                </Box>

                <Box mt={1} className="center">
                    <Typography variant='h5' className="fw5 text" gutterBottom>
                        You've successfully changed your password. Please log in with the new password.
                    </Typography>
                </Box>

                <Box pt={2}>
                    <Link href="/" passHref>
                        <Button variant='contained' className="form-btn" fullWidth>Back to Login</Button>
                    </Link>
                </Box>

            </Box>
        </>
    )
}

export default ResetSuccess