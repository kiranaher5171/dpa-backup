"use client";
import * as React from 'react';
import Link from 'next/link';
import { Box, Button, Container, Grid, IconButton, InputAdornment, OutlinedInput, Typography } from '@mui/material';
import LOGO from "../../../public/assets/logo.png";
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import Image from 'next/image';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';


import style from "../../css/forms.module.css"
import ResetSuccess from './_ResetSuccess';



const Page = () => {
  const [values, setValues] = React.useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
    showOldPassword: false,
    showNewPassword: false,
    showConfirmPassword: false,
  });

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  const handleClickShowPassword = (field) => () => {
    setValues({ ...values, [field]: !values[field] });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };


  const [isReset, setIsReset] = React.useState(false);

  const handleResetClick = () => {
    setIsReset(true);
  };


  return (
    <>
      <Box id={style.formPage}>
        <Grid container alignItems='center' justifyContent="center">
          <Grid item lg={8} md={8} sm={6} xs={12}>
            <Box className={style.formbg}>
              <Container maxWidth="md">
                <Box className={style.formText}>
                  <Box>
                    <Typography variant='h4' className="white">
                      Welcome…
                    </Typography>
                  </Box>

                  <Box py={'4px'}>
                    <Typography variant='h1' className="white fw5">
                      INDIAN AIR FORCE
                    </Typography>
                  </Box>

                  <Typography variant='h4' className="white" gutterBottom>
                    Touch The Sky With Glory
                  </Typography>
                </Box>
              </Container>
            </Box>
          </Grid>
          <Grid item lg={4} md={4} sm={6} xs={12}>
            <Grid container alignItems='center' justifyContent="center">
              <Grid item lg={8} md={8} sm={10} xs={12}>

                {!isReset && (
                  <Box className={style.formbx}>
                    <Box pb={2} className="center">
                      <Image src={LOGO} className={style.formLogo} alt='Indian Air Force' priority />
                    </Box>

                    <Box className="center">
                      <Typography variant='h4' className="fw5 blue" gutterBottom>
                        Reset Password
                      </Typography>
                    </Box>

                    <Box mt={3}>
                      <Grid container alignItems="top" justifyContent='center' spacing={3}>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                          <Box className='form-textfield'>
                            <OutlinedInput
                              id="old-password"
                              placeholder='Old Password'
                              fullWidth
                              type={values.showOldPassword ? 'text' : 'password'}
                              value={values.oldPassword}
                              onChange={handleChange('oldPassword')}
                              startAdornment={<InputAdornment position="end">
                                <LockOutlinedIcon />
                              </InputAdornment>}
                              endAdornment={<InputAdornment position="end">
                                <IconButton
                                  size="small"
                                  aria-label="toggle old password visibility"
                                  onClick={handleClickShowPassword('showOldPassword')}
                                  onMouseDown={handleMouseDownPassword}
                                  edge="end"
                                >
                                  {values.showOldPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                </IconButton>
                              </InputAdornment>}
                            />
                          </Box>
                        </Grid>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                          <Box className='form-textfield'>
                            <OutlinedInput
                              id="new-password"
                              placeholder='New Password'
                              fullWidth
                              type={values.showNewPassword ? 'text' : 'password'}
                              value={values.newPassword}
                              onChange={handleChange('newPassword')}
                              startAdornment={<InputAdornment position="end">
                                <LockOutlinedIcon />
                              </InputAdornment>}
                              endAdornment={<InputAdornment position="end">
                                <IconButton
                                  size="small"
                                  aria-label="toggle new password visibility"
                                  onClick={handleClickShowPassword('showNewPassword')}
                                  onMouseDown={handleMouseDownPassword}
                                  edge="end"
                                >
                                  {values.showNewPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                </IconButton>
                              </InputAdornment>}
                            />
                          </Box>
                        </Grid>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                          <Box className='form-textfield'>
                            <OutlinedInput
                              id="confirm-password"
                              placeholder='Confirm Password'
                              fullWidth
                              type={values.showConfirmPassword ? 'text' : 'password'}
                              value={values.confirmPassword}
                              onChange={handleChange('confirmPassword')}
                              startAdornment={<InputAdornment position="end">
                                <LockOutlinedIcon />
                              </InputAdornment>}
                              endAdornment={<InputAdornment position="end">
                                <IconButton
                                  size="small"
                                  aria-label="toggle confirm password visibility"
                                  onClick={handleClickShowPassword('showConfirmPassword')}
                                  onMouseDown={handleMouseDownPassword}
                                  edge="end"
                                >
                                  {values.showConfirmPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                </IconButton>
                              </InputAdornment>}
                            />
                          </Box>
                        </Grid>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                          <Box pt={0}>
                            {/* <Link href="/" passHref> */}
                            <Button variant='contained' className="form-btn" fullWidth onClick={handleResetClick}>Reset</Button>
                            {/* </Link> */}
                          </Box>
                        </Grid>

                      </Grid>
                    </Box>
                  </Box>
                )}

                {isReset && (
                  <Box>
                    <ResetSuccess />
                  </Box>
                )}


              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Box>
    </>
  );
}

export default Page;
