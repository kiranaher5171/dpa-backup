import "./root.css";
import localFont from 'next/font/local';
import ThemeProviderComponent from "@/components/ThemeProviderComponent";

// Import and define your custom font
const roboto = localFont({
  src: [
    {
      path: '../../public/fonts/Roboto-Thin.ttf',
      weight: '100',
      style: 'thin',
    },
    {
      path: '../../public/fonts/Roboto-Light.ttf',
      weight: '300',
      style: 'light',
    },
    {
      path: '../../public/fonts/Roboto-Regular.ttf',
      weight: '400',
      style: 'regular',
    },
    {
      path: '../../public/fonts/Roboto-Medium.ttf',
      weight: '500',
      style: 'medium',
    },
    {
      path: '../../public/fonts/Roboto-Bold.ttf',
      weight: '700',
      style: 'bold',
    },
  ],
});

export const metadata = {
  title: "Indian Air Force",
  description: "Touch The Sky With Glory",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={roboto.className}>
        <ThemeProviderComponent>
          <main>
            {children}
          </main>
        </ThemeProviderComponent>
      </body>
    </html>
  );
}
