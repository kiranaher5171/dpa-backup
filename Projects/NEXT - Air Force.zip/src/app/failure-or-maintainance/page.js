"use client"
import React from 'react'
import MainLayout from '../layouts/MainLayout'
import PageHeading from '@/components/PageHeading'
import { Box, Grid, Container, Divider, Typography, TextField, Button, IconButton, Stack } from '@mui/material'
import OutlinedInput from '@mui/material/OutlinedInput';
import Autocomplete from '@mui/material/Autocomplete';
import CachedOutlinedIcon from '@mui/icons-material/CachedOutlined';

import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import CloseIcon from '@mui/icons-material/Close';

import Save from "../../../public/assets/success.png";
import Image from 'next/image'
import SimpleDatePicker from '@/components/SimpleDatePicker'
import CardHeading from '@/components/CardHeading'



const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]


const page = () => {

    const parameters = Array.from({ length: 35 }, (_, index) => index + 1);

    const [open1, setOpen1] = React.useState(false);
    const handleClickOpen1 = () => {
        setOpen1(true);
    };
    const handleClose1 = () => {
        setOpen1(false);
    };

    return (

        <>
            {/* <MainLayout> */}
                <Box>
                    <PageHeading title={"Component Failure/Maintenance"} note={"As on 8th February 2024"} />
                </Box>
                <Container maxWidth>
                    <Box id="page-content">

                        <Box className="alicebx" mb={2}>
                            <Box>
                                <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield'>
                                            <Typography variant='body' className='label'>Select Date</Typography>
                                            <SimpleDatePicker />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Select Radar Unit</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Select Component</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Component" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Select Category</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Category" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Types of Failures</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select type" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Stack direction={"row"} spacing={1} justifyContent={"flex-start"} alignItems={"center"}>
                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box>
                                                    <IconButton size='medium'>
                                                        <CachedOutlinedIcon fontSize='small' className='skyblue' />
                                                    </IconButton>
                                                </Box>
                                            </Box>

                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box className="left">
                                                    <Button variant='outlined' className='primary-btn' size='small'>View</Button>
                                                </Box>
                                            </Box>
                                        </Stack>
                                    </Grid>

                                </Grid>
                            </Box>
                        </Box>



                        <Box className="whitebx">
                            {/* <Box className="fx_sb" mb={1}>
                                <Typography variant='h5' className='blue fw5'>Fill Details if any</Typography>
                            </Box> */}
                            <CardHeading heading={"Fill Details if any"} />

                            <Divider />

                            <Box mt={1}>
                                <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Box className='textfield'>
                                            <OutlinedInput
                                                id={`outlined-adornment-area`}
                                                placeholder='Type Text Here...'
                                                fullWidth
                                                inputProps={{
                                                    'aria-label': `text-area`,
                                                }}
                                                multiline
                                                rows={5}
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Box>
                        </Box>

                        <Box mt={2} className="right">
                            <Button variant='outlined' className='secondary-btn' size='small' onClick={handleClickOpen1}>Submit</Button>
                        </Box>
                    </Box>
                </Container>
            {/* </MainLayout> */}





            <Dialog open={open1} onClose={handleClose1} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description" >
                <IconButton aria-label="close" onClick={handleClose1} sx={{ position: 'absolute', right: 8, top: 8, }} >
                    <CloseIcon />
                </IconButton>
                <Divider />
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box>
                            <Grid container alignItems="center" justifyContent='center' spacing={2}>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center'>
                                        <Image src={Save} alt="saved" className="dialog-img" />
                                    </Box>
                                </Grid>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center'>
                                        <Typography variant='h4' className='green fw5'>Save successful!</Typography>
                                        <Typography variant='h5' className='gray fw5'>Your data is safe now.</Typography>
                                    </Box>
                                </Grid>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center' mt={1} mb={2}>
                                        <Button variant='contained' className='secondary-btn' onClick={handleClose1}>
                                            Close
                                        </Button>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog>

        </>
    )
}

export default page