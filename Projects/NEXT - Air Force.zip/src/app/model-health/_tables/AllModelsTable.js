"use client";
import React from 'react'
import { Box, Button } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/TableSkeleton';
import AgGridInfo from '@/components/AgGridInfo';
import AgGridPagination from '@/components/AgGridPagination';
import Link from 'next/link';



const AllModelsTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const rowHeight = 25;
    const headerHeight = 30;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: true, flex: 1, suppressMovable: false, resizable: true
    }

    const rowStyle = { background: '#ffffff' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'rgb(249, 252, 255)' };
        }
    };

    const [rowData] = useState([
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
    ]);


    const columnDefs = [
        {
            headerName: 'Model Names', field: 'name', minWidth: 160, cellRenderer: () => <> Model 25 Jan 2024  </>,
        },
        {
            headerName: 'Start Data Date', field: 'sdate', minWidth: 160, maxWidth: 160, cellRenderer: () => <> 01-01-2023  </>,
        },
        {
            headerName: 'End Data Date', field: 'edate', minWidth: 160, maxWidth: 160, cellRenderer: () => <> 01-01-2024  </>,
        },
        {
            headerName: 'Result', field: 'result', minWidth: 160, cellRenderer: () => <> Result: Accuracy: 87%  </>,
        },
        {
            headerName: '', field: 'btn', minWidth: 160, maxWidth: 160, cellRenderer: () => <> 
            <Button variant='outlined' className='secondary-btn rbtn' size='small'>Test Model</Button> 
             </>, cellClass: "center", filter: false, sortable: false,
        },
        {
            headerName: '', field: 'val', minWidth: 120, cellRenderer: () => <>  <Link href="#">Set As Production Model</Link> </>,
        },
    ];


    return (
        <>
            <Box className="">
                {loading ? (
                    <Box style={{ width: '100%', height: '20vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz" style={{ width: '100%', height: '20vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                                getRowStyle={getRowStyle}
                                rowStyle={rowStyle}
                            />
                        </Box>
                        <Box id="tb_footer" className="fx_sb" mt={1}>
                            <AgGridInfo />
                            <AgGridPagination />
                        </Box>
                    </>
                )}
            </Box>




        </>
    )
}

export default AllModelsTable