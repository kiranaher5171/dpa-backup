"use client";
import React from 'react'
import { Box } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/TableSkeleton';
import AgGridInfo from '@/components/AgGridInfo';
import AgGridPagination from '@/components/AgGridPagination';
import Link from 'next/link';



const DataDriftTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const rowHeight = 25;
    const headerHeight = 30;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: true, flex: 1, suppressMovable: false, resizable: true
    }

    const rowStyle = { background: '#ffffff' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'rgb(249, 252, 255)' };
        }
    };

    const [rowData] = useState([
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
    ]);


    const columnDefs = [
        {
            headerName: 'Parameter Names', field: 'name', minWidth: 160, cellRenderer: () => <> Parameter 01  </>,
        },
        {
            headerName: 'SD Hist', field: 'sdh', minWidth: 120, maxWidth: 200, cellRenderer: () => <> 21.34 </>, cellClass: 'right',
        },
        {
            headerName: 'Mean Hist', field: 'mh', minWidth: 120, maxWidth: 200, cellRenderer: () => <> 245 </>, cellClass: 'right',
        },
        {
            headerName: 'SD Rolling 30 Day', field: 'sdr', minWidth: 120, maxWidth: 200, cellRenderer: () => <> 10.11 </>, cellClass: 'right',
        },
        {
            headerName: 'Mean Rolling 30 Day', field: 'mr', minWidth: 120, maxWidth: 200, cellRenderer: () => <> 1204 </>, cellClass: 'right',
        },
    ];


    return (
        <>
            <Box className="">
                {loading ? (
                    <Box style={{ width: '100%', height: '20vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz" style={{ width: '100%', height: '20vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                                getRowStyle={getRowStyle}
                                rowStyle={rowStyle}
                            />
                        </Box>
                        <Box id="tb_footer" className="fx_sb" mt={1}>
                            <AgGridInfo />
                            <AgGridPagination />
                        </Box>
                    </>
                )}
            </Box>




        </>
    )
}

export default DataDriftTable