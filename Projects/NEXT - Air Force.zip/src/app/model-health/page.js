"use client"
import React, { useState, useEffect } from 'react'
import MainLayout from '../layouts/MainLayout'
import PageHeading from '@/components/PageHeading'
import { Box, Grid, Divider, Typography, Button, Container, IconButton, Stack, TextField } from '@mui/material'
import DataDriftTable from './_tables/DataDriftTable'
import AllModelsTable from './_tables/AllModelsTable'
import Image from 'next/image'
import Icon1 from '../../../public/assets/icons/1.svg'
import Icon2 from '../../../public/assets/icons/2.svg'
import Icon3 from '../../../public/assets/icons/3.svg'
import Icon4 from '../../../public/assets/icons/4.svg'

import Autocomplete from '@mui/material/Autocomplete';
import CachedOutlinedIcon from '@mui/icons-material/CachedOutlined';


import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import CloseIcon from '@mui/icons-material/Close';

import Loading from "../../../public/assets/processing.gif";
import Done from "../../../public/assets/done.gif";
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import CardHeading from '@/components/CardHeading'

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]



const page = () => {

    const [open1, setOpen1] = useState(false);
    const [processingStep, setProcessingStep] = useState(0);
    const [isProcessingDone, setIsProcessingDone] = useState(false);

    const handleClickOpen1 = () => {
        setOpen1(true);
        setProcessingStep(0); // Reset processing step when opening dialog
        setIsProcessingDone(false); // Reset processing state
    };

    const handleClose1 = () => {
        setOpen1(false);
    };

    useEffect(() => {
        if (open1) {
            const timers = [
                setTimeout(() => setProcessingStep(1), 1000), // After 1 sec, Data Collection is processed
                setTimeout(() => setProcessingStep(2), 2000), // After 2 sec, Data Preparation is processed
                setTimeout(() => setProcessingStep(3), 3000), // After 3 sec, Training / Finetuning is processed
                setTimeout(() => setIsProcessingDone(true), 4000), // After 4 sec, processing is done
            ];

            // Cleanup timers if component unmounts
            return () => timers.forEach(timer => clearTimeout(timer));
        }
    }, [open1]);



    return (

        <>
            {/* <MainLayout> */}
                <Box>
                    <PageHeading title={"Model Health"} note={"As on 8th February 2024"} />
                </Box>

                <Container maxWidth>
                    <Box id="page-content">


                        <Box className="alicebx" mb={2}>
                            <Box>
                                <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Select Radar Unit</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Components</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Stack direction={"row"} spacing={1} justifyContent={"flex-start"} alignItems={"center"}>
                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box>
                                                    <IconButton size='medium'>
                                                        <CachedOutlinedIcon fontSize='small' className='skyblue' />
                                                    </IconButton>
                                                </Box>
                                            </Box>

                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box className="left">
                                                    <Button variant='outlined' className='primary-btn' size='small'>Search</Button>
                                                </Box>
                                            </Box>
                                        </Stack>
                                    </Grid>



                                </Grid>
                            </Box>
                        </Box>


                        <Box>
                            <Grid container alignItems="center" justifyContent='flex-start' rowSpacing={{ xs: 1, sm: 1, md: 1, lg: 0 }} columnSpacing={{ xs: 1, sm: 2, md: 2 }}>
                                <Grid item lg={3} md={6} sm={6} xs={12}>
                                    <Box className="whitebx">
                                        <Box className="fx_sb">
                                            <Box className="icon">
                                                <Image src={Icon1} height={25} width={25} alt="Icon" />
                                            </Box>
                                            <Box className="right">
                                                <Typography variant='h6' className='gray fw5'>CURRENT MODEL</Typography>
                                                <Typography variant='h4' className='blue fw7'>model_12_dec_2023</Typography>
                                            </Box>
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={3} md={6} sm={6} xs={12}>
                                    <Box className="whitebx">
                                        <Box className="fx_sb">
                                            <Box className="icon">
                                                <Image src={Icon2} height={25} width={25} alt="Icon" />
                                            </Box>
                                            <Box className="right">
                                                <Typography variant='h6' className='gray fw5'>MODEL ACCURACY</Typography>
                                                <Typography variant='h4' className='blue fw7'>85%</Typography>
                                            </Box>
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={3} md={6} sm={6} xs={12}>
                                    <Box className="whitebx">
                                        <Box className="fx_sb">
                                            <Box className="icon">
                                                <Image src={Icon3} height={25} width={25} alt="Icon" />
                                            </Box>
                                            <Box className="right">
                                                <Typography variant='h6' className='gray fw5'>MODEL PRECISION</Typography>
                                                <Typography variant='h4' className='blue fw7'>90%</Typography>
                                            </Box>
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={3} md={6} sm={6} xs={12}>
                                    <Box className="whitebx">
                                        <Box className="fx_sb">
                                            <Box className="icon">
                                                <Image src={Icon4} height={25} width={25} alt="Icon" />
                                            </Box>
                                            <Box className="right">
                                                <Typography variant='h6' className='gray fw5'>ALL DATA DRIFT INDICATOR</Typography>
                                                <Typography variant='h4' className='blue fw7'>0.2</Typography>
                                            </Box>
                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>

                        <Box className="whitebx" mt={2}>
                            <Box className="fx_sb" mb={0}>
                                {/* <Typography variant='h5' className='blue fw5'>Data Drift</Typography> */}
                                <CardHeading heading={"Data Drift"} />
                            </Box>
                            <Divider />
                            <Box mt={1}>
                                <DataDriftTable />
                            </Box>
                        </Box>


                        <Box className="whitebx" mt={2}>
                            <Box className="fx_sb" mb={1}>
                                <Typography variant='h5' className='card-heading fw5'>All Models</Typography>
                                <Button variant='outlined' className='secondary-btn' size='small' onClick={handleClickOpen1}>Finetune Model</Button>
                            </Box>
                            <Divider />
                            <Box mt={1}>
                                <AllModelsTable />
                            </Box>
                        </Box>

                    </Box>
                </Container>

            {/* </MainLayout> */}





            <Dialog open={open1} onClose={handleClose1} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                <IconButton aria-label="close" onClick={handleClose1} sx={{ position: 'absolute', right: 8, top: 8, }} >
                    <CloseIcon />
                </IconButton>
                <Divider />
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box>
                            <Grid container alignItems="center" justifyContent='center' spacing={2}>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center'>
                                        <Image src={isProcessingDone ? Done : Loading} alt="saved" className="dialog-gif-sm" unoptimized />
                                    </Box>
                                </Grid>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    {isProcessingDone ?
                                        <Box className='center'>
                                            <Typography variant='h4' className='green fw5'>Successfully</Typography>
                                            <Typography variant='h5' className='gray fw5'>Processed</Typography>
                                        </Box>
                                        :
                                        <Box className='center'>
                                            <Typography variant='h4' className='skyblue fw5'>Processing...</Typography>
                                            <Typography variant='h5' className='gray fw5'>Please wait...</Typography>
                                        </Box>
                                    }

                                </Grid>


                                <Grid item lg={4} md={4} sm={12} xs={12}>
                                    <Box className={`grybx ${processingStep >= 1 ? 'processed' : 'processsing'}`}>
                                        <Box>
                                            <CheckCircleOutlineIcon className={processingStep >= 1 ? "processed" : "processsing"} />
                                        </Box>
                                        <Box pt={'4px'}>
                                            <Typography variant='h6' className='fw6'>Data Collection</Typography>
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={4} md={4} sm={12} xs={12}>
                                    <Box className={`grybx ${processingStep >= 2 ? 'processed' : 'processsing'}`}>
                                        <Box>
                                            <CheckCircleOutlineIcon className={processingStep >= 2 ? "processed" : "processsing"} />
                                        </Box>
                                        <Box pt={'4px'}>
                                            <Typography variant='h6' className='fw6'>Data Preparation</Typography>
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={4} md={4} sm={12} xs={12}>
                                    <Box className={`grybx ${processingStep >= 3 ? 'processed' : 'processsing'}`}>
                                        <Box>
                                            <CheckCircleOutlineIcon className={processingStep >= 3 ? "processed" : "processsing"} />
                                        </Box>
                                        <Box pt={'4px'}>
                                            <Typography variant='h6' className='fw6'>Training / Finetuning</Typography>
                                        </Box>
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center' mt={1} mb={2}>
                                        <Button variant='contained' className='secondary-btn' onClick={handleClose1} disabled={!isProcessingDone}>
                                            Ok
                                        </Button>
                                    </Box>
                                </Grid>

                            </Grid>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog>


        </>
    )
}

export default page