"use client"
import React from 'react'
import MainLayout from '../layouts/MainLayout'
import PageHeading from '@/components/PageHeading'
import { Box, Container } from '@mui/material'
import HealthHistoryTabs from './_tabs/HealthHistoryTabs'


const page = () => {

    return (

        <>
            {/* <MainLayout> */}
            <Box>
                <PageHeading title={"Radar Health History"} note={"As on 8th February 2024"} />
            </Box>

            {/* <Box className="inner-page-scroll"> */}

                <Container maxWidth>
                    <Box id="page-content">
                        <HealthHistoryTabs />
                    </Box>
                </Container>

            {/* </Box> */}
            {/* </MainLayout> */}

        </>
    )
}

export default page