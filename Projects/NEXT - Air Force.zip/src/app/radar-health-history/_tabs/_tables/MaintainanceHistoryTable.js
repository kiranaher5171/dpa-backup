"use client";
import React from 'react'
import { Box, IconButton } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/TableSkeleton';
import AgGridInfo from '@/components/AgGridInfo';
import AgGridPagination from '@/components/AgGridPagination';

import EditOutlinedIcon from '@mui/icons-material/EditOutlined';


const MaintainanceHistoryTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const rowHeight = 25;
    const headerHeight = 30;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: true, flex: 1, suppressMovable: false, resizable: true
    }

    const rowStyle = { background: '#ffffff' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'rgb(249, 252, 255)' };
        }
    };

    const [rowData] = useState([
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
    ]);


    const columnDefs = [
        {
            headerName: 'Maintainance Date', field: 'date', maxWidth: 160, minWidth: 160, cellRenderer: () => "18-10-2023",
        },
        {
            headerName: 'Component Name', field: 'name', maxWidth: 180, minWidth: 160, cellRenderer: () => "Component 1",
        },
        {
            headerName: 'Description', field: 'desc', minWidth: 200, cellRenderer: () => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum",
        },
        {
            headerName: 'Created On', field: 'cdate', maxWidth: 180, minWidth: 160, cellRenderer: () => "22-05-2023",
        },
        {
            headerName: 'Created By', field: 'cname', maxWidth: 180, minWidth: 160, cellRenderer: () => "Mohan Patil",
        },
        {
            headerName: 'Updated On', field: 'udate', maxWidth: 180, minWidth: 160, cellRenderer: () => "07-08-2024",
        },
        {
            headerName: 'Updated By', field: 'uname', maxWidth: 180, minWidth: 160, cellRenderer: () => "Mohan Patil",
        },
        {
            headerName: 'Modify', field: 'action', maxWidth: 100, minWidth: 80,
            cellRenderer: () => {
                return (
                    <>
                        <Box className={"fx_se"}>
                            <IconButton size='small' aria-label="Edit">
                                <EditOutlinedIcon fontSize='small' className='green' />
                            </IconButton>
                        </Box>
                    </>
                );
            },
        },
    ];


    return (
        <>
            <Box className="">
                {loading ? (
                    <Box className="radar-health-history-table" style={{ width: '100%', height: '35vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz radar-health-history-table" style={{ width: '100%', height: '35vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                                getRowStyle={getRowStyle}
                                rowStyle={rowStyle}
                            />
                        </Box>
                        <Box id="tb_footer" className="fx_sb" mt={1}>
                            <AgGridInfo />
                            <AgGridPagination />
                        </Box>
                    </>
                )}
            </Box>




        </>
    )
}

export default MaintainanceHistoryTable