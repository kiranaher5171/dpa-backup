"use client";
import React from 'react'
import { Box } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/TableSkeleton';
import AgGridInfo from '@/components/AgGridInfo';
import AgGridPagination from '@/components/AgGridPagination';



const PredictionHistoryTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const rowHeight = 25;
    const headerHeight = 30;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: true, flex: 1, suppressMovable: false, resizable: true
    }

    const rowStyle = { background: '#ffffff' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            // return { background: 'rgb(249, 252, 255)' };
            return { background: 'rgb(251, 251, 251)' };
        }
    };

    const [rowData] = useState([
        { prediction: "fault" }, {}, { prediction: "fault" }, {}, { prediction: "fault" },
        { prediction: "fault" }, {}, { prediction: "fault" }, {}, { prediction: "fault" },
        { prediction: "fault" }, {}, { prediction: "fault" }, {}, { prediction: "fault" },
        { prediction: "fault" }, {}, { prediction: "fault" }, {}, { prediction: "fault" },
        { prediction: "fault" }, {}, { prediction: "fault" }, {}, { prediction: "fault" },
        { prediction: "fault" }, {}, { prediction: "fault" }, {}, { prediction: "fault" },
    ]);


    const columnDefs = [
        {
            headerName: 'Date', field: 'date', maxWidth: 160, minWidth: 160, cellRenderer: () => "18-10-2023",
        },
        {
            headerName: 'Radar', field: 'radar', maxWidth: 160, minWidth: 160, cellRenderer: () => "Radar 01",
        },
        {
            headerName: 'Prediction', field: 'pred', maxWidth: 200, minWidth: 160,
            cellRenderer: (params) => {
                const { prediction } = params.data;
                return (
                    <>
                        {prediction === 'fault' ? (
                            <>
                                <span className="red"> Fault </span>
                            </>
                        ) : (
                            <>
                                <span className="green"> No Fault </span>
                            </>
                        )}
                    </>
                );
            },
        },
        {
            headerName: 'Severity', field: 'severity', maxWidth: 200, minWidth: 160,
            cellRenderer: (params) => {
                const { prediction } = params.data;
                return (
                    <>
                        {prediction === 'fault' ? (
                            <>
                                Moderate
                            </>
                        ) : (
                            <>
                                Normal
                            </>
                        )}
                    </>
                );
            },
        },
        {
            headerName: 'Description', field: 'desc', minWidth: 200, cellRenderer: () => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum",
        },
    ];


    return (
        <>
            <Box className="">
                {loading ? (
                    <Box className="radar-health-history-table" style={{ width: '100%', height: '35vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz radar-health-history-table" style={{ width: '100%', height: '35vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                                getRowStyle={getRowStyle}
                                rowStyle={rowStyle}
                            />
                        </Box>
                        <Box id="tb_footer" className="fx_sb" mt={1}>
                            <AgGridInfo />
                            <AgGridPagination />
                        </Box>
                    </>
                )}
            </Box>




        </>
    )
}

export default PredictionHistoryTable