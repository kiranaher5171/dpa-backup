"use client"
import React from 'react'
import { Box, Grid, Divider, Typography, TextField, Button, Stack, IconButton } from '@mui/material'
import Autocomplete from '@mui/material/Autocomplete';
import SimpleDatePicker from '@/components/SimpleDatePicker'
import CachedOutlinedIcon from '@mui/icons-material/CachedOutlined';
import MaintainanceHistoryTable from './_tables/MaintainanceHistoryTable';
import CardHeading from '@/components/CardHeading';



const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]


const MaintainanceHistory = () => {

    return (

        <>


            <Box className="alicebx" mb={2}>
                <Box>
                    <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                        <Grid item lg={2} md={3} sm={4} xs={6}>
                            <Box className='textfield'>
                                <Typography variant='body' className='label'>From</Typography>
                                <SimpleDatePicker />
                            </Box>
                        </Grid>

                        <Grid item lg={2} md={3} sm={4} xs={6}>
                            <Box className='textfield'>
                                <Typography variant='body' className='label'>To</Typography>
                                <SimpleDatePicker />
                            </Box>
                        </Grid>

                        <Grid item lg={2} md={3} sm={4} xs={6}>
                            <Box className='textfield auto-complete'>
                                <Typography variant='body' className='label'>Component</Typography>
                                <Autocomplete
                                    disablePortal
                                    fullWidth
                                    id="combo-box-demo"
                                    options={options}
                                    renderInput={(params) => <TextField {...params} placeholder="Select Component" variant='outlined' size='small' />}
                                />
                            </Box>
                        </Grid>

                        <Grid item lg={2} md={3} sm={4} xs={6}>
                            <Box className='textfield auto-complete'>
                                <Typography variant='body' className='label'>Select Radar Unit</Typography>
                                <Autocomplete
                                    disablePortal
                                    fullWidth
                                    id="combo-box-demo"
                                    options={options}
                                    renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                />
                            </Box>
                        </Grid>


                        <Grid item lg={2} md={3} sm={4} xs={6}>
                            <Stack direction={"row"} spacing={1} justifyContent={"flex-start"} alignItems={"center"}>
                                <Box>
                                    <Typography variant='body' className='label'>&nbsp;</Typography>
                                    <Box>
                                        <IconButton size='medium'>
                                            <CachedOutlinedIcon fontSize='small' className='skyblue' />
                                        </IconButton>
                                    </Box>
                                </Box>

                                <Box>
                                    <Typography variant='body' className='label'>&nbsp;</Typography>
                                    <Box className="left">
                                        <Button variant='outlined' className='primary-btn' size='small'>Search</Button>
                                    </Box>
                                </Box>
                            </Stack>
                        </Grid>



                    </Grid>
                </Box>
            </Box>


            <Box className="whitebx">
                {/* <Box className="fx_sb" mb={1}>
                    <Typography variant='h5' className='blue fw5'>Maintainance History</Typography>
                </Box> */}
                <CardHeading heading={"Maintainance History"}/>

                <Divider />

                <Box mt={1}>
                    <MaintainanceHistoryTable />
                </Box>
            </Box>

        </>
    )
}

export default MaintainanceHistory