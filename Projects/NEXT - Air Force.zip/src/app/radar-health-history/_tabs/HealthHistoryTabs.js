"use client"
import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import PredictionHistory from './PredictionHistory';
import MaintainanceHistory from './MaintainanceHistory';
import FailureLogs from './FailureLogs';

export default function HealthHistoryTabs() {
    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <>
            <Box id={"simpleTabs"}>
                <TabContext value={value}>
                    <Box>
                        <TabList onChange={handleChange} aria-label="Radar Health History tabs" allowScrollButtonsMobile={"true"} variant='scrollable'>
                            <Tab label="Prediction History" value="1" />
                            <Tab label="Maintainance History" value="2" />
                            <Tab label="Failure Logs" value="3" />
                        </TabList>
                    </Box>
                    <TabPanel value="1">
                        <PredictionHistory />
                    </TabPanel>
                    <TabPanel value="2">
                        <MaintainanceHistory />
                    </TabPanel>
                    <TabPanel value="3">
                        <FailureLogs />
                    </TabPanel>
                </TabContext>
            </Box>
        </>
    );
}
