"use client";
import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import IconButton from '@mui/material/IconButton';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import logo from '../../../public/assets/logo.png';
import { AppBar, Avatar, Button, Divider, Toolbar, Tooltip } from '@mui/material';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import Image from 'next/image';
import Profile from '../../../public/assets/profile-pic.png';
import Link from 'next/link';
import Footer from '@/components/Footer';
import LogoutIcon from '@mui/icons-material/Logout';
import { usePathname } from 'next/navigation'; // Import usePathname

import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import MobileDrawer from './MobileDrawer';

import MonitorHeartOutlinedIcon from '@mui/icons-material/MonitorHeartOutlined';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import KeyboardAltOutlinedIcon from '@mui/icons-material/KeyboardAltOutlined';
import WifiOutlinedIcon from '@mui/icons-material/WifiOutlined';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import HealthAndSafetyOutlinedIcon from '@mui/icons-material/HealthAndSafetyOutlined';

import { useMediaQuery } from '@mui/material';


import MenuIcon from '@mui/icons-material/Menu';
import MenuOpenIcon from '@mui/icons-material/MenuOpen';


const drawerWidth = 260;

const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
});

const closedMixin = (theme) => ({
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: `calc(${theme.spacing(10)} + 1px)`,
    [theme.breakpoints.up('sm')]: {
        width: `calc(${theme.spacing(10)} + 1px)`,
    },
});

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        width: drawerWidth,
        flexShrink: 0,
        whiteSpace: 'nowrap',
        boxSizing: 'border-box',
        ...(open && {
            ...openedMixin(theme),
            '& .MuiDrawer-paper': openedMixin(theme),
        }),
        ...(!open && {
            ...closedMixin(theme),
            '& .MuiDrawer-paper': closedMixin(theme),
        }),
    }),
);





export default function MainLayout({ children }) {
    const [open, setOpen] = React.useState(true);


    const handleDrawerToggle = () => {
        const newOpenState = !open;
        setOpen(newOpenState);
        localStorage.setItem('drawerState', newOpenState);
    };

    React.useEffect(() => {
        const savedState = localStorage.getItem('drawerState');
        if (savedState !== null) {
            setOpen(JSON.parse(savedState));
        }
    }, []);


    const pathname = usePathname();

    const menuItems = [
        { href: '/data-entry', title: 'Data Entry', icon: <KeyboardAltOutlinedIcon fontSize="small" /> },
        { href: '/failure-or-maintainance', title: 'Failure / Maintainance', icon: <ErrorOutlineOutlinedIcon fontSize="small" /> },
        { href: '/radar-status', title: 'Radar Status', icon: <WifiOutlinedIcon fontSize="small" /> },
        { href: '/radar-health-summary', title: 'Radar Health Summary', icon: <HealthAndSafetyOutlinedIcon fontSize="small" /> },
        { href: '/radar-health-history', title: 'Radar Health History', icon: <MonitorHeartOutlinedIcon fontSize="small" /> },
        { href: '/model-health', title: 'Model Health', icon: <DescriptionOutlinedIcon fontSize="small" /> },
        { href: '/user-management', title: 'User Management', icon: <PersonOutlinedIcon fontSize="small" /> },
    ];


    const isActive = (href) => {
        return pathname.startsWith(href);
    };


    const isMobile = useMediaQuery('(max-width:800px)');



    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />

            <AppBar position="fixed" open={open} id="mobile-header">
                <Toolbar className='fx_sb'>
                    <Box className="logo-container">
                        <Image src={logo} className={'smlogo'} alt="Indian Air Force" priority />
                    </Box>
                    <Box className="fx_fe">
                        <IconButton size='small'>
                            <Avatar>
                                <Image src={Profile} height={30} width={30} className="profile" alt="Mohan Patil" priority />
                            </Avatar>
                        </IconButton>

                        <MobileDrawer />

                        <Link href={"/"} passHref>
                            <IconButton size='small'>
                                <LogoutIcon fontSize='small' className='skyblue' />
                            </IconButton>
                        </Link>
                    </Box>
                </Toolbar>
            </AppBar>

            <Drawer variant="permanent" open={open} className="drawer">
                <Box className="sidebar-bg">
                    <Box className="fx_sb" m={'14px'} mt={'22px'}>
                        <Box className="w100 center">
                            <Box className="logo-container">
                                <Image src={logo} className={`${open ? 'lglogo' : 'smlogo'}`} alt="Logo" />
                            </Box>
                        </Box>
                        {/* <Box className="sidebar-handler22">
                            <IconButton onClick={handleDrawerToggle} size="small">
                                {open ? (
                                    <KeyboardBackspaceIcon fontSize="small" className="black" />
                                ) : (
                                    <KeyboardDoubleArrowRightIcon fontSize="small" className="blue" />
                                )}
                            </IconButton>
                        </Box> */}
                    </Box>

                    <Divider />

                    <Box id="menus" className="user-profile">
                        <List>
                            <ListItem disablePadding>
                                <ListItemButton disableRipple className='no-events'>
                                    <Tooltip title="Profile" arrow placement="right">
                                        <ListItemAvatar>
                                            <Avatar>
                                                <Image src={Profile} height={40} width={40} className="profile" alt="Mohan Patil" />
                                            </Avatar>
                                        </ListItemAvatar>
                                    </Tooltip>
                                    <ListItemText primary={<>
                                        <span className="black">Mohan Patil</span>
                                    </>}
                                        sx={{ opacity: open ? 1 : 0 }} />
                                </ListItemButton>
                            </ListItem>
                        </List>
                    </Box>

                    <Box id="menus" className="">
                        <List>
                            {menuItems.map((item) => (
                                <Link href={item.href} passHref key={item.href}>
                                    <ListItem disablePadding>
                                        <ListItemButton selected={isActive(item.href)}>
                                            <Tooltip title={item.title} arrow placement="right">
                                                <ListItemIcon>
                                                    {item.icon}
                                                </ListItemIcon>
                                            </Tooltip>
                                            <ListItemText primary={item.title} sx={{ opacity: open ? 1 : 0 }} />
                                        </ListItemButton>
                                    </ListItem>
                                </Link>
                            ))}
                        </List>



                    </Box>


                    <Box id="menus" className="log-out">
                        <List>
                            <Link href="/" passHref>
                                <ListItem disablePadding>
                                    <ListItemButton>
                                        <Tooltip title={"Log Out"} arrow placement="right">
                                            <ListItemIcon>
                                                <LogoutIcon />
                                            </ListItemIcon>
                                        </Tooltip>
                                        <ListItemText primary={"Log Out"} sx={{ opacity: open ? 1 : 0 }} />
                                    </ListItemButton>
                                </ListItem>
                            </Link>
                        </List>
                    </Box>

                </Box>
            </Drawer>

            <Box component="main" className="main-layout-content">

                <Box className="positioned-handler">
                    <IconButton onClick={handleDrawerToggle} size="small">
                        {open ? (
                            <MenuOpenIcon fontSize="small" className="white" />
                        ) : (
                            <MenuIcon fontSize="small" className="white" />
                        )}
                    </IconButton>
                </Box>


                {children}
                {/* show this footer if my viewport id below 800 */}
                {isMobile ? (
                    <Footer clsName={"footer2"} />
                ) : (
                    <>
                        <Footer clsName={"footer"} />
                    </>
                )}
            </Box> 
        </Box>
    );
}
