"use client"
import * as React from 'react';
import { useState } from 'react';
import { Drawer, IconButton } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import MobileDrawerContent from './MobileDrawerContent';



export default function MobileDrawer() {
    const [state, setState] = useState({ right: false });

    const toggleDrawer = (anchor, open) => () => {
        setState({ ...state, [anchor]: open });
    };

    const isDrawerOpen = state['right'];

    const handleCloseDrawer = () => {
        setState({ ...state, right: false });
    };

    return (
        <>
            <IconButton
                className='drawer_btn'
                size='medium'
                onClick={toggleDrawer('right', !isDrawerOpen)}
            >
                {isDrawerOpen ? <CloseIcon fontSize='small' className='wh' /> : <MenuIcon fontSize='small' className='wh' />}
            </IconButton>

            <Drawer id='mobile-drawer' anchor="right" open={isDrawerOpen} onClose={toggleDrawer('right', false)}>

                <MobileDrawerContent onClose={handleCloseDrawer} />

            </Drawer>
        </>
    );
}
