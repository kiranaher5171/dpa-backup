"use client";
import * as React from 'react';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import { Tooltip } from '@mui/material';
import Link from 'next/link';
import MonitorHeartOutlinedIcon from '@mui/icons-material/MonitorHeartOutlined';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import KeyboardAltOutlinedIcon from '@mui/icons-material/KeyboardAltOutlined';
import WifiOutlinedIcon from '@mui/icons-material/WifiOutlined'; 
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import { usePathname } from 'next/navigation'; // Import usePathname
import HealthAndSafetyOutlinedIcon from '@mui/icons-material/HealthAndSafetyOutlined';




export default function MobileDrawerContent({ onClose }) {

    const pathname = usePathname(); // Use usePathname hook


    // const isActive = (href) => {
    //     return pathname === href;
    // };

    const isActive = (href) => {
        return pathname.startsWith(href);
    };
    

    const menuItems = [
        { href: '/data-entry', title: 'Data Entry', icon: <KeyboardAltOutlinedIcon fontSize="small" /> },
        { href: '/failure-or-maintainance', title: 'Failure / Maintainance', icon: <ErrorOutlineOutlinedIcon fontSize="small" /> },
        { href: '/radar-status', title: 'Radar Status', icon: <WifiOutlinedIcon fontSize="small" /> },
        { href: '/radar-health-summary', title: 'Radar Health Summary', icon: <HealthAndSafetyOutlinedIcon fontSize="small" /> },
        { href: '/radar-health-history', title: 'Radar Health History', icon: <MonitorHeartOutlinedIcon fontSize="small" /> },
        { href: '/model-health', title: 'Model Health', icon: <DescriptionOutlinedIcon fontSize="small" /> },
        { href: '/user-management', title: 'User Management', icon: <PersonOutlinedIcon fontSize="small" /> },
    ];




    return (
        <>
            <Box className="sidebar-bg">
                <Box mt={'60px'} />

                <Box id="menus">
                    <List>
                        {menuItems.map((item) => (
                            <Link href={item.href} passHref key={item.href}>
                                <ListItem disablePadding>
                                    <ListItemButton onClick={onClose} selected={isActive(item.href)}>
                                        <Tooltip title={item.title} arrow placement="right">
                                            <ListItemIcon>
                                                {item.icon}
                                            </ListItemIcon>
                                        </Tooltip>
                                        <ListItemText primary={item.title} />
                                    </ListItemButton>
                                </ListItem>
                            </Link>
                        ))}
                    </List>

                </Box>
            </Box>
        </>
    );
}
