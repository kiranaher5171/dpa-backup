import React from 'react'
import MainLayout from '../layouts/MainLayout'

const Sample = () => {
    return (
        <>
            <MainLayout>
                Sample
            </MainLayout>
        </>
    )
}

export default Sample