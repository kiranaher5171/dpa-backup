"use client";
import React from 'react'
import { Box, IconButton, InputAdornment, Grid, Button, Divider, Typography, TextField, } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import Image from 'next/image';
import TableSkeleton from '@/components/TableSkeleton';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import CloseIcon from '@mui/icons-material/Close';
import Autocomplete from '@mui/material/Autocomplete';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import Checkbox from '@mui/material/Checkbox';
import OutlinedInput from '@mui/material/OutlinedInput';
import Save from "../../../public/assets/success.png";


const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]


const AdminTable = () => {



    const [open1, setOpen1] = React.useState(false);
    const handleClickOpen1 = () => {
        setOpen1(true);
    };
    const handleClose1 = () => {
        setOpen1(false);
    };


    const [open2, setOpen2] = React.useState(false);
    const handleClickOpen2 = () => {
        setOpen1(false);
        setOpen2(true);
    };
    const handleClose2 = () => {
        setOpen2(false);
    };

    const [changePassword, setChangePassword] = React.useState(false);
    const handleChangePasswordCheckbox = (event) => { setChangePassword(event.target.checked); };


    // input handleers
    const [values, setValues] = React.useState({
        password: '',
        showPassword: false,
    });

    const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
    };

    const handleClickShowPassword = () => {
        setValues({ ...values, showPassword: !values.showPassword });
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };






    const [gridApi, setGridApi] = useState(null);

    const rowHeight = 25;
    const headerHeight = 30;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: true, flex: 1, suppressMovable: false, resizable: true
    }

    const rowStyle = { background: '#ffffff' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'rgb(249, 252, 255)' };
        }
    };

    const [rowData] = useState([
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
        {}, {}, {}, {}, {},
    ]);


    const columnDefs = [
        {
            headerName: 'Username', field: 'name', minWidth: 220, cellRenderer: () => "User A",
        },
        {
            headerName: 'Create Date', field: 'date', maxWidth: 300, minWidth: 160, cellRenderer: () => "18-10-2023",
        },
        {
            headerName: 'Status', field: 'status', maxWidth: 300, minWidth: 220, cellRenderer: () => "Active",
        },
        {
            headerName: 'Role', field: 'role', maxWidth: 300, minWidth: 220, cellRenderer: () => "Data Entry",
        },
        {
            headerName: 'Last Update', field: 'date2', maxWidth: 300, minWidth: 160, cellRenderer: () => "28-07-2024",
        },
        {
            headerName: 'User Permission', field: 'action', maxWidth: 300, minWidth: 140,
            cellRenderer: () => {
                return (
                    <>
                        <Box className={"fx_se"}>
                            <IconButton size='small' aria-label="Edit" onClick={handleClickOpen1}>
                                <EditOutlinedIcon fontSize='small' className='green' />
                            </IconButton>
                        </Box>
                    </>
                );
            },
        },
    ];


    return (
        <>
            <Box className="">
                {loading ? (
                    <Box className="user-management-table" style={{ width: '100%', height: '35vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <Box className="ag-theme-quartz user-management-table" style={{ width: '100%', height: '35vh' }}>
                        <AgGridReact
                            onGridReady={onGridReady}
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            rowHeight={rowHeight}
                            headerHeight={headerHeight}
                            getRowStyle={getRowStyle}
                            rowStyle={rowStyle}
                        />
                    </Box>
                )}
            </Box>







            <Dialog open={open1} onClose={handleClose1} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description" >
                <DialogTitle id="alert-dialog-title">
                    <Typography variant='h4' className='h4v2'>
                        {"User Permissions"}
                    </Typography>
                </DialogTitle>
                <IconButton aria-label="close" onClick={handleClose1} sx={{ position: 'absolute', right: 8, top: 8, }} >
                    <CloseIcon />
                </IconButton>
                <Divider />
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box>

                            <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>Username</Typography>
                                        <OutlinedInput
                                            id="username"
                                            placeholder='Username'
                                            fullWidth
                                            inputProps={{
                                                'aria-label': 'username',
                                            }}
                                        />
                                    </Box>
                                </Grid>

                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield auto-complete'>
                                        <Typography variant='body' className='label'>Role</Typography>
                                        <Autocomplete
                                            disablePortal
                                            fullWidth
                                            id="combo-box-demo"
                                            options={options}
                                            renderInput={(params) => <TextField {...params} placeholder="Role" variant='outlined' size='small' />}
                                        />
                                    </Box>
                                </Grid>


                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='switch'>
                                        <span className='green'>Active</span>
                                        <FormControlLabel control={<Switch />} />
                                        <span className='red'>Inactive</span>
                                    </Box>
                                </Grid>

                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='checkbox'>
                                        <FormControlLabel
                                            control={<Checkbox checked={changePassword} onChange={handleChangePasswordCheckbox} />}
                                            label={changePassword ? <span className='blue'>Change Password</span> : <span className='light-gray'>Change Password</span>}
                                        />
                                    </Box>
                                </Grid>


                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>Admin Password</Typography>
                                        <OutlinedInput
                                            id="admin-password"
                                            placeholder='Admin Password'
                                            fullWidth
                                            type={values.showPassword ? 'text' : 'password'}
                                            value={values.password}
                                            onChange={handleChange('password')}
                                            endAdornment={<InputAdornment position="end">
                                                <IconButton
                                                    size="small"
                                                    aria-label="toggle password visibility"
                                                    onClick={handleClickShowPassword}
                                                    onMouseDown={handleMouseDownPassword}
                                                    edge="end"
                                                >
                                                    {values.showPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                                </IconButton>
                                            </InputAdornment>}
                                        />
                                    </Box>
                                </Grid>



                                {changePassword && (
                                    <>

                                        <Grid item lg={6} md={6} sm={12} xs={12}>
                                            <Box className='textfield'>
                                                <Typography variant='body' className='label'>Password</Typography>
                                                <OutlinedInput
                                                    id="password"
                                                    placeholder='Password'
                                                    fullWidth
                                                    type={values.showPassword ? 'text' : 'password'}
                                                    value={values.password}
                                                    onChange={handleChange('password')}
                                                    endAdornment={<InputAdornment position="end">
                                                        <IconButton
                                                            size="small"
                                                            aria-label="toggle password visibility"
                                                            onClick={handleClickShowPassword}
                                                            onMouseDown={handleMouseDownPassword}
                                                            edge="end"
                                                        >
                                                            {values.showPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                                        </IconButton>
                                                    </InputAdornment>}
                                                />
                                            </Box>
                                        </Grid>

                                        <Grid item lg={6} md={6} sm={12} xs={12}>
                                            <Box className='textfield'>
                                                <Typography variant='body' className='label'>Confirm Password</Typography>
                                                <OutlinedInput
                                                    id="confirm-password"
                                                    placeholder='Confirm Password'
                                                    fullWidth
                                                    type={values.showPassword ? 'text' : 'password'}
                                                    value={values.password}
                                                    onChange={handleChange('password')}
                                                    endAdornment={<InputAdornment position="end">
                                                        <IconButton
                                                            size="small"
                                                            aria-label="toggle password visibility"
                                                            onClick={handleClickShowPassword}
                                                            onMouseDown={handleMouseDownPassword}
                                                            edge="end"
                                                        >
                                                            {values.showPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                                        </IconButton>
                                                    </InputAdornment>}
                                                />
                                            </Box>
                                        </Grid>

                                    </>
                                )}


                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>&nbsp;</Typography>
                                        <Box className="left">
                                            <Button variant='contained' className='secondary-btn' onClick={handleClickOpen2}>
                                                Save
                                            </Button>
                                        </Box>
                                    </Box>
                                </Grid>



                            </Grid>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog>




            <Dialog open={open2} onClose={handleClose2} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description" >
                <IconButton aria-label="close" onClick={handleClose2} sx={{ position: 'absolute', right: 8, top: 8, }} >
                    <CloseIcon />
                </IconButton>
                <Divider />
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box>

                            <Grid container alignItems="center" justifyContent='center' spacing={2}>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center'>
                                        <Image src={Save} alt="saved" className="dialog-img" />
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center'>
                                        <Typography variant='h4' className='green fw5'>Save successful!</Typography>
                                        <Typography variant='h5' className='gray fw5'>Your data is safe now.</Typography>
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center' mt={1} mb={2}>
                                        <Button variant='contained' className='secondary-btn' onClick={handleClose2}>
                                            Close
                                        </Button>
                                    </Box>
                                </Grid>


                            </Grid>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog >



        </>
    )
}

export default AdminTable