"use client"
import React from 'react'
import MainLayout from '../layouts/MainLayout'
import { Box, Button, Container, Divider, IconButton, Typography, Grid, InputAdornment, TextField } from '@mui/material'
import PageHeading from '@/components/PageHeading'
import PersonAddAltOutlinedIcon from '@mui/icons-material/PersonAddAltOutlined';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import CloseIcon from '@mui/icons-material/Close';
import OutlinedInput from '@mui/material/OutlinedInput';
import Autocomplete from '@mui/material/Autocomplete';

import Save from "../../../public/assets/success.png";
import Image from 'next/image'


import dynamic from 'next/dynamic';
const AdminTable = dynamic(() => import('./AdminTable'));



const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]

const page = () => {


    const [open1, setOpen1] = React.useState(false);
    const handleClickOpen1 = () => {
        setOpen1(true);
    };
    const handleClose1 = () => {
        setOpen1(false);
    };


    const [open2, setOpen2] = React.useState(false);
    const handleClickOpen2 = () => {
        setOpen1(false);
        setOpen2(true);
    };
    const handleClose2 = () => {
        setOpen2(false);
    };



    const [values, setValues] = React.useState({
        password: '',
        showPassword: false,
    });

    const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
    };

    const handleClickShowPassword = () => {
        setValues({ ...values, showPassword: !values.showPassword });
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };





    return (
        <>
            {/* <MainLayout> */}
                <Box>
                    <PageHeading title={"Admin"} note={"As on 8th February 2024"} />
                </Box>

                <Container maxWidth>
                    <Box id="page-content">

                        <Box className="whitebx">
                            <Box className="fx_sb" mb={1}>
                                <Typography variant='h5' className='card-heading fw5'>User Details</Typography>

                                <Button variant='outlined' className='secondary-btn' size='small' startIcon={<PersonAddAltOutlinedIcon fontSize='small' />} onClick={handleClickOpen1}>Add New User</Button>
                            </Box>

                            <Divider />

                            <Box mt={1}>
                                <AdminTable />
                            </Box>
                        </Box>
                    </Box>
                </Container>
            {/* </MainLayout> */}





            <Dialog open={open1} onClose={handleClose1} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description" >
                <DialogTitle id="alert-dialog-title">
                    <Typography variant='h4' className='h4v2'>
                        {"Add New User"}
                    </Typography>
                </DialogTitle>
                <IconButton aria-label="close" onClick={handleClose1} sx={{ position: 'absolute', right: 8, top: 8, }} >
                    <CloseIcon />
                </IconButton>
                <Divider />
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box>

                            <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>Username</Typography>
                                        <OutlinedInput
                                            id="username"
                                            placeholder='Username'
                                            fullWidth
                                            inputProps={{
                                                'aria-label': 'username',
                                            }}
                                        />
                                    </Box>
                                </Grid>

                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield auto-complete'>
                                        <Typography variant='body' className='label'>Role</Typography>
                                        <Autocomplete
                                            disablePortal
                                            fullWidth
                                            id="combo-box-demo"
                                            options={options}
                                            renderInput={(params) => <TextField {...params} placeholder="Role" variant='outlined' size='small' />}
                                        />
                                    </Box>
                                </Grid>


                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>Password</Typography>
                                        <OutlinedInput
                                            id="password"
                                            placeholder='Password'
                                            fullWidth
                                            type={values.showPassword ? 'text' : 'password'}
                                            value={values.password}
                                            onChange={handleChange('password')}
                                            endAdornment={<InputAdornment position="end">
                                                <IconButton
                                                    size="small"
                                                    aria-label="toggle password visibility"
                                                    onClick={handleClickShowPassword}
                                                    onMouseDown={handleMouseDownPassword}
                                                    edge="end"
                                                >
                                                    {values.showPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                                </IconButton>
                                            </InputAdornment>}
                                        />
                                    </Box>
                                </Grid>

                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>Confirm Password</Typography>
                                        <OutlinedInput
                                            id="confirm-password"
                                            placeholder='Confirm Password'
                                            fullWidth
                                            type={values.showPassword ? 'text' : 'password'}
                                            value={values.password}
                                            onChange={handleChange('password')}
                                            endAdornment={<InputAdornment position="end">
                                                <IconButton
                                                    size="small"
                                                    aria-label="toggle password visibility"
                                                    onClick={handleClickShowPassword}
                                                    onMouseDown={handleMouseDownPassword}
                                                    edge="end"
                                                >
                                                    {values.showPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                                </IconButton>
                                            </InputAdornment>}
                                        />
                                    </Box>
                                </Grid>


                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>Admin Password</Typography>
                                        <OutlinedInput
                                            id="admin-password"
                                            placeholder='Admin Password'
                                            fullWidth
                                            type={values.showPassword ? 'text' : 'password'}
                                            value={values.password}
                                            onChange={handleChange('password')}
                                            endAdornment={<InputAdornment position="end">
                                                <IconButton
                                                    size="small"
                                                    aria-label="toggle password visibility"
                                                    onClick={handleClickShowPassword}
                                                    onMouseDown={handleMouseDownPassword}
                                                    edge="end"
                                                >
                                                    {values.showPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                                                </IconButton>
                                            </InputAdornment>}
                                        />
                                    </Box>
                                </Grid>


                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className='textfield'>
                                        <Typography variant='body' className='label'>&nbsp;</Typography>
                                        <Box className="left">
                                            <Button variant='contained' className='secondary-btn' onClick={handleClickOpen2}>
                                                Create
                                            </Button>
                                        </Box>
                                    </Box>
                                </Grid>


                            </Grid>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog>




            <Dialog open={open2} onClose={handleClose2} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description" >
                <IconButton aria-label="close" onClick={handleClose2} sx={{ position: 'absolute', right: 8, top: 8, }} >
                    <CloseIcon />
                </IconButton>
                <Divider />
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Box>

                            <Grid container alignItems="center" justifyContent='center' spacing={2}>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center'>
                                        <Image src={Save} alt="saved" className="dialog-img" />
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center'>
                                        <Typography variant='h4' className='green fw5'>Save successful!</Typography>
                                        <Typography variant='h5' className='gray fw5'>Your data is safe now.</Typography>
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className='center' mt={1} mb={2}>
                                        <Button variant='contained' className='secondary-btn' onClick={handleClose2}>
                                            Close
                                        </Button>
                                    </Box>
                                </Grid>


                            </Grid>
                        </Box>
                    </DialogContentText>
                </DialogContent>
            </Dialog>




        </>
    )
}

export default page