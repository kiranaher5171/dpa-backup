"use client"
import React from 'react'
import PageHeading from '@/components/PageHeading'
import { Box, Grid, Divider, Typography, TextField, Button, Stack, IconButton, Container } from '@mui/material'
// import RadarStatusTable from './RadarStatusTable'
import Autocomplete from '@mui/material/Autocomplete';
import SimpleDatePicker from '@/components/SimpleDatePicker'
import CachedOutlinedIcon from '@mui/icons-material/CachedOutlined';
import MainLayout from '@/app/layouts/MainLayout';
import RadarDetailsTable from './RadarDetailsTable';
import Link from 'next/link';

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]



const page = () => {

    return (

        <>
            {/* <MainLayout> */}
                <Box>
                    <PageHeading title={"Radar Status"} note={"As on 8th February 2024"} />
                </Box>

                <Container maxWidth>
                    <Box id="page-content">


                        {/* <Box className="alicebx" mb={2}>
                            <Box>
                                <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield'>
                                            <Typography variant='body' className='label'>Select Date</Typography>
                                            <SimpleDatePicker />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Select Radar Unit</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Stack direction={"row"} spacing={2} justifyContent={"flex-start"} alignItems={"center"}>
                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box>
                                                    <IconButton size='medium'>
                                                        <CachedOutlinedIcon fontSize='small' className='skyblue' />
                                                    </IconButton>
                                                </Box>
                                            </Box>

                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box className="left">
                                                    <Button variant='outlined' className='primary-btn' size='small'>Search</Button>
                                                </Box>
                                            </Box>
                                        </Stack>
                                    </Grid>



                                </Grid>
                            </Box>
                        </Box> */}


                        <Box className="whitebx">
                            <Box className="fx_sb" mb={1}>
                                <Typography variant='h5' className='card-heading fw5'>Radar 01</Typography>
                                {/* <Typography variant='h5' className='blue fw5'>Back</Typography> */}
                                <Box className="left">
                                    <Link href="/radar-status">
                                        <Button variant='outlined' className='tertiary-btn' size='small'>Back</Button>
                                    </Link>
                                </Box>
                            </Box>

                            <Divider />

                            <Box mt={1}>
                                <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={2}>
                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                        <Box>
                                            <RadarDetailsTable />
                                        </Box>
                                    </Grid>
                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                        <Box>
                                            <RadarDetailsTable />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                        <Box className="fx_fs">
                                            <Typography variant='h6' className='blue fw6'>Pre-Processing : </Typography>
                                            <Typography variant='h6' className='red fw6'> &nbsp; Failure </Typography>
                                            <Typography variant='h6' className='gray fw6'> &nbsp; | &nbsp; </Typography>
                                            <Typography variant='h6' className='gray fw5'> Authentication failed to access database while fetching data </Typography>
                                        </Box>

                                        <Box className="fx_fs" mt={1}>
                                            <Typography variant='h6' className='blue fw6'>Prediction Result : </Typography>
                                            <Typography variant='h6' className='yellow fw6'> &nbsp; Pending </Typography>
                                        </Box>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={12} xs={12}>
                                        <Box className="right">
                                            <Button variant='outlined' className='secondary-btn rbtn' size='small'>Raise Issue</Button>
                                        </Box>
                                    </Grid>


                                </Grid>
                            </Box>
                        </Box>



                    </Box>
                </Container>

            {/* </MainLayout> */}

        </>
    )
}

export default page