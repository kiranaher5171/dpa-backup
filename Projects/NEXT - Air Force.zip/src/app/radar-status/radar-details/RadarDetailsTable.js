"use client";
import React from 'react'
import { Box } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/TableSkeleton';
import AgGridInfo from '@/components/AgGridInfo';
import AgGridPagination from '@/components/AgGridPagination';
import Link from 'next/link';



const RadarDetailsTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const rowHeight = 25;
    const headerHeight = 30;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: true, flex: 1, suppressMovable: false, resizable: true
    }

    const rowStyle = { background: '#ffffff' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'rgb(249, 252, 255)' };
        }
    };

    const [rowData] = useState([
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
    ]);


    const columnDefs = [
        {
            headerName: 'Parameter Names', field: 'name', minWidth: 160, cellRenderer: () => <> Parameter 01  </>,
        },
        {
            headerName: 'Values', field: 'val', minWidth: 120, maxWidth: 120, cellRenderer: () => <> 200 </>, cellClass: 'right',
        },
    ];


    return (
        <>
            <Box className="">
                {loading ? (
                    <Box className="radar-status-details-table" style={{ width: '100%', height: '35vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz radar-status-details-table" style={{ width: '100%', height: '35vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                                getRowStyle={getRowStyle}
                                rowStyle={rowStyle}
                            />
                        </Box>
                    </>
                )}
            </Box>




        </>
    )
}

export default RadarDetailsTable