"use client"
import React from 'react'
import MainLayout from '../layouts/MainLayout'
import PageHeading from '@/components/PageHeading'
import { Box, Grid, Divider, Typography, TextField, Button, Stack, IconButton, Container } from '@mui/material'
import RadarStatusTable from './RadarStatusTable'
import Autocomplete from '@mui/material/Autocomplete';
import SimpleDatePicker from '@/components/SimpleDatePicker'
import CachedOutlinedIcon from '@mui/icons-material/CachedOutlined';
import CardHeading from '@/components/CardHeading'

const options = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
    { label: 'Option 5' },
]



const page = () => {

    return (

        <>
            {/* <MainLayout> */}
                <Box>
                    <PageHeading title={"Radar Status"} note={"As on 8th February 2024"} />
                </Box>

                <Container maxWidth>
                    <Box id="page-content">


                        <Box className="alicebx" mb={2}>
                            <Box>
                                <Grid container alignItems="center" justifyContent='flex-start' spacing={2}>
                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield'>
                                            <Typography variant='body' className='label'>Select Date</Typography>
                                            <SimpleDatePicker />
                                        </Box>
                                    </Grid>

                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Box className='textfield auto-complete'>
                                            <Typography variant='body' className='label'>Select Radar Unit</Typography>
                                            <Autocomplete
                                                disablePortal
                                                fullWidth
                                                id="combo-box-demo"
                                                options={options}
                                                renderInput={(params) => <TextField {...params} placeholder="Select Unit" variant='outlined' size='small' />}
                                            />
                                        </Box>
                                    </Grid>


                                    <Grid item lg={2} md={3} sm={4} xs={6}>
                                        <Stack direction={"row"} spacing={1} justifyContent={"flex-start"} alignItems={"center"}>
                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box>
                                                    <IconButton size='medium'>
                                                        <CachedOutlinedIcon fontSize='small' className='skyblue' />
                                                    </IconButton>
                                                </Box>
                                            </Box>

                                            <Box>
                                                <Typography variant='body' className='label'>&nbsp;</Typography>
                                                <Box className="left">
                                                    <Button variant='outlined' className='primary-btn' size='small'>Search</Button>
                                                </Box>
                                            </Box>
                                        </Stack>
                                    </Grid>



                                </Grid>
                            </Box>
                        </Box>


                        <Box className="whitebx">
                            {/* <Box className="fx_sb" mb={1}>
                                <Typography variant='h5' className='blue fw5'>Some Heading Here..</Typography>
                            </Box> */}
                            <CardHeading heading={"Some Heading Here..."} />

                            <Divider />

                            <Box mt={1}>
                                <RadarStatusTable />
                            </Box>
                        </Box>



                    </Box>
                </Container>

            {/* </MainLayout> */}

        </>
    )
}

export default page