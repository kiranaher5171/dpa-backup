"use client";
import React from 'react'
import { Box } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/TableSkeleton';
import AgGridInfo from '@/components/AgGridInfo';
import AgGridPagination from '@/components/AgGridPagination';
import Link from 'next/link';



const RadarStatusTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const rowHeight = 25;
    const headerHeight = 30;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: true, flex: 1, suppressMovable: false, resizable: true
    }

    const rowStyle = { background: '#ffffff' };

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'rgb(249, 252, 255)' };
        }
    };

    const [rowData] = useState([
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
        { result: "success" }, {}, { result: "failed" }, {}, { result: "success" },
    ]);


    const columnDefs = [
        {
            headerName: 'Radar Name', field: 'name', minWidth: 160, cellRenderer: () => <>
                <Link href="/radar-status/radar-details">Radar 01</Link>
            </>,
        },
        {
            headerName: 'Data Collection', field: 'dc', minWidth: 160, cellRenderer: () => <><span className='green'>Success</span></>,
        },
        {
            headerName: 'Pre-Processing', field: 'pre-pro', minWidth: 160,
            cellRenderer: (params) => {
                const { result } = params.data;
                return (
                    <>
                        {result === 'success' ? (
                            <>
                                <span className="green"> Success </span>
                            </>
                        ) : result === 'failed' ? (
                            <>
                                <span className="red"> Failed </span>
                            </>
                        ) : (
                            <>
                                <span className="yellow"> Pending </span>
                            </>
                        )
                        }
                    </>
                );
            },
        },
        {
            headerName: 'Prediction Result', field: 'pre-pro', minWidth: 160,
            cellRenderer: (params) => {
                const { result } = params.data;
                return (
                    <>
                        {result === 'success' ? (
                            <>
                                <span className="green"> No-Fault </span>
                            </>
                        ) : result === 'failed' ? (
                            <>
                                <span className="red"> Fault </span>
                            </>
                        ) : (
                            <>
                                <span className="yellow"> Pending </span>
                            </>
                        )
                        }
                    </>
                );
            },
        },
    ];


    return (
        <>
            <Box className="">
                {loading ? (
                    <Box className="radar-status-table" style={{ width: '100%', height: '35vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz radar-status-table" style={{ width: '100%', height: '35vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                                getRowStyle={getRowStyle}
                                rowStyle={rowStyle}
                            />
                        </Box>
                        <Box id="tb_footer" className="fx_sb" mt={1}>
                            <AgGridInfo />
                            <AgGridPagination />
                        </Box>
                    </>
                )}
            </Box>




        </>
    )
}

export default RadarStatusTable