"use client"
import * as React from 'react';
import Link from 'next/link';
import { Box, Button, Container, Grid, IconButton, InputAdornment, Typography } from '@mui/material'
import LOGO from "../../public/assets/logo.png";
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import Image from 'next/image';
import OutlinedInput from '@mui/material/OutlinedInput';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';

import style from "../css/forms.module.css"




const page = () => {

  const [values, setValues] = React.useState({
    password: '',
    showPassword: false,
  });

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };


  return (
    <>

      <Box id={style.formPage}>
        <Grid container alignItems='center' justifyContent="center">
          <Grid item lg={8} md={8} sm={6} xs={12}>
            <Box className={style.formbg}>
              <Container maxWidth="md">
                <Box className={style.formText}>
                  <Box>
                    <Typography variant='h4' className="white">
                      Welcome…
                    </Typography>
                  </Box>

                  <Box py={'4px'}>
                    <Typography variant='h1' className="white fw5">
                      INDIAN AIR FORCE
                    </Typography>
                  </Box>

                  <Typography variant='h4' className="white" gutterBottom>
                    Touch The Sky With Glory
                  </Typography>

                </Box>
              </Container>
            </Box>
          </Grid>
          <Grid item lg={4} md={4} sm={6} xs={12}>
            <Grid container alignItems='center' justifyContent="center">
              <Grid item lg={8} md={8} sm={10} xs={12}>
                <Box className={style.formbx}>
                  <Box pb={2} className="center">
                    <Image src={LOGO} className={style.formLogo} alt='Indian Air Force' priority />
                  </Box>

                  <Box className="center">
                    <Typography variant='h4' className="fw5 blue" gutterBottom>
                      Sign in
                    </Typography>
                  </Box>

                  <Box mt={3}>
                    <Grid container alignItems="top" justifyContent='center' spacing={3}>
                      <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='form-textfield'>
                          <OutlinedInput
                            id="username"
                            placeholder='Username'
                            fullWidth
                            startAdornment={<InputAdornment position="end">
                              <PersonOutlineOutlinedIcon />
                            </InputAdornment>}
                            inputProps={{
                              'aria-label': 'username',
                            }}
                          />

                        </Box>
                      </Grid>

                      <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className='form-textfield'>
                          <OutlinedInput
                            id="password"
                            placeholder='Password'
                            fullWidth
                            type={values.showPassword ? 'text' : 'password'}
                            value={values.password}
                            onChange={handleChange('password')}
                            startAdornment={<InputAdornment position="end">
                              <LockOutlinedIcon />
                            </InputAdornment>}
                            endAdornment={<InputAdornment position="end">
                              <IconButton
                                size="small"
                                aria-label="toggle password visibility"
                                onClick={handleClickShowPassword}
                                onMouseDown={handleMouseDownPassword}
                                edge="end"
                              >
                                {values.showPassword ? <VisibilityOutlinedIcon fontSize="small" className='gry' /> : <VisibilityOffOutlinedIcon fontSize="small" className='gry' />}
                              </IconButton>
                            </InputAdornment>}
                          />


                        </Box>
                      </Grid>



                      <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box pt={0}>
                          <Link href="/data-entry" passHref>
                            <Button variant='contained' className="form-btn" fullWidth>Sign in</Button>
                          </Link>
                        </Box>
                      </Grid>


                    </Grid>
                  </Box>
                </Box>
              </Grid>
            </Grid>



          </Grid>
        </Grid>
      </Box>

    </>
  )
}

export default page