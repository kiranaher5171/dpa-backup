"use client";
import React, { useState } from "react";
import {
  Grid,
  Box,
  Container,
  Tabs,
  Tab,
} from "@mui/material";
import '../tanent-management.css';
import AllUsersTable from "./AllUsersTable";
import AccessControlTable from "./AccessControlTable";
import ConfigurationRights from "./ConfigurationRights";

const MainTableTabs = () => {

  const [currentTab, setCurrentTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setCurrentTab(newValue);
  };

  const TabPanel = (props) => {
    const { children, value, index, ...other } = props;
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`tabpanel-${index}`}
        aria-labelledby={`tab-${index}`}
        {...other}
        style={{ display: value === index ? 'block' : 'none' }}
      >
        {value === index && <Box>{children}</Box>}
      </div>
    );
  };

  return (
    <>
      <Container maxWidth pb={2}>
        <Box className="table-box" mt={2}>
          <Box sx={{ bgcolor: "white", maxHeight: "80vh", overflowY: "auto", px: 1 }}>
            <Grid container spacing={2}>
              <Grid item lg={12} md={12} xs={12} sm={12}>
                <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
                  <Tabs
                    value={currentTab}
                    onChange={handleTabChange}
                    variant="scrollable"
                    scrollButtons="auto"
                    allowScrollButtonsMobile
                    className="form-tabs"
                  >
                    <Tab label="All Users" id="tab-0" aria-controls="tabpanel-0" />
                    <Tab label="Access Control" id="tab-1" aria-controls="tabpanel-1" />
                    <Tab label="Configuration Rights" id="tab-2" aria-controls="tabpanel-2" />
                  </Tabs>
                </Box>
              </Grid>
            </Grid>

            <TabPanel value={currentTab} index={0}>
              <AllUsersTable />
            </TabPanel>

            <TabPanel value={currentTab} index={1}>
              <AccessControlTable />
            </TabPanel>

            <TabPanel value={currentTab} index={2}>
              <ConfigurationRights />
            </TabPanel>
          </Box>
        </Box>
      </Container >
    </>
  );
};

export default MainTableTabs;
