"use client";
import MainLayout from '@/Layouts/MainLayout'
import React, { useState } from 'react'
import { Box, Button, Container, Grid, Stack, Typography, MenuItem, Breadcrumbs, Menu } from '@mui/material'
import Link from 'next/link';
import { LuMousePointerClick } from 'react-icons/lu';
import MainTableTabs from './MainTableTabs';
import { FiEye } from "react-icons/fi";

const ActionsMenu = () => {
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <Stack direction='row' spacing={1}>
            <Button variant='contained' className="primary-btn mobile-ico-btn" startIcon={<LuMousePointerClick />} onClick={handleClick}
                aria-controls={open ? 'action-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={open ? 'true' : undefined}
            > <span className="mobile-ico-btn-text">Actions</span></Button>

            <Button variant='contained' className="primary-btn mobile-ico-btn" startIcon={<FiEye />}> <span className="mobile-ico-btn-text">View Logs</span></Button>

            <Menu
                id="action-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                MenuListProps={{
                    'aria-labelledby': 'action-button',
                }}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                }}
            >
                <MenuItem>
                    Archive
                </MenuItem>
                <MenuItem>
                    Suspend
                </MenuItem>
                <MenuItem>
                    Reactivate
                </MenuItem>
                <MenuItem>
                    Reset Password
                </MenuItem>
                <MenuItem>
                    Change Tenant Plan
                </MenuItem>
                <MenuItem>
                    Activate/Extend Trial Period
                </MenuItem>
                <MenuItem>
                    Assign/Reset Tenant Compliance Flags
                </MenuItem>
                <MenuItem>
                    Upload Tenant Agreement
                </MenuItem>
            </Menu>
        </Stack>
    )
}

const page = () => {
    return (
        <>
            <MainLayout>

                <Container maxWidth sx={{ pt: 2 }}>
                    <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className="fx_sb w100" mb={1}>
                                <Box className="fx_fs gap1">
                                    <Box className="heading-decorator" />
                                    <Breadcrumbs aria-label="breadcrumb">
                                        <Link href="/tenant-management">
                                            <Typography variant="h5" className="primary fw6">
                                                Tenant Management
                                            </Typography>
                                        </Link>
                                        <Typography variant="h5" className="primary fw6">Tenant Management Details</Typography>
                                    </Breadcrumbs>
                                </Box>
                            </Box>


                            <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className="two-toned-box">
                                        <Box className="toned-content">

                                            <Grid container spacing={2}>
                                                <Grid item xs={12}>
                                                    <Box className="fx_sb w100" px={1}>
                                                        <Box>
                                                            <Typography variant="h5">Tenant Details</Typography>
                                                        </Box>
                                                        <Box>
                                                            <ActionsMenu />
                                                        </Box>
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12}>
                                                    <Box px={2}>
                                                        <Grid container spacing={2}>
                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Tenant Name:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>Google Tenant</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Tenant Type:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>Project Owner</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Plan:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>Professional Plan</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', height: '100%' }}>
                                                                    <Box>
                                                                        <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Status:</Typography>
                                                                        <Box  >
                                                                            <span style={{
                                                                                backgroundColor: "#d6ffd6",
                                                                                color: "green",
                                                                                borderRadius: "4px",
                                                                                fontSize: "11px",
                                                                                fontWeight: 500,
                                                                                minWidth: '100px',
                                                                                display: 'flex',
                                                                                height: '25px',
                                                                                alignItems: 'center',
                                                                                justifyContent: 'center',
                                                                            }}>Active</span>
                                                                        </Box>
                                                                    </Box>
                                                                </Box>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Number of Users:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>10</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Industry:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>New industry</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Compliance Flags:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>GDPR, FAR, Legal Hold</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Region:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>India, Andhra Pradesh</Typography>
                                                            </Grid>
                                                        </Grid>
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12}>
                                                    <Box px={1}>
                                                        <Typography variant="h5">Tenant Admin Details</Typography>
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12}>
                                                    <Box px={2} pb={2}>
                                                        <Grid container spacing={2}>
                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Admin Full Name:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>Google Admin, New Admin</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }} >Admin Email:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#2b6bbb', fontSize: '13px', fontWeight: 700 }}>
                                                                    <a href="mailto:googletent.admin@gmail.com" style={{ color: '#2b6bbb', textDecoration: 'none' }}>googletent.admin@gmail.com</a>,<br />
                                                                    <a href="mailto:newadmin@gmail.com" style={{ color: '#2b6bbb', textDecoration: 'none' }}>newadmin@gmail.com</a>
                                                                </Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Contact Number:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>+912345674563, +919748514263</Typography>
                                                            </Grid>

                                                            <Grid item lg={3} md={6} sm={12} xs={12}>
                                                                <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>Last Login:</Typography>
                                                                <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 700 }}>29 Jan 26 At 08:42AM, N/A</Typography>
                                                            </Grid>
                                                        </Grid>
                                                    </Box>
                                                </Grid>
                                            </Grid>

                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </Container>

                <Box my={3}>
                    <MainTableTabs />
                </Box>

            </MainLayout>
        </>
    )
}

export default page