"use client";
import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, TextField, Grid, Button, InputAdornment, Menu, MenuItem, ListItemIcon, IconButton, Tooltip, Typography } from "@mui/material";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import { FaSearch, FaFileCsv, FaFileExcel, FaFilePdf } from "react-icons/fa";
import { FiDownload, FiShield, FiEye } from "react-icons/fi";
import { LuUser } from "react-icons/lu";
import SearchIcon from "@mui/icons-material/Search";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import AgGridInfo from "@/components/table_components/AgGridInfo";

ModuleRegistry.registerModules([AllCommunityModule]);

const AllUsersTable = ({ onCreateTenant }) => {
  const router = useRouter();

  const [exportAnchorEl, setExportAnchorEl] = useState(null)
  const exportMenuOpen = Boolean(exportAnchorEl)
  const [selectedAction, setSelectedAction] = useState(null);
  const [filteredRowData, setFilteredRowData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditUser, setAuditUser] = useState(null);

  const auditLogs = [
    "User role updated from Contract Manager to Director At 2025-12-22 13:25:08",
    "Status updated from Awaiting Activation to Active At 2025-12-22 13:25:08",
    "Last login recorded At 2025-12-20 09:15:00",
    "Assigned role updated At 2025-12-18 11:30:22",
    "User profile updated At 2025-12-15 14:45:10",
  ];
  const filteredAuditLogs = auditLogs.filter((log) =>
    log.toLowerCase().includes(auditSearch.toLowerCase())
  );

  const [rowData] = useState([
    {
      name: 'Test Role',
      email: 'testrole@gmail.com',
      assignedRole: 'Auditor/Compliance, Contract Manager, Legal (Paralegal)',
      status: 'Suspend Pending',
      lastLogin: '',
    },
    {
      name: 'Test Access',
      email: 'testaccess@gmail.com',
      assignedRole: 'Auditor/Compliance, Director, Document Controller',
      status: 'Awaiting Activation',
      lastLogin: '',
    },
    {
      name: 'Abhi Ram',
      email: 'abhi.ram@gmail.com',
      assignedRole: 'Auditor/Compliance, Consultant, Contract Administrator, Contract Role, Document Controller',
      status: 'Awaiting Activation',
      lastLogin: '',
    },
    {
      name: 'Akhil Mitta',
      email: 'akhil.mittauser@gmail.com',
      assignedRole: 'Auditor/Compliance, Consultant, Contract Manager, Director',
      status: 'Awaiting Activation',
      lastLogin: '',
    },
    {
      name: 'Anji Medam',
      email: 'anji.user@gmail.com',
      assignedRole: 'Consultant',
      status: 'Awaiting Activation',
      lastLogin: '',
    },
    {
      name: 'Vrund Googleuser',
      email: 'vrund.googleuserrrrrrrrrrrrrrrrrrrrr@gmail.com',
      assignedRole: 'Auditor/Compliance, Consultant, Contract Administrator, Document Controller',
      status: 'Active',
      lastLogin: '09 Dec 25 At 07:29AM',
    },
    {
      name: 'Googleuser user',
      email: 'googleuser1@gmail.com',
      assignedRole: 'Auditor/Compliance, Contract Administrator, Contract Manager, Document Controller',
      status: 'Active',
      lastLogin: '09 Dec 25 At 07:29AM',
    },
  ]);

  const handleExportClick = (event) => {
    setExportAnchorEl(event.currentTarget)
  }

  const handleExportClose = () => {
    setExportAnchorEl(null)
  }

  const handleExport = (type) => {
    console.log(`Exporting as ${type}`)
    handleExportClose()
  }

  const [currentPage, setCurrentPage] = useState(1);
  const [colDefs] = useState([
    { field: "name", headerName: "Name", minWidth: 200 },
    {
      field: "email", headerName: "Email", minWidth: 240, cellRenderer: (params) => (
        <a href={`mailto:${params.value}`} style={{ color: '#2b6bbb', textDecoration: 'none' }}>{params.value}</a>
      )
    },
    {
      field: "assignedRole",
      headerName: "Assigned Role",
      minWidth: 550,
      cellRenderer: (params) => (
        <span style={{ whiteSpace: 'normal', lineHeight: 1.3 }}>{params.value}</span>
      ),
    },
    {
      headerName: "Status",
      field: "status",
      minWidth: 160,
      cellRenderer: (params) => {
        const roleColors = {
          "Active": { bg: "#d6ffd6", color: "green" },
          "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" },
          "Suspend Pending": { bg: "#ffecef", color: "red" },
        };
        const style = roleColors[params.value] || { bg: "#f5f5f5", color: "#616161" };
        return (
          <span
            style={{
              backgroundColor: style.bg,
              color: style.color,
              borderRadius: "4px",
              fontSize: "11px",
              fontWeight: 500,
              minWidth: '125px',
              display: 'flex',
              height: '25px',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {params.value}
          </span>
        );
      },
    },
    { field: "lastLogin", headerName: "Last Login", minWidth: 180 },
    {
      headerName: "Actions",
      field: "actions",
      minWidth: 120,
      headerClass: "table-header-center",
      sortable: false,
      cellRenderer: (params) => (
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
          <Tooltip title="View Audit Logs" arrow>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={() => {
                setAuditUser(params.data);
                setAuditDialogOpen(true);
              }}
              sx={{ color: "#2b6bbb" }}
            >
              <FiEye size={16} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Access Control" arrow>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={() => router.push("/admin/users/access-control-view")}
              sx={{ color: "#ff9800" }}
            >
              <FiShield size={16} />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (selectedAction) {
      const filtered = rowData.filter(row => row.actionStatus === selectedAction);
      setFilteredRowData(filtered);
    } else {
      setFilteredRowData(rowData);
    }
  }, [selectedAction, rowData]);

  const defaultColDef = {
    sortable: true,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "30vh", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
            <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="w100 tenantTableHead" mb={2}>
                  <Box className="fx_fe gap1">
                    <Box className="textfield-search">
                      <TextField
                        placeholder="Search"
                        size="small"
                        className="tenantTableHeadSearch"
                        InputProps={{
                          startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                        }}
                      />
                    </Box>

                    <Button
                      className="primary-outlined-btn mobile-ico-btn"
                      startIcon={<FiDownload />}
                      onClick={handleExportClick}
                      aria-controls={exportMenuOpen ? 'export-menu' : undefined}
                      aria-haspopup="true"
                      aria-expanded={exportMenuOpen ? 'true' : undefined}
                    >
                      <span className="mobile-ico-btn-text">Export</span>
                    </Button>
                    <Menu
                      id="export-menu"
                      anchorEl={exportAnchorEl}
                      open={exportMenuOpen}
                      onClose={handleExportClose}
                      MenuListProps={{
                        'aria-labelledby': 'export-button',
                      }}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'right',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                      }}
                    >
                      <MenuItem onClick={() => handleExport('csv')} sx={{ fontSize: '13px' }}>
                        <ListItemIcon><FaFileCsv style={{ color: '#4CAF50' }} /></ListItemIcon>
                        CSV
                      </MenuItem>
                      <MenuItem onClick={() => handleExport('excel')} sx={{ fontSize: '13px' }}>
                        <ListItemIcon><FaFileExcel style={{ color: '#217346' }} /></ListItemIcon>
                        Excel
                      </MenuItem>
                      <MenuItem onClick={() => handleExport('pdf')} sx={{ fontSize: '13px' }}>
                        <ListItemIcon><FaFilePdf style={{ color: '#E53935' }} /></ListItemIcon>
                        PDF
                      </MenuItem>
                    </Menu>
                  </Box>
                </Box>
              </Grid>

            </Grid>
          </Box>

          <Box style={{ width: "100%", height: "30vh" }}>
            <AgGridReact
              rowData={filteredRowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              rowSelection="multiple"
              suppressRowClickSelection={true}
              pagination={false}
            />
          </Box>
          <Box id="tb_footer" className="fx_sb" mt={1}>
            <AgGridInfo
              currentPage={currentPage}
              rowsPerPage={10}
              totalRows={rowData.length}
            />
            <AgGridPagination
              currentPage={currentPage}
              totalPages={Math.ceil(rowData.length / 10)}
              onPageChange={(_, page) => setCurrentPage(page)}
            />
          </Box>
        </>
      )}

      <CustomDialog
        open={auditDialogOpen}
        onClose={() => setAuditDialogOpen(false)}
        title="User Audit Logs"
        maxWidth="md"
      >
        <Box my={2}>
          <Grid container alignItems="center" justifyContent="flex-start" spacing={3}>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box className="fx_fs gap1">
                <LuUser style={{ fontSize: "20px", color: "var(--primary)" }} />
                <Box>
                  {auditUser && (
                    <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                      {auditUser.name}
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box>
                <SimpleTextField
                  placeholder="Search Logs"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  fullWidth
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <SearchIcon
                        style={{ fontSize: 18, margin: "0px 12px", marginRight: 0, color: "#757575" }}
                      />
                    ),
                  }}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>
        <Box sx={{ height: 250, overflow: "auto", overflowY: "auto", backgroundColor: "#f5f5f5", padding: "16px", borderRadius: "6px" }}>
          {filteredAuditLogs.map((log, idx) => (
            <Typography key={idx} variant="body2" sx={{ mb: 0.5, color: "text.secondary" }}>
              {log}
            </Typography>
          ))}
          {filteredAuditLogs.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              No logs match your search.
            </Typography>
          )}
        </Box>
      </CustomDialog>
    </>
  )
}

export default AllUsersTable;
