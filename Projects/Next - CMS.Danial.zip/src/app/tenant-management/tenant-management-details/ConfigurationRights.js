"use client";
import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, TextField, Grid, InputAdornment, Switch } from "@mui/material";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import { FaSearch } from "react-icons/fa";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";

ModuleRegistry.registerModules([AllCommunityModule]);

const PROJECT_OPTIONS = ["Project1", "Project2"];

const ConfigurationRights = ({ onCreateTenant }) => {
  const router = useRouter();

  const [selectedAction, setSelectedAction] = useState(null);
  const [filteredRowData, setFilteredRowData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState("Project1");

  const [rowData, setRowData] = useState([
    { config: 'Confidential Documents', enabled: true },
    { config: 'Dashboards', enabled: true },
    { config: 'Forms', enabled: true },
    { config: 'Libraries', enabled: true },
    { config: 'Naming Convention', enabled: true },
    { config: 'Projects', enabled: true },
    { config: 'Templates', enabled: true },
    { config: 'Workflow', enabled: true },
  ]);



  const toggleEnable = (rowIndex) => {
    setRowData(prev => prev.map((r, i) => i === rowIndex ? { ...r, enabled: !r.enabled } : r));
  };

  const [currentPage, setCurrentPage] = useState(1);
  const [colDefs] = useState([
    { field: "config", headerName: "Configuration Name", minWidth: 600 },
    {
      field: "enabled",
      headerName: "Enable Access",
      minWidth: 200,
      sortable: false,
      cellRenderer: (params) => (
        <Switch checked={!!params.data.enabled} onChange={() => toggleEnable(params.node.rowIndex)} />
      ),
    },
  ]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (selectedAction) {
      const filtered = rowData.filter(row => row.actionStatus === selectedAction);
      setFilteredRowData(filtered);
    } else {
      setFilteredRowData(rowData);
    }
  }, [selectedAction, rowData]);

  const defaultColDef = {
    sortable: true,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "30vh", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
            <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="w100 tenantTableHead" mb={2}>
                  <Box className="fx_fe gap1">
                    <Box className="textfield-search">
                      <TextField
                        placeholder="Search"
                        size="small"
                        className="tenantTableHeadSearch"
                        InputProps={{
                          startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                        }}
                      />
                    </Box>
                    <Box className="select-user-project">
                      <SingleSelectAutocomplete label="Select User" fullWidth required />
                    </Box>
                    <Box className="select-user-project">
                      <SingleSelectAutocomplete
                        label="Select Project"
                        placeholder="Select Project"
                        fullWidth 
                      />
                    </Box>
                  </Box>
                </Box>
              </Grid>

            </Grid>
          </Box>

          <Box style={{ width: "100%", height: "30vh" }}>
            <AgGridReact
              rowData={filteredRowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              rowSelection="multiple"
              suppressRowClickSelection={true}
              pagination={false}
            />
          </Box>
          <Box id="tb_footer" className="fx_sb" mt={1}>
            <AgGridInfo
              currentPage={currentPage}
              rowsPerPage={10}
              totalRows={rowData.length}
            />
            <AgGridPagination
              currentPage={currentPage}
              totalPages={Math.ceil(rowData.length / 10)}
              onPageChange={(_, page) => setCurrentPage(page)}
            />
          </Box>
        </>
      )}
    </>
  )
}

export default ConfigurationRights;
