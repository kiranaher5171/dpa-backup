"use client";
import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, Container, IconButton, TextField, Grid, Button, Stack, Typography, InputAdornment, Menu, MenuItem, ListItemIcon, Tooltip } from "@mui/material";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import { Search as SearchIcon, FilterList as FilterIcon } from '@mui/icons-material';
import { FaSearch, FaFileCsv, FaFileExcel, FaFilePdf } from "react-icons/fa";
import { GrPowerReset } from "react-icons/gr";
import { FiDownload, FiPlus, FiEye, FiEdit, FiShield } from "react-icons/fi";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import { LuMousePointerClick } from "react-icons/lu";
import { LiaIndustrySolid } from "react-icons/lia";

ModuleRegistry.registerModules([AllCommunityModule]);

const TenantManagementTable = ({ onCreateTenant }) => {
  const router = useRouter();

  const [exportAnchorEl, setExportAnchorEl] = useState(null);
  const exportMenuOpen = Boolean(exportAnchorEl);
  const [openConformation, setOpenConformation] = useState(false);
  const [actionAnchorEl, setActionAnchorEl] = useState(null);
  const actionMenuOpen = Boolean(actionAnchorEl);
  const [selectedAction, setSelectedAction] = useState(null);
  const [filteredRowData, setFilteredRowData] = useState([]);
  const [loading, setLoading] = useState(true);

  const [rowData] = useState([

    {
      tenantId: "481",
      tenantName: "Globe Tenant",
      tenantType: "Project Owner",
      plan: "Enterprise Plan",
      adminEmail: "globe.admin@gmail.com",
      adminName: "Globe Admin",
      status: "Reactivation",
      documents: "Globe_DSA.pdf, Globe_MSA.pdf",
      agreement: "Agreement A",
      acceptedBy: "Globe Admin",
      acceptedDate: "15 Dec 25 At 12:00PM",
      auditLogs: "-",
      result: "pending",
      actionStatus: "Reactivate",
    },
    {
      tenantId: "421",
      tenantName: "Platformdash",
      tenantType: "Project Owner",
      plan: "Basic Plan",
      adminEmail: "Platformdash@gmail.c...",
      adminName: "Platformdash Platform...",
      status: "Suspend",
      documents: "Platformdash_Terms.pdf",
      agreement: "Agreement B",
      acceptedBy: "Platformdash Admin",
      acceptedDate: "17 Dec 25 At 11:21AM",
      auditLogs: "-",
      result: "Suspended",
      actionStatus: "Suspend",
    },
    {
      tenantId: "341",
      tenantName: "Google Tenant",
      tenantType: "Project Owner",
      plan: "Professional Plan",
      adminEmail: "googletenant.admin@...",
      adminName: "Google Admin, New A...",
      status: "Active",
      documents: "Google_DSA.pdf, Google_Terms.pdf",
      agreement: "Agreement C",
      acceptedBy: "Google Admin",
      acceptedDate: "13 Jan 26 At 11:45AM",
      auditLogs: "23 Jan 26 At 08:05",
      result: "success",
      actionStatus: "Archive",
    },
    {
      tenantId: "321",
      tenantName: "Heritage Tenant",
      tenantType: "Project Owner",
      plan: "Professional Plan",
      adminEmail: "heri.admin@gmail.com...",
      adminName: "Heri Admin, Tenantad...",
      status: "Active",
      documents: "Heritage_Agreement.pdf",
      agreement: "Agreement D",
      acceptedBy: "Heri Admin",
      acceptedDate: "15 Oct 25 At 08:31AM",
      auditLogs: "14 Nov 25 At 10:0",
      result: "success",
      actionStatus: "Archive",
    },
    {
      tenantId: "282",
      tenantName: "DKF.JVBDFJKB",
      tenantType: "Prime Contractor",
      plan: "Enterprise Plan",
      adminEmail: "HSBCJHSB@JBC.CO...",
      adminName: "Sdhcb Jshcbjhb, Seco...",
      status: "Active",
      documents: "DKF_Agreement.pdf",
      agreement: "Agreement E",
      acceptedBy: "DKF Admin",
      acceptedDate: "01 Sep 25 At 09:00AM",
      auditLogs: "-",
      result: "success",
      actionStatus: "Archive",
    },
    {
      tenantId: "281",
      tenantName: "CopperChain",
      tenantType: "Prime Contractor",
      plan: "Enterprise Plan",
      adminEmail: "bhakir@gmail.com, var...",
      adminName: "Bhakir shane, Varun M...",
      status: "Expired",
      documents: "CopperChain_Terms.pdf",
      agreement: "Agreement F",
      acceptedBy: "Bhakir Shane",
      acceptedDate: "20 Aug 25 At 10:00AM",
      auditLogs: "-",
      result: "Suspended",
      actionStatus: "Reactivate",
    },
    {
      tenantId: "141",
      tenantName: "DPA Company",
      tenantType: "Project Owner",
      plan: "Professional Plan",
      adminEmail: "-",
      adminName: "-",
      status: "Active",
      documents: "DPA_Agreement.pdf",
      agreement: "Agreement G",
      acceptedBy: "DPA Admin",
      acceptedDate: "05 Jul 25 At 09:30AM",
      auditLogs: "-",
      result: "success",
      actionStatus: "Suspend",
    },
    {
      tenantId: "122",
      tenantName: "Big Data Limited",
      tenantType: "Sub Contractor",
      plan: "Basic Plan",
      adminEmail: "dave@gmail.com, roh...",
      adminName: "Dave Mathew, Ram Na...",
      status: "Active",
      documents: "BigData_MSA.pdf, BigData_DPA.pdf",
      agreement: "Agreement H",
      acceptedBy: "Ram Narayan",
      acceptedDate: "14 Oct 25 At 11:22AM",
      auditLogs: "29 Dec 25 At 09:4",
      result: "success",
      actionStatus: "Archive",
    },
    {
      tenantId: "5",
      tenantName: "Sunrise Credit Union",
      tenantType: "Project Owner",
      plan: "Basic Plan",
      adminEmail: "-",
      adminName: "-",
      status: "Active",
      documents: "Sunrise_Agreement.pdf",
      agreement: "Agreement I",
      acceptedBy: "Sunrise Admin",
      acceptedDate: "01 Jun 25 At 09:00AM",
      auditLogs: "-",
      result: "success",
      actionStatus: "Reset Password",
    },
    {
      tenantId: "2",
      tenantName: "BlueRock Bank",
      tenantType: "Prime Contractor",
      plan: "Basic Plan",
      adminEmail: "-",
      adminName: "-",
      status: "Archive",
      documents: "BlueRock_Terms.pdf",
      agreement: "Agreement J",
      acceptedBy: "BlueRock Admin",
      acceptedDate: "02 Feb 25 At 10:00AM",
      auditLogs: "-",
      result: "success",
      actionStatus: "Archive",
    },
  ]);

  const handleExportClick = (event) => {
    setExportAnchorEl(event.currentTarget)
  }

  const handleExportClose = () => {
    setExportAnchorEl(null)
  }

  const handleExport = (type) => {
    console.log(`Exporting as ${type}`)
    handleExportClose()
  }

  const handleEdit = (data) => {
    console.log("Edit tenant:", data);
  };

  const handleAccessControl = (data) => {
    console.log("Access control for:", data);
  };

  const handleActionClick = (event) => {
    setActionAnchorEl(event.currentTarget);
  };

  const handleActionClose = () => {
    setActionAnchorEl(null);
  };

  const handleResetActions = () => {
    setSelectedAction(null);
  };

  const handleCreateTenantClick = () => {
    router.push('/tenant-management/create-tenant');
  };
  const [currentPage, setCurrentPage] = useState(1);

  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditTenant, setAuditTenant] = useState(null);

  const [agreementDialogOpen, setAgreementDialogOpen] = useState(false);
  const [agreementTenant, setAgreementTenant] = useState(null);

  const agreementTableData = [
    {
      documents: "Agreement_DSA.pdf",
      acceptedBy: "Tenant Admin",
      acceptedDate: "15 Dec 25 At 12:00 PM",
    },
    {
      documents: "Agreement_MSA.pdf",
      acceptedBy: "Tenant Manager",
      acceptedDate: "16 Dec 25 At 03:30 PM",
    },
  ];

  const auditLogs = [
    "System Admin changed status from Active to Suspended at 2025-12-22 13:25:08",
    "Globe Admin updated plan from Basic to Enterprise at 2025-12-20 09:15:00",
    "Tenant created by system at 2025-11-01 08:00:00",
    "Globe Tenant accepted terms at 2025-12-15 12:00:00",
    "Platformdash suspended by admin at 2025-12-17 11:21:45",
  ];

  const filteredAuditLogs = auditLogs.filter((log) =>
    log.toLowerCase().includes(auditSearch.toLowerCase())
  );

  const [colDefs] = useState([
    {
      headerName: "",
      field: "checkbox",
      width: 50,
      pinned: "left",
      checkboxSelection: true,
      headerCheckboxSelection: true,
      sortable: false,
      filter: false,
      suppressMenu: true,
    },
    { field: "tenantId", headerName: "Tenant Id", minWidth: 90,maxWidth: 90, cellClass: "fx_fe" },
    {
      field: "tenantName",
      headerName: "Tenant Name",
      minWidth: 160,
      cellRenderer: (params) => (
        <a
          href="/tenant-management/tenant-management-details"
          style={{ color: '#1976d2', cursor: 'pointer' }}
        >
          {params.value}
        </a>
      ),
    },
    { field: "tenantType", headerName: "Tenant Type", minWidth: 150 },
    { field: "plan", headerName: "Plan", minWidth: 150 },
    {
      field: "adminName",
      headerName: "Admin Name",
      minWidth: 180,
    },
    {
      field: "adminEmail",
      headerName: "Admin Email",
      minWidth: 180,
    },
    {
      headerName: "Status",
      field: "status",
      headerClass: "table-header-center",
      minWidth: 160,
      cellRenderer: (params) => {
        const roleColors = {
          "Active": { bg: "#d6ffd6", color: "green" },
          "Archive": { bg: "#e3f2fd", color: "#1565c0" },
          "Reactivation": { bg: "#fcf3cc", color: "#D0B404" },
          "Expired": { bg: "#f5f5f5", color: "#616161" },
          "Suspend": { bg: "#ffecef", color: "red" },
        };
        const style = roleColors[params.value] || { bg: "#f5f5f5", color: "#616161" };
        return (
          <span
            style={{
              backgroundColor: style.bg,
              color: style.color,
              borderRadius: "4px",
              fontSize: "11px",
              fontWeight: 500,
              minWidth: '125px',
              display: 'flex',
              height: '25px',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {params.value}
          </span>
        );
      },
    },
    {
      field: "agreement",
      headerName: "Agreement",
      minWidth: 150,
      maxWidth: 150,
      sortable: false,
      cellRenderer: (params) => {
        const label = params.data.agreement || (params.data.documents && params.data.documents !== '-' ? params.data.documents : 'No Agreement');
        return (
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); setAgreementTenant(params.data); setAgreementDialogOpen(true); }}
            style={{ color: '#1976d2', cursor: 'pointer' }}
          >
            {label}
          </a>
        )
      }
    },
    {
      field: "actions",
      headerName: "Actions",
      minWidth: 120,
      maxWidth: 120,
      headerClass: "table-header-center",
      sortable: false,
      cellRenderer: (params) => (
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
          <Tooltip title="Edit" arrow>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={() => handleEdit(params.data)}
              sx={{ color: "#2b6bbb" }}
            >
              <FiEdit size={16} />
            </IconButton>
          </Tooltip>
          <Tooltip title="View Audit Logs" arrow>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={() => {
                setAuditTenant(params.data);
                setAuditDialogOpen(true);
              }}
              sx={{ color: "#2b6bbb" }}
            >
              <FiEye size={16} />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (selectedAction) {
      const filtered = rowData.filter(row => row.actionStatus === selectedAction);
      setFilteredRowData(filtered);
    } else {
      setFilteredRowData(rowData);
    }
  }, [selectedAction, rowData]);

  const defaultColDef = {
    sortable: true,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "30vh", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', px: 2, py: 1 }}>

            <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
              <Grid item lg={12} md={12} sm={12} xs={12}>
                <Box className="w100 tenantTableHead" mb={1}>
                  <Box className="fx_fe gap1">
                    <Box className="textfield-search">
                      <TextField
                        placeholder="Search"
                        size="small"
                        className="tenantTableHeadSearch"
                        InputProps={{
                          startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                        }}
                      />
                    </Box>

                    <Button variant='contained' className="primary-btn mobile-ico-btn" startIcon={<LuMousePointerClick />} onClick={handleActionClick}
                      aria-controls={actionMenuOpen ? 'action-menu' : undefined}
                      aria-haspopup="true"
                      aria-expanded={actionMenuOpen ? 'true' : undefined}
                    > <span className="mobile-ico-btn-text">Actions</span></Button>
                    <Menu
                      id="action-menu"
                      anchorEl={actionAnchorEl}
                      open={actionMenuOpen}
                      onClose={handleActionClose}
                      MenuListProps={{
                        'aria-labelledby': 'action-button',
                      }}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'left',
                      }}
                    >
                      <MenuItem>
                        Archive
                      </MenuItem>
                      <MenuItem>
                        Suspend
                      </MenuItem>
                      <MenuItem>
                        Reactivate
                      </MenuItem>
                      <MenuItem>
                        Reset Password
                      </MenuItem>
                      <MenuItem>
                        Change Tenant Plan
                      </MenuItem>
                      <MenuItem>
                        Activate/Extend Trial Period
                      </MenuItem>
                      <MenuItem>
                        Assign/Reset Tenant Compliance Flags
                      </MenuItem>
                      <MenuItem>
                        Upload Tenant Agreement
                      </MenuItem>
                    </Menu>
                    <Button variant='contained' className="primary-btn mobile-ico-btn" startIcon={<FiPlus />} onClick={handleCreateTenantClick}><span className="mobile-ico-btn-text">Create Tenant</span></Button>

                    <Button
                      className="primary-outlined-btn mobile-ico-btn"
                      startIcon={<GrPowerReset />}
                      onClick={handleResetActions}
                    >
                      <span className="mobile-ico-btn-text">Reset</span>
                    </Button>

                    <Button
                      className="primary-outlined-btn mobile-ico-btn"
                      startIcon={<FiDownload />}
                      onClick={handleExportClick}
                      aria-controls={exportMenuOpen ? 'export-menu' : undefined}
                      aria-haspopup="true"
                      aria-expanded={exportMenuOpen ? 'true' : undefined}
                    >
                      <span className="mobile-ico-btn-text">Export</span>
                    </Button>
                    <Menu
                      id="export-menu"
                      anchorEl={exportAnchorEl}
                      open={exportMenuOpen}
                      onClose={handleExportClose}
                      MenuListProps={{
                        'aria-labelledby': 'export-button',
                      }}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'right',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                      }}
                    >
                      <MenuItem onClick={() => handleExport('csv')} sx={{ fontSize: '13px' }}>
                        <ListItemIcon><FaFileCsv style={{ color: '#4CAF50' }} /></ListItemIcon>
                        CSV
                      </MenuItem>
                      <MenuItem onClick={() => handleExport('excel')} sx={{ fontSize: '13px' }}>
                        <ListItemIcon><FaFileExcel style={{ color: '#217346' }} /></ListItemIcon>
                        Excel
                      </MenuItem>
                      <MenuItem onClick={() => handleExport('pdf')} sx={{ fontSize: '13px' }}>
                        <ListItemIcon><FaFilePdf style={{ color: '#E53935' }} /></ListItemIcon>
                        PDF
                      </MenuItem>
                    </Menu>
                  </Box>
                </Box>
              </Grid>

            </Grid>
          </Box>

          <Box style={{ width: "100%", height: "60vh" }}>
            <AgGridReact
              rowData={filteredRowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              rowSelection="multiple"
              suppressRowClickSelection={true}
              pagination={false}
            />
          </Box>

          <CustomDialog
            open={auditDialogOpen}
            onClose={() => setAuditDialogOpen(false)}
            title="Tenant Audit Logs"
            maxWidth="md"
          >

            <Box my={2}>
              <Grid container alignItems="center" justifyContent='flex-start' spacing={3}>
                <Grid item lg={6} md={6} sm={12} xs={12}>
                  <Box className="fx_fs gap1">

                    <LiaIndustrySolid style={{ fontSize: '20px', color: 'var(--primary)' }} />

                    <Box>
                      {auditTenant && (
                        <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                          {auditTenant.tenantName}
                        </Typography>
                      )}
                    </Box>
                  </Box>
                </Grid>
                <Grid item lg={6} md={6} sm={12} xs={12}>
                  <Box>
                    <SimpleTextField
                      placeholder="Search Logs"
                      value={auditSearch}
                      onChange={(e) => setAuditSearch(e.target.value)}
                      fullWidth
                      size="small"
                      InputProps={{
                        startAdornment: (
                          <SearchIcon
                            style={{ fontSize: 18, margin: '0px 12px', marginRight: 0, color: "#757575" }}
                          />
                        ),
                      }}
                    />
                  </Box>
                </Grid>
              </Grid>
            </Box>


            <Box sx={{ height: 250, overflow: "auto", overflowY: "auto", backgroundColor: "#f5f5f5", padding: "16px", borderRadius: "6px" }}>
              {filteredAuditLogs.map((log, idx) => (
                <Typography
                  key={idx}
                  variant="body2"
                  sx={{ mb: 0.5, color: "text.secondary" }}
                >
                  {log}
                </Typography>
              ))}
              {filteredAuditLogs.length === 0 && (
                <Typography variant="body2" color="text.secondary">
                  No logs match your search.
                </Typography>
              )}
            </Box>
          </CustomDialog>

          <CustomDialog
            open={agreementDialogOpen}
            onClose={() => setAgreementDialogOpen(false)}
            title="Agreement Details"
            maxWidth="md"
          >
            <Box my={2}>
              <Grid container alignItems="center" justifyContent='flex-start' spacing={3}>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                  <Box className="fx_fs gap1">
                    <LiaIndustrySolid style={{ fontSize: '20px', color: 'var(--primary)' }} />
                    <Box>
                      {agreementTenant && (
                        <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                          {agreementTenant.tenantName}
                        </Typography>
                      )}
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>

            <Box style={{ width: "100%", height: "15vh" }}>
              <AgGridReact
                rowData={agreementTableData}
                columnDefs={[
                  { field: "documents", headerName: "Documents", minWidth: 200 },
                  { field: "acceptedBy", headerName: "Accepted By", minWidth: 150 },
                  { field: "acceptedDate", headerName: "Accepted Date", minWidth: 200 },
                ]}
                defaultColDef={{
                  sortable: true,
                  filter: false,
                  autoHeight: true,
                  resizable: false,
                  suppressMovable: true,
                  flex: 1,
                }}
                getRowStyle={(params) => ({
                  backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
                })}
                headerHeight={40}
                rowHeight={40}
                pagination={false}
              />
            </Box>
          </CustomDialog>

          <Box id="tb_footer" className="fx_sb" mt={1}>
            <AgGridInfo
              currentPage={currentPage}
              rowsPerPage={10}
              totalRows={rowData.length}
            />
            <AgGridPagination
              currentPage={currentPage}
              totalPages={Math.ceil(rowData.length / 10)}
              onPageChange={(_, page) => setCurrentPage(page)}
            />
          </Box>
        </>
      )}
    </>
  )
}

export default TenantManagementTable;
