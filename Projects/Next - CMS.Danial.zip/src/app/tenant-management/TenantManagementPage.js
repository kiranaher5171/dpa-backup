"use client";
import React, { useState } from 'react'
import { Box, Container, Grid, Typography } from '@mui/material'
import WhiteCard from '@/components/whiteCards';
import TenantManagementTable from './TenantManagementTable';
import CreateTenantForm from './create-tenant/CreateTenantForm';

const STAT_CARDS = [
  { value: "10", label: "Total Tenants" },
  { value: "7", label: "Active" },
  { value: "0", label: "Suspended" },
  { value: "0", label: "Archived" },
  { value: "1", label: "Trial Expired" },
];

export default function TenantManagementPage() {
    const [openCreateTenant, setOpenCreateTenant] = useState(false);

    const handleCreateTenantOpen = () => {
        setOpenCreateTenant(true);
    };

    const handleCreateTenantClose = () => {
        setOpenCreateTenant(false);
    };

    if (openCreateTenant) {
        return <CreateTenantForm onBack={handleCreateTenantClose} />;
    }

    return (
        <Container maxWidth sx={{ py: 2 }}>
            <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box className="fx_sb w100" mb={1}>
                        <Box className="fx_fs gap1">
                            <Box className="heading-decorator" />
                            <Typography variant='h5' className="primary fw6">Tenant Management</Typography>
                        </Box>
                    </Box>
                </Grid>
            </Grid>

            <Grid container spacing={2} alignItems="stretch" justifyContent="flex-start">
                {STAT_CARDS.map((card, index) => (
                    <Grid item xs={12} sm={6} md={4} lg={2.4} key={index}>
                        <WhiteCard value={card.value} label={card.label} />
                    </Grid>
                ))}
            </Grid>

            <Box className="table-box" my={2}>
                <TenantManagementTable onCreateTenant={handleCreateTenantOpen} />
            </Box>
        </Container>
    )
}
