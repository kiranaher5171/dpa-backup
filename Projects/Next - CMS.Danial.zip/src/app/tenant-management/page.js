"use client";
import MainLayout from '@/Layouts/MainLayout'
import React from 'react'
import './tanent-management.css';
import TenantManagementPage from './TenantManagementPage';

export default function page() {
    return (
        <>
            <MainLayout>
                <TenantManagementPage />
            </MainLayout>
        </>
    )
}
