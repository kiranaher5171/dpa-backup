"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import {
    Button,
    Grid,
    Box,
    Typography,
    FormControlLabel,
    Switch,
    Paper,
    Container,
    Checkbox,
    Popover,
    Breadcrumbs,
    Tabs,
    Tab,
} from "@mui/material";
import { FiUploadCloud } from "react-icons/fi";
import { MdClose } from "react-icons/md";
import Link from "next/link";
import { FiPlus } from "react-icons/fi";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import ContactNumberInput from "@/components/FormInputComponents/ContactNumberInput";
import MultiSelectAutocomplete from "@/components/FormInputComponents/MultiSelectAutocomplete";
import SimpleTextFieldMultiline from "@/components/FormInputComponents/SimpleTextFieldMultiline";
import DatePicker from "@/components/FormInputComponents/DatePicker";
import CustomDialog from "@/components/CustomDialog";
import '../tanent-management.css';

const COMPLIANCE_FLAGS_LIST = [
    "Legal Hold",
    "GDPR",
    "FAR",
    "DEFAULT_FLAG",
    "DEFAULT_FLAG",
    "DEFAULT_FLAG",
    "DEFAULT_FLAG",
    "DEFAULT_FLAG",
    "DEFAULT_FLAG",
    "DEFAULT_FLAG",
    "DEFAULT_FLAG",
];

const CreateTenantForm = () => {
    const router = useRouter();
    const [formData, setFormData] = useState({
        companyName: "",
        companyWebsite: "",
        companySize: "",
        companyLogo: null,
        country: "",
        state: "",
        primaryContactName: "",
        primaryContactEmail: "",
        primaryContactPhone: "",
        tenantName: "",
        tenantType: "",
        taxId: "",
        complianceFlags: [],
        couponCode: "",
        referralTag: "",
        billingState: "",
        city: "",
        address: "",
        billingCycle: "",
        planSelection: "",
        adminFirstName: "",
        adminLastName: "",
        adminEmail: "",
        adminContactNumber: "",
        enableTrialPeriod: false,
        trialDuration: "",
        trialStartDate: null,
        trialEndDate: null,
    });

    const [uploadedFiles, setUploadedFiles] = useState({
        companyLogo: null,
        tddFile: null,
        dpaFile: null,
        msaFile: null,
    });

    const [currentTab, setCurrentTab] = useState(0);
    const [adminUsers, setAdminUsers] = useState([
        {
            adminFirstName: "",
            adminLastName: "",
            adminEmail: "",
            adminContactNumber: "",
        }
    ]);
    const [policies, setPolicies] = useState([
        {
            id: 1,
            name: "TDD (Terms of Use)",
            file: null,
            description: "",
            fileKey: "tddFile",
        },
        {
            id: 2,
            name: "DPA (Data Processing Agreement)",
            file: null,
            description: "",
            fileKey: "dpaFile",
        },
        {
            id: 3,
            name: "SubscriptionMSA",
            file: null,
            description: "",
            fileKey: "msaFile",
        }
    ]);

    const [complianceFlagsAnchorEl, setComplianceFlagsAnchorEl] = useState(null);
    const [openAddComplianceDialog, setOpenAddComplianceDialog] = useState(false);
    const [newComplianceFlag, setNewComplianceFlag] = useState({
        name: "",
        description: "",
    });

    const logoInputRef = React.useRef(null);

    const handleSwitchChange = (e) => {
        const { name, checked } = e.target;
        setFormData((prev) => {
            const next = { ...prev, [name]: checked };
            if (name === "enableTrialPeriod" && !checked) {
                next.trialDuration = "";
                next.trialStartDate = null;
                next.trialEndDate = null;
            }
            return next;
        });
    };

    const handleLogoClick = () => {
        logoInputRef.current?.click();
    };

    const handleFileChange = (e, fileType) => {
        const file = e.target.files?.[0];
        if (file) {
            setUploadedFiles((prev) => ({
                ...prev,
                [fileType]: file,
            }));
        }
    };

    const handleComplianceFlagsClose = () => {
        setComplianceFlagsAnchorEl(null);
    };

    const handleComplianceFlagToggle = (flag) => {
        setFormData((prev) => {
            const currentFlags = prev.complianceFlags || [];
            const isSelected = currentFlags.includes(flag);
            return {
                ...prev,
                complianceFlags: isSelected
                    ? currentFlags.filter((f) => f !== flag)
                    : [...currentFlags, flag],
            };
        });
    };

    const handleAddAdminUser = () => {
        setAdminUsers((prev) => [
            ...prev,
            {
                adminFirstName: "",
                adminLastName: "",
                adminEmail: "",
                adminContactNumber: "",
            }
        ]);
    };

    const handleRemoveAdminUser = (index) => {
        setAdminUsers((prev) => prev.filter((_, i) => i !== index));
    };

    const handleOpenAddComplianceDialog = () => {
        setComplianceFlagsAnchorEl(null);
        setOpenAddComplianceDialog(true);
    };

    const handleCloseAddComplianceDialog = () => {
        setOpenAddComplianceDialog(false);
        setNewComplianceFlag({ name: "", description: "" });
    };


    const handleAddNewComplianceFlag = () => {
        if (newComplianceFlag.name.trim()) {
            const flagName = newComplianceFlag.name.trim();
            setFormData((prev) => ({
                ...prev,
                complianceFlags: [...(prev.complianceFlags || []), flagName],
            }));
            handleCloseAddComplianceDialog();
        }
    };

    const handleTabChange = (event, newValue) => {
        setCurrentTab(newValue);
    };

    const TabPanel = (props) => {
        const { children, value, index, ...other } = props;
        return (
            <div
                role="tabpanel"
                hidden={value !== index}
                id={`tabpanel-${index}`}
                aria-labelledby={`tab-${index}`}
                {...other}
                style={{ display: value === index ? 'block' : 'none' }}
            >
                {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
            </div>
        );
    };

    const addPolicy = () => {
        setPolicies(prev => [
            ...prev,
            {
                id: Date.now(),
                name: "",
                fileKey: `policy_${prev.length}`,
                description: ""
            }
        ]);
    };

    const removePolicy = (id) => {
        if (id <= 3) return;
        setPolicies(prev => prev.filter(p => p.id !== id));
    };

    const handleSubmit = () => {
        console.log("Form Data:", formData);
        router.push('/tenant-management');
    };
    const [contactNumber, setContactNumber] = useState("");
    return (
        <>
            <Container maxWidth>
                <Box className="table-box" mt={2}>
                    <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className="fx_sb w100" m={2}>
                                <Box className="fx_fs gap1">
                                    <Box className="heading-decorator" />
                                    <Breadcrumbs aria-label="breadcrumb">
                                        <Link href="/tenant-management">
                                            <Typography variant="h5" className="primary fw6">
                                                Tenant Management
                                            </Typography>
                                        </Link>
                                        <Typography variant="h5" className="primary fw6">Create Tenant</Typography>
                                    </Breadcrumbs>
                                </Box>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>
            </Container>

            <Container maxWidth pb={2}>
                <Box className="table-box" mt={2}>
                    <Box sx={{ p: 3, bgcolor: "white", maxHeight: "80vh", overflowY: "auto" }}>
                        <Box sx={{ mb: 3, pb: 2, borderBottom: "1px solid #e0e0e0" }}>
                            <Box className="fx_fs gap1">
                                <Typography variant='h5' className="primary fw6">Create Tenant</Typography>
                            </Box>
                        </Box>

                        <Grid container spacing={2}>
                            <Grid item lg={12} md={12} xs={12} sm={12}>
                                <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
                                    <Tabs
                                        value={currentTab}
                                        onChange={handleTabChange}
                                        variant="scrollable"
                                        scrollButtons="auto"
                                        allowScrollButtonsMobile
                                        className="form-tabs"
                                    >
                                        <Tab label="Company Details" id="tab-0" aria-controls="tabpanel-0" />
                                        <Tab label="Tenant Details" id="tab-1" aria-controls="tabpanel-1" />
                                        <Tab label="Tenant Admin Details" id="tab-2" aria-controls="tabpanel-2" />
                                        <Tab label="Agreements & Policies" id="tab-3" aria-controls="tabpanel-3" />
                                    </Tabs>
                                </Box>
                            </Grid>
                        </Grid>

                        <TabPanel value={currentTab} index={0}>
                            <Grid container spacing={2}>
                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Company Name" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Company Website" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="Company Size" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box
                                        onClick={handleLogoClick}
                                        sx={{
                                            border: "1px dashed #ccc",
                                            borderRadius: "4px",
                                            p: 2,
                                            textAlign: "center",
                                            cursor: "pointer",
                                            "&:hover": { backgroundColor: "#f5f5f5" },
                                        }}
                                    >
                                        <FiUploadCloud size={24} style={{ margin: "0 auto" }} />
                                        <Typography sx={{ fontSize: "12px", mt: 1 }}>
                                            {uploadedFiles.companyLogo ? uploadedFiles.companyLogo.name : "Company Logo"}
                                        </Typography>
                                    </Box>
                                    <input
                                        ref={logoInputRef}
                                        type="file"
                                        hidden
                                        onChange={(e) => handleFileChange(e, "companyLogo")}
                                        accept="image/*"
                                    />
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="Country" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="State" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="City" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Company Address" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Zip Code" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Close Of Business" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Primary Contact Name" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Job Title / Role" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Email Address" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <ContactNumberInput
                                            fullWidth
                                            required
                                            defaultCountry="US"
                                            value={contactNumber}
                                            onChange={setContactNumber}
                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </TabPanel>

                        <TabPanel value={currentTab} index={1}>
                            <Grid container spacing={2}>
                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Tenant Name" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="Tenant Type" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Tax ID" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <Grid container spacing={2} justifyContent="space-between" alignItems="center">
                                            <Grid item lg={8} md={12} xs={12} sm={12}>
                                                <Box>
                                                    <MultiSelectAutocomplete label="Compliance Flags" fullWidth required />
                                                </Box>
                                            </Grid>
                                            <Grid item lg={4} md={12} xs={12} sm={12}>
                                                <Box>
                                                    <Button
                                                        variant="contained"
                                                        fullWidth
                                                        className="btn-filled-primary"
                                                        onClick={handleOpenAddComplianceDialog}
                                                        startIcon={<FiPlus />}
                                                    >
                                                        Add Compliance Flag
                                                    </Button>
                                                </Box>
                                            </Grid>

                                        </Grid>

                                    </Box>
                                    <Popover
                                        open={Boolean(complianceFlagsAnchorEl)}
                                        anchorEl={complianceFlagsAnchorEl}
                                        onClose={handleComplianceFlagsClose}
                                        anchorOrigin={{
                                            vertical: "bottom",
                                            horizontal: "left",
                                        }}
                                    >
                                        <Paper sx={{ p: 2, maxWidth: "400px", maxHeight: "400px", overflowY: "auto" }}>
                                            {COMPLIANCE_FLAGS_LIST.map((flag) => (
                                                <FormControlLabel
                                                    key={flag}
                                                    control={
                                                        <Checkbox
                                                            checked={(formData.complianceFlags || []).includes(flag)}
                                                            onChange={() => handleComplianceFlagToggle(flag)}
                                                        />
                                                    }
                                                    label={flag}
                                                    sx={{ display: "block", mb: 1 }}
                                                />
                                            ))}
                                        </Paper>
                                    </Popover>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Coupon Code" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Referral Tag" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item lg={12} md={12} xs={12} sm={6}>
                                    <FormControlLabel
                                        control={
                                            <Switch
                                                name="sameAsCompanyLocation"
                                                checked={formData.sameAsCompanyLocation || false}
                                                onChange={handleSwitchChange}
                                            />
                                        }
                                        label="Same as Company Location?"
                                    />
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="Country" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="State" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="City" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SimpleTextField label="Address" fullWidth required />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="Billing Cycle" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="Plan Selection" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <Box>
                                        <SingleSelectAutocomplete label="Industry" fullWidth required options={[]} />
                                    </Box>
                                </Grid>

                                <Grid item xs={12} sm={6}>
                                    <FormControlLabel
                                        control={
                                            <Switch
                                                name="enableTrialPeriod"
                                                checked={formData.enableTrialPeriod || false}
                                                onChange={handleSwitchChange}
                                            />
                                        }
                                        label="Enable Trial Period"
                                    />
                                </Grid>

                                {formData.enableTrialPeriod && (
                                    <>
                                        <Grid item xs={12} sm={6}>
                                            <Box>
                                                <SingleSelectAutocomplete
                                                    label="Trial Duration"
                                                    fullWidth
                                                    required
                                                    options={[]}
                                                    value={formData.trialDuration}
                                                    onChange={(val) => setFormData(prev => ({ ...prev, trialDuration: val }))}
                                                />
                                            </Box>
                                        </Grid>

                                        <Grid item xs={12} sm={6}>
                                            <Box>
                                                <Grid container spacing={2}>
                                                    <Grid item lg={6} md={6} xs={12} sm={6}>
                                                        <Box>
                                                            <DatePicker
                                                                required
                                                                label="Trial Start Date"
                                                                value={formData.trialStartDate || null}
                                                                onChange={(newVal) => setFormData(prev => ({ ...prev, trialStartDate: newVal }))}
                                                            />
                                                        </Box>
                                                    </Grid>
                                                    <Grid item lg={6} md={6} xs={12} sm={6}>
                                                        <Box>
                                                            <DatePicker
                                                                required
                                                                label="Trial End Date"
                                                                value={formData.trialEndDate || null}
                                                                onChange={(newVal) => setFormData(prev => ({ ...prev, trialEndDate: newVal }))}
                                                            />
                                                        </Box>
                                                    </Grid>
                                                </Grid>
                                            </Box>
                                        </Grid>
                                    </>
                                )}

                            </Grid>
                        </TabPanel>

                        <TabPanel value={currentTab} index={2}>
                            <Grid container spacing={3}>
                                {adminUsers.map((admin, index) => (
                                    <Grid item xs={12} key={index}>
                                        <Box sx={{
                                            border: "1px solid #e0e0e0",
                                            borderRadius: "4px",
                                            p: 2.5,
                                            backgroundColor: "#fafafa"
                                        }}>
                                            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                                                <Typography sx={{ fontSize: "14px", fontWeight: "600" }}>
                                                    Admin User {index + 1}
                                                </Typography>
                                                {adminUsers.length > 1 && (
                                                    <Button
                                                        variant="outlined"
                                                        color="error"
                                                        size="small"
                                                        onClick={() => handleRemoveAdminUser(index)}
                                                    >
                                                        Remove
                                                    </Button>
                                                )}
                                            </Box>
                                            <Grid container spacing={2}>
                                                <Grid item xs={12} sm={6}>
                                                    <Box>
                                                        <SimpleTextField label="First Name" fullWidth required />
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12} sm={6}>
                                                    <Box>
                                                        <SimpleTextField label="Last Name" fullWidth required />
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12} sm={6}>
                                                    <Box>
                                                        <SimpleTextField label="Email" fullWidth required />
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12} sm={6}>
                                                    <Box>
                                                        <ContactNumberInput
                                                            fullWidth
                                                            required
                                                            defaultCountry="US"
                                                            value={contactNumber}
                                                            onChange={setContactNumber}
                                                        />
                                                    </Box>
                                                </Grid>
                                            </Grid>
                                        </Box>
                                    </Grid>
                                ))}

                                <Grid item xs={12} className="right">
                                    <Button
                                        variant="contained"
                                        className="btn-filled-primary"
                                        onClick={handleAddAdminUser}
                                        startIcon={<FiPlus />}
                                    >
                                        Add New Admin
                                    </Button>
                                </Grid>

                            </Grid>
                        </TabPanel>

                        <TabPanel value={currentTab} index={3}>
                            <Grid container spacing={2}>

                                {policies.map((policy, index) => (
                                    <Grid item xs={12} key={policy.id}>
                                        <Paper sx={{ p: 2, backgroundColor: "#f9f9f9", position: "relative" }}>
                                            {index >= 3 && (
                                                <Button
                                                    size="small"
                                                    color="error"
                                                    onClick={() => removePolicy(policy.id)}
                                                    sx={{ position: "absolute", top: 8, right: 8 }}
                                                >
                                                    Remove
                                                </Button>
                                            )}

                                            <Grid container spacing={2}>
                                                <Grid item xs={12} sm={6}>
                                                    <Typography sx={{ fontSize: "12px", fontWeight: 600, mb: 1 }}>
                                                        Agreements & Policies
                                                    </Typography>
                                                    <Box>
                                                        <SimpleTextField label="Enter policy name" fullWidth required />
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12} sm={6}>
                                                    <Typography sx={{ fontSize: "12px", fontWeight: 600, mb: 1 }}>
                                                        Upload File
                                                    </Typography>

                                                    <Box
                                                        onClick={handleLogoClick}
                                                        sx={{
                                                            border: "1px dashed #ccc",
                                                            borderRadius: "4px",
                                                            p: 1.5,
                                                            textAlign: "center",
                                                            cursor: "pointer",
                                                            "&:hover": { backgroundColor: "#f5f5f5" },
                                                        }}
                                                    >
                                                        <FiUploadCloud size={24} style={{ margin: "0 auto" }} />
                                                        <Typography sx={{ fontSize: "12px", mt: 1 }}>
                                                            {uploadedFiles.companyLogo ? uploadedFiles.companyLogo.name : "Company Logo"}
                                                        </Typography>
                                                    </Box>
                                                    <input
                                                        ref={logoInputRef}
                                                        type="file"
                                                        hidden
                                                        onChange={(e) => handleFileChange(e, "companyLogo")}
                                                        accept="image/*"
                                                    />
                                                </Grid>

                                                <Grid item xs={12}>
                                                    <Typography sx={{ fontSize: "12px", fontWeight: 600, mb: 1 }}>
                                                        Short Description
                                                    </Typography>
                                                    <Box>
                                                        <SimpleTextFieldMultiline label="Enter description" fullWidth required />
                                                    </Box>
                                                </Grid>
                                            </Grid>
                                        </Paper>
                                    </Grid>
                                ))}

                                <Grid item xs={12} className="right">
                                    <Button
                                        variant="contained"
                                        onClick={addPolicy}
                                        className="btn-filled-primary"
                                        startIcon={<FiPlus />}
                                    >
                                        Add New Policy
                                    </Button>
                                </Grid>

                            </Grid>
                        </TabPanel>

                        <Box sx={{ display: "flex", gap: 2, justifyContent: "flex-end", mt: 4, pt: 2, borderTop: "1px solid #e0e0e0" }}>
                            <Button
                                onClick={() => router.push('/tenant-management')}
                                variant="outlined"
                                sx={{
                                    color: "#666",
                                    borderColor: "#ddd",
                                    "&:hover": { borderColor: "#999" },
                                }}
                            >
                                Cancel
                            </Button>
                            {currentTab < 3 && (
                                <Button
                                    className="btn-filled-primary"
                                    onClick={() => setCurrentTab(currentTab + 1)}
                                    variant="contained"
                                >
                                    Next
                                </Button>
                            )}
                            {currentTab > 0 && (
                                <Button
                                    onClick={() => setCurrentTab(currentTab - 1)}
                                    variant="outlined"
                                    sx={{ color: "#666", borderColor: "#ddd" }}
                                >
                                    Previous
                                </Button>
                            )}
                            {currentTab === 3 && (
                                <Button
                                    onClick={handleSubmit}
                                    variant="contained"
                                    className="btn-filled-primary"
                                >
                                    Create
                                </Button>
                            )}
                        </Box>
                    </Box>
                </Box>
            </Container >
            < CustomDialog open={openAddComplianceDialog} onClose={handleCloseAddComplianceDialog} title="Add Compliance Flag" maxWidth="sm" >
                <Box my={2}>
                    <Typography sx={{ fontSize: "13px", fontWeight: "600", mb: 2 }}>
                        * Compliance Name
                    </Typography>
                    <Box mb={3}>
                        <SimpleTextField
                            fullWidth
                            required
                            value={newComplianceFlag.name}
                            onChange={(e) => setNewComplianceFlag(prev => ({ ...prev, name: e.target.value }))}
                        />
                    </Box>

                    <Typography sx={{ fontSize: "13px", fontWeight: "600", mb: 2 }}>
                        Compliance Description
                    </Typography>
                    <Box mb={3}>
                        <SimpleTextFieldMultiline
                            fullWidth
                            required
                            value={newComplianceFlag.description}
                            onChange={(e) => setNewComplianceFlag(prev => ({ ...prev, description: e.target.value }))}
                        />
                    </Box>
                </Box>

                <Box sx={{ display: "flex", gap: 1.5, justifyContent: "flex-end", mt: 3 }}>
                    <Button
                        variant="outlined"
                        onClick={handleCloseAddComplianceDialog}
                        sx={{ color: "#666", borderColor: "#ddd" }}
                    >
                        Cancel
                    </Button>
                    <Button
                        className="btn-filled-primary"
                        onClick={handleAddNewComplianceFlag}
                        variant="contained"
                    >
                        Add Compliance
                    </Button>
                </Box>
            </CustomDialog >
        </>
    );
};

export default CreateTenantForm;
