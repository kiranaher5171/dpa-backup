"use client";
import MainLayout from '@/Layouts/MainLayout';
import React from 'react';
import CreateTenantForm from './CreateTenantForm';

export default function page() {
    return (
        <>
            <MainLayout>
                <CreateTenantForm />
            </MainLayout>
        </>
    )
}
