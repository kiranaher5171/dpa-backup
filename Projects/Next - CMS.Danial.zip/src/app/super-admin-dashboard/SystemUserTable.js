"use client";

import React, { useState, useMemo, useRef } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, IconButton, Tooltip, Typography, Grid, Button } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import { LuUser } from "react-icons/lu";
import {
  MdPersonOff,
  MdPersonAddAlt,
  MdPauseCircleOutline,
  MdLockReset,
  MdMailOutline,
  MdVisibility
} from "react-icons/md";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import Link from "next/link";
import { FiEye } from "react-icons/fi";
import { ImBlocked } from "react-icons/im";
import { MdOutlinePersonOff } from "react-icons/md";

ModuleRegistry.registerModules([AllCommunityModule]);

const SystemUserTable = ({ onEditUser }) => {
  const [loading, setLoading] = useState(true);
  const gridRef = useRef(null);
  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditUser, setAuditUser] = useState(null);

  const auditLogs = [
    "Vaibhav Updated Previous_Status From Active To Suspend Pending At 2025-12-22 13:25:08",
    "Vaibhav Updated Status From Suspend Pending To Suspended At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_By From 141 To 453 At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_Date From 12/17/2025 To 12/22/2025 At 2025-12-22 13:25:08",
    "Vaibhav Updated Previous_Status From Reactivation Pending To Active At 2025-12-17 11:21:45",
    "Vaibhav Updated Status From Active To Suspend Pending At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_By From 155 To 141 At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_Date From 10/5/2025 To 12/17/2025 At 2025-12-17 11:21:45",
    "Vaibhav Updated Previous_Status From Deactivated To Reactivation Pending At 2025-10-05 09:28:23",
    "Vaibhav Updated Status From Reactivation Pending To Active At 2025-10-05 09:28:23",
  ];

  const filteredAuditLogs = auditLogs.filter((log) =>
    log.toLowerCase().includes((auditSearch || "").toLowerCase())
  );

  React.useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);


  const [rowData] = useState([
    {
      id: 1,
      userName: "Platform Owner",
      role: "Platform Owner",
      assignedTenants: "Big Data Limited, BlueRock Bank, CopperChain...",
      status: "Active",
      lastLogin: "05 Feb 2026 At 06:46 AM",
    },
    {
      id: 2,
      userName: "Security Admin",
      role: "Security Admin",
      assignedTenants: "Google Tenant, Orion Logistics Pvt. Ltd.",
      status: "Active",
      lastLogin: "03 Feb 2026 At 08:01 AM",
    },
    {
      id: 3,
      userName: "Pratima Dongare",
      role: "Super Admin",
      assignedTenants: "Big Data Limited, Newtenant",
      status: "Active",
      lastLogin: "07 Jan 2026 At 09:31 AM",
    },
    {
      id: 4,
      userName: "Testinguser User",
      role: "Platform Owner",
      assignedTenants: "Teanntnewwwwwwww",
      status: "Active",
      lastLogin: "29 Dec 2025 At 07:52 AM",
    },
    {
      id: 5,
      userName: "New User",
      role: "Super Admin",
      assignedTenants: "123, Teanntnewwwwwwww, tenantadmin",
      status: "Active",
      lastLogin: "24 Dec 2025 At 07:40 AM",
    },
  ]);

  const handleDeactivate = (data) => {
    console.log("Deactivate user:", data);
  };

  const handleReactivate = (data) => {
    console.log("Reactivate user:", data);
  };

  const handleSuspend = (data) => {
    console.log("Suspend user:", data);
  };

  const handleResetPassword = (data) => {
    console.log("Reset password for:", data);
  };

  const handleResendInvitation = (data) => {
    console.log("Resend invitation to:", data);
  };

  const handleViewLogs = (data) => {
    setAuditUser(data);
    setAuditSearch("");
    setAuditDialogOpen(true);
  };

  const columnDefs = useMemo(
    () => [
      {
        field: "userName",
        headerName: "User Name",
        minWidth: 180,
        cellRenderer: (params) => <span>{params.value}</span>,
      },
      {
        field: "role",
        headerName: "Role",
        headerClass: "table-header-center",
        minWidth: 160,
        maxWidth: 160,
        cellRenderer: (params) => {
          const roleColors = {
            "Platform Owner": { bg: "#e8f5e9", color: "#2e7d32" },
            "Super Admin": { bg: "#e3f2fd", color: "#1565c0" },
            "Security Admin": { bg: "#fff3e0", color: "#ef6c00" },
            "Support Engineer": { bg: "#e1f5fe", color: "#0277bd" },
            "Compliance Auditor": { bg: "#f3e5f5", color: "#7b1fa2" },
          };
          const style = roleColors[params.value] || { bg: "#f5f5f5", color: "#616161" };
          return (
            <span
              style={{
                backgroundColor: style.bg,
                color: style.color,
                borderRadius: "4px",
                fontSize: "11px",
                fontWeight: 500,
                minWidth: "125px",
                display: "flex",
                height: "25px",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {params.value}
            </span>
          );
        },
      },
      {
        field: "assignedTenants",
        headerName: "Assigned Tenants",
        minWidth: 250,
        cellRenderer: (params) => (
          <span style={{ color: "#616161" }}>{params.value}</span>
        ),
      },
      {
        field: "status",
        headerName: "Status",
        headerClass: "table-header-center",
        minWidth: 160,
        maxWidth: 160,
        cellRenderer: (params) => {
          const statusColors = {
            Active: { bg: "#d6ffd6", color: "green" },
            "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" },
            Deactivated: { bg: "#f5f5f5", color: "#616161" },
            Suspended: { bg: "#ffecef", color: "red" },
          };
          const style = statusColors[params.value] || statusColors.Deactivated;
          return (
            <span
              style={{
                backgroundColor: style.bg,
                color: style.color,
                borderRadius: "4px",
                fontSize: "11px",
                fontWeight: 500,
                minWidth: "120px",
                display: "flex",
                height: "25px",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {params.value}
            </span>
          );
        },
      },
      {
        field: "lastLogin",
        headerName: "Last Login",
        minWidth: 200,
        cellRenderer: (params) => (
          <span style={{ color: "#616161" }}>{params.value}</span>
        ),
      },
      {
        headerName: "Actions",
        field: "actions",
        minWidth: 230,
        maxWidth: 230,
        headerClass: "table-header-center",
        // pinned: "right",
        sortable: false,
        filter: false,
        // lockPosition: true,
        cellRenderer: (params) => {
          return (
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
              <Tooltip title="Deactivate" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleDeactivate(params.data)}
                  sx={{ color: "#ff6100" }}
                >
                  <MdOutlinePersonOff size={18} />
                </IconButton>
              </Tooltip>
           

              <Tooltip title="Reactivate" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleReactivate(params.data)}
                  sx={{ color: "#2e7d32" }}
                >
                  <MdPersonAddAlt size={18} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Suspend" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleSuspend(params.data)}
                  sx={{ color: "var(--error)" }}
                >
                  <ImBlocked size={13} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Reset Password" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleResetPassword(params.data)}
                  sx={{ color: "#2b6bbb" }}
                >
                  <MdLockReset size={18} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Resend Invitation" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleResendInvitation(params.data)}
                  sx={{ color: "#7b1fa2" }}
                >
                  <MdMailOutline size={16} />
                </IconButton>
              </Tooltip>

              <Tooltip title="View Logs" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleViewLogs(params.data)}
                  sx={{ color: "#2b6bbb" }}
                >
                  <FiEye size={16} />
                </IconButton>
              </Tooltip>
            </Box>
          );
        },
      },
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  // Show all rows (no pagination)
  const paginatedRowData = rowData;

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "255px", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box style={{ width: "100%", height: "255px" }}>
            <AgGridReact
              ref={gridRef}
              rowData={paginatedRowData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              pagination={false}
              animateRows={true}
            />
          </Box>
          <Box id="tb_footer" className="fx_fe"  >
          <Link
            href="/system-management"
            className="link-text-btn" 
          > 
          <Button variant="text" color="primary" className="link-text-btn">View All</Button>
          </Link>
          </Box>
        </>
      )}

      <CustomDialog
        open={auditDialogOpen}
        onClose={() => setAuditDialogOpen(false)}
        title="System User Audit Logs"
        maxWidth="md"
      >
        <Box my={2}>
          <Grid container alignItems="center" justifyContent="flex-start" spacing={3}>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box className="fx_fs gap1">
                <LuUser style={{ fontSize: "20px", color: "var(--primary)" }} />
                <Box>
                  {auditUser && (
                    <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                      {auditUser.userName}
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box>
                <SimpleTextField
                  placeholder="Search Logs"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  fullWidth
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <SearchIcon
                        style={{ fontSize: 18, margin: "0px 12px", marginRight: 0, color: "#757575" }}
                      />
                    ),
                  }}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>

        <Box
          sx={{
            height: 250,
            overflow: "auto",
            overflowY: "auto",
            backgroundColor: "#f5f5f5",
            padding: "16px",
            borderRadius: "6px",
          }}
        >
          {filteredAuditLogs.map((log, idx) => (
            <Typography key={idx} variant="body2" sx={{ mb: 0.5, color: "text.secondary" }}>
              {log}
            </Typography>
          ))}
          {filteredAuditLogs.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              No logs match your search.
            </Typography>
          )}
        </Box>
      </CustomDialog>
    </>
  );
};

export default SystemUserTable;
