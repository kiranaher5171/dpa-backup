"use client";

import React, { useState, useMemo, useRef } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, Typography, Grid, Button, IconButton, Tooltip } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import { LuUser } from "react-icons/lu";
import { MdPauseCircleOutline, MdPlayArrow, MdArchive, MdVisibility } from "react-icons/md";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import Link from "next/link";
import { FiEye } from "react-icons/fi";
import { MdOutlineArchive } from "react-icons/md";
import { MdRefresh } from "react-icons/md";
import { ImBlocked } from "react-icons/im";

ModuleRegistry.registerModules([AllCommunityModule]);

const TenantOverviewTable = ({ onEditUser }) => {
  const [loading, setLoading] = useState(true);
  const gridRef = useRef(null);
  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditTenant, setAuditTenant] = useState(null);

  const auditLogs = [
    "Vaibhav Updated Previous_Status From Active To Suspend Pending At 2025-12-22 13:25:08",
    "Vaibhav Updated Status From Suspend Pending To Suspended At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_By From 141 To 453 At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_Date From 12/17/2025 To 12/22/2025 At 2025-12-22 13:25:08",
    "Vaibhav Updated Previous_Status From Reactivation Pending To Active At 2025-12-17 11:21:45",
    "Vaibhav Updated Status From Active To Suspend Pending At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_By From 155 To 141 At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_Date From 10/5/2025 To 12/17/2025 At 2025-12-17 11:21:45",
    "Vaibhav Updated Previous_Status From Deactivated To Reactivation Pending At 2025-10-05 09:28:23",
    "Vaibhav Updated Status From Reactivation Pending To Active At 2025-10-05 09:28:23",
  ];

  const filteredAuditLogs = auditLogs.filter((log) =>
    log.toLowerCase().includes((auditSearch || "").toLowerCase())
  );

  React.useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  const [rowData] = useState([
    {
      id: 1,
      tenantName: "Google Tenant",
      tenantType: "Project Owner",
      plan: "Professional Plan",
      status: "Active",
      users: 8,
      projects: 13,
      lastActivity: "04 Feb 2026 At 01:46 PM",
    },
    {
      id: 2,
      tenantName: "Sunrise Credit Union",
      tenantType: "Project Owner",
      plan: "Basic Plan",
      status: "Active",
      users: 8,
      projects: 3,
      lastActivity: "--",
    },
    {
      id: 3,
      tenantName: "Big Data Limited",
      tenantType: "Sub Contractor",
      plan: "Basic Plan",
      status: "Active",
      users: 3,
      projects: 3,
      lastActivity: "29 Dec 2025 At 09:42 AM",
    },
    {
      id: 4,
      tenantName: "Jacob Tenant",
      tenantType: "Prime Contractor",
      plan: "Professional Plan",
      status: "Active",
      users: 0,
      projects: 0,
      lastActivity: "23 Jan 2026 At 08:05 AM",
    },
    {
      id: 5,
      tenantName: "Globe Tenant",
      tenantType: "Project Owner",
      plan: "Enterprise Plan",
      status: "Active",
      users: 0,
      projects: 0,
      lastActivity: "--",
    },
  ]);

  const handleSuspend = (data) => {
    console.log("Suspend tenant:", data);
  };

  const handleReactivate = (data) => {
    console.log("Reactivate tenant:", data);
  };

  const handleArchive = (data) => {
    console.log("Archive tenant:", data);
  };

  const handleViewLogs = (data) => {
    setAuditTenant(data);
    setAuditSearch("");
    setAuditDialogOpen(true);
  };

  const columnDefs = useMemo(
    () => [
      {
        field: "tenantName",
        headerName: "Tenant Name",
        minWidth: 180,
        cellRenderer: (params) => <span>{params.value}</span>,
      },
      {
        field: "tenantType",
        headerName: "Tenant Type",
        minWidth: 150,
        cellRenderer: (params) => <span>{params.value}</span>,
      },
      {
        field: "plan",
        headerName: "Plan",
        minWidth: 180,
        maxWidth: 180,
        headerClass: "table-header-center",
        cellRenderer: (params) => {
          const planColors = {
            "Professional Plan": { bg: "#d6ffd6", color: "green" },
            "Basic Plan": { bg: "#e3f2fd", color: "#1565c0" },
            "Enterprise Plan": { bg: "#fff9c4", color: "#f57f17" },
          };
          const style = planColors[params.value] || { bg: "#f5f5f5", color: "#616161" };
          return (
            <span
              style={{
                backgroundColor: style.bg,
                color: style.color,
                borderRadius: "4px",
                fontSize: "11px",
                fontWeight: 500,
                minWidth: "120px",
                display: "flex",
                height: "25px",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {params.value}
            </span>
          );
        },
      },
      {
        field: "status",
        headerName: "Status",
        minWidth: 150,
        headerClass: "table-header-center",
        maxWidth: 150,
        cellRenderer: (params) => {
          const statusColors = {
            Active: { bg: "#d6ffd6", color: "green" },
            "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" },
            Deactivated: { bg: "#f5f5f5", color: "#616161" },
            Suspended: { bg: "#ffecef", color: "red" },
          };
          const style = statusColors[params.value] || statusColors.Deactivated;
          return (
            <span
              style={{
                backgroundColor: style.bg,
                color: style.color,
                borderRadius: "4px",
                fontSize: "11px",
                fontWeight: 500,
                minWidth: "100px",
                display: "flex",
                height: "25px",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {params.value}
            </span>
          );
        },
      },
      {
        field: "users",
        headerName: "Users",
        minWidth: 100,
        headerClass: "table-header-right",
        cellClass: "fx_fe",
        cellRenderer: (params) => <span>{params.value}</span>,
      },
      {
        field: "projects",
        headerName: "Projects",
        cellClass: "fx_fe",
        headerClass: "table-header-right",
        minWidth: 100,
        cellRenderer: (params) => <span>{params.value}</span>,
      }, 
      {
        headerName: "Actions",
        field: "actions",
        minWidth: 200,
        headerClass: "table-header-center",
        // pinned: "right",
        sortable: false,
        filter: false,
        // lockPosition: true,
        cellRenderer: (params) => {
          return (
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
              <Tooltip title="Suspend" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleSuspend(params.data)}
                  sx={{ color: "var(--error)" }}
                >
                  <ImBlocked size={13} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Reactivate" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleReactivate(params.data)}
                  sx={{ color: "#2e7d32" }}
                >
                  <MdRefresh size={18} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Archive" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleArchive(params.data)}
                  sx={{ color: "#616161" }}
                >
                  <MdOutlineArchive size={18} />
                </IconButton>
              </Tooltip>

              <Tooltip title="View Logs" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleViewLogs(params.data)}
                  sx={{ color: "#2b6bbb" }}
                >
                  <FiEye size={16} />
                </IconButton>
              </Tooltip>
            </Box>
          );
        },
      },
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  // Show all rows (no pagination)
  const paginatedRowData = rowData;

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "255px", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box style={{ width: "100%", height: "255px" }}>
            <AgGridReact
              ref={gridRef}
              rowData={paginatedRowData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              pagination={false}
              animateRows={true}
            />
          </Box>
          <Box id="tb_footer" className="fx_fe">
            <Link href="/tenant-management" className="link-text-btn">
              <Button variant="text" color="primary" className="link-text-btn">
                View All
              </Button>
            </Link>
          </Box>
        </>
      )}

      <CustomDialog
        open={auditDialogOpen}
        onClose={() => setAuditDialogOpen(false)}
        title="Tenant Audit Logs"
        maxWidth="md"
      >
        <Box my={2}>
          <Grid container alignItems="center" justifyContent="flex-start" spacing={3}>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box className="fx_fs gap1">
                <LuUser style={{ fontSize: "20px", color: "var(--primary)" }} />
                <Box>
                  {auditTenant && (
                    <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                      {auditTenant.tenantName}
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box>
                <SimpleTextField
                  placeholder="Search Logs"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  fullWidth
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <SearchIcon
                        style={{ fontSize: 18, margin: "0px 12px", marginRight: 0, color: "#757575" }}
                      />
                    ),
                  }}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>

        <Box
          sx={{
            height: 250,
            overflow: "auto",
            overflowY: "auto",
            backgroundColor: "#f5f5f5",
            padding: "16px",
            borderRadius: "6px",
          }}
        >
          {filteredAuditLogs.map((log, idx) => (
            <Typography key={idx} variant="body2" sx={{ mb: 0.5, color: "text.secondary" }}>
              {log}
            </Typography>
          ))}
          {filteredAuditLogs.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              No logs match your search.
            </Typography>
          )}
        </Box>
      </CustomDialog>
    </>
  );
};

export default TenantOverviewTable;
