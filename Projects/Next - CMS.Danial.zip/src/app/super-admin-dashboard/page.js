"use client";

import MainLayout from "@/Layouts/MainLayout";
import React, { useState } from "react";
import Link from "next/link";
import {
  Box,
  Button,
  Container,
  Grid,
  InputAdornment,
  TextField,
  Typography,
} from "@mui/material";
import WhiteCard from "@/components/whiteCards";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";
import SystemUserTable from "./SystemUserTable";
import { FiPlus, FiBell, FiUsers, FiBarChart2, FiX, FiCheck } from "react-icons/fi";
import { MdOutlineSubscriptions } from "react-icons/md";
import { MdOutlineDescription } from "react-icons/md";
import TenantOverviewTable from "./TenantOverviewTable";
import { FaSearch } from "react-icons/fa";

const TENANT_SUMMARY_CARDS = [
  { value: "18", label: "Total Tenants", valueColor: "#2b6bbb", href: "/tenant-management" },
  { value: "20", label: "Users Across Tenants", valueColor: "green", href: "/tenant-management" },
  { value: "20", label: "Active Projects", valueColor: "#7b1fa2", href: "/tenant-management" },
  { value: "2", label: "New Tenants (30d)", valueColor: "#ff6100", href: "/tenant-management" },
];

const SUBSCRIPTION_PLANS_CARDS = [
  { value: "9", label: "Basic Plan", valueColor: "#9c27b0", href: "/system-management" },
  { value: "4", label: "Professional Plan", valueColor: "#009688", href: "/system-management" },
  { value: "5", label: "Enterprise Plan", valueColor: "#7b1fa2", href: "/system-management" },
];

const PENDING_APPROVALS = [

  {
    id: 1,
    title: "Assign User 'Akhil Mitta' to Project 'DNL Test Project'",
    requestedBy: "Google Admin on 06 Jan 2026 At 09:04 AM",
  },
  {
    id: 2,
    title: "Create Contract Party - Colorcheck (Contractor)",
    requestedBy: "Requested by Google Admin on 21 Nov 2025 at 10:44 AM",
  },
];

const Page = () => {
  const [planFilter, setPlanFilter] = useState({ label: "All Plans", value: "all" });
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  const handleApprove = (id) => {
    console.log("Approve", id);
  };

  const handleReject = (id) => {
    console.log("Reject", id);
  };

  const handleCreateUser = () => {
    setEditingUser(null);
    setDrawerOpen(true);
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setDrawerOpen(false);
    setEditingUser(null);
  };

  return (
    <MainLayout>
      <Container maxWidth sx={{ py: 2 }}>
        <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="fx_sb w100" mb={2}>
              <Box className="fx_fs gap1">
                <Box className="heading-decorator" />
                <Typography variant="h5" className="primary fw6">
                  Super Admin Dashboard
                </Typography>
              </Box>
            </Box>



            {/* Tenant Overview */}
            <Box className="table-box" mb={2}>
              <Box mb={2}>
                <Box className="fx_sb w100" mb={1}>
                  <Box className="fx_fs gap1">
                    <MdOutlineDescription size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                      Tenant Summary
                    </Typography>
                  </Box>
                  <Box sx={{ minWidth: 160 }}>
                    <SingleSelectAutocomplete
                      placeholder="All Plans"
                      options={[
                        { label: "All Plans", value: "all" },
                        { label: "Professional Plan", value: "professional" },
                        { label: "Basic Plan", value: "basic" },
                      ]}
                      value={planFilter}
                      onChange={setPlanFilter}
                    />
                  </Box>
                </Box>
                {/* Tenant Statistics */}
                <Grid container spacing={2} alignItems="stretch" justifyContent="flex-start" >
                  {TENANT_SUMMARY_CARDS.map((card, index) => (
                    <Grid item xs={12} sm={6} md={3} lg={3} key={index}>
                      <WhiteCard
                        value={card.value}
                        label={card.label}
                        valueColor={card.valueColor}
                        href={card.href}
                      />
                    </Grid>
                  ))}
                </Grid>
              </Box>

              <Box mb={2}>
                <Box className="fx_sb w100" mb={1}>
                  <Box className="fx_fs gap1" py={1}>
                    <MdOutlineSubscriptions size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                      Subscription Plans
                    </Typography>
                  </Box>
                </Box>
                <Grid container spacing={2} alignItems="stretch" justifyContent="flex-start" >
                  {SUBSCRIPTION_PLANS_CARDS.map((card, index) => (
                    <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
                      <WhiteCard value={card.value} label={card.label} href={card.href} />
                    </Grid>
                  ))}
                </Grid>
              </Box>


              <Box mt={2}>
                <Box className="fx_sb w100" mb={1}>
                  <Box className="fx_fs gap1">
                    <FiUsers size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                      Tenant Overview
                    </Typography>
                  </Box>

                  <Box className="fx_fe gap1">
                    <Box className="textfield-search">
                      <TextField
                        placeholder="Search"
                        size="small"
                        fullWidth={true}
                        InputProps={{
                          startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                        }}
                      />
                    </Box>
                    <Link href="/tenant-management/create-tenant" passHref legacyBehavior>
                      <Button
                        variant="contained"
                        className="primary-btn mobile-ico-btn"
                        startIcon={<FiPlus />}
                        sx={{ flexShrink: 0 }}
                        component="a"
                      >
                        <span className="mobile-ico-btn-text">Create Tenant</span>
                      </Button>
                    </Link>
                  </Box>
                </Box>
                <TenantOverviewTable onEditUser={handleEditUser} />
              </Box>

             
            </Box>



            {/* Tenant Overview */}
            <Box className="table-box" mb={3}>
            <Box >
                <Box className="fx_sb w100" mb={1}>
                  <Box className="fx_fs gap1" py={1}>
                    <FiUsers size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                      System Users
                    </Typography>
                  </Box>
                </Box>
                <SystemUserTable onEditUser={handleEditUser} />
              </Box>
            </Box>


            {/* Pending Approvals */}
            <Box className="table-box" mb={3}>
              <Box>
                <Box className="fx_fs gap1" mb={2}>
                  <Box sx={{ position: "relative", display: "inline-flex" }}>
                    <FiBell size={22} style={{ color: "var(--error)" }} />
                  </Box>
                  <Typography variant="h5" className="red fw6">
                    Pending Actions(Operartional Queue)
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  {PENDING_APPROVALS.map((item) => (
                    <Grid item lg={12} xs={12} md={6} key={item.id}>
                      <Box
                        sx={{
                          p: 2,
                          height: "100%",
                          bgcolor: "#f9f9f9",
                          borderRadius: 1,
                          border: "1px solid #eee",
                        }}
                      >
                        <Grid container alignItems="center" spacing={2}>
                          <Grid item xs={12} sm={12} md={6} lg={9}>
                            <Typography variant="subtitle1" fontWeight={600} sx={{ mb: 0.5 }}>
                              {item.title}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              Requested by {item.requestedBy}
                            </Typography>
                          </Grid>
                          <Grid
                            item
                            xs={12}
                            sm={12}
                            md={6}
                            lg={3}
                            sx={{
                              display: "flex",
                              gap: 1,
                              justifyContent: { xs: "flex-start", sm: "flex-start", md: "flex-end" },
                              flexShrink: 0,
                            }}
                          >
                            <Button
                              variant="outlined"
                              className="primary-outlined-btn mobile-ico-btn"
                              size="small"
                              startIcon={<FiX />}
                              onClick={() => handleReject(item.id)}
                            >
                              <span className="mobile-ico-btn-text"> Reject</span>
                            </Button>
                            <Button
                              variant="contained"
                              className="primary-btn mobile-ico-btn"
                              size="small"
                              startIcon={<FiCheck />}
                              onClick={() => handleApprove(item.id)}
                            >
                              <span className="mobile-ico-btn-text">Approve</span>
                            </Button>
                          </Grid>
                        </Grid>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
                <Box className="fx_fe gap1" mt={2}>
                   <Link
            href="/#"
            className="link-text-btn" 
          > 
          <Button variant="text" color="primary" className="link-text-btn">View All</Button>
          </Link>
                </Box>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </MainLayout>
  );
};

export default Page;
