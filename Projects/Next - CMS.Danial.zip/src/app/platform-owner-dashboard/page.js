"use client";

import MainLayout from "@/Layouts/MainLayout";
import React, { useState, useMemo, useRef } from "react";
import Link from "next/link";
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  IconButton,
  Tooltip,
  InputAdornment,
} from "@mui/material";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import WhiteCard from "@/components/whiteCards";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import SideDrawer from "@/components/SideDrawer";
import SystemUserForm from "@/app/system-management/SystemUserForm";
import { FiPlus, FiBell, FiUsers, FiLayers, FiEye, FiBarChart2, FiCheck, FiX } from "react-icons/fi";
import { LuUserPlus } from "react-icons/lu";
import SearchIcon from "@mui/icons-material/Search";

ModuleRegistry.registerModules([AllCommunityModule]);

const TENANT_STAT_CARDS = [
  { value: "10", label: "Total Tenants", valueColor: "#2b6bbb", href: "/tenant-management" },
  { value: "8", label: "Active", valueColor: "green", href: "/tenant-management" },
  { value: "0", label: "Suspended", valueColor: "red", href: "/tenant-management" },
  { value: "0", label: "Archived", valueColor: "#616161", href: "/tenant-management" },
  { value: "1", label: "Trial Expired", valueColor: "#ff6100", href: "/tenant-management" },
];

const SYSTEM_USER_CARDS = [
  { value: "34", label: "Platform Owners", href: "/system-management" },
  { value: "16", label: "Super Admins", href: "/system-management" },
  { value: "3", label: "Security Admins", href: "/system-management" },
  { value: "1", label: "Compliance Auditors", href: "/system-management" },
  { value: "2", label: "Support Engineers", href: "/system-management" },
];

const PENDING_APPROVALS = [
  {
    id: 1,
    title: "Tenant 'Platformdash' Suspension Request",
    requestedBy: "Anjireddy Auditor on 02 Jan 2026 At 09:34 AM",
  },
  {
    id: 2,
    title: "Assign User 'Akhil Mitta' to Project 'DNL Test Project'",
    requestedBy: "Google Admin on 06 Jan 2026 At 09:04 AM",
  },
  {
    id: 3,
    title: "Tenant 'Sunrise Villas' Reactivation Request",
    requestedBy: "Platform Admin on 05 Jan 2026 At 02:15 PM",
  },
  {
    id: 4,
    title: "Assign User 'John Smith' to Project 'Heritage Tenant'",
    requestedBy: "Super Admin on 04 Jan 2026 At 11:20 AM",
  },
  {
    id: 5,
    title: "Tenant 'Metro Holdings' Plan Upgrade Request",
    requestedBy: "Compliance Auditor on 03 Jan 2026 At 09:00 AM",
  },
];

const TENANT_OVERVIEW_DATA = [
  { id: 1, tenantName: "Google Tenant", tenantType: "Project Owner", plan: "Professional Plan", status: "Active", users: 12, projects: 5 },
  { id: 2, tenantName: "Sunrise Credit Union", tenantType: "Project Owner", plan: "Professional Plan", status: "Active", users: 8, projects: 3 },
  { id: 3, tenantName: "Big Data Limited", tenantType: "Sub Contractor", plan: "Basic Plan", status: "Active", users: 5, projects: 2 },
  { id: 4, tenantName: "Heritage Tenant", tenantType: "Project Owner", plan: "Professional Plan", status: "Active", users: 6, projects: 4 },
  { id: 5, tenantName: "Platformdash", tenantType: "Project Owner", plan: "Basic Plan", status: "Suspended", users: 3, projects: 1 },
  { id: 6, tenantName: "Globe Tenant", tenantType: "Prime Contractor", plan: "Professional Plan", status: "Active", users: 15, projects: 7 },
  { id: 7, tenantName: "CopperChain", tenantType: "Sub Contractor", plan: "Basic Plan", status: "Active", users: 4, projects: 2 },
  { id: 8, tenantName: "DKF Construction", tenantType: "Prime Contractor", plan: "Professional Plan", status: "Active", users: 10, projects: 5 },
  { id: 9, tenantName: "Sunrise Villas", tenantType: "Project Owner", plan: "Basic Plan", status: "Awaiting Activation", users: 2, projects: 0 },
  { id: 10, tenantName: "Metro Holdings", tenantType: "Project Owner", plan: "Professional Plan", status: "Active", users: 9, projects: 4 },
  { id: 11, tenantName: "Northgate Corp", tenantType: "Sub Contractor", plan: "Basic Plan", status: "Active", users: 7, projects: 3 },
  { id: 12, tenantName: "Pacific Ventures", tenantType: "Project Owner", plan: "Professional Plan", status: "Deactivated", users: 0, projects: 0 },
  { id: 13, tenantName: "Summit Labs", tenantType: "Project Owner", plan: "Basic Plan", status: "Active", users: 5, projects: 2 },
  { id: 14, tenantName: "Vertex Solutions", tenantType: "Prime Contractor", plan: "Professional Plan", status: "Active", users: 11, projects: 6 },
  { id: 15, tenantName: "Apex Industries", tenantType: "Sub Contractor", plan: "Basic Plan", status: "Active", users: 4, projects: 1 },
];

const TENANT_OVERVIEW_PREVIEW_SIZE = 5;

const TENANT_AUDIT_LOGS = [
  "Admin Updated Tenant Status From Active To Suspended At 2026-02-01 10:30:00",
  "Admin Updated Plan From Basic To Professional At 2026-01-28 14:22:15",
  "System User 'Google Admin' Logged In At 2026-01-27 09:15:00",
  "Admin Updated Users Count From 10 To 12 At 2026-01-25 11:00:00",
  "Admin Updated Projects From 4 To 5 At 2026-01-20 16:45:30",
  "Tenant Agreement Accepted By Platform Admin At 2026-01-15 08:00:00",
  "Admin Updated Previous_Status From Awaiting Activation To Active At 2026-01-10 12:30:00",
  "Support Engineer Viewed Audit Logs At 2026-01-05 09:20:00",
];

const Page = () => {
  const [planFilter, setPlanFilter] = useState({ label: "All Plans", value: "all" });
  const [tenantPage, setTenantPage] = useState(1);
  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditTenant, setAuditTenant] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const gridRef = useRef(null);

  const filteredAuditLogs = TENANT_AUDIT_LOGS.filter((log) =>
    log.toLowerCase().includes((auditSearch || "").toLowerCase())
  );

  const tenantTableRows = TENANT_OVERVIEW_DATA.slice(0, TENANT_OVERVIEW_PREVIEW_SIZE);

  const handleApprove = (id) => {
    console.log("Approve", id);
  };

  const handleReject = (id) => {
    console.log("Reject", id);
  };

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  const columnDefs = useMemo(
    () => [
      {
        field: "tenantName",
        headerName: "Tenant Name",
        minWidth: 180,
        cellRenderer: (params) => (
          <Link
            href="/tenant-management/tenant-management-details"
            style={{ color: "#2b6bbb", textDecoration: "none", cursor: "pointer" }}
          >
            {params.value}
          </Link>
        ),
      },
      { field: "tenantType", headerName: "Tenant Type", minWidth: 150 },
      {
        field: "plan",
        headerName: "Plan",
        minWidth: 150,
        cellRenderer: (params) => {
          const isProfessional = (params.value || "").toLowerCase().includes("professional");
          const style = isProfessional
            ? { bg: "#d6ffd6", color: "green" }
            : { bg: "#e3f2fd", color: "#1565c0" };
          return (
            <span
              style={{
                backgroundColor: style.bg,
                color: style.color,
                borderRadius: "4px",
                fontSize: "11px",
                fontWeight: 500,
                minWidth: "120px",
                display: "flex",
                height: "25px",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {params.value}
            </span>
          );
        },
      },
      {
        field: "status",
        headerName: "Status",
        minWidth: 160,
        maxWidth: 160,
        cellRenderer: (params) => {
          const statusColors = {
            Active: { bg: "#d6ffd6", color: "green" },
            "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" },
            Deactivated: { bg: "#f5f5f5", color: "#616161" },
            Suspended: { bg: "#ffecef", color: "red" },
          };
          const style = statusColors[params.value] || statusColors.Deactivated;
          return (
            <span
              style={{
                backgroundColor: style.bg,
                color: style.color,
                borderRadius: "4px",
                fontSize: "11px",
                fontWeight: 500,
                minWidth: "120px",
                display: "flex",
                height: "25px",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {params.value}
            </span>
          );
        },
      },
      { field: "users", headerName: "Users", minWidth: 100 },
      { field: "projects", headerName: "Projects", minWidth: 100 },
      {
        field: "auditLogs",
        headerName: "Audit Logs",
        minWidth: 120,
        maxWidth: 120,
        sortable: false,
        cellRenderer: (params) => (
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
            <Tooltip title="View Audit Logs" arrow>
              <IconButton
                size="small"
                className="ico-btn"
                onClick={() => {
                  setAuditSearch("");
                  setAuditTenant(params.data);
                  setAuditDialogOpen(true);
                }}
                sx={{ color: "#2b6bbb" }}
              >
                <FiEye size={16} />
              </IconButton>
            </Tooltip>
          </Box>
        ),
      },
    ],
    []
  );

  return (
    <MainLayout>
      <Container maxWidth sx={{ py: 2 }}>
        <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="fx_sb w100" mb={2}>
              <Box className="fx_fs gap1">
                <Box className="heading-decorator" />
                <Typography variant="h5" className="primary fw6">
                  Platform Owner Dashboard
                </Typography>
              </Box>
            </Box>

            {/* System Users by Role */}
            <Box className="table-box" mb={3}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_sb w100" mb={2}>
                  <Box className="fx_fs gap1">
                    <FiUsers size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                      System Users by Role
                    </Typography>
                  </Box>
                  <Button
                    variant="contained"
                    className="primary-btn mobile-ico-btn"
                    startIcon={<FiPlus />}
                    onClick={() => {
                      setEditingUser(null);
                      setDrawerOpen(true);
                    }}
                    sx={{ flexShrink: 0 }}
                  >
                    <span className="mobile-ico-btn-text">Create System User</span>
                  </Button>
                </Box>
                <Grid container spacing={2} alignItems="stretch" justifyContent="flex-start">
                  {SYSTEM_USER_CARDS.map((card, index) => (
                    <Grid item xs={12} sm={6} md={4} lg={2.4} key={index}>
                      <WhiteCard value={card.value} label={card.label} href={card.href} />
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </Box>




            {/* Tenant Overview */}
            <Box className="table-box" mb={2}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_sb w100" mb={2}>
                  <Box className="fx_fs gap1">
                    <FiBarChart2 size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                      Tenants by Status
                    </Typography>
                  </Box>
                  <Box sx={{ minWidth: 160 }}>
                    <SingleSelectAutocomplete
                      placeholder="All Plans"
                      options={[
                        { label: "All Plans", value: "all" },
                        { label: "Professional Plan", value: "professional" },
                        { label: "Basic Plan", value: "basic" },
                      ]}
                      value={planFilter}
                      onChange={setPlanFilter}
                    />
                  </Box>
                </Box>
                {/* Tenant Statistics */}
                <Grid container spacing={2} alignItems="stretch" justifyContent="flex-start" sx={{ mb: 3 }}>
                  {TENANT_STAT_CARDS.map((card, index) => (
                    <Grid item xs={12} sm={6} md={4} lg={2.4} key={index}>
                      <WhiteCard
                        value={card.value}
                        label={card.label}
                        valueColor={card.valueColor}
                        href={card.href}
                      />
                    </Grid>
                  ))}
                </Grid>
                <Box className="fx_fs gap1" mb={2}>
                  <FiLayers size={22} style={{ color: "var(--primary)" }} />
                  <Typography variant="h5" className="primary fw6">
                    Tenant Overview
                  </Typography>
                </Box>
                <Box sx={{ width: "100%", height: "30vh", position: "relative" }}>
                  <AgGridReact
                    ref={gridRef}
                    rowData={tenantTableRows}
                    columnDefs={columnDefs}
                    defaultColDef={defaultColDef}
                    getRowStyle={getRowStyle}
                    headerHeight={40}
                    rowHeight={40}
                    suppressCellFocus={true}
                    pagination={false}
                    animateRows={true}
                  />
                </Box>
                <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1 }}>
                  <Link
                    href="/tenant-management"
                    style={{
                      color: "#2b6bbb",
                      fontSize: "14px",
                      fontWeight: 500,
                      textDecoration: "none",
                    }}
                  >
                    View All
                  </Link>
                </Box>
              </Box>
            </Box>


            {/* Pending Approvals */}
            <Box className="table-box" mb={3}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_fs gap1" mb={2}>
                  <Box sx={{ position: "relative", display: "inline-flex" }}>
                    <FiBell size={22} style={{ color: "var(--primary)" }} />
                  </Box>
                  <Typography variant="h5" className="primary fw6">
                    Pending Approvals ({PENDING_APPROVALS.length})
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  {PENDING_APPROVALS.map((item) => (
                    <Grid item lg={12} xs={12} md={6} key={item.id}>
                      <Box
                        sx={{
                          p: 2,
                          height: "100%",
                          bgcolor: "#f9f9f9",
                          borderRadius: 1,
                          border: "1px solid #eee",
                        }}
                      >
                        <Grid container alignItems="center" spacing={2}>
                          <Grid item xs={12} sm={12} md={6} lg={9}>
                            <Typography variant="subtitle1" fontWeight={600} sx={{ mb: 0.5 }}>
                              {item.title}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              Requested by {item.requestedBy}
                            </Typography>
                          </Grid>
                          <Grid
                            item
                            xs={12}
                            sm={12}
                            md={6}
                            lg={3}
                            sx={{
                              display: "flex",
                              gap: 1,
                              justifyContent: { xs: "flex-start", sm: "flex-start", md: "flex-end" },
                              flexShrink: 0,
                            }}
                          >
                            <Button
                              variant="outlined"
                              className="primary-outlined-btn mobile-ico-btn"
                              size="small"
                              startIcon={<FiX />}
                              onClick={() => handleReject(item.id)}
                            >
                              <span className="mobile-ico-btn-text"> Reject</span>
                            </Button>
                            <Button
                              variant="contained"
                              className="primary-btn mobile-ico-btn"
                              size="small"
                              startIcon={<FiCheck />}
                              onClick={() => handleApprove(item.id)}
                            >
                              <span className="mobile-ico-btn-text">Approve</span>
                            </Button>
                          </Grid>
                        </Grid>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
                <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1 }}>
                  <Link
                    href="/notifications"
                    style={{
                      color: "#2b6bbb",
                      fontSize: "14px",
                      fontWeight: 500,
                      textDecoration: "none",
                    }}
                  >
                    View All
                  </Link>
                </Box>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Container>

      <CustomDialog
        open={auditDialogOpen}
        onClose={() => setAuditDialogOpen(false)}
        title="Tenant Audit Logs"
        maxWidth="md"
      >
        <Box my={2}>
          <Grid container alignItems="center" justifyContent="flex-start" spacing={3}>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box className="fx_fs gap1">
                <FiLayers size={20} style={{ color: "var(--primary)" }} />
                <Box>
                  {auditTenant && (
                    <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                      {auditTenant.tenantName}
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <SimpleTextField
                placeholder="Search Logs"
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
                fullWidth
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon style={{ fontSize: 18, margin: '0px 12px', marginRight: 0, color: "#757575" }} />
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
          </Grid>
        </Box>
        <Box
          sx={{
            height: 250,
            overflow: "auto",
            overflowY: "auto",
            backgroundColor: "#f5f5f5",
            padding: "16px",
            borderRadius: "6px",
          }}
        >
          {filteredAuditLogs.map((log, idx) => (
            <Typography key={idx} variant="body2" sx={{ mb: 0.5, color: "text.secondary" }}>
              {log}
            </Typography>
          ))}
          {filteredAuditLogs.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              No logs match your search.
            </Typography>
          )}
        </Box>
      </CustomDialog>

      <SideDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <Box className="right-drawer-header fx_fs gap1">
          <LuUserPlus style={{ fontSize: "20px", color: "var(--primary)" }} />
          <Typography variant="h5" className="primary fw6">
            {editingUser ? "Edit System User" : "Create System User"}
          </Typography>
        </Box>
        <Box className="right-drawer-content">
          <SystemUserForm />
        </Box>
        <Box className="right-drawer-footer fx_fe gap1">
          <Button variant="contained" className="primary-outlined-btn" onClick={() => setDrawerOpen(false)}>
            Cancel
          </Button>
          <Button variant="contained" className="primary-btn" autoFocus onClick={() => setDrawerOpen(false)}>
            Save
          </Button>
        </Box>
      </SideDrawer>
    </MainLayout>
  );
};

export default Page;
