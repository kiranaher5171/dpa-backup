"use client";

import React, { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, IconButton, Tooltip, Typography, Grid, Button, Container, TextField, InputAdornment, Autocomplete, Menu, MenuItem, Stack } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import { LuUser } from "react-icons/lu";
import { FiPlus, FiEdit, FiChevronDown } from "react-icons/fi";
import { MdContentCopy } from "react-icons/md";
import { FaSearch } from "react-icons/fa";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import Link from "next/link";
import MainLayout from "@/Layouts/MainLayout";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import SideDrawer from "@/components/SideDrawer";
import CloneNamingConventionForm from "./CloneNamingConventionForm";
import { SiRclone } from "react-icons/si";

ModuleRegistry.registerModules([AllCommunityModule]);

const NamingConventionPage = () => {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [auditDialogOpen, setAuditDialogOpen] = useState(false);
    const [auditSearch, setAuditSearch] = useState("");
    const [auditUser, setAuditUser] = useState(null);
    const [searchValue, setSearchValue] = useState("");
    const [selectedModule, setSelectedModule] = useState("All");
    const [actionAnchorEl, setActionAnchorEl] = useState(null);
    const actionMenuOpen = Boolean(actionAnchorEl);
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [cloneData, setCloneData] = useState(null);

    const auditLogs = [
        "Vaibhav Updated Previous_Status From Active To Suspend Pending At 2025-12-22 13:25:08",
        "Vaibhav Updated Status From Suspend Pending To Suspended At 2025-12-22 13:25:08",
        "Vaibhav Updated Updated_By From 141 To 453 At 2025-12-22 13:25:08",
        "Vaibhav Updated Updated_Date From 12/17/2025 To 12/22/2025 At 2025-12-22 13:25:08",
        "Vaibhav Updated Previous_Status From Reactivation Pending To Active At 2025-12-17 11:21:45",
        "Vaibhav Updated Status From Active To Suspend Pending At 2025-12-17 11:21:45",
        "Vaibhav Updated Updated_By From 155 To 141 At 2025-12-17 11:21:45",
        "Vaibhav Updated Updated_Date From 10/5/2025 To 12/17/2025 At 2025-12-17 11:21:45",
        "Vaibhav Updated Previous_Status From Deactivated To Reactivation Pending At 2025-10-05 09:28:23",
        "Vaibhav Updated Status From Reactivation Pending To Active At 2025-10-05 09:28:23",
    ];

    const filteredAuditLogs = auditLogs.filter((log) =>
        log.toLowerCase().includes((auditSearch || "").toLowerCase())
    );

    useEffect(() => {
        const timer = setTimeout(() => {
            setLoading(false);
        }, 2500);

        return () => clearTimeout(timer);
    }, []);


    // Row data matching the image
    const [rowData] = useState([
        {
            id: 1,
            project: "ABCD Project 1",
            modules: "Correspondence",
            categoryName: "Contract Records",
            objectName: "Letter",
            referenceId: "202-ANJI-001-V.0",
            createdBy: "Google Admin",
            createdDate: "12 Nov 2025 At 02:17 PM",
            cloneRefId: "",
            modifiedBy: "",
            modifiedOn: "",
        },
        {
            id: 2,
            project: "ABCD Project 2",
            modules: "Correspondence",
            categoryName: "Contract Records",
            objectName: "MoM",
            referenceId: "202-ANJI-001-V.0",
            createdBy: "Google Admin",
            createdDate: "11 Nov 2025 At 07:07 AM",
            cloneRefId: "",
            modifiedBy: "Google Admin",
            modifiedOn: "12 Nov 2025 At 12:25 PM",
        },
    ]);

    const handleEdit = (data) => {
        router.push("/naming-convention/create-naming-convention");
    };

    const handleClone = (data) => {
        setCloneData(data);
        setDrawerOpen(true);
    };

    const handleCloseDrawer = () => {
        setDrawerOpen(false);
        setCloneData(null);
    };

    const handleActionClick = (event) => {
        setActionAnchorEl(event.currentTarget);
    };

    const handleActionClose = () => {
        setActionAnchorEl(null);
    };

    const handleCreate = () => {
        router.push("/naming-convention/create-naming-convention");
    };

    const moduleOptions = ["All", "Correspondence", "Prime Contract", "Subcontracts"];


    const columnDefs = useMemo(
        () => [
            {
                field: "project",
                headerName: "Project",
                minWidth: 150,
                flex: 1,
            },
            {
                field: "modules",
                headerName: "Modules",
                minWidth: 150,
                flex: 1,
            },
            {
                field: "categoryName",
                headerName: "Category Name",
                minWidth: 150,
                flex: 1,
            },
            {
                field: "objectName",
                headerName: "Object Name",
                minWidth: 150,
                flex: 1,
            },
            {
                field: "referenceId",
                headerName: "Reference ID",
                minWidth: 150,
                flex: 1,
            },
            {
                field: "createdBy",
                headerName: "Created By",
                minWidth: 150,
                flex: 1,
            },
            {
                field: "createdDate",
                headerName: "Created Date",
                minWidth: 150,
                flex: 1,
            }, 
            {
                field: "modifiedBy",
                headerName: "Modified by",
                minWidth: 150,
                flex: 1,
            },
            {
                field: "modifiedOn",
                headerName: "Modified on",
                minWidth: 150,
                flex: 1,
            },
            {
                headerName: "Actions",
                field: "actions",
                headerClass: "table-header-center",
                width: 120, 
                cellRenderer: (params) => (
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
                        <Tooltip title="Edit" arrow>
                            <IconButton
                                size="small"
                                onClick={() => handleEdit(params.data)}
                                sx={{ color: "#2b6bbb" }}
                            >
                                <FiEdit size={16} />
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="Clone Ref ID" arrow>
                            <IconButton
                                size="small"
                                onClick={() => handleClone(params.data)}
                                sx={{ color: "#2b6bbb" }}
                            >
                                <MdContentCopy size={16} />
                            </IconButton>
                        </Tooltip>
                    </Box>
                ),
                sortable: false,
                filter: false,
            },
        ],
        []
    );

    const defaultColDef = useMemo(
        () => ({
            sortable: true,
            filter: false,
            resizable: true,
            suppressMovable: true,
        }),
        []
    );

    const getRowStyle = (params) => ({
        backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
    });

    // Pagination logic
    const rowsPerPage = 10;
    const totalPages = Math.ceil(rowData.length / rowsPerPage);
    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const paginatedRowData = rowData.slice(startIndex, endIndex);

    return (

        <MainLayout>
            <Container maxWidth sx={{ py: 2 }}>
                <>

                    <Box className="fx_fs gap1" mb={2}>
                        <Box className="heading-decorator" />
                        <Typography variant="h5" className="primary fw6">
                            Naming Convention
                        </Typography>
                    </Box>
                    <Box className="table-box">
                        {/* Search and Action Buttons */}
                        <Stack direction="row" justifyContent="flex-end" alignItems="center" flexWrap={'wrap'} gap={2} mb={2}>


                            <Box className="textfield-search">
                                <TextField
                                    placeholder="Search"
                                    size="small"
                                    fullWidth={true}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                                    }}
                                />
                            </Box>

                            <Button
                                variant="contained"
                                className="primary-btn"
                                startIcon={<FiPlus />}
                                onClick={handleCreate}
                            >
                                Create
                            </Button>
                        </Stack>

                        {loading ? (
                            <Box style={{ width: "100%", height: "60vh", overflow: "auto" }}>
                                <TableSkeleton />
                            </Box>
                        ) : (
                            <>
                                <Box style={{ width: "100%", height: "60vh" }}>
                                    <AgGridReact
                                        rowData={paginatedRowData}
                                        columnDefs={columnDefs}
                                        defaultColDef={defaultColDef}
                                        getRowStyle={getRowStyle}
                                        headerHeight={40}
                                        rowHeight={40}
                                        pagination={false}
                                        animateRows={true}
                                    />
                                </Box>
                                <Box id="tb_footer" className="fx_sb" mt={1}>
                                    <AgGridInfo
                                        currentPage={currentPage}
                                        rowsPerPage={rowsPerPage}
                                        totalRows={rowData.length}
                                    />
                                    <AgGridPagination
                                        currentPage={currentPage}
                                        totalPages={totalPages}
                                        onPageChange={(_, page) => setCurrentPage(page)}
                                    />
                                </Box>
                            </>
                        )}
                    </Box>

                    <CustomDialog
                        open={auditDialogOpen}
                        onClose={() => setAuditDialogOpen(false)}
                        title="User Audit Logs"
                        maxWidth="md"
                    >
                        <Box my={2}>
                            <Grid container alignItems="center" justifyContent="flex-start" spacing={3}>
                                <Grid item lg={6} md={6} sm={12} xs={12}>
                                    <Box className="fx_fs gap1">
                                        <LuUser style={{ fontSize: "20px", color: "var(--primary)" }} />
                                        <Box>
                                            {auditUser && (
                                                <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                                                    {auditUser.userName}
                                                </Typography>
                                            )}
                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>

                        <Box
                            sx={{
                                height: 250,
                                overflow: "auto",
                                overflowY: "auto",
                                backgroundColor: "#f5f5f5",
                                padding: "16px",
                                borderRadius: "6px",
                            }}
                        >
                            {filteredAuditLogs.map((log, idx) => (
                                <Typography key={idx} variant="body2" sx={{ mb: 0.5, color: "text.secondary" }}>
                                    {log}
                                </Typography>
                            ))}
                            {filteredAuditLogs.length === 0 && (
                                <Typography variant="body2" color="text.secondary">
                                    No logs match your search.
                                </Typography>
                            )}
                        </Box>
                    </CustomDialog>

                    {/* Side Drawer for Clone Naming Convention */}
                    <SideDrawer open={drawerOpen} onClose={handleCloseDrawer}>
                        <Box className="right-drawer-header fx_fs gap1">
                            <MdContentCopy style={{ fontSize: "20px", color: "var(--primary)" }} />
                            <Typography variant="h5" className="primary fw6">
                                Clone Naming Convention
                            </Typography>
                        </Box>
                        <Box className="right-drawer-content">
                            <CloneNamingConventionForm />
                        </Box>
                        <Box className="right-drawer-footer fx_fe gap1">
                            <Button variant="contained" className="primary-outlined-btn" onClick={handleCloseDrawer}>
                                Cancel
                            </Button>
                            <Button variant="contained" className="primary-btn" autoFocus onClick={handleCloseDrawer}>
                                Clone
                            </Button>
                        </Box>
                    </SideDrawer>
                </>
            </Container>
        </MainLayout>
    );
};

export default NamingConventionPage;
