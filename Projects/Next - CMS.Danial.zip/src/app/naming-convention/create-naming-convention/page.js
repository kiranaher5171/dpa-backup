"use client";

import React, { useState } from 'react';
import MainLayout from '@/Layouts/MainLayout';
import { Container, Box, Grid, Breadcrumbs, Typography, Divider, Button, Stack } from '@mui/material';
import Link from 'next/link';
import SingleSelectAutocomplete from '@/components/FormInputComponents/SingleSelectAutocomplete';
import SimpleTextField from '@/components/FormInputComponents/SimpleTextField';
import { FiPlus } from "react-icons/fi";
import { FaEye } from "react-icons/fa";
import { FiFileText } from "react-icons/fi";
import { FiTrash2 } from "react-icons/fi";
import { FiList } from "react-icons/fi";

const page = () => {
    // Options for dropdowns
    const Options = [
        { label: "Option 1", value: "option1" },
        { label: "Option 2", value: "option2" },
        { label: "Option 3", value: "option3" }
    ];

    // State for pattern rows
    const [patternRows, setPatternRows] = useState([
        { id: 1, patternType: null, characterLimit: "3", patternValue: "" },
        { id: 2, patternType: null, characterLimit: "3", patternValue: "" },
        { id: 3, patternType: "Auto Progressive", characterLimit: "3", patternValue: "001", isReadOnly: true },
        { id: 4, patternType: "Version", characterLimit: "3", patternValue: "V.0", isReadOnly: true }
    ]);

    const handleAddPatternRow = () => {
        const newRow = {
            id: patternRows.length + 1,
            patternType: null,
            characterLimit: "",
            patternValue: ""
        };
        setPatternRows([...patternRows, newRow]);
    };

    // State for field rows (between dividers)
    const [fieldRows, setFieldRows] = useState([]);

    const handleAddFieldRow = () => {
        const newRow = {
            id: fieldRows.length + 1,
            patternType: null,
            characterLimit: "",
            patternValue: ""
        };
        setFieldRows([...fieldRows, newRow]);
    };

    const handleFieldChange = (id, field, value) => {
        setFieldRows(fieldRows.map(row =>
            row.id === id ? { ...row, [field]: value } : row
        ));
    };

    const handleRemoveFieldRow = (id) => {
        setFieldRows(fieldRows.filter(row => row.id !== id));
    };

    return (
        <MainLayout>
            <Container maxWidth sx={{ py: 2 }}>
                <Box   mb={2}>
                    <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className="fx_sb w100">
                                <Box className="fx_fs gap1">
                                    <Box className="heading-decorator" />
                                    <Breadcrumbs aria-label="breadcrumb">
                                        <Link href="/naming-convention">
                                            <Typography variant="h5" className="primary fw6">
                                                Naming Convention
                                            </Typography>
                                        </Link>
                                        <Typography variant="h5" className="primary fw6">Create Naming Convention</Typography>
                                    </Breadcrumbs>
                                </Box>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>

                {/* Naming Convention Section */}
                <Box className="table-box" mb={2}>
                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={3}>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className="fx_fs gap1" mb={2}>
                                <FiFileText size={22} style={{ color: "var(--primary)" }} />
                                <Typography variant="h5" className="primary fw6">
                                    Naming Convention
                                </Typography>
                            </Box>
                        </Grid>
                    </Grid>
                    <Divider /> 

                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={2} sx={{ mt: 2 }}>
                    <Grid item lg={3} md={6} sm={6} xs={12}>
                            <SingleSelectAutocomplete
                                label="Project"
                                placeholder="Select Project"
                                fullWidth
                                required
                                options={Options}
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SingleSelectAutocomplete
                                label="Module"
                                placeholder="Select Module"
                                fullWidth
                                required
                                options={Options}
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SingleSelectAutocomplete
                                label="Record Category"
                                placeholder="Select Record Category"
                                fullWidth
                                required
                                options={Options}
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SingleSelectAutocomplete
                                label="Contract Object"
                                placeholder="Select Contract Object"
                                fullWidth
                                required
                                options={Options}
                            />
                        </Grid>
                    </Grid>

                </Box>

                {/* Field Configuration Section */}
                <Box className="table-box" mb={2}>
                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={3}>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                        <Box className="fx_fs gap1" mb={2}>
                                <FiList size={22} style={{ color: "var(--primary)" }} />
                                <Typography variant="h5" className="primary fw6">
                                    Field Configuration
                                </Typography>
                            </Box>
                        </Grid>
                    </Grid>
                    <Divider />

                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={2} sx={{ mt: 2 }}>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SingleSelectAutocomplete
                                label="Pattern Type"
                                placeholder="Select Pattern Type"
                                fullWidth
                                required
                                options={Options}
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SimpleTextField
                                label="Character Limit"
                                placeholder="Character Limit"
                                fullWidth
                                required
                                type="number"
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SimpleTextField label="Pattern Value" fullWidth required />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <Box>
                                <Button
                                    variant="outlined"
                                    className="primary-outlined-btn mobile-ico-btn"
                                    size="small"
                                    startIcon={<FiPlus />}
                                    onClick={handleAddFieldRow}
                                >
                                    <span className="mobile-ico-btn-text"> Add Field</span>
                                </Button>
                            </Box>
                        </Grid>
                    </Grid>


                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={2} sx={{ mt: 2 }}>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SingleSelectAutocomplete
                                label="Pattern Type"
                                placeholder="Select Pattern Type"
                                fullWidth
                                required
                                options={Options}
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SimpleTextField
                                label="Character Limit"
                                placeholder="Character Limit"
                                fullWidth
                                required
                                type="number"
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SimpleTextField label="Pattern Value" fullWidth required />
                        </Grid>
                    </Grid>


                    {/* Dynamic Field Rows - Added when clicking Add Field button */}
                    {fieldRows.map((row) => (
                        <Grid
                            container
                            alignItems="flex-start"
                            justifyContent='flex-start'
                            spacing={2}
                            key={row.id}
                            mt={2}
                        >
                            <Grid item lg={3} md={4} sm={6} xs={12}>
                                <SingleSelectAutocomplete
                                    label="Pattern Type"
                                    placeholder="Select Pattern Type"
                                    fullWidth
                                    required
                                    options={Options}
                                    value={row.patternType}
                                    onChange={(value) => handleFieldChange(row.id, 'patternType', value)}
                                />
                            </Grid>
                            <Grid item lg={3} md={4} sm={6} xs={12}>
                                <SimpleTextField
                                    label="Character Limit"
                                    placeholder="Character Limit"
                                    fullWidth
                                    required
                                    type="number"
                                    value={row.characterLimit}
                                    onChange={(e) => handleFieldChange(row.id, 'characterLimit', e.target.value)}
                                />
                            </Grid>
                            <Grid item lg={3} md={4} sm={6} xs={12}>
                                <SimpleTextField
                                    label="Pattern Value"
                                    fullWidth
                                    required
                                    value={row.patternValue}
                                    onChange={(e) => handleFieldChange(row.id, 'patternValue', e.target.value)}
                                />
                            </Grid>
                             <Grid item lg={3} md={4} sm={6} xs={12}>
                                 <Box sx={{ display: 'flex', alignItems: 'center', height: '100%' }}>
                                     <Button
                                         variant="outlined"
                                         className="primary-outlined-btn mobile-ico-btn"
                                         size="small"
                                         startIcon={<FiTrash2 />}
                                         onClick={() => handleRemoveFieldRow(row.id)}
                                     >
                                         <span className="mobile-ico-btn-text"> Remove</span>
                                     </Button>
                                 </Box>
                             </Grid>
                        </Grid>
                    ))}

                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={2} mt={4}>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                        <SimpleTextField label="Pattern Value" fullWidth value="Auto Progressive" />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SimpleTextField
                                label="Character Limit"
                                placeholder="Character Limit"
                                fullWidth
                                required
                                type="number"
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SimpleTextField label="Pattern Value" fullWidth />
                        </Grid>
                    </Grid>

                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={2} sx={{ mt: 2 }}>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                        <SimpleTextField label="Pattern Value" fullWidth value="Version" />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SingleSelectAutocomplete
                                label="Module"
                                placeholder="Select Module"
                                fullWidth
                                options={Options}
                            />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <SimpleTextField label="Pattern Value" fullWidth value="V.0" />
                        </Grid>
                    </Grid>

                    <Grid container alignItems="flex-start" justifyContent='flex-start' spacing={2} mt={4}>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <SimpleTextField label="Reference ID Format" fullWidth required />
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <Box>
                                <Button
                                    variant="outlined"
                                    className="primary-outlined-btn mobile-ico-btn"
                                    size="small"
                                    startIcon={<FaEye />}
                                    onClick={handleAddFieldRow}
                                >
                                    <span className="mobile-ico-btn-text"> Show Preview
                                    </span>
                                </Button>
                            </Box>
                        </Grid>

                    </Grid>

                </Box>

                {/* Footer Actions */}
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mt: 2 }}>
                    <Link href="/naming-convention">
                        <Button
                            variant="outlined"
                            className="primary-outlined-btn"
                            size="medium"
                        >
                            Cancel
                        </Button>
                    </Link>
                    <Button
                        variant="contained"
                        className="primary-btn"
                        size="medium"
                    >
                        Save
                    </Button>
                </Box>
            </Container>
        </MainLayout>
    )
}

export default page