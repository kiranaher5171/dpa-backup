import React from 'react'
import { Box, Grid } from '@mui/material'
import SingleSelectAutocomplete from '@/components/FormInputComponents/SingleSelectAutocomplete'

const CloneNamingConventionForm = () => {
    return (
        <>
            <Grid container alignItems="flex-start" justifyContent='center' spacing={3}>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete 
                            label="Project" 
                            fullWidth 
                            required 
                            placeholder="Select Project"
                            options={[]}
                        />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete 
                            label="Record Category" 
                            fullWidth 
                            required 
                            placeholder="Select Record Category"
                            options={[]}
                        />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete 
                            label="Module" 
                            fullWidth 
                            required 
                            placeholder="Select Module"
                            options={[]}
                        />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete 
                            label="Contract Object" 
                            fullWidth 
                            required 
                            placeholder="Select Contract Object"
                            options={[]}
                        />
                    </Box>
                </Grid>
            </Grid>
        </>
    )
}

export default CloneNamingConventionForm