"use client";
import React, { useState } from 'react';
import { DateRange } from 'react-date-range';
import { Box, TextField, MenuItem, Select, FormControl, IconButton, Typography, Collapse, Button } from '@mui/material';
import { Search as SearchIcon, FilterList as FilterIcon } from '@mui/icons-material';

export default function SmartSearch() {
    const [searchQuery, setSearchQuery] = useState('');
    const [openFilters, setOpenFilters] = useState(false);
    const [dateRange, setDateRange] = useState({
        startDate: new Date(),
        endDate: new Date(),
        key: 'selection'
    });
    const [month, setMonth] = useState(new Date().getMonth());
    const [year, setYear] = useState(new Date().getFullYear());
    const [hour, setHour] = useState(0);
    const [minute, setMinute] = useState(0);
    const [ampm, setAmpm] = useState('AM');

    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];

    const years = Array.from({ length: 10 }, (_, i) => new Date().getFullYear() - 5 + i);
    const hours = Array.from({ length: 12 }, (_, i) => i);
    const minutes = Array.from({ length: 60 }, (_, i) => i);

    const handleDateRangeChange = (ranges) => {
        const selection = ranges.selection;
        setDateRange(selection);

        // Update month and year based on start date
        if (selection.startDate) {
            setMonth(selection.startDate.getMonth());
            setYear(selection.startDate.getFullYear());
        }
    };

    const handleMonthChange = (newMonth) => {
        setMonth(newMonth);
        // Navigate calendar to the selected month
        // Use a temporary date for navigation that doesn't interfere with selection
        const navigateDate = new Date(year, newMonth, 1);
        // Update startDate to navigate calendar (this is how DateRange determines which month to show)
        // The actual selection will be preserved in the ranges prop
        setDateRange(prev => ({
            ...prev,
            startDate: navigateDate
        }));
    };

    const handleYearChange = (newYear) => {
        setYear(newYear);
        // Navigate calendar to the selected year
        const navigateDate = new Date(newYear, month, 1);
        setDateRange(prev => ({
            ...prev,
            startDate: navigateDate
        }));
    };

    return (
        <Box sx={{ width: '100%' }}>
            {/* Smart Search Header */}
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, mb: 2 }}>
                <Typography variant="body1" sx={{ fontWeight: 600, fontSize: '14px' }}>
                    Smart Search
                </Typography>
                <Button
                    variant="outlined"
                    size="small"
                    onClick={() => setOpenFilters(!openFilters)}
                    startIcon={<FilterIcon />}
                    sx={{
                        textTransform: 'none',
                        fontSize: '13px',
                        whiteSpace: 'nowrap',
                        minWidth: 'auto',
                        padding: '6px 12px'
                    }}
                >
                    Advanced Filters
                </Button>
            </Box>

            <Box mb={1}>
                <Box sx={{ position: 'relative', flex: 1 }}>
                    <TextField
                        fullWidth
                        size="small"
                        placeholder="Search..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        sx={{
                            '& .MuiOutlinedInput-root': {
                                fontSize: '13px',
                                '& fieldset': {
                                    borderColor: '#ddd',
                                },
                            },
                        }}
                    />
                    <IconButton
                        sx={{
                            position: 'absolute',
                            right: 0,
                            top: '50%',
                            transform: 'translateY(-50%)',
                            padding: '4px',
                        }}
                    >
                        <SearchIcon sx={{ fontSize: '18px', color: '#666' }} />
                    </IconButton>
                </Box>
            </Box>

            {/* Advanced Filters Collapse */}
            <Collapse in={openFilters}>
                {/* Date and Time Selection Controls */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                    <FormControl size="small" sx={{ minWidth: 100 }} fullWidth>
                        <Select
                            value={month}
                            onChange={(e) => handleMonthChange(e.target.value)}
                            sx={{
                                fontSize: '13px',
                                '& .MuiOutlinedInput-notchedOutline': {
                                    borderColor: '#ddd',
                                },
                            }}
                        >
                            {months.map((monthName, index) => (
                                <MenuItem key={index} value={index} sx={{ fontSize: '13px' }}>
                                    {monthName}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>

                    <FormControl size="small" sx={{ minWidth: 80 }} fullWidth>
                        <Select
                            value={year}
                            onChange={(e) => handleYearChange(e.target.value)}
                            sx={{
                                fontSize: '13px',
                                '& .MuiOutlinedInput-notchedOutline': {
                                    borderColor: '#ddd',
                                },
                            }}
                        >
                            {years.map((yr) => (
                                <MenuItem key={yr} value={yr} sx={{ fontSize: '13px' }}>
                                    {yr}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>

                    <IconButton size="small" sx={{ padding: '4px' }}>
                        <FilterIcon sx={{ fontSize: '20px', color: '#666' }} />
                    </IconButton>
                </Box>

                {/* Calendar */}
                <Box className="center" sx={{
                    '& .rdr-Calendar': {
                        width: '100%',
                    },
                    '& .rdr-Month': {
                        width: '100%',
                    },
                    '& .rdr-Day': {
                        fontSize: '13px',
                    },
                    '& .rdr-WeekDay': {
                        fontSize: '13px',
                        fontWeight: 600,
                    },
                    '& .rdr-DayNumber': {
                        fontSize: '13px',
                    },
                    '& .rdr-DayRangeStart, & .rdr-DayRangeEnd': {
                        backgroundColor: '#1976d2 !important',
                        color: '#fff !important',
                    },
                    '& .rdr-DayInRange': {
                        backgroundColor: '#e3f2fd !important',
                    },
                }}>
                    <DateRange
                        ranges={[dateRange]}
                        onChange={handleDateRangeChange}
                        showMonthAndYearPickers={false}
                        showDateDisplay={false}
                        months={months}
                        weekStartsOn={0}
                        moveRangeOnFirstSelection={false}
                        calendars={1}
                        direction="vertical"
                    />
                </Box>
            </Collapse>
        </Box>
    );
}
