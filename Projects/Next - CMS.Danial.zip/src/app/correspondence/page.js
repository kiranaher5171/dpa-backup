"use client";
import MainLayout from '@/Layouts/MainLayout'
import React, { useState } from 'react'
import MainTable from './MainTable'
import { Box, Button, Container, Grid, Stack, Typography, IconButton, List, ListItem, ListItemAvatar, Avatar, ListItemText, Switch, FormControlLabel, TextField, Select, MenuItem, FormControl, InputLabel } from '@mui/material'
import SmartSearch from './SmartSearch';
import { FaCloudUploadAlt, FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import { MdSettings, MdShare, MdLocationOn } from 'react-icons/md';

import { RiUserShared2Fill } from "react-icons/ri";
import { RiUserReceived2Fill } from "react-icons/ri";
import { MdOutlineDateRange } from "react-icons/md";
import { FaLocationDot } from "react-icons/fa6";

import { MdOutlineSubtitles } from "react-icons/md";
import { MdPerson } from "react-icons/md";

import { IoDocumentText } from "react-icons/io5";
import { MdDragIndicator } from "react-icons/md";
import { FaSearch } from "react-icons/fa";


const page = () => {
    const [activeTab, setActiveTab] = useState('prime')
    const [draggedIndex, setDraggedIndex] = useState(null)
    const [openConfigureColumns, setOpenConfigureColumns] = useState(false)
    const [searchQuery, setSearchQuery] = useState('')
    const [actionSelect, setActionSelect] = useState('')

    const [columns, setColumns] = useState([
        { id: 1, name: 'Correspondence Classification', visible: false },
        { id: 2, name: 'Reference Number', visible: false },
        { id: 3, name: 'Correspondence Date', visible: true },
        { id: 4, name: 'Correspondent', visible: true },
        { id: 5, name: 'Correspondence Subject', visible: true },
        { id: 6, name: 'Correspondence Attachment', visible: true },
        { id: 7, name: 'Response Priority Status', visible: true },
        { id: 8, name: 'Response Status', visible: true },
    ])

    const handleToggle = (id) => {
        setColumns(columns.map(col =>
            col.id === id ? { ...col, visible: !col.visible } : col
        ))
    }

    const handleShowAll = () => {
        setColumns(columns.map(col => ({ ...col, visible: true })))
    }

    const handleDragStart = (index) => {
        setDraggedIndex(index)
    }

    const handleDragOver = (e) => {
        e.preventDefault()
    }

    const handleDrop = (e, dropIndex) => {
        e.preventDefault()
        if (draggedIndex === null || draggedIndex === dropIndex) return

        const newColumns = [...columns]
        const draggedItem = newColumns[draggedIndex]
        newColumns.splice(draggedIndex, 1)
        newColumns.splice(dropIndex, 0, draggedItem)
        setColumns(newColumns)
        setDraggedIndex(null)
    }

    const handleDragEnd = () => {
        setDraggedIndex(null)
    }
    return (
        <>
            <MainLayout>

                <Container maxWidth sx={{ py: 2 }}>


                    <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                        <Grid item lg={9} md={8} sm={7} xs={12}>
                            <Box className="fx_sb w100" mb={1}>
                                <Box className="fx_fs gap1">
                                    <Box className="heading-decorator" />
                                    <Typography variant='h5' className="primary fw6">Correspondence</Typography>
                                </Box>

                                <Box>
                                    <Stack direction='row' spacing={1}>
                                        <Button variant='outlined' size='small'>Incoming</Button>
                                        <Button variant='outlined' size='small'>Create</Button>
                                    </Stack>
                                </Box>
                            </Box>


                            <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                                <Grid item lg={12} md={12} sm={12} xs={12}>
                                    <Box className="two-toned-box">
                                        <Box className="toned-content">
                                            <Box sx={{ display: 'flex', gap: '8px', mb: '1px' }}>
                                                <Box
                                                    onClick={() => setActiveTab('prime')}
                                                    sx={{
                                                        padding: '8px 16px',
                                                        backgroundColor: activeTab === 'prime' ? '#E3F2FD' : '#FFFFFF',
                                                        // borderBottom: activeTab === 'prime' ? '2px solid #1976D2' : 'none',
                                                        cursor: 'pointer',
                                                        fontSize: '13px',
                                                        fontWeight: 600,
                                                        color: '#000000',
                                                        userSelect: 'none',
                                                        transition: 'all 0.2s ease',
                                                        '&:hover': {
                                                            backgroundColor: activeTab === 'prime' ? '#E3F2FD' : '#F5F5F5',
                                                        }
                                                    }}
                                                >
                                                    Prime Contract
                                                </Box>
                                                <Box
                                                    onClick={() => setActiveTab('sub')}
                                                    sx={{
                                                        padding: '8px 16px',
                                                        backgroundColor: activeTab === 'sub' ? '#e1eaf9' : '#FFFFFF',
                                                        // borderBottom: activeTab === 'sub' ? '2px solid #1976D2' : 'none',
                                                        cursor: 'pointer',
                                                        fontSize: '13px',
                                                        fontWeight: 600,
                                                        color: '#000000',
                                                        userSelect: 'none',
                                                        transition: 'all 0.2s ease',
                                                        '&:hover': {
                                                            backgroundColor: activeTab === 'sub' ? '#e1eaf9' : '#F5F5F5',
                                                        }
                                                    }}
                                                >
                                                    Sub Contract
                                                </Box>
                                                <Box
                                                    onClick={() => setActiveTab('internal')}
                                                    sx={{
                                                        padding: '8px 16px',
                                                        backgroundColor: activeTab === 'internal' ? '#e1eaf9' : '#FFFFFF',
                                                        // borderBottom: activeTab === 'internal' ? '2px solid #1976D2' : 'none',
                                                        cursor: 'pointer',
                                                        fontSize: '13px',
                                                        fontWeight: 600,
                                                        color: '#000000',
                                                        userSelect: 'none',
                                                        transition: 'all 0.2s ease',
                                                        '&:hover': {
                                                            backgroundColor: activeTab === 'internal' ? '#e1eaf9' : '#F5F5F5',
                                                        }
                                                    }}
                                                >
                                                    Internal
                                                </Box>
                                            </Box>
                                        </Box>
                                    </Box>
                                </Grid>
                                <Grid item lg={4} md={4} sm={12} xs={12}>
                                    <Box className="two-toned-box">
                                        <Box className="toned-content">


                                            <Grid container spacing={2}>
                                                <Grid item xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <RiUserShared2Fill style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                From
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                Name of Entity that sends the correspondence
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <RiUserReceived2Fill style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                To
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                Name of Entity that recieves the correspondence
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>

                                                <Grid item xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <MdOutlineDateRange style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Date
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                06/18/2018
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>
                                            </Grid>


                                        </Box>
                                    </Box>
                                </Grid>
                                <Grid item lg={8} md={8} sm={12} xs={12}>
                                    <Box className="two-toned-box">
                                        <Box className="toned-content">


                                            <Grid container spacing={2}>
                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <MdOutlineSubtitles style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Project Name
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                Name of Project
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>


                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <MdPerson style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Project Owner
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                Name of Project Owner
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>


                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <MdPerson style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Owner's Representative
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                Name Here
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>

                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <IoDocumentText style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Contract No.
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                CN12345
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>


                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <MdOutlineDateRange style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Contract Date
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                08th Jul, 2023
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>



                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <IoDocumentText style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Contract Type
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                Design - Build
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>


                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <MdOutlineDateRange style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Notice to Proceed
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                12 Sep, 2023
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>


                                                <Grid item lg={4} md={6} sm={12} xs={12}>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 35, height: 35, bgcolor: '#ffffff', color: '#172238', borderRadius: '0px' }}>
                                                            <FaLocationDot style={{ fontSize: '15px' }} />
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                                                                Project Location
                                                            </Typography>
                                                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                                                                1234 Bluedrive, Miami FL, 57780
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Grid>
                                            </Grid>


                                        </Box>
                                    </Box>
                                </Grid>
                            </Grid>

                            <Box className="white-box box-brd" mt={3}>
                                {/* Simple Search Field and action select*/}
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                                    <Box sx={{ position: 'relative', flex: 1 }}>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            placeholder="Search..."
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            sx={{
                                                '& .MuiOutlinedInput-root': {
                                                    fontSize: '13px',
                                                    '& fieldset': {
                                                        borderColor: '#ddd',
                                                    },
                                                },
                                            }}
                                        />
                                        <IconButton
                                            sx={{
                                                position: 'absolute',
                                                right: 0,
                                                top: '50%',
                                                transform: 'translateY(-50%)',
                                                padding: '4px',
                                            }}
                                        >
                                            <FaSearch sx={{ fontSize: '16px', color: '#666' }} />
                                        </IconButton>
                                    </Box>
                                    <FormControl size="small" sx={{ minWidth: 150 }}>
                                        <InputLabel sx={{ fontSize: '13px' }}>Action</InputLabel>
                                        <Select
                                            value={actionSelect}
                                            onChange={(e) => setActionSelect(e.target.value)}
                                            label="Action"
                                            sx={{
                                                fontSize: '13px',
                                                '& .MuiOutlinedInput-notchedOutline': {
                                                    borderColor: '#ddd',
                                                },
                                            }}
                                        >
                                            <MenuItem value="" sx={{ fontSize: '13px' }}>
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="view" sx={{ fontSize: '13px' }}>View</MenuItem>
                                            <MenuItem value="edit" sx={{ fontSize: '13px' }}>Edit</MenuItem>
                                            <MenuItem value="delete" sx={{ fontSize: '13px' }}>Delete</MenuItem>
                                            <MenuItem value="export" sx={{ fontSize: '13px' }}>Export</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Box>
                                <MainTable />
                            </Box>

                        </Grid>



                        <Grid item lg={3} md={4} sm={5} xs={12}>
                            <Box sx={{ height: 'calc(100vh - 100px)', overflow: 'auto' }}>

                                <Box className="white-box box-brd">
                                    <SmartSearch />
                                </Box>

                                <Box className="white-box1 box-brd0" sx={{ mt: 1 }}>
                                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
                                        {/* Left Arrow */}
                                        {/* <IconButton
                                        size="small"
                                        sx={{
                                            color: '#666',
                                            padding: '4px',
                                            '&:hover': {
                                                backgroundColor: '#f5f5f5'
                                            }
                                        }}
                                    >
                                        <FaChevronLeft style={{ fontSize: '16px' }} />
                                    </IconButton> */}

                                        {/* Cards Container */}
                                        <Box sx={{ display: 'flex', gap: 2, flex: 1 }}>
                                            {/* Open Correspondence Card */}
                                            <Box
                                                sx={{
                                                    flex: 1,
                                                    backgroundColor: '#ffffff',
                                                    borderRadius: '8px',
                                                    overflow: 'hidden',
                                                    boxShadow: '0px 2px 4px rgba(0,0,0,0.1)',
                                                    border: '1px solid #e0e0e0'
                                                }}
                                            >
                                                <Box
                                                    sx={{
                                                        backgroundColor: '#FF9800',
                                                        padding: '8px 12px',
                                                        color: '#ffffff',
                                                        fontSize: '13px',
                                                        fontWeight: 600,
                                                        // minHeight: '60px'
                                                    }}
                                                >
                                                    Open Correspondence
                                                </Box>
                                                <Box sx={{ padding: '20px 12px' }}>
                                                    <Typography
                                                        variant="h4"
                                                        sx={{
                                                            fontSize: '36px',
                                                            fontWeight: 700,
                                                            color: '#000',
                                                            mb: 1
                                                        }}
                                                    >
                                                        18
                                                    </Typography>
                                                    <Typography
                                                        variant="body2"
                                                        sx={{
                                                            color: '#666',
                                                            fontSize: '13px'
                                                        }}
                                                    >
                                                        Agreements for your review
                                                    </Typography>
                                                </Box>
                                            </Box>

                                            {/* To Do Card */}
                                            <Box
                                                sx={{
                                                    flex: 1,
                                                    backgroundColor: '#ffffff',
                                                    borderRadius: '8px',
                                                    overflow: 'hidden',
                                                    boxShadow: '0px 2px 4px rgba(0,0,0,0.1)',
                                                    border: '1px solid #e0e0e0'
                                                }}
                                            >
                                                <Box
                                                    sx={{
                                                        backgroundColor: '#F44336',
                                                        padding: '8px 12px',
                                                        color: '#ffffff',
                                                        fontSize: '13px',
                                                        fontWeight: 600,
                                                        // minHeight: '60px'
                                                    }}
                                                >
                                                    To Do
                                                </Box>
                                                <Box sx={{ padding: '20px 12px' }}>
                                                    <Typography
                                                        variant="h4"
                                                        sx={{
                                                            fontSize: '36px',
                                                            fontWeight: 700,
                                                            color: '#000',
                                                            mb: 1
                                                        }}
                                                    >
                                                        26
                                                    </Typography>
                                                    <Typography
                                                        variant="body2"
                                                        sx={{
                                                            color: '#666',
                                                            fontSize: '13px'
                                                        }}
                                                    >
                                                        Will expire in next 30 days
                                                    </Typography>
                                                </Box>
                                            </Box>
                                        </Box>

                                        {/* Right Arrow */}
                                        {/* <IconButton
                                        size="small"
                                        sx={{
                                            color: '#666',
                                            padding: '4px',
                                            '&:hover': {
                                                backgroundColor: '#f5f5f5'
                                            }
                                        }}
                                    >
                                        <FaChevronRight style={{ fontSize: '16px' }} />
                                    </IconButton> */}
                                    </Box>
                                </Box>


                                <Box className="white-box box-brd" sx={{ mt: 2 }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                                        <Typography variant="body2" sx={{ fontWeight: 600, color: '#000', fontSize: '14px' }}>
                                            Configure Columns
                                        </Typography>
                                        <Button
                                            variant="text"
                                            size="small"
                                            onClick={handleShowAll}
                                            sx={{
                                                textTransform: 'none',
                                                fontSize: '13px',
                                                color: '#1976D2',
                                                minWidth: 'auto',
                                                padding: '4px 8px'
                                            }}
                                        >
                                            Show All
                                        </Button>
                                    </Box>

                                    <List sx={{ maxHeight: '350px', overflow: 'auto' }}>
                                        {columns.map((column, index) => (
                                            <ListItem
                                                key={column.id}
                                                draggable
                                                onDragStart={() => handleDragStart(index)}
                                                onDragOver={handleDragOver}
                                                onDrop={(e) => handleDrop(e, index)}
                                                onDragEnd={handleDragEnd}
                                                sx={{
                                                    cursor: 'move',
                                                    border: '1px solid #e0e0e0',
                                                    borderRadius: '4px',
                                                    mb: 1,
                                                    backgroundColor: draggedIndex === index ? '#f5f5f5' : '#fff',
                                                    padding: '8px 12px',
                                                    '&:hover': {
                                                        backgroundColor: '#f9f9f9'
                                                    }
                                                }}
                                            >
                                                <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', gap: 1 }}>
                                                    <Box
                                                        sx={{
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            cursor: 'grab',
                                                            color: '#999',
                                                            '&:active': {
                                                                cursor: 'grabbing'
                                                            }
                                                        }}
                                                    >
                                                        <MdDragIndicator style={{ fontSize: '20px' }} />
                                                    </Box>
                                                    <Box sx={{ flex: 1 }}>
                                                        <Typography variant="body2" sx={{ fontSize: '13px', color: '#000' }}>
                                                            {column.name}
                                                        </Typography>
                                                    </Box>
                                                    <FormControlLabel
                                                        control={
                                                            <Switch
                                                                checked={column.visible}
                                                                onChange={() => handleToggle(column.id)}
                                                                size="small"
                                                                sx={{
                                                                    '& .MuiSwitch-switchBase.Mui-checked': {
                                                                        color: '#1976D2',
                                                                    },
                                                                    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                                                        backgroundColor: '#1976D2',
                                                                    },
                                                                }}
                                                            />
                                                        }
                                                        label=""
                                                        sx={{ margin: 0 }}
                                                    />
                                                </Box>
                                            </ListItem>
                                        ))}
                                    </List>
                                </Box>
                            </Box>


                        </Grid>
                    </Grid>

                </Container>


            </MainLayout>
        </>
    )
}

export default page