import "./root.css";
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import localFont from 'next/font/local';
import ThemeProviderComponent from "@/components/ThemeProviderComponent";
import crypto from 'crypto';


const poppins = localFont({
  src: [
    {
      path: '../../public/fonts/Poppins-Thin.ttf',
      weight: '100',
      style: 'Thin',
    },
    {
      path: '../../public/fonts/Poppins-ExtraLight.ttf',
      weight: '200',
      style: 'ExtraLight',
    },
    {
      path: '../../public/fonts/Poppins-Light.ttf',
      weight: '300',
      style: 'Light',
    },
    {
      path: '../../public/fonts/Poppins-Regular.ttf',
      weight: '400',
      style: 'Regular',
    },
    {
      path: '../../public/fonts/Poppins-Medium.ttf',
      weight: '500',
      style: 'Medium',
    },
    {
      path: '../../public/fonts/Poppins-SemiBold.ttf',
      weight: '600',
      style: 'SemiBold',
    },
    {
      path: '../../public/fonts/Poppins-Bold.ttf',
      weight: '700',
      style: 'Bold',
    },
    {
      path: '../../public/fonts/Poppins-ExtraBold.ttf',
      weight: '800',
      style: 'ExtraBold',
    },
    {
      path: '../../public/fonts/Poppins-Black.ttf',
      weight: '900',
      style: 'Black',
    },
  ],
  variable: "--font-poppins",
});

export const metadata = {
  title: "CMS",
};

export default function RootLayout({ children }) {
  const nonce = crypto.randomBytes(16).toString('base64');

  return (
    <html lang="en" className={`${poppins.variable}`}>
      <body className={poppins.className}>
        <ThemeProviderComponent nonce={nonce}>
          <main>
            {children}
          </main>
        </ThemeProviderComponent>
      </body>
    </html>
  );
}
