"use client";
import React, { useState } from 'react';
import MainLayout from '@/Layouts/MainLayout';
import './design-system.css';
import {
  Box,
  TextField,
  Button,
  IconButton,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  Autocomplete,
  Checkbox,
  Radio,
  RadioGroup,
  FormControlLabel,
  Switch,
  Snackbar,
  Alert,
  InputAdornment,
  Tooltip,
  Avatar,
  Badge,
  CircularProgress,
  LinearProgress,
  Paper,
  Typography,
  Grid,
  Container
} from '@mui/material';
import { IoSearch, IoClose, IoEye, IoEyeOff, IoSend } from "react-icons/io5";
import { IoIosArrowForward } from "react-icons/io";
import { MdOutlineLogin, MdClose, MdCheck, MdRefresh } from "react-icons/md";
import { FiDownload, FiUpload, FiSave, FiEdit, FiTrash2, FiPlus } from "react-icons/fi";
import SearchIcon from '@mui/icons-material/Search';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';

const DesignSystemPage = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [selectValue, setSelectValue] = useState('');
  const [autocompleteValue, setAutocompleteValue] = useState(null);
  const [multipleAutocompleteValue, setMultipleAutocompleteValue] = useState([]);
  const [chips, setChips] = useState(['React', 'Next.js', 'MUI']);
  const [checked, setChecked] = useState(true);
  const [radioValue, setRadioValue] = useState('option1');
  const [switchChecked, setSwitchChecked] = useState(true);
  const [snackbar, setSnackbar] = useState({ open: false, severity: 'success', message: '' });

  const autocompleteOptions = [
    { label: 'Apple', value: 'apple' },
    { label: 'Banana', value: 'banana' },
    { label: 'Cherry', value: 'cherry' },
    { label: 'Date', value: 'date' },
    { label: 'Grape', value: 'grape' },
  ];

  const handleDeleteChip = (chipToDelete) => {
    setChips(chips.filter(chip => chip !== chipToDelete));
  };

  const showSnackbar = (severity, message) => {
    setSnackbar({ open: true, severity, message });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const colors = [
    { name: 'Primary', var: '--primary', value: '#172238' },
    { name: 'Secondary', var: '--secondary', value: '#2b6bbb' },
    { name: 'Tertiary', var: '--tertiary', value: '#abb5be' },
    { name: 'Text', var: '--text', value: '#5b5b5b' },
    { name: 'White', var: '--white', value: '#ffffff' },
    { name: 'Black', var: '--black', value: '#000000' },
    { name: 'Success', var: '--success', value: 'green' },
    { name: 'Error', var: '--error', value: '#f00' },
    { name: 'Warning', var: '--pending', value: '#ffc000' },
    { name: 'Alice Blue', var: '--aliceblue', value: '#eefaff' },
  ];

  return (
        <MainLayout>
      <Container maxWidth>
        <Box sx={{ p: 3 }}>
          {/* Header */}
          <div className="design-system-header">
            <h1>Design System</h1>
            <p>UI components and styles guide using MUI (Material UI)</p>
          </div>

          {/* ==================== COLOR PALETTE ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Color Palette</h2>
            <div className="color-grid">
              {colors.map((color) => (
                <div key={color.var} className="color-card">
                  <div
                    className="color-swatch"
                    style={{
                      backgroundColor: color.value,
                      border: color.value === '#ffffff' ? '1px solid #e6e6e6' : 'none'
                    }}
                  />
                  <div className="color-info">
                    <div className="color-name">{color.name}</div>
                    <div className="color-value">var({color.var})</div>
                    <div className="color-value">{color.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* ==================== TYPOGRAPHY ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Typography</h2>

            <Grid container spacing={3}>
              {/* Font Family */}
              <Grid item xs={12}>
                <Paper sx={{ p: 3 }}>
                  <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 2, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                    Font Family: Poppins
                  </Typography>
                  <Typography variant="body1" sx={{ mb: 1 }}>The quick brown fox jumps over the lazy dog.</Typography>
                  <Typography variant="body1" sx={{ fontStyle: 'italic', color: 'text.secondary' }}>
                    The quick brown fox jumps over the lazy dog. (Italic)
                  </Typography>
                </Paper>
              </Grid>

              {/* Headings */}
              {[
                { tag: 'H1', size: '38px', component: 'h1' },
                { tag: 'H2', size: '32px', component: 'h2' },
                { tag: 'H3', size: '28px', component: 'h3' },
                { tag: 'H4', size: '22px', component: 'h4' },
                { tag: 'H5', size: '16px', component: 'h5' },
                { tag: 'H6', size: '13px', component: 'h6' },
              ].map((heading) => (
                <Grid item xs={12} sm={6} md={4} key={heading.tag}>
                  <Paper sx={{ p: 3, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                    <Typography variant="caption" color="text.secondary" sx={{ mb: 1 }}>
                      {heading.tag} · {heading.size}
                    </Typography>
                    {React.createElement(heading.component, { style: { margin: 0 } }, `Heading ${heading.tag.slice(1)}`)}
                  </Paper>
                </Grid>
              ))}

              {/* Font Weights */}
              <Grid item xs={12}>
                <Paper sx={{ p: 3 }}>
                  <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 2, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                    Font Weights
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    {[100, 200, 300, 400, 500, 600, 700, 800, 900].map((weight) => (
                      <Box key={weight} sx={{ textAlign: 'center', minWidth: 80, p: 2, bgcolor: '#f5f5f5', borderRadius: 2 }}>
                        <Typography sx={{ fontWeight: weight, fontSize: 24, mb: 0.5 }}>Aa</Typography>
                        <Typography variant="caption" color="text.secondary">{weight}</Typography>
                      </Box>
                    ))}
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </section>

          {/* ==================== FORM COMPONENTS ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Form Components</h2>

            <Grid container spacing={3}>
              {/* Text Fields */}
              <Grid item xs={12} md={6} lg={4}>
                <Paper className="component-card">
                  <h5>Text Fields - Variants</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <TextField label="Outlined" variant="outlined" size="small" fullWidth />
                    <TextField label="Filled" variant="filled" size="small" fullWidth />
                    <TextField label="Standard" variant="standard" size="small" fullWidth />
                  </Box>
                </Paper>
              </Grid>

              <Grid item xs={12} md={6} lg={4}>
                <Paper className="component-card">
                  <h5>Text Fields - States</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <TextField label="Default" size="small" fullWidth />
                    <TextField label="Disabled" size="small" disabled fullWidth />
                    <TextField label="Error" size="small" error helperText="Error message" fullWidth />
                  </Box>
                </Paper>
              </Grid>

              <Grid item xs={12} md={6} lg={4}>
                <Paper className="component-card">
                  <h5>Text Fields - With Icons</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <TextField
                      label="Search"
                      size="small"
                      fullWidth
                      InputProps={{
                        startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment>,
                      }}
                    />
                    <TextField
                      label="Password"
                      type={showPassword ? 'text' : 'password'}
                      size="small"
                      fullWidth
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton onClick={() => setShowPassword(!showPassword)} edge="end" size="small">
                              {showPassword ? <IoEyeOff /> : <IoEye />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                    <TextField label="Multiline" multiline rows={2} size="small" fullWidth />
                  </Box>
                </Paper>
              </Grid>

              {/* Select */}
              <Grid item xs={12} md={6} lg={4}>
                <Paper className="component-card">
                  <h5>Select</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <FormControl fullWidth size="small">
                      <InputLabel>Option</InputLabel>
                      <Select value={selectValue} label="Option" onChange={(e) => setSelectValue(e.target.value)}>
                        <MenuItem value=""><em>None</em></MenuItem>
                        <MenuItem value="option1">Option 1</MenuItem>
                        <MenuItem value="option2">Option 2</MenuItem>
                        <MenuItem value="option3">Option 3</MenuItem>
                      </Select>
                    </FormControl>
                    <FormControl fullWidth size="small" disabled>
                      <InputLabel>Disabled</InputLabel>
                      <Select label="Disabled" defaultValue=""><MenuItem value="">Item</MenuItem></Select>
                    </FormControl>
                    <FormControl fullWidth size="small" error>
                      <InputLabel>Error</InputLabel>
                      <Select label="Error" defaultValue=""><MenuItem value="">Item</MenuItem></Select>
                    </FormControl>
                  </Box>
                </Paper>
              </Grid>

              {/* Autocomplete */}
              <Grid item xs={12} md={6} lg={4}>
                <Paper className="component-card">
                  <h5>Autocomplete</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <Autocomplete
                      options={autocompleteOptions}
                      value={autocompleteValue}
                      onChange={(e, newValue) => setAutocompleteValue(newValue)}
                      size="small"
                      renderInput={(params) => <TextField {...params} label="Single Select" />}
                    />
                    <Tooltip
                      title={multipleAutocompleteValue.length > 0 ? multipleAutocompleteValue.map(v => v.label).join(', ') : 'No items selected'}
                      placement="top" arrow
                    >
                      <Autocomplete
                        multiple
                        options={autocompleteOptions}
                        value={multipleAutocompleteValue}
                        onChange={(e, newValue) => setMultipleAutocompleteValue(newValue)}
                        size="small"
                        disableCloseOnSelect
                        renderTags={(value) => value.length > 0 ? (
                          <Typography variant="body2" sx={{ ml: 1 }}>{value.length} selected</Typography>
                        ) : null}
                        renderInput={(params) => (
                          <TextField {...params} label="Multi Select" placeholder={multipleAutocompleteValue.length === 0 ? "Select..." : ""} />
                        )}
                      />
                    </Tooltip>
                  </Box>
                </Paper>
              </Grid>

              {/* Checkbox, Radio, Switch */}
              <Grid item xs={12} md={6} lg={4}>
                <Paper className="component-card">
                  <h5>Checkbox, Radio, Switch</h5>
                  <Grid container spacing={2}>
                    <Grid item xs={4}>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>Checkbox</Typography>
                      <FormControlLabel control={<Checkbox checked={checked} onChange={(e) => setChecked(e.target.checked)} size="small" />} label="On" />
                      <FormControlLabel control={<Checkbox size="small" />} label="Off" />
                    </Grid>
                    <Grid item xs={4}>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>Radio</Typography>
                      <RadioGroup value={radioValue} onChange={(e) => setRadioValue(e.target.value)}>
                        <FormControlLabel value="option1" control={<Radio size="small" />} label="A" />
                        <FormControlLabel value="option2" control={<Radio size="small" />} label="B" />
                      </RadioGroup>
                    </Grid>
                    <Grid item xs={4}>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>Switch</Typography>
                      <FormControlLabel control={<Switch checked={switchChecked} onChange={(e) => setSwitchChecked(e.target.checked)} size="small" />} label="On" />
                      <FormControlLabel control={<Switch size="small" />} label="Off" />
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            </Grid>
          </section>

          {/* ==================== BUTTONS ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Buttons</h2>

            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <div className="ds-subsection">
                  <h3 className="ds-subsection-title">Primary</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Button className="primary-btn">Primary</Button>
                    <Button className="primary-btn" startIcon={<FiSave />}>Save</Button>
                    <Button className="primary-btn" endIcon={<IoIosArrowForward />}>Continue</Button>
                  </Box>
                </div>
              </Grid>

              <Grid item xs={12} md={6}>
                <div className="ds-subsection">
                  <h3 className="ds-subsection-title">Primary Outlined</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Button className="primary-outlined-btn">Outlined</Button>
                    <Button className="primary-outlined-btn" startIcon={<FiEdit />}>Edit</Button>
                    <Button className="primary-outlined-btn" startIcon={<FiDownload />}>Download</Button>
                  </Box>
                </div>
              </Grid>

              <Grid item xs={12} md={6}>
                <div className="ds-subsection">
                  <h3 className="ds-subsection-title">Secondary</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Button className="secondary-btn">Secondary</Button>
                    <Button className="secondary-btn" startIcon={<FiPlus />}>Add New</Button>
                    <Button className="secondary-btn" startIcon={<IoSend />}>Submit</Button>
                  </Box>
                </div>
              </Grid>

              <Grid item xs={12} md={6}>
                <div className="ds-subsection">
                  <h3 className="ds-subsection-title">Secondary Outlined</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Button className="secondary-outlined-btn">Outlined</Button>
                    <Button className="secondary-outlined-btn" startIcon={<MdRefresh />}>Refresh</Button>
                    <Button className="secondary-outlined-btn" startIcon={<FiUpload />}>Upload</Button>
                  </Box>
                </div>
              </Grid>

              <Grid item xs={12} md={6}>
                <div className="ds-subsection">
                  <h3 className="ds-subsection-title">Error / Danger</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Button className="btn-error">Delete</Button>
                    <Button className="btn-error" startIcon={<FiTrash2 />}>Remove</Button>
                    <Button className="btn-outlined-error">Cancel</Button>
                    <Button className="btn-outlined-error" startIcon={<MdClose />}>Discard</Button>
                  </Box>
                </div>
              </Grid>

              <Grid item xs={12} md={6}>
                <div className="ds-subsection" style={{ background: 'var(--primary)' }}>
                  <h3 className="ds-subsection-title" style={{ color: 'rgba(255,255,255,0.7)' }}>White Outlined</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Button className="white-outlined-btn">Outlined</Button>
                    <Button className="white-outlined-btn" startIcon={<MdOutlineLogin />}>Login</Button>
                  </Box>
                </div>
              </Grid>

              <Grid item xs={12} md={6}>
                <div className="ds-subsection">
                  <h3 className="ds-subsection-title">Common Actions</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Button className="primary-btn" startIcon={<MdCheck />}>Confirm</Button>
                    <Button className="btn-outlined-error" startIcon={<MdClose />}>Cancel</Button>
                  </Box>
                </div>
              </Grid>

              <Grid item xs={12} md={6}>
                <div className="ds-subsection">
                  <h3 className="ds-subsection-title">Icon Buttons</h3>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <IconButton className="primary-btn" sx={{ p: 1 }}><FiPlus /></IconButton>
                    <IconButton className="primary-outlined-btn" sx={{ p: 1 }}><FiEdit /></IconButton>
                    <IconButton className="secondary-btn" sx={{ p: 1 }}><IoSearch /></IconButton>
                    <IconButton className="btn-error" sx={{ p: 1 }}><FiTrash2 /></IconButton>
                    <IconButton className="btn-outlined-error" sx={{ p: 1 }}><MdClose /></IconButton>
                  </Box>
                </div>
              </Grid>
            </Grid>
          </section>

          {/* ==================== CHIPS ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Chips</h2>

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>Basic & Status</h5>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                    <Chip label="Default" />
                    <Chip label="Primary" color="primary" />
                    <Chip label="Secondary" color="secondary" />
                    <Chip label="Outlined" variant="outlined" />
                  </Box>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    <Chip label="Success" color="success" size="small" />
                    <Chip label="Error" color="error" size="small" />
                    <Chip label="Warning" color="warning" size="small" />
                    <Chip label="Info" color="info" size="small" />
                  </Box>
                </Paper>
              </Grid>

              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>With Icons & Deletable</h5>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                    <Chip icon={<CheckCircleIcon />} label="Done" color="success" size="small" />
                    <Chip icon={<ErrorIcon />} label="Error" color="error" size="small" />
                    <Chip avatar={<Avatar sx={{ width: 24, height: 24 }}>M</Avatar>} label="Avatar" size="small" />
                  </Box>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {chips.map((chip) => (
                      <Chip key={chip} label={chip} onDelete={() => handleDeleteChip(chip)} color="primary" size="small" />
                    ))}
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </section>

          {/* ==================== FEEDBACK ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Feedback Components</h2>

            <Grid container spacing={3}>
              {/* Alerts */}
              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>Alerts</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    <Alert severity="success" variant="filled">Success alert</Alert>
                    <Alert severity="error" variant="filled">Error alert</Alert>
                    <Alert severity="warning" variant="filled">Warning alert</Alert>
                    <Alert severity="info" variant="filled">Info alert</Alert>
                  </Box>
                </Paper>
              </Grid>

              {/* Snackbar Test */}
              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>Snackbar Test</h5>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
                    <Button size="small" variant="contained" color="success" onClick={() => showSnackbar('success', 'Success!')}>Success</Button>
                    <Button size="small" variant="contained" color="error" onClick={() => showSnackbar('error', 'Error!')}>Error</Button>
                    <Button size="small" variant="contained" color="warning" onClick={() => showSnackbar('warning', 'Warning!')}>Warning</Button>
                    <Button size="small" variant="contained" color="info" onClick={() => showSnackbar('info', 'Info!')}>Info</Button>
                  </Box>
                </Paper>
              </Grid>

              {/* Progress */}
              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>Progress</h5>
                  <Box sx={{ display: 'flex', gap: 3, alignItems: 'center', mb: 2 }}>
                    <CircularProgress size={24} />
                    <CircularProgress size={32} color="secondary" />
                    <CircularProgress size={40} color="success" />
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    <LinearProgress />
                    <LinearProgress color="secondary" />
                    <LinearProgress variant="determinate" value={60} color="success" />
                  </Box>
                </Paper>
              </Grid>

              {/* Tooltips */}
              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>Tooltips</h5>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                    <Tooltip title="Top" placement="top" arrow><Button size="small" variant="outlined">Top</Button></Tooltip>
                    <Tooltip title="Bottom" placement="bottom" arrow><Button size="small" variant="outlined">Bottom</Button></Tooltip>
                    <Tooltip title="Left" placement="left" arrow><Button size="small" variant="outlined">Left</Button></Tooltip>
                    <Tooltip title="Right" placement="right" arrow><Button size="small" variant="outlined">Right</Button></Tooltip>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </section>

          {/* ==================== DATA DISPLAY ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Data Display</h2>

            <Grid container spacing={3}>
              {/* Avatars */}
              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>Avatars</h5>
                  <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                    <Avatar>A</Avatar>
                    <Avatar sx={{ bgcolor: 'primary.main' }}>B</Avatar>
                    <Avatar sx={{ bgcolor: 'secondary.main' }}>C</Avatar>
                    <Avatar sx={{ bgcolor: 'success.main' }}>D</Avatar>
                    <Avatar sx={{ bgcolor: 'error.main' }}>E</Avatar>
                  </Box>
                  <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                    <Avatar sx={{ width: 24, height: 24, fontSize: 12 }}>S</Avatar>
                    <Avatar sx={{ width: 32, height: 32, fontSize: 14 }}>M</Avatar>
                    <Avatar>D</Avatar>
                    <Avatar sx={{ width: 48, height: 48 }}>L</Avatar>
                  </Box>
                </Paper>
              </Grid>

              {/* Badges */}
              <Grid item xs={12} md={6}>
                <Paper className="component-card">
                  <h5>Badges</h5>
                  <Box sx={{ display: 'flex', gap: 4 }}>
                    <Badge badgeContent={4} color="primary"><Avatar>N</Avatar></Badge>
                    <Badge badgeContent={10} color="secondary"><Avatar>N</Avatar></Badge>
                    <Badge badgeContent={99} color="error"><Avatar>N</Avatar></Badge>
                    <Badge variant="dot" color="success"><Avatar>N</Avatar></Badge>
                  </Box>
                </Paper>
              </Grid>

              {/* Shadows */}
              <Grid item xs={12}>
                <Paper className="component-card">
                  <h5>Shadows / Elevation</h5>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                    {[1, 3, 6, 12, 24].map((elevation) => (
                      <Paper key={elevation} elevation={elevation} sx={{ p: 3, minWidth: 100, textAlign: 'center' }}>
                        <Typography variant="caption">Elevation {elevation}</Typography>
                      </Paper>
                    ))}
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </section>

          {/* ==================== UTILITY CLASSES ==================== */}
          <section className="ds-section">
            <h2 className="ds-section-title">Utility Classes</h2>

            <Grid container spacing={3}>
              <Grid item xs={12} md={4}>
                <Paper className="component-card">
                  <h5>Text Colors</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                    <span className="primary">.primary</span>
                    <span className="secondary">.secondary</span>
                    <span className="green">.green</span>
                    <span className="red">.red</span>
                    <span className="yellow">.yellow</span>
                    <span className="gray">.gray</span>
                  </Box>
                </Paper>
              </Grid>

              <Grid item xs={12} md={4}>
                <Paper className="component-card">
                  <h5>Font Weights</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                    <span className="fw3">.fw3 - Light (300)</span>
                    <span className="fw4">.fw4 - Regular (400)</span>
                    <span className="fw5">.fw5 - Medium (500)</span>
                    <span className="fw6">.fw6 - SemiBold (600)</span>
                    <span className="fw7">.fw7 - Bold (700)</span>
                  </Box>
                </Paper>
              </Grid>

              <Grid item xs={12} md={4}>
                <Paper className="component-card">
                  <h5>Button Classes</h5>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                    <code className="code-inline">.primary-btn</code>
                    <code className="code-inline">.primary-outlined-btn</code>
                    <code className="code-inline">.secondary-btn</code>
                    <code className="code-inline">.secondary-outlined-btn</code>
                    <code className="code-inline">.btn-error</code>
                    <code className="code-inline">.btn-outlined-error</code>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </section>

          {/* Snackbar */}
          <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={handleCloseSnackbar} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
            <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} variant="filled">{snackbar.message}</Alert>
          </Snackbar>
        </Box>
      </Container>
        </MainLayout>
  );
};

export default DesignSystemPage;
