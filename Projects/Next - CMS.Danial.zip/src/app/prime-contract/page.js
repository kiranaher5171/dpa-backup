import MainLayout from '@/Layouts/MainLayout'
import React from 'react'

export default function page() {
    return (
        <>
            <MainLayout>

            </MainLayout>
        </>
    )
}
