"use client";
import MainLayout from "@/Layouts/MainLayout";
import React, { useState, useMemo } from "react";
import Link from "next/link";
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  Breadcrumbs,
  Switch,
  TextField,
  InputAdornment,
} from "@mui/material";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";
import { FaSearch } from "react-icons/fa";
import { FiArrowRight } from "react-icons/fi";
import { MdKeyboardArrowRight } from "react-icons/md";

ModuleRegistry.registerModules([AllCommunityModule]);

const CONFIG_RIGHTS = [
  "Confidential Documents",
  "Dashboards",
  "Forms",
  "Libraries",
  "Naming Convention",
  "Projects",
  "Templates",
  "Workflow",
];

const MODULE_PERMISSIONS = [
  { module: "FCN Hub", createEdit: true, participate: true, approve: true, deleteRetrieve: true, view: true, lockTerms: true },
  { module: "Correspondence", createEdit: true, participate: false, approve: false, deleteRetrieve: false, view: true, lockTerms: false },
];

const Page = () => {
  const [configEnabled, setConfigEnabled] = useState(
    CONFIG_RIGHTS.reduce((acc, name) => ({ ...acc, [name]: true }), {})
  );
  const [modulePermissions, setModulePermissions] = useState(MODULE_PERMISSIONS);
  const [moduleSearch, setModuleSearch] = useState("");
  const [showAccessControl, setShowAccessControl] = useState(false);
  const [moduleGridPage, setModuleGridPage] = useState(1);
  const [configGridPage, setConfigGridPage] = useState(1);

  const handleConfigToggle = (name) => {
    setConfigEnabled((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const handleModuleToggle = (rowIndex, key) => {
    setModulePermissions((prev) =>
      prev.map((r, i) => (i === rowIndex ? { ...r, [key]: !r[key] } : r))
    );
  };

  const handleCancel = () => {
    if (typeof window !== "undefined") window.history.back();
  };

  const handleAddProjectSave = () => {
    setShowAccessControl(true);
  };

  const configRowData = useMemo(
    () => CONFIG_RIGHTS.map((name) => ({ name, enabled: configEnabled[name] })),
    [configEnabled]
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  const moduleColDefs = useMemo(
    () => [
      { field: "module", headerName: "Module Name", minWidth: 180 },
      {
        field: "createEdit",
        headerName: "Create/Edit/Update",
        minWidth: 160,
        sortable: false,
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.createEdit}
            onChange={() => handleModuleToggle(params.node.rowIndex, "createEdit")}
            color="primary"
            size="small"
          />
        ),
      },
      {
        field: "participate",
        headerName: "Participate/Comment",
        minWidth: 160,
        sortable: false,
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.participate}
            onChange={() => handleModuleToggle(params.node.rowIndex, "participate")}
            color="primary"
            size="small"
          />
        ),
      },
      {
        field: "approve",
        headerName: "Approve/Submit",
        minWidth: 140,
        sortable: false,
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.approve}
            onChange={() => handleModuleToggle(params.node.rowIndex, "approve")}
            color="primary"
            size="small"
          />
        ),
      },
      {
        field: "deleteRetrieve",
        headerName: "Delete/Retrieve",
        minWidth: 140,
        sortable: false,
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.deleteRetrieve}
            onChange={() => handleModuleToggle(params.node.rowIndex, "deleteRetrieve")}
            color="primary"
            size="small"
          />
        ),
      },
      {
        field: "view",
        headerName: "View",
        minWidth: 100,
        sortable: false,
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.view}
            onChange={() => handleModuleToggle(params.node.rowIndex, "view")}
            color="primary"
            size="small"
          />
        ),
      },
      {
        field: "lockTerms",
        headerName: "Lock Terms",
        minWidth: 120,
        sortable: false,
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.lockTerms}
            onChange={() => handleModuleToggle(params.node.rowIndex, "lockTerms")}
            color="primary"
            size="small"
          />
        ),
      },
    ],
    []
  );

  const configColDefs = useMemo(
    () => [
      { field: "name", headerName: "Configuration Name", minWidth: 240 },
      {
        field: "enabled",
        headerName: "Enable Access",
        minWidth: 140,
        sortable: false,
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.enabled}
            onChange={() => handleConfigToggle(params.data?.name)}
            color="primary"
            size="small"
          />
        ),
      },
    ],
    []
  );

  return (
    <MainLayout>
      <Container maxWidth sx={{ py: 2 }}>
        <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
          <Grid item lg={12} md={12} sm={12} xs={12}>
            {/* Breadcrumb */}
            <Box className="fx_sb w100" mb={2}>
              <Box className="fx_fs gap1">
                <Box className="heading-decorator" />
                <Breadcrumbs aria-label="breadcrumb">
                  <Link href="/admin/users">
                    <Typography variant="h5" className="primary fw6">
                      Users
                    </Typography>
                  </Link>
                  <Typography variant="h5" className="primary fw6">
                    Update User
                  </Typography>
                  <Typography variant="h5" className="primary fw6">
                    Update Role
                  </Typography>
                </Breadcrumbs>
              </Box>
            </Box>

            {/* Add Project form */}
            <Box className="table-box" mb={2}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_fs gap1" mb={2}>
                  <Typography variant="h5" className="primary fw6">
                    Update Role
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SingleSelectAutocomplete
                      label="Project Name"
                      placeholder="Project Name"
                      fullWidth
                      required
                      options={[]}
                    />
                  </Grid>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SingleSelectAutocomplete
                      label="Role"
                      placeholder="Role"
                      fullWidth
                      required
                      options={[]}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 1, mt: 2 }}>
                      <Button variant="outlined" className="primary-outlined-btn" onClick={handleCancel}>
                        Cancel
                      </Button>
                      <Button variant="contained" className="primary-btn" onClick={handleAddProjectSave}>
                        Save
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            {/* Access Control - visible after Add Project Save */}
            {showAccessControl && (
              <>

                <Box className="table-box" mb={2}>
                  <Box sx={{ p: 2 }}>
                    <Box className="fx_fs gap1" mb={2}>
                      <Typography variant="h5" className="primary fw6">
                        Give control of modules
                      </Typography>
                    </Box>
                    <Box className="w100 tenantTableHead" mb={2}>
                      <Grid container spacing={1} alignItems="center" justifyContent="flex-end">
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                          <Box className="textfield-search">
                            <TextField
                              placeholder="Search"
                              size="small"
                              fullWidth
                              value={moduleSearch}
                              onChange={(e) => setModuleSearch(e.target.value)}
                              InputProps={{
                                startAdornment: (
                                  <InputAdornment position="start">
                                    <FaSearch />
                                  </InputAdornment>
                                ),
                              }}
                            />
                          </Box>
                        </Grid>
                        <Grid item>
                          <Button
                            variant="contained"
                            endIcon={<MdKeyboardArrowRight />}
                            className="primary-btn mobile-ico-btn mobile-ml-0"
                            sx={{ flexShrink: 0 }}
                          >
                            <span className="mobile-ico-btn-text">Go</span>
                          </Button>
                        </Grid>
                      </Grid>
                    </Box>
                    <Box sx={{ width: "100%", height: "40vh", position: "relative" }}>
                      <AgGridReact
                        rowData={modulePermissions}
                        columnDefs={moduleColDefs}
                        defaultColDef={defaultColDef}
                        getRowStyle={getRowStyle}
                        headerHeight={40}
                        rowHeight={40}
                        suppressCellFocus={true}
                        pagination={false}
                        animateRows={true}
                      />
                    </Box>
                    <Box id="tb_footer" className="fx_sb" mt={1}>
                      <AgGridInfo
                        currentPage={moduleGridPage}
                        rowsPerPage={10}
                        totalRows={modulePermissions.length}
                      />
                      <AgGridPagination
                        currentPage={moduleGridPage}
                        totalPages={Math.ceil(modulePermissions.length / 10)}
                        onPageChange={(_, page) => setModuleGridPage(page)}
                      />
                    </Box>
                  </Box>
                </Box>

                <Box className="table-box" mb={2}>
                  <Box sx={{ p: 2 }}>
                    <Box className="fx_fs gap1" mb={2}>
                      <Typography variant="h5" className="primary fw6">
                        Create Configuration Rights
                      </Typography>
                    </Box>
                    <Box sx={{ width: "100%", height: "40vh", position: "relative" }}>
                      <AgGridReact
                        rowData={configRowData}
                        columnDefs={configColDefs}
                        defaultColDef={defaultColDef}
                        getRowStyle={getRowStyle}
                        headerHeight={40}
                        rowHeight={40}
                        suppressCellFocus={true}
                        pagination={false}
                        animateRows={true}
                      />
                    </Box>
                    <Box id="tb_footer" className="fx_sb" mt={1}>
                      <AgGridInfo
                        currentPage={configGridPage}
                        rowsPerPage={10}
                        totalRows={configRowData.length}
                      />
                      <AgGridPagination
                        currentPage={configGridPage}
                        totalPages={Math.ceil(configRowData.length / 10)}
                        onPageChange={(_, page) => setConfigGridPage(page)}
                      />
                    </Box>
                  </Box>
                </Box>

                <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 1 }}>
                  <Button variant="outlined" className="primary-outlined-btn" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button variant="contained" className="primary-btn" onClick={handleCancel}>
                    Apply Changes
                  </Button>
                </Box>
              </>
            )}
          </Grid>
        </Grid>
      </Container>
    </MainLayout>
  );
};

export default Page;
