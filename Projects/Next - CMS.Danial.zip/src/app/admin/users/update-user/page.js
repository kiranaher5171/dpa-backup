"use client";
import MainLayout from "@/Layouts/MainLayout";
import React, { useState, useMemo, useRef, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  Breadcrumbs,
  TextField,
  InputAdornment,
  IconButton,
  Tooltip,
} from "@mui/material";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";
import ContactNumberInput from "@/components/FormInputComponents/ContactNumberInput";
import { FaSearch } from "react-icons/fa";
import { FiEdit, FiPlus, FiTrash2, FiCheck, FiX } from "react-icons/fi";

ModuleRegistry.registerModules([AllCommunityModule]);

const PROJECTS_ROW_DATA = [
  { id: 1, projectName: "HHHHFFF", roleName: "Consultant" },
  { id: 2, projectName: "SubcontractTest", roleName: "Auditor/Compliance" },
  { id: 3, projectName: "logotest2", roleName: "Contract Administrator" },
  { id: 4, projectName: "Decimalcheckuuuu", roleName: "Legal (Paralegal)" },
  { id: 5, projectName: "savecheck2", roleName: "Contract Role" },
  { id: 6, projectName: "addresscheck", roleName: "Consultant" },
  { id: 7, projectName: "enterentity", roleName: "Contract Manager" },
  { id: 8, projectName: "Demoq", roleName: "Consultant" },
  { id: 9, projectName: "DNL Test Project", roleName: "Contract Manager" },
];

const Page = () => {
  const router = useRouter();
  const [firstName, setFirstName] = useState("Test");
  const [lastName, setLastName] = useState("Role");
  const [email, setEmail] = useState("testrole@gmail.com");
  const [location, setLocation] = useState({ label: "Angola", value: "Angola" });
  const [stateVal, setStateVal] = useState({ label: "Cuanza", value: "Cuanza" });
  const [city, setCity] = useState({ label: "Quibala", value: "Quibala" });
  const [contactNumber, setContactNumber] = useState("+918123456789");
  const [projectSearch, setProjectSearch] = useState("");
  const [projectsPage, setProjectsPage] = useState(1);
  const [rowData] = useState(PROJECTS_ROW_DATA);
  const [selectedRows, setSelectedRows] = useState([]);
  const gridRef = useRef(null);

  const handleCancel = () => {
    if (typeof window !== "undefined") window.history.back();
  };

  const handleApplyChanges = () => {
    // TODO: submit form
  };

  const handleEditRole = (data) => {
    const projectId = data?.id != null ? data.id : "";
    const query = projectId ? `?projectId=${encodeURIComponent(projectId)}` : "";
    router.push(`/admin/users/update-user/update-role${query}`);
  };

  const handleRemoveProject = () => {
    if (gridRef.current) {
      const selected = gridRef.current.api.getSelectedRows();
      // TODO: remove selected projects
    }
  };

  const handleAddProjects = () => {
    // TODO: open add projects flow
  };

  const onSelectionChanged = useCallback(() => {
    if (gridRef.current) {
      const selected = gridRef.current.api.getSelectedRows();
      setSelectedRows(selected);
    }
  }, []);

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  const columnDefs = useMemo(
    () => [
      {
        headerName: "",
        field: "checkbox",
        width: 50,
        pinned: "left",
        checkboxSelection: true,
        headerCheckboxSelection: true,
        sortable: false,
        filter: false,
        suppressMenu: true,
        lockPosition: true,
      },
      {
        headerName: "Edit Role",
        field: "editRole",
        minWidth: 100,
        maxWidth: 120,
        sortable: false,
        filter: false,
        cellRenderer: (params) => (
          <Tooltip title="Edit Role" arrow>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={() => handleEditRole(params.data)}
              sx={{ color: "#2b6bbb" }}
            >
              <FiEdit size={16} />
            </IconButton>
          </Tooltip>
        ),
      },
      { field: "projectName", headerName: "Project Name", minWidth: 180 },
      { field: "roleName", headerName: "Role Name", minWidth: 180 },
    ],
    []
  );

  return (
    <MainLayout>
      <Container maxWidth sx={{ py: 2 }}>
        <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
          <Grid item lg={12} md={12} sm={12} xs={12}>
            {/* Breadcrumb */}
            <Box className="fx_sb w100" mb={2}>
              <Box className="fx_fs gap1">
                <Box className="heading-decorator" />
                <Breadcrumbs aria-label="breadcrumb">
                  <Link href="/admin/users">
                    <Typography variant="h5" className="primary fw6">
                      Users
                    </Typography>
                  </Link>
                  <Typography variant="h5" className="primary fw6">
                    Update User
                  </Typography>
                </Breadcrumbs>
              </Box>
            </Box>

            {/* Update User form */}
            <Box className="table-box" mb={2}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_fs gap1" mb={2}>
                  <Typography variant="h5" className="primary fw6" mb={1}>
                    Update User
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SimpleTextField label="First Name" fullWidth required value={firstName} onChange={(e) => setFirstName(e.target.value)} />
                  </Grid>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SimpleTextField label="Last Name" fullWidth required value={lastName} onChange={(e) => setLastName(e.target.value)} />
                  </Grid>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SimpleTextField label="Email" fullWidth required value={email} onChange={(e) => setEmail(e.target.value)} />
                  </Grid>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SingleSelectAutocomplete
                      label="Location"
                      placeholder="Location"
                      fullWidth
                      required
                      options={[
                        { label: "Angola", value: "Angola" },
                        { label: "India", value: "India" },
                      ]}
                      value={location}
                      onChange={setLocation}
                    />
                  </Grid>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SingleSelectAutocomplete
                      label="State"
                      placeholder="State"
                      fullWidth
                      options={[{ label: "Cuanza", value: "Cuanza" }]}
                      value={stateVal}
                      onChange={setStateVal}
                    />
                  </Grid>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <SingleSelectAutocomplete
                      label="City"
                      placeholder="City"
                      fullWidth
                      options={[{ label: "Quibala", value: "Quibala" }]}
                      value={city}
                      onChange={setCity}
                    />
                  </Grid>
                  <Grid item lg={4} md={6} sm={12} xs={12}>
                    <ContactNumberInput 
                      fullWidth
                      defaultCountry="IN"
                      value={contactNumber}
                      onChange={setContactNumber}
                      placeholder="Enter phone number"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
                      <Button
                        variant="contained"
                        className="primary-btn mobile-ico-btn"
                        startIcon={<FiCheck />}
                        onClick={handleApplyChanges}
                        sx={{ flexShrink: 0 }}
                      >
                        <span className="mobile-ico-btn-text">Apply Changes</span>
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            {/* Projects Details */}
            <Box className="table-box" mb={2}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_fs gap1" mb={2}>
                  <Typography variant="h5" className="primary fw6">
                    Projects Details
                  </Typography> 
                </Box>
                <Box className="w100 tenantTableHead" mb={2}>
                  <Grid container spacing={1} alignItems="center" justifyContent="flex-end">
                    <Grid item lg={3} md={4} sm={6} xs={12}>
                      <Box className="textfield-search">
                        <TextField
                          placeholder="Search"
                          size="small"
                          fullWidth
                          value={projectSearch}
                          onChange={(e) => setProjectSearch(e.target.value)}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <FaSearch />
                              </InputAdornment>
                            ),
                          }}
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12} sm={12} md="auto" lg="auto" sx={{ minWidth: 0, display: "flex", flexWrap: "wrap", gap: 1, alignItems: "center" }}>
                      {selectedRows.length > 0 && (
                        <Button
                          variant="outlined"
                          className="primary-outlined-btn mobile-ico-btn"
                          startIcon={<FiTrash2 />}
                          onClick={handleRemoveProject}
                          sx={{ flexShrink: 0 }}
                        >
                          <span className="mobile-ico-btn-text">Remove Project</span>
                        </Button>
                      )}
                      <Button
                        variant="contained"
                        className="primary-btn mobile-ico-btn"
                        startIcon={<FiPlus />}
                        onClick={handleAddProjects}
                        sx={{ flexShrink: 0 }}
                      >
                        <span className="mobile-ico-btn-text">Add Projects</span>
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
                <Box sx={{ width: "100%", height: "40vh", position: "relative" }}>
                  <AgGridReact
                    ref={gridRef}
                    rowData={rowData}
                    columnDefs={columnDefs}
                    defaultColDef={defaultColDef}
                    getRowStyle={getRowStyle}
                    headerHeight={40}
                    rowHeight={40}
                    suppressCellFocus={true}
                    pagination={false}
                    animateRows={true}
                    rowSelection="multiple"
                    onSelectionChanged={onSelectionChanged}
                  />
                </Box>
                <Box id="tb_footer" className="fx_sb" mt={1}>
                  <AgGridInfo
                    currentPage={projectsPage}
                    rowsPerPage={10}
                    totalRows={rowData.length}
                  />
                  <AgGridPagination
                    currentPage={projectsPage}
                    totalPages={Math.ceil(rowData.length / 10)}
                    onPageChange={(_, page) => setProjectsPage(page)}
                  />
                </Box>
              </Box>
            </Box>

            <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 1 }}>
              <Button
                variant="outlined"
                className="primary-outlined-btn mobile-ico-btn"
                startIcon={<FiX />}
                onClick={handleCancel}
                sx={{ flexShrink: 0 }}
              >
                <span className="mobile-ico-btn-text">Cancel</span>
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </MainLayout>
  );
};

export default Page;
