"use client";
import MainLayout from '@/Layouts/MainLayout'
import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import MainTable from './MainTable'
import SideDrawer from '@/components/SideDrawer'
import { Box, Button, Container, Grid, Typography, TextField, MenuItem, InputAdornment, Menu, ListItemIcon } from '@mui/material'
import { FaSearch, FaFileCsv, FaFileExcel, FaFilePdf } from "react-icons/fa";
import { FiDownload, FiSend, FiPlus, FiUser } from "react-icons/fi";
import { LuUserPlus, LuMousePointerClick } from "react-icons/lu";
import SystemUserForm from "./SystemUserForm";
import { GrPowerReset } from "react-icons/gr";
import SingleSelectAutocomplete from '@/components/FormInputComponents/SingleSelectAutocomplete';


const page = () => {
    const router = useRouter()

    // Drawer state
    const [drawerOpen, setDrawerOpen] = useState(false)
    const [editingUser, setEditingUser] = useState(null)

    // Actions menu state
    const [actionAnchorEl, setActionAnchorEl] = useState(null)
    const actionMenuOpen = Boolean(actionAnchorEl)

    // Send Request menu state
    const [sendRequestAnchorEl, setSendRequestAnchorEl] = useState(null)
    const sendRequestMenuOpen = Boolean(sendRequestAnchorEl)

    // Export menu state
    const [exportAnchorEl, setExportAnchorEl] = useState(null)
    const exportMenuOpen = Boolean(exportAnchorEl)

    const handleExportClick = (event) => {
        setExportAnchorEl(event.currentTarget)
    }

    const handleExportClose = () => {
        setExportAnchorEl(null)
    }

    const handleExport = (type) => {
        console.log(`Exporting as ${type}`)
        // Add your export logic here
        handleExportClose()
    }

    const handleActionClick = (event) => {
        setActionAnchorEl(event.currentTarget)
    }

    const handleActionClose = () => {
        setActionAnchorEl(null)
    }

    const handleSendRequestClick = (event) => {
        setSendRequestAnchorEl(event.currentTarget)
    }

    const handleSendRequestClose = () => {
        setSendRequestAnchorEl(null)
    }

    const handleCustomRole = () => {
        router.push('/admin/users/custom-roles')
    }

    const handleResetActions = () => {
        // Add your reset logic here (e.g. clear filters, reset selection)
        console.log('Reset')
    }

    const handleAddUser = () => {
        setEditingUser(null)
        setDrawerOpen(true)
    }

    const handleEditUser = (user) => {
        setEditingUser(user)
        setDrawerOpen(true)
    }

    const handleDrawerClose = () => {
        setDrawerOpen(false)
        setEditingUser(null)
    }

    return (
        <>
            <MainLayout>
                <Container maxWidth sx={{ py: 2 }}>
                    <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Grid container spacing={2} alignItems="center">
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <Box className="fx_fs gap1">
                                        <Box className="heading-decorator" />
                                        <Typography variant='h5' className="primary fw6">Users</Typography>
                                    </Box>
                                </Grid>
                            </Grid>
                            <Grid container spacing={2} alignItems="center">
                                <Grid item lg={12} md={12} sm={12} xs={12} my={2}>
                                    <Box className="table-box">
                                        <Grid container spacing={2} alignItems="center">
                                            <Grid item lg={3} md={3} sm={12} xs={12} m={1}>
                                                <SingleSelectAutocomplete label="Select Tenant" fullWidth required options={[]} />
                                            </Grid>
                                        </Grid>
                                    </Box>
                                </Grid>
                            </Grid>
                            <Grid container spacing={1} alignItems="flex-end" justifyContent="flex-end">
                                <Grid item lg={3} md={6} sm={6} xs={12}>
                                    <Box className="textfield-search">
                                        <TextField
                                            placeholder="Search"
                                            size="small" 
                                            fullWidth={true}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                                            }}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={true} lg={true} sx={{ minWidth: 0, flex: { md: '1 1 auto' } }}>
                                    <Box
                                        className="fx_fe gap1"
                                        sx={{
                                            display: 'flex',
                                            flexWrap: 'wrap',
                                            gap: 1,
                                            justifyContent: { xs: 'flex-start', sm: 'flex-end' },
                                            alignItems: 'center',
                                        }}
                                    >
                                        <Button
                                            className="primary-outlined-btn mobile-ico-btn"
                                            startIcon={<LuMousePointerClick />}
                                            onClick={handleActionClick}
                                            aria-controls={actionMenuOpen ? 'action-menu' : undefined}
                                            aria-haspopup="true"
                                            aria-expanded={actionMenuOpen ? 'true' : undefined}
                                            sx={{ flexShrink: 0 }}
                                        >
                                            <span className="mobile-ico-btn-text">Actions</span>
                                        </Button>
                                        <Menu
                                            id="action-menu"
                                            anchorEl={actionAnchorEl}
                                            open={actionMenuOpen}
                                            onClose={handleActionClose}
                                            MenuListProps={{ 'aria-labelledby': 'action-button' }}
                                            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                            transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                        >
                                            <MenuItem>Delete</MenuItem>
                                            <MenuItem>Deactivate</MenuItem>
                                            <MenuItem>Reactivate</MenuItem>
                                            <MenuItem>Suspend</MenuItem>
                                            <MenuItem>Reset Password</MenuItem>
                                            <MenuItem>Resend Invitation</MenuItem>
                                        </Menu>
                                        <Button
                                            className="primary-outlined-btn mobile-ico-btn"
                                            startIcon={<GrPowerReset />}
                                            onClick={handleResetActions}
                                            sx={{ flexShrink: 0 }}
                                        >
                                            <span className="mobile-ico-btn-text">Reset</span>
                                        </Button>
                                        <Button
                                            className="primary-outlined-btn mobile-ico-btn"
                                            startIcon={<FiUser />}
                                            onClick={handleCustomRole}
                                            sx={{ flexShrink: 0 }}
                                        >
                                            <span className="mobile-ico-btn-text">Custom Roles</span>
                                        </Button>
                                        <Button
                                            className="primary-outlined-btn mobile-ico-btn"
                                            startIcon={<FiSend />}
                                            onClick={handleSendRequestClick}
                                            aria-controls={sendRequestMenuOpen ? 'send-request-menu' : undefined}
                                            aria-haspopup="true"
                                            aria-expanded={sendRequestMenuOpen ? 'true' : undefined}
                                            sx={{ flexShrink: 0 }}
                                        >
                                            <span className="mobile-ico-btn-text">Send Request</span>
                                        </Button>
                                        <Menu
                                            id="send-request-menu"
                                            anchorEl={sendRequestAnchorEl}
                                            open={sendRequestMenuOpen}
                                            onClose={handleSendRequestClose}
                                            MenuListProps={{ 'aria-labelledby': 'send-request-button' }}
                                            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                            transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                        >
                                            <MenuItem>Add User</MenuItem>
                                            <MenuItem>Add Project</MenuItem>
                                            <MenuItem>Remove Project</MenuItem>
                                            <MenuItem>Delete</MenuItem>
                                            <MenuItem>Deactivate</MenuItem>
                                            <MenuItem>Reactivate</MenuItem>
                                            <MenuItem>Suspend</MenuItem>
                                            <MenuItem>Reset Password</MenuItem>
                                            <MenuItem>Resend Invitation</MenuItem>
                                        </Menu>
                                        <Button
                                            className="primary-outlined-btn mobile-ico-btn"
                                            startIcon={<FiDownload />}
                                            onClick={handleExportClick}
                                            aria-controls={exportMenuOpen ? 'export-menu' : undefined}
                                            aria-haspopup="true"
                                            aria-expanded={exportMenuOpen ? 'true' : undefined}
                                            sx={{ flexShrink: 0 }}
                                        >
                                            <span className="mobile-ico-btn-text">Export</span>
                                        </Button>
                                        <Menu
                                            id="export-menu"
                                            anchorEl={exportAnchorEl}
                                            open={exportMenuOpen}
                                            onClose={handleExportClose}
                                            MenuListProps={{
                                                'aria-labelledby': 'export-button',
                                            }}
                                            anchorOrigin={{
                                                vertical: 'bottom',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                        >
                                            <MenuItem onClick={() => handleExport('csv')}>
                                                <ListItemIcon>
                                                    <FaFileCsv style={{ color: '#4CAF50', fontSize: '18px' }} />
                                                </ListItemIcon>
                                                CSV
                                            </MenuItem>
                                            <MenuItem onClick={() => handleExport('excel')}>
                                                <ListItemIcon>
                                                    <FaFileExcel style={{ color: '#217346', fontSize: '18px' }} />
                                                </ListItemIcon>
                                                Excel
                                            </MenuItem>
                                            <MenuItem onClick={() => handleExport('pdf')}>
                                                <ListItemIcon>
                                                    <FaFilePdf style={{ color: '#E53935', fontSize: '18px' }} />
                                                </ListItemIcon>
                                                PDF
                                            </MenuItem>
                                        </Menu>
                                        <Button
                                            variant="contained"
                                            className="primary-btn mobile-ico-btn"
                                            startIcon={<FiPlus />}
                                            onClick={handleAddUser}
                                            sx={{ flexShrink: 0 }}
                                        >
                                            <span className="mobile-ico-btn-text">Add User</span>
                                        </Button>
                                    </Box>
                                </Grid>
                            </Grid>


                        </Grid>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className="table-box">
                                <MainTable onEditUser={handleEditUser} />
                            </Box>
                        </Grid>
                    </Grid>
                </Container>

            </MainLayout>

            <SideDrawer open={drawerOpen} onClose={handleDrawerClose}>
                <Box className="right-drawer-header fx_fs gap1">
                    <LuUserPlus style={{ fontSize: "20px", color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                        {editingUser ? "Edit User" : "Add User"}
                    </Typography>
                </Box>
                <Box className="right-drawer-content">
                    <SystemUserForm />
                </Box>
                <Box className="right-drawer-footer fx_fe gap1">
                    <Button variant="contained" className="primary-outlined-btn" onClick={handleDrawerClose}>
                        Cancel
                    </Button>
                    <Button variant="contained" className="primary-btn" autoFocus onClick={handleDrawerClose}>
                        Save
                    </Button>
                </Box>
            </SideDrawer>
        </>
    )
}

export default page