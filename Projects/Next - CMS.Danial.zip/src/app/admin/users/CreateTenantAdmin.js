import React, { useState } from 'react'
import { Box, Grid } from '@mui/material'
import SimpleTextField from '@/components/FormInputComponents/SimpleTextField'
import SingleSelectAutocomplete from '@/components/FormInputComponents/SingleSelectAutocomplete'
import ContactNumberInput from '@/components/FormInputComponents/ContactNumberInput'
import MultiSelectAutocomplete from '@/components/FormInputComponents/MultiSelectAutocomplete'

const CreateTenantAdmin = () => {
    const [contactNumber, setContactNumber] = useState("");

    return (
        <>
            <Grid container alignItems="flex-start" justifyContent='center' spacing={3}>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SimpleTextField label="First Name" fullWidth required />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SimpleTextField label="Last Name" fullWidth required />
                    </Box>
                </Grid> 
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SimpleTextField label="Email" fullWidth required />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <ContactNumberInput
                            // label="Contact Number"
                            fullWidth
                            required
                            defaultCountry="US"
                            value={contactNumber}
                            onChange={setContactNumber}
                        />
                    </Box>
                </Grid> 
            </Grid>

        </>
    )
}

export default CreateTenantAdmin