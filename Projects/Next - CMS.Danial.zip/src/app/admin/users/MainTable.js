"use client";
import React, { useEffect, useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, IconButton, Tooltip, Button, Typography, Slide, Grid } from "@mui/material";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import { FiEdit, FiTrash2, FiShield, FiX, FiEye, FiPlus, FiPlusCircle } from "react-icons/fi";
import SearchIcon from "@mui/icons-material/Search";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import { LuUser } from "react-icons/lu";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";


ModuleRegistry.registerModules([AllCommunityModule]);

const MainTable = ({ onEditUser }) => {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [selectedRows, setSelectedRows] = useState([]);
  const gridRef = useRef(null);
  const [currentPage, setCurrentPage] = useState(1);

  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditUser, setAuditUser] = useState(null);

  const auditLogs = [
    "Vaibhav Updated Previous_Status From Active To Suspend Pending At 2025-12-22 13:25:08",
    "Vaibhav Updated Status From Suspend Pending To Suspended At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_By From 141 To 453 At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_Date From 12/17/2025 To 12/22/2025 At 2025-12-22 13:25:08",
    "Vaibhav Updated Previous_Status From Reactivation Pending To Active At 2025-12-17 11:21:45",
    "Vaibhav Updated Status From Active To Suspend Pending At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_By From 155 To 141 At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_Date From 10/5/2025 To 12/17/2025 At 2025-12-17 11:21:45",
    "Vaibhav Updated Previous_Status From Deactivated To Reactivation Pending At 2025-10-05 09:28:23",
    "Vaibhav Updated Status From Reactivation Pending To Active At 2025-10-05 09:28:23",
  ];

  const filteredAuditLogs = auditLogs.filter((log) =>
    log.toLowerCase().includes(auditSearch.toLowerCase())
  );

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  // Handle row selection change
  const onSelectionChanged = useCallback(() => {
    if (gridRef.current) {
      const selected = gridRef.current.api.getSelectedRows();
      setSelectedRows(selected);
    }
  }, []);

  // Reset selection (deselect all)
  const handleResetSelection = () => {
    if (gridRef.current) {
      gridRef.current.api.deselectAll();
      setSelectedRows([]);
    }
  };

  // Delete selected rows
  const handleDeleteSelected = () => {
    console.log("Delete selected rows:", selectedRows);
    // Add your delete logic here
    // After deletion, reset selection
    handleResetSelection();
  };

  const [rowData] = useState([
    {
      id: 1,
      userName: "Test Role",
      accessControl: "",
      project: "SubcontractTest, Decimalcheckuuuu, DNL Test Project",
      email: "testrole@gmail.com",
      assignedRole: "Auditor/Compliance, Legal (Paralegal), Contract Manager",
      status: "Awaiting Activation",
      lastLoggedIn: "09 Dec 25 At 07:29AM",
      auditLog: "View Logs",
    },
    {
      id: 2,
      userName: "Test Access",
      accessControl: "",
      project: "HHHHFFF, Subcontract Test, addresscheck, enterentity",
      email: "testaccess@gmail.com",
      assignedRole: "Consultant",
      status: "Invitation Sent",
      lastLoggedIn: "13 Oct 25 At 08:56PM",
      auditLog: "View Logs",
    },
    {
      id: 3,
      userName: "Abhi Ram",
      accessControl: "",
      project: "logotest",
      email: "abhi.ram@gmail.com",
      assignedRole: "Risk Manager",
      status: "Active",
      lastLoggedIn: "14 Sep 25 At 11:42AM",
      auditLog: "View Logs",
    },
    {
      id: 4,
      userName: "Anji Medam",
      accessControl: "",
      project: "Sunrise Villas",
      email: "anji.user@gmail.com",
      assignedRole: "Subcontractor General User",
      status: "Active",
      lastLoggedIn: "23 Dec 25 At 08:08AM",
      auditLog: "View Logs",
    },
    {
      id: 5,
      userName: "Vrund Googleuser",
      accessControl: "",
      project: "Demo",
      email: "vrund.googleuserrrrrrrrrrrrrrrrm@gmail.com",
      assignedRole: "Subcontractor Billing",
      status: "Active",
      lastLoggedIn: "30 Jan 26 At 09:38AM",
      auditLog: "View Logs",
    },
    {
      id: 6,
      userName: "Googleuser user",
      accessControl: "",
      project: "Samsung2.2",
      email: "googleuser1@gmail.com",
      assignedRole: "Director",
      status: "Active",
      lastLoggedIn: "12 Jul 25 At 11:31AM",
      auditLog: "View Logs",
    },
    {
      id: 7,
      userName: "Normal User",
      accessControl: "",
      project: "Check admin approval",
      email: "new.userone@gmail.com",
      assignedRole: "Legal (Paralegal)",
      status: "Invitation Sent",
      lastLoggedIn: "-",
      auditLog: "View Logs",
    },
    {
      id: 8,
      userName: "Mukesh Bhatt",
      accessControl: "",
      project: "Sunrise Villas, Alice Wonderland",
      email: "mukeshB@gmail.com",
      assignedRole: "Document Controller, Consultant",
      status: "Active",
      lastLoggedIn: "23 Dec 25 At 08:08AM",
      auditLog: "View Logs",
    },
    {
      id: 9,
      userName: "Legal Reviewer",
      accessControl: "",
      project: "Sunrise Villas, kjadnvckjbsn",
      email: "legalReviewer@gmail.com",
      assignedRole: "Document Controller, Executive",
      status: "Deactivated",
      lastLoggedIn: "-",
      auditLog: "View Logs",
    },
    {
      id: 10,
      userName: "Draft Out",
      accessControl: "",
      project: "Demo",
      email: "draftOut@gmail.com",
      assignedRole: "Consultant",
      status: "Awaiting Activation",
      lastLoggedIn: "-",
      auditLog: "View Logs",
    },
    {
      id: 11,
      userName: "Suman Adak",
      accessControl: "",
      project: "Sunrise Villas",
      email: "suman@gmail.com",
      assignedRole: "Risk Manager",
      status: "Active",
      lastLoggedIn: "09 Dec 25 At 07:29AM",
      auditLog: "View Logs",
    },
    {
      id: 12,
      userName: "Test Role",
      accessControl: "",
      project: "SubcontractTest, Decimalcheckuuuu, DNL Test Project",
      email: "testrole@gmail.com",
      assignedRole: "Auditor/Compliance, Legal (Paralegal), Contract Manager",
      status: "Invitation Sent",
      lastLoggedIn: "13 Oct 25 At 08:56PM",
      auditLog: "View Logs",
    },
    {
      id: 13,
      userName: "Abhi Ram",
      accessControl: "",
      project: "logotest",
      email: "abhi.ram@gmail.com",
      assignedRole: "Director",
      status: "Deactivated",
      lastLoggedIn: "14 Sep 25 At 11:42AM",
      auditLog: "View Logs",
    },
    {
      id: 14,
      userName: "Anji Medam",
      accessControl: "",
      project: "Sunrise Villas",
      email: "anji.user@gmail.com",
      assignedRole: "Subcontractor General User",
      status: "Active",
      lastLoggedIn: "30 Jan 26 At 09:38AM",
      auditLog: "View Logs",
    },
    {
      id: 15,
      userName: "Vrund Googleuser",
      accessControl: "",
      project: "Demo",
      email: "vrund.googleuserrrrrrrrrrrrrrrrm@gmail.com",
      assignedRole: "Subcontractor Billing",
      status: "Active",
      lastLoggedIn: "12 Jul 25 At 11:31AM",
      auditLog: "View Logs",
    },
    {
      id: 16,
      userName: "Mukesh Bhatt",
      accessControl: "",
      project: "Sunrise Villas, Alice Wonderland",
      email: "mukeshB@gmail.com",
      assignedRole: "Document Controller, Consultant",
      status: "Awaiting Activation",
      lastLoggedIn: "-",
      auditLog: "View Logs",
    },
    {
      id: 17,
      userName: "Legal Reviewer",
      accessControl: "",
      project: "Sunrise Villas, kjadnvckjbsn",
      email: "legalReviewer@gmail.com",
      assignedRole: "Document Controller, Executive",
      status: "Invitation Sent",
      lastLoggedIn: "23 Dec 25 At 08:08AM",
      auditLog: "View Logs",
    },
    {
      id: 18,
      userName: "Suman Adak",
      accessControl: "",
      project: "Sunrise Villas",
      email: "suman@gmail.com",
      assignedRole: "Legal (Paralegal)",
      status: "Deactivated",
      lastLoggedIn: "Never",
      auditLog: "View Logs",
    },
    {
      id: 19,
      userName: "Normal User",
      accessControl: "",
      project: "Check admin approval",
      email: "new.userone@gmail.com",
      assignedRole: "Consultant",
      status: "Active",
      lastLoggedIn: "09 Dec 25 At 07:29AM",
      auditLog: "View Logs",
    },
    {
      id: 20,
      userName: "Draft Out",
      accessControl: "",
      project: "Demo",
      email: "draftOut@gmail.com",
      assignedRole: "Risk Manager",
      status: "Active",
      lastLoggedIn: "30 Jan 26 At 09:38AM",
      auditLog: "View Logs",
    },
  ]);

  const handleEdit = (data) => {
    const userId = data?.id != null ? data.id : "";
    const query = userId ? `?userId=${encodeURIComponent(userId)}` : "";
    router.push(`/admin/users/update-user${query}`);
  };

  const handleDelete = (data) => {
    console.log("Delete user:", data);
  };

  const handleAccessControl = (data) => {
    router.push("/admin/users/access-control-view");
  };

  const [colDefs] = useState([
    {
      headerName: "",
      field: "checkbox",
      width: 50,
      pinned: "left",
      checkboxSelection: true,
      headerCheckboxSelection: true,
      sortable: false,
      filter: false,
      suppressMenu: true,
      lockPosition: true,
    },
    {
      field: "userName",
      headerName: "User Name",
      minWidth: 180,
      cellRenderer: (params) => (
        <span>{params.value}</span>
      ),
    },
    {
      field: "email",
      headerName: "Email",
      minWidth: 200,
      filter: true,
      cellRenderer: (params) => (
        <span style={{ color: "#2b6bbb" }}>{params.value}</span>
      ),
    },
    {
      field: "project",
      headerName: "Project",
      minWidth: 120,
    },
    {
      field: "assignedRole",
      headerName: "Assigned Role",
      minWidth: 150,
    },
    {
      field: "status",
      headerName: "Status",
      minWidth: 160,
      maxWidth: 160,
      headerClass: "table-header-center",
      cellRenderer: (params) => {
        const statusColors = {
          Active: { bg: "#d6ffd6", color: "green" },                 // green-btn
          "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" }, // yellow-btn
          "Invitation Sent": { bg: "#e0f2f7", color: "#01579b" },    // light blue
          Deactivated: { bg: "#f5f5f5", color: "#616161" },          // gray-btn
          Suspended: { bg: "#ffecef", color: "red" },                // red-btn
        };
        const style = statusColors[params.value] || statusColors.Deactivated;
        return (
          <span
            style={{
              backgroundColor: style.bg,
              color: style.color,
              borderRadius: "4px",
              fontSize: "11px",
              fontWeight: 500,
              minWidth: "120px",
              display: "flex",
              height: "25px",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {params.value}
          </span>
        );
      },
    },
    {
      field: "lastLoggedIn",
      headerName: "Last Logged In",
      minWidth: 180,
      cellRenderer: (params) => (
        <span style={{ color: (params.value === "Never" || params.value === "-") ? "#9e9e9e" : "inherit", fontStyle: (params.value === "Never" || params.value === "-") ? "italic" : "normal" }}>
          {params.value}
        </span>
      ),
    },
    {
      headerName: "Actions",
      field: "actions",
      minWidth: 180,
      maxWidth: 180,
      headerClass: "table-header-center",
      pinned: "right",
      sortable: false,
      filter: false,
      lockPosition: true,
      cellRenderer: (params) => {
        return (
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
            <Tooltip title="Edit" arrow>
              <IconButton
                size="small"
                className="ico-btn"
                onClick={() => handleEdit(params.data)}
                sx={{ color: "#2b6bbb" }}
              >
                <FiEdit size={16} />
              </IconButton>
            </Tooltip> 

            <Tooltip title="View Audit Logs" arrow>
              <IconButton
                size="small"
                className="ico-btn"
                onClick={() => {
                  setAuditUser(params.data);
                  setAuditDialogOpen(true);
                }}
                sx={{ color: "#2b6bbb" }}
              >
                <FiEye size={16} />
              </IconButton>
            </Tooltip>

            <Tooltip title="Access Control" arrow>
              <IconButton
                size="small"
                className="ico-btn"
                onClick={() => handleAccessControl(params.data)}
                sx={{ color: "#ff9800" }}
              >
                <FiShield size={16} />
              </IconButton>
            </Tooltip>

            <Tooltip title="Add Project" arrow>
              <IconButton
                size="small"
                onClick={(e) => {
                  e.stopPropagation();
                  router.push("/admin/users/add-project");
                }} 
                sx={{ color: "#2b6bbb" }}
              >
                <FiPlusCircle size={18} />
              </IconButton>
            </Tooltip> 
          </Box>
        );
      },
    },
  ]);

  const defaultColDef = {
    sortable: true,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "66vh", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box sx={{ width: "100%", height: "66vh", position: "relative" }}>
            <AgGridReact
              ref={gridRef}
              rowData={rowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              rowSelection="multiple"
              suppressRowClickSelection={true}
              pagination={false}
              animateRows={true}
              onSelectionChanged={onSelectionChanged}
            />
          </Box>
          <Box id="tb_footer" className="fx_sb" mt={1}>
            <AgGridInfo
              currentPage={currentPage}
              rowsPerPage={10}
              totalRows={rowData.length}
            />
            <AgGridPagination
              currentPage={currentPage}
              totalPages={Math.ceil(rowData.length / 10)}
              onPageChange={(_, page) => setCurrentPage(page)}
            />
          </Box>
        </>
      )}

      <CustomDialog
        open={auditDialogOpen}
        onClose={() => setAuditDialogOpen(false)}
        title="System User Audit Logs"
        maxWidth="md"
      >


        <Box my={2}>
          <Grid container alignItems="center" justifyContent='flex-start' spacing={3}>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box className="fx_fs gap1">

                <LuUser style={{ fontSize: '20px', color: 'var(--primary)' }} />

                <Box>
                  {auditUser && (
                    <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                      {auditUser.userName}
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box>
                <SimpleTextField
                  placeholder="Search Logs"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  fullWidth
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <SearchIcon
                        style={{ fontSize: 18, margin: '0px 12px', marginRight: 0, color: "#757575" }}
                      />
                    ),
                  }}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>



        <Box sx={{ height: 250, overflow: "auto", overflowY: "auto", backgroundColor: "#f5f5f5", padding: "16px", borderRadius: "6px" }}>
          {filteredAuditLogs.map((log, idx) => (
            <Typography
              key={idx}
              variant="body2"
              sx={{ mb: 0.5, color: "text.secondary" }}
            >
              {log}
            </Typography>
          ))}
          {filteredAuditLogs.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              No logs match your search.
            </Typography>
          )}
        </Box>
      </CustomDialog>
    </>
  );
};

export default MainTable;
