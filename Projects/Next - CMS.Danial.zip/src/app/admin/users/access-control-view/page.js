"use client";
import MainLayout from "@/Layouts/MainLayout";
import React, { useState, useMemo } from "react";
import Link from "next/link";
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  Breadcrumbs,
  Switch,
} from "@mui/material";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";

ModuleRegistry.registerModules([AllCommunityModule]);

const CONFIG_RIGHTS = [
  "Confidential Documents",
  "Dashboards",
  "Forms",
  "Libraries",
  "Naming Convention",
  "Projects",
  "Templates",
  "Workflow",
];

const ACCESS_MODULES = ["Correspondence", "Repository", "Subcontract"];

const ACCESS_PERMISSIONS = [
  { field: "createEditUpdate", headerName: "Create/Edit/Update" },
  { field: "participateComment", headerName: "Participate/Comment" },
  { field: "approveSubmit", headerName: "Approve/Submit" },
  { field: "deleteRetrieve", headerName: "Delete/Retrieve" },
  { field: "view", headerName: "View" },
  { field: "signExecute", headerName: "Sign/Execute" },
  { field: "lockTerms", headerName: "Lock Terms" },
  { field: "recoveryOverride", headerName: "Recovery/Override" },
];

const initialAccessControl = () =>
  ACCESS_MODULES.reduce((acc, module) => {
    acc[module] = {
      createEditUpdate: true,
      participateComment: true,
      approveSubmit: true,
      deleteRetrieve: true,
      view: true,
      signExecute: true,
      lockTerms: true,
      recoveryOverride: false,
    };
    return acc;
  }, {});

const PROJECT_OPTIONS = ["Project1", "Project2"];

const Page = () => {
  const [configEnabled, setConfigEnabled] = useState(
    CONFIG_RIGHTS.reduce((acc, name) => ({ ...acc, [name]: true }), {})
  );
  const [accessControl, setAccessControl] = useState(initialAccessControl);
  const [selectedProject, setSelectedProject] = useState("Project1");

  const handleToggle = (name) => {
    setConfigEnabled((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const handleAccessToggle = (module, permission) => {
    setAccessControl((prev) => ({
      ...prev,
      [module]: { ...prev[module], [permission]: !prev[module][permission] },
    }));
  };

  const configRowData = useMemo(
    () => CONFIG_RIGHTS.map((name) => ({ name, enabled: configEnabled[name] })),
    [configEnabled]
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getConfigRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#ffffff" : "#f9f9f9",
  });

  const configColDefs = useMemo(
    () => [
      { field: "name", headerName: "Configuration Name", minWidth: 240, cellStyle: { fontSize: "13px" } },
      {
        field: "enabled",
        headerName: "Enable Access",
        minWidth: 140,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.enabled}
            onChange={() => handleToggle(params.data?.name)}
            color="primary"
            size="small"
          />
        ),
      },
    ],
    []
  );

  const accessControlRowData = useMemo(
    () =>
      ACCESS_MODULES.map((module) => ({
        module,
        ...accessControl[module],
      })),
    [accessControl]
  );

  const accessControlColDefs = useMemo(
    () => [
      {
        field: "module",
        headerName: "Module",
        minWidth: 140,
        cellStyle: { fontSize: "13px" },
      },
      ...ACCESS_PERMISSIONS.map(({ field, headerName }) => ({
        field,
        headerName,
        minWidth: 120,
        sortable: false,
        cellStyle: { fontSize: "13px", display: "flex", alignItems: "center", justifyContent: "center" },
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.[field]}
            onChange={() => handleAccessToggle(params.data?.module, field)}
            color="primary"
            size="small"
          />
        ),
      })),
    ],
    []
  );

  const getAccessControlRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#ffffff" : "#f9f9f9",
  });

  return (
    <MainLayout>
      <Container maxWidth sx={{ py: 2 }}>
        <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="fx_sb w100" mb={2}>
              <Box className="fx_fs gap1">
                <Box className="heading-decorator" />
                <Breadcrumbs aria-label="breadcrumb">
                  <Link href="/admin/users">
                    <Typography variant="h5" className="primary fw6">
                      Users
                    </Typography>
                  </Link>
                  <Typography variant="h5" className="primary fw6">
                    Access Control Edit/View
                  </Typography>
                </Breadcrumbs>
              </Box>
            </Box>

            {/* User Info Panel */}
            <Box className="table-box" mb={2}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_fs gap1" mb={2}> 
                  <Typography variant="h5" className="primary fw6">
                    User Info
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Typography variant="body2" sx={{ color: "#666", fontSize: "11px" }}>
                      Full Name:
                    </Typography>
                    <Typography variant="body2" sx={{ color: "#000", fontSize: "13px", fontWeight: 600 }}>
                      Test Access
                    </Typography>
                  </Grid>
                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Typography variant="body2" sx={{ color: "#666", fontSize: "11px" }}>
                      Status:
                    </Typography>
                    <Box sx={{ mt: 0.5 }}>
                      <span
                        style={{
                          backgroundColor: "#fcf3cc",
                          color: "#D0B404",
                          borderRadius: "4px",
                          fontSize: "11px",
                          fontWeight: 500,
                          padding: "4px 10px",
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        Awaiting Activation
                      </span>
                    </Box>
                  </Grid>
                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <Typography variant="body2" sx={{ color: "#666", fontSize: "11px" }}>
                      Role:
                    </Typography>
                    <Typography variant="body2" sx={{ color: "#000", fontSize: "13px", fontWeight: 600 }}>
                    Document Controller
                    </Typography>
                  </Grid>
                  <Grid item lg={3} md={6} sm={12} xs={12}>
                    <SingleSelectAutocomplete
                      label="Select Project"
                      placeholder="Select Project"
                      fullWidth
                      options={PROJECT_OPTIONS}
                      value={selectedProject}
                      onChange={setSelectedProject}
                    />
                  </Grid>
                </Grid>
              </Box>
            </Box>

            {/* Access Control Panel */}
            <Box className="table-box" mb={2}>
              <Box sx={{ p: 2 }}>
                <Box className="fx_fs gap1" mb={2}> 
                  <Typography variant="h5" className="primary fw6">
                    Access Control
                  </Typography>
                </Box>
                <Box className="access-control-ag-grid ag-theme-alpine" sx={{ width: "100%", height: 200, position: "relative" }}>
                  <AgGridReact
                    rowData={accessControlRowData}
                    columnDefs={accessControlColDefs}
                    defaultColDef={defaultColDef}
                    getRowStyle={getAccessControlRowStyle}
                    headerHeight={40}
                    rowHeight={44}
                    suppressCellFocus={true}
                    pagination={false}
                    animateRows={true}
                  />
                </Box>
              </Box>
            </Box>

            {/* Configuration Rights Panel */}
            <Box className="table-box">
              <Box sx={{ p: 2 }}>
                <Box className="fx_fs gap1" mb={2}> 
                  <Typography variant="h5" className="primary fw6">
                    Configuration Rights
                  </Typography>
                </Box>
                <Box className="config-rights-ag-grid" sx={{ width: "100%", height: "40vh", position: "relative" }}>
                  <AgGridReact
                    rowData={configRowData}
                    columnDefs={configColDefs}
                    defaultColDef={defaultColDef}
                    getRowStyle={getConfigRowStyle}
                    headerHeight={40}
                    rowHeight={40}
                    suppressCellFocus={true}
                    pagination={false}
                    animateRows={true}
                  />
                </Box>
                <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 1, mt: 2 }}>
                  <Button variant="outlined" className="primary-outlined-btn">
                    Cancel
                  </Button>
                  <Button variant="contained" className="primary-btn">
                    Apply Changes
                  </Button>
                </Box>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </MainLayout>
  );
};

export default Page;
