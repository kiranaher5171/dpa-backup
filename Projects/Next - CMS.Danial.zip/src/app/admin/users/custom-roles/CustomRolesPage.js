"use client";

import React, { useState } from "react";
import { Box, Breadcrumbs, Container, Grid, Typography } from "@mui/material";
import CustomRolesTable from "./CustomRolesTable";
import Link from "next/link";

export default function CustomRolesPage() {
  const [createRoleOpen, setCreateRoleOpen] = useState(false);

  const handleCreateRoleOpen = () => {
    setCreateRoleOpen(true);
  };

  const handleCreateRoleClose = () => {
    setCreateRoleOpen(false);
  };

  return (
    <Container maxWidth sx={{ py: 2 }}>
      <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
        <Grid item lg={12} md={12} sm={12} xs={12}>
          <Box className="fx_sb w100" mb={2}>
            <Box className="fx_fs gap1">
              <Box className="heading-decorator" />
              <Breadcrumbs aria-label="breadcrumb">
                <Link href="/admin/users">
                  <Typography variant="h5" className="primary fw6">
                    Users
                  </Typography>
                </Link>
                <Typography variant="h5" className="primary fw6">
                  Custom Roles
                </Typography>
              </Breadcrumbs>
            </Box>
          </Box>

        </Grid>
      </Grid>

      <Box className="table-box" my={2}>
        <CustomRolesTable onCreateCustom={handleCreateRoleOpen} />
      </Box>
    </Container>
  );
}
