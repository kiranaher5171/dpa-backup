"use client";

import MainLayout from "@/Layouts/MainLayout";
import React from "react";
import CustomRolesPage from "./CustomRolesPage";

export default function CustomRolePage() {
  return (
    <MainLayout>
      <CustomRolesPage />
    </MainLayout>
  );
}
