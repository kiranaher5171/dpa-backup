"use client";

import React, { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import {
  Box,
  TextField,
  Grid,
  Button,
  InputAdornment,
  IconButton,
  Tooltip,
  Switch,
  Typography,
} from "@mui/material";
import { FaSearch } from "react-icons/fa";
import { FiPlus, FiEdit, FiShield } from "react-icons/fi";
import CustomDialog from "@/components/CustomDialog";
import AgGridPagination from "@/components/table_components/AgGridPagination";
import AgGridInfo from "@/components/table_components/AgGridInfo";

ModuleRegistry.registerModules([AllCommunityModule]);

const ACCESS_MODULES = ["Correspondence", "Repository", "Subcontract"];
const ACCESS_PERMISSIONS = [
  { field: "createEditUpdate", headerName: "Create/Edit/Update" },
  { field: "participateComment", headerName: "Participate/Comment" },
  { field: "approveSubmit", headerName: "Approve/Submit" },
  { field: "deleteRetrieve", headerName: "Delete/Retrieve" },
  { field: "view", headerName: "View" },
  { field: "signExecute", headerName: "Sign/Execute" },
  { field: "lockTerms", headerName: "Lock Terms" },
  { field: "recoveryOverride", headerName: "Recovery/Override" },
];
const initialAccessControl = () =>
  ACCESS_MODULES.reduce((acc, module) => {
    acc[module] = {
      createEditUpdate: true,
      participateComment: true,
      approveSubmit: true,
      deleteRetrieve: true,
      view: true,
      signExecute: true,
      lockTerms: true,
      recoveryOverride: false,
    };
    return acc;
  }, {});

const CustomRolesTable = ({ onCreateCustom }) => {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [accessControlDialogOpen, setAccessControlDialogOpen] = useState(false);
  const [selectedRoleForAccessControl, setSelectedRoleForAccessControl] = useState(null);
  const [accessControl, setAccessControl] = useState(initialAccessControl());

  const [rowData] = useState([
    {
      id: 1,
      roleName: "Contract Manager",
      roleDescription: "Manages contracts and approvals",
      modules: "Legal, Schedule, Payment Applications",
      accessControl: true,
    },
    {
      id: 2,
      roleName: "Document Controller",
      roleDescription: "Controls document access and workflow",
      modules: "Correspondence, Legal, Schedule ",
      accessControl: true,
    },
    {
      id: 3,
      roleName: "Compliance Auditor",
      roleDescription: "Audits compliance and reports",
      modules: "Correspondence, Repository, Legal",
      accessControl: true,
    },
  ]);

  const filteredRowData = rowData.filter(
    (row) =>
      !search ||
      row.roleName?.toLowerCase().includes(search.toLowerCase()) ||
      row.roleDescription?.toLowerCase().includes(search.toLowerCase()) ||
      row.modules?.toLowerCase().includes(search.toLowerCase())
  );

  const handleEdit = (data) => {
    console.log("Edit role:", data);
  };

  const handleAccessControl = (data) => {
    setSelectedRoleForAccessControl(data);
    setAccessControl(initialAccessControl());
    setAccessControlDialogOpen(true);
  };

  const handleAccessToggle = (module, permission) => {
    setAccessControl((prev) => ({
      ...prev,
      [module]: { ...prev[module], [permission]: !prev[module][permission] },
    }));
  };

  const accessControlRowData = useMemo(
    () =>
      ACCESS_MODULES.map((module) => ({
        module,
        ...accessControl[module],
      })),
    [accessControl]
  );

  const accessControlColDefs = useMemo(
    () => [
      {
        field: "module",
        headerName: "Module",
        minWidth: 140,
        cellStyle: { fontSize: "13px" },
      },
      ...ACCESS_PERMISSIONS.map(({ field, headerName }) => ({
        field,
        headerName,
        minWidth: 120,
        sortable: false,
        cellStyle: { fontSize: "13px", display: "flex", alignItems: "center", justifyContent: "center" },
        cellRenderer: (params) => (
          <Switch
            checked={!!params.data?.[field]}
            onChange={() => handleAccessToggle(params.data?.module, field)}
            color="primary"
            size="small"
          />
        ),
      })),
    ],
    []
  );

  const getAccessControlRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#ffffff" : "#f9f9f9",
  });

  const defaultColDef = {
    sortable: true,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  const [colDefs] = useState([
    { field: "roleName", headerName: "Role Name", minWidth: 180 },
    { field: "roleDescription", headerName: "Role Description", minWidth: 260 },
    { field: "modules", headerName: "Modules", minWidth: 240 },
    {
      headerName: "Actions",
      field: "actions",
      minWidth: 120,
      headerClass: "table-header-center",
      sortable: false,
      cellRenderer: (params) => (
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
          <Tooltip title="Edit" arrow>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={() => handleEdit(params.data)}
              sx={{ color: "#2b6bbb" }}
            >
              <FiEdit size={16} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Access Control" arrow>
            <IconButton
              size="small"
              className="ico-btn"
              onClick={() => handleAccessControl(params.data)}
              sx={{ color: "#ff9800" }}
            >
              <FiShield size={16} />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ]);

  return (
    <>
      <Box sx={{ display: "flex", justifyContent: "flex-end", alignItems: "center", px: 2, py: 1 }}>
        <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="w100 tenantTableHead" mb={1}>
              <Box className="fx_fe gap1">
                <Box className="textfield-search">
                  <TextField
                    placeholder="Search"
                    size="small"
                    className="tenantTableHeadSearch"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <FaSearch />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
                <Button
                  variant="contained"
                  className="primary-btn mobile-ico-btn"
                  startIcon={<FiPlus />}
                  onClick={() => router.push("/admin/users/custom-roles/create-custom-role")}
                >
                  <span className="mobile-ico-btn-text">Create Custom Role</span>
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>

      <Box style={{ width: "100%", height: "60vh" }}>
        <AgGridReact
          rowData={filteredRowData}
          columnDefs={colDefs}
          defaultColDef={defaultColDef}
          getRowStyle={getRowStyle}
          headerHeight={40}
          rowHeight={40}
          pagination={false}
        />
      </Box>

      <Box id="tb_footer" className="fx_sb" mt={1}>
        <AgGridInfo
          currentPage={currentPage}
          rowsPerPage={10}
          totalRows={filteredRowData.length}
        />
        <AgGridPagination
          currentPage={currentPage}
          totalPages={Math.ceil(filteredRowData.length / 10) || 1}
          onPageChange={(_, page) => setCurrentPage(page)}
        />
      </Box>

      <CustomDialog
        open={accessControlDialogOpen}
        onClose={() => setAccessControlDialogOpen(false)}
        title="Access Control"
        maxWidth="md"
      >
        <Box my={2}>
          {/* {selectedRoleForAccessControl && (
            <Typography variant="subtitle2" sx={{ color: "text.secondary", mb: 2 }}>
              Role: {selectedRoleForAccessControl.roleName}
            </Typography>
          )} */}
          <Box className="table-box">
            <Box sx={{ p: 2 }}>
              <Box className="fx_fs gap1" mb={2}>
                <Box className="heading-decorator" />
                <Typography variant="h6" className="primary fw6">
                  {selectedRoleForAccessControl?.roleName ? `Role: ${selectedRoleForAccessControl.roleName}` : "Access Control"}
                </Typography>
              </Box>
              <Box className="access-control-ag-grid ag-theme-alpine" sx={{ width: "100%", height: 200, position: "relative" }}>
                <AgGridReact
                  rowData={accessControlRowData}
                  columnDefs={accessControlColDefs}
                  defaultColDef={defaultColDef}
                  getRowStyle={getAccessControlRowStyle}
                  headerHeight={40}
                  rowHeight={44}
                  suppressCellFocus={true}
                  pagination={false}
                  animateRows={true}
                />
              </Box>
            </Box>
          </Box>
          <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 1, mt: 2 }}>
            <Button variant="outlined" className="primary-outlined-btn" onClick={() => setAccessControlDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="contained" className="primary-btn" onClick={() => setAccessControlDialogOpen(false)}>
              Apply Changes
            </Button>
          </Box>
        </Box>
      </CustomDialog>
    </>
  );
};

export default CustomRolesTable;
