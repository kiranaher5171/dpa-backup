"use client";
import React from 'react';
import NoAuthLayout from '@/Layouts/NoAuth/NoAuthLayout';
import { Box, Typography, Button, Container, Paper, Chip } from '@mui/material';
import { MdDescription, MdSecurity, MdSpeed, MdOutlineLogin } from "react-icons/md";
import { IoDocumentText, IoShieldCheckmark, IoAnalytics } from "react-icons/io5";
import { FaLaptopCode } from "react-icons/fa";
import { IoIosArrowForward } from "react-icons/io";
import Link from 'next/link';

const LandingPage = () => {
    return (
        <NoAuthLayout>
            {/* Hero Section */}
            <Container maxWidth="md">
                <Box sx={{
                    textAlign: 'center',
                    py: { xs: 4, md: 8 },
                    minHeight: 'calc(100vh - 200px)',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}>
                    {/* In Progress Badge */}
                    <Chip
                        label={<><span className='fw5'>Under Development</span></>}
                        color="secondary"
                    />

                    {/* Main Heading */}
                    <Typography variant="h1" className='primary fw7' sx={{ mt: 2, mb: 3 }}>
                        Contract Management System
                    </Typography>

                    {/* Subtitle */}
                    <Typography variant="h5" className='text fw5' sx={{ mb: 4 }}>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    </Typography>

                    {/* CTA Buttons */}
                    <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', justifyContent: 'center', mb: 6 }}>
                        <Link href="/system-management">
                        <Button
                            variant="contained"
                            color="primary"
                            size="large"
                            className='primary-btn'
                            endIcon={<MdOutlineLogin />}
                        >
                            Get Started
                        </Button>
                        </Link>
                        <Button
                            variant="contained"
                            color="secondary"
                            size="large"
                            className='primary-outlined-btn'
                            endIcon={<IoIosArrowForward />}
                        >
                            Learn More
                        </Button>
                    </Box>

                </Box>
            </Container>
        </NoAuthLayout>
    );
};

export default LandingPage;
