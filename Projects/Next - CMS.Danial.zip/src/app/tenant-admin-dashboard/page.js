"use client";

import MainLayout from "@/Layouts/MainLayout";
import React, { useState } from "react";
import Link from "next/link";
import {
  Box,
  Button,
  Container,
  Grid,
  InputAdornment,
  TextField,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  IconButton,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Stack,
} from "@mui/material";
import WhiteCard from "@/components/whiteCards";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";
import { FiPlus, FiBell, FiUsers, FiBarChart2, FiX, FiCheck, FiChevronDown, FiLink2, FiEye, FiUser, FiZoomIn, FiZoomOut, FiPrinter, FiMessageCircle, FiEdit, FiType, FiPenTool } from "react-icons/fi";
import { MdExpandMore, MdCheckCircle, MdWarning, MdFolder, MdDescription, MdPeople, MdStorage, MdCode, MdCalendarToday } from "react-icons/md";
import { HiOutlineExclamationTriangle } from "react-icons/hi2";
import { FaEnvelope } from "react-icons/fa";
import { IoScaleSharp } from "react-icons/io5";
import { LuUserPlus } from "react-icons/lu";
import { LuMousePointerClick } from "react-icons/lu";
import { GrPowerReset } from "react-icons/gr";
import { MdOutlineSubscriptions, MdBusiness, MdPerson, MdOutlineWork, MdBadge, MdAdminPanelSettings, MdOutlineCategory, MdOutlineDescription } from "react-icons/md";
import { FaSearch } from "react-icons/fa";
import UserTable from "./UserTable";
import LinkedProjectViewsTableDialog from "./LinkedProjectViewsTableDialog";
import CustomDialog from "@/components/CustomDialog";
import SideDrawer from "@/components/SideDrawer";
import SystemUserForm from "../admin/users/SystemUserForm";
import { FiDownload } from "react-icons/fi";
import CreateTenantAdmin from "../admin/users/CreateTenantAdmin";
import { MdOutlineBusinessCenter } from "react-icons/md";
import { TbListDetails } from "react-icons/tb";

const PROJECTS_CARDS = [
  { value: "13", label: "Total Projects", valueColor: "#2b6bbb" },
  { value: "11", label: "Active", valueColor: "#2b6bbb" },
  { value: "1", label: "Draft", valueColor: "#2b6bbb" },
  { value: "1", label: "Completed", valueColor: "#2b6bbb" },
];

const USERS_CARDS = [
  { value: "8", label: "Total Users", valueColor: "#7b1fa2" },
  { value: "2", label: "Active Users", valueColor: "#2e7d32" },
  { value: "4", label: "Awaiting Users", valueColor: "#f57f17" },
  { value: "0", label: "Suspended Users", valueColor: "#c2185b" },
  { value: "0", label: "Deactivated Users", valueColor: "#6a1b9a" },
  { value: "0", label: "Locked Users", valueColor: "#e64a19" },
];

const PENDING_APPROVALS = [

  {
    id: 1,
    title: "Assign User 'Akhil Mitta' to Project 'DNL Test Project'",
    requestedBy: "Google Admin on 06 Jan 2026 At 09:04 AM",
  },
  {
    id: 2,
    title: "Create Contract Party - Colorcheck (Contractor)",
    requestedBy: "Requested by Google Admin on 21 Nov 2025 at 10:44 AM",
  },
];

const Page = () => {
  const [planFilter, setPlanFilter] = useState({ label: "Project", value: "project" });
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerType, setDrawerType] = useState(null); // "user" or "tenant-admin"
  const [editingUser, setEditingUser] = useState(null);
  const [createMenuAnchor, setCreateMenuAnchor] = useState(null);
  const [linkedProjectDialogOpen, setLinkedProjectDialogOpen] = useState(false);
  const [planDetailsDialogOpen, setPlanDetailsDialogOpen] = useState(false);
  const [documentPreviewOpen, setDocumentPreviewOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [actionAnchorEl, setActionAnchorEl] = useState(null);
  const actionMenuOpen = Boolean(actionAnchorEl);

  const handleApprove = (id) => {
    console.log("Approve", id);
  };

  const handleReject = (id) => {
    console.log("Reject", id);
  };

  const handleLinkedProjectView = () => {
    setLinkedProjectDialogOpen(true);
  };

  const handleCloseLinkedProjectDialog = () => {
    setLinkedProjectDialogOpen(false);
  };

  const handlePlanDetailsOpen = () => {
    setPlanDetailsDialogOpen(true);
  };

  const handlePlanDetailsClose = () => {
    setPlanDetailsDialogOpen(false);
  };

  const handleViewDocument = (doc) => {
    setSelectedDocument(doc);
    setDocumentPreviewOpen(true);
  };

  const handleCloseDocumentPreview = () => {
    setDocumentPreviewOpen(false);
    setSelectedDocument(null);
  };

  const handleCreateUser = () => {
    setEditingUser(null);
    setDrawerOpen(true);
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setDrawerOpen(false);
    setEditingUser(null);
  };

  const handleCreateMenuOpen = (event) => {
    setCreateMenuAnchor(event.currentTarget);
  };

  const handleCreateMenuClose = () => {
    setCreateMenuAnchor(null);
  };

  const handleCreateOption = (option) => {
    handleCreateMenuClose();
    if (option === "tenant-admin") {
      setEditingUser(null);
      setDrawerType("tenant-admin");
      setDrawerOpen(true);
    } else if (option === "user") {
      setEditingUser(null);
      setDrawerType("user");
      setDrawerOpen(true);
    } else {
      console.log(`Create ${option}`);
    }
  };

  const handleActionClick = (event) => {
    setActionAnchorEl(event.currentTarget);
  };

  const handleActionClose = () => {
    setActionAnchorEl(null);
  };

  const handleResetActions = () => {
    console.log("Reset");
  };

  const handleCustomRole = () => {
    console.log("Custom Role");
  };

  return (
    <MainLayout>
      <Container maxWidth sx={{ py: 2 }}>
        <Grid container alignItems="flex-start" justifyContent="center" spacing={1}>
          <Grid item lg={12} md={12} sm={12} xs={12}>
            <Box className="fx_sb w100" mb={2}>
              <Box className="fx_fs gap1">
                <Box className="heading-decorator" />
                <Typography variant="h5" className="primary fw6">
                  Tenant Admin Dashboard
                </Typography>
              </Box>

            

            </Box>


            {/* Tenant Information */}
            <Box mb={2}>
              <Box className="table-box"> 
                <Stack direction="row" justifyContent="space-between" alignItems="center" flexWrap={'wrap'} gap={2} mb={2}>
                  <Box className="fx_fs gap1">
                    <TbListDetails size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                    Tenant Details
                    </Typography>
                  </Box>

                  <Box>
                <Button
                  variant="outlined"
                  className="primary-outlined-btn  "
                  size="small"
                  onClick={handleLinkedProjectView}
                >
                  <span className=" "> Data Residency: India, Andhra Pradesh </span>
                </Button>
              </Box>
                </Stack>
                <Grid container spacing={3}>
                  {/* Column 1 */}
                  <Grid item xs={12} md={4}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Company Name
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                              Google Company New
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Tenant Name
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                              Google Tenant
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Tenant Type
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                              Project Owner
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>
                    </Grid>
                  </Grid>

                  {/* Column 2 */}
                  <Grid item xs={12} md={4}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Tenant ID
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                              341
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Tenant Admin(s)
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                              Google Admin, New Admin
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Industry
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#000', fontSize: '13px', fontWeight: 500 }}>
                              New industry
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>
                    </Grid>
                  </Grid>

                  {/* Column 3 */}
                  <Grid item xs={12} md={4}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Status
                            </Typography>
                            <Box sx={{ mt: 0.5 }}>
                              <span
                                style={{
                                  backgroundColor: "#d6ffd6",
                                  color: "green",
                                  borderRadius: "4px",
                                  fontSize: "11px",
                                  fontWeight: 500,
                                  padding: "2px 20px",
                                  display: "inline-block",
                                }}
                              >
                                Active
                              </span>
                            </Box>
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box>
                            <Typography variant="body2" sx={{ color: '#666', fontSize: '11px' }}>
                              Plan
                            </Typography>
                            <Button
                              variant="text"
                              className="link-text-btn"
                              size="small"
                              onClick={handlePlanDetailsOpen}
                            >
                              Professional Plan
                            </Button>
                          </Box>
                        </Box>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Box>
            </Box>



            {/* Projects & Users */}
            <Box className="table-box" mb={2}>
              <Box >

                <Box className="fx_fe w100" mb={1}>
                  <Box className="fx_fe gap1">


                    <Button
                      variant="outlined"
                      className="primary-outlined-btn mobile-ico-btn"
                      size="small"
                      startIcon={<FiLink2 />}
                      onClick={handleLinkedProjectView}
                    >
                      <span className="mobile-ico-btn-text"> Linked Project View</span>
                    </Button>

                    <Button
                      variant="contained"
                      className="primary-btn  "
                      endIcon={<FiChevronDown />}
                      onClick={handleCreateMenuOpen}
                      aria-controls={createMenuAnchor ? 'create-menu' : undefined}
                      aria-haspopup="true"
                      aria-expanded={createMenuAnchor ? 'true' : undefined}
                      sx={{ flexShrink: 0 }}
                    >
                      <span className=" ">Create</span>
                    </Button>
                    <Menu
                      id="create-menu"
                      anchorEl={createMenuAnchor}
                      open={Boolean(createMenuAnchor)}
                      onClose={handleCreateMenuClose}
                      MenuListProps={{ 'aria-labelledby': 'create-button' }}
                      anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                      transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                    >
                      <MenuItem onClick={() => handleCreateOption("project")}>Project</MenuItem>
                      <MenuItem onClick={() => handleCreateOption("contract-party")}>Contract Party</MenuItem>
                      <MenuItem onClick={() => handleCreateOption("user")}>User</MenuItem>
                      <MenuItem onClick={() => handleCreateOption("tenant-admin")}>Tenant Admin</MenuItem>
                    </Menu>





                  </Box>

                </Box>

                {/* Projects Section - First Row (4 cards) */}
                <Grid container spacing={2} alignItems="stretch" justifyContent="flex-start" sx={{ mb: 2 }}>
                  {PROJECTS_CARDS.map((card, index) => (
                    <Grid item xs={12} sm={6} md={2} lg={2} key={index}>
                      <WhiteCard
                        value={card.value}
                        label={card.label}
                        valueColor={card.valueColor}
                      />
                    </Grid>
                  ))}
                </Grid>

                {/* Users Section - Second Row (6 cards) */}
                <Grid container spacing={2} alignItems="stretch" justifyContent="flex-start">
                  {USERS_CARDS.map((card, index) => (
                    <Grid item xs={12} sm={6} md={4} lg={2} key={index}>
                      <WhiteCard
                        value={card.value}
                        label={card.label}
                        valueColor={card.valueColor}
                      />
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </Box>

            {/* Users Table */}
            <Box className="table-box" mb={3}>
              <Box>
                <Stack direction="row" justifyContent="space-between" alignItems="center" flexWrap={'wrap'} gap={2} mb={2}>
                  <Box className="fx_fs gap1">
                    <FiUsers size={22} style={{ color: "var(--primary)" }} />
                    <Typography variant="h5" className="primary fw6">
                      Users
                    </Typography>
                  </Box>

                  <Box className="fx_fe gap1">
                    <Box className="textfield-search">
                      <TextField
                        placeholder="Search"
                        size="small"
                        fullWidth={true}
                        InputProps={{
                          startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                        }}
                      />
                    </Box>
                  </Box>
                </Stack>
                <UserTable onEditUser={handleEditUser} />
              </Box>
            </Box>


            {/* Pending Approvals */}
            <Box mb={3}>
              <Grid container spacing={2}>
                <Grid item lg={9} xs={12} md={6} sm={12}  >
                  <Box className="table-box">
                    <Box className="fx_fs gap1" mb={2}>
                      <Box sx={{ position: "relative", display: "inline-flex" }}>
                        <FiBell size={22} style={{ color: "var(--error)" }} />
                      </Box>
                      <Typography variant="h5" className="red fw6">
                        Pending Actions(Operartional Queue)
                      </Typography>
                    </Box>
                    <Grid container spacing={2}>
                      {PENDING_APPROVALS.map((item) => (
                        <Grid item lg={12} xs={12} md={6} key={item.id}>
                          <Box
                            sx={{
                              p: 2,
                              height: "100%",
                              bgcolor: "#f9f9f9",
                              borderRadius: 1,
                              border: "1px solid #eee",
                            }}
                          >
                            <Grid container alignItems="center" spacing={2}>
                              <Grid item xs={12} sm={12} md={6} lg={9}>
                                <Typography variant="subtitle1" fontWeight={600} sx={{ mb: 0.5 }}>
                                  {item.title}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                  Requested by {item.requestedBy}
                                </Typography>
                              </Grid>
                              <Grid
                                item
                                xs={12}
                                sm={12}
                                md={6}
                                lg={3}
                                sx={{
                                  display: "flex",
                                  gap: 1,
                                  justifyContent: { xs: "flex-start", sm: "flex-start", md: "flex-end" },
                                  flexShrink: 0,
                                }}
                              >
                                <Button
                                  variant="outlined"
                                  className="primary-outlined-btn mobile-ico-btn"
                                  size="small"
                                  startIcon={<FiX />}
                                  onClick={() => handleReject(item.id)}
                                >
                                  <span className="mobile-ico-btn-text"> Reject</span>
                                </Button>
                                <Button
                                  variant="contained"
                                  className="primary-btn mobile-ico-btn"
                                  size="small"
                                  startIcon={<FiCheck />}
                                  onClick={() => handleApprove(item.id)}
                                >
                                  <span className="mobile-ico-btn-text">Approve</span>
                                </Button>
                              </Grid>
                            </Grid>
                          </Box>
                        </Grid>
                      ))}
                    </Grid>
                    <Box className="fx_fe gap1" mt={2}>
                      <Link
                        href="/#"
                        className="link-text-btn"
                      >
                        <Button variant="text" color="primary" className="link-text-btn">View All</Button>
                      </Link>
                    </Box>
                  </Box>

                </Grid>
                <Grid item lg={3} xs={12} md={6} sm={12}>
                  <Box className="table-box">

                    <Box className="fx_fs gap1" mb={2}>
                      <Box sx={{ position: "relative", display: "inline-flex" }}>
                        <MdOutlineDescription size={22} style={{ color: "var(--primary)" }} />
                      </Box>
                      <Typography variant="h5" className="primary fw6">
                        Accepted Agreements
                      </Typography>
                    </Box>

                    <Box  >
                      <List sx={{ width: '100%', bgcolor: 'background.paper', p: 0 }}>
                        {[
                          { name: 'Google TOU' },
                          { name: 'Google DSA' },
                          { name: 'Google MSA' }
                        ].map((doc, idx) => (
                          <ListItem
                            key={idx}
                            sx={{
                              border: '1px solid #e0e0e0',
                              borderRadius: '4px',
                              mb: 1,
                              bgcolor: '#f9f9f9',
                              display: 'flex',
                              alignItems: 'center'
                            }}
                            secondaryAction={
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                
                                <IconButton 
                                  edge="end" 
                                  aria-label="view" 
                                  size="small"
                                  onClick={() => handleViewDocument(doc)}
                                >
                                  <FiEye size={18} style={{ color: '#2b6bbb' }} />
                                </IconButton>
                                <IconButton edge="end" aria-label="download" size="small">
                                  <FiDownload size={18} style={{ color: 'var(--green)' }} />
                                </IconButton>
                              </Box>
                            }
                          >
                            <ListItemText
                              primary={
                                <Typography variant="subtitle1" fontWeight={600} sx={{ mb: 0.5 }}>
                                  {doc.name}
                                </Typography>
                              }
                            />
                          </ListItem>
                        ))}
                      </List>
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Grid>
        </Grid>
      </Container>

      {/* Linked Project View Dialog */}
      <CustomDialog
        open={linkedProjectDialogOpen}
        onClose={handleCloseLinkedProjectDialog}
        title="Linked Project View"
        maxWidth="lg"
      >
        <Box mt={2}>
          <Box className="fx_fe gap1">
            <Box className="textfield-search" mb={1}>
              <TextField
                placeholder="Search"
                size="small"
                fullWidth={true}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                }}
              />
            </Box>
          </Box>
          <LinkedProjectViewsTableDialog />
        </Box>
      </CustomDialog>

      {/* Plan Details Dialog */}
      <CustomDialog
        open={planDetailsDialogOpen}
        onClose={handlePlanDetailsClose}
        title="Detail Plan Info"
        maxWidth="md"
      >
        <Box mt={2}>
          {/* Available Modules Accordion */}
          <Accordion
            defaultExpanded
            sx={{
              mb: 2,
              boxShadow: "none",
              border: "1px solid #e0e0e0",
              borderRadius: "4px",
              "&:before": { display: "none" },
            }}
          >
            <AccordionSummary
              expandIcon={<MdExpandMore style={{ color: "#fff" }} />}
              sx={{
                bgcolor: "#2b6bbb",
                color: "#fff",
                borderRadius: "4px 4px 0 0",
                minHeight: 56,
                "&.Mui-expanded": {
                  minHeight: 56,
                  borderRadius: "4px 4px 0 0",
                },
                "&:hover": {
                  bgcolor: "#1e5a9e",
                  transition: "background-color 0.3s ease",
                },
                transition: "background-color 0.3s ease",
              }}
            >
              <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                <MdFolder style={{ fontSize: "20px" }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Available Modules
                </Typography>
              </Box>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 3 }}>
              <Box>
                <Typography variant="subtitle2" sx={{ mb: 2, color: "#666", fontWeight: 600 }}>
                  Module Status
                </Typography>
                <Grid container spacing={1.5}>
                  {[
                    { name: "Prime Contract", enabled: true, icon: <MdCheckCircle /> },
                    { name: "Risks and Opportunities", enabled: false, icon: <HiOutlineExclamationTriangle /> },
                    { name: "Correspondence", enabled: false, icon: <FaEnvelope /> },
                    { name: "Repository", enabled: true, icon: <MdCheckCircle /> },
                    { name: "FCN Hub", enabled: true, icon: <MdCheckCircle /> },
                    { name: "Schedule Analytics", enabled: false, icon: <MdCalendarToday /> },
                    { name: "Subcontract", enabled: true, icon: <MdCheckCircle /> },
                    { name: "Legal", enabled: false, icon: <IoScaleSharp /> },
                    { name: "Payment Applications", enabled: true, icon: <MdCheckCircle /> },
                  ].map((module, index) => (
                    <Grid item xs={12} key={index}>
                      <Box
                        sx={{
                          p: 1.5,
                          border: "1px solid #e0e0e0",
                          borderRadius: "4px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          bgcolor: "#f9f9f9",
                          transition: "all 0.2s ease",
                          "&:hover": {
                            bgcolor: "#f5f5f5",
                            borderColor: "#bdbdbd",
                            transform: "translateY(-1px)",
                            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                          },
                        }}
                      >
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                          <Box
                            sx={{
                              color: module.enabled ? "#2e7d32" : "#9e9e9e",
                              fontSize: "20px",
                              display: "flex",
                              alignItems: "center",
                            }}
                          >
                            {module.icon}
                          </Box>
                          <Typography
                            variant="body1"
                            sx={{
                              color: module.enabled ? "#2e7d32" : "#9e9e9e",
                              fontWeight: 500,
                            }}
                          >
                            {module.name}
                          </Typography>
                        </Box>
                        {!module.enabled && (
                          <Button
                            variant="contained"
                            size="small"
                            sx={{
                              bgcolor: "#ff9800",
                              color: "#fff",
                              textTransform: "none",
                              px: 2,
                              "&:hover": {
                                bgcolor: "#f57c00",
                                transform: "scale(1.05)",
                              },
                              transition: "all 0.2s ease",
                            }}
                          >
                            Upgrade
                          </Button>
                        )}
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </AccordionDetails>
          </Accordion>

          {/* Plan Details Accordion */}
          <Accordion
            defaultExpanded
            sx={{
              boxShadow: "none",
              border: "1px solid #e0e0e0",
              borderRadius: "4px",
              "&:before": { display: "none" },
            }}
          >
            <AccordionSummary
              expandIcon={<MdExpandMore style={{ color: "#fff" }} />}
              sx={{
                bgcolor: "#2b6bbb",
                color: "#fff",
                borderRadius: "4px 4px 0 0",
                minHeight: 56,
                "&.Mui-expanded": {
                  minHeight: 56,
                  borderRadius: "4px 4px 0 0",
                },
                "&:hover": {
                  bgcolor: "#1e5a9e",
                  transition: "background-color 0.3s ease",
                },
                transition: "background-color 0.3s ease",
              }}
            >
              <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                <MdDescription style={{ fontSize: "20px" }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Plan Details
                </Typography>
              </Box>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 3 }}>
              <Box>
                <Grid container spacing={1.5}>
                  {[
                    { icon: <MdPeople />, label: "Max Users", value: "100" },
                    { icon: <MdStorage />, label: "Storage Limit", value: "50 GB" },
                    { icon: <MdCode />, label: "API Access", value: "Enabled" },
                    { icon: <MdCalendarToday />, label: "Billing Cycle", value: "Annual" },
                  ].map((detail, index) => (
                    <Grid item xs={12} key={index}>
                      <Box
                        sx={{
                          p: 2,
                          bgcolor: "#e8f5e9",
                          borderRadius: "4px",
                          display: "flex",
                          alignItems: "center",
                          gap: 2,
                          transition: "all 0.2s ease",
                          "&:hover": {
                            bgcolor: "#c8e6c9",
                            transform: "translateY(-1px)",
                            boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                          },
                        }}
                      >
                        <Box sx={{ color: "#2e7d32", fontSize: "24px", display: "flex", alignItems: "center" }}>
                          {detail.icon}
                        </Box>
                        <Typography variant="body1" sx={{ color: "#2e7d32", fontWeight: 500 }}>
                          {detail.label}: {detail.value}
                        </Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </AccordionDetails>
          </Accordion>
        </Box>
      </CustomDialog>

      {/* Document Preview Dialog */}
      <CustomDialog
        open={documentPreviewOpen}
        onClose={handleCloseDocumentPreview}
        title="Document Preview"
        showCloseButton={true}
        maxWidth="lg"
        fullWidth={true}
        PaperProps={{
          sx: {
            height: "90vh",
            maxHeight: "90vh",
            display: "flex",
            flexDirection: "column",
            m: 2,
            overflow: "hidden",
          },
        }}
        
      >
        <Box sx={{ display: "flex", flexDirection: "column", height: "100%", flex: 1, minHeight: 0 }} pt={2}>
          {/* Toolbar */}
          <Box
            sx={{
              bgcolor: "#f5f5f5",
              borderBottom: "1px solid #e0e0e0",
              p: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 2,
            }}
          >
            {/* Left Section */}
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <MdDescription size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiZoomIn size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiZoomOut size={18} />
              </IconButton>
              <TextField
                size="small"
                value="4 of 4"
                sx={{
                  width: "80px",
                  "& .MuiOutlinedInput-root": {
                    height: "32px",
                    fontSize: "12px",
                  },
                }}
                inputProps={{ readOnly: true }}
              />
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <Typography sx={{ fontSize: "18px" }}>-</Typography>
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <Typography sx={{ fontSize: "18px" }}>+</Typography>
              </IconButton>
              <TextField
                size="small"
                value="Automatic Zoom"
                sx={{
                  width: "140px",
                  "& .MuiOutlinedInput-root": {
                    height: "32px",
                    fontSize: "12px",
                  },
                }}
                inputProps={{ readOnly: true }}
              />
            </Box>

            {/* Right Section */}
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiMessageCircle size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiEdit size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiType size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiPenTool size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiPrinter size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiDownload size={18} />
              </IconButton>
              <IconButton size="small" sx={{ "&:hover": { bgcolor: "#e0e0e0" } }}>
                <FiChevronDown size={18} />
              </IconButton>
            </Box>
          </Box>

          {/* Document Content Area */}
          <Box
            sx={{
              flex: 1,
              bgcolor: "#f5f5f5",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              overflow: "auto",
              position: "relative",
            }}
          >
            <Box
              sx={{
                bgcolor: "#fff",
                width: "100%",
                height: "100%",
                minHeight: "500px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
              }}
            >
              {selectedDocument && (
                <Typography variant="body1" sx={{ color: "#666" }}>
                  {selectedDocument.name}
                </Typography>
              )} 
            </Box>
          </Box>
        </Box>
      </CustomDialog>

      {/* Side Drawer for Tenant Admin */}
      <SideDrawer open={drawerOpen} onClose={handleCloseDrawer}>
        <Box className="right-drawer-header fx_fs gap1">
          <LuUserPlus style={{ fontSize: "20px", color: "var(--primary)" }} />
          <Typography variant="h5" className="primary fw6">
            {drawerType === "user" ? (editingUser ? "Edit User" : "Add User") : "Create Tenant Admin User"}
          </Typography>
        </Box>
        <Box className="right-drawer-content">
          {drawerType === "user" ? <SystemUserForm /> : <CreateTenantAdmin />}
        </Box>
        <Box className="right-drawer-footer fx_fe gap1">
          <Button variant="contained" className="primary-outlined-btn" onClick={handleCloseDrawer}>
            Cancel
          </Button>
          <Button variant="contained" className="primary-btn" autoFocus onClick={handleCloseDrawer}>
            {drawerType === "user" ? "Save" : "Create"}
          </Button>
        </Box>
      </SideDrawer>
    </MainLayout>
  );
};

export default Page;
