"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, IconButton, Tooltip, Typography, Grid, Button } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import { LuUser } from "react-icons/lu";
import {
  MdPersonAddAlt,
  MdLockReset,
  MdMailOutline,
  MdDelete
} from "react-icons/md";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import Link from "next/link";
import { FiEye } from "react-icons/fi";
import { ImBlocked } from "react-icons/im";
import { MdOutlinePersonOff } from "react-icons/md";
import { MdDeleteOutline } from "react-icons/md";
import { FiShield } from "react-icons/fi";


ModuleRegistry.registerModules([AllCommunityModule]);

const UserTable = ({ onEditUser }) => {
  const [loading, setLoading] = useState(true);
  const gridRef = useRef(null);
  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditUser, setAuditUser] = useState(null);

  const auditLogs = [
    "Vaibhav Updated Previous_Status From Active To Suspend Pending At 2025-12-22 13:25:08",
    "Vaibhav Updated Status From Suspend Pending To Suspended At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_By From 141 To 453 At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_Date From 12/17/2025 To 12/22/2025 At 2025-12-22 13:25:08",
    "Vaibhav Updated Previous_Status From Reactivation Pending To Active At 2025-12-17 11:21:45",
    "Vaibhav Updated Status From Active To Suspend Pending At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_By From 155 To 141 At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_Date From 10/5/2025 To 12/17/2025 At 2025-12-17 11:21:45",
    "Vaibhav Updated Previous_Status From Deactivated To Reactivation Pending At 2025-10-05 09:28:23",
    "Vaibhav Updated Status From Reactivation Pending To Active At 2025-10-05 09:28:23",
  ];

  const filteredAuditLogs = auditLogs.filter((log) =>
    log.toLowerCase().includes((auditSearch || "").toLowerCase())
  );

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);


  // Updated rowData with lastLogin values for each user
  const [rowData] = useState([
    {
      id: 1,
      userName: "Test Role",
      assignedProject: "DNL Test Project, Decimalcheckuuuu, De...",
      role: "Auditor/Compliance, Consultant, Contract...",
      status: "Awaiting Activation",
      lastLogin: "09 Dec 25 At 10:10AM",
    },
    {
      id: 2,
      userName: "Test Access",
      assignedProject: "HHHHFFF, SubcontractTest, addresscheck...",
      role: "Auditor/Compliance, Director, Document C...",
      status: "Awaiting Activation",
      lastLogin: "04 Dec 25 At 02:27PM",
    },
    {
      id: 3,
      userName: "Abhi Ram",
      assignedProject: "DNL Test Project, Decimalcheckuuuu, HH...",
      role: "Auditor/Compliance, Consultant, Contract...",
      status: "Awaiting Activation",
      lastLogin: "01 Dec 25 At 05:18PM",
    },
    {
      id: 4,
      userName: "Akhil Mitta",
      assignedProject: "DNL Test Project, HHHHFFF, SubcontractT...",
      role: "Auditor/Compliance, Consultant, Contract...",
      status: "Awaiting Activation",
      lastLogin: "28 Nov 25 At 11:40AM",
    },
    {
      id: 5,
      userName: "Anji Medam",
      assignedProject: "Decimalcheckuuuu, HHHHFFF, Subcontra...",
      role: "Consultant",
      status: "Invitation Sent",
      lastLogin: "14 Nov 25 At 09:12AM",
    },
  ]);

  const handleDeactivate = (data) => {
    console.log("Deactivate user:", data);
  };

  const handleReactivate = (data) => {
    console.log("Reactivate user:", data);
  };

  const handleSuspend = (data) => {
    console.log("Suspend user:", data);
  };

  const handleResetPassword = (data) => {
    console.log("Reset password for:", data);
  };

  const handleResendInvitation = (data) => {
    console.log("Resend invitation to:", data);
  };

  const handleDelete = (data) => {
    console.log("Delete user:", data);
  };

  const handleViewLogs = (data) => {
    setAuditUser(data);
    setAuditSearch("");
    setAuditDialogOpen(true);
  };

  const handleAccessControl = (data) => {
    console.log("Access control for:", data);
  };

  const columnDefs = useMemo(
    () => [
      {
        field: "userName",
        headerName: "User Name",
        minWidth: 70,
        cellRenderer: (params) => <span>{params.value}</span>,
      },
      {
        field: "assignedProject",
        headerName: "Assigned Project",
        minWidth: 250,
        cellRenderer: (params) => (
               <span>{params.value}</span>
        ),
      },
      {
        field: "role",
        headerName: "Role",
        headerClass: "table-header-center",
        minWidth: 200,
        cellRenderer: (params) => {
          return (
                <span>{params.value}</span>
          );
        },
      },
      {
        field: "status",
        headerName: "Status",
        headerClass: "table-header-center",
        minWidth: 160,
        maxWidth: 160,
        cellRenderer: (params) => {
          const statusColors = {
            Active: { bg: "#d6ffd6", color: "green" },
            "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" },
            "Invitation Sent": { bg: "#fcf3cc", color: "#D0B404" },
            Deactivated: { bg: "#f5f5f5", color: "#616161" },
            Suspended: { bg: "#ffecef", color: "red" },
          };
          const style = statusColors[params.value] || statusColors.Deactivated;
          return (
            <span
              style={{
                backgroundColor: style.bg,
                color: style.color,
                borderRadius: "4px",
                fontSize: "11px",
                fontWeight: 500,
                minWidth: "120px",
                display: "flex",
                height: "25px",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {params.value}
            </span>
          );
        },
      }, 
      {
        field: "lastLogin",
        headerName: "Last Login",
        minWidth: 180,
        maxWidth: 180,
        cellRenderer: (params) => (
          <span>
            {params.value}
          </span>
        ),
      },
      {
        headerName: "Actions",
        field: "actions",
        minWidth: 290,
        maxWidth: 290,
        headerClass: "table-header-center",
        // pinned: "right",
        sortable: false,
        filter: false,
        // lockPosition: true,
        cellRenderer: (params) => {
          return (
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
              <Tooltip title="Deactivate" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleDeactivate(params.data)}
                  sx={{ color: "#ff6100" }}
                >
                  <MdOutlinePersonOff size={18} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Reactivate" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleReactivate(params.data)}
                  sx={{ color: "#2e7d32" }}
                >
                  <MdPersonAddAlt size={18} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Suspend" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleSuspend(params.data)}
                  sx={{ color: "#ff9800" }}
                >
                  <ImBlocked size={13} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Delete" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleDelete(params.data)}
                  sx={{ color: "var(--error)" }}
                >
                  <MdDeleteOutline size={16} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Reset Password" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleResetPassword(params.data)}
                  sx={{ color: "#2b6bbb" }}
                >
                  <MdLockReset size={18} />
                </IconButton>
              </Tooltip>

              <Tooltip title="Resend Invitation" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleResendInvitation(params.data)}
                  sx={{ color: "#7b1fa2" }}
                >
                  <MdMailOutline size={16} />
                </IconButton>
              </Tooltip>

              <Tooltip title="View Logs" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleViewLogs(params.data)}
                  sx={{ color: "#2b6bbb" }}
                >
                  <FiEye size={16} />
                </IconButton>
              </Tooltip>

              <Tooltip title="access control" arrow>
                <IconButton
                  size="small"
                  className="ico-btn"
                  onClick={() => handleAccessControl(params.data)}
                  sx={{ color: "#ff9800" }}
                >
                  <FiShield size={16} />
                </IconButton>
              </Tooltip>
            </Box>
          );
        },
      },
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  // Show all rows (no pagination)
  const paginatedRowData = rowData;

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "250px", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box style={{ width: "100%", height: "250px" }}>
            <AgGridReact
              ref={gridRef}
              rowData={paginatedRowData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              pagination={false}
              animateRows={true}
            />
          </Box>
          <Box id="tb_footer" className="fx_fe"  >
            <Link
              href="/system-management"
              className="link-text-btn"
            >
              <Button variant="text" color="primary" className="link-text-btn">View All</Button>
            </Link>
          </Box>
        </>
      )}

      <CustomDialog
        open={auditDialogOpen}
        onClose={() => setAuditDialogOpen(false)}
        title="User Audit Logs"
        maxWidth="md"
      >
        <Box my={2}>
          <Grid container alignItems="center" justifyContent="flex-start" spacing={3}>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box className="fx_fs gap1">
                <LuUser style={{ fontSize: "20px", color: "var(--primary)" }} />
                <Box>
                  {auditUser && (
                    <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                      {auditUser.userName}
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box>
                <SimpleTextField
                  placeholder="Search Logs"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  fullWidth
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <SearchIcon
                        style={{ fontSize: 18, margin: "0px 12px", marginRight: 0, color: "#757575" }}
                      />
                    ),
                  }}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>

        <Box
          sx={{
            height: 250,
            overflow: "auto",
            overflowY: "auto",
            backgroundColor: "#f5f5f5",
            padding: "16px",
            borderRadius: "6px",
          }}
        >
          {filteredAuditLogs.map((log, idx) => (
            <Typography key={idx} variant="body2" sx={{ mb: 0.5, color: "text.secondary" }}>
              {log}
            </Typography>
          ))}
          {filteredAuditLogs.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              No logs match your search.
            </Typography>
          )}
        </Box>
      </CustomDialog>
    </>
  );
};

export default UserTable;
