"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Box, IconButton, Tooltip, Typography, Button } from "@mui/material";
import TableSkeleton from "@/components/table_components/TableSkeleton";

ModuleRegistry.registerModules([AllCommunityModule]);

const LinkedProjectViewsTableDialog = () => {
  const [loading, setLoading] = useState(true);
  const gridRef = useRef(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);


  const [rowData] = useState([
    {
      id: 1,
      projectName: "DNL Test Project",
      agreementType: "Contract Agreement",
      contractNumber: "#12467",
      owner: "Google Tenant",
      entityName: "Test",
    },
    {
      id: 2,
      projectName: "Demoq",
      agreementType: "Contract Agreement",
      contractNumber: "183",
      owner: "Google Tenant",
      entityName: "DKF",
    },
    {
      id: 3,
      projectName: "enterentity",
      agreementType: "Contract Agreement",
      contractNumber: "enterentity",
      owner: "Google Tenant",
      entityName: "",
    },
    {
      id: 4,
      projectName: "addresscheck",
      agreementType: "Contract Agreement",
      contractNumber: "addresscheck",
      owner: "Google Tenant",
      entityName: "Agreement",
    },
    {
      id: 5,
      projectName: "servicecheck",
      agreementType: "Service Agreement",
      contractNumber: "savedraft",
      owner: "Google Tenant",
      entityName: "Building",
    },
    {
      id: 6,
      projectName: "Decimalcheckuuuu",
      agreementType: "Contract Agreement",
      contractNumber: "linkcheck123",
      owner: "Google Tenant",
      entityName: "Building",
    },
    {
      id: 7,
      projectName: "savecheck2",
      agreementType: "Contract Agreement",
      contractNumber: "savecheck2",
      owner: "Google Tenant",
      entityName: "Copper",
    },
    {
      id: 8,
      projectName: "servicecheck",
      agreementType: "Contract Agreement",
      contractNumber: "servicecheck",
      owner: "Google Tenant",
      entityName: "",
    },
    {
      id: 9,
      projectName: "DNL Test Project",
      agreementType: "Contract Agreement",
      contractNumber: "#12467",
      owner: "Google Tenant",
      entityName: "Test",
    },
    {
      id: 10,
      projectName: "Demoq",
      agreementType: "Contract Agreement",
      contractNumber: "183",
      owner: "Google Tenant",
      entityName: "DKF",
    },
    {
      id: 11,
      projectName: "enterentity",
      agreementType: "Contract Agreement",
      contractNumber: "enterentity",
      owner: "Google Tenant",
      entityName: "",
    },
    {
      id: 12,
      projectName: "addresscheck",
      agreementType: "Contract Agreement",
      contractNumber: "addresscheck",
      owner: "Google Tenant",
      entityName: "Agreement",
    },
    {
      id: 13,
      projectName: "servicecheck",
      agreementType: "Service Agreement",
      contractNumber: "savedraft",
      owner: "Google Tenant",
      entityName: "Building",
    },
    {
      id: 14,
      projectName: "Decimalcheckuuuu",
      agreementType: "Contract Agreement",
      contractNumber: "linkcheck123",
      owner: "Google Tenant",
      entityName: "Building",
    },
    {
      id: 15,
      projectName: "savecheck2",
      agreementType: "Contract Agreement",
      contractNumber: "savecheck2",
      owner: "Google Tenant",
      entityName: "Copper",
    },
    {
      id: 16,
      projectName: "servicecheck",
      agreementType: "Contract Agreement",
      contractNumber: "servicecheck",
      owner: "Google Tenant",
      entityName: "",
    },
  ]);


  const columnDefs = useMemo(
    () => [
      {
        field: "projectName",
        headerName: "Project Name",
        minWidth: 200,
        cellRenderer: (params) => <span>{params.value}</span>,
      },
      {
        field: "agreementType",
        headerName: "Agreement Type",
        minWidth: 180,
        cellRenderer: (params) => (
          <span style={{ color: "#616161" }}>{params.value}</span>
        ),
      },
      {
        field: "contractNumber",
        headerName: "Contract Number",
        minWidth: 150,
        cellRenderer: (params) => (
          <span style={{ color: "#616161" }}>{params.value}</span>
        ),
      },
      {
        field: "owner",
        headerName: "Owner",
        minWidth: 150,
        cellRenderer: (params) => (
          <span style={{ color: "#616161" }}>{params.value}</span>
        ),
      },
      {
        field: "entityName",
        headerName: "Entity Name",
        minWidth: 150,
        cellRenderer: (params) => (
          <Tooltip title={params.value || ""} arrow>
            <Typography 
              variant="body2" 
              sx={{ 
                maxWidth: 150, 
                overflow: "hidden", 
                textOverflow: "ellipsis", 
                color: params.value ? "#616161" : "#9e9e9e" 
              }}
            >
              {params.value || ""}
            </Typography>
          </Tooltip>
        ),
      },
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  // Show all rows (no pagination)
  const paginatedRowData = rowData;

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "400px", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <Box style={{ width: "100%", height: "400px" }}>
          <AgGridReact
            ref={gridRef}
            rowData={paginatedRowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            getRowStyle={getRowStyle}
            headerHeight={40}
            rowHeight={40}
            pagination={false}
            animateRows={true}
          />
        </Box>
      )}
    </>
  );
};

export default LinkedProjectViewsTableDialog;
