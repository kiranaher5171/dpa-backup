"use client";
import MainLayout from '@/Layouts/MainLayout'
import React, { useState } from 'react'
import MainTable from './MainTable'
import SideDrawer from '@/components/SideDrawer'
import { Box, Button, Container, Grid, Typography, TextField, MenuItem, InputAdornment, Menu, ListItemIcon } from '@mui/material'
import { FaSearch, FaFileCsv, FaFileExcel, FaFilePdf } from "react-icons/fa";
import { FiDownload } from "react-icons/fi";
import { FiPlus } from "react-icons/fi";
import SystemUserForm from './SystemUserForm';
import { LuUserPlus } from "react-icons/lu";
import { LuMousePointerClick } from "react-icons/lu";


const page = () => {

    // Drawer state
    const [drawerOpen, setDrawerOpen] = useState(false)
    const [editingUser, setEditingUser] = useState(null)

    // Export menu state
    const [exportAnchorEl, setExportAnchorEl] = useState(null)
    const exportMenuOpen = Boolean(exportAnchorEl)

    // Actions menu state
    const [actionsAnchorEl, setActionsAnchorEl] = useState(null)
    const actionsMenuOpen = Boolean(actionsAnchorEl)

    const handleExportClick = (event) => {
        setExportAnchorEl(event.currentTarget)
    }

    const handleExportClose = () => {
        setExportAnchorEl(null)
    }

    const handleExport = (type) => {
        console.log(`Exporting as ${type}`)
        // Add your export logic here
        handleExportClose()
    }

    const handleActionsClick = (event) => {
        setActionsAnchorEl(event.currentTarget)
    }

    const handleActionsClose = () => {
        setActionsAnchorEl(null)
    }

    const handleAction = (action) => {
        console.log(`Performing action: ${action}`)
        // Add your actions logic here (archive, activate, etc.)
        handleActionsClose()
    }

    const handleEditUser = (user) => {
        setEditingUser(user)
        setDrawerOpen(true)
    }

    return (
        <>
            <MainLayout>
                <Container maxWidth sx={{ py: 2 }}>
                    <Grid container alignItems="flex-start" justifyContent='center' spacing={1}>
                        <Grid item lg={12} md={12} sm={12} xs={12}>


                            <Grid container spacing={2} alignItems="center">
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <Box className="fx_fs gap1">
                                        <Box className="heading-decorator" />
                                        <Typography variant='h5' className="primary fw6">System Users</Typography>
                                    </Box>
                                </Grid>
                                <Grid item lg md sm={6} xs={12}>
                                    <Box className="textfield-search">
                                        <TextField
                                            placeholder="Search"
                                            size="small"
                                            // sx={{ width: '250px' }}
                                            fullWidth={true}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start"><FaSearch /></InputAdornment>,
                                            }}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item xs="auto">
                                    <Box className="fx_fe gap1">
                                        <Button
                                            className="primary-outlined-btn mobile-ico-btn"
                                            startIcon={<LuMousePointerClick />}
                                            onClick={handleActionsClick}
                                            aria-controls={actionsMenuOpen ? 'actions-menu' : undefined}
                                            aria-haspopup="true"
                                            aria-expanded={actionsMenuOpen ? 'true' : undefined}
                                        >
                                            <span className="mobile-ico-btn-text">Actions</span>
                                        </Button>
                                        <Menu
                                            id="actions-menu"
                                            anchorEl={actionsAnchorEl}
                                            open={actionsMenuOpen}
                                            onClose={handleActionsClose}
                                            MenuListProps={{
                                                'aria-labelledby': 'actions-button',
                                            }}
                                            anchorOrigin={{
                                                vertical: 'bottom',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                        >
                                            <MenuItem onClick={() => handleAction('archive')}>
                                                Archive
                                            </MenuItem>
                                            <MenuItem onClick={() => handleAction('activate')}>
                                                Activate
                                            </MenuItem>
                                            <MenuItem onClick={() => handleAction('reactivate')}>
                                                Reactivate
                                            </MenuItem>
                                            <MenuItem onClick={() => handleAction('suspend')}>
                                                Suspend
                                            </MenuItem>
                                            <MenuItem onClick={() => handleAction('reset_password')}>
                                                Reset Password
                                            </MenuItem>
                                        </Menu>

                                        <Button
                                            className="primary-outlined-btn mobile-ico-btn"
                                            startIcon={<FiDownload />}
                                            onClick={handleExportClick}
                                            aria-controls={exportMenuOpen ? 'export-menu' : undefined}
                                            aria-haspopup="true"
                                            aria-expanded={exportMenuOpen ? 'true' : undefined}
                                        >
                                            <span className="mobile-ico-btn-text">Export</span>
                                        </Button>
                                        <Menu
                                            id="export-menu"
                                            anchorEl={exportAnchorEl}
                                            open={exportMenuOpen}
                                            onClose={handleExportClose}
                                            MenuListProps={{
                                                'aria-labelledby': 'export-button',
                                            }}
                                            anchorOrigin={{
                                                vertical: 'bottom',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                        >
                                            <MenuItem onClick={() => handleExport('csv')}>
                                                <ListItemIcon>
                                                    <FaFileCsv style={{ color: '#4CAF50', fontSize: '18px' }} />
                                                </ListItemIcon>
                                                CSV
                                            </MenuItem>
                                            <MenuItem onClick={() => handleExport('excel')}>
                                                <ListItemIcon>
                                                    <FaFileExcel style={{ color: '#217346', fontSize: '18px' }} />
                                                </ListItemIcon>
                                                Excel
                                            </MenuItem>
                                            <MenuItem onClick={() => handleExport('pdf')}>
                                                <ListItemIcon>
                                                    <FaFilePdf style={{ color: '#E53935', fontSize: '18px' }} />
                                                </ListItemIcon>
                                                PDF
                                            </MenuItem>
                                        </Menu>

                                        <Button
                                            variant='contained'
                                            className="primary-btn mobile-ico-btn"
                                            startIcon={<FiPlus />}
                                            onClick={() => setDrawerOpen(true)}
                                        >
                                            <span className="mobile-ico-btn-text">Add User</span>
                                        </Button>

                                    </Box>
                                </Grid>
                            </Grid>


                        </Grid>
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Box className="table-box">
                                <MainTable onEditUser={handleEditUser} />
                            </Box>
                        </Grid>
                    </Grid>

                </Container>

                <SideDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)}>
                    <Box className="right-drawer-header fx_fs gap1">
                        <LuUserPlus style={{ fontSize: '20px', color: 'var(--primary)' }} />
                        <Typography variant='h5' className="primary fw6">
                            {editingUser ? 'Edit System User' : 'Create System User'}
                        </Typography>
                    </Box>
                    <Box className="right-drawer-content">
                        <SystemUserForm />
                    </Box>
                    <Box className="right-drawer-footer fx_fe gap1">
                        <Button variant='contained' className="primary-outlined-btn" onClick={() => setDrawerOpen(false)}>Cancel</Button>
                        <Button variant='contained' className="primary-btn" autoFocus onClick={() => setDrawerOpen(false)}>Save</Button>
                    </Box>
                </SideDrawer>

            </MainLayout>
        </>
    )
}

export default page