"use client";
import React, { useEffect, useState, useRef, useCallback } from "react";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { VscCircleFilled } from "react-icons/vsc";
import { Box, IconButton, Tooltip, Button, Typography, Slide, Grid } from "@mui/material";
import TableSkeleton from "@/components/table_components/TableSkeleton";
import { FiEdit, FiTrash2, FiShield, FiX, FiEye } from "react-icons/fi";
import { MdDeleteSweep, MdRefresh } from "react-icons/md";
import { BsBox2Fill } from "react-icons/bs";
import SearchIcon from "@mui/icons-material/Search";
import CustomDialog from "@/components/CustomDialog";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import { LuUser } from "react-icons/lu";
import AgGridInfo from "@/components/table_components/AgGridInfo";
import AgGridPagination from "@/components/table_components/AgGridPagination";


ModuleRegistry.registerModules([AllCommunityModule]);

const MainTable = ({ onEditUser }) => {
  const [loading, setLoading] = useState(true);
  const [selectedRows, setSelectedRows] = useState([]);
  const gridRef = useRef(null);
  const [currentPage, setCurrentPage] = useState(1);

  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditUser, setAuditUser] = useState(null);

  const auditLogs = [
    "Vaibhav Updated Previous_Status From Active To Suspend Pending At 2025-12-22 13:25:08",
    "Vaibhav Updated Status From Suspend Pending To Suspended At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_By From 141 To 453 At 2025-12-22 13:25:08",
    "Vaibhav Updated Updated_Date From 12/17/2025 To 12/22/2025 At 2025-12-22 13:25:08",
    "Vaibhav Updated Previous_Status From Reactivation Pending To Active At 2025-12-17 11:21:45",
    "Vaibhav Updated Status From Active To Suspend Pending At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_By From 155 To 141 At 2025-12-17 11:21:45",
    "Vaibhav Updated Updated_Date From 10/5/2025 To 12/17/2025 At 2025-12-17 11:21:45",
    "Vaibhav Updated Previous_Status From Deactivated To Reactivation Pending At 2025-10-05 09:28:23",
    "Vaibhav Updated Status From Reactivation Pending To Active At 2025-10-05 09:28:23",
  ];

  const filteredAuditLogs = auditLogs.filter((log) =>
    log.toLowerCase().includes(auditSearch.toLowerCase())
  );

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  // Handle row selection change
  const onSelectionChanged = useCallback(() => {
    if (gridRef.current) {
      const selected = gridRef.current.api.getSelectedRows();
      setSelectedRows(selected);
    }
  }, []);

  // Reset selection (deselect all)
  const handleResetSelection = () => {
    if (gridRef.current) {
      gridRef.current.api.deselectAll();
      setSelectedRows([]);
    }
  };

  // Delete selected rows
  const handleDeleteSelected = () => {
    console.log("Delete selected rows:", selectedRows);
    // Add your delete logic here
    // After deletion, reset selection
    handleResetSelection();
  };

  const [rowData] = useState([
    {
      id: 1,
      fullName: "John Smith",
      systemRole: "Platform Owner",
      scope: "Full Access",
      email: "john.smith@example.com",
      contactNumber: "+1 234 567 890",
      status: "Active",
      lastLoggedIn: "2026-01-27 10:30 AM",
      auditLog: "View Logs",
    },
    {
      id: 2,
      fullName: "Sarah Johnson",
      systemRole: "Super Admin",
      scope: "Department",
      email: "sarah.j@example.com",
      contactNumber: "+1 234 567 891",
      status: "Active",
      lastLoggedIn: "2026-01-26 03:45 PM",
      auditLog: "View Logs",
    },
    {
      id: 3,
      fullName: "Michael Brown",
      systemRole: "Support Engineer",
      scope: "Limited",
      email: "m.brown@example.com",
      contactNumber: "+1 234 567 892",
      status: "Deactivated",
      lastLoggedIn: "2026-01-20 09:15 AM",
      auditLog: "View Logs",
    },
    {
      id: 4,
      fullName: "Emily Davis",
      systemRole: "Security Admin",
      scope: "Team",
      email: "emily.d@example.com",
      contactNumber: "+1 234 567 893",
      status: "Active",
      lastLoggedIn: "2026-01-27 08:00 AM",
      auditLog: "View Logs",
    },
    {
      id: 5,
      fullName: "Robert Wilson",
      systemRole: "Compliance Auditor",
      scope: "Limited",
      email: "r.wilson@example.com",
      contactNumber: "+1 234 567 894",
      status: "Suspended",
      lastLoggedIn: "2026-01-15 11:20 AM",
      auditLog: "View Logs",
    },
    {
      id: 6,
      fullName: "Jessica Martinez",
      systemRole: "Super Admin",
      scope: "Department",
      email: "j.martinez@example.com",
      contactNumber: "+1 234 567 895",
      status: "Active",
      lastLoggedIn: "2026-01-27 09:45 AM",
      auditLog: "View Logs",
    },
    {
      id: 7,
      fullName: "David Anderson",
      systemRole: "Platform Owner",
      scope: "Full Access",
      email: "d.anderson@example.com",
      contactNumber: "+1 234 567 896",
      status: "Active",
      lastLoggedIn: "2026-01-27 07:30 AM",
      auditLog: "View Logs",
    },
    {
      id: 8,
      fullName: "Amanda Taylor",
      systemRole: "Support Engineer",
      scope: "Limited",
      email: "a.taylor@example.com",
      contactNumber: "+1 234 567 897",
      status: "Awaiting Activation",
      lastLoggedIn: "Never",
      auditLog: "View Logs",
    },
    {
      id: 9,
      fullName: "Christopher Lee",
      systemRole: "Security Admin",
      scope: "Team",
      email: "c.lee@example.com",
      contactNumber: "+1 234 567 898",
      status: "Active",
      lastLoggedIn: "2026-01-26 04:20 PM",
      auditLog: "View Logs",
    },
    {
      id: 10,
      fullName: "Michelle Garcia",
      systemRole: "Compliance Auditor",
      scope: "Limited",
      email: "m.garcia@example.com",
      contactNumber: "+1 234 567 899",
      status: "Deactivated",
      lastLoggedIn: "2026-01-10 02:00 PM",
      auditLog: "View Logs",
    },
    {
      id: 11,
      fullName: "John Smith",
      systemRole: "Platform Owner",
      scope: "Full Access",
      email: "john.smith@example.com",
      contactNumber: "+1 234 567 890",
      status: "Active",
      lastLoggedIn: "2026-01-27 10:30 AM",
      auditLog: "View Logs",
    },
    {
      id: 12,
      fullName: "Sarah Johnson",
      systemRole: "Super Admin",
      scope: "Department",
      email: "sarah.j@example.com",
      contactNumber: "+1 234 567 891",
      status: "Active",
      lastLoggedIn: "2026-01-26 03:45 PM",
      auditLog: "View Logs",
    },
    {
      id: 13,
      fullName: "Michael Brown",
      systemRole: "Support Engineer",
      scope: "Limited",
      email: "m.brown@example.com",
      contactNumber: "+1 234 567 892",
      status: "Deactivated",
      lastLoggedIn: "2026-01-20 09:15 AM",
      auditLog: "View Logs",
    },
    {
      id: 14,
      fullName: "Emily Davis",
      systemRole: "Security Admin",
      scope: "Team",
      email: "emily.d@example.com",
      contactNumber: "+1 234 567 893",
      status: "Active",
      lastLoggedIn: "2026-01-27 08:00 AM",
      auditLog: "View Logs",
    },
    {
      id: 15,
      fullName: "Robert Wilson",
      systemRole: "Compliance Auditor",
      scope: "Limited",
      email: "r.wilson@example.com",
      contactNumber: "+1 234 567 894",
      status: "Suspended",
      lastLoggedIn: "2026-01-15 11:20 AM",
      auditLog: "View Logs",
    },
    {
      id: 16,
      fullName: "Jessica Martinez",
      systemRole: "Super Admin",
      scope: "Department",
      email: "j.martinez@example.com",
      contactNumber: "+1 234 567 895",
      status: "Active",
      lastLoggedIn: "2026-01-27 09:45 AM",
      auditLog: "View Logs",
    },
    {
      id: 17,
      fullName: "David Anderson",
      systemRole: "Platform Owner",
      scope: "Full Access",
      email: "d.anderson@example.com",
      contactNumber: "+1 234 567 896",
      status: "Active",
      lastLoggedIn: "2026-01-27 07:30 AM",
      auditLog: "View Logs",
    },
    {
      id: 18,
      fullName: "Amanda Taylor",
      systemRole: "Support Engineer",
      scope: "Limited",
      email: "a.taylor@example.com",
      contactNumber: "+1 234 567 897",
      status: "Awaiting Activation",
      lastLoggedIn: "Never",
      auditLog: "View Logs",
    },
    {
      id: 19,
      fullName: "Christopher Lee",
      systemRole: "Security Admin",
      scope: "Team",
      email: "c.lee@example.com",
      contactNumber: "+1 234 567 898",
      status: "Active",
      lastLoggedIn: "2026-01-26 04:20 PM",
      auditLog: "View Logs",
    },
    {
      id: 20,
      fullName: "Michelle Garcia",
      systemRole: "Compliance Auditor",
      scope: "Limited",
      email: "m.garcia@example.com",
      contactNumber: "+1 234 567 899",
      status: "Deactivated",
      lastLoggedIn: "2026-01-10 02:00 PM",
      auditLog: "View Logs",
    },
  ]);

  const handleEdit = (data) => {
    if (onEditUser) {
      onEditUser(data);
    }
    console.log("Edit user:", data);
  };

  const handleDelete = (data) => {
    console.log("Delete user:", data);
  };

  const handleAccessControl = (data) => {
    console.log("Access control for:", data);
  };

  const [colDefs] = useState([
    {
      headerName: "",
      field: "checkbox",
      width: 50,
      pinned: "left",
      checkboxSelection: true,
      headerCheckboxSelection: true,
      sortable: false,
      filter: false,
      suppressMenu: true,
      lockPosition: true,
    },
    {
      field: "fullName",
      headerName: "Full Name",
      minWidth: 180,
      cellRenderer: (params) => (
        <span>{params.value}</span>
      ),
    },
    {
      field: "systemRole",
      headerName: "System Role",
      minWidth: 160,
      maxWidth: 160,
      headerClass: "table-header-center",
      cellRenderer: (params) => {
        const roleColors = {
          "Platform Owner": { bg: "#e8f5e9", color: "#2e7d32" },
          "Super Admin": { bg: "#e3f2fd", color: "#1565c0" },
          "Security Admin": { bg: "#fff3e0", color: "#ef6c00" },
          "Support Engineer": { bg: "#e1f5fe", color: "#0277bd" },
          "Compliance Auditor": { bg: "#f3e5f5", color: "#7b1fa2" },
        };
        const style = roleColors[params.value] || { bg: "#f5f5f5", color: "#616161" };
        return (
          <span
            style={{
              backgroundColor: style.bg,
              color: style.color,
              // padding: "4px 10px",
              borderRadius: "4px",
              fontSize: "11px",
              fontWeight: 500,
              minWidth: '125px',
              display: 'flex',
              height: '25px',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {params.value}
          </span>
        );
      },
    },
    {
      field: "scope",
      headerName: "Scope",
      minWidth: 120,
    },
    {
      field: "email",
      headerName: "Email",
      minWidth: 200,
      filter: true,
      cellRenderer: (params) => (
        <span style={{ color: "#2b6bbb" }}>{params.value}</span>
      ),
    },
    {
      field: "contactNumber",
      headerName: "Contact Number",
      minWidth: 150,
    },
    {
      field: "status",
      headerName: "Status",
      minWidth: 160,
      maxWidth: 160,
      headerClass: "table-header-center",
      cellRenderer: (params) => {
        const statusColors = {
          Active: { bg: "#d6ffd6", color: "green" },                 // green-btn
          "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" }, // yellow-btn
          Deactivated: { bg: "#f5f5f5", color: "#616161" },          // gray-btn
          Suspended: { bg: "#ffecef", color: "red" },                // red-btn
        };
        const style = statusColors[params.value] || statusColors.Deactivated;
        return (
          <span
            style={{
              backgroundColor: style.bg,
              color: style.color,
              borderRadius: "4px",
              fontSize: "11px",
              fontWeight: 500,
              minWidth: "120px",
              display: "flex",
              height: "25px",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {params.value}
          </span>
        );
      },
    },
    {
      field: "lastLoggedIn",
      headerName: "Last Logged In",
      minWidth: 180,
      cellRenderer: (params) => (
        <span style={{ color: params.value === "Never" ? "#9e9e9e" : "inherit", fontStyle: params.value === "Never" ? "italic" : "normal" }}>
          {params.value}
        </span>
      ),
    },
    {
      headerName: "Actions",
      field: "actions",
      minWidth: 150,
      maxWidth: 150,
      headerClass: "table-header-center",
      pinned: "right",
      sortable: false,
      filter: false,
      lockPosition: true,
      cellRenderer: (params) => {
        return (
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1 }}>
            <Tooltip title="Edit" arrow>
              <IconButton
                size="small"
                className="ico-btn"
                onClick={() => handleEdit(params.data)}
                sx={{ color: "#2b6bbb" }}
              >
                <FiEdit size={16} />
              </IconButton>
            </Tooltip>

            <Tooltip title="View Audit Logs" arrow>
              <IconButton
                size="small"
                className="ico-btn"
                onClick={() => {
                  setAuditUser(params.data);
                  setAuditDialogOpen(true);
                }}
                sx={{ color: "#2b6bbb" }}
              >
                <FiEye size={16} />
              </IconButton>
            </Tooltip>

            <Tooltip title="Access Control" arrow>
              <IconButton
                size="small"
                className="ico-btn"
                onClick={() => handleAccessControl(params.data)}
                sx={{ color: "#ff9800" }}
              >
                <FiShield size={16} />
              </IconButton>
            </Tooltip> 

          </Box>
        );
      },
    },
  ]);

  const defaultColDef = {
    sortable: true,
    filter: false,
    autoHeight: true,
    resizable: false,
    suppressMovable: true,
    flex: 1,
  };

  const getRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  return (
    <>
      {loading ? (
        <Box style={{ width: "100%", height: "500px", overflow: "auto" }}>
          <TableSkeleton />
        </Box>
      ) : (
        <>
          <Box sx={{ width: "100%", height: "485px", position: "relative" }}>
            <AgGridReact
              ref={gridRef}
              rowData={rowData}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              headerHeight={40}
              rowHeight={40}
              rowSelection="multiple"
              suppressRowClickSelection={true}
              pagination={false}
              // paginationPageSize={10}
              // paginationPageSizeSelector={[10, 20, 50, 100]}
              // paginationPosition="bottom"
              animateRows={true}
              onSelectionChanged={onSelectionChanged}
            />
          </Box>
          <Box id="tb_footer" className="fx_sb" mt={1}>
            <AgGridInfo
              currentPage={currentPage}
              rowsPerPage={10}
              totalRows={rowData.length}
            />
            <AgGridPagination
              currentPage={currentPage}
              totalPages={Math.ceil(rowData.length / 10)}
              onPageChange={(_, page) => setCurrentPage(page)}
            />
          </Box>
        </>
      )}

      <CustomDialog
        open={auditDialogOpen}
        onClose={() => setAuditDialogOpen(false)}
        title="System User Audit Logs"
        maxWidth="md"
      >


        <Box my={2}>
          <Grid container alignItems="center" justifyContent='flex-start' spacing={3}>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box className="fx_fs gap1">

                <LuUser style={{ fontSize: '20px', color: 'var(--primary)' }} />

                <Box>
                  {auditUser && (
                    <Typography variant="subtitle2" sx={{ color: "text.secondary" }}>
                      {auditUser.fullName}
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>
            <Grid item lg={6} md={6} sm={12} xs={12}>
              <Box>
                <SimpleTextField
                  placeholder="Search Logs"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  fullWidth
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <SearchIcon
                        style={{ fontSize: 18, margin: '0px 12px', marginRight: 0, color: "#757575" }}
                      />
                    ),
                  }}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>



        <Box sx={{ height: 250, overflow: "auto", overflowY: "auto", backgroundColor: "#f5f5f5", padding: "16px", borderRadius: "6px" }}>
          {filteredAuditLogs.map((log, idx) => (
            <Typography
              key={idx}
              variant="body2"
              sx={{ mb: 0.5, color: "text.secondary" }}
            >
              {log}
            </Typography>
          ))}
          {filteredAuditLogs.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              No logs match your search.
            </Typography>
          )}
        </Box>
      </CustomDialog>

      {/* Bottom Action Bar - ClickUp Style */}
      {/* Full-width wrapper positioned in content area, centers the bar with flexbox */}
      {/* <Box
        sx={{
          position: "fixed",
          bottom: 24,
          left: 250, // Sidebar width
          right: 0,
          display: "flex",
          justifyContent: "center",
          zIndex: 1300,
          pointerEvents: selectedRows.length > 0 ? "auto" : "none",
        }}
      >
        <Slide direction="up" in={selectedRows.length > 0} mountOnEnter unmountOnExit>
          <Box
            sx={{
              backgroundColor: "#1a1f36",
              borderRadius: "12px",
              padding: "12px 24px",
              display: "flex",
              alignItems: "center",
              gap: 3,
              boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
              minWidth: "400px",
            }}
          >
             
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Box
                sx={{
                  backgroundColor: "#3b82f6",
                  borderRadius: "6px",
                  padding: "4px 12px",
                  minWidth: "32px",
                  textAlign: "center",
                }}
              >
                <Typography sx={{ color: "#fff", fontWeight: 600, fontSize: "14px" }}>
                  {selectedRows.length}
                </Typography>
              </Box>
              <Typography sx={{ color: "#a0aec0", fontSize: "14px" }}>
                {selectedRows.length === 1 ? "item selected" : "items selected"}
              </Typography>
            </Box>

             
            <Box sx={{ width: "1px", height: "24px", backgroundColor: "#374151" }} />

            
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Tooltip title="Delete Selected" arrow>
                <Button
                  onClick={handleDeleteSelected}
                  startIcon={<MdDeleteSweep size={18} />}
                  sx={{
                    color: "#f87171",
                    textTransform: "none",
                    fontSize: "13px",
                    fontWeight: 500,
                    padding: "6px 12px",
                    borderRadius: "8px",
                    "&:hover": {
                      backgroundColor: "rgba(248, 113, 113, 0.1)",
                    },
                  }}
                >
                  Delete
                </Button>
              </Tooltip>

              <Tooltip title="Reset Selection" arrow>
                <Button
                  onClick={handleResetSelection}
                  startIcon={<MdRefresh size={18} />}
                  sx={{
                    color: "#60a5fa",
                    textTransform: "none",
                    fontSize: "13px",
                    fontWeight: 500,
                    padding: "6px 12px",
                    borderRadius: "8px",
                    "&:hover": {
                      backgroundColor: "rgba(96, 165, 250, 0.1)",
                    },
                  }}
                >
                  Reset
                </Button>
              </Tooltip>
            </Box>

           
            <Box sx={{ width: "1px", height: "24px", backgroundColor: "#374151" }} />

           
            <Tooltip title="Dismiss" arrow>
              <IconButton
                onClick={handleResetSelection}
                size="small"
                sx={{
                  color: "#9ca3af",
                  "&:hover": {
                    backgroundColor: "rgba(156, 163, 175, 0.1)",
                    color: "#fff",
                  },
                }}
              >
                <FiX size={18} />
              </IconButton>
            </Tooltip>
          </Box>
        </Slide>
      </Box> */}
    </>
  );
};

export default MainTable;
