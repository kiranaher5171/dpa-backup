import React, { useState } from 'react'
import { Box, Grid } from '@mui/material'
import SimpleTextField from '@/components/FormInputComponents/SimpleTextField'
import SingleSelectAutocomplete from '@/components/FormInputComponents/SingleSelectAutocomplete'
import ContactNumberInput from '@/components/FormInputComponents/ContactNumberInput'
import MultiSelectAutocomplete from '@/components/FormInputComponents/MultiSelectAutocomplete'

const SystemUserForm = () => {
    const [contactNumber, setContactNumber] = useState("");

    return (
        <>
            <Grid container alignItems="flex-start" justifyContent='center' spacing={3}>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SimpleTextField label="First Name" fullWidth required />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SimpleTextField label="Last Name" fullWidth required />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete label="System Role" fullWidth required options={[]} />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SimpleTextField label="Email" fullWidth required />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <ContactNumberInput 
                            fullWidth
                            required
                            defaultCountry="US"
                            value={contactNumber}
                            onChange={setContactNumber}
                        />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete label="Country" fullWidth required options={[]} />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete label="State" fullWidth required options={[]} />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <SingleSelectAutocomplete label="City" fullWidth required options={[]} />
                    </Box>
                </Grid>
                <Grid item lg={12} md={12} sm={12} xs={12}>
                    <Box>
                        <MultiSelectAutocomplete label="Tenants" fullWidth required options={[]} multiple />
                    </Box>
                </Grid>
            </Grid>

        </>
    )
}

export default SystemUserForm