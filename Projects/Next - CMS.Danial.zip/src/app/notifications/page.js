"use client";

import MainLayout from "@/Layouts/MainLayout";
import React, { useState } from "react";
import { Box, Tabs, Tab, Container } from "@mui/material";
import AdministrativeNotifications from "./administrativeNotifications";
import OperationalNotifications from "./operationalNotifications";

function TabPanel({ children, value, index, ...rest }) {
  return (
    <div role="tabpanel" hidden={value !== index} id={`notifications-tabpanel-${index}`} aria-labelledby={`notifications-tab-${index}`} {...rest} style={{ display: value === index ? "block" : "none" }}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

export default function NotificationsPage() {
  const [tabValue, setTabValue] = useState(0);
  const [administrativeCount, setAdministrativeCount] = useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <MainLayout>
      <Box sx={{ width: "100%" }} mt={2}>
        <Container maxWidth>
          <Box sx={{ borderBottom: 1, borderColor: '#d2d2d2'}}>
            <Tabs
              value={tabValue}
              onChange={handleTabChange}
              variant="scrollable"
              scrollButtons="auto"
              allowScrollButtonsMobile
              className="form-tabs"
              aria-label="notifications tabs"
            >
              <Tab label={`Administrative Notifications (${administrativeCount})`} id="notifications-tab-0" aria-controls="notifications-tabpanel-0" />
              <Tab label="Operational Notifications" id="notifications-tab-1" aria-controls="notifications-tabpanel-1" />
            </Tabs>
          </Box>
        </Container>
        <TabPanel value={tabValue} index={0}>
          <AdministrativeNotifications onCountChange={setAdministrativeCount} />
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <OperationalNotifications />
        </TabPanel>
      </Box>

    </MainLayout >
  );
}
