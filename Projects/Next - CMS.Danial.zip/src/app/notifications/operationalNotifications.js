"use client";

import React, { useState, useMemo } from "react";
import {
  Box,
  Container,
  Grid,
  Typography,
  TextField,
  InputAdornment,
  IconButton,
  Snackbar,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import CloseIcon from "@mui/icons-material/Close";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";

ModuleRegistry.registerModules([AllCommunityModule]);

const OPERATIONAL_ALERTS_DATA = [
  {
    id: 1,
    contractName: "DNL Main Contract",
    alertType: "Expiry Reminder",
    dueDate: "15/3/2026",
    status: "Pending",
  },
];

function SearchBar({ placeholder = "Search", value, onChange }) {
  return (
    <TextField
      placeholder={placeholder}
      size="small"
      value={value || ""}
      onChange={(e) => onChange?.(e.target.value)}
      sx={{ minWidth: 220 }}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <SearchIcon sx={{ fontSize: 20, color: "#757575" }} />
          </InputAdornment>
        ),
        endAdornment: (
          <InputAdornment position="end">
            <IconButton size="small" edge="end" aria-label="dropdown">
              <KeyboardArrowDownIcon fontSize="small" />
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
}

function EmptyNotificationsState() {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        color: "text.secondary",
        height: "100%",
        width: "100%",
      }}
    >
      <SearchIcon sx={{ fontSize: 30, mb: 1, color: "#bdbdbd" }} />
      <Typography variant="body2">No notifications found.</Typography>
    </Box>
  );
}

const STATUS_BADGE_STYLES = {
  Active: { bg: "#d6ffd6", color: "green" },
  Pending: { bg: "#fcf3cc", color: "#D0B404" },
  Resolved: { bg: "#e8f5e9", color: "#2e7d32" },
  Overdue: { bg: "#ffecef", color: "#c62828" },
};

function StatusBadge({ value }) {
  const style = STATUS_BADGE_STYLES[value] || STATUS_BADGE_STYLES.Pending;
  return (
    <span
      style={{
        backgroundColor: style.bg,
        color: style.color,
        borderRadius: "4px",
        fontSize: "11px",
        fontWeight: 500,
        minWidth: "80px",
        display: "flex",
        height: "25px",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {value}
    </span>
  );
}

export default function OperationalNotifications() {
  const [alertsSearch, setAlertsSearch] = useState("");
  const [workflowSearch, setWorkflowSearch] = useState("");
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");

  const handleSnackbarClose = (event, reason) => {
    if (reason === "clickaway") return;
    setSnackbarOpen(false);
  };

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = useMemo(
    () => (params) => ({
      backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
    }),
    []
  );

  const operationalAlertsColDefs = useMemo(
    () => [
      { field: "contractName", headerName: "Contract Name", minWidth: 180, cellStyle: { fontSize: "13px" } },
      { field: "alertType", headerName: "Alert Type", minWidth: 140, cellStyle: { fontSize: "13px" } },
      { field: "dueDate", headerName: "Due Date", minWidth: 120, cellStyle: { fontSize: "13px" } },
      {
        field: "status",
        headerName: "Status",
        minWidth: 120,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (params.value ? <StatusBadge value={params.value} /> : null),
      },
    ],
    []
  );

  return (
    <Container maxWidth sx={{ py: 2 }}>
      <Grid container alignItems="flex-start" justifyContent="center" spacing={2}> 

        {/* Section 1: Operational Alerts */}
        <Grid item lg={12} md={12} sm={12} xs={12}>
          <Box className="table-box">
            <Box mb={2}>
              <Grid container alignItems="center" spacing={2}>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <Typography variant="h5" className="primary fw6">
                    Operational Alerts
                  </Typography>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12} className="fx_fe">
                  <SearchBar placeholder="Search" value={alertsSearch} onChange={setAlertsSearch} />
                </Grid>
              </Grid>
            </Box>
            <Box sx={{ width: "100%", height: "10vh", minHeight: "10vh" }}>
              <AgGridReact
                rowData={OPERATIONAL_ALERTS_DATA}
                columnDefs={operationalAlertsColDefs}
                defaultColDef={defaultColDef}
                getRowStyle={getRowStyle}
                headerHeight={40}
                rowHeight={40}
                suppressCellFocus={true}
                pagination={false}
                animateRows={true}
                domLayout="normal"
              />
            </Box>
          </Box>
        </Grid>

        {/* Section 2: Workflow Notifications - Empty */}
        <Grid item lg={12} md={12} sm={12} xs={12}>
          <Box className="table-box">
            <Box mb={2}>
              <Grid container alignItems="center" spacing={2}>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <Typography variant="h5" className="primary fw6">
                    Workflow Notifications
                  </Typography>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12} className="fx_fe">
                  <SearchBar placeholder="Search" value={workflowSearch} onChange={setWorkflowSearch} />
                </Grid>
              </Grid>
            </Box>
            <Box sx={{ width: "100%", height: "10vh", minHeight: "10vh" }}>
              <EmptyNotificationsState />
            </Box>
          </Box>
        </Grid>
      </Grid>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        message={snackbarMessage}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        ContentProps={{
          sx: {
            backgroundColor: "#1976d2",
            color: "#fff",
          },
        }}
        action={
          <IconButton size="small" aria-label="close" color="inherit" onClick={handleSnackbarClose}>
            <CloseIcon fontSize="small" />
          </IconButton>
        }
      />
    </Container>
  );
}
