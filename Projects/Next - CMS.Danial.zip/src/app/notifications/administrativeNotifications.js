"use client";

import React, { useState, useMemo, useEffect } from "react";
import {
  Box,
  Container,
  Grid,
  Typography,
  TextField,
  InputAdornment,
  IconButton,
  Button,
  Snackbar,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import CloseIcon from "@mui/icons-material/Close";
import { FiCheck, FiX } from "react-icons/fi";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";

ModuleRegistry.registerModules([AllCommunityModule]);

const ASSIGN_USER_DATA = [
  {
    id: 1,
    projectName: "DNL Test Project",
    assignedUser: "Akhil Mitta",
    createdBy: "Google Admin",
    createdDate: "1/6/2026",
    status: "Approval Pending",
  },
];

const CONTRACT_PARTY_DATA = [
  {
    id: 1,
    contractorName: "Colorcheck",
    tenantName: "Google Tenant",
    status: "Approval Pending",
    contractorPartyType: "Contractor",
  },
];

const CONTRACT_PARTY_NOTIFICATIONS_INITIAL = [
  { id: 1, type: "approved", partyName: "AM Legal Associates" },
  { id: 2, type: "rejected", partyName: "Smith & Co" },
  { id: 3, type: "approved", partyName: "Baker Contractors Ltd" },
  { id: 4, type: "rejected", partyName: "Delta Solutions" },
  { id: 5, type: "approved", partyName: "Prime Builders Inc" },
];

function SearchBar({ placeholder = "Search", value, onChange }) {
  return (
    <TextField
      placeholder={placeholder}
      size="small"
      value={value || ""}
      onChange={(e) => onChange?.(e.target.value)}
      sx={{ minWidth: 220 }}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <SearchIcon sx={{ fontSize: 20, color: "#757575" }} />
          </InputAdornment>
        ),
        endAdornment: (
          <InputAdornment position="end">
            <IconButton size="small" edge="end" aria-label="dropdown">
              <KeyboardArrowDownIcon fontSize="small" />
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
}

function EmptyNotificationsState() {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        color: "text.secondary",
        height: "100%",
        width: "100%",
      }}
    >
      <SearchIcon sx={{ fontSize: 30, mb: 1, color: "#bdbdbd" }} />
      <Typography variant="body2">No notifications found.</Typography>
    </Box>
  );
}

const STATUS_BADGE_STYLES = {
  Active: { bg: "#d6ffd6", color: "green" },
  "Awaiting Activation": { bg: "#fcf3cc", color: "#D0B404" },
  "Approval Pending": { bg: "#fcf3cc", color: "#D0B404" },
  Deactivated: { bg: "#f5f5f5", color: "#616161" },
  Suspended: { bg: "#ffecef", color: "red" },
};

function StatusBadge({ value }) {
  const style = STATUS_BADGE_STYLES[value] || STATUS_BADGE_STYLES["Approval Pending"];
  return (
    <span
      style={{
        backgroundColor: style.bg,
        color: style.color,
        borderRadius: "4px",
        fontSize: "11px",
        fontWeight: 500,
        minWidth: "120px",
        display: "flex",
        height: "25px",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {value}
    </span>
  );
}

export default function AdministrativeNotifications({ onCountChange }) {
  const [assignUserSearch, setAssignUserSearch] = useState("");
  const [projectRemovalSearch, setProjectRemovalSearch] = useState("");
  const [contractPartySearch, setContractPartySearch] = useState("");
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarType, setSnackbarType] = useState("approve"); // "approve" | "reject"
  const [contractPartyNotifications, setContractPartyNotifications] = useState(CONTRACT_PARTY_NOTIFICATIONS_INITIAL);

  const notificationCount =
    ASSIGN_USER_DATA.length + CONTRACT_PARTY_DATA.length + contractPartyNotifications.length;
  useEffect(() => {
    onCountChange?.(notificationCount);
  }, [notificationCount, onCountChange]);

  const removeContractPartyNotification = (id) => {
    setContractPartyNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === "clickaway") return;
    setSnackbarOpen(false);
  };

  const handleApproveAssign = (id) => {
    setSnackbarMessage("Approved successfully");
    setSnackbarType("approve");
    setSnackbarOpen(true);
  };
  const handleRejectAssign = (id) => {
    setSnackbarMessage("Rejected successfully");
    setSnackbarType("reject");
    setSnackbarOpen(true);
  };
  const handleApproveContract = (id) => {
    setSnackbarMessage("Approved successfully");
    setSnackbarType("approve");
    setSnackbarOpen(true);
  };
  const handleRejectContract = (id) => {
    setSnackbarMessage("Rejected successfully");
    setSnackbarType("reject");
    setSnackbarOpen(true);
  };

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      filter: false,
      autoHeight: true,
      resizable: false,
      suppressMovable: true,
      flex: 1,
    }),
    []
  );

  const getRowStyle = useMemo(
    () => (params) => ({
      backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
    }),
    []
  );

  const assignUserColDefs = useMemo(
    () => [
      { field: "projectName", headerName: "Project Name", minWidth: 160, cellStyle: { fontSize: "13px" } },
      { field: "assignedUser", headerName: "Assigned User", minWidth: 140, cellStyle: { fontSize: "13px" } },
      { field: "createdBy", headerName: "Created By", minWidth: 130, cellStyle: { fontSize: "13px" } },
      { field: "createdDate", headerName: "Created Date", minWidth: 120, cellStyle: { fontSize: "13px" } },
      {
        field: "status",
        headerName: "Status",
        minWidth: 140,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (params.value ? <StatusBadge value={params.value} /> : null),
      },
      {
        headerName: "Approve",
        minWidth: 100,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (
          <Button
            size="small"
            startIcon={<FiCheck style={{ color: "green" }} />}
            onClick={() => handleApproveAssign(params.data?.id)}
            sx={{ color: "green", textTransform: "none", minWidth: "auto" }}
          >
            Approve
          </Button>
        ),
      },
      {
        headerName: "Reject",
        minWidth: 90,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (
          <Button
            size="small"
            startIcon={<FiX style={{ color: "#d32f2f" }} />}
            onClick={() => handleRejectAssign(params.data?.id)}
            sx={{ color: "#d32f2f", textTransform: "none", minWidth: "auto" }}
          >
            Reject
          </Button>
        ),
      },
    ],
    []
  );

  const contractPartyColDefs = useMemo(
    () => [
      { field: "contractorName", headerName: "Contractor Name", minWidth: 160, cellStyle: { fontSize: "13px" } },
      { field: "tenantName", headerName: "Tenant Name", minWidth: 140, cellStyle: { fontSize: "13px" } },
      {
        field: "status",
        headerName: "Status",
        minWidth: 140,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (params.value ? <StatusBadge value={params.value} /> : null),
      },
      {
        field: "contractorPartyType",
        headerName: "Contractor Party Type",
        minWidth: 160,
        cellStyle: { fontSize: "13px" },
      },
      {
        headerName: "Approve",
        minWidth: 100,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (
          <Button
            size="small"
            startIcon={<FiCheck style={{ color: "green" }} />}
            onClick={() => handleApproveContract(params.data?.id)}
            sx={{ color: "green", textTransform: "none", minWidth: "auto" }}
          >
            Approve
          </Button>
        ),
      },
      {
        headerName: "Reject",
        minWidth: 90,
        sortable: false,
        cellStyle: { fontSize: "13px" },
        cellRenderer: (params) => (
          <Button
            size="small"
            startIcon={<FiX style={{ color: "#d32f2f" }} />}
            onClick={() => handleRejectContract(params.data?.id)}
            sx={{ color: "#d32f2f", textTransform: "none", minWidth: "auto" }}
          >
            Reject
          </Button>
        ),
      },
    ],
    []
  );

  return (
    <Container maxWidth sx={{ py: 2 }}>
      <Grid container alignItems="flex-start" justifyContent="center" spacing={2}>

        {/* Section 1: Notifications Of Assign User to Project */}
        <Grid item lg={12} md={12} sm={12} xs={12}>
          <Box className="table-box">
            <Box mb={2}>
              <Grid container alignItems="center" spacing={2}>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <Typography variant="h5" className="primary fw6">Notifications Of Assign User to Project</Typography>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12} className="fx_fe">
                  <SearchBar placeholder="Search" value={assignUserSearch} onChange={setAssignUserSearch} />
                </Grid>
              </Grid>
            </Box>
            <Box sx={{ width: "100%", height: '10vh', minHeight: '10vh' }}>
              <AgGridReact
                rowData={ASSIGN_USER_DATA}
                columnDefs={assignUserColDefs}
                defaultColDef={defaultColDef}
                getRowStyle={getRowStyle}
                headerHeight={40}
                rowHeight={40}
                suppressCellFocus={true}
                pagination={false}
                animateRows={true}
                domLayout="normal"
              />
            </Box>
          </Box>
        </Grid>

        {/* Section 2: Notifications Of Project Removal - Empty */}
        <Grid item lg={12} md={12} sm={12} xs={12}>
          <Box className="table-box">
            <Box mb={2}>
              <Grid container alignItems="center" spacing={2}>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <Typography variant="h5" className="primary fw6">Notifications Of Project Removal</Typography>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12} className="fx_fe">
                  <SearchBar placeholder="Search" value={projectRemovalSearch} onChange={setProjectRemovalSearch} />
                </Grid>
              </Grid>
            </Box>
            <Box sx={{ width: "100%", height: '10vh', minHeight: '10vh' }}>
              <EmptyNotificationsState />
            </Box>
          </Box>
        </Grid>

        {/* Section 3: Notifications Of Contract Party Addition */}
        <Grid item lg={12} md={12} sm={12} xs={12}>
          <Box className="table-box">
            <Box mb={2}>
              <Grid container alignItems="center" spacing={2}>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <Typography variant="h5" className="primary fw6">Notifications Of Contract Party Addition</Typography>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12} className="fx_fe">
                  <SearchBar placeholder="Search" value={contractPartySearch} onChange={setContractPartySearch} />
                </Grid>
              </Grid>
            </Box>
            <Box sx={{ width: "100%", height: '10vh', minHeight: '10vh' }}>
              <AgGridReact
                rowData={CONTRACT_PARTY_DATA}
                columnDefs={contractPartyColDefs}
                defaultColDef={defaultColDef}
                getRowStyle={getRowStyle}
                headerHeight={40}
                rowHeight={40}
                suppressCellFocus={true}
                pagination={false}
                animateRows={true}
                domLayout="normal"
              />
            </Box>
            <Box mt={1}>
              {contractPartyNotifications.map((item) => (
                <Box
                  key={item.id}
                  mb={2}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: 2,
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      color: item.type === "approved" ? "#2e7d32" : "#c62828",
                      flex: 1,
                      minWidth: 0,
                    }}
                  >
                    The request to add a contract party "{item.partyName}" has been {item.type === "approved" ? "approved" : "rejected"}.
                    <IconButton
                      size="small"
                      aria-label="close notification"
                      onClick={() => removeContractPartyNotification(item.id)}
                      sx={{ flexShrink: 0, color: item.type === "approved" ? "#2e7d32" : "#c62828", ml: 1 }}
                    >
                      <CloseIcon fontSize="small" />
                    </IconButton>
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>
        </Grid>
      </Grid>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        message={snackbarMessage}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        ContentProps={{
          sx: {
            backgroundColor: snackbarType === "reject" ? "#d32f2f" : "green",
            color: "#fff",
          },
        }}
        action={
          <IconButton size="small" aria-label="close" color="inherit" onClick={handleSnackbarClose}>
            <CloseIcon fontSize="small" />
          </IconButton>
        }
      />
    </Container>
  );
}
