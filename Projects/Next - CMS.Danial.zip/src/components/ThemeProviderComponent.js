"use client";
import { ThemeProvider, createTheme } from "@mui/material";
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';
import PropTypes from 'prop-types';

// Custom theme matching root.css variables
const theme = createTheme({
  palette: {
    primary: {
      main: '#172238',      // --primary
      light: '#2a3a52',
      dark: '#0f1829',
      contrastText: '#ffffff',
    },
    secondary: {
      main: '#2b6bbb',      // --secondary
      light: '#4a8ad4',
      dark: '#1f5599',
      contrastText: '#ffffff',
    },
    success: {
      main: '#008000',      // --success (green)
      light: '#4caf50',
      dark: '#006600',
      contrastText: '#ffffff',
    },
    error: {
      main: '#ff0000',      // --error
      light: '#ff4444',
      dark: '#cc0000',
      contrastText: '#ffffff',
    },
    warning: {
      main: '#ffc000',      // --pending/warning
      light: '#ffcd38',
      dark: '#b38600',
      contrastText: '#000000',
    },
    info: {
      main: '#2196f3',
      light: '#64b5f6',
      dark: '#1976d2',
      contrastText: '#ffffff',
    },
    text: {
      primary: '#172238',   // --primary
      secondary: '#5b5b5b', // --text
      disabled: '#abb5be',  // --tertiary
    },
    background: {
      default: '#ffffff',   // --white
      paper: '#ffffff',
    },
    grey: {
      50: '#fafafa',
      100: '#f5f5f5',
      200: '#eeeeee',
      300: '#e0e0e0',
      400: '#bdbdbd',
      500: '#9e9e9e',
      600: '#757575',
      700: '#616161',
      800: '#424242',
      900: '#212121',
    },
    divider: '#e6e6e6',
  },
  typography: {
    fontFamily: 'Poppins, sans-serif',
    h1: {
      fontSize: '38px',
      lineHeight: '58px',
      fontWeight: 700,
    },
    h2: {
      fontSize: '32px',
      lineHeight: '48px',
      fontWeight: 600,
    },
    h3: {
      fontSize: '28px',
      lineHeight: '40px',
      fontWeight: 600,
    },
    h4: {
      fontSize: '22px',
      lineHeight: '32px',
      fontWeight: 600,
    },
    h5: {
      fontSize: '16px',
      lineHeight: '22px',
      fontWeight: 600,
    },
    h6: {
      fontSize: '13px',
      lineHeight: '20px',
      fontWeight: 600,
    },
    body1: {
      fontSize: '14px',
      lineHeight: '22px',
    },
    body2: {
      fontSize: '13px',
      lineHeight: '20px',
    },
    button: {
      textTransform: 'none',
      fontWeight: 500,
    },
    caption: {
      fontSize: '11px',
      lineHeight: '16px',
    },
  },
  shape: {
    borderRadius: 8,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 500,
          borderRadius: '6px',
        },
        sizeLarge: {
          padding: '12px 28px',
          fontSize: '15px',
        },
        sizeMedium: {
          padding: '8px 20px',
          fontSize: '14px',
        },
        sizeSmall: {
          padding: '4px 14px',
          fontSize: '12px',
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 500,
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            '& fieldset': {
              borderColor: '#e6e6e6',
            },
            '&:hover fieldset': {
              borderColor: '#abb5be',
            },
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-notchedOutline': {
            borderColor: '#e6e6e6',
          },
          '&:hover .MuiOutlinedInput-notchedOutline': {
            borderColor: '#abb5be',
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
        },
      },
    },
    MuiAlert: {
      styleOverrides: {
        standardSuccess: {
          backgroundColor: 'rgba(0, 128, 0, 0.1)',
          color: '#008000',
        },
        standardError: {
          backgroundColor: 'rgba(255, 0, 0, 0.1)',
          color: '#ff0000',
        },
        standardWarning: {
          backgroundColor: 'rgba(255, 192, 0, 0.15)',
          color: '#b38600',
        },
        standardInfo: {
          backgroundColor: 'rgba(33, 150, 243, 0.1)',
          color: '#1976d2',
        },
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          fontSize: '10px',
          fontWeight: 600,
          backgroundColor: '#000000',
          borderRadius: 0,
        },
        arrow: {
          color: '#000000',
        },
      },
    },
  },
});

const ThemeProviderComponent = ({ children, nonce }) => {
  const cache = createCache({
    key: 'dpa',
    nonce: nonce,
    prepend: true,
  });

  return (
    <CacheProvider value={cache}>
      <ThemeProvider theme={theme}>
        {children}
      </ThemeProvider>
    </CacheProvider>
  );
};

ThemeProviderComponent.propTypes = {
  children: PropTypes.node.isRequired,
  nonce: PropTypes.string.isRequired,
};

export default ThemeProviderComponent;
