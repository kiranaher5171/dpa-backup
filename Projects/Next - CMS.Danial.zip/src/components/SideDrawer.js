import * as React from 'react';
import Drawer from '@mui/material/Drawer';

export default function SideDrawer({ children, open, onClose, width }) {
    const [isOpen, setIsOpen] = React.useState(false);

    const handleClose = (event) => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }
        setIsOpen(false);
        if (onClose) onClose();
    };

    React.useEffect(() => {
        if (open !== undefined) {
            setIsOpen(open);
        }
    }, [open]);

    const paperWidth =
        width == null
            ? undefined
            : typeof width === 'number'
                ? `${width}px`
                : typeof width === 'object' && width !== null
                    ? Object.fromEntries(
                        Object.entries(width).map(([k, v]) => [k, typeof v === 'number' ? `${v}px` : v])
                    )
                    : width;

    return (
        <Drawer
            id="side-drawer"
            anchor="right"
            open={open !== undefined ? open : isOpen}
            onClose={handleClose}
            PaperProps={paperWidth != null ? { sx: { width: paperWidth, maxWidth: '100vw' } } : undefined}
        >
            {children}
        </Drawer>
    );
}
