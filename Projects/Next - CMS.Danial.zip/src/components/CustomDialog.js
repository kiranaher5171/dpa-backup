"use client";
import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';

export default function CustomDialog({
    children,
    open,
    onClose,
    title,
    actions,
    maxWidth = 'sm',
    fullWidth = true,
    showCloseButton = true,
    ...otherProps
}) {
    const [isOpen, setIsOpen] = React.useState(false);

    const handleClose = (event, reason) => {
        // Prevent closing on backdrop click or escape if needed
        if (reason === 'backdropClick' && otherProps.disableBackdropClick) {
            return;
        }
        if (reason === 'escapeKeyDown' && otherProps.disableEscapeKeyDown) {
            return;
        }

        setIsOpen(false);
        if (onClose) onClose(event, reason);
    };

    React.useEffect(() => {
        if (open !== undefined) {
            setIsOpen(open);
        }
    }, [open]);

    return (
        <Dialog
            open={open !== undefined ? open : isOpen}
            onClose={handleClose}
            maxWidth={maxWidth}
            fullWidth={fullWidth}
            {...otherProps}
        >
            {(title || showCloseButton) && (
                <DialogTitle>
                    {title}
                    {showCloseButton && (
                        <IconButton
                            aria-label="close"
                            onClick={handleClose}
                            sx={{
                                position: 'absolute',
                                right: 8,
                                top: 8,
                                color: (theme) => theme.palette.grey[500],
                            }}
                        >
                            <CloseIcon />
                        </IconButton>
                    )}
                </DialogTitle>
            )}
            <DialogContent>
                {children}
            </DialogContent>
            {actions && (
                <DialogActions>
                    {actions}
                </DialogActions>
            )}
        </Dialog>
    );
}

