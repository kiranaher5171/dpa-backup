"use client";

import React from "react";
import Link from "next/link";
import { Box, Typography } from "@mui/material";

/**
 * Reusable white/stat card showing a value and label.
 * @param {string|number} value - Main value (e.g. count) to display
 * @param {string} label - Label text below the value (e.g. "Total Tenants", "Active")
 * @param {string} [href] - Optional link URL; when set, the card is clickable
 * @param {string} [className="tm_box"] - CSS class for the card container
 * @param {string} [valueVariant="h2"] - MUI Typography variant for the value
 * @param {string} [labelVariant="body1"] - MUI Typography variant for the label
 * @param {string} [valueColor] - Optional color for the value (e.g. "#2b6bbb", "green", "#D0B404")
 * @param {object} [sx] - Optional MUI sx props for the Box
 */
const WhiteCard = ({
  value,
  label,
  href,
  className = "tm_box",
  valueVariant = "h2",
  labelVariant = "body1",
  valueColor,
  sx,
  ...rest
}) => {
  const cardContent = (
    <Box
      className={className}
      sx={{
        ...(href && {
          cursor: "pointer",
          transition: "opacity 0.2s, box-shadow 0.2s",
          "&:hover": { opacity: 0.9, boxShadow: 2 },
        }),
        ...sx,
      }}
      {...rest}
    >
      <Typography className="fw6" variant={valueVariant} sx={valueColor ? { color: valueColor } : undefined}>
        {value}
      </Typography>
      <Typography variant={labelVariant}>{label}</Typography>
    </Box>
  );

  if (href) {
    return (
      <Link href={href} style={{ textDecoration: "none", color: "inherit" }}>
        {cardContent}
      </Link>
    );
  }

  return cardContent;
};

export default WhiteCard;
