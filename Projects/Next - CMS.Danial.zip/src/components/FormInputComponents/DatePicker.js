"use client";

import React from "react";
import { Box, TextField } from "@mui/material";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker as MuiDatePicker } from '@mui/x-date-pickers/DatePicker';

const FormDatePicker = ({
  label,
  value,
  onChange,
  required = false,
  fullWidth = true,
  size = "small",
  minDate,
  maxDate,
  disablePast = false,
  ...props
}) => {
  return (
    <Box className="datepicker">
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <MuiDatePicker
          label={label}
          value={value || null}
          onChange={onChange}
          minDate={minDate}
          maxDate={maxDate}
          disablePast={disablePast}
          {...props}
          renderInput={(params) => (
            <TextField {...params} fullWidth={fullWidth} size={size} required={required} />
          )}
        />
      </LocalizationProvider>
    </Box>
  );
};

export default FormDatePicker;


