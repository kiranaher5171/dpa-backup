"use client";

import React from "react";
import { Autocomplete, Box, TextField } from "@mui/material";

const SingleSelectAutocomplete = ({
  label,
  value,
  onChange,
  options = [],
  placeholder,
  fullWidth = true,
  size = "small",
  required = false,
  textFieldProps = {},
  ...props
}) => {
  const handleChange = (event, newValue) => {
    if (onChange) {
      onChange(newValue);
    }
  };

  return (
    <Box className="textfield">
      <Autocomplete
        options={options}
        value={value ?? null}
        onChange={handleChange}
        getOptionLabel={(option) =>
          typeof option === "string" ? option : option?.label ?? ""
        }
        isOptionEqualToValue={(option, val) =>
          (typeof option === "string" ? option : option?.value ?? option?.label) ===
          (typeof val === "string" ? val : val?.value ?? val?.label)
        }
        {...props}
        renderInput={(params) => (
          <TextField
            {...params}
            label={label}
            placeholder={placeholder}
            size={size}
            fullWidth={fullWidth}
            required={required}
            InputLabelProps={{
              required: required,
              sx: {
                "& .MuiFormLabel-asterisk": {
                  color: "#d32f2f", // Red color for required asterisk
                },
              },
            }}
            {...textFieldProps}
          />
        )}
      />
    </Box>
  );
};

export default SingleSelectAutocomplete;


