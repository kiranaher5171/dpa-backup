"use client";

import React from "react";
import { Box, TextField } from "@mui/material";

const SimpleTextField = ({
  label,
  value,
  onChange,
  fullWidth = true,
  size = "small",
  required = false,
  ...props
}) => {
  return (
    <Box className="textfield">
      <TextField
        label={label}
        value={value}
        onChange={onChange}
        fullWidth={fullWidth}
        size={size}
        required={required}
        InputLabelProps={{
          required: required,
          sx: {
            "& .MuiFormLabel-asterisk": {
              color: "#d32f2f", // Red color for required asterisk
            },
          },
        }}
        {...props}
      />
    </Box>
  );
};

export default SimpleTextField;


