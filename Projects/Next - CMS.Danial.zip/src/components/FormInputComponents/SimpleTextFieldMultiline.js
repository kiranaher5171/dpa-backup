"use client";

import React from "react";
import { Box, TextField } from "@mui/material";

const SimpleTextFieldMultiline = ({
  label,
  value,
  onChange,
  fullWidth = true,
  size = "small",
  ...props
}) => {
  return (
    <Box className="textfield">
      <TextField
        label={label}
        value={value}
        onChange={onChange}
        fullWidth={fullWidth}
        size={size}
        multiline
        rows={1}
        {...props}
      />
    </Box>
  );
};

export default SimpleTextFieldMultiline;


