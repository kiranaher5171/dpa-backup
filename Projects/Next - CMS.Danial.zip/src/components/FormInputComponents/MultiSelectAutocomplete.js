"use client";

import React from "react";
import { Autocomplete, Box, TextField, Tooltip, Typography } from "@mui/material";

const MultiSelectAutocomplete = ({
  label,
  value = [],
  onChange,
  options = [],
  placeholder = "Select...",
  fullWidth = true,
  size = "small",
  textFieldProps = {},
  showCountSummary = true,
  ...props
}) => {
  const handleChange = (event, newValue) => {
    if (onChange) {
      onChange(newValue);
    }
  };

  const getOptionLabelSafe = (option) =>
    typeof option === "string" ? option : option?.label ?? "";

  const selectedLabels = (value || []).map(getOptionLabelSafe).join(", ");

  return (
    <Box className="textfield">
    <Tooltip
      title={
        value && value.length > 0
          ? selectedLabels
          : "No items selected"
      }
      placement="top"
      arrow
    >
      <Autocomplete
        multiple
        options={options}
        value={value}
        onChange={handleChange}
        disableCloseOnSelect
        getOptionLabel={getOptionLabelSafe}
        isOptionEqualToValue={(option, val) =>
          (typeof option === "string"
            ? option
            : option?.value ?? option?.label) ===
          (typeof val === "string"
            ? val
            : val?.value ?? val?.label)
        }
        renderTags={(selected) =>
          showCountSummary && selected.length > 0 ? (
            <Typography variant="body2" sx={{ ml: 1 }}>
              {selected.length} selected
            </Typography>
          ) : null
        }
        {...props}
        renderInput={(params) => (
          <TextField
            {...params}
            label={label}
            placeholder={
              value && value.length === 0 ? placeholder : ""
            }
            size={size}
            fullWidth={fullWidth}
            {...textFieldProps}
          />
        )}
      />
    </Tooltip>
    </Box>
  );
};

export default MultiSelectAutocomplete;

