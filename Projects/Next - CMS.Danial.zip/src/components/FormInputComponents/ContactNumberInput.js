"use client";

import React from "react";
import { Box, Typography } from "@mui/material";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";

const ContactNumberInput = ({
  label,
  value,
  onChange,
  placeholder = "Enter phone number",
  fullWidth = true,
  required = false,
  helperText,
  defaultCountry = "US",
  error = false,
  ...props
}) => {
  return (
    <Box id="contact-number-input" className="textfield" sx={{ width: fullWidth ? "100%" : "auto" }}>
      {label && (
        <Typography
          variant="caption"
          sx={{ display: "block", mb: 0.5 }}
          color={error ? "error" : "text.secondary"}
        >
          {label}
          {required && <span style={{ color: "#d32f2f" }}> *</span>}
        </Typography>
      )}

      <PhoneInput
        international
        defaultCountry={defaultCountry}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        {...props}
      />

      {helperText && (
        <Typography
          variant="caption"
          sx={{ mt: 0.5 }}
          color={error ? "error" : "text.secondary"}
        >
          {helperText}
        </Typography>
      )}
    </Box>
  );
};

export default ContactNumberInput;


