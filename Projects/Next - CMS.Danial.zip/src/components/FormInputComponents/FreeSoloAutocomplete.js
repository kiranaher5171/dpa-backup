"use client";

import React from "react";
import { Autocomplete, Box, TextField } from "@mui/material";

const FreeSoloAutocomplete = ({
  label,
  value,
  onChange,
  options = [],
  placeholder,
  fullWidth = true,
  size = "small",
  textFieldProps = {},
  ...props
}) => {
  const handleInputChange = (event, newInputValue) => {
    if (onChange) {
      onChange(newInputValue);
    }
  };

  return (
    <Box className="textfield">
    <Autocomplete
      freeSolo
      options={options}
      inputValue={value ?? ""}
      onInputChange={handleInputChange}
      {...props}
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          placeholder={placeholder}
          size={size}
          fullWidth={fullWidth}
          {...textFieldProps}
        />
      )}
    />
    </Box>
  );
};

export default FreeSoloAutocomplete;


