"use client";

import React, { useState, useMemo, useRef } from "react";
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Button,
  IconButton,
  Grid,
  Switch,
  useMediaQuery,
  useTheme,
  Avatar,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import PhotoCameraOutlinedIcon from "@mui/icons-material/PhotoCameraOutlined";
import SideDrawer from "@/components/SideDrawer";
import SimpleTextField from "@/components/FormInputComponents/SimpleTextField";
import SingleSelectAutocomplete from "@/components/FormInputComponents/SingleSelectAutocomplete";
import ContactNumberInput from "@/components/FormInputComponents/ContactNumberInput";
import { AllCommunityModule, ModuleRegistry } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";

ModuleRegistry.registerModules([AllCommunityModule]);

const ACCESS_PERMISSIONS = [
  "System User Actions",
  "Tenant onboarding",
  "Tenant Users",
  "Multiple Tenant Admins",
  "Project",
  "Audit logs",
  "Tenant Actions",
  "User Actions",
  "Correspondence metadata",
  "Prime contract metadata",
  "Sub contract metadata",
  "Risks & Opportunities metadata",
  "Schedule Analytics metadata",
  "Legal metadata",
  "Payment Applications metadata",
  "Front-End Contract Negotiation metadata",
];

const PERMISSION_COLUMNS = ["No Access", "View", "Create", "Update", "Delete"];

const DEFAULT_PROFILE_IMAGE = "https://media.istockphoto.com/id/1327592506/vector/default-avatar-photo-placeholder-icon-grey-profile-picture-business-man.jpg?s=612x612&w=0&k=20&c=BpR0FVaEa5F24GIw7K8nMWiiGmbb8qmhfkpXcp1dhQg=";

function TabPanel({ children, value, index, ...rest }) {
  return (
    <div role="tabpanel" hidden={value !== index} {...rest}>
      {value === index && <Box sx={{ py: 2 }}>{children}</Box>}
    </div>
  );
}

export default function ProfileDrawer({ open, onClose }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [tabValue, setTabValue] = useState(0);
  const [firstName, setFirstName] = useState("Platform");
  const [lastName, setLastName] = useState("Owner");
  const [mobileNo, setMobileNo] = useState("+913452348761");
  const [country, setCountry] = useState({ label: "India", value: "India" });
  const [state, setState] = useState({ label: "Maharashtra", value: "Maharashtra" });
  const [city, setCity] = useState({ label: "Akalkot", value: "Akalkot" });
  const [profilePhotoUrl, setProfilePhotoUrl] = useState(null);
  const profilePhotoInputRef = useRef(null);
  const [permissions, setPermissions] = useState(() =>
    ACCESS_PERMISSIONS.reduce(
      (acc, name) => ({
        ...acc,
        [name]: { noAccess: true, view: false, create: false, update: false, delete: false },
      }),
      {}
    )
  );

  const handleTabChange = (_, newValue) => setTabValue(newValue);

  const handleProfilePhotoChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setProfilePhotoUrl(url);
    }
    e.target.value = "";
  };

  const handleProfilePhotoClick = () => profilePhotoInputRef.current?.click();

  const handlePermissionChange = (permName, field, checked) => {
    setPermissions((prev) => ({
      ...prev,
      [permName]: { ...prev[permName], [field]: checked },
    }));
  };

  const accessControlRowData = useMemo(
    () =>
      ACCESS_PERMISSIONS.map((name) => ({
        permissionName: name,
        ...permissions[name],
      })),
    [permissions]
  );

  const accessControlColDefs = useMemo(
    () => [
      {
        field: "permissionName",
        headerName: "Permission Name",
        width: 200,
        cellStyle: { fontSize: "13px" },
      },
      ...PERMISSION_COLUMNS.map((col) => {
        const field = col === "No Access" ? "noAccess" : col.toLowerCase();
        return {
          field,
          headerName: col,
          width: 80,
          sortable: false,
          wrapHeaderText: col === "No Access",
          cellStyle: { fontSize: "13px" },
          cellRenderer: (params) => (
            <Switch
              size="small"
              color="primary"
              checked={!!params.data?.[field]}
              onChange={(e) => handlePermissionChange(params.data?.permissionName, field, e.target.checked)}
            />
          ),
        };
      }),
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: false,
      filter: false,
      resizable: false,
      suppressMovable: true,
    }),
    []
  );

  const getAccessControlRowStyle = (params) => ({
    backgroundColor: params.node.rowIndex % 2 === 0 ? "#f9f9f9" : "#ffffff",
  });

  const handleApplyChanges = () => {
    // TODO: submit profile changes
    onClose?.();
  };

  const drawerWidth = { xs: "100%", sm: 540, md: 650 };

  return (
    <SideDrawer open={open} onClose={onClose} width={drawerWidth}>
      <Box
        className="right-drawer-header"
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 1,
          minWidth: 0,
        }}
      >
        <Typography variant="h5" className="primary fw6" sx={{ fontSize: { xs: "1.1rem", sm: "1.25rem" }, overflow: "hidden", textOverflow: "ellipsis" }}>
          Update User Profile
        </Typography>
        <IconButton size="small" onClick={onClose} aria-label="close" sx={{ flexShrink: 0 }}>
          <CloseIcon />
        </IconButton>
      </Box>

      <Box
        className="right-drawer-content-profile"
        sx={{
          width: "100%",
          minWidth: 0,
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box sx={{ borderBottom: 1, borderColor: "divider", width: "100%", mb: 2 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            variant={isMobile ? "scrollable" : "fullWidth"}
            scrollButtons={isMobile ? "auto" : false}
            allowScrollButtonsMobile={isMobile}
            className="form-tabs w100" 
          >
            <Tab label="My Profile" id="profile-tab-0" aria-controls="profile-tabpanel-0" />
            <Tab label="Login & Security" id="profile-tab-1" aria-controls="profile-tabpanel-1" />
            <Tab label="Access & Control" id="profile-tab-2" aria-controls="profile-tabpanel-2" />
          </Tabs>
        </Box>

        <Box sx={{ flex: 1, overflow: "auto", minHeight: 0 }}>
          {/* My Profile */}
          <TabPanel value={tabValue} index={0}>
            <Typography variant="h5" className="primary fw6" mb={3}>
              My Profile
            </Typography>
            <Grid container spacing={2} sx={{ width: "100%" }}>
              <Grid item xs={12}>
                <SimpleTextField label="First Name" required fullWidth value={firstName} onChange={(e) => setFirstName(e.target.value)} />
              </Grid>
              <Grid item xs={12}>
                <SimpleTextField label="Last Name" required fullWidth value={lastName} onChange={(e) => setLastName(e.target.value)} />
              </Grid>
              <Grid item xs={12}>
                <ContactNumberInput fullWidth required value={mobileNo} onChange={setMobileNo} defaultCountry="IN" /> 
              </Grid>
              <Grid item xs={12}>
                <SingleSelectAutocomplete
                  label="Country"
                  required
                  fullWidth
                  options={[{ label: "India", value: "India" }]}
                  value={country}
                  onChange={setCountry}
                />
              </Grid>
              <Grid item xs={12}>
                <SingleSelectAutocomplete
                  label="State"
                  required
                  fullWidth
                  options={[{ label: "Maharashtra", value: "Maharashtra" }]}
                  value={state}
                  onChange={setState}
                />
              </Grid>
              <Grid item xs={12}>
                <SingleSelectAutocomplete
                  label="City"
                  fullWidth
                  options={[{ label: "Akalkot", value: "Akalkot" }]}
                  value={city}
                  onChange={setCity}
                />
              </Grid>
              <Grid item xs={12}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 2,
                    py: 2,
                  }}
                >
                  <input
                    ref={profilePhotoInputRef}
                    type="file"
                    accept="image/*"
                    hidden
                    onChange={handleProfilePhotoChange}
                  />
                  <Box
                    onClick={handleProfilePhotoClick}
                    sx={{
                      position: "relative",
                      cursor: "pointer",
                      "&:hover .profile-photo-overlay": { opacity: 1 },
                    }}
                  >
                    <Avatar
                      src={profilePhotoUrl || DEFAULT_PROFILE_IMAGE}
                      sx={{
                        width: 120,
                        height: 120,
                        bgcolor: "#e0e0e0",
                        border: "3px solid",
                        borderColor: "divider",
                        fontSize: "2.5rem",
                      }}
                    >
                      {(firstName?.[0] || "") + (lastName?.[0] || "")}
                    </Avatar>
                    <Box
                      className="profile-photo-overlay"
                      sx={{
                        position: "absolute",
                        inset: 0,
                        borderRadius: "50%",
                        bgcolor: "rgba(0,0,0,0.45)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        opacity: 0,
                        transition: "opacity 0.2s ease",
                      }}
                    >
                      <PhotoCameraOutlinedIcon sx={{ color: "#fff", fontSize: 36 }} />
                    </Box>
                  </Box>
                  <Button
                    component="span"
                    variant="text"
                    size="small"
                    onClick={handleProfilePhotoClick}
                    sx={{
                      color: "var(--secondary)",
                      fontWeight: 600,
                      textTransform: "none", 
                    }}
                  >
                    {profilePhotoUrl ? "Change profile photo" : "Upload profile photo"}
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </TabPanel>

          {/* Login & Security */}
          <TabPanel value={tabValue} index={1}>
            <Typography variant="h5" className="primary fw6" mb={3}>
              Login & Security
            </Typography>
            <Grid container spacing={2} sx={{ width: "100%" }}>
              <Grid item xs={12}>
                <SimpleTextField
                  label="Email"
                  fullWidth
                  value="platform.owner123@gmail.com"
                />
              </Grid>
              <Grid item xs={12}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 1 }}>
                  <Button variant="contained" className="primary-btn" size="small">Change Password</Button>
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>Session Timeout Policy</Typography>
                <Typography variant="body2" sx={{ wordBreak: "break-word" }}>Idle: 3600s (default), Length: 28800s (default)</Typography>
              </Grid>
            </Grid>
          </TabPanel>

          {/* Access & Control */}
          <TabPanel value={tabValue} index={2}>
            <Typography variant="h5" className="primary fw6" mb={3}>
              Access & Control
            </Typography>
            <Box
              sx={{
                width: "100%",
                height: "min(420px, 50vh)",
                minHeight: 320,
                position: "relative",
              }}
            >
              <AgGridReact
                rowData={accessControlRowData}
                columnDefs={accessControlColDefs}
                defaultColDef={defaultColDef}
                getRowStyle={getAccessControlRowStyle}
                headerHeight={40}
                autoHeaderHeight={true}
                rowHeight={40}
                suppressCellFocus={true}
                pagination={false}
                animateRows={true}
                domLayout="normal" 
              />
            </Box>
          </TabPanel>
        </Box>
      </Box>

      <Box className="right-drawer-footer fx_fe gap1" sx={{ flexWrap: "wrap", gap: 1 }}>
        <Button
          variant="outlined"
          className="primary-outlined-btn"
          onClick={onClose}
          size="small" 
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          className="primary-btn"
          onClick={handleApplyChanges}
          size="small" 
        >
          Apply Changes
        </Button>
      </Box>
    </SideDrawer>
  );
}
