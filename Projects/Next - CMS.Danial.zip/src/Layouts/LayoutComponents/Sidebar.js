"use client";
import { Box, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Tooltip, Typography, Popover } from '@mui/material'
import React from 'react'
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { IoDocumentTextOutline } from "react-icons/io5";
import { HiOutlineClipboardDocumentList } from "react-icons/hi2";
import { HiOutlineDocumentDuplicate } from "react-icons/hi2";
import { HiOutlineExclamationTriangle } from "react-icons/hi2";
import { HiOutlineCurrencyDollar } from "react-icons/hi2";
import { HiOutlineCalendar } from "react-icons/hi2";
import { HiOutlineFolder } from "react-icons/hi2";
import { MdGavel } from "react-icons/md";
import { HiOutlineCog6Tooth } from "react-icons/hi2";
import { HiOutlineUserGroup } from "react-icons/hi2";
import { HiOutlineUsers } from "react-icons/hi2";
import { HiOutlineBuildingOffice2 } from "react-icons/hi2";
import { SlEnvolopeLetter } from "react-icons/sl";
import { TbContract } from "react-icons/tb";
import { MdOutlineAdminPanelSettings } from "react-icons/md";
import { RiDashboardHorizontalLine } from "react-icons/ri";
import { TbUsersGroup, TbFileText } from "react-icons/tb";
// Export menuItems configuration for use in other components
export const menuItems = [
    // { href: '/platform-owner-dashboard', title: 'Platform Owner Dashboard', icon: <IoDocumentTextOutline /> },
    // { href: '/system-management', title: 'System Management', icon: <IoDocumentTextOutline /> },
    // { href: '/tenant-management', title: 'Tenant Management', icon: <IoDocumentTextOutline /> },
    { href: '/prime-contract', title: 'Prime Contract', icon: <IoDocumentTextOutline /> },
    { href: '/subcontracts', title: 'Subcontracts', icon: <HiOutlineClipboardDocumentList /> },
    { href: '/correspondence', title: 'Correspondence', icon: <SlEnvolopeLetter /> },
    { href: '/front-end-contracts', title: 'Front-End Contracts', icon: <TbContract /> },
    { href: '/risks-opportunities', title: 'Risks & Opportunities', icon: <HiOutlineExclamationTriangle /> },
    { href: '/payment-applications', title: 'Payment Applications', icon: <HiOutlineCurrencyDollar /> },
    { href: '/schedule', title: 'Schedule', icon: <HiOutlineCalendar /> },
    { href: '/legal', title: 'Legal', icon: <MdGavel /> },
    { href: '/repository', title: 'Repository', icon: <HiOutlineFolder /> },
    { href: '/naming-convention', title: 'Naming Convention', icon: <TbFileText /> },
];

// Admin menu items
const adminMenuItems = [
    { href: '/platform-owner-dashboard', title: 'Platform Owner Dashboard', icon: <RiDashboardHorizontalLine /> },
    { href: '/super-admin-dashboard', title: 'Super Admin Dashboard', icon: <RiDashboardHorizontalLine /> },
    { href: '/tenant-admin-dashboard', title: 'Tenant Admin Dashboard', icon: <TbUsersGroup /> },
    { href: '/system-management', title: 'System Management', icon: <IoDocumentTextOutline /> },
    { href: '/tenant-management', title: 'Tenant Management', icon: <IoDocumentTextOutline /> },
    // { href: '/admin/projects', title: 'Projects', icon: <HiOutlineBuildingOffice2 /> },
    { href: '/admin/users', title: 'Users', icon: <HiOutlineUsers /> },
    // { href: '/admin/contract-party', title: 'Contract Party', icon: <HiOutlineUserGroup /> },
    // { href: '/admin/contract-party-users', title: 'Contract Party Users', icon: <TbUsersGroup /> },
];

const Sidebar = ({ open = true }) => {
    const pathname = usePathname();
    const [anchorEl, setAnchorEl] = React.useState(null);
    const adminMenuOpen = Boolean(anchorEl);


    const isActive = (href) => {
        if (href === '/' && pathname === '/') return true; // Exact match for home
        if (href !== '/' && pathname.startsWith(href)) return true; // Match base path and subpaths
        return false;
    };

    const handleAdminMenuClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleAdminMenuClose = () => {
        setAnchorEl(null);
    };


    return (
        <>

            <Box mt={0} id="menus">

                <Box
                    id="main-menus"
                    sx={{
                        height: 'calc(100vh - 175px)',
                        overflow: 'auto',
                        overflowX: 'hidden',
                    }}
                >
                    {menuItems.map((item) => (
                        <Link href={item.href} passHref key={item.href}>
                            <ListItem disablePadding sx={{ display: 'block' }}>
                                <ListItemButton
                                    disableRipple
                                    selected={isActive(item.href)}
                                    sx={[
                                        {
                                            minHeight: 48,
                                            px: 2.5,
                                        },
                                        open
                                            ? {
                                                justifyContent: 'initial',
                                            }
                                            : {
                                                justifyContent: 'center',
                                            },
                                    ]}
                                >
                                    <ListItemIcon
                                        sx={[
                                            {
                                                minWidth: 0,
                                                justifyContent: 'center',
                                            },
                                            open
                                                ? {
                                                    mr: 3,
                                                }
                                                : {
                                                    mr: 'auto',
                                                },
                                        ]}
                                    >
                                        <Tooltip title={item.title} arrow placement="right">
                                            <Box className="menu-icon">{item.icon}</Box>
                                        </Tooltip>
                                    </ListItemIcon>
                                    <ListItemText
                                        primary={item.title}
                                        sx={[
                                            open
                                                ? {
                                                    opacity: 1,
                                                }
                                                : {
                                                    opacity: 0,
                                                },
                                        ]}
                                    />
                                </ListItemButton>
                            </ListItem>
                        </Link>
                    ))}
                </Box>

                {/* Admin Access Menu Item */}
                <Box id="admin-access-menu"
                    sx={{
                        position: 'absolute',
                        bottom: 0,
                        background: '#394764',
                        width: '100%',
                    }}
                >
                    <ListItem disablePadding sx={{ display: 'block' }}>
                        <ListItemButton
                            disableRipple
                            onClick={handleAdminMenuClick}
                            sx={[
                                {
                                    minHeight: 48,
                                    px: 2.5,
                                },
                                open
                                    ? {
                                        justifyContent: 'initial',
                                    }
                                    : {
                                        justifyContent: 'center',
                                    },
                            ]}
                        >
                            <ListItemIcon
                                sx={[
                                    {
                                        minWidth: 0,
                                        justifyContent: 'center',
                                    },
                                    open
                                        ? {
                                            mr: 3,
                                        }
                                        : {
                                            mr: 'auto',
                                        },
                                ]}
                            >
                                <Tooltip title="Administration" arrow placement="right">
                                    <Box className="menu-icon">
                                        <MdOutlineAdminPanelSettings />
                                    </Box>
                                </Tooltip>
                            </ListItemIcon>
                            <ListItemText
                                primary="Administration"
                                sx={[
                                    open
                                        ? {
                                            opacity: 1,
                                        }
                                        : {
                                            opacity: 0,
                                        },
                                ]}
                            />
                        </ListItemButton>
                    </ListItem>
                </Box>
            </Box>

            {/* Admin Menu Popover */}
            <Popover
                open={adminMenuOpen}
                anchorEl={anchorEl}
                onClose={handleAdminMenuClose}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                }}
                slotProps={{
                    paper: {
                        sx: {
                            mt: 0.5,
                            ml: 0.5,
                            boxShadow: 3,
                        }
                    }
                }}
            >
                <List id="admin-menu-list" sx={{ minWidth: 250, py: 0 }}>
                    {adminMenuItems.map((item) => (
                        <Link href={item.href} passHref key={item.href} onClick={handleAdminMenuClose}>
                            <ListItem disablePadding>
                                <ListItemButton
                                    disableRipple
                                    selected={isActive(item.href)}
                                    sx={{
                                        minHeight: 48,
                                        px: 2.5,
                                    }}
                                >
                                    <ListItemIcon
                                        sx={{
                                            minWidth: 0,
                                            mr: 2,
                                            justifyContent: 'center',
                                        }}
                                    >
                                        <Box className="menu-admin-icon">{item.icon}</Box>
                                    </ListItemIcon>
                                    <ListItemText primary={item.title} />
                                </ListItemButton>
                            </ListItem>
                        </Link>
                    ))}
                </List>
            </Popover>




        </>
    )
}

export default Sidebar