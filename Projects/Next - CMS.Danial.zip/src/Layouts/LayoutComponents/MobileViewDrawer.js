import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import { styled } from '@mui/material/styles';
import { useState } from 'react';
import MenuOpenOutlinedIcon from '@mui/icons-material/MenuOpenOutlined';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import Sidebar from './Sidebar';
import { Typography, useMediaQuery } from '@mui/material';
import Link from 'next/link';
import Image from 'next/image';
import ProjectSelectionAutocomplete from '../MainlayoutComponents/ProjectSelectionAutocomplete';



export default function MobileViewDrawer() {

    const isSmallScreen = useMediaQuery('(max-width:400px)');


    const [state, setState] = useState({ left: false, });

    const toggleDrawer = (anchor, open) => () => {
        setState({ ...state, [anchor]: open });
    };

    const isDrawerOpen = state['left'];


    const DrawerHeader = styled('div')(({ theme }) => ({
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: theme.spacing(0, 1),
        ...theme.mixins.toolbar,
    }));



    return (
        <>

            <Box className="fx_fs">
                <IconButton
                    disableRipple
                    className='drawer_btn'
                    onClick={toggleDrawer('left', !isDrawerOpen)}
                    size='small'
                >
                    {isDrawerOpen ? <MenuOpenOutlinedIcon fontSize='small' className='white' /> : <MenuIcon fontSize='small' className='white' />}
                </IconButton>
            </Box>

            <Drawer id='mobile-drawer' open={isDrawerOpen} onClose={toggleDrawer('left', false)}>
                <Box id="mobile-drawer-header">
                    <ProjectSelectionAutocomplete />
                </Box>
                <Sidebar />
            </Drawer>
        </>
    );
}
