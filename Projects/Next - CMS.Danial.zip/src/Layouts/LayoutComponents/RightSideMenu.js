"use client";
import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import Menu from '@mui/material/Menu';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import EditIcon from '@mui/icons-material/Edit';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import Logout from '@mui/icons-material/Logout';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import { Badge, Box, List, ListItem, ListItemAvatar, ListItemButton, ListItemText, Stack, useMediaQuery, Dialog, DialogTitle, DialogContent, DialogContentText, IconButton, MenuItem } from '@mui/material';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { MdOutlineNotificationsNone } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";
import CloseIcon from '@mui/icons-material/Close';
import GlobalSearchAutocomplete from '../MainlayoutComponents/GlobalSearchAutocomplete';
import HelpCenterOutlinedIcon from '@mui/icons-material/HelpCenterOutlined';
import CustomDialog from '@/components/CustomDialog';
import ProfileDrawer from '@/components/ProfileDrawer';
import { PiSignOutBold } from "react-icons/pi";
export default function RightSideMenu() {
  const router = useRouter();
  const isSmallScreen = useMediaQuery('(max-width:767px)');
  const isTabletOrBelow = useMediaQuery('(max-width:900px)');
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [helpAnchorEl, setHelpAnchorEl] = React.useState(null);
  const [searchDialogOpen, setSearchDialogOpen] = React.useState(false);
  const [logoutDialogOpen, setLogoutDialogOpen] = React.useState(false);
  const [profileDrawerOpen, setProfileDrawerOpen] = React.useState(false);
  const open = Boolean(anchorEl);
  const helpMenuOpen = Boolean(helpAnchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleSearchDialogOpen = () => {
    setSearchDialogOpen(true);
  };

  const handleSearchDialogClose = () => {
    setSearchDialogOpen(false);
  };

  const handleHelpClick = (event) => {
    setHelpAnchorEl(event.currentTarget);
  };

  const handleHelpClose = () => {
    setHelpAnchorEl(null);
  };

  const handleHelpAction = (action) => {
    console.log(`Help action: ${action}`);
    // Add your help action logic here
    handleHelpClose();
  };

  const handleLogoutClick = () => {
    setLogoutDialogOpen(true);
    handleClose(); // Close the profile menu
  };

  const handleLogoutConfirm = () => {
    setLogoutDialogOpen(false);
    router.push('/');
  };

  const handleLogoutCancel = () => {
    setLogoutDialogOpen(false);
  };

  const handleEditProfile = () => {
    handleClose();
    setProfileDrawerOpen(true);
  };

  const handleProfileDrawerClose = () => {
    setProfileDrawerOpen(false);
  };

  return (
    <>
      <Stack direction="row" alignItems="center" justifyContent="flex-end" spacing={isSmallScreen ? 1 : 1}>

        {/* Search Field - Visible on desktop (above 900px) */}
        {!isTabletOrBelow && (
          <Box>
            <GlobalSearchAutocomplete />
          </Box>
        )}

        {/* Search Button - Visible on tablet/laptop (below 900px), hidden by default on desktop */}
        {isTabletOrBelow && (
          <Tooltip arrow title="Search">
            <IconButton
              size="medium"
              className='tertiary'
              onClick={handleSearchDialogOpen}
            >
              <IoSearchOutline style={{ fontSize: '22px' }} />
            </IconButton>
          </Tooltip>
        )}

        {/* Search Dialog for smaller screens */}
        <Dialog
          open={searchDialogOpen}
          onClose={handleSearchDialogClose}
          maxWidth="sm"
          id="search-dialog"
          fullWidth
          PaperProps={{
            sx: {
              borderRadius: 2,
            }
          }}
        >
          <DialogTitle sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            Search
            <IconButton
              aria-label="close"
              onClick={handleSearchDialogClose}
              sx={{ color: 'text.secondary' }}
            >
              <CloseIcon style={{ fontSize: '20px', color: 'var(--white)' }} />
            </IconButton>
          </DialogTitle>
          <DialogContent sx={{ pt: 1 }}>
            <GlobalSearchAutocomplete fullWidth={true} />
          </DialogContent>
        </Dialog>

        <Tooltip arrow title="Help & Support">
          <IconButton
            size="medium"
            className='tertiary'
            onClick={handleHelpClick}
            aria-controls={helpMenuOpen ? 'help-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={helpMenuOpen ? 'true' : undefined}
          >
            <HelpCenterOutlinedIcon style={{ fontSize: '22px' }} />
          </IconButton>
        </Tooltip>

        <Menu
          id="help-menu"
          anchorEl={helpAnchorEl}
          open={helpMenuOpen}
          onClose={handleHelpClose}
          MenuListProps={{
            'aria-labelledby': 'help-button',
          }}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
        >
          <MenuItem onClick={() => handleHelpAction('resources')}>
            Resources
          </MenuItem>
          <MenuItem onClick={() => handleHelpAction('faqs')}>
            FAQs
          </MenuItem>
          <MenuItem onClick={() => handleHelpAction('user_guides')}>
            User Guides
          </MenuItem>
        </Menu>

        <Tooltip arrow title="Notifications">
          <Link href="/notifications" passHref legacyBehavior>
            <IconButton size="medium" className='tertiary' component="span" aria-label="View notifications">
              <Badge className='notification-badge' badgeContent={4} color="error">
                <MdOutlineNotificationsNone style={{ fontSize: '22px' }} />
              </Badge>
            </IconButton>
          </Link>
        </Tooltip>

        <List id="profile" disablePadding>
          <ListItem disablePadding>
            <ListItemButton
              onClick={handleClick}
              aria-controls={open ? 'profile-menu' : undefined}
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
              sx={{ position: 'relative' }}
            >
              <ListItemAvatar>
                <Avatar>
                  AD
                </Avatar>
              </ListItemAvatar>
              <ListItemText primary={<Typography variant='h6' className='white'>Welcome, <span>Aida</span></Typography>} />
            </ListItemButton>
          </ListItem>
        </List>

        <Menu
          id="profile-menu"
          anchorEl={anchorEl}
          open={open}
          // onClose={handleClose}
          onClick={handleClose}
          PaperProps={{
            elevation: 0,
            sx: {
              overflow: 'visible',
              filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
              mt: 1,
              padding: 2,
              width: anchorEl ? anchorEl.offsetWidth : 'auto',
              minWidth: 250,
              '&::before': {
                content: '""',
                display: 'block',
                position: 'absolute',
                top: 0,
                right: 14,
                width: 10,
                height: 10,
                bgcolor: 'background.paper',
                transform: 'translateY(-50%) rotate(45deg)',
                zIndex: 0,
              },
            },
          }}
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
        >
          {/* User Profile Section - Not Clickable */}
          <Box id="user-profile-section" sx={{
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            // padding: 2,
            gap: 1,
            mb: 1
          }}>
            <Avatar sx={{ width: 50, height: 50 }}>
              AD
            </Avatar>
            <ListItemText
              primary="Aida"
              secondary="Email@example.com"
              sx={{ textAlign: 'left' }}
            />
          </Box>

          <Divider />

          {/* Mobile Number and Location */}
          <List id="user-details-section" sx={{ py: 0 }}>
            <ListItem disablePadding>
              <ListItemAvatar sx={{ minWidth: 40 }}>
                <Avatar sx={{ bgcolor: 'var(--secondary)', width: 30, height: 30, borderRadius: '2px' }}>
                  <AdminPanelSettingsIcon fontSize="small" style={{ color: 'var(--white)' }} />
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary="User Type"
                secondary="Admin"
              />
            </ListItem>
            <ListItem disablePadding>
              <ListItemAvatar sx={{ minWidth: 40 }}>
                <Avatar sx={{ bgcolor: 'var(--secondary)', width: 30, height: 30, borderRadius: '2px' }}>
                  <PhoneIcon fontSize="small" style={{ color: 'var(--white)' }} />
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary="Mobile Number"
                secondary="+918888888888"
              />
            </ListItem>
            <ListItem disablePadding>
              <ListItemAvatar sx={{ minWidth: 40 }}>
                <Avatar sx={{ bgcolor: 'var(--secondary)', width: 30, height: 30, borderRadius: '2px' }}>
                  <LocationOnIcon fontSize="small" style={{ color: 'var(--white)' }} />
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary="Location"
                secondary="Mumbai, India"
              />
            </ListItem>
          </List>

          <Divider />

          {/* Action Buttons */}
          <Box sx={{ pt: 1, display: 'flex', gap: 1 }}>
            <Button
              variant="contained"
              startIcon={<EditIcon />}
              className="primary-btn btn-small"
              onClick={handleEditProfile}
              fullWidth
              size="small"
            >
              Edit
            </Button>
            <Button
              variant="contained"
              className="btn-error btn-small"
              startIcon={<Logout />}
              onClick={handleLogoutClick}
              fullWidth
              size="small"
              color="error"
            >
              Sign Out
            </Button>
          </Box>
        </Menu>

        {/* Logout Confirmation Dialog */}
        <CustomDialog
          open={logoutDialogOpen}
          onClose={handleLogoutCancel}
          // title="Confirm Logout"
          maxWidth="xs"
          showCloseButton={false}
          actions={
            <>
              <Stack direction="row" justifyContent="center" alignItems="center" spacing={1} sx={{ width: '100%', mb: 2 }}>
                <Button onClick={handleLogoutCancel} className="primary-outlined-btn btn-small">
                  Cancel
                </Button>
                <Button onClick={handleLogoutConfirm} className="btn-error btn-small" variant="contained" autoFocus>
                  Yes
                </Button>
              </Stack>
            </>
          }
        >
          <DialogContentText pt={0} className='center'>
            <Box
              sx={{
                background: '#f000001f !important',
                height: '80px !important',
                width: '80px !important',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '16px',
                margin: '0 auto'
              }}
            >
              <PiSignOutBold style={{ fontSize: '35px', color: 'var(--error)' }} />
            </Box>
            <br />
            <Typography variant='h5' className='center fw5 primary'>Are you sure you want to sign out?</Typography>
          </DialogContentText>
        </CustomDialog>

        <ProfileDrawer open={profileDrawerOpen} onClose={handleProfileDrawerClose} />
      </Stack>
    </>
  );
}