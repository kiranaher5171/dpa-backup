import { Box, Typography } from '@mui/material'
import React from 'react'

const Footer = () => {
    return (
        <>

            <Box className='footer'>
                <Typography variant='h6' className='center white'>
                    Copyright © 2026 Daniel Cankoski. All rights reserved.
                </Typography>
            </Box>

        </>
    )
}

export default Footer