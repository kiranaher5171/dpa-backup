"use client";
import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import CssBaseline from '@mui/material/CssBaseline';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import { GoSidebarCollapse } from "react-icons/go";
import AppBar from '@mui/material/AppBar';
import Image from 'next/image';
import Logo from '../../../public/logo.png';
import '../MainLayout.css';
import { Button } from '@mui/material';
import { MdOutlineLogin } from "react-icons/md";

export default function Header() {


    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <AppBar position="fixed" className='appbar desktop'>
                <Toolbar className="fx_sb">
                    <Box className="fx_fs">
                        <Image src={Logo} alt='Logo' width={100} height={100} className='header-logo' />
                    </Box>
                    <Box className="fx_fs">
                        <Button variant='contained' color='primary' className='white-outlined-btn' endIcon={<MdOutlineLogin />}>Login</Button>
                    </Box>
                </Toolbar>
            </AppBar>
        </Box>
    );
}
