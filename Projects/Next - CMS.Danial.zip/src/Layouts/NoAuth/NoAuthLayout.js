import React from 'react'
import Header from './Header'
import Footer from './Footer'
import { Box } from '@mui/material'

const NoAuthLayout = ({ children }) => {
    return (
        <>
            <Header />
            <Box pt={"55px"} pb={"40px"} sx={{ minHeight: '100vh', backgroundColor: '#eefaff' }}>
                {children}
            </Box>
            <Footer />
        </>
    )
}

export default NoAuthLayout