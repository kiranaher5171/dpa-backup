import React from 'react'
import { Box, TextField, Autocomplete, InputAdornment } from '@mui/material'

export default function GlobalSearchAutocomplete({ fullWidth = false }) {
    const [searchValue, setSearchValue] = React.useState('');
    const [selectedModule, setSelectedModule] = React.useState('All');

    const moduleOptions = ['All', 'Module 1', 'Module 2', 'Module 3'];

    return (
        <Box className="dark-bg-textfield search-textfield" sx={fullWidth ? { width: '100%' } : {}}>
            <TextField
                variant='outlined'
                size='small'
                placeholder="Search here..."
                id="outlined-start-adornment"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                sx={{ m: 0, width: fullWidth ? '100%' : '40ch' }}
                InputProps={{
                    startAdornment: (
                        <InputAdornment position="start">
                            <Autocomplete
                                size='small'
                                value={selectedModule}
                                onChange={(event, newValue) => {
                                    setSelectedModule(newValue || 'All');
                                }}
                                options={moduleOptions}
                                sx={{ minWidth: 120 }}
                                renderInput={(params) => (
                                    <TextField {...params} size='small' placeholder="Select..." />
                                )}
                            />
                        </InputAdornment>
                    )
                }}
            />
        </Box>
    )
}

