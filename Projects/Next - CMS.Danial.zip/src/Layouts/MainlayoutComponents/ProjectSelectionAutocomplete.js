import React from 'react'
import { Box, TextField, Autocomplete, IconButton } from '@mui/material'
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';

export default function ProjectSelectionAutocomplete() {
    const [selectedProject, setSelectedProject] = React.useState(null);
    const [favorites, setFavorites] = React.useState(new Set());

    const projectOptions = [
        'Project1',
        'Project2',
        'Project3',
        'Project4',
        'Project5',
    ];

    const handleStarClick = (event, project) => {
        event.stopPropagation(); // Prevent option selection when clicking star
        setFavorites(prev => {
            const newFavorites = new Set(prev);
            if (newFavorites.has(project)) {
                newFavorites.delete(project);
            } else {
                newFavorites.add(project);
            }
            return newFavorites;
        });
    };

    return (
        <>

            <Box className="dark-bg-textfield search-textfield">
                <Autocomplete
                    value={selectedProject}
                    onChange={(event, newValue) => {
                        setSelectedProject(newValue);
                    }}
                    options={projectOptions}
                    sx={{
                        width: 200
                    }}
                    renderOption={(props, option) => (
                        <Box
                            {...props}
                            component="li"
                            sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                width: '100%',
                            }}
                        > 
                            <IconButton
                                size="small"
                                onClick={(e) => handleStarClick(e, option)}
                                sx={{
                                    padding: '4px',
                                    '&:hover': {
                                        backgroundColor: 'transparent',
                                    },
                                }}
                            >
                                {favorites.has(option) ? (
                                    <StarIcon sx={{ fontSize: '18px', color: '#ffc107' }} />
                                ) : (
                                    <StarBorderIcon sx={{ fontSize: '18px', color: 'text.secondary' }} />
                                )}
                            </IconButton>
                            <span>{option}</span>
                        </Box>
                    )}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            variant='outlined'
                            size='small'
                            placeholder='Select Project...'
                        />
                    )}
                />
            </Box>


        </>
    )
}