"use client";
import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import CssBaseline from '@mui/material/CssBaseline';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import './MainLayout.css';
import MobileViewDrawer from './LayoutComponents/MobileViewDrawer';
import RightSideMenu from './LayoutComponents/RightSideMenu';
import Sidebar from './LayoutComponents/Sidebar';
import ProjectSelectionAutocomplete from './MainlayoutComponents/ProjectSelectionAutocomplete';
import { usePathname } from 'next/navigation';
import { GoSidebarCollapse } from "react-icons/go";
import { GoSidebarExpand } from "react-icons/go"; 
import Logo from "../../public/logo.png"
import Image from 'next/image';

const drawerWidth = 250;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => {
  const closedWidth = `calc(${theme.spacing(7)} + 1px)`;
  const closedWidthSm = `calc(${theme.spacing(8)} + 1px)`;

  return {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    }),
    ...(!open && {
      marginLeft: closedWidth,
      width: `calc(100% - ${closedWidth})`,
      [theme.breakpoints.up('sm')]: {
        marginLeft: closedWidthSm,
        width: `calc(100% - ${closedWidthSm})`,
      },
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    }),
  };
});

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme }) => ({
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
    boxSizing: 'border-box',
    variants: [
      {
        props: ({ open }) => open,
        style: {
          ...openedMixin(theme),
          '& .MuiDrawer-paper': openedMixin(theme),
        },
      },
      {
        props: ({ open }) => !open,
        style: {
          ...closedMixin(theme),
          '& .MuiDrawer-paper': closedMixin(theme),
        },
      },
    ],
  }),
);

const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme }) => ({
    flexGrow: 1,
    padding: theme.spacing(0),
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  }),
);


export default function MainLayout({ children }) {
  const pathname = usePathname();

  // Initialize drawer state - start with false, then read from localStorage after mount
  const [open, setOpen] = React.useState(false);
  const [mounted, setMounted] = React.useState(false);

  // Read from localStorage after component mounts (client-side only)
  React.useEffect(() => {
    setMounted(true);
    if (typeof window !== 'undefined') {
      const savedState = localStorage.getItem('drawerOpen');
      if (savedState !== null) {
        setOpen(savedState === 'true');
      }
    }
  }, []);

  // Save drawer state to localStorage whenever it changes
  React.useEffect(() => {
    if (mounted && typeof window !== 'undefined') {
      localStorage.setItem('drawerOpen', open.toString());
    }
  }, [open, mounted]);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };


  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />

      <AppBar position="fixed" open={open} className='appbar desktop'>
        <Toolbar className="fx_sb">
          <Box className="fx_fs">

            <Box sx={{ minWidth: '52px' }}>
              <IconButton className='white' onClick={open ? handleDrawerClose : handleDrawerOpen}>
                {!open ? <GoSidebarCollapse /> : <GoSidebarExpand />}
              </IconButton>
            </Box>

            <Box className="fx_fs gap2">
              <Image src={Logo} alt='Logo' width={100} height={100} className='header-logo' />
              <ProjectSelectionAutocomplete />
            </Box>
          </Box>
          <Box>
            <RightSideMenu />
          </Box>
        </Toolbar>
      </AppBar>

      <AppBar position="fixed" open={open} className='appbar mobile' >
        <Toolbar className='fx_sb'>
          <Box className="fx_fs gap2">
            <MobileViewDrawer />
            <Image src={Logo} alt='Logo' width={100} height={100} className='header-logo' />
          </Box>

          <Box>
            <RightSideMenu />
          </Box>

        </Toolbar>
      </AppBar>

      <Drawer variant="permanent" open={open}>
        <Sidebar open={open} />
      </Drawer>

      <Main open={open} className='sidebar' id='main-contain'>
        <Box id="main-contain-page">
          {children}
        </Box>
      </Main>
    </Box>
  );
}
