"""
Keep Windows awake while this script runs — reduces auto-lock and helps Teams
stay on "Available" by resetting the idle timer (tiny mouse move).

Stop with Ctrl+C in this window. Uses only the Python standard library on Windows.

Note: Employer or IT policies may restrict this; use only where allowed.
"""

from __future__ import annotations

import argparse
import ctypes
import signal
import sys
import time

# --- Windows: prevent sleep / display off while running ---
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

# mouse_event: relative move
MOUSEEVENTF_MOVE = 0x0001


def _set_prevent_sleep(enable: bool) -> None:
    if not enable:
        ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
        return
    ctypes.windll.kernel32.SetThreadExecutionState(
        ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    )


def _nudge_mouse() -> None:
    """1 pixel out and back — resets idle without being noticeable."""
    u = ctypes.windll.user32
    u.mouse_event(MOUSEEVENTF_MOVE, 1, 0, 0, 0)
    u.mouse_event(MOUSEEVENTF_MOVE, -1, 0, 0, 0)


def main() -> int:
    if sys.platform != "win32":
        print("This script is for Windows only.", file=sys.stderr)
        return 1

    p = argparse.ArgumentParser(
        description="Keep system awake and nudge idle timer (helps Teams stay Available)."
    )
    p.add_argument(
        "-i",
        "--interval",
        type=float,
        default=45.0,
        metavar="SEC",
        help="Seconds between idle nudges and sleep-state refresh (default: 45)",
    )
    args = p.parse_args()
    if args.interval < 5:
        print("Interval must be at least 5 seconds.", file=sys.stderr)
        return 1

    stop = False

    def _on_sigint(_sig, _frame) -> None:
        nonlocal stop
        stop = True

    signal.signal(signal.SIGINT, _on_sigint)
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, _on_sigint)

    _set_prevent_sleep(True)
    print(
        "Awake mode ON — preventing sleep/display off; nudging idle timer every "
        f"{args.interval:.0f}s. Press Ctrl+C to stop."
    )

    try:
        while not stop:
            time.sleep(args.interval)
            if stop:
                break
            _set_prevent_sleep(True)
            _nudge_mouse()
    finally:
        _set_prevent_sleep(False)
        print("Awake mode OFF — normal power/lock behavior restored.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
