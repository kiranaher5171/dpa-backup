# DPA HONO - HR Connect Application

This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## 🔒 Security Features

This application includes comprehensive security measures:

- ✅ **Latest Next.js version** with all security patches
- ✅ **Content Security Policy (CSP)** with nonce-based script execution
- ✅ **Security headers** (XSS Protection, Frame Options, Content Type Options)
- ✅ **Input sanitization** and validation utilities
- ✅ **Rate limiting** headers
- ✅ **HTTPS enforcement** in production
- ✅ **Secure session management**
- ✅ **Password strength validation**
- ✅ **File upload restrictions**

## Getting Started

First, install dependencies:

```bash
npm install
```

Then, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Security Configuration

The application uses several security layers:

1. **Middleware Security** (`src/app/middleware.js`) - Sets security headers and CSP
2. **Next.js Config** (`next.config.mjs`) - Additional security headers
3. **Security Utils** (`src/utils/security.js`) - Input validation and sanitization
4. **Security Config** (`src/config/security.js`) - Centralized security settings

### Environment Variables

Create a `.env.local` file with the following variables:

```env
NODE_ENV=production
HTTPS=true
NEXTAUTH_SECRET=your-super-secret-key-here
SESSION_SECRET=your-session-secret-here
```

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js/) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/deployment) for more details.
