import MainLayout from '@/layouts/MainLayout'
import { Box, Container } from '@mui/material'
import React from 'react'
import HrPoliciesTable from './HrPoliciesTable'

const page = () => {
    return (
        <>
            <MainLayout>
                <Container maxWidth>
                <Box className="whitebox" mt={2}>
                        <HrPoliciesTable />
                    </Box>
                </Container>
            </MainLayout>
        </>
    )
}

export default page