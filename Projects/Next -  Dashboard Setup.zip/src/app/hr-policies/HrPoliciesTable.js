"use client";
import React from 'react'
import { Box, IconButton, Typography, TextField, InputAdornment } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/table_components/TableSkeleton';
import { IoSearchOutline } from "react-icons/io5";
import AgGridPagination from '@/components/table_components/AgGridPagination';
import AgGridInfo from '@/components/table_components/AgGridInfo';


const UsersRoleTable = () => {

    const [gridApi, setGridApi] = useState(null);

    const headerHeight = 45;
    const rowHeight = 60;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: false, flex: 1, suppressMovable: true, resizable: false,
    }


    const [rowData] = useState([
        {},  {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {},
    ]);


    const columnDefs = [
        {
            headerName: 'EMP ID', field: 'emp_code', minWidth: 120, maxWidth: 120, cellRenderer: () => "4820",
        },
        {
            headerName: 'Categories', field: 'Categories', minWidth: 220, cellRenderer: () => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,  ",
        },
        {
            headerName: 'Description', field: 'Description', minWidth: 220, cellRenderer: () => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,  ",
        },
    ];


    return (
        <>
            <Box>
                <Box className="fx_sb" pb={2}>
                    <Typography variant='h5' className='fw6 black'>Organisation Policies</Typography>
                    <Box className="textfield standard auto-complete" mt={1}>
                        <TextField variant='outlined' placeholder='Search' size='small' fullWidth
                            slotProps={{
                                input: {
                                    startAdornment: <InputAdornment position="start">
                                        <IconButton disabled>
                                            <IoSearchOutline style={{ fontSize: '20px' }} />
                                        </IconButton>
                                    </InputAdornment>
                                },
                            }}
                        />
                    </Box>
                </Box>
                {loading ? (
                    <Box style={{ width: '100%', height: '62vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz" style={{ width: '100%', height: '62vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                            />
                        </Box>

                        <Box className="fx_sb" pt={1}>
                            <AgGridInfo />
                            <AgGridPagination />
                        </Box>
                    </>
                )}
            </Box>

        </>
    )
}

export default UsersRoleTable