import React from 'react'
import MainLayout from '@/layouts/MainLayout'
import { Typography, Box, Container, Stack, Button, IconButton } from '@mui/material'
import Grid from '@mui/material/Grid2';
import { LuClock3 } from "react-icons/lu";
import { BiBadgeCheck } from "react-icons/bi";
import { IoMdCheckmarkCircleOutline } from "react-icons/io";
import { IoClose } from "react-icons/io5";
import { GiGlassCelebration } from "react-icons/gi";


const page = () => {
    return (
        <>
            <MainLayout>

                <Container maxWidth>

                    <Box mt={1}>
                        <Grid container spacing={2} alignItems="center" justifyContent="flex-start">
                            <Grid size={{ lg: 3, md: 7, sm: 6, xs: 12 }}>
                                <Box className="whitebox" sx={{ height: "43vh" }}>
                                    <Box className="fx_fs card-heading" pb={1}> 
                                        <Typography variant='h5' className='fw5 text'>Need To Act</Typography>
                                    </Box>

                                </Box>
                            </Grid>

                            <Grid size={{ lg: 3, md: 5, sm: 6, xs: 12 }}>
                                <Box className="whitebox" sx={{ height: "43vh" }}>
                                    <Box className="fx_fs card-heading" pb={1}>
                                        <IconButton  >
                                            <LuClock3 className='primary' />
                                        </IconButton>
                                        <Typography variant='h5' className='fw5 text'>Calendar</Typography>
                                    </Box>

                                </Box>
                            </Grid>

                            <Grid size={{ lg: 3, md: 5, sm: 6, xs: 12 }}>
                                <Box className="whitebox" sx={{ height: "43vh" }}>
                                    <Box className="fx_fs card-heading" pb={1}>
                                        <IconButton  >
                                            <LuClock3 className='primary' />
                                        </IconButton>
                                        <Typography variant='h5' className='fw5 text'>Upcoming Holidays</Typography>
                                    </Box>

                                </Box>
                            </Grid>

                            <Grid size={{ lg: 3, md: 7, sm: 6, xs: 12 }}>
                                <Box className="whitebox" sx={{ height: "43vh" }}>
                                    <Box className="fx_fs card-heading" pb={1}>
                                        <IconButton  >
                                            <GiGlassCelebration className='primary' />
                                        </IconButton>
                                        <Typography variant='h5' className='fw5 text'>Today's Wishes</Typography>
                                    </Box>

                                </Box>
                            </Grid>
                        </Grid>
                    </Box>

                </Container>

            </MainLayout>

        </>
    )
}

export default page