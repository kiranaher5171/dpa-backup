"use client";
import React from 'react'
import { Box, Tooltip, IconButton, Typography, Button, Stack, TextField, InputAdornment } from '@mui/material';
import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import TableSkeleton from '@/components/table_components/TableSkeleton';
import Avatar from '@mui/material/Avatar';
import { FaCircle } from "react-icons/fa";
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { IoBanSharp } from "react-icons/io5";
import { MdOutlineFileDownloadDone } from "react-icons/md";
import { LuRefreshCcw } from "react-icons/lu";
import { IoSearchOutline } from "react-icons/io5";
import { Autocomplete } from "@mui/material";
import { IoMdAdd } from "react-icons/io";
import Grid from '@mui/material/Grid2';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import SimpleDatePicker from '@/components/SimpleDatePicker';
import PdfDropzone from '@/components/UploadDropzone';
import Link from 'next/link';
import Image from 'next/image';
import CloseIcon from '@mui/icons-material/Close';


const dummyOptions = [
    { label: 'Option 1' },
    { label: 'Option 2' },
    { label: 'Option 3' },
    { label: 'Option 4' },
]



const UsersRoleTable = () => {


    const [gridApi, setGridApi] = useState(null);

    const headerHeight = 45;
    const rowHeight = 60;

    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => { setLoading(false); }, 500);
        return () => clearTimeout(timer);
    }, []);

    function onGridReady(params) {
        setGridApi(params.api);
    }

    const defaultColDef = {
        sortable: true, checkboxSelection: false, autoHeight: true, filter: false, flex: 1, suppressMovable: true, resizable: false,
    }


    const [rowData] = useState([
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' },
        { status: 'enabled' },
        { status: 'disabled' }
    ]);


    const columnDefs = [
        {
            headerName: 'EMP ID', field: 'emp_code', minWidth: 120, maxWidth: 120, cellRenderer: () => "# 4820",
        },
        {
            headerName: 'Username', field: 'name', minWidth: 160, cellRenderer: () => "John Doe",
        },
        {
            headerName: 'Status', field: 'status', minWidth: 140, maxWidth: 150, cellRenderer: (params) => {
                const status = params.data.status;
                if (status === 'enabled') {
                    return <Typography variant='h6' className='approved txt-tag'> <FaCircle /> Enabled</Typography>;
                } else {
                    return <Typography variant='h6' className='canceled txt-tag'> <FaCircle /> Disabled</Typography>;
                }
            }
        },
        {
            headerName: 'Last login', field: 'login', minWidth: 220, cellRenderer: () => "12th Feb 2025 | 12:00:00",
        },
        {
            headerName: 'Owner', field: 'owner', minWidth: 220, cellRenderer: () => "Accountant/HR",
        },
        {
            headerName: 'Actions', field: 'action', minWidth: 160, maxWidth: 160,
            cellRenderer: () => {
                return (
                    <>
                        <Box className="left"> 
                            <Box className="fx_sb gap1">
                                <Tooltip arrow title="Disable User">
                                    <IconButton className='sq_ico_btn red' onClick={handleOpen2}><IoBanSharp /></IconButton>
                                </Tooltip>
                                <Tooltip arrow title="Grant a New Role">
                                    <IconButton className='sq_ico_btn green' onClick={handleOpen}><MdOutlineFileDownloadDone /></IconButton>
                                </Tooltip>
                                <Tooltip arrow title="Revoke a Role">
                                    <IconButton className='sq_ico_btn yellow' onClick={handleOpen}><LuRefreshCcw /></IconButton>
                                </Tooltip>
                            </Box> 
                        </Box>
                    </>
                );
            },
        },
    ];


    // For Dialog
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => { setOpen(true); };
    const handleClose = () => { setOpen(false); };

    // For Success Dialog
    const [open1, setOpen1] = React.useState(false);
    const handleOpen1 = () => { setOpen(false); setOpen1(true); };
    const handleClose1 = () => { setOpen1(false); };


    // For Failed Dialog
    const [open2, setOpen2] = React.useState(false);
    const handleOpen2 = () => { setOpen2(true); };
    const handleClose2 = () => { setOpen2(false); };

    return (
        <>
            <Box>
                <Box className="fx_sb" pb={2}>
                    <Typography variant='h5' className='fw6 black'>Recent Claims</Typography> 
                    <Box className="textfield standard auto-complete" mt={1}>
                        <TextField variant='outlined' placeholder='Search' size='small' fullWidth
                            slotProps={{
                                input: {
                                    startAdornment: <InputAdornment position="start">
                                        <IconButton disabled>
                                            <IoSearchOutline style={{ fontSize: '20px' }} />
                                        </IconButton>
                                    </InputAdornment>
                                },
                            }}
                        />
                    </Box>
                </Box>
                {loading ? (
                    <Box style={{ width: '100%', height: '66vh', overflow: 'hidden' }} area-label="Loading...">
                        <TableSkeleton />
                    </Box>
                ) : (
                    <>
                        <Box className="ag-theme-quartz" style={{ width: '100%', height: '66vh' }}>
                            <AgGridReact
                                onGridReady={onGridReady}
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowHeight={rowHeight}
                                headerHeight={headerHeight}
                            />
                        </Box>
                    </>
                )}
            </Box>





            <Dialog
                open={open}
                onClose={handleClose}
                fullWidth
                maxWidth="xs"
            >
                <DialogTitle id="scroll-dialog-title">
                    <Typography variant='h5' className='fw6 black'>Grant User a Role</Typography>
                </DialogTitle>

                <DialogContent>


                    <Grid container spacing={3} alignItems="flex-start" justifyContent="flex-start">
                        <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                            <Box className='textfield auto-complete' mt={2}>
                                <Typography variant='body1' className='label'>Grant User a Role</Typography>
                                <TextField placeholder="Username" variant='outlined' fullWidth />
                            </Box>
                        </Grid>

                        <Grid size={{ lg: 12, md: 12, sm: 12, xs: 12 }}>
                            <Box className='textfield auto-complete' pb={'40px'}>
                                <Typography variant='body1' className='label'>Role to grant</Typography>
                                <Autocomplete
                                    disablePortal
                                    options={dummyOptions}
                                    fullWidth
                                    renderInput={(params) => <TextField {...params} placeholder="Select" variant='outlined' />}
                                />
                            </Box>
                        </Grid>

                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Button variant='outlined' className='btn-tertiary-outlined' onClick={handleClose}>Cancel</Button>
                    <Button variant='contained' className='btn-primary-contained' onClick={handleOpen1}>Grant</Button>
                </DialogActions>
            </Dialog>



            {/* Role Granted */}
            <Dialog
                open={open1}
                onClose={handleClose1}
                fullWidth
                maxWidth="xs"
            >
                <IconButton
                    aria-label="close"
                    onClick={handleClose1}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent>

                    <Box className="center w100">
                        <Box pt={3} className="center">
                            <Box className="dialog-img primary">
                                <MdOutlineFileDownloadDone />
                            </Box>
                        </Box>
                        <Box py={3}>
                            <Typography variant='h5' className='primary fw6'>
                                Role Granted Successfully
                            </Typography>
                        </Box>
                    </Box>

                </DialogContent>

            </Dialog>



            {/* Role Granted */}
            <Dialog
                open={open2}
                onClose={handleClose2}
                fullWidth
                maxWidth="xs"
            >
                <IconButton
                    aria-label="close"
                    onClick={handleClose2}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent>

                    <Box className="center w100">
                        <Box pt={3} className="center">
                            <Box className="dialog-img red">
                                <IoBanSharp />
                            </Box>
                        </Box>
                        <Box py={3}>
                            <Typography variant='h5' className='primary fw6'>
                                User Disabled Successfully
                            </Typography>
                        </Box>
                    </Box>

                </DialogContent>

            </Dialog>

        </>
    )
}

export default UsersRoleTable