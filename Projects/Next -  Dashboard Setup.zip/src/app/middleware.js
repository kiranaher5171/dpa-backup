import { NextResponse } from 'next/server';
import crypto from 'crypto';

export function middleware(req) {
  // Generate a nonce for each request
  const nonce = crypto.randomBytes(16).toString('base64');

  // Enhanced CSP header with additional security measures
  const csp = `
    default-src 'self';
    script-src 'self' 'nonce-${nonce}' 'unsafe-eval';
    style-src 'self' 'nonce-${nonce}' 'unsafe-inline';
    img-src 'self' blob: data: https:;
    font-src 'self' data: blob: font:;
    connect-src 'self';
    object-src 'none';
    base-uri 'self';
    form-action 'self';
    frame-ancestors 'none';
    upgrade-insecure-requests;
    block-all-mixed-content;
  `.replace(/\n/g, '').trim();

  // Create a response object
  const res = NextResponse.next();

  // Set comprehensive security headers
  res.headers.set('Content-Security-Policy', csp);
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('X-Frame-Options', 'DENY');
  res.headers.set('X-XSS-Protection', '1; mode=block');
  res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), browsing-topics=()');
  
  // Add HSTS header for HTTPS environments
  if (req.nextUrl.protocol === 'https:') {
    res.headers.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  }

  // Rate limiting headers (basic implementation)
  res.headers.set('X-RateLimit-Limit', '100');
  res.headers.set('X-RateLimit-Remaining', '99');

  // Optionally pass the nonce to the response if needed elsewhere
  req.nextUrl.searchParams.set('nonce', nonce);

  return res;
}
